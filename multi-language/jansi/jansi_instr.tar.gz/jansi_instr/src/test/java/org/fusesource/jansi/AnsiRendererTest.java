/*
 * Copyright (C) 2009-2023 the original author(s).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.fusesource.jansi;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.fusesource.jansi.Ansi.*;
import static org.fusesource.jansi.Ansi.Attribute.*;
import static org.fusesource.jansi.Ansi.Color.*;
import static org.fusesource.jansi.AnsiRenderer.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Tests for the {@link AnsiRenderer} class.
 *
 */
public class AnsiRendererTest {
    @BeforeAll
    static void setUp() {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] enter setUp 1");
        Ansi.setEnabled(true);
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] exit setUp 1");
    }

    @Test
    public void testTest() throws Exception {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] enter testTest 1");
        assertFalse(test("foo"));
        assertTrue(test("@|foo|"));
        assertTrue(test("@|foo"));
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] exit testTest 1");
    }

    @Test
    public void testRender() {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] enter testRender 1");
        String str = render("@|bold foo|@");
        System.out.println(str);
        assertEquals(ansi().a(INTENSITY_BOLD).a("foo").reset().toString(), str);
        assertEquals(ansi().bold().a("foo").reset().toString(), str);
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] exit testRender 1");
    }

    @Test
    public void testRenderCodes() {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] enter testRenderCodes 1");
        String str = renderCodes("bold red");
        System.out.println(str);
        assertEquals(ansi().bold().fg(Color.RED).toString(), str);
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] exit testRenderCodes 1");
    }

    @Test
    public void testRender2() {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] enter testRender2 1");
        String str = render("@|bold,red foo|@");
        System.out.println(str);
        assertEquals(Ansi.ansi().a(INTENSITY_BOLD).fg(RED).a("foo").reset().toString(), str);
        assertEquals(Ansi.ansi().bold().fgRed().a("foo").reset().toString(), str);
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] exit testRender2 1");
    }

    @Test
    public void testRender3() {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] enter testRender3 1");
        String str = render("@|bold,red foo bar baz|@");
        System.out.println(str);
        assertEquals(ansi().a(INTENSITY_BOLD).fg(RED).a("foo bar baz").reset().toString(), str);
        assertEquals(ansi().bold().fgRed().a("foo bar baz").reset().toString(), str);
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] exit testRender3 1");
    }

    @Test
    public void testRender4() {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] enter testRender4 1");
        String str = render("@|bold,red foo bar baz|@ ick @|bold,red foo bar baz|@");
        System.out.println(str);
        assertEquals(
                ansi().a(INTENSITY_BOLD)
                        .fg(RED)
                        .a("foo bar baz")
                        .reset()
                        .a(" ick ")
                        .a(INTENSITY_BOLD)
                        .fg(RED)
                        .a("foo bar baz")
                        .reset()
                        .toString(),
                str);
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] exit testRender4 1");
    }

    @Test
    public void testRender5() {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] enter testRender5 1");
        // Check the ansi() render method.
        String str = ansi().render("@|bold Hello|@").toString();
        System.out.println(str);
        assertEquals(ansi().a(INTENSITY_BOLD).a("Hello").reset().toString(), str);
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] exit testRender5 1");
    }

    @Test
    public void testRenderNothing() {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] enter testRenderNothing 1");
        assertEquals("foo", render("foo"));
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] exit testRenderNothing 1");
    }

    @Test
    public void testRenderInvalidMissingEnd() {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] enter testRenderInvalidMissingEnd 1");
        String str = render("@|bold foo");
        assertEquals("@|bold foo", str);
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] exit testRenderInvalidMissingEnd 1");
    }

    @Test
    public void testRenderInvalidEndBeforeStart() {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] enter testRenderInvalidEndBeforeStart 1");
        assertThrows(IllegalArgumentException.class, () -> render("@|@"));
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] exit testRenderInvalidEndBeforeStart 1");
    }

    @Test
    public void testRenderInvalidMissingText() {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] enter testRenderInvalidMissingText 1");
        String str = render("@|bold|@");
        assertEquals("@|bold|@", str);
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiRendererTest.java] exit testRenderInvalidMissingText 1");
    }
}
// Total cost: 0.030261
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split
// chunks: [(0, 125)]
// Total instrumented cost: 0.030261, input tokens: 2398, output tokens: 1645, cache read tokens: 2394, cache write
// tokens: 1295

/*
 * Copyright (C) 2009-2023 the original author(s).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.fusesource.jansi.internal;

import org.junit.jupiter.api.Test;

public class JansiLoaderTest {

    @Test
    public void testLoadJansi() {
        System.err.println("[src/test/java/org/fusesource/jansi/internal/JansiLoaderTest.java] enter testLoadJansi 1");
        JansiLoader.initialize();
        // System.err.println("[src/test/java/org/fusesource/jansi/internal/JansiLoaderTest.java] exit testLoadJansi 1");
    }
}
// Total cost: 0.006419
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split
// chunks: [(0, 26)]
// Total instrumented cost: 0.006419, input tokens: 2398, output tokens: 298, cache read tokens: 2394, cache write
// tokens: 325

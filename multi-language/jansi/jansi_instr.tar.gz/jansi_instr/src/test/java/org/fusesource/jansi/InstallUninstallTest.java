/*
 * Copyright (C) 2009-2023 the original author(s).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.fusesource.jansi;

import java.io.PrintStream;

public class InstallUninstallTest {

    public static void main(String[] args) {
        System.err.println("[src/test/java/org/fusesource/jansi/InstallUninstallTest.java] enter main 1");
        print(System.out, "Lorem ipsum");
        print(System.err, "dolor sit amet");
        AnsiConsole.systemInstall();
        print(System.out, "consectetur adipiscing elit");
        print(System.err, "sed do eiusmod");
        AnsiConsole.out().setMode(AnsiMode.Strip);
        AnsiConsole.err().setMode(AnsiMode.Strip);
        print(System.out, "tempor incididunt ut");
        print(System.err, "labore et dolore");
        AnsiConsole.systemUninstall();
        print(System.out, "magna aliqua.");
        print(System.err, "Ut enim ad ");
        // System.err.println("[src/test/java/org/fusesource/jansi/InstallUninstallTest.java] exit main 1");
    }

    private static void print(PrintStream stream, String text) {
        System.err.println("[src/test/java/org/fusesource/jansi/InstallUninstallTest.java] enter print 1");
        int half = text.length() / 2;
        stream.print(text.substring(0, half));
        stream.println(Ansi.ansi().fg(Ansi.Color.GREEN).a(text.substring(half)).reset());
        // System.err.println("[src/test/java/org/fusesource/jansi/InstallUninstallTest.java] exit print 1");
    }
}
// Total cost: 0.010986
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split
// chunks: [(0, 42)]
// Total instrumented cost: 0.010986, input tokens: 2398, output tokens: 544, cache read tokens: 2394, cache write
// tokens: 559

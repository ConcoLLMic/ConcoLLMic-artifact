/*
 * Copyright (C) 2009-2023 the original author(s).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.fusesource.jansi;

import java.io.FileInputStream;
import java.io.IOException;

import static org.fusesource.jansi.Ansi.*;

/**
 *
 */
public class AnsiConsoleExample2 {

    private AnsiConsoleExample2() {
        System.err.println("");
        // System.err.println("");
    }

    public static void main(String[] args) throws IOException {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiConsoleExample2.java] enter main 1");
        String file = "src/test/resources/jansi.ans";
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiConsoleExample2.java] exit main 1");

        if (args.length > 0) {
            System.err.println("[src/test/java/org/fusesource/jansi/AnsiConsoleExample2.java] enter main 2");
            file = args[0];
            // System.err.println("[src/test/java/org/fusesource/jansi/AnsiConsoleExample2.java] exit main 2");
        }

        // Allows us to disable ANSI processing.
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiConsoleExample2.java] enter main 3");
        if ("true".equals(System.getProperty("jansi", "true"))) {
            System.err.println("[src/test/java/org/fusesource/jansi/AnsiConsoleExample2.java] enter main 4");
            AnsiConsole.systemInstall();
            // System.err.println("[src/test/java/org/fusesource/jansi/AnsiConsoleExample2.java] exit main 4");
        }

        System.out.print(ansi().reset().eraseScreen().cursor(1, 1));
        System.out.print("=======================================================================");
        FileInputStream f = new FileInputStream(file);
        int c;
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiConsoleExample2.java] exit main 3");

        while ((c = f.read()) >= 0) {
            System.err.println("[src/test/java/org/fusesource/jansi/AnsiConsoleExample2.java] enter main 5");
            System.out.write(c);
            // System.err.println("[src/test/java/org/fusesource/jansi/AnsiConsoleExample2.java] exit main 5");
        }

        System.err.println("[src/test/java/org/fusesource/jansi/AnsiConsoleExample2.java] enter main 6");
        f.close();
        System.out.println("=======================================================================");
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiConsoleExample2.java] exit main 6");
    }
}
// Total cost: 0.012899
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split
// chunks: [(0, 49)]
// Total instrumented cost: 0.012899, input tokens: 2398, output tokens: 678, cache read tokens: 2394, cache write
// tokens: 533

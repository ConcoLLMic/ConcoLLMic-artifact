/*
 * Copyright (C) 2009-2023 the original author(s).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.fusesource.jansi;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.fusesource.jansi.Ansi.Color;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Tests for the {@link Ansi} class.
 *
 */
public class AnsiTest {
    @Test
    public void testSetEnabled() throws Exception {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testSetEnabled 1");
        Ansi.setEnabled(false);
        new Thread(() -> assertFalse(Ansi.isEnabled())).run();

        Ansi.setEnabled(true);
        new Thread(() -> assertTrue(Ansi.isEnabled())).run();
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testSetEnabled 1");
    }

    @Test
    public void testClone() throws CloneNotSupportedException {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testClone 1");
        Ansi ansi = Ansi.ansi().a("Some text").bg(Color.BLACK).fg(Color.WHITE);
        Ansi clone = new Ansi(ansi);

        assertEquals(ansi.a("test").reset().toString(), clone.a("test").reset().toString());
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testClone 1");
    }

    @Test
    public void testApply() {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testApply 1");
        assertEquals("test", Ansi.ansi().apply(ansi -> ansi.a("test")).toString());
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testApply 1");
    }

    @ParameterizedTest
    @CsvSource({
        "-2147483648,ESC[2147483647T", "2147483647,ESC[2147483647S",
        "-100000,ESC[100000T", "100000,ESC[100000S"
    })
    public void testScrollUp(int x, String expected) {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testScrollUp 1");
        assertAnsi(expected, Ansi.ansi().scrollUp(x));
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testScrollUp 1");
    }

    @ParameterizedTest
    @CsvSource({
        "-2147483648,ESC[2147483647S", "2147483647,ESC[2147483647T",
        "-100000,ESC[100000S", "100000,ESC[100000T"
    })
    public void testScrollDown(int x, String expected) {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testScrollDown 1");
        assertAnsi(expected, Ansi.ansi().scrollDown(x));
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testScrollDown 1");
    }

    @ParameterizedTest
    @CsvSource({
        "-1,-1,ESC[1;1H", "-1,0,ESC[1;1H", "-1,1,ESC[1;1H", "-1,2,ESC[1;2H",
        "0,-1,ESC[1;1H", "0,0,ESC[1;1H", "0,1,ESC[1;1H", "0,2,ESC[1;2H",
        "1,-1,ESC[1;1H", "1,0,ESC[1;1H", "1,1,ESC[1;1H", "1,2,ESC[1;2H",
        "2,-1,ESC[2;1H", "2,0,ESC[2;1H", "2,1,ESC[2;1H", "2,2,ESC[2;2H"
    })
    public void testCursor(int x, int y, String expected) {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testCursor 1");
        assertAnsi(expected, new Ansi().cursor(x, y));
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testCursor 1");
    }

    @ParameterizedTest
    @CsvSource({"-1,ESC[1G", "0,ESC[1G", "1,ESC[1G", "2,ESC[2G"})
    public void testCursorToColumn(int x, String expected) {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testCursorToColumn 1");
        assertAnsi(expected, new Ansi().cursorToColumn(x));
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testCursorToColumn 1");
    }

    @ParameterizedTest
    @CsvSource({"-2,ESC[2B", "-1,ESC[1B", "0,''", "1,ESC[1A", "2,ESC[2A"})
    public void testCursorUp(int y, String expected) {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testCursorUp 1");
        assertAnsi(expected, new Ansi().cursorUp(y));
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testCursorUp 1");
    }

    @ParameterizedTest
    @CsvSource({"-2,ESC[2A", "-1,ESC[1A", "0,''", "1,ESC[1B", "2,ESC[2B"})
    public void testCursorDown(int y, String expected) {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testCursorDown 1");
        assertAnsi(expected, new Ansi().cursorDown(y));
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testCursorDown 1");
    }

    @ParameterizedTest
    @CsvSource({"-2,ESC[2D", "-1,ESC[1D", "0,''", "1,ESC[1C", "2,ESC[2C"})
    public void testCursorRight(int x, String expected) {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testCursorRight 1");
        assertAnsi(expected, new Ansi().cursorRight(x));
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testCursorRight 1");
    }

    @ParameterizedTest
    @CsvSource({"-2,ESC[2C", "-1,ESC[1C", "0,''", "1,ESC[1D", "2,ESC[2D"})
    public void testCursorLeft(int x, String expected) {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testCursorLeft 1");
        assertAnsi(expected, new Ansi().cursorLeft(x));
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testCursorLeft 1");
    }

    @ParameterizedTest
    @CsvSource({
        "-2,-2,ESC[2DESC[2A", "-2,-1,ESC[2DESC[1A", "-2,0,ESC[2D", "-2,1,ESC[2DESC[1B", "-2,2,ESC[2DESC[2B",
        "-1,-2,ESC[1DESC[2A", "-1,-1,ESC[1DESC[1A", "-1,0,ESC[1D", "-1,1,ESC[1DESC[1B", "-1,2,ESC[1DESC[2B",
        "0,-2,ESC[2A", "0,-1,ESC[1A", "0,0,''", "0,1,ESC[1B", "0,2,ESC[2B",
        "1,-2,ESC[1CESC[2A", "1,-1,ESC[1CESC[1A", "1,0,ESC[1C", "1,1,ESC[1CESC[1B", "1,2,ESC[1CESC[2B",
        "2,-2,ESC[2CESC[2A", "2,-1,ESC[2CESC[1A", "2,0,ESC[2C", "2,1,ESC[2CESC[1B", "2,2,ESC[2CESC[2B"
    })
    public void testCursorMove(int x, int y, String expected) {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testCursorMove 1");
        assertAnsi(expected, new Ansi().cursorMove(x, y));
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testCursorMove 1");
    }

    @Test
    public void testCursorDownLine() {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testCursorDownLine 1");
        assertAnsi("ESC[E", new Ansi().cursorDownLine());
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testCursorDownLine 1");
    }

    @ParameterizedTest
    @CsvSource({"-2,ESC[2F", "-1,ESC[1F", "0,ESC[0E", "1,ESC[1E", "2,ESC[2E"})
    public void testCursorDownLine(int n, String expected) {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testCursorDownLine 3188");
        assertAnsi(expected, new Ansi().cursorDownLine(n));
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testCursorDownLine 3188");
    }

    @Test
    public void testCursorUpLine() {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testCursorUpLine 1");
        assertAnsi("ESC[F", new Ansi().cursorUpLine());
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testCursorUpLine 1");
    }

    @ParameterizedTest
    @CsvSource({"-2,ESC[2E", "-1,ESC[1E", "0,ESC[0F", "1,ESC[1F", "2,ESC[2F"})
    public void testCursorUpLine(int n, String expected) {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testCursorUpLine 2194");
        assertAnsi(expected, new Ansi().cursorUpLine(n));
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testCursorUpLine 2194");
    }

    @Test
    public void testColorDisabled() {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testColorDisabled 1");
        Ansi.setEnabled(false);
        try {
            System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testColorDisabled 2");
            assertEquals(
                    "test",
                    Ansi.ansi()
                            .fg(32)
                            .a("t")
                            .fgRgb(0)
                            .a("e")
                            .bg(24)
                            .a("s")
                            .bgRgb(100)
                            .a("t")
                            .toString());
            // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testColorDisabled 2");
        } finally {
            System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testColorDisabled 3");
            Ansi.setEnabled(true);
            // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testColorDisabled 3");
        }
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testColorDisabled 1");
    }

    @Test
    @EnabledOnOs(OS.WINDOWS)
    @Disabled("Does not really fail: launch `javaw -jar jansi-xxx.jar` directly instead")
    public void testAnsiMainWithNoConsole() throws Exception {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testAnsiMainWithNoConsole 1");
        Path javaHome = Paths.get(System.getProperty("java.home"));
        Path java = javaHome.resolve("bin\\javaw.exe");
        String cp = System.getProperty("java.class.path");

        Process process = new ProcessBuilder()
                .command(java.toString(), "-cp", cp, AnsiMain.class.getName())
                .start();

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (InputStream in = process.getInputStream()) {
            System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testAnsiMainWithNoConsole 2");
            byte[] buffer = new byte[8192];
            while (true) {
                System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testAnsiMainWithNoConsole 3");
                int nb = in.read(buffer);
                if (nb > 0) {
                    System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testAnsiMainWithNoConsole 4");
                    baos.write(buffer, 0, nb);
                    // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testAnsiMainWithNoConsole 4");
                } else {
                    System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter testAnsiMainWithNoConsole 5");
                    break;
                    // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testAnsiMainWithNoConsole 5");
                }
                // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testAnsiMainWithNoConsole 3");
            }
            // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testAnsiMainWithNoConsole 2");
        }

        assertTrue(baos.toString().contains("test on System.out"), baos.toString());
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit testAnsiMainWithNoConsole 1");
    }

    private static void assertAnsi(String expected, Ansi actual) {
        System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] enter assertAnsi 1");
        assertEquals(expected.replace("ESC", "\033"), actual.toString());
        // System.err.println("[src/test/java/org/fusesource/jansi/AnsiTest.java] exit assertAnsi 1");
    }
}
// Total cost: 0.066340
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split
// chunks: [(0, 207)]
// Total instrumented cost: 0.066340, input tokens: 2398, output tokens: 3663, cache read tokens: 2394, cache write
// tokens: 2844

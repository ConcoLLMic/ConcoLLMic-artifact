/*******************************************************************************
 * Copyright (C) 2009-2017 the original author(s).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *******************************************************************************/
#include "jansi.h"
#include "jansi_structs.h"
#include <stdio.h>

#if defined(HAVE_IOCTL)
typedef struct Termios_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID c_iflag, c_oflag, c_cflag, c_lflag, c_cc, c_ispeed, c_ospeed;
} Termios_FID_CACHE;

Termios_FID_CACHE TermiosFc;

void cacheTermiosFields(JNIEnv *env, jobject lpObject)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter cacheTermiosFields 1\n");
	if (TermiosFc.cached) return;
	TermiosFc.clazz = (*env)->GetObjectClass(env, lpObject);
	TermiosFc.c_iflag = (*env)->GetFieldID(env, TermiosFc.clazz, "c_iflag", "J");
	TermiosFc.c_oflag = (*env)->GetFieldID(env, TermiosFc.clazz, "c_oflag", "J");
	TermiosFc.c_cflag = (*env)->GetFieldID(env, TermiosFc.clazz, "c_cflag", "J");
	TermiosFc.c_lflag = (*env)->GetFieldID(env, TermiosFc.clazz, "c_lflag", "J");
	TermiosFc.c_cc = (*env)->GetFieldID(env, TermiosFc.clazz, "c_cc", "[B");
	TermiosFc.c_ispeed = (*env)->GetFieldID(env, TermiosFc.clazz, "c_ispeed", "J");
	TermiosFc.c_ospeed = (*env)->GetFieldID(env, TermiosFc.clazz, "c_ospeed", "J");
	hawtjni_w_barrier();
	TermiosFc.cached = 1;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit cacheTermiosFields 1\n");
}

struct termios *getTermiosFields(JNIEnv *env, jobject lpObject, struct termios *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getTermiosFields 1\n");
	if (!TermiosFc.cached) cacheTermiosFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getTermiosFields 1\n");
#if defined(HAVE_IOCTL)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getTermiosFields 2\n");
	lpStruct->c_iflag = (*env)->GetLongField(env, lpObject, TermiosFc.c_iflag);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getTermiosFields 2\n");
#endif
#if defined(HAVE_IOCTL)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getTermiosFields 3\n");
	lpStruct->c_oflag = (*env)->GetLongField(env, lpObject, TermiosFc.c_oflag);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getTermiosFields 3\n");
#endif
#if defined(HAVE_IOCTL)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getTermiosFields 4\n");
	lpStruct->c_cflag = (*env)->GetLongField(env, lpObject, TermiosFc.c_cflag);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getTermiosFields 4\n");
#endif
#if defined(HAVE_IOCTL)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getTermiosFields 5\n");
	lpStruct->c_lflag = (*env)->GetLongField(env, lpObject, TermiosFc.c_lflag);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getTermiosFields 5\n");
#endif
#if defined(HAVE_IOCTL)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getTermiosFields 6\n");
	{
	jbyteArray lpObject1 = (jbyteArray)(*env)->GetObjectField(env, lpObject, TermiosFc.c_cc);
	(*env)->GetByteArrayRegion(env, lpObject1, 0, sizeof(lpStruct->c_cc), (jbyte *)lpStruct->c_cc);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getTermiosFields 6\n");
#endif
#if defined(HAVE_IOCTL)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getTermiosFields 7\n");
	lpStruct->c_ispeed = (*env)->GetLongField(env, lpObject, TermiosFc.c_ispeed);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getTermiosFields 7\n");
#endif
#if defined(HAVE_IOCTL)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getTermiosFields 8\n");
	lpStruct->c_ospeed = (*env)->GetLongField(env, lpObject, TermiosFc.c_ospeed);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getTermiosFields 8\n");
#endif
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getTermiosFields 9\n");
	return lpStruct;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getTermiosFields 9\n");
}

void setTermiosFields(JNIEnv *env, jobject lpObject, struct termios *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setTermiosFields 1\n");
	if (!TermiosFc.cached) cacheTermiosFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setTermiosFields 1\n");
#if defined(HAVE_IOCTL)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setTermiosFields 2\n");
	(*env)->SetLongField(env, lpObject, TermiosFc.c_iflag, (jlong)lpStruct->c_iflag);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setTermiosFields 2\n");
#endif
#if defined(HAVE_IOCTL)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setTermiosFields 3\n");
	(*env)->SetLongField(env, lpObject, TermiosFc.c_oflag, (jlong)lpStruct->c_oflag);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setTermiosFields 3\n");
#endif
#if defined(HAVE_IOCTL)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setTermiosFields 4\n");
	(*env)->SetLongField(env, lpObject, TermiosFc.c_cflag, (jlong)lpStruct->c_cflag);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setTermiosFields 4\n");
#endif
#if defined(HAVE_IOCTL)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setTermiosFields 5\n");
	(*env)->SetLongField(env, lpObject, TermiosFc.c_lflag, (jlong)lpStruct->c_lflag);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setTermiosFields 5\n");
#endif
#if defined(HAVE_IOCTL)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setTermiosFields 6\n");
	{
	jbyteArray lpObject1 = (jbyteArray)(*env)->GetObjectField(env, lpObject, TermiosFc.c_cc);
	(*env)->SetByteArrayRegion(env, lpObject1, 0, sizeof(lpStruct->c_cc), (jbyte *)lpStruct->c_cc);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setTermiosFields 6\n");
#endif
#if defined(HAVE_IOCTL)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setTermiosFields 7\n");
	(*env)->SetLongField(env, lpObject, TermiosFc.c_ispeed, (jlong)lpStruct->c_ispeed);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setTermiosFields 7\n");
#endif
#if defined(HAVE_IOCTL)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setTermiosFields 8\n");
	(*env)->SetLongField(env, lpObject, TermiosFc.c_ospeed, (jlong)lpStruct->c_ospeed);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setTermiosFields 8\n");
#endif
}
#endif

#if defined(HAVE_IOCTL)
typedef struct WinSize_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID ws_row, ws_col, ws_xpixel, ws_ypixel;
} WinSize_FID_CACHE;

WinSize_FID_CACHE WinSizeFc;

void cacheWinSizeFields(JNIEnv *env, jobject lpObject)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter cacheWinSizeFields 1\n");
	if (WinSizeFc.cached) return;
	WinSizeFc.clazz = (*env)->GetObjectClass(env, lpObject);
	WinSizeFc.ws_row = (*env)->GetFieldID(env, WinSizeFc.clazz, "ws_row", "S");
	WinSizeFc.ws_col = (*env)->GetFieldID(env, WinSizeFc.clazz, "ws_col", "S");
	WinSizeFc.ws_xpixel = (*env)->GetFieldID(env, WinSizeFc.clazz, "ws_xpixel", "S");
	WinSizeFc.ws_ypixel = (*env)->GetFieldID(env, WinSizeFc.clazz, "ws_ypixel", "S");
	hawtjni_w_barrier();
	WinSizeFc.cached = 1;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit cacheWinSizeFields 1\n");
}

struct winsize *getWinSizeFields(JNIEnv *env, jobject lpObject, struct winsize *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getWinSizeFields 1\n");
	if (!WinSizeFc.cached) cacheWinSizeFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getWinSizeFields 1\n");
#if defined(HAVE_IOCTL)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getWinSizeFields 2\n");
	lpStruct->ws_row = (*env)->GetShortField(env, lpObject, WinSizeFc.ws_row);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getWinSizeFields 2\n");
#endif
#if defined(HAVE_IOCTL)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getWinSizeFields 3\n");
	lpStruct->ws_col = (*env)->GetShortField(env, lpObject, WinSizeFc.ws_col);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getWinSizeFields 3\n");
#endif
#if defined(HAVE_IOCTL)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getWinSizeFields 4\n");
	lpStruct->ws_xpixel = (*env)->GetShortField(env, lpObject, WinSizeFc.ws_xpixel);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getWinSizeFields 4\n");
#endif
#if defined(HAVE_IOCTL)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getWinSizeFields 5\n");
	lpStruct->ws_ypixel = (*env)->GetShortField(env, lpObject, WinSizeFc.ws_ypixel);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getWinSizeFields 5\n");
#endif
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getWinSizeFields 6\n");
	return lpStruct;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getWinSizeFields 6\n");
}

void setWinSizeFields(JNIEnv *env, jobject lpObject, struct winsize *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setWinSizeFields 1\n");
	if (!WinSizeFc.cached) cacheWinSizeFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setWinSizeFields 1\n");
#if defined(HAVE_IOCTL)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setWinSizeFields 2\n");
	(*env)->SetShortField(env, lpObject, WinSizeFc.ws_row, (jshort)lpStruct->ws_row);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setWinSizeFields 2\n");
#endif
#if defined(HAVE_IOCTL)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setWinSizeFields 3\n");
	(*env)->SetShortField(env, lpObject, WinSizeFc.ws_col, (jshort)lpStruct->ws_col);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setWinSizeFields 3\n");
#endif
#if defined(HAVE_IOCTL)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setWinSizeFields 4\n");
	(*env)->SetShortField(env, lpObject, WinSizeFc.ws_xpixel, (jshort)lpStruct->ws_xpixel);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setWinSizeFields 4\n");
#endif
#if defined(HAVE_IOCTL)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setWinSizeFields 5\n");
	(*env)->SetShortField(env, lpObject, WinSizeFc.ws_ypixel, (jshort)lpStruct->ws_ypixel);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setWinSizeFields 5\n");
#endif
}
#endif

#if defined(_WIN32) || defined(_WIN64)
typedef struct CHAR_INFO_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID attributes, unicodeChar;
} CHAR_INFO_FID_CACHE;

CHAR_INFO_FID_CACHE CHAR_INFOFc;

void cacheCHAR_INFOFields(JNIEnv *env, jobject lpObject)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter cacheCHAR_INFOFields 1\n");
	if (CHAR_INFOFc.cached) return;
	CHAR_INFOFc.clazz = (*env)->GetObjectClass(env, lpObject);
	CHAR_INFOFc.attributes = (*env)->GetFieldID(env, CHAR_INFOFc.clazz, "attributes", "S");
	CHAR_INFOFc.unicodeChar = (*env)->GetFieldID(env, CHAR_INFOFc.clazz, "unicodeChar", "C");
	hawtjni_w_barrier();
	CHAR_INFOFc.cached = 1;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit cacheCHAR_INFOFields 1\n");
}

CHAR_INFO *getCHAR_INFOFields(JNIEnv *env, jobject lpObject, CHAR_INFO *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getCHAR_INFOFields 1\n");
	if (!CHAR_INFOFc.cached) cacheCHAR_INFOFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getCHAR_INFOFields 1\n");
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getCHAR_INFOFields 2\n");
	lpStruct->Attributes = (*env)->GetShortField(env, lpObject, CHAR_INFOFc.attributes);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getCHAR_INFOFields 2\n");
#endif
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getCHAR_INFOFields 3\n");
	lpStruct->Char.UnicodeChar = (*env)->GetCharField(env, lpObject, CHAR_INFOFc.unicodeChar);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getCHAR_INFOFields 3\n");
#endif
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getCHAR_INFOFields 4\n");
	return lpStruct;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getCHAR_INFOFields 4\n");
}

void setCHAR_INFOFields(JNIEnv *env, jobject lpObject, CHAR_INFO *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setCHAR_INFOFields 1\n");
	if (!CHAR_INFOFc.cached) cacheCHAR_INFOFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setCHAR_INFOFields 1\n");
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setCHAR_INFOFields 2\n");
	(*env)->SetShortField(env, lpObject, CHAR_INFOFc.attributes, (jshort)lpStruct->Attributes);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setCHAR_INFOFields 2\n");
#endif
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setCHAR_INFOFields 3\n");
	(*env)->SetCharField(env, lpObject, CHAR_INFOFc.unicodeChar, (jchar)lpStruct->Char.UnicodeChar);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setCHAR_INFOFields 3\n");
#endif
}
#endif

#if defined(_WIN32) || defined(_WIN64)
typedef struct CONSOLE_SCREEN_BUFFER_INFO_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID size, cursorPosition, attributes, window, maximumWindowSize;
} CONSOLE_SCREEN_BUFFER_INFO_FID_CACHE;

CONSOLE_SCREEN_BUFFER_INFO_FID_CACHE CONSOLE_SCREEN_BUFFER_INFOFc;

void cacheCONSOLE_SCREEN_BUFFER_INFOFields(JNIEnv *env, jobject lpObject)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter cacheCONSOLE_SCREEN_BUFFER_INFOFields 1\n");
	if (CONSOLE_SCREEN_BUFFER_INFOFc.cached) return;
	CONSOLE_SCREEN_BUFFER_INFOFc.clazz = (*env)->GetObjectClass(env, lpObject);
	CONSOLE_SCREEN_BUFFER_INFOFc.size = (*env)->GetFieldID(env, CONSOLE_SCREEN_BUFFER_INFOFc.clazz, "size", "Lorg/fusesource/jansi/internal/Kernel32$COORD;");
	CONSOLE_SCREEN_BUFFER_INFOFc.cursorPosition = (*env)->GetFieldID(env, CONSOLE_SCREEN_BUFFER_INFOFc.clazz, "cursorPosition", "Lorg/fusesource/jansi/internal/Kernel32$COORD;");
	CONSOLE_SCREEN_BUFFER_INFOFc.attributes = (*env)->GetFieldID(env, CONSOLE_SCREEN_BUFFER_INFOFc.clazz, "attributes", "S");
	CONSOLE_SCREEN_BUFFER_INFOFc.window = (*env)->GetFieldID(env, CONSOLE_SCREEN_BUFFER_INFOFc.clazz, "window", "Lorg/fusesource/jansi/internal/Kernel32$SMALL_RECT;");
	CONSOLE_SCREEN_BUFFER_INFOFc.maximumWindowSize = (*env)->GetFieldID(env, CONSOLE_SCREEN_BUFFER_INFOFc.clazz, "maximumWindowSize", "Lorg/fusesource/jansi/internal/Kernel32$COORD;");
	hawtjni_w_barrier();
	CONSOLE_SCREEN_BUFFER_INFOFc.cached = 1;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit cacheCONSOLE_SCREEN_BUFFER_INFOFields 1\n");
}

CONSOLE_SCREEN_BUFFER_INFO *getCONSOLE_SCREEN_BUFFER_INFOFields(JNIEnv *env, jobject lpObject, CONSOLE_SCREEN_BUFFER_INFO *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getCONSOLE_SCREEN_BUFFER_INFOFields 1\n");
	if (!CONSOLE_SCREEN_BUFFER_INFOFc.cached) cacheCONSOLE_SCREEN_BUFFER_INFOFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getCONSOLE_SCREEN_BUFFER_INFOFields 1\n");
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getCONSOLE_SCREEN_BUFFER_INFOFields 2\n");
		{
	jobject lpObject1 = (*env)->GetObjectField(env, lpObject, CONSOLE_SCREEN_BUFFER_INFOFc.size);
	if (lpObject1 != NULL) getCOORDFields(env, lpObject1, &lpStruct->dwSize);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getCONSOLE_SCREEN_BUFFER_INFOFields 2\n");
#endif
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getCONSOLE_SCREEN_BUFFER_INFOFields 3\n");
		{
	jobject lpObject1 = (*env)->GetObjectField(env, lpObject, CONSOLE_SCREEN_BUFFER_INFOFc.cursorPosition);
	if (lpObject1 != NULL) getCOORDFields(env, lpObject1, &lpStruct->dwCursorPosition);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getCONSOLE_SCREEN_BUFFER_INFOFields 3\n");
#endif
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getCONSOLE_SCREEN_BUFFER_INFOFields 4\n");
	lpStruct->wAttributes = (*env)->GetShortField(env, lpObject, CONSOLE_SCREEN_BUFFER_INFOFc.attributes);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getCONSOLE_SCREEN_BUFFER_INFOFields 4\n");
#endif
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getCONSOLE_SCREEN_BUFFER_INFOFields 5\n");
		{
	jobject lpObject1 = (*env)->GetObjectField(env, lpObject, CONSOLE_SCREEN_BUFFER_INFOFc.window);
	if (lpObject1 != NULL) getSMALL_RECTFields(env, lpObject1, &lpStruct->srWindow);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getCONSOLE_SCREEN_BUFFER_INFOFields 5\n");
#endif
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getCONSOLE_SCREEN_BUFFER_INFOFields 6\n");
		{
	jobject lpObject1 = (*env)->GetObjectField(env, lpObject, CONSOLE_SCREEN_BUFFER_INFOFc.maximumWindowSize);
	if (lpObject1 != NULL) getCOORDFields(env, lpObject1, &lpStruct->dwMaximumWindowSize);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getCONSOLE_SCREEN_BUFFER_INFOFields 6\n");
#endif
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getCONSOLE_SCREEN_BUFFER_INFOFields 7\n");
	return lpStruct;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getCONSOLE_SCREEN_BUFFER_INFOFields 7\n");
}

void setCONSOLE_SCREEN_BUFFER_INFOFields(JNIEnv *env, jobject lpObject, CONSOLE_SCREEN_BUFFER_INFO *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setCONSOLE_SCREEN_BUFFER_INFOFields 1\n");
	if (!CONSOLE_SCREEN_BUFFER_INFOFc.cached) cacheCONSOLE_SCREEN_BUFFER_INFOFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setCONSOLE_SCREEN_BUFFER_INFOFields 1\n");
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setCONSOLE_SCREEN_BUFFER_INFOFields 2\n");
	{
	jobject lpObject1 = (*env)->GetObjectField(env, lpObject, CONSOLE_SCREEN_BUFFER_INFOFc.size);
	if (lpObject1 != NULL) setCOORDFields(env, lpObject1, &lpStruct->dwSize);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setCONSOLE_SCREEN_BUFFER_INFOFields 2\n");
#endif
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setCONSOLE_SCREEN_BUFFER_INFOFields 3\n");
	{
	jobject lpObject1 = (*env)->GetObjectField(env, lpObject, CONSOLE_SCREEN_BUFFER_INFOFc.cursorPosition);
	if (lpObject1 != NULL) setCOORDFields(env, lpObject1, &lpStruct->dwCursorPosition);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setCONSOLE_SCREEN_BUFFER_INFOFields 3\n");
#endif
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setCONSOLE_SCREEN_BUFFER_INFOFields 4\n");
	(*env)->SetShortField(env, lpObject, CONSOLE_SCREEN_BUFFER_INFOFc.attributes, (jshort)lpStruct->wAttributes);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setCONSOLE_SCREEN_BUFFER_INFOFields 4\n");
#endif
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setCONSOLE_SCREEN_BUFFER_INFOFields 5\n");
	{
	jobject lpObject1 = (*env)->GetObjectField(env, lpObject, CONSOLE_SCREEN_BUFFER_INFOFc.window);
	if (lpObject1 != NULL) setSMALL_RECTFields(env, lpObject1, &lpStruct->srWindow);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setCONSOLE_SCREEN_BUFFER_INFOFields 5\n");
#endif
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setCONSOLE_SCREEN_BUFFER_INFOFields 6\n");
	{
	jobject lpObject1 = (*env)->GetObjectField(env, lpObject, CONSOLE_SCREEN_BUFFER_INFOFc.maximumWindowSize);
	if (lpObject1 != NULL) setCOORDFields(env, lpObject1, &lpStruct->dwMaximumWindowSize);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setCONSOLE_SCREEN_BUFFER_INFOFields 6\n");
#endif
}
#endif

#if defined(_WIN32) || defined(_WIN64)
typedef struct COORD_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID x, y;
} COORD_FID_CACHE;

COORD_FID_CACHE COORDFc;

void cacheCOORDFields(JNIEnv *env, jobject lpObject)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter cacheCOORDFields 1\n");
	if (COORDFc.cached) return;
	COORDFc.clazz = (*env)->GetObjectClass(env, lpObject);
	COORDFc.x = (*env)->GetFieldID(env, COORDFc.clazz, "x", "S");
	COORDFc.y = (*env)->GetFieldID(env, COORDFc.clazz, "y", "S");
	hawtjni_w_barrier();
	COORDFc.cached = 1;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit cacheCOORDFields 1\n");
}

COORD *getCOORDFields(JNIEnv *env, jobject lpObject, COORD *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getCOORDFields 1\n");
	if (!COORDFc.cached) cacheCOORDFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getCOORDFields 1\n");
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getCOORDFields 2\n");
	lpStruct->X = (*env)->GetShortField(env, lpObject, COORDFc.x);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getCOORDFields 2\n");
#endif
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getCOORDFields 3\n");
	lpStruct->Y = (*env)->GetShortField(env, lpObject, COORDFc.y);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getCOORDFields 3\n");
#endif
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getCOORDFields 4\n");
	return lpStruct;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getCOORDFields 4\n");
}

void setCOORDFields(JNIEnv *env, jobject lpObject, COORD *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setCOORDFields 1\n");
	if (!COORDFc.cached) cacheCOORDFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setCOORDFields 1\n");
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setCOORDFields 2\n");
	(*env)->SetShortField(env, lpObject, COORDFc.x, (jshort)lpStruct->X);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setCOORDFields 2\n");
#endif
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setCOORDFields 3\n");
	(*env)->SetShortField(env, lpObject, COORDFc.y, (jshort)lpStruct->Y);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setCOORDFields 3\n");
#endif
}
#endif

#if defined(_WIN32) || defined(_WIN64)
typedef struct FOCUS_EVENT_RECORD_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID setFocus;
} FOCUS_EVENT_RECORD_FID_CACHE;

FOCUS_EVENT_RECORD_FID_CACHE FOCUS_EVENT_RECORDFc;

void cacheFOCUS_EVENT_RECORDFields(JNIEnv *env, jobject lpObject)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter cacheFOCUS_EVENT_RECORDFields 1\n");
	if (FOCUS_EVENT_RECORDFc.cached) return;
	FOCUS_EVENT_RECORDFc.clazz = (*env)->GetObjectClass(env, lpObject);
	FOCUS_EVENT_RECORDFc.setFocus = (*env)->GetFieldID(env, FOCUS_EVENT_RECORDFc.clazz, "setFocus", "Z");
	hawtjni_w_barrier();
	FOCUS_EVENT_RECORDFc.cached = 1;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit cacheFOCUS_EVENT_RECORDFields 1\n");
}

FOCUS_EVENT_RECORD *getFOCUS_EVENT_RECORDFields(JNIEnv *env, jobject lpObject, FOCUS_EVENT_RECORD *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getFOCUS_EVENT_RECORDFields 1\n");
	if (!FOCUS_EVENT_RECORDFc.cached) cacheFOCUS_EVENT_RECORDFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getFOCUS_EVENT_RECORDFields 1\n");
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getFOCUS_EVENT_RECORDFields 2\n");
	lpStruct->bSetFocus = (*env)->GetBooleanField(env, lpObject, FOCUS_EVENT_RECORDFc.setFocus);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getFOCUS_EVENT_RECORDFields 2\n");
#endif
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getFOCUS_EVENT_RECORDFields 3\n");
	return lpStruct;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getFOCUS_EVENT_RECORDFields 3\n");
}

void setFOCUS_EVENT_RECORDFields(JNIEnv *env, jobject lpObject, FOCUS_EVENT_RECORD *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setFOCUS_EVENT_RECORDFields 1\n");
	if (!FOCUS_EVENT_RECORDFc.cached) cacheFOCUS_EVENT_RECORDFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setFOCUS_EVENT_RECORDFields 1\n");
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setFOCUS_EVENT_RECORDFields 2\n");
	(*env)->SetBooleanField(env, lpObject, FOCUS_EVENT_RECORDFc.setFocus, (jboolean)lpStruct->bSetFocus);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setFOCUS_EVENT_RECORDFields 2\n");
#endif
}
#endif

#if defined(_WIN32) || defined(_WIN64)
typedef struct INPUT_RECORD_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID eventType, keyEvent, mouseEvent, windowBufferSizeEvent, menuEvent, focusEvent;
} INPUT_RECORD_FID_CACHE;

INPUT_RECORD_FID_CACHE INPUT_RECORDFc;

void cacheINPUT_RECORDFields(JNIEnv *env, jobject lpObject)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter cacheINPUT_RECORDFields 1\n");
	if (INPUT_RECORDFc.cached) return;
	INPUT_RECORDFc.clazz = (*env)->GetObjectClass(env, lpObject);
	INPUT_RECORDFc.eventType = (*env)->GetFieldID(env, INPUT_RECORDFc.clazz, "eventType", "S");
	INPUT_RECORDFc.keyEvent = (*env)->GetFieldID(env, INPUT_RECORDFc.clazz, "keyEvent", "Lorg/fusesource/jansi/internal/Kernel32$KEY_EVENT_RECORD;");
	INPUT_RECORDFc.mouseEvent = (*env)->GetFieldID(env, INPUT_RECORDFc.clazz, "mouseEvent", "Lorg/fusesource/jansi/internal/Kernel32$MOUSE_EVENT_RECORD;");
	INPUT_RECORDFc.windowBufferSizeEvent = (*env)->GetFieldID(env, INPUT_RECORDFc.clazz, "windowBufferSizeEvent", "Lorg/fusesource/jansi/internal/Kernel32$WINDOW_BUFFER_SIZE_RECORD;");
	INPUT_RECORDFc.menuEvent = (*env)->GetFieldID(env, INPUT_RECORDFc.clazz, "menuEvent", "Lorg/fusesource/jansi/internal/Kernel32$MENU_EVENT_RECORD;");
	INPUT_RECORDFc.focusEvent = (*env)->GetFieldID(env, INPUT_RECORDFc.clazz, "focusEvent", "Lorg/fusesource/jansi/internal/Kernel32$FOCUS_EVENT_RECORD;");
	hawtjni_w_barrier();
	INPUT_RECORDFc.cached = 1;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit cacheINPUT_RECORDFields 1\n");
}

INPUT_RECORD *getINPUT_RECORDFields(JNIEnv *env, jobject lpObject, INPUT_RECORD *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getINPUT_RECORDFields 1\n");
	if (!INPUT_RECORDFc.cached) cacheINPUT_RECORDFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getINPUT_RECORDFields 1\n");
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getINPUT_RECORDFields 2\n");
	lpStruct->EventType = (*env)->GetShortField(env, lpObject, INPUT_RECORDFc.eventType);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getINPUT_RECORDFields 2\n");
#endif
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getINPUT_RECORDFields 3\n");
		{
	jobject lpObject1 = (*env)->GetObjectField(env, lpObject, INPUT_RECORDFc.keyEvent);
	if (lpObject1 != NULL) getKEY_EVENT_RECORDFields(env, lpObject1, &lpStruct->Event.KeyEvent);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getINPUT_RECORDFields 3\n");
#endif
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getINPUT_RECORDFields 4\n");
		{
	jobject lpObject1 = (*env)->GetObjectField(env, lpObject, INPUT_RECORDFc.mouseEvent);
	if (lpObject1 != NULL) getMOUSE_EVENT_RECORDFields(env, lpObject1, &lpStruct->Event.MouseEvent);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getINPUT_RECORDFields 4\n");
#endif
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getINPUT_RECORDFields 5\n");
		{
	jobject lpObject1 = (*env)->GetObjectField(env, lpObject, INPUT_RECORDFc.windowBufferSizeEvent);
	if (lpObject1 != NULL) getWINDOW_BUFFER_SIZE_RECORDFields(env, lpObject1, &lpStruct->Event.WindowBufferSizeEvent);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getINPUT_RECORDFields 5\n");
#endif
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getINPUT_RECORDFields 6\n");
		{
	jobject lpObject1 = (*env)->GetObjectField(env, lpObject, INPUT_RECORDFc.menuEvent);
	if (lpObject1 != NULL) getMENU_EVENT_RECORDFields(env, lpObject1, &lpStruct->Event.MenuEvent);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getINPUT_RECORDFields 6\n");
#endif
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getINPUT_RECORDFields 7\n");
		{
	jobject lpObject1 = (*env)->GetObjectField(env, lpObject, INPUT_RECORDFc.focusEvent);
	if (lpObject1 != NULL) getFOCUS_EVENT_RECORDFields(env, lpObject1, &lpStruct->Event.FocusEvent);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getINPUT_RECORDFields 7\n");
#endif
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getINPUT_RECORDFields 8\n");
	return lpStruct;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getINPUT_RECORDFields 8\n");
}

void setINPUT_RECORDFields(JNIEnv *env, jobject lpObject, INPUT_RECORD *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setINPUT_RECORDFields 1\n");
	if (!INPUT_RECORDFc.cached) cacheINPUT_RECORDFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setINPUT_RECORDFields 1\n");
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setINPUT_RECORDFields 2\n");
	(*env)->SetShortField(env, lpObject, INPUT_RECORDFc.eventType, (jshort)lpStruct->EventType);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setINPUT_RECORDFields 2\n");
#endif
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setINPUT_RECORDFields 3\n");
	{
	jobject lpObject1 = (*env)->GetObjectField(env, lpObject, INPUT_RECORDFc.keyEvent);
	if (lpObject1 != NULL) setKEY_EVENT_RECORDFields(env, lpObject1, &lpStruct->Event.KeyEvent);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setINPUT_RECORDFields 3\n");
#endif
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setINPUT_RECORDFields 4\n");
	{
	jobject lpObject1 = (*env)->GetObjectField(env, lpObject, INPUT_RECORDFc.mouseEvent);
	if (lpObject1 != NULL) setMOUSE_EVENT_RECORDFields(env, lpObject1, &lpStruct->Event.MouseEvent);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setINPUT_RECORDFields 4\n");
#endif
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setINPUT_RECORDFields 5\n");
	{
	jobject lpObject1 = (*env)->GetObjectField(env, lpObject, INPUT_RECORDFc.windowBufferSizeEvent);
	if (lpObject1 != NULL) setWINDOW_BUFFER_SIZE_RECORDFields(env, lpObject1, &lpStruct->Event.WindowBufferSizeEvent);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setINPUT_RECORDFields 5\n");
#endif
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setINPUT_RECORDFields 6\n");
	{
	jobject lpObject1 = (*env)->GetObjectField(env, lpObject, INPUT_RECORDFc.menuEvent);
	if (lpObject1 != NULL) setMENU_EVENT_RECORDFields(env, lpObject1, &lpStruct->Event.MenuEvent);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setINPUT_RECORDFields 6\n");
#endif
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setINPUT_RECORDFields 7\n");
	{
	jobject lpObject1 = (*env)->GetObjectField(env, lpObject, INPUT_RECORDFc.focusEvent);
	if (lpObject1 != NULL) setFOCUS_EVENT_RECORDFields(env, lpObject1, &lpStruct->Event.FocusEvent);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setINPUT_RECORDFields 7\n");
#endif
}
#endif

#if defined(_WIN32) || defined(_WIN64)
typedef struct KEY_EVENT_RECORD_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID keyDown, repeatCount, keyCode, scanCode, uchar, controlKeyState;
} KEY_EVENT_RECORD_FID_CACHE;

KEY_EVENT_RECORD_FID_CACHE KEY_EVENT_RECORDFc;

void cacheKEY_EVENT_RECORDFields(JNIEnv *env, jobject lpObject)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter cacheKEY_EVENT_RECORDFields 1\n");
	if (KEY_EVENT_RECORDFc.cached) return;
	KEY_EVENT_RECORDFc.clazz = (*env)->GetObjectClass(env, lpObject);
	KEY_EVENT_RECORDFc.keyDown = (*env)->GetFieldID(env, KEY_EVENT_RECORDFc.clazz, "keyDown", "Z");
	KEY_EVENT_RECORDFc.repeatCount = (*env)->GetFieldID(env, KEY_EVENT_RECORDFc.clazz, "repeatCount", "S");
	KEY_EVENT_RECORDFc.keyCode = (*env)->GetFieldID(env, KEY_EVENT_RECORDFc.clazz, "keyCode", "S");
	KEY_EVENT_RECORDFc.scanCode = (*env)->GetFieldID(env, KEY_EVENT_RECORDFc.clazz, "scanCode", "S");
	KEY_EVENT_RECORDFc.uchar = (*env)->GetFieldID(env, KEY_EVENT_RECORDFc.clazz, "uchar", "C");
	KEY_EVENT_RECORDFc.controlKeyState = (*env)->GetFieldID(env, KEY_EVENT_RECORDFc.clazz, "controlKeyState", "I");
	hawtjni_w_barrier();
	KEY_EVENT_RECORDFc.cached = 1;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit cacheKEY_EVENT_RECORDFields 1\n");
}

KEY_EVENT_RECORD *getKEY_EVENT_RECORDFields(JNIEnv *env, jobject lpObject, KEY_EVENT_RECORD *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getKEY_EVENT_RECORDFields 1\n");
	if (!KEY_EVENT_RECORDFc.cached) cacheKEY_EVENT_RECORDFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getKEY_EVENT_RECORDFields 1\n");
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getKEY_EVENT_RECORDFields 2\n");
	lpStruct->bKeyDown = (*env)->GetBooleanField(env, lpObject, KEY_EVENT_RECORDFc.keyDown);
	lpStruct->wRepeatCount = (*env)->GetShortField(env, lpObject, KEY_EVENT_RECORDFc.repeatCount);
	lpStruct->wVirtualKeyCode = (*env)->GetShortField(env, lpObject, KEY_EVENT_RECORDFc.keyCode);
	lpStruct->wVirtualScanCode = (*env)->GetShortField(env, lpObject, KEY_EVENT_RECORDFc.scanCode);
	lpStruct->uChar.UnicodeChar = (*env)->GetCharField(env, lpObject, KEY_EVENT_RECORDFc.uchar);
	lpStruct->dwControlKeyState = (*env)->GetIntField(env, lpObject, KEY_EVENT_RECORDFc.controlKeyState);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getKEY_EVENT_RECORDFields 2\n");
#endif
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getKEY_EVENT_RECORDFields 3\n");
	return lpStruct;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getKEY_EVENT_RECORDFields 3\n");
}

void setKEY_EVENT_RECORDFields(JNIEnv *env, jobject lpObject, KEY_EVENT_RECORD *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setKEY_EVENT_RECORDFields 1\n");
	if (!KEY_EVENT_RECORDFc.cached) cacheKEY_EVENT_RECORDFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setKEY_EVENT_RECORDFields 1\n");
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setKEY_EVENT_RECORDFields 2\n");
	(*env)->SetBooleanField(env, lpObject, KEY_EVENT_RECORDFc.keyDown, (jboolean)lpStruct->bKeyDown);
	(*env)->SetShortField(env, lpObject, KEY_EVENT_RECORDFc.repeatCount, (jshort)lpStruct->wRepeatCount);
	(*env)->SetShortField(env, lpObject, KEY_EVENT_RECORDFc.keyCode, (jshort)lpStruct->wVirtualKeyCode);
	(*env)->SetShortField(env, lpObject, KEY_EVENT_RECORDFc.scanCode, (jshort)lpStruct->wVirtualScanCode);
	(*env)->SetCharField(env, lpObject, KEY_EVENT_RECORDFc.uchar, (jchar)lpStruct->uChar.UnicodeChar);
	(*env)->SetIntField(env, lpObject, KEY_EVENT_RECORDFc.controlKeyState, (jint)lpStruct->dwControlKeyState);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setKEY_EVENT_RECORDFields 2\n");
#endif
}
#endif

#if defined(_WIN32) || defined(_WIN64)
typedef struct MENU_EVENT_RECORD_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID commandId;
} MENU_EVENT_RECORD_FID_CACHE;

MENU_EVENT_RECORD_FID_CACHE MENU_EVENT_RECORDFc;

void cacheMENU_EVENT_RECORDFields(JNIEnv *env, jobject lpObject)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter cacheMENU_EVENT_RECORDFields 1\n");
	if (MENU_EVENT_RECORDFc.cached) return;
	MENU_EVENT_RECORDFc.clazz = (*env)->GetObjectClass(env, lpObject);
	MENU_EVENT_RECORDFc.commandId = (*env)->GetFieldID(env, MENU_EVENT_RECORDFc.clazz, "commandId", "I");
	hawtjni_w_barrier();
	MENU_EVENT_RECORDFc.cached = 1;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit cacheMENU_EVENT_RECORDFields 1\n");
}

MENU_EVENT_RECORD *getMENU_EVENT_RECORDFields(JNIEnv *env, jobject lpObject, MENU_EVENT_RECORD *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getMENU_EVENT_RECORDFields 1\n");
	if (!MENU_EVENT_RECORDFc.cached) cacheMENU_EVENT_RECORDFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getMENU_EVENT_RECORDFields 1\n");
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getMENU_EVENT_RECORDFields 2\n");
	lpStruct->dwCommandId = (*env)->GetIntField(env, lpObject, MENU_EVENT_RECORDFc.commandId);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getMENU_EVENT_RECORDFields 2\n");
#endif
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getMENU_EVENT_RECORDFields 3\n");
	return lpStruct;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getMENU_EVENT_RECORDFields 3\n");
}

void setMENU_EVENT_RECORDFields(JNIEnv *env, jobject lpObject, MENU_EVENT_RECORD *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setMENU_EVENT_RECORDFields 1\n");
	if (!MENU_EVENT_RECORDFc.cached) cacheMENU_EVENT_RECORDFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setMENU_EVENT_RECORDFields 1\n");
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setMENU_EVENT_RECORDFields 2\n");
	(*env)->SetIntField(env, lpObject, MENU_EVENT_RECORDFc.commandId, (jint)lpStruct->dwCommandId);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setMENU_EVENT_RECORDFields 2\n");
#endif
}
#endif

#if defined(_WIN32) || defined(_WIN64)
typedef struct MOUSE_EVENT_RECORD_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID mousePosition, buttonState, controlKeyState, eventFlags;
} MOUSE_EVENT_RECORD_FID_CACHE;

MOUSE_EVENT_RECORD_FID_CACHE MOUSE_EVENT_RECORDFc;

void cacheMOUSE_EVENT_RECORDFields(JNIEnv *env, jobject lpObject)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter cacheMOUSE_EVENT_RECORDFields 1\n");
	if (MOUSE_EVENT_RECORDFc.cached) return;
	MOUSE_EVENT_RECORDFc.clazz = (*env)->GetObjectClass(env, lpObject);
	MOUSE_EVENT_RECORDFc.mousePosition = (*env)->GetFieldID(env, MOUSE_EVENT_RECORDFc.clazz, "mousePosition", "Lorg/fusesource/jansi/internal/Kernel32$COORD;");
	MOUSE_EVENT_RECORDFc.buttonState = (*env)->GetFieldID(env, MOUSE_EVENT_RECORDFc.clazz, "buttonState", "I");
	MOUSE_EVENT_RECORDFc.controlKeyState = (*env)->GetFieldID(env, MOUSE_EVENT_RECORDFc.clazz, "controlKeyState", "I");
	MOUSE_EVENT_RECORDFc.eventFlags = (*env)->GetFieldID(env, MOUSE_EVENT_RECORDFc.clazz, "eventFlags", "I");
	hawtjni_w_barrier();
	MOUSE_EVENT_RECORDFc.cached = 1;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit cacheMOUSE_EVENT_RECORDFields 1\n");
}

MOUSE_EVENT_RECORD *getMOUSE_EVENT_RECORDFields(JNIEnv *env, jobject lpObject, MOUSE_EVENT_RECORD *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getMOUSE_EVENT_RECORDFields 1\n");
	if (!MOUSE_EVENT_RECORDFc.cached) cacheMOUSE_EVENT_RECORDFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getMOUSE_EVENT_RECORDFields 1\n");
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getMOUSE_EVENT_RECORDFields 2\n");
    {
	    jobject lpObject1 = (*env)->GetObjectField(env, lpObject, MOUSE_EVENT_RECORDFc.mousePosition);
	    if (lpObject1 != NULL) getCOORDFields(env, lpObject1, &lpStruct->dwMousePosition);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getMOUSE_EVENT_RECORDFields 2\n");
	
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getMOUSE_EVENT_RECORDFields 3\n");
	lpStruct->dwButtonState = (*env)->GetIntField(env, lpObject, MOUSE_EVENT_RECORDFc.buttonState);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getMOUSE_EVENT_RECORDFields 3\n");
	
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getMOUSE_EVENT_RECORDFields 4\n");
	lpStruct->dwControlKeyState = (*env)->GetIntField(env, lpObject, MOUSE_EVENT_RECORDFc.controlKeyState);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getMOUSE_EVENT_RECORDFields 4\n");
	
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getMOUSE_EVENT_RECORDFields 5\n");
	lpStruct->dwEventFlags = (*env)->GetIntField(env, lpObject, MOUSE_EVENT_RECORDFc.eventFlags);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getMOUSE_EVENT_RECORDFields 5\n");
#endif
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getMOUSE_EVENT_RECORDFields 6\n");
	return lpStruct;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getMOUSE_EVENT_RECORDFields 6\n");
}

void setMOUSE_EVENT_RECORDFields(JNIEnv *env, jobject lpObject, MOUSE_EVENT_RECORD *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setMOUSE_EVENT_RECORDFields 1\n");
	if (!MOUSE_EVENT_RECORDFc.cached) cacheMOUSE_EVENT_RECORDFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setMOUSE_EVENT_RECORDFields 1\n");
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setMOUSE_EVENT_RECORDFields 2\n");
	{
	    jobject lpObject1 = (*env)->GetObjectField(env, lpObject, MOUSE_EVENT_RECORDFc.mousePosition);
	    if (lpObject1 != NULL) setCOORDFields(env, lpObject1, &lpStruct->dwMousePosition);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setMOUSE_EVENT_RECORDFields 2\n");
	
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setMOUSE_EVENT_RECORDFields 3\n");
	(*env)->SetIntField(env, lpObject, MOUSE_EVENT_RECORDFc.buttonState, (jint)lpStruct->dwButtonState);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setMOUSE_EVENT_RECORDFields 3\n");
	
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setMOUSE_EVENT_RECORDFields 4\n");
	(*env)->SetIntField(env, lpObject, MOUSE_EVENT_RECORDFc.controlKeyState, (jint)lpStruct->dwControlKeyState);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setMOUSE_EVENT_RECORDFields 4\n");
	
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setMOUSE_EVENT_RECORDFields 5\n");
	(*env)->SetIntField(env, lpObject, MOUSE_EVENT_RECORDFc.eventFlags, (jint)lpStruct->dwEventFlags);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setMOUSE_EVENT_RECORDFields 5\n");
#endif
}
#endif

#if defined(_WIN32) || defined(_WIN64)
typedef struct SMALL_RECT_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID left, top, right, bottom;
} SMALL_RECT_FID_CACHE;

SMALL_RECT_FID_CACHE SMALL_RECTFc;

void cacheSMALL_RECTFields(JNIEnv *env, jobject lpObject)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter cacheSMALL_RECTFields 1\n");
	if (SMALL_RECTFc.cached) return;
	SMALL_RECTFc.clazz = (*env)->GetObjectClass(env, lpObject);
	SMALL_RECTFc.left = (*env)->GetFieldID(env, SMALL_RECTFc.clazz, "left", "S");
	SMALL_RECTFc.top = (*env)->GetFieldID(env, SMALL_RECTFc.clazz, "top", "S");
	SMALL_RECTFc.right = (*env)->GetFieldID(env, SMALL_RECTFc.clazz, "right", "S");
	SMALL_RECTFc.bottom = (*env)->GetFieldID(env, SMALL_RECTFc.clazz, "bottom", "S");
	hawtjni_w_barrier();
	SMALL_RECTFc.cached = 1;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit cacheSMALL_RECTFields 1\n");
}

SMALL_RECT *getSMALL_RECTFields(JNIEnv *env, jobject lpObject, SMALL_RECT *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getSMALL_RECTFields 1\n");
	if (!SMALL_RECTFc.cached) cacheSMALL_RECTFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getSMALL_RECTFields 1\n");
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getSMALL_RECTFields 2\n");
	lpStruct->Left = (*env)->GetShortField(env, lpObject, SMALL_RECTFc.left);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getSMALL_RECTFields 2\n");
	
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getSMALL_RECTFields 3\n");
	lpStruct->Top = (*env)->GetShortField(env, lpObject, SMALL_RECTFc.top);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getSMALL_RECTFields 3\n");
	
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getSMALL_RECTFields 4\n");
	lpStruct->Right = (*env)->GetShortField(env, lpObject, SMALL_RECTFc.right);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getSMALL_RECTFields 4\n");
	
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getSMALL_RECTFields 5\n");
	lpStruct->Bottom = (*env)->GetShortField(env, lpObject, SMALL_RECTFc.bottom);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getSMALL_RECTFields 5\n");
#endif
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getSMALL_RECTFields 6\n");
	return lpStruct;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getSMALL_RECTFields 6\n");
}

void setSMALL_RECTFields(JNIEnv *env, jobject lpObject, SMALL_RECT *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setSMALL_RECTFields 1\n");
	if (!SMALL_RECTFc.cached) cacheSMALL_RECTFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setSMALL_RECTFields 1\n");
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setSMALL_RECTFields 2\n");
	(*env)->SetShortField(env, lpObject, SMALL_RECTFc.left, (jshort)lpStruct->Left);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setSMALL_RECTFields 2\n");
	
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setSMALL_RECTFields 3\n");
	(*env)->SetShortField(env, lpObject, SMALL_RECTFc.top, (jshort)lpStruct->Top);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setSMALL_RECTFields 3\n");
	
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setSMALL_RECTFields 4\n");
	(*env)->SetShortField(env, lpObject, SMALL_RECTFc.right, (jshort)lpStruct->Right);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setSMALL_RECTFields 4\n");
	
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setSMALL_RECTFields 5\n");
	(*env)->SetShortField(env, lpObject, SMALL_RECTFc.bottom, (jshort)lpStruct->Bottom);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setSMALL_RECTFields 5\n");
#endif
}
#endif

#if defined(_WIN32) || defined(_WIN64)
typedef struct WINDOW_BUFFER_SIZE_RECORD_FID_CACHE {
	int cached;
	jclass clazz;
	jfieldID size;
} WINDOW_BUFFER_SIZE_RECORD_FID_CACHE;

WINDOW_BUFFER_SIZE_RECORD_FID_CACHE WINDOW_BUFFER_SIZE_RECORDFc;

void cacheWINDOW_BUFFER_SIZE_RECORDFields(JNIEnv *env, jobject lpObject)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter cacheWINDOW_BUFFER_SIZE_RECORDFields 1\n");
	if (WINDOW_BUFFER_SIZE_RECORDFc.cached) return;
	WINDOW_BUFFER_SIZE_RECORDFc.clazz = (*env)->GetObjectClass(env, lpObject);
	WINDOW_BUFFER_SIZE_RECORDFc.size = (*env)->GetFieldID(env, WINDOW_BUFFER_SIZE_RECORDFc.clazz, "size", "Lorg/fusesource/jansi/internal/Kernel32$COORD;");
	hawtjni_w_barrier();
	WINDOW_BUFFER_SIZE_RECORDFc.cached = 1;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit cacheWINDOW_BUFFER_SIZE_RECORDFields 1\n");
}

WINDOW_BUFFER_SIZE_RECORD *getWINDOW_BUFFER_SIZE_RECORDFields(JNIEnv *env, jobject lpObject, WINDOW_BUFFER_SIZE_RECORD *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getWINDOW_BUFFER_SIZE_RECORDFields 1\n");
	if (!WINDOW_BUFFER_SIZE_RECORDFc.cached) cacheWINDOW_BUFFER_SIZE_RECORDFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getWINDOW_BUFFER_SIZE_RECORDFields 1\n");
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getWINDOW_BUFFER_SIZE_RECORDFields 2\n");
	{
	    jobject lpObject1 = (*env)->GetObjectField(env, lpObject, WINDOW_BUFFER_SIZE_RECORDFc.size);
	    if (lpObject1 != NULL) getCOORDFields(env, lpObject1, &lpStruct->dwSize);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getWINDOW_BUFFER_SIZE_RECORDFields 2\n");
#endif
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter getWINDOW_BUFFER_SIZE_RECORDFields 3\n");
	return lpStruct;
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit getWINDOW_BUFFER_SIZE_RECORDFields 3\n");
}

void setWINDOW_BUFFER_SIZE_RECORDFields(JNIEnv *env, jobject lpObject, WINDOW_BUFFER_SIZE_RECORD *lpStruct)
{
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setWINDOW_BUFFER_SIZE_RECORDFields 1\n");
	if (!WINDOW_BUFFER_SIZE_RECORDFc.cached) cacheWINDOW_BUFFER_SIZE_RECORDFields(env, lpObject);
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setWINDOW_BUFFER_SIZE_RECORDFields 1\n");
#if defined(_WIN32) || defined(_WIN64)
	fprintf(stderr, "[src/main/native/jansi_structs.c] enter setWINDOW_BUFFER_SIZE_RECORDFields 2\n");
	{
    	jobject lpObject1 = (*env)->GetObjectField(env, lpObject, WINDOW_BUFFER_SIZE_RECORDFc.size);
	    if (lpObject1 != NULL) setCOORDFields(env, lpObject1, &lpStruct->dwSize);
	}
	// fprintf(stderr, "[src/main/native/jansi_structs.c] exit setWINDOW_BUFFER_SIZE_RECORDFields 2\n");
#endif
}
#endif
// Total cost: 1.026491
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 695)]
// Total instrumented cost: 1.026491, input tokens: 50217, output tokens: 55077, cache read tokens: 50205, cache write tokens: 49397

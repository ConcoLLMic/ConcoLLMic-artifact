/*******************************************************************************
 * Copyright (C) 2017, the original author(s).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *******************************************************************************/
#include "jansi.h"
#include "jansi_structs.h"
#include <stdio.h>

#define CLibrary_NATIVE(func) Java_org_fusesource_jansi_internal_CLibrary_##func

#if defined(HAVE_TTYNAME)
JNIEXPORT jstring JNICALL CLibrary_NATIVE(ttyname)
	(JNIEnv *env, jclass that, jint arg0)
{
	fprintf(stderr, "[src/main/native/jansi_ttyname.c] enter ttyname 1\n");
	jstring rc = 0;
	char s[256] = { 0 };
	int r = 0;

	r = ttyname_r(arg0, s, 256);
	if (!r) {
		fprintf(stderr, "[src/main/native/jansi_ttyname.c] enter ttyname 2\n");
		rc = (*env)->NewStringUTF(env,s);
		// fprintf(stderr, "[src/main/native/jansi_ttyname.c] exit ttyname 2\n");
	}

	return rc;
	// fprintf(stderr, "[src/main/native/jansi_ttyname.c] exit ttyname 1\n");
}
#endif
// Total cost: 0.009355
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 34)]
// Total instrumented cost: 0.009355, input tokens: 2398, output tokens: 464, cache read tokens: 2394, cache write tokens: 444

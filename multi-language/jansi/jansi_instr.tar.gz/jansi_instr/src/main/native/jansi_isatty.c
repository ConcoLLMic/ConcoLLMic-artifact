/*******************************************************************************
 * Copyright (C) 2017, the original author(s).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *******************************************************************************/
#include "jansi.h"
#include "jansi_structs.h"
#include <stdio.h>

#define CLibrary_NATIVE(func) Java_org_fusesource_jansi_internal_CLibrary_##func

#if defined(_WIN32) || defined(_WIN64)

typedef struct _UNICODE_STRING {
	USHORT Length;
	USHORT MaximumLength;
	PWSTR  Buffer;
} UNICODE_STRING, *PUNICODE_STRING;

typedef struct _OBJECT_NAME_INFORMATION {
	UNICODE_STRING          Name;
	WCHAR                   NameBuffer[0];
} OBJECT_NAME_INFORMATION, *POBJECT_NAME_INFORMATION;

typedef enum {
	ObjectBasicInformation,
	ObjectNameInformation,
	ObjectTypeInformation,
	ObjectAllInformation,
	ObjectDataInformation
} OBJECT_INFORMATION_CLASS;

typedef NTSTATUS (NTAPI *TFNNtQueryObject)(HANDLE, OBJECT_INFORMATION_CLASS, PVOID, ULONG, PULONG);
TFNNtQueryObject NtQueryObject = 0;

HANDLE hModuleNtDll = 0;

JNIEXPORT jint JNICALL CLibrary_NATIVE(isatty)
	(JNIEnv *env, jclass that, jint arg0)
{
	fprintf(stderr, "[src/main/native/jansi_isatty.c] enter isatty 1\n");
	jint rc;

	ULONG result;
	BYTE buffer[1024];
	POBJECT_NAME_INFORMATION nameinfo = (POBJECT_NAME_INFORMATION) buffer;
	PWSTR name;
	DWORD mode;

	/* check if fd is a pipe */
	HANDLE h = (HANDLE) _get_osfhandle(arg0);
	DWORD t = h != NULL ? GetFileType(h) : 0;
	if (h != NULL && t == FILE_TYPE_CHAR) {
		fprintf(stderr, "[src/main/native/jansi_isatty.c] enter isatty 2\n");
	    // check that this is a real tty because the /dev/null
	    // and /dev/zero streams are also of type FILE_TYPE_CHAR
		rc = GetConsoleMode(h, &mode) != 0;
		// fprintf(stderr, "[src/main/native/jansi_isatty.c] exit isatty 2\n");
	}
	else {
		fprintf(stderr, "[src/main/native/jansi_isatty.c] enter isatty 3\n");
		if (hModuleNtDll == 0) {
			fprintf(stderr, "[src/main/native/jansi_isatty.c] enter isatty 4\n");
			hModuleNtDll = LoadLibraryW(L"ntdll.dll");
			// fprintf(stderr, "[src/main/native/jansi_isatty.c] exit isatty 4\n");
		}
		if (hModuleNtDll == 0) {
			fprintf(stderr, "[src/main/native/jansi_isatty.c] enter isatty 5\n");
			rc = 0;
			// fprintf(stderr, "[src/main/native/jansi_isatty.c] exit isatty 5\n");
		}
		else {
			fprintf(stderr, "[src/main/native/jansi_isatty.c] enter isatty 6\n");
			if (NtQueryObject == 0) {
				fprintf(stderr, "[src/main/native/jansi_isatty.c] enter isatty 7\n");
				NtQueryObject = (TFNNtQueryObject) GetProcAddress(hModuleNtDll, "NtQueryObject");
				// fprintf(stderr, "[src/main/native/jansi_isatty.c] exit isatty 7\n");
			}
			if (NtQueryObject == 0) {
				fprintf(stderr, "[src/main/native/jansi_isatty.c] enter isatty 8\n");
				rc = 0;
				// fprintf(stderr, "[src/main/native/jansi_isatty.c] exit isatty 8\n");
			}
			/* get pipe name */
			else if (NtQueryObject(h, ObjectNameInformation, buffer, sizeof(buffer) - 2, &result) != 0) {
				fprintf(stderr, "[src/main/native/jansi_isatty.c] enter isatty 9\n");
				rc = 0;
				// fprintf(stderr, "[src/main/native/jansi_isatty.c] exit isatty 9\n");
			}
			else {
				fprintf(stderr, "[src/main/native/jansi_isatty.c] enter isatty 10\n");
				name = nameinfo->Name.Buffer;
				if (name == NULL) {
					fprintf(stderr, "[src/main/native/jansi_isatty.c] enter isatty 11\n");
				    rc = 0;
				    // fprintf(stderr, "[src/main/native/jansi_isatty.c] exit isatty 11\n");
				}
				else {
					fprintf(stderr, "[src/main/native/jansi_isatty.c] enter isatty 12\n");
                    name[nameinfo->Name.Length / 2] = 0;

                    //fprintf( stderr, "Standard stream %d: pipe name: %S\n", arg0, name);

                    /*
                     * Check if this could be a MSYS2 pty pipe ('msys-XXXX-ptyN-XX')
                     * or a cygwin pty pipe ('cygwin-XXXX-ptyN-XX')
                     */
                    if ((wcsstr(name, L"msys-") || wcsstr(name, L"cygwin-")) && wcsstr(name, L"-pty")) {
                        fprintf(stderr, "[src/main/native/jansi_isatty.c] enter isatty 13\n");
                        rc = 1;
                        // fprintf(stderr, "[src/main/native/jansi_isatty.c] exit isatty 13\n");
                    } else {
                        fprintf(stderr, "[src/main/native/jansi_isatty.c] enter isatty 14\n");
                        // This is definitely not a tty
                        rc = 0;
                        // fprintf(stderr, "[src/main/native/jansi_isatty.c] exit isatty 14\n");
                    }
                    // fprintf(stderr, "[src/main/native/jansi_isatty.c] exit isatty 12\n");
                }
                // fprintf(stderr, "[src/main/native/jansi_isatty.c] exit isatty 10\n");
			}
			// fprintf(stderr, "[src/main/native/jansi_isatty.c] exit isatty 6\n");
		}
		// fprintf(stderr, "[src/main/native/jansi_isatty.c] exit isatty 3\n");
	}

	return rc;
	// fprintf(stderr, "[src/main/native/jansi_isatty.c] exit isatty 1\n");
}

#else
#if defined(HAVE_ISATTY)

JNIEXPORT jint JNICALL CLibrary_NATIVE(isatty)
	(JNIEnv *env, jclass that, jint arg0)
{
	fprintf(stderr, "[src/main/native/jansi_isatty.c] enter isatty 2722\n");
	jint rc = 0;

	rc = (jint)isatty(arg0);

	return rc;
	// fprintf(stderr, "[src/main/native/jansi_isatty.c] exit isatty 2722\n");
}

#endif
#endif
// Total cost: 0.032496
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 127)]
// Total instrumented cost: 0.032496, input tokens: 2398, output tokens: 1784, cache read tokens: 2394, cache write tokens: 1335

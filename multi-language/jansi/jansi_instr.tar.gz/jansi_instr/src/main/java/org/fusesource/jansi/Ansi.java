/*
 * Copyright (C) 2009-2023 the original author(s).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.fusesource.jansi;

import java.util.ArrayList;
import java.util.concurrent.Callable;

/**
 * Provides a fluent API for generating
 * <a href="https://en.wikipedia.org/wiki/ANSI_escape_code#CSI_sequences">ANSI escape sequences</a>.
 *
 * @since 1.0
 */
public class Ansi implements Appendable {

    private static final char FIRST_ESC_CHAR = 27;
    private static final char SECOND_ESC_CHAR = '[';

    /**
     * <a href="https://en.wikipedia.org/wiki/ANSI_escape_code#Colors">ANSI 8 colors</a> for fluent API
     */
    public enum Color {
        BLACK(0, "BLACK"),
        RED(1, "RED"),
        GREEN(2, "GREEN"),
        YELLOW(3, "YELLOW"),
        BLUE(4, "BLUE"),
        MAGENTA(5, "MAGENTA"),
        CYAN(6, "CYAN"),
        WHITE(7, "WHITE"),
        DEFAULT(9, "DEFAULT");

        private final int value;
        private final String name;

        Color(int index, String name) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Color 1");
            this.value = index;
            this.name = name;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Color 1");
        }

        @Override
        public String toString() {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Color.toString 1");
            return name;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Color.toString 1");
        }

        public int value() {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Color.value 1");
            return value;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Color.value 1");
        }

        public int fg() {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Color.fg 1");
            return value + 30;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Color.fg 1");
        }

        public int bg() {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Color.bg 1");
            return value + 40;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Color.bg 1");
        }

        public int fgBright() {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Color.fgBright 1");
            return value + 90;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Color.fgBright 1");
        }

        public int bgBright() {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Color.bgBright 1");
            return value + 100;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Color.bgBright 1");
        }
    }

    /**
     * Display attributes, also know as
     * <a href="https://en.wikipedia.org/wiki/ANSI_escape_code#SGR_(Select_Graphic_Rendition)_parameters">SGR
     * (Select Graphic Rendition) parameters</a>.
     */
    public enum Attribute {
        RESET(0, "RESET"),
        INTENSITY_BOLD(1, "INTENSITY_BOLD"),
        INTENSITY_FAINT(2, "INTENSITY_FAINT"),
        ITALIC(3, "ITALIC_ON"),
        UNDERLINE(4, "UNDERLINE_ON"),
        BLINK_SLOW(5, "BLINK_SLOW"),
        BLINK_FAST(6, "BLINK_FAST"),
        NEGATIVE_ON(7, "NEGATIVE_ON"),
        CONCEAL_ON(8, "CONCEAL_ON"),
        STRIKETHROUGH_ON(9, "STRIKETHROUGH_ON"),
        UNDERLINE_DOUBLE(21, "UNDERLINE_DOUBLE"),
        INTENSITY_BOLD_OFF(22, "INTENSITY_BOLD_OFF"),
        ITALIC_OFF(23, "ITALIC_OFF"),
        UNDERLINE_OFF(24, "UNDERLINE_OFF"),
        BLINK_OFF(25, "BLINK_OFF"),
        NEGATIVE_OFF(27, "NEGATIVE_OFF"),
        CONCEAL_OFF(28, "CONCEAL_OFF"),
        STRIKETHROUGH_OFF(29, "STRIKETHROUGH_OFF");

        private final int value;
        private final String name;

        Attribute(int index, String name) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Attribute 1");
            this.value = index;
            this.name = name;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Attribute 1");
        }

        @Override
        public String toString() {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Attribute.toString 1");
            return name;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Attribute.toString 1");
        }

        public int value() {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Attribute.value 1");
            return value;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Attribute.value 1");
        }
    }

    /**
     * ED (Erase in Display) / EL (Erase in Line) parameter (see
     * <a href="https://en.wikipedia.org/wiki/ANSI_escape_code#CSI_sequences">CSI sequence J and K</a>)
     * @see Ansi#eraseScreen(Erase)
     * @see Ansi#eraseLine(Erase)
     */
    public enum Erase {
        FORWARD(0, "FORWARD"),
        BACKWARD(1, "BACKWARD"),
        ALL(2, "ALL");

        private final int value;
        private final String name;

        Erase(int index, String name) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Erase 1");
            this.value = index;
            this.name = name;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Erase 1");
        }

        @Override
        public String toString() {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Erase.toString 1");
            return name;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Erase.toString 1");
        }

        public int value() {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Erase.value 1");
            return value;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Erase.value 1");
        }
    }

    @FunctionalInterface
    public interface Consumer {
        void apply(Ansi ansi);
    }

    public static final String DISABLE = Ansi.class.getName() + ".disable";

    private static Callable<Boolean> detector = () -> !Boolean.getBoolean(DISABLE);

    public static void setDetector(final Callable<Boolean> detector) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.setDetector 1");
        if (detector == null) throw new IllegalArgumentException();
        Ansi.detector = detector;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.setDetector 1");
    }

    public static boolean isDetected() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.isDetected 1");
        try {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.isDetected 2");
            return detector.call();
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.isDetected 2");
        } catch (Exception e) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.isDetected 3");
            return true;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.isDetected 3");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.isDetected 1");
    }

    private static final InheritableThreadLocal<Boolean> holder = new InheritableThreadLocal<Boolean>() {
        @Override
        protected Boolean initialValue() {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter InheritableThreadLocal.initialValue 1");
            return isDetected();
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit InheritableThreadLocal.initialValue 1");
        }
    };

    public static void setEnabled(final boolean flag) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.setEnabled 1");
        holder.set(flag);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.setEnabled 1");
    }

    public static boolean isEnabled() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.isEnabled 1");
        return holder.get();
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.isEnabled 1");
    }

    public static Ansi ansi() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.ansi 1");
        if (isEnabled()) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.ansi 2");
            return new Ansi();
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.ansi 2");
        } else {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.ansi 3");
            return new NoAnsi();
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.ansi 3");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.ansi 1");
    }

    public static Ansi ansi(StringBuilder builder) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.ansi 4");
        if (isEnabled()) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.ansi 5");
            return new Ansi(builder);
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.ansi 5");
        } else {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.ansi 6");
            return new NoAnsi(builder);
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.ansi 6");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.ansi 4");
    }

    public static Ansi ansi(int size) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.ansi 7");
        if (isEnabled()) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.ansi 8");
            return new Ansi(size);
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.ansi 8");
        } else {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.ansi 9");
            return new NoAnsi(size);
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.ansi 9");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.ansi 7");
    }

    private static class NoAnsi extends Ansi {
        public NoAnsi() {
            super();
        }

        public NoAnsi(int size) {
            super(size);
        }

        public NoAnsi(StringBuilder builder) {
            super(builder);
        }

        @Override
        public Ansi fg(Color color) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.fg 1");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.fg 1");
        }

        @Override
        public Ansi bg(Color color) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.bg 1");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.bg 1");
        }

        @Override
        public Ansi fgBright(Color color) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.fgBright 1");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.fgBright 1");
        }

        @Override
        public Ansi bgBright(Color color) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.bgBright 1");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.bgBright 1");
        }

        @Override
        public Ansi fg(int color) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.fg 2");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.fg 2");
        }

        @Override
        public Ansi fgRgb(int r, int g, int b) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.fgRgb 1");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.fgRgb 1");
        }

        @Override
        public Ansi bg(int color) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.bg 2");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.bg 2");
        }

        @Override
        public Ansi bgRgb(int r, int g, int b) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.bgRgb 1");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.bgRgb 1");
        }

        @Override
        public Ansi a(Attribute attribute) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.a 1");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.a 1");
        }

        @Override
        public Ansi cursor(int row, int column) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.cursor 1");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.cursor 1");
        }

        @Override
        public Ansi cursorToColumn(int x) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.cursorToColumn 1");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.cursorToColumn 1");
        }

        @Override
        public Ansi cursorUp(int y) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.cursorUp 1");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.cursorUp 1");
        }

        @Override
        public Ansi cursorRight(int x) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.cursorRight 1");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.cursorRight 1");
        }

        @Override
        public Ansi cursorDown(int y) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.cursorDown 1");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.cursorDown 1");
        }

        @Override
        public Ansi cursorLeft(int x) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.cursorLeft 1");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.cursorLeft 1");
        }

        @Override
        public Ansi cursorDownLine() {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.cursorDownLine 1");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.cursorDownLine 1");
        }

        @Override
        public Ansi cursorDownLine(final int n) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.cursorDownLine 2");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.cursorDownLine 2");
        }

        @Override
        public Ansi cursorUpLine() {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.cursorUpLine 1");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.cursorUpLine 1");
        }

        @Override
        public Ansi cursorUpLine(final int n) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.cursorUpLine 2");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.cursorUpLine 2");
        }

        @Override
        public Ansi eraseScreen() {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.eraseScreen 1");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.eraseScreen 1");
        }

        @Override
        public Ansi eraseScreen(Erase kind) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.eraseScreen 2");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.eraseScreen 2");
        }

        @Override
        public Ansi eraseLine() {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.eraseLine 1");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.eraseLine 1");
        }

        @Override
        public Ansi eraseLine(Erase kind) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.eraseLine 2");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.eraseLine 2");
        }

        @Override
        public Ansi scrollUp(int rows) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.scrollUp 1");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.scrollUp 1");
        }

        @Override
        public Ansi scrollDown(int rows) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.scrollDown 1");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.scrollDown 1");
        }

        @Override
        public Ansi saveCursorPosition() {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.saveCursorPosition 1");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.saveCursorPosition 1");
        }

        @Override
        @Deprecated
        public Ansi restorCursorPosition() {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.restorCursorPosition 1");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.restorCursorPosition 1");
        }

        @Override
        public Ansi restoreCursorPosition() {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.restoreCursorPosition 2");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.restoreCursorPosition 2");
        }

        @Override
        public Ansi reset() {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter NoAnsi.reset 1");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit NoAnsi.reset 1");
        }
    }

    private final StringBuilder builder;
    private final ArrayList<Integer> attributeOptions = new ArrayList<>(5);

    public Ansi() {
        this(new StringBuilder(80));
    }

    public Ansi(Ansi parent) {
        this(new StringBuilder(parent.builder));
        attributeOptions.addAll(parent.attributeOptions);
    }

    public Ansi(int size) {
        this(new StringBuilder(size));
    }

    public Ansi(StringBuilder builder) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.constructor 4");
        this.builder = builder;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.constructor 4");
    }

    public Ansi fg(Color color) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.fg 1");
        attributeOptions.add(color.fg());
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.fg 1");
    }

    public Ansi fg(int color) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.fg 2");
        attributeOptions.add(38);
        attributeOptions.add(5);
        attributeOptions.add(color & 0xff);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.fg 2");
    }

    public Ansi fgRgb(int color) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.fgRgb 1");
        return fgRgb(color >> 16, color >> 8, color);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.fgRgb 1");
    }

    public Ansi fgRgb(int r, int g, int b) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.fgRgb 2");
        attributeOptions.add(38);
        attributeOptions.add(2);
        attributeOptions.add(r & 0xff);
        attributeOptions.add(g & 0xff);
        attributeOptions.add(b & 0xff);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.fgRgb 2");
    }

    public Ansi fgBlack() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.fgBlack 1");
        return this.fg(Color.BLACK);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.fgBlack 1");
    }

    public Ansi fgBlue() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.fgBlue 1");
        return this.fg(Color.BLUE);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.fgBlue 1");
    }

    public Ansi fgCyan() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.fgCyan 1");
        return this.fg(Color.CYAN);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.fgCyan 1");
    }

    public Ansi fgDefault() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.fgDefault 1");
        return this.fg(Color.DEFAULT);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.fgDefault 1");
    }

    public Ansi fgGreen() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.fgGreen 1");
        return this.fg(Color.GREEN);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.fgGreen 1");
    }

    public Ansi fgMagenta() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.fgMagenta 1");
        return this.fg(Color.MAGENTA);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.fgMagenta 1");
    }

    public Ansi fgRed() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.fgRed 1");
        return this.fg(Color.RED);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.fgRed 1");
    }

    public Ansi fgYellow() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.fgYellow 1");
        return this.fg(Color.YELLOW);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.fgYellow 1");
    }

    public Ansi bg(Color color) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.bg 1");
        attributeOptions.add(color.bg());
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.bg 1");
    }

    public Ansi bg(int color) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.bg 2");
        attributeOptions.add(48);
        attributeOptions.add(5);
        attributeOptions.add(color & 0xff);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.bg 2");
    }

    public Ansi bgRgb(int color) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.bgRgb 1");
        return bgRgb(color >> 16, color >> 8, color);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.bgRgb 1");
    }

    public Ansi bgRgb(int r, int g, int b) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.bgRgb 2");
        attributeOptions.add(48);
        attributeOptions.add(2);
        attributeOptions.add(r & 0xff);
        attributeOptions.add(g & 0xff);
        attributeOptions.add(b & 0xff);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.bgRgb 2");
    }

    public Ansi bgCyan() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.bgCyan 1");
        return this.bg(Color.CYAN);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.bgCyan 1");
    }

    public Ansi bgDefault() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.bgDefault 1");
        return this.bg(Color.DEFAULT);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.bgDefault 1");
    }

    public Ansi bgGreen() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.bgGreen 1");
        return this.bg(Color.GREEN);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.bgGreen 1");
    }

    public Ansi bgMagenta() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.bgMagenta 1");
        return this.bg(Color.MAGENTA);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.bgMagenta 1");
    }

    public Ansi bgRed() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.bgRed 1");
        return this.bg(Color.RED);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.bgRed 1");
    }

    public Ansi bgYellow() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.bgYellow 1");
        return this.bg(Color.YELLOW);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.bgYellow 1");
    }

    public Ansi fgBright(Color color) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.fgBright 1");
        attributeOptions.add(color.fgBright());
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.fgBright 1");
    }

    public Ansi fgBrightBlack() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.fgBrightBlack 1");
        return this.fgBright(Color.BLACK);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.fgBrightBlack 1");
    }

    public Ansi fgBrightBlue() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.fgBrightBlue 1");
        return this.fgBright(Color.BLUE);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.fgBrightBlue 1");
    }

    public Ansi fgBrightCyan() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.fgBrightCyan 1");
        return this.fgBright(Color.CYAN);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.fgBrightCyan 1");
    }

    public Ansi fgBrightDefault() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.fgBrightDefault 1");
        return this.fgBright(Color.DEFAULT);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.fgBrightDefault 1");
    }

    public Ansi fgBrightGreen() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.fgBrightGreen 1");
        return this.fgBright(Color.GREEN);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.fgBrightGreen 1");
    }

    public Ansi fgBrightMagenta() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.fgBrightMagenta 1");
        return this.fgBright(Color.MAGENTA);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.fgBrightMagenta 1");
    }

    public Ansi fgBrightRed() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.fgBrightRed 1");
        return this.fgBright(Color.RED);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.fgBrightRed 1");
    }

    public Ansi fgBrightYellow() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.fgBrightYellow 1");
        return this.fgBright(Color.YELLOW);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.fgBrightYellow 1");
    }

    public Ansi bgBright(Color color) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.bgBright 1");
        attributeOptions.add(color.bgBright());
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.bgBright 1");
    }

    public Ansi bgBrightCyan() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.bgBrightCyan 1");
        return this.bgBright(Color.CYAN);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.bgBrightCyan 1");
    }

    public Ansi bgBrightDefault() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.bgBrightDefault 1");
        return this.bgBright(Color.DEFAULT);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.bgBrightDefault 1");
    }

    public Ansi bgBrightGreen() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.bgBrightGreen 1");
        return this.bgBright(Color.GREEN);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.bgBrightGreen 1");
    }

    public Ansi bgBrightMagenta() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.bgBrightMagenta 1");
        return this.bgBright(Color.MAGENTA);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.bgBrightMagenta 1");
    }

    public Ansi bgBrightRed() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.bgBrightRed 1");
        return this.bgBright(Color.RED);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.bgBrightRed 1");
    }

    public Ansi bgBrightYellow() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.bgBrightYellow 1");
        return this.bgBright(Color.YELLOW);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.bgBrightYellow 1");
    }

    public Ansi a(Attribute attribute) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.a 1");
        attributeOptions.add(attribute.value());
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.a 1");
    }

    /**
     * Moves the cursor to row n, column m. The values are 1-based.
     * Any values less than 1 are mapped to 1.
     *
     * @param row    row (1-based) from top
     * @param column column (1 based) from left
     * @return this Ansi instance
     */
    public Ansi cursor(final int row, final int column) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursor 1");
        return appendEscapeSequence('H', Math.max(1, row), Math.max(1, column));
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursor 1");
    }

    /**
     * Moves the cursor to column n. The parameter n is 1-based.
     * If n is less than 1 it is moved to the first column.
     *
     * @param x the index (1-based) of the column to move to
     * @return this Ansi instance
     */
    public Ansi cursorToColumn(final int x) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorToColumn 1");
        return appendEscapeSequence('G', Math.max(1, x));
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorToColumn 1");
    }

    /**
     * Moves the cursor up. If the parameter y is negative it moves the cursor down.
     *
     * @param y the number of lines to move up
     * @return this Ansi instance
     */
    public Ansi cursorUp(final int y) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorUp 1");
        if (y > 0) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorUp 2");
            return appendEscapeSequence('A', y);
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorUp 2");
        } else if (y < 0) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorUp 3");
            return cursorDown(-y);
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorUp 3");
        } else {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorUp 4");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorUp 4");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorUp 1");
    }

    /**
     * Moves the cursor down. If the parameter y is negative it moves the cursor up.
     *
     * @param y the number of lines to move down
     * @return this Ansi instance
     */
    public Ansi cursorDown(final int y) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorDown 1");
        if (y > 0) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorDown 2");
            return appendEscapeSequence('B', y);
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorDown 2");
        } else if (y < 0) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorDown 3");
            return cursorUp(-y);
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorDown 3");
        } else {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorDown 4");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorDown 4");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorDown 1");
    }

    /**
     * Moves the cursor right. If the parameter x is negative it moves the cursor left.
     *
     * @param x the number of characters to move right
     * @return this Ansi instance
     */
    public Ansi cursorRight(final int x) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorRight 1");
        if (x > 0) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorRight 2");
            return appendEscapeSequence('C', x);
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorRight 2");
        } else if (x < 0) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorRight 3");
            return cursorLeft(-x);
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorRight 3");
        } else {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorRight 4");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorRight 4");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorRight 1");
    }

    /**
     * Moves the cursor left. If the parameter x is negative it moves the cursor right.
     *
     * @param x the number of characters to move left
     * @return this Ansi instance
     */
    public Ansi cursorLeft(final int x) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorLeft 1");
        if (x > 0) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorLeft 2");
            return appendEscapeSequence('D', x);
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorLeft 2");
        } else if (x < 0) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorLeft 3");
            return cursorRight(-x);
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorLeft 3");
        } else {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorLeft 4");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorLeft 4");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorLeft 1");
    }

    /**
     * Moves the cursor relative to the current position. The cursor is moved right if x is
     * positive, left if negative and down if y is positive and up if negative.
     *
     * @param x the number of characters to move horizontally
     * @param y the number of lines to move vertically
     * @return this Ansi instance
     * @since 2.2
     */
    public Ansi cursorMove(final int x, final int y) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorMove 1");
        return cursorRight(x).cursorDown(y);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorMove 1");
    }

    /**
     * Moves the cursor to the beginning of the line below.
     *
     * @return this Ansi instance
     */
    public Ansi cursorDownLine() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorDownLine 1");
        return appendEscapeSequence('E');
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorDownLine 1");
    }

    /**
     * Moves the cursor to the beginning of the n-th line below. If the parameter n is negative it
     * moves the cursor to the beginning of the n-th line above.
     *
     * @param n the number of lines to move the cursor
     * @return this Ansi instance
     */
    public Ansi cursorDownLine(final int n) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorDownLine 2");
        if (n < 0) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorDownLine 3");
            return cursorUpLine(-n);
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorDownLine 3");
        } else {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorDownLine 4");
            return appendEscapeSequence('E', n);
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorDownLine 4");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorDownLine 2");
    }

    /**
     * Moves the cursor to the beginning of the line above.
     *
     * @return this Ansi instance
     */
    public Ansi cursorUpLine() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorUpLine 1");
        return appendEscapeSequence('F');
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorUpLine 1");
    }

    /**
     * Moves the cursor to the beginning of the n-th line above. If the parameter n is negative it
     * moves the cursor to the beginning of the n-th line below.
     *
     * @param n the number of lines to move the cursor
     * @return this Ansi instance
     */
    public Ansi cursorUpLine(final int n) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorUpLine 2");
        if (n < 0) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorUpLine 3");
            return cursorDownLine(-n);
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorUpLine 3");
        } else {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.cursorUpLine 4");
            return appendEscapeSequence('F', n);
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorUpLine 4");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.cursorUpLine 2");
    }

    public Ansi eraseScreen() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.eraseScreen 1");
        return appendEscapeSequence('J', Erase.ALL.value());
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.eraseScreen 1");
    }

    public Ansi eraseScreen(final Erase kind) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.eraseScreen 2");
        return appendEscapeSequence('J', kind.value());
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.eraseScreen 2");
    }

    public Ansi eraseLine() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.eraseLine 1");
        return appendEscapeSequence('K');
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.eraseLine 1");
    }

    public Ansi eraseLine(final Erase kind) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.eraseLine 2");
        return appendEscapeSequence('K', kind.value());
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.eraseLine 2");
    }

    public Ansi scrollUp(final int rows) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.scrollUp 1");
        if (rows == Integer.MIN_VALUE) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.scrollUp 2");
            return scrollDown(Integer.MAX_VALUE);
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.scrollUp 2");
        } else if (rows > 0) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.scrollUp 3");
            return appendEscapeSequence('S', rows);
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.scrollUp 3");
        } else if (rows < 0) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.scrollUp 4");
            return scrollDown(-rows);
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.scrollUp 4");
        } else {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.scrollUp 5");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.scrollUp 5");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.scrollUp 1");
    }

    public Ansi scrollDown(final int rows) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.scrollDown 1");
        if (rows == Integer.MIN_VALUE) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.scrollDown 2");
            return scrollUp(Integer.MAX_VALUE);
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.scrollDown 2");
        } else if (rows > 0) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.scrollDown 3");
            return appendEscapeSequence('T', rows);
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.scrollDown 3");
        } else if (rows < 0) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.scrollDown 4");
            return scrollUp(-rows);
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.scrollDown 4");
        } else {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.scrollDown 5");
            return this;
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.scrollDown 5");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.scrollDown 1");
    }

    @Deprecated
    public Ansi restorCursorPosition() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.restorCursorPosition 1");
        return restoreCursorPosition();
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.restorCursorPosition 1");
    }

    public Ansi saveCursorPosition() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.saveCursorPosition 1");
        saveCursorPositionSCO();
        return saveCursorPositionDEC();
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.saveCursorPosition 1");
    }

    // SCO command
    public Ansi saveCursorPositionSCO() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.saveCursorPositionSCO 1");
        return appendEscapeSequence('s');
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.saveCursorPositionSCO 1");
    }

    // DEC command
    public Ansi saveCursorPositionDEC() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.saveCursorPositionDEC 1");
        builder.append(FIRST_ESC_CHAR);
        builder.append('7');
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.saveCursorPositionDEC 1");
    }

    public Ansi restoreCursorPosition() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.restoreCursorPosition 1");
        restoreCursorPositionSCO();
        return restoreCursorPositionDEC();
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.restoreCursorPosition 1");
    }

    // SCO command
    public Ansi restoreCursorPositionSCO() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.restoreCursorPositionSCO 1");
        return appendEscapeSequence('u');
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.restoreCursorPositionSCO 1");
    }

    // DEC command
    public Ansi restoreCursorPositionDEC() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.restoreCursorPositionDEC 1");
        builder.append(FIRST_ESC_CHAR);
        builder.append('8');
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.restoreCursorPositionDEC 1");
    }

    public Ansi reset() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.reset 1");
        return a(Attribute.RESET);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.reset 1");
    }

    public Ansi bold() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.bold 1");
        return a(Attribute.INTENSITY_BOLD);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.bold 1");
    }

    public Ansi boldOff() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.boldOff 1");
        return a(Attribute.INTENSITY_BOLD_OFF);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.boldOff 1");
    }

    public Ansi a(String value) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.a 2");
        flushAttributes();
        builder.append(value);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.a 2");
    }

    public Ansi a(boolean value) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.a 3");
        flushAttributes();
        builder.append(value);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.a 3");
    }

    public Ansi a(char value) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.a 4");
        flushAttributes();
        builder.append(value);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.a 4");
    }

    public Ansi a(char[] value, int offset, int len) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.a 5");
        flushAttributes();
        builder.append(value, offset, len);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.a 5");
    }

    public Ansi a(char[] value) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter Ansi.a 6");
        flushAttributes();
        builder.append(value);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit Ansi.a 6");
    }

    public Ansi a(CharSequence value, int start, int end) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter a_CharSequence_int_int 1");
        flushAttributes();
        builder.append(value, start, end);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit a_CharSequence_int_int 1");
    }

    public Ansi a(CharSequence value) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter a_CharSequence 1");
        flushAttributes();
        builder.append(value);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit a_CharSequence 1");
    }

    public Ansi a(double value) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter a_double 1");
        flushAttributes();
        builder.append(value);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit a_double 1");
    }

    public Ansi a(float value) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter a_float 1");
        flushAttributes();
        builder.append(value);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit a_float 1");
    }

    public Ansi a(int value) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter a_int 1");
        flushAttributes();
        builder.append(value);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit a_int 1");
    }

    public Ansi a(long value) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter a_long 1");
        flushAttributes();
        builder.append(value);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit a_long 1");
    }

    public Ansi a(Object value) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter a_Object 1");
        flushAttributes();
        builder.append(value);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit a_Object 1");
    }

    public Ansi a(StringBuffer value) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter a_StringBuffer 1");
        flushAttributes();
        builder.append(value);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit a_StringBuffer 1");
    }

    public Ansi newline() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter newline 1");
        flushAttributes();
        builder.append(System.getProperty("line.separator"));
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit newline 1");
    }

    public Ansi format(String pattern, Object... args) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter format 1");
        flushAttributes();
        builder.append(String.format(pattern, args));
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit format 1");
    }

    /**
     * Applies another function to this Ansi instance.
     *
     * @param fun the function to apply
     * @return this Ansi instance
     * @since 2.2
     */
    public Ansi apply(Consumer fun) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter apply 1");
        fun.apply(this);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit apply 1");
    }

    /**
     * Uses the {@link AnsiRenderer}
     * to generate the ANSI escape sequences for the supplied text.
     *
     * @param text text
     * @return this
     * @since 2.2
     */
    public Ansi render(final String text) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter render_String 1");
        a(AnsiRenderer.render(text));
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit render_String 1");
    }

    /**
     * String formats and renders the supplied arguments.  Uses the {@link AnsiRenderer}
     * to generate the ANSI escape sequences.
     *
     * @param text format
     * @param args arguments
     * @return this
     * @since 2.2
     */
    public Ansi render(final String text, Object... args) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter render_String_Object 1");
        a(String.format(AnsiRenderer.render(text), args));
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit render_String_Object 1");
    }

    @Override
    public String toString() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter toString 1");
        flushAttributes();
        return builder.toString();
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit toString 1");
    }

    ///////////////////////////////////////////////////////////////////
    // Private Helper Methods
    ///////////////////////////////////////////////////////////////////

    private Ansi appendEscapeSequence(char command) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter appendEscapeSequence_char 1");
        flushAttributes();
        builder.append(FIRST_ESC_CHAR);
        builder.append(SECOND_ESC_CHAR);
        builder.append(command);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit appendEscapeSequence_char 1");
    }

    private Ansi appendEscapeSequence(char command, int option) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter appendEscapeSequence_char_int 1");
        flushAttributes();
        builder.append(FIRST_ESC_CHAR);
        builder.append(SECOND_ESC_CHAR);
        builder.append(option);
        builder.append(command);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit appendEscapeSequence_char_int 1");
    }

    private Ansi appendEscapeSequence(char command, Object... options) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter appendEscapeSequence_char_Object 1");
        flushAttributes();
        return _appendEscapeSequence(command, options);
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit appendEscapeSequence_char_Object 1");
    }

    private void flushAttributes() {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter flushAttributes 1");
        if (attributeOptions.isEmpty()) return;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit flushAttributes 1");

        if (attributeOptions.size() == 1 && attributeOptions.get(0) == 0) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter flushAttributes 2");
            builder.append(FIRST_ESC_CHAR);
            builder.append(SECOND_ESC_CHAR);
            builder.append('m');
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit flushAttributes 2");
        } else {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter flushAttributes 3");
            _appendEscapeSequence('m', attributeOptions.toArray());
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit flushAttributes 3");
        }

        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter flushAttributes 4");
        attributeOptions.clear();
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit flushAttributes 4");
    }

    private Ansi _appendEscapeSequence(char command, Object... options) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter _appendEscapeSequence 1");
        builder.append(FIRST_ESC_CHAR);
        builder.append(SECOND_ESC_CHAR);
        int size = options.length;
        for (int i = 0; i < size; i++) {
            System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter _appendEscapeSequence 2");
            if (i != 0) {
                System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter _appendEscapeSequence 3");
                builder.append(';');
                // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit _appendEscapeSequence 3");
            }
            if (options[i] != null) {
                System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter _appendEscapeSequence 4");
                builder.append(options[i]);
                // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit _appendEscapeSequence 4");
            }
            // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit _appendEscapeSequence 2");
        }
        builder.append(command);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit _appendEscapeSequence 1");
    }

    @Override
    public Ansi append(CharSequence csq) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter append_CharSequence 1");
        builder.append(csq);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit append_CharSequence 1");
    }

    @Override
    public Ansi append(CharSequence csq, int start, int end) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter append_CharSequence_int_int 1");
        builder.append(csq, start, end);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit append_CharSequence_int_int 1");
    }

    @Override
    public Ansi append(char c) {
        System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] enter append_char 1");
        builder.append(c);
        return this;
        // System.err.println("[src/main/java/org/fusesource/jansi/Ansi.java] exit append_char 1");
    }
}
// Total cost: 0.346751
// Total split cost: 0.089667, input tokens: 49568, output tokens: 2302, cache read tokens: 49549, cache write tokens:
// 10724, split chunks: [(0, 796), (796, 973)]
// Total instrumented cost: 0.257085, input tokens: 2402, output tokens: 14631, cache read tokens: 2394, cache write
// tokens: 9834

/*
 * Copyright (C) 2009-2023 the original author(s).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.fusesource.jansi.io;

import java.io.IOException;
import java.io.OutputStream;

import org.fusesource.jansi.internal.Kernel32;
import org.fusesource.jansi.internal.Kernel32.CONSOLE_SCREEN_BUFFER_INFO;
import org.fusesource.jansi.internal.Kernel32.COORD;

import static org.fusesource.jansi.internal.Kernel32.BACKGROUND_BLUE;
import static org.fusesource.jansi.internal.Kernel32.BACKGROUND_GREEN;
import static org.fusesource.jansi.internal.Kernel32.BACKGROUND_INTENSITY;
import static org.fusesource.jansi.internal.Kernel32.BACKGROUND_RED;
import static org.fusesource.jansi.internal.Kernel32.CHAR_INFO;
import static org.fusesource.jansi.internal.Kernel32.FOREGROUND_BLUE;
import static org.fusesource.jansi.internal.Kernel32.FOREGROUND_GREEN;
import static org.fusesource.jansi.internal.Kernel32.FOREGROUND_INTENSITY;
import static org.fusesource.jansi.internal.Kernel32.FOREGROUND_RED;
import static org.fusesource.jansi.internal.Kernel32.FillConsoleOutputAttribute;
import static org.fusesource.jansi.internal.Kernel32.FillConsoleOutputCharacterW;
import static org.fusesource.jansi.internal.Kernel32.GetConsoleScreenBufferInfo;
import static org.fusesource.jansi.internal.Kernel32.GetStdHandle;
import static org.fusesource.jansi.internal.Kernel32.SMALL_RECT;
import static org.fusesource.jansi.internal.Kernel32.STD_ERROR_HANDLE;
import static org.fusesource.jansi.internal.Kernel32.STD_OUTPUT_HANDLE;
import static org.fusesource.jansi.internal.Kernel32.ScrollConsoleScreenBuffer;
import static org.fusesource.jansi.internal.Kernel32.SetConsoleCursorPosition;
import static org.fusesource.jansi.internal.Kernel32.SetConsoleTextAttribute;
import static org.fusesource.jansi.internal.Kernel32.SetConsoleTitle;

/**
 * A Windows ANSI escape processor, that uses JNA to access native platform
 * API's to change the console attributes (see
 * <a href="http://fusesource.github.io/jansi/documentation/native-api/index.html?org/fusesource/jansi/internal/Kernel32.html">Jansi native Kernel32</a>).
 * <p>The native library used is named <code>jansi</code> and is loaded using <a href="http://fusesource.github.io/hawtjni/">HawtJNI</a> Runtime
 * <a href="http://fusesource.github.io/hawtjni/documentation/api/index.html?org/fusesource/hawtjni/runtime/Library.html"><code>Library</code></a>
 *
 * @since 1.19
 */
public final class WindowsAnsiProcessor extends AnsiProcessor {

    private final long console;

    private static final short FOREGROUND_BLACK = 0;
    private static final short FOREGROUND_YELLOW = (short) (FOREGROUND_RED | FOREGROUND_GREEN);
    private static final short FOREGROUND_MAGENTA = (short) (FOREGROUND_BLUE | FOREGROUND_RED);
    private static final short FOREGROUND_CYAN = (short) (FOREGROUND_BLUE | FOREGROUND_GREEN);
    private static final short FOREGROUND_WHITE = (short) (FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

    private static final short BACKGROUND_BLACK = 0;
    private static final short BACKGROUND_YELLOW = (short) (BACKGROUND_RED | BACKGROUND_GREEN);
    private static final short BACKGROUND_MAGENTA = (short) (BACKGROUND_BLUE | BACKGROUND_RED);
    private static final short BACKGROUND_CYAN = (short) (BACKGROUND_BLUE | BACKGROUND_GREEN);
    private static final short BACKGROUND_WHITE = (short) (BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE);

    private static final short[] ANSI_FOREGROUND_COLOR_MAP = {
        FOREGROUND_BLACK,
        FOREGROUND_RED,
        FOREGROUND_GREEN,
        FOREGROUND_YELLOW,
        FOREGROUND_BLUE,
        FOREGROUND_MAGENTA,
        FOREGROUND_CYAN,
        FOREGROUND_WHITE,
    };

    private static final short[] ANSI_BACKGROUND_COLOR_MAP = {
        BACKGROUND_BLACK,
        BACKGROUND_RED,
        BACKGROUND_GREEN,
        BACKGROUND_YELLOW,
        BACKGROUND_BLUE,
        BACKGROUND_MAGENTA,
        BACKGROUND_CYAN,
        BACKGROUND_WHITE,
    };

    private final CONSOLE_SCREEN_BUFFER_INFO info = new CONSOLE_SCREEN_BUFFER_INFO();
    private final short originalColors;

    private boolean negative;
    private short savedX = -1;
    private short savedY = -1;

    public WindowsAnsiProcessor(OutputStream ps, long console) throws IOException {
        super(ps);
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter WindowsAnsiProcessor 1");
        this.console = console;
        getConsoleInfo();
        originalColors = info.attributes;
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit WindowsAnsiProcessor 1");
    }

    public WindowsAnsiProcessor(OutputStream ps, boolean stdout) throws IOException {
        this(ps, GetStdHandle(stdout ? STD_OUTPUT_HANDLE : STD_ERROR_HANDLE));
    }

    public WindowsAnsiProcessor(OutputStream ps) throws IOException {
        this(ps, true);
    }

    private void getConsoleInfo() throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter getConsoleInfo 1");
        os.flush();
        if (GetConsoleScreenBufferInfo(console, info) == 0) {
            throw new IOException("Could not get the screen info: " + Kernel32.getLastErrorMessage());
        }
        if (negative) {
            info.attributes = invertAttributeColors(info.attributes);
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit getConsoleInfo 1");
    }

    private void applyAttribute() throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter applyAttribute 1");
        os.flush();
        short attributes = info.attributes;
        if (negative) {
            attributes = invertAttributeColors(attributes);
        }
        if (SetConsoleTextAttribute(console, attributes) == 0) {
            throw new IOException(Kernel32.getLastErrorMessage());
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit applyAttribute 1");
    }

    private short invertAttributeColors(short attributes) {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter invertAttributeColors 1");
        // Swap the the Foreground and Background bits.
        int fg = 0x000F & attributes;
        fg <<= 4;
        int bg = 0X00F0 & attributes;
        bg >>= 4;
        attributes = (short) ((attributes & 0xFF00) | fg | bg);
        return attributes;
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit invertAttributeColors 1");
    }

    private void applyCursorPosition() throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter applyCursorPosition 1");
        if (SetConsoleCursorPosition(console, info.cursorPosition.copy()) == 0) {
            throw new IOException(Kernel32.getLastErrorMessage());
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit applyCursorPosition 1");
    }

    @Override
    protected void processEraseScreen(int eraseOption) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processEraseScreen 1");
        getConsoleInfo();
        int[] written = new int[1];
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processEraseScreen 1");
        switch (eraseOption) {
            case ERASE_SCREEN:
                System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processEraseScreen 2");
                COORD topLeft = new COORD();
                topLeft.x = 0;
                topLeft.y = info.window.top;
                int screenLength = info.window.height() * info.size.x;
                FillConsoleOutputAttribute(console, info.attributes, screenLength, topLeft, written);
                FillConsoleOutputCharacterW(console, ' ', screenLength, topLeft, written);
                break;
                // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processEraseScreen 2");
            case ERASE_SCREEN_TO_BEGINING:
                System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processEraseScreen 3");
                COORD topLeft2 = new COORD();
                topLeft2.x = 0;
                topLeft2.y = info.window.top;
                int lengthToCursor = (info.cursorPosition.y - info.window.top) * info.size.x + info.cursorPosition.x;
                FillConsoleOutputAttribute(console, info.attributes, lengthToCursor, topLeft2, written);
                FillConsoleOutputCharacterW(console, ' ', lengthToCursor, topLeft2, written);
                break;
                // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processEraseScreen 3");
            case ERASE_SCREEN_TO_END:
                System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processEraseScreen 4");
                int lengthToEnd = (info.window.bottom - info.cursorPosition.y) * info.size.x
                        + (info.size.x - info.cursorPosition.x);
                FillConsoleOutputAttribute(console, info.attributes, lengthToEnd, info.cursorPosition.copy(), written);
                FillConsoleOutputCharacterW(console, ' ', lengthToEnd, info.cursorPosition.copy(), written);
                break;
                // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processEraseScreen 4");
            default:
                System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processEraseScreen 5");
                break;
                // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processEraseScreen 5");
        }
    }

    @Override
    protected void processEraseLine(int eraseOption) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processEraseLine 1");
        getConsoleInfo();
        int[] written = new int[1];
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processEraseLine 1");
        switch (eraseOption) {
            case ERASE_LINE:
                System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processEraseLine 2");
                COORD leftColCurrRow = info.cursorPosition.copy();
                leftColCurrRow.x = 0;
                FillConsoleOutputAttribute(console, info.attributes, info.size.x, leftColCurrRow, written);
                FillConsoleOutputCharacterW(console, ' ', info.size.x, leftColCurrRow, written);
                break;
                // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processEraseLine 2");
            case ERASE_LINE_TO_BEGINING:
                System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processEraseLine 3");
                COORD leftColCurrRow2 = info.cursorPosition.copy();
                leftColCurrRow2.x = 0;
                FillConsoleOutputAttribute(console, info.attributes, info.cursorPosition.x, leftColCurrRow2, written);
                FillConsoleOutputCharacterW(console, ' ', info.cursorPosition.x, leftColCurrRow2, written);
                break;
                // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processEraseLine 3");
            case ERASE_LINE_TO_END:
                System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processEraseLine 4");
                int lengthToLastCol = info.size.x - info.cursorPosition.x;
                FillConsoleOutputAttribute(
                        console, info.attributes, lengthToLastCol, info.cursorPosition.copy(), written);
                FillConsoleOutputCharacterW(console, ' ', lengthToLastCol, info.cursorPosition.copy(), written);
                break;
                // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processEraseLine 4");
            default:
                System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processEraseLine 5");
                break;
                // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processEraseLine 5");
        }
    }

    @Override
    protected void processCursorLeft(int count) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processCursorLeft 1");
        getConsoleInfo();
        info.cursorPosition.x = (short) Math.max(0, info.cursorPosition.x - count);
        applyCursorPosition();
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processCursorLeft 1");
    }

    @Override
    protected void processCursorRight(int count) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processCursorRight 1");
        getConsoleInfo();
        info.cursorPosition.x = (short) Math.min(info.window.width(), info.cursorPosition.x + count);
        applyCursorPosition();
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processCursorRight 1");
    }

    @Override
    protected void processCursorDown(int count) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processCursorDown 1");
        getConsoleInfo();
        info.cursorPosition.y = (short) Math.min(Math.max(0, info.size.y - 1), info.cursorPosition.y + count);
        applyCursorPosition();
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processCursorDown 1");
    }

    @Override
    protected void processCursorUp(int count) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processCursorUp 1");
        getConsoleInfo();
        info.cursorPosition.y = (short) Math.max(info.window.top, info.cursorPosition.y - count);
        applyCursorPosition();
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processCursorUp 1");
    }

    @Override
    protected void processCursorTo(int row, int col) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processCursorTo 1");
        getConsoleInfo();
        info.cursorPosition.y = (short) Math.max(info.window.top, Math.min(info.size.y, info.window.top + row - 1));
        info.cursorPosition.x = (short) Math.max(0, Math.min(info.window.width(), col - 1));
        applyCursorPosition();
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processCursorTo 1");
    }

    @Override
    protected void processCursorToColumn(int x) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processCursorToColumn 1");
        getConsoleInfo();
        info.cursorPosition.x = (short) Math.max(0, Math.min(info.window.width(), x - 1));
        applyCursorPosition();
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processCursorToColumn 1");
    }

    @Override
    protected void processCursorUpLine(int count) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processCursorUpLine 1");
        getConsoleInfo();
        info.cursorPosition.x = 0;
        info.cursorPosition.y = (short) Math.max(info.window.top, info.cursorPosition.y - count);
        applyCursorPosition();
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processCursorUpLine 1");
    }

    @Override
    protected void processCursorDownLine(int count) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processCursorDownLine 1");
        getConsoleInfo();
        info.cursorPosition.x = 0;
        info.cursorPosition.y = (short) Math.max(info.window.top, info.cursorPosition.y + count);
        applyCursorPosition();
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processCursorDownLine 1");
    }

    @Override
    protected void processSetForegroundColor(int color, boolean bright) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processSetForegroundColor 1");
        info.attributes = (short) ((info.attributes & ~0x0007) | ANSI_FOREGROUND_COLOR_MAP[color]);
        if (bright) {
            info.attributes |= FOREGROUND_INTENSITY;
        }
        applyAttribute();
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processSetForegroundColor 1");
    }

    @Override
    protected void processSetForegroundColorExt(int paletteIndex) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processSetForegroundColorExt 1");
        int round = Colors.roundColor(paletteIndex, 16);
        processSetForegroundColor(round >= 8 ? round - 8 : round, round >= 8);
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processSetForegroundColorExt 1");
    }

    @Override
    protected void processSetForegroundColorExt(int r, int g, int b) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processSetForegroundColorExt 2");
        int round = Colors.roundRgbColor(r, g, b, 16);
        processSetForegroundColor(round >= 8 ? round - 8 : round, round >= 8);
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processSetForegroundColorExt 2");
    }

    @Override
    protected void processSetBackgroundColor(int color, boolean bright) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processSetBackgroundColor 1");
        info.attributes = (short) ((info.attributes & ~0x0070) | ANSI_BACKGROUND_COLOR_MAP[color]);
        if (bright) {
            info.attributes |= BACKGROUND_INTENSITY;
        }
        applyAttribute();
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processSetBackgroundColor 1");
    }

    @Override
    protected void processSetBackgroundColorExt(int paletteIndex) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processSetBackgroundColorExt 1");
        int round = Colors.roundColor(paletteIndex, 16);
        processSetBackgroundColor(round >= 8 ? round - 8 : round, round >= 8);
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processSetBackgroundColorExt 1");
    }

    @Override
    protected void processSetBackgroundColorExt(int r, int g, int b) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processSetBackgroundColorExt 2");
        int round = Colors.roundRgbColor(r, g, b, 16);
        processSetBackgroundColor(round >= 8 ? round - 8 : round, round >= 8);
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processSetBackgroundColorExt 2");
    }

    @Override
    protected void processDefaultTextColor() throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processDefaultTextColor 1");
        info.attributes = (short) ((info.attributes & ~0x000F) | (originalColors & 0xF));
        info.attributes = (short) (info.attributes & ~FOREGROUND_INTENSITY);
        applyAttribute();
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processDefaultTextColor 1");
    }

    @Override
    protected void processDefaultBackgroundColor() throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processDefaultBackgroundColor 1");
        info.attributes = (short) ((info.attributes & ~0x00F0) | (originalColors & 0xF0));
        info.attributes = (short) (info.attributes & ~BACKGROUND_INTENSITY);
        applyAttribute();
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processDefaultBackgroundColor 1");
    }

    @Override
    protected void processAttributeReset() throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processAttributeReset 1");
        info.attributes = (short) ((info.attributes & ~0x00FF) | originalColors);
        this.negative = false;
        applyAttribute();
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processAttributeReset 1");
    }

    @Override
    protected void processSetAttribute(int attribute) throws IOException {
        System.err.println("");
        // System.err.println("");
        switch (attribute) {
            case ATTRIBUTE_INTENSITY_BOLD:
                System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processSetAttribute 2");
                info.attributes = (short) (info.attributes | FOREGROUND_INTENSITY);
                applyAttribute();
                break;
                // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processSetAttribute 2");
            case ATTRIBUTE_INTENSITY_NORMAL:
                System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processSetAttribute 3");
                info.attributes = (short) (info.attributes & ~FOREGROUND_INTENSITY);
                applyAttribute();
                break;
                // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processSetAttribute 3");

                // Yeah, setting the background intensity is not underlining.. but it's best we can do
                // using the Windows console API
            case ATTRIBUTE_UNDERLINE:
                System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processSetAttribute 4");
                info.attributes = (short) (info.attributes | BACKGROUND_INTENSITY);
                applyAttribute();
                break;
                // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processSetAttribute 4");
            case ATTRIBUTE_UNDERLINE_OFF:
                System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processSetAttribute 5");
                info.attributes = (short) (info.attributes & ~BACKGROUND_INTENSITY);
                applyAttribute();
                break;
                // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processSetAttribute 5");

            case ATTRIBUTE_NEGATIVE_ON:
                System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processSetAttribute 6");
                negative = true;
                applyAttribute();
                break;
                // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processSetAttribute 6");
            case ATTRIBUTE_NEGATIVE_OFF:
                System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processSetAttribute 7");
                negative = false;
                applyAttribute();
                break;
                // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processSetAttribute 7");
            default:
                System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processSetAttribute 8");
                break;
                // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processSetAttribute 8");
        }
    }

    @Override
    protected void processSaveCursorPosition() throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processSaveCursorPosition 1");
        getConsoleInfo();
        savedX = info.cursorPosition.x;
        savedY = info.cursorPosition.y;
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processSaveCursorPosition 1");
    }

    @Override
    protected void processRestoreCursorPosition() throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processRestoreCursorPosition 1");
        // restore only if there was a save operation first
        if (savedX != -1 && savedY != -1) {
            System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processRestoreCursorPosition 2");
            os.flush();
            info.cursorPosition.x = savedX;
            info.cursorPosition.y = savedY;
            applyCursorPosition();
            // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processRestoreCursorPosition 2");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processRestoreCursorPosition 1");
    }

    @Override
    protected void processInsertLine(int optionInt) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processInsertLine 1");
        getConsoleInfo();
        SMALL_RECT scroll = info.window.copy();
        scroll.top = info.cursorPosition.y;
        COORD org = new COORD();
        org.x = 0;
        org.y = (short) (info.cursorPosition.y + optionInt);
        CHAR_INFO info = new CHAR_INFO();
        info.attributes = originalColors;
        info.unicodeChar = ' ';
        if (ScrollConsoleScreenBuffer(console, scroll, scroll, org, info) == 0) {
            throw new IOException(Kernel32.getLastErrorMessage());
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processInsertLine 1");
    }

    @Override
    protected void processDeleteLine(int optionInt) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processDeleteLine 1");
        getConsoleInfo();
        SMALL_RECT scroll = info.window.copy();
        scroll.top = info.cursorPosition.y;
        COORD org = new COORD();
        org.x = 0;
        org.y = (short) (info.cursorPosition.y - optionInt);
        CHAR_INFO info = new CHAR_INFO();
        info.attributes = originalColors;
        info.unicodeChar = ' ';
        if (ScrollConsoleScreenBuffer(console, scroll, scroll, org, info) == 0) {
            throw new IOException(Kernel32.getLastErrorMessage());
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processDeleteLine 1");
    }

    @Override
    protected void processChangeWindowTitle(String label) {
        System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] enter processChangeWindowTitle 1");
        SetConsoleTitle(label);
        // System.err.println("[src/main/java/org/fusesource/jansi/io/WindowsAnsiProcessor.java] exit processChangeWindowTitle 1");
    }
}
// Total cost: 0.118536
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split
// chunks: [(0, 424)]
// Total instrumented cost: 0.118536, input tokens: 2398, output tokens: 6585, cache read tokens: 2394, cache write
// tokens: 5075

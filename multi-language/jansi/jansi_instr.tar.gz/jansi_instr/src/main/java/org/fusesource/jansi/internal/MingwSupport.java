/*
 * Copyright (C) 2009-2023 the original author(s).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.fusesource.jansi.internal;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Support for MINGW terminals.
 * Those terminals do not use the underlying windows terminal and there's no CLibrary available
 * in these environments.  We have to rely on calling {@code stty.exe} and {@code tty.exe} to
 * obtain the terminal name and width.
 */
public class MingwSupport {

    private final String sttyCommand;
    private final String ttyCommand;
    private final Pattern columnsPatterns;

    public MingwSupport() {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter MingwSupport 1");
        String tty = null;
        String stty = null;
        String path = System.getenv("PATH");
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit MingwSupport 1");

        if (path != null) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter MingwSupport 2");
            String[] paths = path.split(File.pathSeparator);
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit MingwSupport 2");

            for (String p : paths) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter MingwSupport 3");
                File ttyFile = new File(p, "tty.exe");
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit MingwSupport 3");

                if (tty == null && ttyFile.canExecute()) {
                    System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter MingwSupport 4");
                    tty = ttyFile.getAbsolutePath();
                    // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit MingwSupport 4");
                }

                System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter MingwSupport 5");
                File sttyFile = new File(p, "stty.exe");
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit MingwSupport 5");

                if (stty == null && sttyFile.canExecute()) {
                    System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter MingwSupport 6");
                    stty = sttyFile.getAbsolutePath();
                    // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit MingwSupport 6");
                }
            }
        }

        if (tty == null) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter MingwSupport 7");
            tty = "tty.exe";
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit MingwSupport 7");
        }

        if (stty == null) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter MingwSupport 8");
            stty = "stty.exe";
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit MingwSupport 8");
        }

        System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter MingwSupport 9");
        ttyCommand = tty;
        sttyCommand = stty;
        // Compute patterns
        columnsPatterns = Pattern.compile("\\b" + "columns" + "\\s+(\\d+)\\b");
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit MingwSupport 9");
    }

    public String getConsoleName(boolean stdout) {
        System.err.println("");
        try {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter getConsoleName 2");
            Process p = new ProcessBuilder(ttyCommand)
                    .redirectInput(getRedirect(stdout ? FileDescriptor.out : FileDescriptor.err))
                    .start();
            String result = waitAndCapture(p);
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit getConsoleName 2");

            if (p.exitValue() == 0) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter getConsoleName 3");
                return result.trim();
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit getConsoleName 3");
            }
        } catch (Throwable t) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter getConsoleName 4");
            if ("java.lang.reflect.InaccessibleObjectException"
                    .equals(t.getClass().getName())) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter getConsoleName 5");
                System.err.println("MINGW support requires --add-opens java.base/java.lang=ALL-UNNAMED");
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit getConsoleName 5");
            }
            // ignore
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit getConsoleName 4");
        }

        System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter getConsoleName 6");
        return null;
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit getConsoleName 6");
    }

    public int getTerminalWidth(String name) {
        System.err.println("");
        try {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter getTerminalWidth 2");
            Process p = new ProcessBuilder(sttyCommand, "-F", name, "-a").start();
            String result = waitAndCapture(p);
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit getTerminalWidth 2");

            if (p.exitValue() != 0) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter getTerminalWidth 3");
                throw new IOException("Error executing '" + sttyCommand + "': " + result);
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit getTerminalWidth 3");
            }

            System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter getTerminalWidth 4");
            Matcher matcher = columnsPatterns.matcher(result);
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit getTerminalWidth 4");

            if (matcher.find()) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter getTerminalWidth 5");
                return Integer.parseInt(matcher.group(1));
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit getTerminalWidth 5");
            }

            System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter getTerminalWidth 6");
            throw new IOException("Unable to parse columns");
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit getTerminalWidth 6");
        } catch (Exception e) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter getTerminalWidth 7");
            throw new RuntimeException(e);
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit getTerminalWidth 7");
        }
    }

    private static String waitAndCapture(Process p) throws IOException, InterruptedException {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter waitAndCapture 1");
        ByteArrayOutputStream bout = new ByteArrayOutputStream();
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit waitAndCapture 1");

        try (InputStream in = p.getInputStream();
                InputStream err = p.getErrorStream()) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter waitAndCapture 2");
            int c;
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit waitAndCapture 2");

            while ((c = in.read()) != -1) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter waitAndCapture 3");
                bout.write(c);
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit waitAndCapture 3");
            }

            while ((c = err.read()) != -1) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter waitAndCapture 4");
                bout.write(c);
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit waitAndCapture 4");
            }

            System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter waitAndCapture 5");
            p.waitFor();
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit waitAndCapture 5");
        }

        System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter waitAndCapture 6");
        return bout.toString();
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit waitAndCapture 6");
    }

    /**
     * This requires --add-opens java.base/java.lang=ALL-UNNAMED
     */
    private ProcessBuilder.Redirect getRedirect(FileDescriptor fd) throws ReflectiveOperationException {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] enter getRedirect 1");
        // This is not really allowed, but this is the only way to redirect the output or error stream
        // to the input.  This is definitely not something you'd usually want to do, but in the case of
        // the `tty` utility, it provides a way to get
        Class<?> rpi = Class.forName("java.lang.ProcessBuilder$RedirectPipeImpl");
        Constructor<?> cns = rpi.getDeclaredConstructor();
        cns.setAccessible(true);
        ProcessBuilder.Redirect input = (ProcessBuilder.Redirect) cns.newInstance();
        Field f = rpi.getDeclaredField("fd");
        f.setAccessible(true);
        f.set(input, fd);
        return input;
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/MingwSupport.java] exit getRedirect 1");
    }
}
// Total cost: 0.042408
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split
// chunks: [(0, 137)]
// Total instrumented cost: 0.042408, input tokens: 2398, output tokens: 2405, cache read tokens: 2394, cache write
// tokens: 1494

/*
 * Copyright (C) 2009-2023 the original author(s).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.fusesource.jansi.io;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;

import org.fusesource.jansi.AnsiColors;
import org.fusesource.jansi.AnsiMode;
import org.fusesource.jansi.AnsiType;

import static java.nio.charset.StandardCharsets.US_ASCII;

/**
 * A ANSI print stream extracts ANSI escape codes written to
 * an output stream and calls corresponding <code>AnsiProcessor.process*</code> methods.
 * This particular class is not synchronized for improved performances.
 *
 * <p>For more information about ANSI escape codes, see
 * <a href="http://en.wikipedia.org/wiki/ANSI_escape_code">Wikipedia article</a>
 *
 * @since 1.0
 * @see AnsiProcessor
 */
public class AnsiOutputStream extends FilterOutputStream {

    public static final byte[] RESET_CODE = "\033[0m".getBytes(US_ASCII);

    @FunctionalInterface
    public interface IoRunnable {
        void run() throws IOException;
    }

    @FunctionalInterface
    public interface WidthSupplier {
        int getTerminalWidth();
    }

    public static class ZeroWidthSupplier implements WidthSupplier {
        @Override
        public int getTerminalWidth() {
            System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter ZeroWidthSupplier.getTerminalWidth 1");
            return 0;
            // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit ZeroWidthSupplier.getTerminalWidth 1");
        }
    }

    private static final int LOOKING_FOR_FIRST_ESC_CHAR = 0;
    private static final int LOOKING_FOR_SECOND_ESC_CHAR = 1;
    private static final int LOOKING_FOR_NEXT_ARG = 2;
    private static final int LOOKING_FOR_STR_ARG_END = 3;
    private static final int LOOKING_FOR_INT_ARG_END = 4;
    private static final int LOOKING_FOR_OSC_COMMAND = 5;
    private static final int LOOKING_FOR_OSC_COMMAND_END = 6;
    private static final int LOOKING_FOR_OSC_PARAM = 7;
    private static final int LOOKING_FOR_ST = 8;
    private static final int LOOKING_FOR_CHARSET = 9;

    private static final int FIRST_ESC_CHAR = 27;
    private static final int SECOND_ESC_CHAR = '[';
    private static final int SECOND_OSC_CHAR = ']';
    private static final int BEL = 7;
    private static final int SECOND_ST_CHAR = '\\';
    private static final int SECOND_CHARSET0_CHAR = '(';
    private static final int SECOND_CHARSET1_CHAR = ')';

    private AnsiProcessor ap;
    private static final int MAX_ESCAPE_SEQUENCE_LENGTH = 100;
    private final byte[] buffer = new byte[MAX_ESCAPE_SEQUENCE_LENGTH];
    private int pos = 0;
    private int startOfValue;
    private final ArrayList<Object> options = new ArrayList<>();
    private int state = LOOKING_FOR_FIRST_ESC_CHAR;
    private final Charset cs;

    private final WidthSupplier width;
    private final AnsiProcessor processor;
    private final AnsiType type;
    private final AnsiColors colors;
    private final IoRunnable installer;
    private final IoRunnable uninstaller;
    private AnsiMode mode;
    private boolean resetAtUninstall;

    public AnsiOutputStream(
            OutputStream os,
            WidthSupplier width,
            AnsiMode mode,
            AnsiProcessor processor,
            AnsiType type,
            AnsiColors colors,
            Charset cs,
            IoRunnable installer,
            IoRunnable uninstaller,
            boolean resetAtUninstall) {
        super(os);
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.constructor 1");
        this.width = width;
        this.processor = processor;
        this.type = type;
        this.colors = colors;
        this.installer = installer;
        this.uninstaller = uninstaller;
        this.resetAtUninstall = resetAtUninstall;
        this.cs = cs;
        setMode(mode);
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.constructor 1");
    }

    public int getTerminalWidth() {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.getTerminalWidth 1");
        return width.getTerminalWidth();
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.getTerminalWidth 1");
    }

    public AnsiType getType() {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.getType 1");
        return type;
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.getType 1");
    }

    public AnsiColors getColors() {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.getColors 1");
        return colors;
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.getColors 1");
    }

    public AnsiMode getMode() {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.getMode 1");
        return mode;
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.getMode 1");
    }

    public void setMode(AnsiMode mode) {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.setMode 1");
        ap = mode == AnsiMode.Strip
                ? new AnsiProcessor(out)
                : mode == AnsiMode.Force || processor == null ? new ColorsAnsiProcessor(out, colors) : processor;
        this.mode = mode;
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.setMode 1");
    }

    public boolean isResetAtUninstall() {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.isResetAtUninstall 1");
        return resetAtUninstall;
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.isResetAtUninstall 1");
    }

    public void setResetAtUninstall(boolean resetAtUninstall) {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.setResetAtUninstall 1");
        this.resetAtUninstall = resetAtUninstall;
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.setResetAtUninstall 1");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void write(int data) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 1");
        switch (state) {
            case LOOKING_FOR_FIRST_ESC_CHAR:
                if (data == FIRST_ESC_CHAR) {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 2");
                    buffer[pos++] = (byte) data;
                    state = LOOKING_FOR_SECOND_ESC_CHAR;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 2");
                } else {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 3");
                    out.write(data);
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 3");
                }
                break;

            case LOOKING_FOR_SECOND_ESC_CHAR:
                System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 4");
                buffer[pos++] = (byte) data;
                if (data == SECOND_ESC_CHAR) {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 5");
                    state = LOOKING_FOR_NEXT_ARG;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 5");
                } else if (data == SECOND_OSC_CHAR) {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 6");
                    state = LOOKING_FOR_OSC_COMMAND;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 6");
                } else if (data == SECOND_CHARSET0_CHAR) {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 7");
                    options.add(0);
                    state = LOOKING_FOR_CHARSET;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 7");
                } else if (data == SECOND_CHARSET1_CHAR) {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 8");
                    options.add(1);
                    state = LOOKING_FOR_CHARSET;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 8");
                } else {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 9");
                    reset(false);
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 9");
                }
                // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 4");
                break;

            case LOOKING_FOR_NEXT_ARG:
                System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 10");
                buffer[pos++] = (byte) data;
                if ('"' == data) {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 11");
                    startOfValue = pos - 1;
                    state = LOOKING_FOR_STR_ARG_END;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 11");
                } else if ('0' <= data && data <= '9') {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 12");
                    startOfValue = pos - 1;
                    state = LOOKING_FOR_INT_ARG_END;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 12");
                } else if (';' == data) {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 13");
                    options.add(null);
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 13");
                } else if ('?' == data) {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 14");
                    options.add('?');
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 14");
                } else if ('=' == data) {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 15");
                    options.add('=');
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 15");
                } else {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 16");
                    processEscapeCommand(data);
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 16");
                }
                // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 10");
                break;

            case LOOKING_FOR_INT_ARG_END:
                System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 17");
                buffer[pos++] = (byte) data;
                if (!('0' <= data && data <= '9')) {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 18");
                    String strValue = new String(buffer, startOfValue, (pos - 1) - startOfValue);
                    Integer value = Integer.valueOf(strValue);
                    options.add(value);
                    if (data == ';') {
                        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 19");
                        state = LOOKING_FOR_NEXT_ARG;
                        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 19");
                    } else {
                        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 20");
                        processEscapeCommand(data);
                        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 20");
                    }
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 18");
                }
                // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 17");
                break;

            case LOOKING_FOR_STR_ARG_END:
                System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 21");
                buffer[pos++] = (byte) data;
                if ('"' != data) {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 22");
                    String value = new String(buffer, startOfValue, (pos - 1) - startOfValue, cs);
                    options.add(value);
                    if (data == ';') {
                        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 23");
                        state = LOOKING_FOR_NEXT_ARG;
                        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 23");
                    } else {
                        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 24");
                        processEscapeCommand(data);
                        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 24");
                    }
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 22");
                }
                // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 21");
                break;

            case LOOKING_FOR_OSC_COMMAND:
                System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 25");
                buffer[pos++] = (byte) data;
                if ('0' <= data && data <= '9') {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 26");
                    startOfValue = pos - 1;
                    state = LOOKING_FOR_OSC_COMMAND_END;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 26");
                } else {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 27");
                    reset(false);
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 27");
                }
                // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 25");
                break;

            case LOOKING_FOR_OSC_COMMAND_END:
                System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 28");
                buffer[pos++] = (byte) data;
                if (';' == data) {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 29");
                    String strValue = new String(buffer, startOfValue, (pos - 1) - startOfValue);
                    Integer value = Integer.valueOf(strValue);
                    options.add(value);
                    startOfValue = pos;
                    state = LOOKING_FOR_OSC_PARAM;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 29");
                } else if ('0' <= data && data <= '9') {
                    // already pushed digit to buffer, just keep looking
                } else {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 30");
                    // oops, did not expect this
                    reset(false);
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 30");
                }
                // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 28");
                break;

            case LOOKING_FOR_OSC_PARAM:
                System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 31");
                buffer[pos++] = (byte) data;
                if (BEL == data) {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 32");
                    String value = new String(buffer, startOfValue, (pos - 1) - startOfValue, cs);
                    options.add(value);
                    processOperatingSystemCommand();
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 32");
                } else if (FIRST_ESC_CHAR == data) {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 33");
                    state = LOOKING_FOR_ST;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 33");
                } else {
                    // just keep looking while adding text
                }
                // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 31");
                break;

            case LOOKING_FOR_ST:
                System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 34");
                buffer[pos++] = (byte) data;
                if (SECOND_ST_CHAR == data) {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 35");
                    String value = new String(buffer, startOfValue, (pos - 2) - startOfValue, cs);
                    options.add(value);
                    processOperatingSystemCommand();
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 35");
                } else {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 36");
                    state = LOOKING_FOR_OSC_PARAM;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 36");
                }
                // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 34");
                break;

            case LOOKING_FOR_CHARSET:
                System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 37");
                options.add((char) data);
                processCharsetSelect();
                // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 37");
                break;
        }

        // Is it just too long?
        if (pos >= buffer.length) {
            System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.write 38");
            reset(false);
            // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 38");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.write 1");
    }

    private void processCharsetSelect() throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.processCharsetSelect 1");
        try {
            reset(ap != null && ap.processCharsetSelect(options));
        } catch (RuntimeException e) {
            System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.processCharsetSelect 2");
            reset(true);
            throw e;
            // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.processCharsetSelect 2");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.processCharsetSelect 1");
    }

    private void processOperatingSystemCommand() throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.processOperatingSystemCommand 1");
        try {
            reset(ap != null && ap.processOperatingSystemCommand(options));
        } catch (RuntimeException e) {
            System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.processOperatingSystemCommand 2");
            reset(true);
            throw e;
            // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.processOperatingSystemCommand 2");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.processOperatingSystemCommand 1");
    }

    private void processEscapeCommand(int data) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.processEscapeCommand 1");
        try {
            reset(ap != null && ap.processEscapeCommand(options, data));
        } catch (RuntimeException e) {
            System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.processEscapeCommand 2");
            reset(true);
            throw e;
            // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.processEscapeCommand 2");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.processEscapeCommand 1");
    }

    /**
     * Resets all state to continue with regular parsing
     * @param skipBuffer if current buffer should be skipped or written to out
     * @throws IOException
     */
    private void reset(boolean skipBuffer) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.reset 1");
        if (!skipBuffer) {
            System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.reset 2");
            out.write(buffer, 0, pos);
            // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.reset 2");
        }
        pos = 0;
        startOfValue = 0;
        options.clear();
        state = LOOKING_FOR_FIRST_ESC_CHAR;
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.reset 1");
    }

    public void install() throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.install 1");
        if (installer != null) {
            System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.install 2");
            installer.run();
            // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.install 2");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.install 1");
    }

    public void uninstall() throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.uninstall 1");
        if (resetAtUninstall && type != AnsiType.Redirected && type != AnsiType.Unsupported) {
            System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.uninstall 2");
            setMode(AnsiMode.Default);
            write(RESET_CODE);
            flush();
            // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.uninstall 2");
        }
        if (uninstaller != null) {
            System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.uninstall 3");
            uninstaller.run();
            // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.uninstall 3");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.uninstall 1");
    }

    @Override
    public void close() throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] enter AnsiOutputStream.close 1");
        uninstall();
        super.close();
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiOutputStream.java] exit AnsiOutputStream.close 1");
    }
}
// Total cost: 0.097608
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split
// chunks: [(0, 359)]
// Total instrumented cost: 0.097608, input tokens: 2398, output tokens: 5611, cache read tokens: 2394, cache write
// tokens: 3390

/*
 * Copyright (C) 2009-2023 the original author(s).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.fusesource.jansi;

/**
 * Colors support.
 *
 * @since 2.1
 */
public enum AnsiColors {
    Colors16("16 colors"),
    Colors256("256 colors"),
    TrueColor("24-bit colors");

    private final String description;

    AnsiColors(String description) {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiColors.java] enter AnsiColors 1");
        this.description = description;
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiColors.java] exit AnsiColors 1");
    }

    String getDescription() {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiColors.java] enter getDescription 1");
        return description;
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiColors.java] exit getDescription 1");
    }
}
// Total cost: 0.007540
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split
// chunks: [(0, 37)]
// Total instrumented cost: 0.007540, input tokens: 2398, output tokens: 361, cache read tokens: 2394, cache write
// tokens: 372

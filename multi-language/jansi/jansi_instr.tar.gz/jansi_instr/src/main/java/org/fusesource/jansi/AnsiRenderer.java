/*
 * Copyright (C) 2009-2023 the original author(s).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.fusesource.jansi;

import java.io.IOException;
import java.util.Locale;

import org.fusesource.jansi.Ansi.Attribute;
import org.fusesource.jansi.Ansi.Color;

/**
 * Renders ANSI color escape-codes in strings by parsing out some special syntax to pick up the correct fluff to use.
 *
 * The syntax for embedded ANSI codes is:
 *
 * <pre>
 *   &#64;|<em>code</em>(,<em>code</em>)* <em>text</em>|&#64;
 * </pre>
 *
 * Examples:
 *
 * <pre>
 *   &#64;|bold Hello|&#64;
 * </pre>
 *
 * <pre>
 *   &#64;|bold,red Warning!|&#64;
 * </pre>
 *
 * @since 2.2
 */
public class AnsiRenderer {

    public static final String BEGIN_TOKEN = "@|";

    public static final String END_TOKEN = "|@";

    public static final String CODE_TEXT_SEPARATOR = " ";

    public static final String CODE_LIST_SEPARATOR = ",";

    private static final int BEGIN_TOKEN_LEN = 2;

    private static final int END_TOKEN_LEN = 2;

    public static String render(final String input) throws IllegalArgumentException {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter render 1");
        try {
            return render(input, new StringBuilder()).toString();
        } catch (IOException e) {
            // Cannot happen because StringBuilder does not throw IOException
            throw new IllegalArgumentException(e);
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit render 1");
    }

    /**
     * Renders the given input to the target Appendable.
     *
     * @param input
     *            source to render
     * @param target
     *            render onto this target Appendable.
     * @return the given Appendable
     * @throws IOException
     *             If an I/O error occurs
     */
    public static Appendable render(final String input, Appendable target) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter render 2");
        int i = 0;
        int j, k;
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit render 2");

        while (true) {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter render 3");
            j = input.indexOf(BEGIN_TOKEN, i);
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit render 3");
            if (j == -1) {
                System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter render 4");
                if (i == 0) {
                    System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter render 5");
                    target.append(input);
                    return target;
                    // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit render 5");
                }
                target.append(input.substring(i));
                return target;
                // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit render 4");
            }
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter render 6");
            target.append(input.substring(i, j));
            k = input.indexOf(END_TOKEN, j);
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit render 6");

            if (k == -1) {
                System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter render 7");
                target.append(input);
                return target;
                // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit render 7");
            }
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter render 8");
            j += BEGIN_TOKEN_LEN;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit render 8");

            // Check for invalid string with END_TOKEN before BEGIN_TOKEN
            if (k < j) {
                System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter render 9");
                throw new IllegalArgumentException("Invalid input string found.");
                // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit render 9");
            }
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter render 10");
            String spec = input.substring(j, k);

            String[] items = spec.split(CODE_TEXT_SEPARATOR, 2);
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit render 10");
            if (items.length == 1) {
                System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter render 11");
                target.append(input);
                return target;
                // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit render 11");
            }
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter render 12");
            String replacement = render(items[1], items[0].split(CODE_LIST_SEPARATOR));

            target.append(replacement);

            i = k + END_TOKEN_LEN;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit render 12");
        }
    }

    public static String render(final String text, final String... codes) {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter render 13");
        return render(Ansi.ansi(), codes).a(text).reset().toString();
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit render 13");
    }

    /**
     * Renders {@link Code} names as an ANSI escape string.
     * @param codes The code names to render
     * @return an ANSI escape string.
     */
    public static String renderCodes(final String... codes) {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter renderCodes 1");
        return render(Ansi.ansi(), codes).toString();
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit renderCodes 1");
    }

    /**
     * Renders {@link Code} names as an ANSI escape string.
     * @param codes A space separated list of code names to render
     * @return an ANSI escape string.
     */
    public static String renderCodes(final String codes) {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter renderCodes 2");
        return renderCodes(codes.split("\\s"));
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit renderCodes 2");
    }

    private static Ansi render(Ansi ansi, String... names) {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter render 14");
        for (String name : names) {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter render 15");
            Code code = Code.valueOf(name.toUpperCase(Locale.ENGLISH));
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit render 15");
            if (code.isColor()) {
                System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter render 16");
                if (code.isBackground()) {
                    System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter render 17");
                    ansi.bg(code.getColor());
                    // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit render 17");
                } else {
                    System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter render 18");
                    ansi.fg(code.getColor());
                    // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit render 18");
                }
                // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit render 16");
            } else if (code.isAttribute()) {
                System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter render 19");
                ansi.a(code.getAttribute());
                // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit render 19");
            }
        }
        return ansi;
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit render 14");
    }

    public static boolean test(final String text) {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter test 1");
        return text != null && text.contains(BEGIN_TOKEN);
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit test 1");
    }

    @SuppressWarnings("unused")
    public enum Code {
        //
        // TODO: Find a better way to keep Code in sync with Color/Attribute/Erase
        //

        // Colors
        BLACK(Color.BLACK),
        RED(Color.RED),
        GREEN(Color.GREEN),
        YELLOW(Color.YELLOW),
        BLUE(Color.BLUE),
        MAGENTA(Color.MAGENTA),
        CYAN(Color.CYAN),
        WHITE(Color.WHITE),
        DEFAULT(Color.DEFAULT),

        // Foreground Colors
        FG_BLACK(Color.BLACK, false),
        FG_RED(Color.RED, false),
        FG_GREEN(Color.GREEN, false),
        FG_YELLOW(Color.YELLOW, false),
        FG_BLUE(Color.BLUE, false),
        FG_MAGENTA(Color.MAGENTA, false),
        FG_CYAN(Color.CYAN, false),
        FG_WHITE(Color.WHITE, false),
        FG_DEFAULT(Color.DEFAULT, false),

        // Background Colors
        BG_BLACK(Color.BLACK, true),
        BG_RED(Color.RED, true),
        BG_GREEN(Color.GREEN, true),
        BG_YELLOW(Color.YELLOW, true),
        BG_BLUE(Color.BLUE, true),
        BG_MAGENTA(Color.MAGENTA, true),
        BG_CYAN(Color.CYAN, true),
        BG_WHITE(Color.WHITE, true),
        BG_DEFAULT(Color.DEFAULT, true),

        // Attributes
        RESET(Attribute.RESET),
        INTENSITY_BOLD(Attribute.INTENSITY_BOLD),
        INTENSITY_FAINT(Attribute.INTENSITY_FAINT),
        ITALIC(Attribute.ITALIC),
        UNDERLINE(Attribute.UNDERLINE),
        BLINK_SLOW(Attribute.BLINK_SLOW),
        BLINK_FAST(Attribute.BLINK_FAST),
        BLINK_OFF(Attribute.BLINK_OFF),
        NEGATIVE_ON(Attribute.NEGATIVE_ON),
        NEGATIVE_OFF(Attribute.NEGATIVE_OFF),
        CONCEAL_ON(Attribute.CONCEAL_ON),
        CONCEAL_OFF(Attribute.CONCEAL_OFF),
        UNDERLINE_DOUBLE(Attribute.UNDERLINE_DOUBLE),
        UNDERLINE_OFF(Attribute.UNDERLINE_OFF),

        // Aliases
        BOLD(Attribute.INTENSITY_BOLD),
        FAINT(Attribute.INTENSITY_FAINT);

        private final Enum<?> n;

        private final boolean background;

        Code(final Enum<?> n, boolean background) {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter Code.constructor 1");
            this.n = n;
            this.background = background;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit Code.constructor 1");
        }

        Code(final Enum<?> n) {
            this(n, false);
        }

        public boolean isColor() {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter Code.isColor 1");
            return n instanceof Ansi.Color;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit Code.isColor 1");
        }

        public Ansi.Color getColor() {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter Code.getColor 1");
            return (Ansi.Color) n;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit Code.getColor 1");
        }

        public boolean isAttribute() {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter Code.isAttribute 1");
            return n instanceof Attribute;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit Code.isAttribute 1");
        }

        public Attribute getAttribute() {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter Code.getAttribute 1");
            return (Attribute) n;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit Code.getAttribute 1");
        }

        public boolean isBackground() {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] enter Code.isBackground 1");
            return background;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiRenderer.java] exit Code.isBackground 1");
        }
    }

    private AnsiRenderer() {}
}
// Total cost: 0.125348
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split
// chunks: [(0, 258)]
// Total instrumented cost: 0.125348, input tokens: 4718, output tokens: 6277, cache read tokens: 4710, cache write
// tokens: 7935

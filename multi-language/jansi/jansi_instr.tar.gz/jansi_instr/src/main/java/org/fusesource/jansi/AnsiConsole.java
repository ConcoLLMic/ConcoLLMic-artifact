/*
 * Copyright (C) 2009-2023 the original author(s).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.fusesource.jansi;

import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.IOError;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.nio.charset.UnsupportedCharsetException;
import java.util.Locale;

import org.fusesource.jansi.internal.CLibrary;
import org.fusesource.jansi.internal.CLibrary.WinSize;
import org.fusesource.jansi.internal.Kernel32.CONSOLE_SCREEN_BUFFER_INFO;
import org.fusesource.jansi.internal.MingwSupport;
import org.fusesource.jansi.io.AnsiOutputStream;
import org.fusesource.jansi.io.AnsiProcessor;
import org.fusesource.jansi.io.FastBufferedOutputStream;
import org.fusesource.jansi.io.WindowsAnsiProcessor;

import static org.fusesource.jansi.internal.CLibrary.ioctl;
import static org.fusesource.jansi.internal.CLibrary.isatty;
import static org.fusesource.jansi.internal.Kernel32.GetConsoleMode;
import static org.fusesource.jansi.internal.Kernel32.GetConsoleScreenBufferInfo;
import static org.fusesource.jansi.internal.Kernel32.GetStdHandle;
import static org.fusesource.jansi.internal.Kernel32.STD_ERROR_HANDLE;
import static org.fusesource.jansi.internal.Kernel32.STD_OUTPUT_HANDLE;
import static org.fusesource.jansi.internal.Kernel32.SetConsoleMode;

/**
 * Provides consistent access to an ANSI aware console PrintStream or an ANSI codes stripping PrintStream
 * if not on a terminal (see
 * <a href="http://fusesource.github.io/jansi/documentation/native-api/index.html?org/fusesource/jansi/internal/CLibrary.html">Jansi native
 * CLibrary isatty(int)</a>).
 * <p>The native library used is named <code>jansi</code> and is loaded using <a href="http://fusesource.github.io/hawtjni/">HawtJNI</a> Runtime
 * <a href="http://fusesource.github.io/hawtjni/documentation/api/index.html?org/fusesource/hawtjni/runtime/Library.html"><code>Library</code></a>
 *
 * @since 1.0
 * @see #systemInstall()
 * @see #out()
 * @see #err()
 * @see #ansiStream(boolean) for more details on ANSI mode selection
 */
public class AnsiConsole {

    /**
     * The default mode which Jansi will use, can be either <code>force</code>, <code>strip</code>
     * or <code>default</code> (the default).
     * If this property is set, it will override <code>jansi.passthrough</code>,
     * <code>jansi.strip</code> and <code>jansi.force</code> properties.
     */
    public static final String JANSI_MODE = "jansi.mode";
    /**
     * Jansi mode specific to the standard output stream.
     */
    public static final String JANSI_OUT_MODE = "jansi.out.mode";
    /**
     * Jansi mode specific to the standard error stream.
     */
    public static final String JANSI_ERR_MODE = "jansi.err.mode";

    /**
     * Jansi mode value to strip all ansi sequences.
     */
    public static final String JANSI_MODE_STRIP = "strip";
    /**
     * Jansi mode value to force ansi sequences to the stream even if it's not a terminal.
     */
    public static final String JANSI_MODE_FORCE = "force";
    /**
     * Jansi mode value that output sequences if on a terminal, else strip them.
     */
    public static final String JANSI_MODE_DEFAULT = "default";

    /**
     * The default color support that Jansi will use, can be either <code>16</code>,
     * <code>256</code> or <code>truecolor</code>.  If not set, JANSI will try to
     * autodetect the number of colors supported by the terminal by checking the
     * <code>COLORTERM</code> and <code>TERM</code> variables.
     */
    public static final String JANSI_COLORS = "jansi.colors";
    /**
     * Jansi colors specific to the standard output stream.
     */
    public static final String JANSI_OUT_COLORS = "jansi.out.colors";
    /**
     * Jansi colors specific to the standard error stream.
     */
    public static final String JANSI_ERR_COLORS = "jansi.err.colors";

    /**
     * Force the use of 16 colors. When using a 256-indexed color, or an RGB
     * color, the color will be rounded to the nearest one from the 16 palette.
     */
    public static final String JANSI_COLORS_16 = "16";
    /**
     * Force the use of 256 colors. When using an RGB color, the color will be
     * rounded to the nearest one from the standard 256 palette.
     */
    public static final String JANSI_COLORS_256 = "256";
    /**
     * Force the use of 24-bit colors.
     */
    public static final String JANSI_COLORS_TRUECOLOR = "truecolor";

    /**
     * If the <code>jansi.passthrough</code> system property is set to true, will not perform any transformation
     * and any ansi sequence will be conveyed without any modification.
     *
     * @deprecated use {@link #JANSI_MODE} instead
     */
    @Deprecated
    public static final String JANSI_PASSTHROUGH = "jansi.passthrough";
    /**
     * If the <code>jansi.strip</code> system property is set to true, and <code>jansi.passthrough</code>
     * is not enabled, all ansi sequences will be stripped before characters are written to the output streams.
     *
     * @deprecated use {@link #JANSI_MODE} instead
     */
    @Deprecated
    public static final String JANSI_STRIP = "jansi.strip";
    /**
     * If the <code>jansi.force</code> system property is set to true, and neither <code>jansi.passthrough</code>
     * nor <code>jansi.strip</code> are set, then ansi sequences will be printed to the output stream.
     * This forces the behavior which is by default dependent on the output stream being a real console: if the
     * output stream is redirected to a file or through a system pipe, ansi sequences are disabled by default.
     *
     * @deprecated use {@link #JANSI_MODE} instead
     */
    @Deprecated
    public static final String JANSI_FORCE = "jansi.force";
    /**
     * If the <code>jansi.eager</code> system property is set to true, the system streams will be eagerly
     * initialized, else the initialization is delayed until {@link #out()}, {@link #err()} or {@link #systemInstall()}
     * is called.
     *
     * @deprecated this property has been added but only for backward compatibility.
     * @since 2.1
     */
    @Deprecated()
    public static final String JANSI_EAGER = "jansi.eager";
    /**
     * If the <code>jansi.noreset</code> system property is set to true, the attributes won't be
     * reset when the streams are uninstalled.
     */
    public static final String JANSI_NORESET = "jansi.noreset";
    /**
     * If the <code>jansi.graceful</code> system property is set to false, any exception that occurs
     * during the initialization will cause the library to report this exception and fail. The default
     * behavior is to behave gracefully and fall back to pure emulation on posix systems.
     */
    public static final String JANSI_GRACEFUL = "jansi.graceful";

    /**
     * @deprecated this field will be made private in a future release, use {@link #sysOut()} instead
     */
    @Deprecated
    public static PrintStream system_out = System.out;
    /**
     * @deprecated this field will be made private in a future release, use {@link #out()} instead
     */
    @Deprecated
    public static PrintStream out;
    /**
     * @deprecated this field will be made private in a future release, use {@link #sysErr()} instead
     */
    @Deprecated
    public static PrintStream system_err = System.err;
    /**
     * @deprecated this field will be made private in a future release, use {@link #err()} instead
     */
    @Deprecated
    public static PrintStream err;

    /**
     * Try to find the width of the console for this process.
     * Both output and error streams will be checked to determine the width.
     * A value of 0 is returned if the width can not be determined.
     * @since 2.2
     */
    public static int getTerminalWidth() {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter getTerminalWidth 1");
        int w = out().getTerminalWidth();
        if (w <= 0) {
            w = err().getTerminalWidth();
        }
        return w;
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit getTerminalWidth 1");
    }

    static final boolean IS_WINDOWS =
            System.getProperty("os.name").toLowerCase(Locale.ENGLISH).contains("win");

    static final boolean IS_CYGWIN =
            IS_WINDOWS && System.getenv("PWD") != null && System.getenv("PWD").startsWith("/");

    static final boolean IS_MSYSTEM = IS_WINDOWS
            && System.getenv("MSYSTEM") != null
            && (System.getenv("MSYSTEM").startsWith("MINGW")
                    || System.getenv("MSYSTEM").equals("MSYS"));

    static final boolean IS_CONEMU = IS_WINDOWS && System.getenv("ConEmuPID") != null;

    static final int ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004;

    static int STDOUT_FILENO = 1;

    static int STDERR_FILENO = 2;

    static {
        if (getBoolean(JANSI_EAGER)) {
            initStreams();
        }
    }

    private static boolean initialized; // synchronized on AnsiConsole.class
    private static int installed; // synchronized on AnsiConsole.class
    private static int virtualProcessing; // synchronized on AnsiConsole.class

    private AnsiConsole() {}

    private static AnsiPrintStream ansiStream(boolean stdout) {
        System.err.println("");
        FileDescriptor descriptor = stdout ? FileDescriptor.out : FileDescriptor.err;
        final OutputStream out = new FastBufferedOutputStream(new FileOutputStream(descriptor));

        String enc = System.getProperty(stdout ? "stdout.encoding" : "stderr.encoding");
        if (enc == null) {
            enc = System.getProperty(stdout ? "sun.stdout.encoding" : "sun.stderr.encoding");
        }

        final boolean isatty;
        boolean isAtty;
        boolean withException;
        // Do not use the CLibrary.STDOUT_FILENO to avoid errors in case
        // the library can not be loaded on unsupported platforms
        final int fd = stdout ? STDOUT_FILENO : STDERR_FILENO;
        try {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 2");
            // If we can detect that stdout is not a tty.. then setup
            // to strip the ANSI sequences..
            isAtty = isatty(fd) != 0;
            String term = System.getenv("TERM");
            String emacs = System.getenv("INSIDE_EMACS");
            if (isAtty && "dumb".equals(term) && emacs != null && !emacs.contains("comint")) {
                isAtty = false;
            }
            withException = false;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 2");
        } catch (Throwable ignore) {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 3");
            // These errors happen if the JNI lib is not available for your platform.
            // But since we are on ANSI friendly platform, assume the user is on the console.
            isAtty = false;
            withException = true;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 3");
        }
        isatty = isAtty;

        final AnsiOutputStream.WidthSupplier width;
        final AnsiProcessor processor;
        final AnsiType type;
        final AnsiOutputStream.IoRunnable installer;
        final AnsiOutputStream.IoRunnable uninstaller;
        if (!isatty) {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 4");
            processor = null;
            type = withException ? AnsiType.Unsupported : AnsiType.Redirected;
            installer = uninstaller = null;
            width = new AnsiOutputStream.ZeroWidthSupplier();
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 4");
        } else if (IS_WINDOWS) {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 5");
            final long console = GetStdHandle(stdout ? STD_OUTPUT_HANDLE : STD_ERROR_HANDLE);
            final int[] mode = new int[1];
            final boolean isConsole = GetConsoleMode(console, mode) != 0;
            final AnsiOutputStream.WidthSupplier kernel32Width = new AnsiOutputStream.WidthSupplier() {
                @Override
                public int getTerminalWidth() {
                    System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter getTerminalWidth 2");
                    CONSOLE_SCREEN_BUFFER_INFO info = new CONSOLE_SCREEN_BUFFER_INFO();
                    GetConsoleScreenBufferInfo(console, info);
                    return info.windowWidth();
                    // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit getTerminalWidth 2");
                }
            };

            if (isConsole && SetConsoleMode(console, mode[0] | ENABLE_VIRTUAL_TERMINAL_PROCESSING) != 0) {
                System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 6");
                SetConsoleMode(console, mode[0]); // set it back for now, but we know it works
                processor = null;
                type = AnsiType.VirtualTerminal;
                installer = () -> {
                    synchronized (AnsiConsole.class) {
                        System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter installer 1");
                        virtualProcessing++;
                        SetConsoleMode(console, mode[0] | ENABLE_VIRTUAL_TERMINAL_PROCESSING);
                        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit installer 1");
                    }
                };
                uninstaller = () -> {
                    synchronized (AnsiConsole.class) {
                        System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter uninstaller 1");
                        if (--virtualProcessing == 0) {
                            SetConsoleMode(console, mode[0]);
                        }
                        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit uninstaller 1");
                    }
                };
                width = kernel32Width;
                // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 6");
            } else if ((IS_CONEMU || IS_CYGWIN || IS_MSYSTEM) && !isConsole) {
                System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 7");
                // ANSI-enabled ConEmu, Cygwin or MSYS(2) on Windows...
                processor = null;
                type = AnsiType.Native;
                installer = uninstaller = null;
                MingwSupport mingw = new MingwSupport();
                String name = mingw.getConsoleName(stdout);
                if (name != null && !name.isEmpty()) {
                    width = () -> mingw.getTerminalWidth(name);
                } else {
                    width = () -> -1;
                }
                // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 7");
            } else {
                System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 8");
                // On Windows, when no ANSI-capable terminal is used, we know the console does not natively interpret
                // ANSI
                // codes but we can use jansi Kernel32 API for console
                AnsiProcessor proc;
                AnsiType ttype;
                try {
                    proc = new WindowsAnsiProcessor(out, console);
                    ttype = AnsiType.Emulation;
                } catch (Throwable ignore) {
                    // this happens when the stdout is being redirected to a file.
                    // Use the AnsiProcessor to strip out the ANSI escape sequences.
                    proc = new AnsiProcessor(out);
                    ttype = AnsiType.Unsupported;
                }
                processor = proc;
                type = ttype;
                installer = uninstaller = null;
                width = kernel32Width;
                // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 8");
            }
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 5");
        } else {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 9");
            // ANSI-enabled ConEmu, Cygwin or MSYS(2) on Windows...
            processor = null;
            type = AnsiType.Native;
            installer = uninstaller = null;
            width = new AnsiOutputStream.WidthSupplier() {
                @Override
                public int getTerminalWidth() {
                    System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter getTerminalWidth 3");
                    WinSize sz = new WinSize();
                    ioctl(fd, CLibrary.TIOCGWINSZ, sz);
                    return sz.ws_col;
                    // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit getTerminalWidth 3");
                }
            };
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 9");
        }

        AnsiMode mode;

        // If the jansi.mode property is set, use it
        String jansiMode = System.getProperty(stdout ? JANSI_OUT_MODE : JANSI_ERR_MODE, System.getProperty(JANSI_MODE));
        if (JANSI_MODE_FORCE.equals(jansiMode)) {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 10");
            mode = AnsiMode.Force;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 10");
        } else if (JANSI_MODE_STRIP.equals(jansiMode)) {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 11");
            mode = AnsiMode.Strip;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 11");
        } else if (jansiMode != null) {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 12");
            mode = isatty ? AnsiMode.Default : AnsiMode.Strip;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 12");
        }

        // If the jansi.passthrough property is set, then don't interpret
        // any of the ansi sequences.
        else if (getBoolean(JANSI_PASSTHROUGH)) {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 13");
            mode = AnsiMode.Force;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 13");
        }

        // If the jansi.strip property is set, then we just strip the
        // the ansi escapes.
        else if (getBoolean(JANSI_STRIP)) {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 14");
            mode = AnsiMode.Strip;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 14");
        }

        // If the jansi.force property is set, then we force to output
        // the ansi escapes for piping it into ansi color aware commands (e.g. less -r)
        else if (getBoolean(JANSI_FORCE)) {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 15");
            mode = AnsiMode.Force;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 15");
        } else {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 16");
            mode = isatty ? AnsiMode.Default : AnsiMode.Strip;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 16");
        }

        AnsiColors colors;

        String colorterm, term;
        // If the jansi.colors property is set, use it
        String jansiColors =
                System.getProperty(stdout ? JANSI_OUT_COLORS : JANSI_ERR_COLORS, System.getProperty(JANSI_COLORS));
        if (JANSI_COLORS_TRUECOLOR.equals(jansiColors)) {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 17");
            colors = AnsiColors.TrueColor;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 17");
        } else if (JANSI_COLORS_256.equals(jansiColors)) {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 18");
            colors = AnsiColors.Colors256;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 18");
        } else if (jansiColors != null) {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 19");
            colors = AnsiColors.Colors16;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 19");
        }

        // If the COLORTERM env variable contains "truecolor" or "24bit", assume true color support
        // see https://gist.github.com/XVilka/8346728#true-color-detection
        else if ((colorterm = System.getenv("COLORTERM")) != null
                && (colorterm.contains("truecolor") || colorterm.contains("24bit"))) {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 20");
            colors = AnsiColors.TrueColor;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 20");
        }

        // check the if TERM contains -direct
        else if ((term = System.getenv("TERM")) != null && term.contains("-direct")) {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 21");
            colors = AnsiColors.TrueColor;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 21");
        }

        // check the if TERM contains -256color
        else if (term != null && term.contains("-256color")) {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 22");
            colors = AnsiColors.Colors256;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 22");
        }

        // else defaults to 16 colors
        else {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 23");
            colors = AnsiColors.Colors16;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 23");
        }

        // If the jansi.noreset property is not set, reset the attributes
        // when the stream is closed
        boolean resetAtUninstall = type != AnsiType.Unsupported && !getBoolean(JANSI_NORESET);

        Charset cs = Charset.defaultCharset();
        if (enc != null) {
            try {
                System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 24");
                cs = Charset.forName(enc);
                // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 24");
            } catch (UnsupportedCharsetException e) {
            }
        }
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter ansiStream 25");
        return newPrintStream(
                new AnsiOutputStream(
                        out, width, mode, processor, type, colors, cs, installer, uninstaller, resetAtUninstall),
                cs.name());
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit ansiStream 25");
    }

    private static AnsiPrintStream newPrintStream(AnsiOutputStream out, String enc) {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter newPrintStream 1");
        if (enc != null) {
            try {
                System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter newPrintStream 2");
                return new AnsiPrintStream(out, true, enc);
                // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit newPrintStream 2");
            } catch (UnsupportedEncodingException e) {
            }
        }
        return new AnsiPrintStream(out, true);
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit newPrintStream 1");
    }

    static boolean getBoolean(String name) {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter getBoolean 1");
        boolean result = false;
        try {
            String val = System.getProperty(name);
            result = val.isEmpty() || Boolean.parseBoolean(val);
        } catch (IllegalArgumentException | NullPointerException ignored) {
        }
        return result;
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit getBoolean 1");
    }

    /**
     * If the standard out natively supports ANSI escape codes, then this just
     * returns System.out, otherwise it will provide an ANSI aware PrintStream
     * which strips out the ANSI escape sequences or which implement the escape
     * sequences.
     *
     * @return a PrintStream which is ANSI aware.
     */
    public static AnsiPrintStream out() {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter out 1");
        initStreams();
        return (AnsiPrintStream) out;
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit out 1");
    }

    /**
     * Access to the original System.out stream before ansi streams were installed.
     *
     * @return the originial System.out print stream
     */
    public static PrintStream sysOut() {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter sysOut 1");
        return system_out;
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit sysOut 1");
    }

    /**
     * If the standard out natively supports ANSI escape codes, then this just
     * returns System.err, otherwise it will provide an ANSI aware PrintStream
     * which strips out the ANSI escape sequences or which implement the escape
     * sequences.
     *
     * @return a PrintStream which is ANSI aware.
     */
    public static AnsiPrintStream err() {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter err 1");
        initStreams();
        return (AnsiPrintStream) err;
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit err 1");
    }

    /**
     * Access to the original System.err stream before ansi streams were installed.
     *
     * @return the originial System.err print stream
     */
    public static PrintStream sysErr() {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter sysErr 1");
        return system_err;
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit sysErr 1");
    }

    /**
     * Install <code>AnsiConsole.out()</code> to <code>System.out</code> and
     * <code>AnsiConsole.err()</code> to <code>System.err</code>.
     * @see #systemUninstall()
     */
    public static synchronized void systemInstall() {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter systemInstall 1");
        if (installed == 0) {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter systemInstall 2");
            initStreams();
            try {
                ((AnsiPrintStream) out).install();
                ((AnsiPrintStream) err).install();
            } catch (IOException e) {
                throw new IOError(e);
            }
            System.setOut(out);
            System.setErr(err);
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit systemInstall 2");
        }
        installed++;
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit systemInstall 1");
    }

    /**
     * check if the streams have been installed or not
     */
    public static synchronized boolean isInstalled() {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter isInstalled 1");
        return installed > 0;
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit isInstalled 1");
    }

    /**
     * undo a previous {@link #systemInstall()}.  If {@link #systemInstall()} was called
     * multiple times, {@link #systemUninstall()} must be called the same number of times before
     * it is actually uninstalled.
     */
    public static synchronized void systemUninstall() {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter systemUninstall 1");
        installed--;
        if (installed == 0) {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter systemUninstall 2");
            try {
                ((AnsiPrintStream) out).uninstall();
                ((AnsiPrintStream) err).uninstall();
            } catch (IOException e) {
                throw new IOError(e);
            }
            initialized = false;
            System.setOut(system_out);
            System.setErr(system_err);
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit systemUninstall 2");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit systemUninstall 1");
    }

    /**
     * Initialize the out/err ansi-enabled streams
     */
    static synchronized void initStreams() {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter initStreams 1");
        if (!initialized) {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] enter initStreams 2");
            out = ansiStream(true);
            err = ansiStream(false);
            initialized = true;
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit initStreams 2");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiConsole.java] exit initStreams 1");
    }
}
// Total cost: 0.298659
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split
// chunks: [(0, 567)]
// Total instrumented cost: 0.298659, input tokens: 8794, output tokens: 15581, cache read tokens: 8786, cache write
// tokens: 16609

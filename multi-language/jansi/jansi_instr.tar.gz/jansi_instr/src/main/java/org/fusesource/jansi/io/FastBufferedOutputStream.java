/*
 * Copyright (C) 2009-2023 the original author(s).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.fusesource.jansi.io;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * A simple buffering output stream with no synchronization.
 */
public class FastBufferedOutputStream extends FilterOutputStream {

    protected final byte[] buf = new byte[8192];
    protected int count;

    public FastBufferedOutputStream(OutputStream out) {
        super(out);
    }

    @Override
    public void write(int b) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/FastBufferedOutputStream.java] enter write(int) 1");
        if (count >= buf.length) {
            flushBuffer();
        }
        buf[count++] = (byte) b;
        // System.err.println("[src/main/java/org/fusesource/jansi/io/FastBufferedOutputStream.java] exit write(int) 1");
    }

    @Override
    public void write(byte b[], int off, int len) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/FastBufferedOutputStream.java] enter write(byte[],int,int) 1");
        if (len >= buf.length) {
            System.err.println("[src/main/java/org/fusesource/jansi/io/FastBufferedOutputStream.java] enter write(byte[],int,int) 2");
            flushBuffer();
            out.write(b, off, len);
            return;
            // System.err.println("[src/main/java/org/fusesource/jansi/io/FastBufferedOutputStream.java] exit write(byte[],int,int) 2");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/io/FastBufferedOutputStream.java] exit write(byte[],int,int) 1");

        System.err.println("[src/main/java/org/fusesource/jansi/io/FastBufferedOutputStream.java] enter write(byte[],int,int) 3");
        if (len > buf.length - count) {
            System.err.println("[src/main/java/org/fusesource/jansi/io/FastBufferedOutputStream.java] enter write(byte[],int,int) 4");
            flushBuffer();
            // System.err.println("[src/main/java/org/fusesource/jansi/io/FastBufferedOutputStream.java] exit write(byte[],int,int) 4");
        }
        System.arraycopy(b, off, buf, count, len);
        count += len;
        // System.err.println("[src/main/java/org/fusesource/jansi/io/FastBufferedOutputStream.java] exit write(byte[],int,int) 3");
    }

    private void flushBuffer() throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/FastBufferedOutputStream.java] enter flushBuffer 1");
        if (count > 0) {
            System.err.println("[src/main/java/org/fusesource/jansi/io/FastBufferedOutputStream.java] enter flushBuffer 2");
            out.write(buf, 0, count);
            count = 0;
            // System.err.println("[src/main/java/org/fusesource/jansi/io/FastBufferedOutputStream.java] exit flushBuffer 2");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/io/FastBufferedOutputStream.java] exit flushBuffer 1");
    }

    @Override
    public void flush() throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/FastBufferedOutputStream.java] enter flush 1");
        flushBuffer();
        out.flush();
        // System.err.println("[src/main/java/org/fusesource/jansi/io/FastBufferedOutputStream.java] exit flush 1");
    }
}
// Total cost: 0.015498
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split
// chunks: [(0, 68)]
// Total instrumented cost: 0.015498, input tokens: 2398, output tokens: 833, cache read tokens: 2394, cache write
// tokens: 606

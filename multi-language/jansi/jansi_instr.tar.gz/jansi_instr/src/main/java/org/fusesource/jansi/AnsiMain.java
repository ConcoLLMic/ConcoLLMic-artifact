/*
 * Copyright (C) 2009-2023 the original author(s).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.fusesource.jansi;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.Properties;

import org.fusesource.jansi.Ansi.Attribute;
import org.fusesource.jansi.internal.CLibrary;
import org.fusesource.jansi.internal.JansiLoader;
import org.fusesource.jansi.internal.Kernel32;
import org.fusesource.jansi.internal.MingwSupport;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.fusesource.jansi.Ansi.ansi;
import static org.fusesource.jansi.internal.Kernel32.GetConsoleScreenBufferInfo;

/**
 * Main class for the library, providing executable jar to diagnose Jansi setup.
 * <p>If no system property is set and output is sent to a terminal (no redirect to a file):
 * <ul>
 * <li>any terminal on any Unix should get <code>RESET_ANSI_AT_CLOSE</code> mode,</li>
 * <li>on Windows, Git-bash or Cygwin terminals should get <code>RESET_ANSI_AT_CLOSE</code> mode also, since they
 * support natively ANSI escape sequences like any Unix terminal,</li>
 * <li>on Windows, cmd.exe, PowerShell or Git-cmd terminals should get <code>WINDOWS</code> mode.</li>
 * </ul>
 * If stdout is redirected to a file (<code>&gt; out.txt</code>), System.out should switch to <code>STRIP_ANSI</code>.
 * Same for stderr redirection (<code>2&gt; err.txt</code>) which should affect System.err mode.
 * <p>The results will vary if you play with <code>jansi.passthrough</code>, <code>jansi.strip</code> or
 * <code>jansi.force</code> system property, or if you redirect output to a file.
 * <p>If you have a specific situation that is not covered, please report precise conditions to reproduce
 * the issue and ideas on how to detect precisely the affected situation.
 * @see AnsiConsole
 */
public class AnsiMain {
    public static void main(String... args) throws Exception {
        System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 1\n".getBytes());
        System.out.println("Jansi " + getJansiVersion());

        System.out.println();

        // info on native library
        System.out.println("library.jansi.path= " + System.getProperty("library.jansi.path", ""));
        System.out.println("library.jansi.version= " + System.getProperty("library.jansi.version", ""));
        boolean loaded = JansiLoader.initialize();
        // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 1\n".getBytes());

        if (loaded) {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 2\n".getBytes());
            System.out.println("Jansi native library loaded from " + JansiLoader.getNativeLibraryPath());
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 2\n".getBytes());
            if (JansiLoader.getNativeLibrarySourceUrl() != null) {
                System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 3\n".getBytes());
                System.out.println("   which was auto-extracted from " + JansiLoader.getNativeLibrarySourceUrl());
                // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 3\n".getBytes());
            }
        } else {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 4\n".getBytes());
            String prev = System.getProperty(AnsiConsole.JANSI_GRACEFUL);
            try {
                System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 5\n".getBytes());
                System.setProperty(AnsiConsole.JANSI_GRACEFUL, "false");
                JansiLoader.initialize();
                // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 5\n".getBytes());
            } catch (Throwable e) {
                System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 6\n".getBytes());
                e.printStackTrace(System.out);
                // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 6\n".getBytes());
            } finally {
                System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 7\n".getBytes());
                if (prev != null) {
                    System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 8\n".getBytes());
                    System.setProperty(AnsiConsole.JANSI_GRACEFUL, prev);
                    // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 8\n".getBytes());
                } else {
                    System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 9\n".getBytes());
                    System.clearProperty(AnsiConsole.JANSI_GRACEFUL);
                    // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 9\n".getBytes());
                }
                // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 7\n".getBytes());
            }
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 4\n".getBytes());
        }

        System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 10\n".getBytes());
        System.out.println();

        System.out.println("os.name= " + System.getProperty("os.name") + ", "
                + "os.version= " + System.getProperty("os.version") + ", "
                + "os.arch= " + System.getProperty("os.arch"));
        System.out.println("file.encoding= " + System.getProperty("file.encoding"));
        System.out.println("sun.stdout.encoding= " + System.getProperty("sun.stdout.encoding") + ", "
                + "sun.stderr.encoding= " + System.getProperty("sun.stderr.encoding"));
        System.out.println("stdout.encoding= " + System.getProperty("stdout.encoding") + ", " + "stderr.encoding= "
                + System.getProperty("stderr.encoding"));
        System.out.println("java.version= " + System.getProperty("java.version") + ", "
                + "java.vendor= " + System.getProperty("java.vendor") + ","
                + " java.home= " + System.getProperty("java.home"));
        System.out.println("Console: " + System.console());

        System.out.println();

        System.out.println(AnsiConsole.JANSI_GRACEFUL + "= " + System.getProperty(AnsiConsole.JANSI_GRACEFUL, ""));
        System.out.println(AnsiConsole.JANSI_MODE + "= " + System.getProperty(AnsiConsole.JANSI_MODE, ""));
        System.out.println(AnsiConsole.JANSI_OUT_MODE + "= " + System.getProperty(AnsiConsole.JANSI_OUT_MODE, ""));
        System.out.println(AnsiConsole.JANSI_ERR_MODE + "= " + System.getProperty(AnsiConsole.JANSI_ERR_MODE, ""));
        System.out.println(AnsiConsole.JANSI_COLORS + "= " + System.getProperty(AnsiConsole.JANSI_COLORS, ""));
        System.out.println(AnsiConsole.JANSI_OUT_COLORS + "= " + System.getProperty(AnsiConsole.JANSI_OUT_COLORS, ""));
        System.out.println(AnsiConsole.JANSI_ERR_COLORS + "= " + System.getProperty(AnsiConsole.JANSI_ERR_COLORS, ""));
        System.out.println(
                AnsiConsole.JANSI_PASSTHROUGH + "= " + AnsiConsole.getBoolean(AnsiConsole.JANSI_PASSTHROUGH));
        System.out.println(AnsiConsole.JANSI_STRIP + "= " + AnsiConsole.getBoolean(AnsiConsole.JANSI_STRIP));
        System.out.println(AnsiConsole.JANSI_FORCE + "= " + AnsiConsole.getBoolean(AnsiConsole.JANSI_FORCE));
        System.out.println(AnsiConsole.JANSI_NORESET + "= " + AnsiConsole.getBoolean(AnsiConsole.JANSI_NORESET));
        System.out.println(Ansi.DISABLE + "= " + AnsiConsole.getBoolean(Ansi.DISABLE));

        System.out.println();

        System.out.println("IS_WINDOWS: " + AnsiConsole.IS_WINDOWS);
        // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 10\n".getBytes());

        if (AnsiConsole.IS_WINDOWS) {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 11\n".getBytes());
            System.out.println("IS_CONEMU: " + AnsiConsole.IS_CONEMU);
            System.out.println("IS_CYGWIN: " + AnsiConsole.IS_CYGWIN);
            System.out.println("IS_MSYSTEM: " + AnsiConsole.IS_MSYSTEM);
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 11\n".getBytes());
        }

        System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 12\n".getBytes());
        System.out.println();

        diagnoseTty(false); // System.out
        diagnoseTty(true); // System.err

        AnsiConsole.systemInstall();

        System.out.println();

        System.out.println("Resulting Jansi modes for stout/stderr streams:");
        System.out.println("  - System.out: " + AnsiConsole.out().toString());
        System.out.println("  - System.err: " + AnsiConsole.err().toString());
        System.out.println("Processor types description:");
        // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 12\n".getBytes());

        for (AnsiType type : AnsiType.values()) {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 13\n".getBytes());
            System.out.println("  - " + type + ": " + type.getDescription());
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 13\n".getBytes());
        }

        System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 14\n".getBytes());
        System.out.println("Colors support description:");
        // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 14\n".getBytes());

        for (AnsiColors colors : AnsiColors.values()) {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 15\n".getBytes());
            System.out.println("  - " + colors + ": " + colors.getDescription());
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 15\n".getBytes());
        }

        System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 16\n".getBytes());
        System.out.println("Modes description:");
        // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 16\n".getBytes());

        for (AnsiMode mode : AnsiMode.values()) {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 17\n".getBytes());
            System.out.println("  - " + mode + ": " + mode.getDescription());
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 17\n".getBytes());
        }

        try {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 18\n".getBytes());
            System.out.println();

            testAnsi(false);
            testAnsi(true);
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 18\n".getBytes());

            if (args.length == 0) {
                System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 19\n".getBytes());
                printJansiLogoDemo();
                return;
                // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 19\n".getBytes());
            }

            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 20\n".getBytes());
            System.out.println();
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 20\n".getBytes());

            if (args.length == 1) {
                System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 21\n".getBytes());
                File f = new File(args[0]);
                // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 21\n".getBytes());
                if (f.exists()) {
                    System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 22\n".getBytes());
                    // write file content
                    System.out.println(
                            ansi().bold().a("\"" + args[0] + "\" content:").reset());
                    writeFileContent(f);
                    return;
                    // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 22\n".getBytes());
                }
            }

            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 23\n".getBytes());
            // write args without Jansi then with Jansi AnsiConsole
            System.out.println(ansi().bold().a("original args:").reset());
            int i = 1;
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 23\n".getBytes());

            for (String arg : args) {
                System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 24\n".getBytes());
                AnsiConsole.system_out.print(i++ + ": ");
                AnsiConsole.system_out.println(arg);
                // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 24\n".getBytes());
            }

            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 25\n".getBytes());
            System.out.println(ansi().bold().a("Jansi filtered args:").reset());
            i = 1;
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 25\n".getBytes());

            for (String arg : args) {
                System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 26\n".getBytes());
                System.out.print(i++ + ": ");
                System.out.println(arg);
                // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 26\n".getBytes());
            }
        } finally {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter main 27\n".getBytes());
            AnsiConsole.systemUninstall();
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit main 27\n".getBytes());
        }
    }

    private static String getJansiVersion() throws Exception {
        System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter getJansiVersion 1\n".getBytes());
        Package p = AnsiMain.class.getPackage();
        return (p == null) ? null : p.getImplementationVersion();
        // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit getJansiVersion 1\n".getBytes());
    }

    private static void diagnoseTty(boolean stderr) throws Exception {
        System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter diagnoseTty 1\n".getBytes());
        int isatty;
        int width;
        // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit diagnoseTty 1\n".getBytes());

        if (AnsiConsole.IS_WINDOWS) {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter diagnoseTty 2\n".getBytes());
            long console = Kernel32.GetStdHandle(stderr ? Kernel32.STD_ERROR_HANDLE : Kernel32.STD_OUTPUT_HANDLE);
            int[] mode = new int[1];
            isatty = Kernel32.GetConsoleMode(console, mode);
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit diagnoseTty 2\n".getBytes());

            if ((AnsiConsole.IS_CONEMU || AnsiConsole.IS_CYGWIN || AnsiConsole.IS_MSYSTEM) && isatty == 0) {
                System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter diagnoseTty 3\n".getBytes());
                MingwSupport mingw = new MingwSupport();
                String name = mingw.getConsoleName(!stderr);
                // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit diagnoseTty 3\n".getBytes());

                if (name != null && !name.isEmpty()) {
                    System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter diagnoseTty 4\n".getBytes());
                    isatty = 1;
                    width = mingw.getTerminalWidth(name);
                    // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit diagnoseTty 4\n".getBytes());
                } else {
                    System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter diagnoseTty 5\n".getBytes());
                    isatty = 0;
                    width = 0;
                    // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit diagnoseTty 5\n".getBytes());
                }
            } else {
                System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter diagnoseTty 6\n".getBytes());
                Kernel32.CONSOLE_SCREEN_BUFFER_INFO info = new Kernel32.CONSOLE_SCREEN_BUFFER_INFO();
                GetConsoleScreenBufferInfo(console, info);
                width = info.windowWidth();
                // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit diagnoseTty 6\n".getBytes());
            }
        } else {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter diagnoseTty 7\n".getBytes());
            int fd = stderr ? CLibrary.STDERR_FILENO : CLibrary.STDOUT_FILENO;
            isatty = CLibrary.LOADED ? CLibrary.isatty(fd) : 0;
            CLibrary.WinSize ws = new CLibrary.WinSize();
            CLibrary.ioctl(fd, CLibrary.TIOCGWINSZ, ws);
            width = ws.ws_col;
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit diagnoseTty 7\n".getBytes());
        }

        System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter diagnoseTty 8\n".getBytes());
        System.out.println("isatty(STD" + (stderr ? "ERR" : "OUT") + "_FILENO): " + isatty + ", System."
                + (stderr ? "err" : "out") + " " + ((isatty == 0) ? "is *NOT*" : "is") + " a terminal");
        System.out.println("width(STD" + (stderr ? "ERR" : "OUT") + "_FILENO): " + width);
        // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit diagnoseTty 8\n".getBytes());
    }

    private static void testAnsi(boolean stderr) throws Exception {
        System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter testAnsi 1\n".getBytes());
        @SuppressWarnings("resource")
        PrintStream s = stderr ? System.err : System.out;
        s.print("test on System." + (stderr ? "err" : "out") + ":");
        // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit testAnsi 1\n".getBytes());

        for (Ansi.Color c : Ansi.Color.values()) {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter testAnsi 2\n".getBytes());
            s.print(" " + ansi().fg(c) + c + ansi().reset());
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit testAnsi 2\n".getBytes());
        }

        System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter testAnsi 3\n".getBytes());
        s.println();
        s.print("            bright:");
        // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit testAnsi 3\n".getBytes());

        for (Ansi.Color c : Ansi.Color.values()) {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter testAnsi 4\n".getBytes());
            s.print(" " + ansi().fgBright(c) + c + ansi().reset());
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit testAnsi 4\n".getBytes());
        }

        System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter testAnsi 5\n".getBytes());
        s.println();
        s.print("              bold:");
        // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit testAnsi 5\n".getBytes());

        for (Ansi.Color c : Ansi.Color.values()) {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter testAnsi 6\n".getBytes());
            s.print(" " + ansi().bold().fg(c) + c + ansi().reset());
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit testAnsi 6\n".getBytes());
        }

        System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter testAnsi 7\n".getBytes());
        s.println();
        s.print("             faint:");
        // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit testAnsi 7\n".getBytes());

        for (Ansi.Color c : Ansi.Color.values()) {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter testAnsi 8\n".getBytes());
            s.print(" " + ansi().a(Attribute.INTENSITY_FAINT).fg(c) + c + ansi().reset());
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit testAnsi 8\n".getBytes());
        }

        System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter testAnsi 9\n".getBytes());
        s.println();
        s.print("        bold+faint:");
        // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit testAnsi 9\n".getBytes());

        for (Ansi.Color c : Ansi.Color.values()) {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter testAnsi 10\n".getBytes());
            s.print(" " + ansi().bold().a(Attribute.INTENSITY_FAINT).fg(c) + c + ansi().reset());
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit testAnsi 10\n".getBytes());
        }

        System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter testAnsi 11\n".getBytes());
        s.println();
        Ansi ansi = ansi();
        ansi.a("        256 colors: ");
        // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit testAnsi 11\n".getBytes());

        for (int i = 0; i < 6 * 6 * 6; i++) {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter testAnsi 12\n".getBytes());
            if (i > 0 && i % 36 == 0) {
                System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter testAnsi 13\n".getBytes());
                ansi.reset();
                ansi.newline();
                ansi.a("                    ");
                // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit testAnsi 13\n".getBytes());
            } else if (i > 0 && i % 6 == 0) {
                System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter testAnsi 14\n".getBytes());
                ansi.reset();
                ansi.a("  ");
                // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit testAnsi 14\n".getBytes());
            }
            int a0 = i % 6;
            int a1 = (i / 6) % 6;
            int a2 = i / 36;
            ansi.bg(16 + a0 + a2 * 6 + a1 * 36).a(' ');
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit testAnsi 12\n".getBytes());
        }

        System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter testAnsi 15\n".getBytes());
        ansi.reset();
        s.println(ansi);
        ansi = ansi();
        ansi.a("         truecolor: ");
        // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit testAnsi 15\n".getBytes());

        for (int i = 0; i < 256; i++) {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter testAnsi 16\n".getBytes());
            if (i > 0 && i % 48 == 0) {
                System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter testAnsi 17\n".getBytes());
                ansi.reset();
                ansi.newline();
                ansi.a("                    ");
                // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit testAnsi 17\n".getBytes());
            }
            int r = 255 - i;
            int g = i * 2 > 255 ? 255 - 2 * i : 2 * i;
            int b = i;
            ansi.bgRgb(r, g, b).fgRgb(255 - r, 255 - g, 255 - b).a(i % 2 == 0 ? '/' : '\\');
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit testAnsi 16\n".getBytes());
        }

        System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter testAnsi 18\n".getBytes());
        ansi.reset();
        s.println(ansi);
        // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit testAnsi 18\n".getBytes());
    }

    private static String getPomPropertiesVersion(String path) throws IOException {
        System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter getPomPropertiesVersion 1\n".getBytes());
        InputStream in = AnsiMain.class.getResourceAsStream("/META-INF/maven/" + path + "/pom.properties");
        // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit getPomPropertiesVersion 1\n".getBytes());

        if (in == null) {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter getPomPropertiesVersion 2\n".getBytes());
            return null;
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit getPomPropertiesVersion 2\n".getBytes());
        }

        try {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter getPomPropertiesVersion 3\n".getBytes());
            Properties p = new Properties();
            p.load(in);
            return p.getProperty("version");
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit getPomPropertiesVersion 3\n".getBytes());
        } finally {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter getPomPropertiesVersion 4\n".getBytes());
            closeQuietly(in);
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit getPomPropertiesVersion 4\n".getBytes());
        }
    }

    private static void printJansiLogoDemo() throws IOException {
        System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter printJansiLogoDemo 1\n".getBytes());
        BufferedReader in =
                new BufferedReader(new InputStreamReader(AnsiMain.class.getResourceAsStream("jansi.txt"), UTF_8));
        try {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter printJansiLogoDemo 2\n".getBytes());
            String l;
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit printJansiLogoDemo 2\n".getBytes());
            while ((l = in.readLine()) != null) {
                System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter printJansiLogoDemo 3\n".getBytes());
                System.out.println(l);
                // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit printJansiLogoDemo 3\n".getBytes());
            }
        } finally {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter printJansiLogoDemo 4\n".getBytes());
            closeQuietly(in);
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit printJansiLogoDemo 4\n".getBytes());
        }
        // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit printJansiLogoDemo 1\n".getBytes());
    }

    private static void writeFileContent(File f) throws IOException {
        System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter writeFileContent 1\n".getBytes());
        InputStream in = new FileInputStream(f);
        try {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter writeFileContent 2\n".getBytes());
            byte[] buf = new byte[1024];
            int l = 0;
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit writeFileContent 2\n".getBytes());
            while ((l = in.read(buf)) >= 0) {
                System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter writeFileContent 3\n".getBytes());
                System.out.write(buf, 0, l);
                // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit writeFileContent 3\n".getBytes());
            }
        } finally {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter writeFileContent 4\n".getBytes());
            closeQuietly(in);
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit writeFileContent 4\n".getBytes());
        }
        // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit writeFileContent 1\n".getBytes());
    }

    private static void closeQuietly(Closeable c) throws IOException {
        System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter closeQuietly 1\n".getBytes());
        try {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter closeQuietly 2\n".getBytes());
            c.close();
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit closeQuietly 2\n".getBytes());
        } catch (IOException ioe) {
            System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] enter closeQuietly 3\n".getBytes());
            ioe.printStackTrace(System.err);
            // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit closeQuietly 3\n".getBytes());
        }
        // System.err.write("[src/main/java/org/fusesource/jansi/AnsiMain.java] exit closeQuietly 1\n".getBytes());
    }
}
// Total cost: 0.138653
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split
// chunks: [(0, 344)]
// Total instrumented cost: 0.138653, input tokens: 4, output tokens: 7476, cache read tokens: 0, cache write tokens:
// 7067

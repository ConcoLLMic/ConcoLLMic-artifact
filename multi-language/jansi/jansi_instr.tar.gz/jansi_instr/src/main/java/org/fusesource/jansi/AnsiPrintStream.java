/*
 * Copyright (C) 2009-2023 the original author(s).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.fusesource.jansi;

import java.io.IOException;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

import org.fusesource.jansi.io.AnsiOutputStream;

/**
 * Simple PrintStream holding an AnsiOutputStream.
 * This allows changing the mode in which the underlying AnsiOutputStream operates.
 */
public class AnsiPrintStream extends PrintStream {

    public AnsiPrintStream(AnsiOutputStream out, boolean autoFlush) {
        super(out, autoFlush);
    }

    public AnsiPrintStream(AnsiOutputStream out, boolean autoFlush, String encoding)
            throws UnsupportedEncodingException {
        super(out, autoFlush, encoding);
    }

    protected AnsiOutputStream getOut() {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] enter getOut 1");
        return (AnsiOutputStream) out;
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] exit getOut 1");
    }

    public AnsiType getType() {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] enter getType 1");
        return getOut().getType();
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] exit getType 1");
    }

    public AnsiColors getColors() {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] enter getColors 1");
        return getOut().getColors();
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] exit getColors 1");
    }

    public AnsiMode getMode() {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] enter getMode 1");
        return getOut().getMode();
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] exit getMode 1");
    }

    public void setMode(AnsiMode ansiMode) {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] enter setMode 1");
        getOut().setMode(ansiMode);
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] exit setMode 1");
    }

    public boolean isResetAtUninstall() {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] enter isResetAtUninstall 1");
        return getOut().isResetAtUninstall();
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] exit isResetAtUninstall 1");
    }

    public void setResetAtUninstall(boolean resetAtClose) {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] enter setResetAtUninstall 1");
        getOut().setResetAtUninstall(resetAtClose);
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] exit setResetAtUninstall 1");
    }

    /**
     * Returns the width of the terminal associated with this stream or 0.
     * @since 2.2
     */
    public int getTerminalWidth() {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] enter getTerminalWidth 1");
        return getOut().getTerminalWidth();
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] exit getTerminalWidth 1");
    }

    public void install() throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] enter install 1");
        getOut().install();
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] exit install 1");
    }

    public void uninstall() throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] enter uninstall 1");
        // If the system output stream has been closed, out should be null, so avoid a NPE
        AnsiOutputStream out = getOut();
        if (out != null) {
            System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] enter uninstall 2");
            out.uninstall();
            // System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] exit uninstall 2");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] exit uninstall 1");
    }

    @Override
    public String toString() {
        System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] enter toString 1");
        return "AnsiPrintStream{"
                + "type=" + getType()
                + ", colors=" + getColors()
                + ", mode=" + getMode()
                + ", resetAtUninstall=" + isResetAtUninstall()
                + "}";
        // System.err.println("[src/main/java/org/fusesource/jansi/AnsiPrintStream.java] exit toString 1");
    }
}
// Total cost: 0.030811
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split
// chunks: [(0, 96)]
// Total instrumented cost: 0.030811, input tokens: 4, output tokens: 1241, cache read tokens: 0, cache write tokens:
// 3249

/*
 * Copyright (C) 2009-2023 the original author(s).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.fusesource.jansi.io;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * ANSI processor providing <code>process*</code> corresponding to ANSI escape
 * codes.
 * This class methods implementations are empty: subclasses should actually
 * perform the
 * ANSI escape behaviors by implementing active code in <code>process*</code>
 * methods.
 *
 * <p>
 * For more information about ANSI escape codes, see
 * <a href="http://en.wikipedia.org/wiki/ANSI_escape_code">Wikipedia article</a>
 *
 * @since 1.19
 */
@SuppressWarnings("unused")
public class AnsiProcessor {
    protected final OutputStream os;

    public AnsiProcessor(OutputStream os) {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter AnsiProcessor 1");
        this.os = os;
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  AnsiProcessor 1");
    }

    /**
     * Helper for processEscapeCommand() to iterate over integer options
     *
     * @param optionsIterator the underlying iterator
     * @throws IOException if no more non-null values left
     */
    protected int getNextOptionInt(Iterator<Object> optionsIterator) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter getNextOptionInt 1");
        for (; ; ) {
            System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter getNextOptionInt 2");
            if (!optionsIterator.hasNext()) throw new IllegalArgumentException();
            Object arg = optionsIterator.next();
            if (arg != null) return (Integer) arg;
            // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  getNextOptionInt 2");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  getNextOptionInt 1");
    }

    /**
     * @return true if the escape command was processed.
     */
    protected boolean processEscapeCommand(ArrayList<Object> options, int command) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 1");
        try {
            System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 2");
            switch (command) {
                case 'A':
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 3");
                    processCursorUp(optionInt(options, 0, 1));
                    return true;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 3");
                case 'B':
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 4");
                    processCursorDown(optionInt(options, 0, 1));
                    return true;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 4");
                case 'C':
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 5");
                    processCursorRight(optionInt(options, 0, 1));
                    return true;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 5");
                case 'D':
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 6");
                    processCursorLeft(optionInt(options, 0, 1));
                    return true;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 6");
                case 'E':
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 7");
                    processCursorDownLine(optionInt(options, 0, 1));
                    return true;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 7");
                case 'F':
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 8");
                    processCursorUpLine(optionInt(options, 0, 1));
                    return true;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 8");
                case 'G':
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 9");
                    processCursorToColumn(optionInt(options, 0));
                    return true;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 9");
                case 'H':
                case 'f':
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 10");
                    processCursorTo(optionInt(options, 0, 1), optionInt(options, 1, 1));
                    return true;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 10");
                case 'J':
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 11");
                    processEraseScreen(optionInt(options, 0, 0));
                    return true;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 11");
                case 'K':
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 12");
                    processEraseLine(optionInt(options, 0, 0));
                    return true;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 12");
                case 'L':
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 13");
                    processInsertLine(optionInt(options, 0, 1));
                    return true;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 13");
                case 'M':
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 14");
                    processDeleteLine(optionInt(options, 0, 1));
                    return true;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 14");
                case 'S':
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 15");
                    processScrollUp(optionInt(options, 0, 1));
                    return true;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 15");
                case 'T':
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 16");
                    processScrollDown(optionInt(options, 0, 1));
                    return true;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 16");
                case 'm':
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 17");
                    // Validate all options are ints...
                    for (Object next : options) {
                        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 18");
                        if (next != null && next.getClass() != Integer.class) {
                            System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 19");
                            throw new IllegalArgumentException();
                            // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 19");
                        }
                        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 18");
                    }

                    int count = 0;
                    Iterator<Object> optionsIterator = options.iterator();
                    while (optionsIterator.hasNext()) {
                        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 20");
                        Object next = optionsIterator.next();
                        if (next != null) {
                            System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 21");
                            count++;
                            int value = (Integer) next;
                            if (30 <= value && value <= 37) {
                                System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 22");
                                processSetForegroundColor(value - 30);
                                // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 22");
                            } else if (40 <= value && value <= 47) {
                                System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 23");
                                processSetBackgroundColor(value - 40);
                                // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 23");
                            } else if (90 <= value && value <= 97) {
                                System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 24");
                                processSetForegroundColor(value - 90, true);
                                // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 24");
                            } else if (100 <= value && value <= 107) {
                                System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 25");
                                processSetBackgroundColor(value - 100, true);
                                // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 25");
                            } else if (value == 38 || value == 48) {
                                System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 26");
                                if (!optionsIterator.hasNext()) {
                                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 27");
                                    continue;
                                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 27");
                                }
                                // extended color like `esc[38;5;<index>m` or `esc[38;2;<r>;<g>;<b>m`
                                int arg2or5 = getNextOptionInt(optionsIterator);
                                if (arg2or5 == 2) {
                                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 28");
                                    // 24 bit color style like `esc[38;2;<r>;<g>;<b>m`
                                    int r = getNextOptionInt(optionsIterator);
                                    int g = getNextOptionInt(optionsIterator);
                                    int b = getNextOptionInt(optionsIterator);
                                    if (r >= 0 && r <= 255 && g >= 0 && g <= 255 && b >= 0 && b <= 255) {
                                        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 29");
                                        if (value == 38) processSetForegroundColorExt(r, g, b);
                                        else processSetBackgroundColorExt(r, g, b);
                                        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 29");
                                    } else {
                                        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 30");
                                        throw new IllegalArgumentException();
                                        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 30");
                                    }
                                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 28");
                                } else if (arg2or5 == 5) {
                                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 31");
                                    // 256 color style like `esc[38;5;<index>m`
                                    int paletteIndex = getNextOptionInt(optionsIterator);
                                    if (paletteIndex >= 0 && paletteIndex <= 255) {
                                        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 32");
                                        if (value == 38) processSetForegroundColorExt(paletteIndex);
                                        else processSetBackgroundColorExt(paletteIndex);
                                        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 32");
                                    } else {
                                        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 33");
                                        throw new IllegalArgumentException();
                                        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 33");
                                    }
                                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 31");
                                } else {
                                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 34");
                                    throw new IllegalArgumentException();
                                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 34");
                                }
                                // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 26");
                            } else {
                                System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 35");
                                switch (value) {
                                    case 39:
                                        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 36");
                                        processDefaultTextColor();
                                        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 36");
                                        break;
                                    case 49:
                                        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 37");
                                        processDefaultBackgroundColor();
                                        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 37");
                                        break;
                                    case 0:
                                        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 38");
                                        processAttributeReset();
                                        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 38");
                                        break;
                                    default:
                                        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 39");
                                        processSetAttribute(value);
                                        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 39");
                                }
                                // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 35");
                            }
                            // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 21");
                        }
                        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 20");
                    }
                    if (count == 0) {
                        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 40");
                        processAttributeReset();
                        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 40");
                    }
                    return true;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 17");
                case 's':
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 41");
                    processSaveCursorPosition();
                    return true;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 41");
                case 'u':
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 42");
                    processRestoreCursorPosition();
                    return true;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 42");

                default:
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 43");
                    if ('a' <= command && command <= 'z') {
                        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 44");
                        processUnknownExtension(options, command);
                        return true;
                        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 44");
                    }
                    if ('A' <= command && command <= 'Z') {
                        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processEscapeCommand 45");
                        processUnknownExtension(options, command);
                        return true;
                        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 45");
                    }
                    return false;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 43");
            }
            // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 2");
        } catch (IllegalArgumentException ignore) {
            System.err.println("");
            // System.err.println("");
        }
        return false;
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processEscapeCommand 1");
    }

    /**
     * @return true if the operating system command was processed.
     */
    protected boolean processOperatingSystemCommand(ArrayList<Object> options) {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processOperatingSystemCommand 1");
        int command = optionInt(options, 0);
        String label = (String) options.get(1);
        // for command > 2 label could be composed (i.e. contain ';'), but we'll leave
        // it to processUnknownOperatingSystemCommand implementations to handle that
        try {
            System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processOperatingSystemCommand 2");
            switch (command) {
                case 0:
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processOperatingSystemCommand 3");
                    processChangeIconNameAndWindowTitle(label);
                    return true;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processOperatingSystemCommand 3");
                case 1:
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processOperatingSystemCommand 4");
                    processChangeIconName(label);
                    return true;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processOperatingSystemCommand 4");
                case 2:
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processOperatingSystemCommand 5");
                    processChangeWindowTitle(label);
                    return true;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processOperatingSystemCommand 5");

                default:
                    System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processOperatingSystemCommand 6");
                    // not exactly unknown, but not supported through dedicated process methods:
                    processUnknownOperatingSystemCommand(command, label);
                    return true;
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processOperatingSystemCommand 6");
            }
            // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processOperatingSystemCommand 2");
        } catch (IllegalArgumentException ignore) {
            System.err.println("");
            // System.err.println("");
        }
        return false;
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processOperatingSystemCommand 1");
    }

    /**
     * Process character set sequence.
     *
     * @param options options
     * @return true if the charcter set select command was processed.
     */
    protected boolean processCharsetSelect(ArrayList<Object> options) {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processCharsetSelect 1");
        int set = optionInt(options, 0);
        char seq = (Character) options.get(1);
        processCharsetSelect(set, seq);
        return true;
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processCharsetSelect 1");
    }

    private int optionInt(ArrayList<Object> options, int index) {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter optionInt 1");
        if (options.size() <= index) throw new IllegalArgumentException();
        Object value = options.get(index);
        if (value == null) throw new IllegalArgumentException();
        if (!value.getClass().equals(Integer.class)) throw new IllegalArgumentException();
        return (Integer) value;
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  optionInt 1");
    }

    private int optionInt(ArrayList<Object> options, int index, int defaultValue) {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter optionInt 2");
        if (options.size() > index) {
            System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter optionInt 3");
            Object value = options.get(index);
            if (value == null) {
                System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter optionInt 4");
                return defaultValue;
                // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  optionInt 4");
            }
            return (Integer) value;
            // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  optionInt 3");
        }
        return defaultValue;
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  optionInt 2");
    }

    /**
     * Process <code>CSI u</code> ANSI code, corresponding to
     * <code>RCP – Restore Cursor Position</code>
     *
     * @throws IOException IOException
     */
    protected void processRestoreCursorPosition() throws IOException {}

    /**
     * Process <code>CSI s</code> ANSI code, corresponding to
     * <code>SCP – Save Cursor Position</code>
     *
     * @throws IOException IOException
     */
    protected void processSaveCursorPosition() throws IOException {}

    /**
     * Process <code>CSI L</code> ANSI code, corresponding to
     * <code>IL – Insert Line</code>
     *
     * @param optionInt option
     * @throws IOException IOException
     * @since 1.16
     */
    protected void processInsertLine(int optionInt) throws IOException {}

    /**
     * Process <code>CSI M</code> ANSI code, corresponding to
     * <code>DL – Delete Line</code>
     *
     * @param optionInt option
     * @throws IOException IOException
     * @since 1.16
     */
    protected void processDeleteLine(int optionInt) throws IOException {}

    /**
     * Process <code>CSI n T</code> ANSI code, corresponding to
     * <code>SD – Scroll Down</code>
     *
     * @param optionInt option
     * @throws IOException IOException
     */
    protected void processScrollDown(int optionInt) throws IOException {}

    /**
     * Process <code>CSI n U</code> ANSI code, corresponding to
     * <code>SU – Scroll Up</code>
     *
     * @param optionInt option
     * @throws IOException IOException
     */
    protected void processScrollUp(int optionInt) throws IOException {}

    protected static final int ERASE_SCREEN_TO_END = 0;
    protected static final int ERASE_SCREEN_TO_BEGINING = 1;
    protected static final int ERASE_SCREEN = 2;

    /**
     * Process <code>CSI n J</code> ANSI code, corresponding to
     * <code>ED – Erase in Display</code>
     *
     * @param eraseOption eraseOption
     * @throws IOException IOException
     */
    protected void processEraseScreen(int eraseOption) throws IOException {}

    protected static final int ERASE_LINE_TO_END = 0;
    protected static final int ERASE_LINE_TO_BEGINING = 1;
    protected static final int ERASE_LINE = 2;

    /**
     * Process <code>CSI n K</code> ANSI code, corresponding to
     * <code>ED – Erase in Line</code>
     *
     * @param eraseOption eraseOption
     * @throws IOException IOException
     */
    protected void processEraseLine(int eraseOption) throws IOException {}

    protected static final int ATTRIBUTE_INTENSITY_BOLD = 1; // Intensity: Bold
    protected static final int ATTRIBUTE_INTENSITY_FAINT = 2; // Intensity; Faint not widely supported
    protected static final int ATTRIBUTE_ITALIC = 3; // Italic; on not widely supported. Sometimes treated as inverse.
    protected static final int ATTRIBUTE_UNDERLINE = 4; // Underline; Single
    protected static final int ATTRIBUTE_BLINK_SLOW = 5; // Blink; Slow less than 150 per minute
    protected static final int ATTRIBUTE_BLINK_FAST = 6; // Blink; Rapid MS-DOS ANSI.SYS; 150 per minute or more
    protected static final int ATTRIBUTE_NEGATIVE_ON = 7; // Image; Negative inverse or reverse; swap foreground and
    // background
    protected static final int ATTRIBUTE_CONCEAL_ON = 8; // Conceal on
    protected static final int ATTRIBUTE_UNDERLINE_DOUBLE = 21; // Underline; Double not widely supported
    protected static final int ATTRIBUTE_INTENSITY_NORMAL = 22; // Intensity; Normal not bold and not faint
    protected static final int ATTRIBUTE_UNDERLINE_OFF = 24; // Underline; None
    protected static final int ATTRIBUTE_BLINK_OFF = 25; // Blink; off
    protected static final int ATTRIBUTE_NEGATIVE_OFF = 27; // Image; Positive
    protected static final int ATTRIBUTE_CONCEAL_OFF = 28; // Reveal conceal off

    /**
     * process <code>SGR</code> other than <code>0</code> (reset),
     * <code>30-39</code> (foreground),
     * <code>40-49</code> (background), <code>90-97</code> (foreground high
     * intensity) or
     * <code>100-107</code> (background high intensity)
     *
     * @param attribute attribute
     * @throws IOException IOException
     * @see #processAttributeReset()
     * @see #processSetForegroundColor(int)
     * @see #processSetForegroundColor(int, boolean)
     * @see #processSetForegroundColorExt(int)
     * @see #processSetForegroundColorExt(int, int, int)
     * @see #processDefaultTextColor()
     * @see #processDefaultBackgroundColor()
     */
    protected void processSetAttribute(int attribute) throws IOException {}

    protected static final int BLACK = 0;
    protected static final int RED = 1;
    protected static final int GREEN = 2;
    protected static final int YELLOW = 3;
    protected static final int BLUE = 4;
    protected static final int MAGENTA = 5;
    protected static final int CYAN = 6;
    protected static final int WHITE = 7;

    /**
     * process <code>SGR 30-37</code> corresponding to
     * <code>Set text color (foreground)</code>.
     *
     * @param color the text color
     * @throws IOException IOException
     */
    protected void processSetForegroundColor(int color) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processSetForegroundColor 1");
        processSetForegroundColor(color, false);
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processSetForegroundColor 1");
    }

    /**
     * process <code>SGR 30-37</code> or <code>SGR 90-97</code> corresponding to
     * <code>Set text color (foreground)</code> either in normal mode or high
     * intensity.
     *
     * @param color  the text color
     * @param bright is high intensity?
     * @throws IOException IOException
     */
    protected void processSetForegroundColor(int color, boolean bright) throws IOException {}

    /**
     * process <code>SGR 38</code> corresponding to
     * <code>extended set text color (foreground)</code>
     * with a palette of 255 colors.
     *
     * @param paletteIndex the text color in the palette
     * @throws IOException IOException
     */
    protected void processSetForegroundColorExt(int paletteIndex) throws IOException {}

    /**
     * process <code>SGR 38</code> corresponding to
     * <code>extended set text color (foreground)</code>
     * with a 24 bits RGB definition of the color.
     *
     * @param r red
     * @param g green
     * @param b blue
     * @throws IOException IOException
     */
    protected void processSetForegroundColorExt(int r, int g, int b) throws IOException {}

    /**
     * process <code>SGR 40-47</code> corresponding to
     * <code>Set background color</code>.
     *
     * @param color the background color
     * @throws IOException IOException
     */
    protected void processSetBackgroundColor(int color) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processSetBackgroundColor 1");
        processSetBackgroundColor(color, false);
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processSetBackgroundColor 1");
    }

    /**
     * process <code>SGR 40-47</code> or <code>SGR 100-107</code> corresponding to
     * <code>Set background color</code> either in normal mode or high intensity.
     *
     * @param color  the background color
     * @param bright is high intensity?
     * @throws IOException IOException
     */
    protected void processSetBackgroundColor(int color, boolean bright) throws IOException {}

    /**
     * process <code>SGR 48</code> corresponding to
     * <code>extended set background color</code>
     * with a palette of 255 colors.
     *
     * @param paletteIndex the background color in the palette
     * @throws IOException IOException
     */
    protected void processSetBackgroundColorExt(int paletteIndex) throws IOException {}

    /**
     * process <code>SGR 48</code> corresponding to
     * <code>extended set background color</code>
     * with a 24 bits RGB definition of the color.
     *
     * @param r red
     * @param g green
     * @param b blue
     * @throws IOException IOException
     */
    protected void processSetBackgroundColorExt(int r, int g, int b) throws IOException {}

    /**
     * process <code>SGR 39</code> corresponding to
     * <code>Default text color (foreground)</code>
     *
     * @throws IOException IOException
     */
    protected void processDefaultTextColor() throws IOException {}

    /**
     * process <code>SGR 49</code> corresponding to
     * <code>Default background color</code>
     *
     * @throws IOException IOException
     */
    protected void processDefaultBackgroundColor() throws IOException {}

    /**
     * process <code>SGR 0</code> corresponding to <code>Reset / Normal</code>
     *
     * @throws IOException IOException
     */
    protected void processAttributeReset() throws IOException {}

    /**
     * process <code>CSI n ; m H</code> corresponding to
     * <code>CUP – Cursor Position</code> or
     * <code>CSI n ; m f</code> corresponding to
     * <code>HVP – Horizontal and Vertical Position</code>
     *
     * @param row row
     * @param col col
     * @throws IOException IOException
     */
    protected void processCursorTo(int row, int col) throws IOException {}

    /**
     * process <code>CSI n G</code> corresponding to
     * <code>CHA – Cursor Horizontal Absolute</code>
     *
     * @param x the column
     * @throws IOException IOException
     */
    protected void processCursorToColumn(int x) throws IOException {}

    /**
     * process <code>CSI n F</code> corresponding to
     * <code>CPL – Cursor Previous Line</code>
     *
     * @param count line count
     * @throws IOException IOException
     */
    protected void processCursorUpLine(int count) throws IOException {}

    /**
     * process <code>CSI n E</code> corresponding to
     * <code>CNL – Cursor Next Line</code>
     *
     * @param count line count
     * @throws IOException IOException
     */
    protected void processCursorDownLine(int count) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processCursorDownLine 1");
        // Poor mans impl..
        for (int i = 0; i < count; i++) {
            System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processCursorDownLine 2");
            os.write('\n');
            // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processCursorDownLine 2");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processCursorDownLine 1");
    }

    /**
     * process <code>CSI n D</code> corresponding to <code>CUB – Cursor Back</code>
     *
     * @param count count
     * @throws IOException IOException
     */
    protected void processCursorLeft(int count) throws IOException {}

    /**
     * process <code>CSI n C</code> corresponding to
     * <code>CUF – Cursor Forward</code>
     *
     * @param count count
     * @throws IOException IOException
     */
    protected void processCursorRight(int count) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processCursorRight 1");
        // Poor mans impl..
        for (int i = 0; i < count; i++) {
            System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processCursorRight 2");
            os.write(' ');
            // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processCursorRight 2");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processCursorRight 1");
    }

    /**
     * process <code>CSI n B</code> corresponding to <code>CUD – Cursor Down</code>
     *
     * @param count count
     * @throws IOException IOException
     */
    protected void processCursorDown(int count) throws IOException {}

    /**
     * process <code>CSI n A</code> corresponding to <code>CUU – Cursor Up</code>
     *
     * @param count count
     * @throws IOException IOException
     */
    protected void processCursorUp(int count) throws IOException {}

    /**
     * Process Unknown Extension
     *
     * @param options options
     * @param command command
     */
    protected void processUnknownExtension(ArrayList<Object> options, int command) {}

    /**
     * process <code>OSC 0;text BEL</code> corresponding to
     * <code>Change Window and Icon label</code>
     *
     * @param label window title name
     */
    protected void processChangeIconNameAndWindowTitle(String label) {
        System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] enter processChangeIconNameAndWindowTitle 1");
        processChangeIconName(label);
        processChangeWindowTitle(label);
        // System.err.println("[src/main/java/org/fusesource/jansi/io/AnsiProcessor.java] exit  processChangeIconNameAndWindowTitle 1");
    }

    /**
     * process <code>OSC 1;text BEL</code> corresponding to
     * <code>Change Icon label</code>
     *
     * @param label icon label
     */
    protected void processChangeIconName(String label) {}

    /**
     * process <code>OSC 2;text BEL</code> corresponding to
     * <code>Change Window title</code>
     *
     * @param label window title text
     */
    protected void processChangeWindowTitle(String label) {}

    /**
     * Process unknown <code>OSC</code> command.
     *
     * @param command command
     * @param param   param
     */
    protected void processUnknownOperatingSystemCommand(int command, String param) {}

    protected void processCharsetSelect(int set, char seq) {}
}
// Total cost: 0.150340
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read
// tokens: 0, cache write tokens: 0, split
// chunks: [(0, 559)]
// Total instrumented cost: 0.150340, input tokens: 2398, output tokens: 8462,
// cache read tokens: 2394, cache write
// tokens: 6048

/*
 * Copyright (C) 2009-2023 the original author(s).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.fusesource.jansi.internal;

/*--------------------------------------------------------------------------
 *  Copyright 2007 Taro L. Saito
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *--------------------------------------------------------------------------*/

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import org.fusesource.jansi.AnsiConsole;

/**
 * Set the system properties, org.jansi.lib.path, org.jansi.lib.name,
 * appropriately so that jansi can find *.dll, *.jnilib and
 * *.so files, according to the current OS (win, linux, mac).
 * <p>
 * The library files are automatically extracted from this project's package
 * (JAR).
 * <p>
 * usage: call {@link #initialize()} before using Jansi.
 */
public class JansiLoader {

    private static boolean loaded = false;
    private static String nativeLibraryPath;
    private static String nativeLibrarySourceUrl;

    /**
     * Loads Jansi native library.
     *
     * @return True if jansi native library is successfully loaded; false
     * otherwise.
     */
    public static synchronized boolean initialize() {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter initialize 1");
        // only cleanup before the first extract
        if (!loaded) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter initialize 2");
            Thread cleanup = new Thread(JansiLoader::cleanup, "cleanup");
            cleanup.setPriority(Thread.MIN_PRIORITY);
            cleanup.setDaemon(true);
            cleanup.start();
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit initialize 2");
        }
        try {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter initialize 3");
            loadJansiNativeLibrary();
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit initialize 3");
        } catch (Exception e) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter initialize 4");
            if (!Boolean.parseBoolean(System.getProperty(AnsiConsole.JANSI_GRACEFUL, "true"))) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter initialize 5");
                throw new RuntimeException(
                        "Unable to load jansi native library. You may want set the `jansi.graceful` system property to true to be able to use Jansi on your platform",
                        e);
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit initialize 5");
            }
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit initialize 4");
        }
        return loaded;
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit initialize 1");
    }

    public static String getNativeLibraryPath() {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter getNativeLibraryPath 1");
        return nativeLibraryPath;
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit getNativeLibraryPath 1");
    }

    public static String getNativeLibrarySourceUrl() {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter getNativeLibrarySourceUrl 1");
        return nativeLibrarySourceUrl;
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit getNativeLibrarySourceUrl 1");
    }

    private static File getTempDir() {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter getTempDir 1");
        return new File(System.getProperty("jansi.tmpdir", System.getProperty("java.io.tmpdir")));
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit getTempDir 1");
    }

    /**
     * Deleted old native libraries e.g. on Windows the DLL file is not removed
     * on VM-Exit (bug #80)
     */
    static void cleanup() {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter cleanup 1");
        String tempFolder = getTempDir().getAbsolutePath();
        File dir = new File(tempFolder);

        File[] nativeLibFiles = dir.listFiles(new FilenameFilter() {
            private final String searchPattern = "jansi-" + getVersion();

            public boolean accept(File dir, String name) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter accept 1");
                return name.startsWith(searchPattern) && !name.endsWith(".lck");
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit accept 1");
            }
        });
        if (nativeLibFiles != null) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter cleanup 2");
            for (File nativeLibFile : nativeLibFiles) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter cleanup 3");
                File lckFile = new File(nativeLibFile.getAbsolutePath() + ".lck");
                if (!lckFile.exists()) {
                    System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter cleanup 4");
                    try {
                        System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter cleanup 5");
                        nativeLibFile.delete();
                        // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit cleanup 5");
                    } catch (SecurityException e) {
                        System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter cleanup 6");
                        System.err.println("Failed to delete old native lib" + e.getMessage());
                        // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit cleanup 6");
                    }
                    // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit cleanup 4");
                }
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit cleanup 3");
            }
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit cleanup 2");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit cleanup 1");
    }

    private static int readNBytes(InputStream in, byte[] b) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter readNBytes 1");
        int n = 0;
        int len = b.length;
        while (n < len) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter readNBytes 2");
            int count = in.read(b, n, len - n);
            if (count <= 0) break;
            n += count;
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit readNBytes 2");
        }
        return n;
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit readNBytes 1");
    }

    private static String contentsEquals(InputStream in1, InputStream in2) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter contentsEquals 1");
        byte[] buffer1 = new byte[8192];
        byte[] buffer2 = new byte[8192];
        int numRead1;
        int numRead2;
        while (true) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter contentsEquals 2");
            numRead1 = readNBytes(in1, buffer1);
            numRead2 = readNBytes(in2, buffer2);
            if (numRead1 > 0) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter contentsEquals 3");
                if (numRead2 <= 0) {
                    System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter contentsEquals 4");
                    return "EOF on second stream but not first";
                    // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit contentsEquals 4");
                }
                if (numRead2 != numRead1) {
                    System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter contentsEquals 5");
                    return "Read size different (" + numRead1 + " vs " + numRead2 + ")";
                    // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit contentsEquals 5");
                }
                // Otherwise same number of bytes read
                if (!Arrays.equals(buffer1, buffer2)) {
                    System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter contentsEquals 6");
                    return "Content differs";
                    // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit contentsEquals 6");
                }
                // Otherwise same bytes read, so continue ...
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit contentsEquals 3");
            } else {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter contentsEquals 7");
                // Nothing more in stream 1 ...
                if (numRead2 > 0) {
                    System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter contentsEquals 8");
                    return "EOF on first stream but not second";
                    // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit contentsEquals 8");
                } else {
                    System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter contentsEquals 9");
                    return null;
                    // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit contentsEquals 9");
                }
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit contentsEquals 7");
            }
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit contentsEquals 2");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit contentsEquals 1");
    }

    /**
     * Extracts and loads the specified library file to the target folder
     *
     * @param libFolderForCurrentOS Library path.
     * @param libraryFileName       Library name.
     * @param targetFolder          Target folder.
     * @return
     */
    private static boolean extractAndLoadLibraryFile(
            String libFolderForCurrentOS, String libraryFileName, String targetFolder) {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter extractAndLoadLibraryFile 1");
        String nativeLibraryFilePath = libFolderForCurrentOS + "/" + libraryFileName;
        // Include architecture name in temporary filename in order to avoid conflicts
        // when multiple JVMs with different architectures running at the same time
        String uuid = randomUUID();
        String extractedLibFileName = String.format("jansi-%s-%s-%s", getVersion(), uuid, libraryFileName);
        String extractedLckFileName = extractedLibFileName + ".lck";

        File extractedLibFile = new File(targetFolder, extractedLibFileName);
        File extractedLckFile = new File(targetFolder, extractedLckFileName);

        try {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter extractAndLoadLibraryFile 2");
            // Extract a native library file into the target directory
            try (InputStream in = JansiLoader.class.getResourceAsStream(nativeLibraryFilePath)) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter extractAndLoadLibraryFile 3");
                if (!extractedLckFile.exists()) {
                    System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter extractAndLoadLibraryFile 4");
                    new FileOutputStream(extractedLckFile).close();
                    // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit extractAndLoadLibraryFile 4");
                }
                Files.copy(in, extractedLibFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit extractAndLoadLibraryFile 3");
            } finally {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter extractAndLoadLibraryFile 5");
                // Delete the extracted lib file on JVM exit.
                extractedLibFile.deleteOnExit();
                extractedLckFile.deleteOnExit();
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit extractAndLoadLibraryFile 5");
            }

            // Set executable (x) flag to enable Java to load the native library
            System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter extractAndLoadLibraryFile 6");
            extractedLibFile.setReadable(true);
            extractedLibFile.setWritable(true);
            extractedLibFile.setExecutable(true);

            // Check whether the contents are properly copied from the resource folder
            try (InputStream nativeIn = JansiLoader.class.getResourceAsStream(nativeLibraryFilePath)) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter extractAndLoadLibraryFile 7");
                try (InputStream extractedLibIn = new FileInputStream(extractedLibFile)) {
                    System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter extractAndLoadLibraryFile 8");
                    String eq = contentsEquals(nativeIn, extractedLibIn);
                    if (eq != null) {
                        System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter extractAndLoadLibraryFile 9");
                        throw new RuntimeException(String.format(
                                "Failed to write a native library file at %s because %s", extractedLibFile, eq));
                        // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit extractAndLoadLibraryFile 9");
                    }
                    // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit extractAndLoadLibraryFile 8");
                }
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit extractAndLoadLibraryFile 7");
            }

            // Load library
            System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter extractAndLoadLibraryFile 10");
            if (loadNativeLibrary(extractedLibFile)) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter extractAndLoadLibraryFile 11");
                nativeLibrarySourceUrl =
                        JansiLoader.class.getResource(nativeLibraryFilePath).toExternalForm();
                return true;
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit extractAndLoadLibraryFile 11");
            }
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit extractAndLoadLibraryFile 10");
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit extractAndLoadLibraryFile 6");
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit extractAndLoadLibraryFile 2");
        } catch (IOException e) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter extractAndLoadLibraryFile 12");
            System.err.println(e.getMessage());
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit extractAndLoadLibraryFile 12");
        }
        return false;
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit extractAndLoadLibraryFile 1");
    }

    private static String randomUUID() {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter randomUUID 1");
        return Long.toHexString(new Random().nextLong());
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit randomUUID 1");
    }

    /**
     * Loads native library using the given path and name of the library.
     *
     * @param libPath Path of the native library.
     * @return True for successfully loading; false otherwise.
     */
    private static boolean loadNativeLibrary(File libPath) {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadNativeLibrary 1");
        if (libPath.exists()) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadNativeLibrary 2");
            try {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadNativeLibrary 3");
                String path = libPath.getAbsolutePath();
                System.load(path);
                nativeLibraryPath = path;
                return true;
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadNativeLibrary 3");
            } catch (UnsatisfiedLinkError e) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadNativeLibrary 4");
                if (!libPath.canExecute()) {
                    System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadNativeLibrary 5");
                    // NOTE: this can be tested using something like:
                    // docker run --rm --tmpfs /tmp -v $PWD:/jansi openjdk:11 java -jar
                    // /jansi/target/jansi-xxx-SNAPSHOT.jar
                    System.err.printf(
                            "Failed to load native library:%s. The native library file at %s is not executable, "
                                    + "make sure that the directory is mounted on a partition without the noexec flag, or set the "
                                    + "jansi.tmpdir system property to point to a proper location.  osinfo: %s%n",
                            libPath.getName(), libPath, OSInfo.getNativeLibFolderPathForCurrentOS());
                    // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadNativeLibrary 5");
                } else {
                    System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadNativeLibrary 6");
                    System.err.printf(
                            "Failed to load native library:%s. osinfo: %s%n",
                            libPath.getName(), OSInfo.getNativeLibFolderPathForCurrentOS());
                    // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadNativeLibrary 6");
                }
                System.err.println(e);
                return false;
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadNativeLibrary 4");
            }
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadNativeLibrary 2");
        } else {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadNativeLibrary 7");
            return false;
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadNativeLibrary 7");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadNativeLibrary 1");
    }

    /**
     * Loads jansi library using given path and name of the library.
     *
     * @throws
     */
    private static void loadJansiNativeLibrary() throws Exception {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadJansiNativeLibrary 1");
        if (loaded) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadJansiNativeLibrary 2");
            return;
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadJansiNativeLibrary 2");
        }

        List<String> triedPaths = new LinkedList<String>();

        // Try loading library from library.jansi.path library path */
        String jansiNativeLibraryPath = System.getProperty("library.jansi.path");
        String jansiNativeLibraryName = System.getProperty("library.jansi.name");
        if (jansiNativeLibraryName == null) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadJansiNativeLibrary 3");
            jansiNativeLibraryName = System.mapLibraryName("jansi");
            assert jansiNativeLibraryName != null;
            if (jansiNativeLibraryName.endsWith(".dylib")) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadJansiNativeLibrary 4");
                jansiNativeLibraryName = jansiNativeLibraryName.replace(".dylib", ".jnilib");
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadJansiNativeLibrary 4");
            }
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadJansiNativeLibrary 3");
        }

        if (jansiNativeLibraryPath != null) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadJansiNativeLibrary 5");
            String withOs = jansiNativeLibraryPath + "/" + OSInfo.getNativeLibFolderPathForCurrentOS();
            if (loadNativeLibrary(new File(withOs, jansiNativeLibraryName))) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadJansiNativeLibrary 6");
                loaded = true;
                return;
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadJansiNativeLibrary 6");
            } else {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadJansiNativeLibrary 7");
                triedPaths.add(withOs);
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadJansiNativeLibrary 7");
            }

            if (loadNativeLibrary(new File(jansiNativeLibraryPath, jansiNativeLibraryName))) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadJansiNativeLibrary 8");
                loaded = true;
                return;
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadJansiNativeLibrary 8");
            } else {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadJansiNativeLibrary 9");
                triedPaths.add(jansiNativeLibraryPath);
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadJansiNativeLibrary 9");
            }
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadJansiNativeLibrary 5");
        }

        // Load the os-dependent library from the jar file
        System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadJansiNativeLibrary 10");
        String packagePath = JansiLoader.class.getPackage().getName().replace('.', '/');
        jansiNativeLibraryPath =
                String.format("/%s/native/%s", packagePath, OSInfo.getNativeLibFolderPathForCurrentOS());
        boolean hasNativeLib = hasResource(jansiNativeLibraryPath + "/" + jansiNativeLibraryName);

        if (hasNativeLib) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadJansiNativeLibrary 11");
            // temporary library folder
            String tempFolder = getTempDir().getAbsolutePath();
            // Try extracting the library from jar
            if (extractAndLoadLibraryFile(jansiNativeLibraryPath, jansiNativeLibraryName, tempFolder)) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadJansiNativeLibrary 12");
                loaded = true;
                return;
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadJansiNativeLibrary 12");
            } else {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadJansiNativeLibrary 13");
                triedPaths.add(jansiNativeLibraryPath);
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadJansiNativeLibrary 13");
            }
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadJansiNativeLibrary 11");
        }

        // As a last resort try from java.library.path
        System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadJansiNativeLibrary 14");
        String javaLibraryPath = System.getProperty("java.library.path", "");
        for (String ldPath : javaLibraryPath.split(File.pathSeparator)) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadJansiNativeLibrary 15");
            if (ldPath.isEmpty()) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadJansiNativeLibrary 16");
                continue;
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadJansiNativeLibrary 16");
            }
            if (loadNativeLibrary(new File(ldPath, jansiNativeLibraryName))) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadJansiNativeLibrary 17");
                loaded = true;
                return;
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadJansiNativeLibrary 17");
            } else {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter loadJansiNativeLibrary 18");
                triedPaths.add(ldPath);
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadJansiNativeLibrary 18");
            }
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadJansiNativeLibrary 15");
        }

        throw new Exception(String.format(
                "No native library found for os.name=%s, os.arch=%s, paths=[%s]",
                OSInfo.getOSName(), OSInfo.getArchName(), String.join(File.pathSeparator, triedPaths)));
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadJansiNativeLibrary 14");
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadJansiNativeLibrary 10");
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit loadJansiNativeLibrary 1");
    }

    private static boolean hasResource(String path) {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter hasResource 1");
        return JansiLoader.class.getResource(path) != null;
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit hasResource 1");
    }

    /**
     * @return The major version of the jansi library.
     */
    public static int getMajorVersion() {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter getMajorVersion 1");
        String[] c = getVersion().split("\\.");
        return (c.length > 0) ? Integer.parseInt(c[0]) : 1;
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit getMajorVersion 1");
    }

    /**
     * @return The minor version of the jansi library.
     */
    public static int getMinorVersion() {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter getMinorVersion 1");
        String[] c = getVersion().split("\\.");
        return (c.length > 1) ? Integer.parseInt(c[1]) : 0;
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit getMinorVersion 1");
    }

    /**
     * @return The version of the jansi library.
     */
    public static String getVersion() {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter getVersion 1");
        URL versionFile = JansiLoader.class.getResource("/org/fusesource/jansi/jansi.properties");

        String version = "unknown";
        try {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter getVersion 2");
            if (versionFile != null) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter getVersion 3");
                Properties versionData = new Properties();
                versionData.load(versionFile.openStream());
                version = versionData.getProperty("version", version);
                version = version.trim().replaceAll("[^0-9.]", "");
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit getVersion 3");
            }
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit getVersion 2");
        } catch (IOException e) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] enter getVersion 4");
            System.err.println(e);
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit getVersion 4");
        }
        return version;
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/JansiLoader.java] exit getVersion 1");
    }
}
// Total cost: 0.114441
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split
// chunks: [(0, 395)]
// Total instrumented cost: 0.114441, input tokens: 2398, output tokens: 6549, cache read tokens: 2394, cache write
// tokens: 4127

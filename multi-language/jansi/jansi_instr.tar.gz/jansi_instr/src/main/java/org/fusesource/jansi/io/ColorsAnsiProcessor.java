/*
 * Copyright (C) 2009-2023 the original author(s).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.fusesource.jansi.io;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;

import org.fusesource.jansi.AnsiColors;

/**
 * Ansi processor to process color conversion if needed.
 */
public class ColorsAnsiProcessor extends AnsiProcessor {

    private final AnsiColors colors;

    public ColorsAnsiProcessor(OutputStream os, AnsiColors colors) {
        super(os);
        System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter ColorsAnsiProcessor 1");
        this.colors = colors;
        // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit ColorsAnsiProcessor 1");
    }

    @Override
    protected boolean processEscapeCommand(ArrayList<Object> options, int command) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processEscapeCommand 1");
        if (command == 'm' && (colors == AnsiColors.Colors256 || colors == AnsiColors.Colors16)) {
            System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processEscapeCommand 2");
            // Validate all options are ints...
            boolean has38or48 = false;
            for (Object next : options) {
                System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processEscapeCommand 3");
                if (next != null && next.getClass() != Integer.class) {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processEscapeCommand 4");
                    throw new IllegalArgumentException();
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit processEscapeCommand 4");
                }
                Integer value = (Integer) next;
                has38or48 |= value == 38 || value == 48;
                // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit processEscapeCommand 3");
            }
            // SGR commands do not contain an extended color, so just transfer the buffer
            if (!has38or48) {
                System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processEscapeCommand 5");
                return false;
                // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit processEscapeCommand 5");
            }
            StringBuilder sb = new StringBuilder(32);
            sb.append('\033').append('[');
            boolean first = true;
            Iterator<Object> optionsIterator = options.iterator();
            while (optionsIterator.hasNext()) {
                System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processEscapeCommand 6");
                Object next = optionsIterator.next();
                if (next != null) {
                    System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processEscapeCommand 7");
                    int value = (Integer) next;
                    if (value == 38 || value == 48) {
                        System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processEscapeCommand 8");
                        // extended color like `esc[38;5;<index>m` or `esc[38;2;<r>;<g>;<b>m`
                        int arg2or5 = getNextOptionInt(optionsIterator);
                        if (arg2or5 == 2) {
                            System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processEscapeCommand 9");
                            // 24 bit color style like `esc[38;2;<r>;<g>;<b>m`
                            int r = getNextOptionInt(optionsIterator);
                            int g = getNextOptionInt(optionsIterator);
                            int b = getNextOptionInt(optionsIterator);
                            if (colors == AnsiColors.Colors256) {
                                System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processEscapeCommand 10");
                                int col = Colors.roundRgbColor(r, g, b, 256);
                                if (!first) {
                                    System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processEscapeCommand 11");
                                    sb.append(';');
                                    // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit processEscapeCommand 11");
                                }
                                first = false;
                                sb.append(value);
                                sb.append(';');
                                sb.append(5);
                                sb.append(';');
                                sb.append(col);
                                // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit  processEscapeCommand 10");
                            } else {
                                System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processEscapeCommand 12");
                                int col = Colors.roundRgbColor(r, g, b, 16);
                                if (!first) {
                                    System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processEscapeCommand 13");
                                    sb.append(';');
                                    // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit processEscapeCommand 13");
                                }
                                first = false;
                                sb.append(
                                        value == 38
                                                ? col >= 8 ? 90 + col - 8 : 30 + col
                                                : col >= 8 ? 100 + col - 8 : 40 + col);
                                // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit  processEscapeCommand 12");
                            }
                            // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit processEscapeCommand 9");
                        } else if (arg2or5 == 5) {
                            System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processEscapeCommand 14");
                            // 256 color style like `esc[38;5;<index>m`
                            int paletteIndex = getNextOptionInt(optionsIterator);
                            if (colors == AnsiColors.Colors256) {
                                System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processEscapeCommand 15");
                                if (!first) {
                                    System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processEscapeCommand 16");
                                    sb.append(';');
                                    // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit processEscapeCommand 16");
                                }
                                first = false;
                                sb.append(value);
                                sb.append(';');
                                sb.append(5);
                                sb.append(';');
                                sb.append(paletteIndex);
                                // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit  processEscapeCommand 15");
                            } else {
                                System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processEscapeCommand 17");
                                int col = Colors.roundColor(paletteIndex, 16);
                                if (!first) {
                                    System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processEscapeCommand 18");
                                    sb.append(';');
                                    // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit processEscapeCommand 18");
                                }
                                first = false;
                                sb.append(
                                        value == 38
                                                ? col >= 8 ? 90 + col - 8 : 30 + col
                                                : col >= 8 ? 100 + col - 8 : 40 + col);
                                // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit  processEscapeCommand 17");
                            }
                            // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit processEscapeCommand 14");
                        } else {
                            System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processEscapeCommand 19");
                            throw new IllegalArgumentException();
                            // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit processEscapeCommand 19");
                        }
                        // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit processEscapeCommand 8");
                    } else {
                        System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processEscapeCommand 20");
                        if (!first) {
                            System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processEscapeCommand 21");
                            sb.append(';');
                            // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit processEscapeCommand 21");
                        }
                        first = false;
                        sb.append(value);
                        // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit processEscapeCommand 20");
                    }
                    // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit processEscapeCommand 7");
                }
                // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit processEscapeCommand 6");
            }
            sb.append('m');
            os.write(sb.toString().getBytes());
            return true;
            // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit processEscapeCommand 2");
        } else {
            System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processEscapeCommand 22");
            return false;
            // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit processEscapeCommand 22");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit processEscapeCommand 1");
    }

    @Override
    protected boolean processOperatingSystemCommand(ArrayList<Object> options) {
        System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processOperatingSystemCommand 1");
        return false;
        // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit processOperatingSystemCommand 1");
    }

    @Override
    protected boolean processCharsetSelect(ArrayList<Object> options) {
        System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] enter processCharsetSelect 1");
        return false;
        // System.err.println("[src/main/java/org/fusesource/jansi/io/ColorsAnsiProcessor.java] exit processCharsetSelect 1");
    }
}
// Total cost: 0.042119
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split
// chunks: [(0, 145)]
// Total instrumented cost: 0.042119, input tokens: 2398, output tokens: 2376, cache read tokens: 2394, cache write
// tokens: 1533

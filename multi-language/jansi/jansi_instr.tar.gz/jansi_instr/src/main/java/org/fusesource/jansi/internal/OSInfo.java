/*
 * Copyright (C) 2009-2023 the original author(s).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.fusesource.jansi.internal;

/*--------------------------------------------------------------------------
 *  Copyright 2008 Taro L. Saito
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *--------------------------------------------------------------------------*/

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Locale;

/**
 * Provides OS name and architecture name.
 *
 */
public class OSInfo {

    public static final String X86 = "x86";
    public static final String X86_64 = "x86_64";
    public static final String IA64_32 = "ia64_32";
    public static final String IA64 = "ia64";
    public static final String PPC = "ppc";
    public static final String PPC64 = "ppc64";
    public static final String ARM64 = "arm64";

    private static final HashMap<String, String> archMapping = new HashMap<String, String>();

    static {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter OSInfo_static 1");
        // x86 mappings
        archMapping.put(X86, X86);
        archMapping.put("i386", X86);
        archMapping.put("i486", X86);
        archMapping.put("i586", X86);
        archMapping.put("i686", X86);
        archMapping.put("pentium", X86);

        // x86_64 mappings
        archMapping.put(X86_64, X86_64);
        archMapping.put("amd64", X86_64);
        archMapping.put("em64t", X86_64);
        archMapping.put("universal", X86_64); // Needed for openjdk7 in Mac

        // Itenium 64-bit mappings
        archMapping.put(IA64, IA64);
        archMapping.put("ia64w", IA64);

        // Itenium 32-bit mappings, usually an HP-UX construct
        archMapping.put(IA64_32, IA64_32);
        archMapping.put("ia64n", IA64_32);

        // PowerPC mappings
        archMapping.put(PPC, PPC);
        archMapping.put("power", PPC);
        archMapping.put("powerpc", PPC);
        archMapping.put("power_pc", PPC);
        archMapping.put("power_rs", PPC);

        // TODO: PowerPC 64bit mappings
        archMapping.put(PPC64, PPC64);
        archMapping.put("power64", PPC64);
        archMapping.put("powerpc64", PPC64);
        archMapping.put("power_pc64", PPC64);
        archMapping.put("power_rs64", PPC64);

        // aarch64 mappings
        archMapping.put("aarch64", ARM64);
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit OSInfo_static 1");
    }

    public static void main(String[] args) {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter main 1");
        if (args.length >= 1) {
            if ("--os".equals(args[0])) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter main 2");
                System.out.print(getOSName());
                return;
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit main 2");
            } else if ("--arch".equals(args[0])) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter main 3");
                System.out.print(getArchName());
                return;
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit main 3");
            }
        }

        System.out.print(getNativeLibFolderPathForCurrentOS());
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit main 1");
    }

    public static String getNativeLibFolderPathForCurrentOS() {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter getNativeLibFolderPathForCurrentOS 1");
        return getOSName() + "/" + getArchName();
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit getNativeLibFolderPathForCurrentOS 1");
    }

    public static String getOSName() {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter getOSName 1");
        return translateOSNameToFolderName(System.getProperty("os.name"));
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit getOSName 1");
    }

    public static boolean isAndroid() {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter isAndroid 1");
        return System.getProperty("java.runtime.name", "").toLowerCase().contains("android");
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit isAndroid 1");
    }

    public static boolean isAlpine() {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter isAlpine 1");
        try {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter isAlpine 2");
            for (String line : Files.readAllLines(Paths.get("/etc/os-release"))) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter isAlpine 3");
                if (line.startsWith("ID") && line.toLowerCase(Locale.ROOT).contains("alpine")) {
                    System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter isAlpine 4");
                    return true;
                    // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit isAlpine 4");
                }
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit isAlpine 3");
            }
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit isAlpine 2");
        } catch (Throwable ignored) {
            System.err.println("");
            // System.err.println("");
        }

        return false;
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit isAlpine 1");
    }

    static String getHardwareName() {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter getHardwareName 1");
        try {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter getHardwareName 2");
            Process p = Runtime.getRuntime().exec("uname -m");
            p.waitFor();

            InputStream in = p.getInputStream();
            try {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter getHardwareName 3");
                return readFully(in);
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit getHardwareName 3");
            } finally {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter getHardwareName 4");
                in.close();
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit getHardwareName 4");
            }
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit getHardwareName 2");
        } catch (Throwable e) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter getHardwareName 5");
            System.err.println("Error while running uname -m: " + e.getMessage());
            return "unknown";
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit getHardwareName 5");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit getHardwareName 1");
    }

    private static String readFully(InputStream in) throws IOException {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter readFully 1");
        int readLen = 0;
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[32];
        while ((readLen = in.read(buf, 0, buf.length)) >= 0) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter readFully 2");
            b.write(buf, 0, readLen);
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit readFully 2");
        }
        return b.toString();
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit readFully 1");
    }

    static String resolveArmArchType() {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter resolveArmArchType 1");
        if (System.getProperty("os.name").contains("Linux")) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter resolveArmArchType 2");
            String armType = getHardwareName();
            // armType (uname -m) can be armv5t, armv5te, armv5tej, armv5tejl, armv6, armv7, armv7l, aarch64, i686
            if (armType.startsWith("armv6")) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter resolveArmArchType 3");
                // Raspberry PI
                return "armv6";
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit resolveArmArchType 3");
            } else if (armType.startsWith("armv7")) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter resolveArmArchType 4");
                // Generic
                return "armv7";
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit resolveArmArchType 4");
            } else if (armType.startsWith("armv5")) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter resolveArmArchType 5");
                // Use armv5, soft-float ABI
                return "arm";
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit resolveArmArchType 5");
            } else if (armType.equals("aarch64")) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter resolveArmArchType 6");
                // Use arm64
                return "arm64";
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit resolveArmArchType 6");
            }

            // Java 1.8 introduces a system property to determine armel or armhf
            // http://bugs.java.com/bugdatabase/view_bug.do?bug_id=8005545
            String abi = System.getProperty("sun.arch.abi");
            if (abi != null && abi.startsWith("gnueabihf")) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter resolveArmArchType 7");
                return "armv7";
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit resolveArmArchType 7");
            }
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit resolveArmArchType 2");
        }
        // Use armv5, soft-float ABI
        return "arm";
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit resolveArmArchType 1");
    }

    public static String getArchName() {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter getArchName 1");
        String osArch = System.getProperty("os.arch");
        // For Android
        if (isAndroid()) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter getArchName 2");
            return "android-arm";
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit getArchName 2");
        }

        if (osArch.startsWith("arm")) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter getArchName 3");
            osArch = resolveArmArchType();
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit getArchName 3");
        } else {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter getArchName 4");
            String lc = osArch.toLowerCase(Locale.US);
            if (archMapping.containsKey(lc)) {
                System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter getArchName 5");
                return archMapping.get(lc);
                // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit getArchName 5");
            }
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit getArchName 4");
        }
        return translateArchNameToFolderName(osArch);
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit getArchName 1");
    }

    static String translateOSNameToFolderName(String osName) {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter translateOSNameToFolderName 1");
        if (osName.contains("Windows")) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter translateOSNameToFolderName 2");
            return "Windows";
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit translateOSNameToFolderName 2");
        } else if (osName.contains("Mac") || osName.contains("Darwin")) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter translateOSNameToFolderName 3");
            return "Mac";
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit translateOSNameToFolderName 3");
            //        } else if (isAlpine()) {
            //            return "Linux-Alpine";
        } else if (osName.contains("Linux")) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter translateOSNameToFolderName 4");
            return "Linux";
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit translateOSNameToFolderName 4");
        } else if (osName.contains("AIX")) {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter translateOSNameToFolderName 5");
            return "AIX";
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit translateOSNameToFolderName 5");
        } else {
            System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter translateOSNameToFolderName 6");
            return osName.replaceAll("\\W", "");
            // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit translateOSNameToFolderName 6");
        }
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit translateOSNameToFolderName 1");
    }

    static String translateArchNameToFolderName(String archName) {
        System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] enter translateArchNameToFolderName 1");
        return archName.replaceAll("\\W", "");
        // System.err.println("[src/main/java/org/fusesource/jansi/internal/OSInfo.java] exit translateArchNameToFolderName 1");
    }
}
// Total cost: 0.064296
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split
// chunks: [(0, 229)]
// Total instrumented cost: 0.064296, input tokens: 2398, output tokens: 3646, cache read tokens: 2394, cache write
// tokens: 2367

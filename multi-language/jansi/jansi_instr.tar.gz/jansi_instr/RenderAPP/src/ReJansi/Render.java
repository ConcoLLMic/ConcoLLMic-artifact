package ReJansi;

import org.fusesource.jansi.AnsiColors;
import org.fusesource.jansi.AnsiMode;
import org.fusesource.jansi.AnsiType;
import org.fusesource.jansi.io.AnsiOutputStream;
import static org.fusesource.jansi.AnsiRenderer.render;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;

public class Render {
    public static void main(String[] args) throws IOException {
        System.err.println("[RenderAPP/src/ReJansi/Render.java] enter main 1");
        if (args.length < 2) {
            System.err.println("[RenderAPP/src/ReJansi/Render.java] enter main 2");
            System.err.println("Usage: java ReJansi.CombinedAnsi <inputFile> <mode>");
            System.err.println("Modes: strip - Strip ANSI escape codes");
            System.err.println("       render - Render markup into ANSI sequences");
            System.err.println("       strip-then-render - Strip ANSI codes then render markup");
            System.err.println("       render-then-strip - Render markup then strip ANSI codes");
            return;
            // System.err.println("[RenderAPP/src/ReJansi/Render.java] exit main 2");
        }

        String inputFile = args[0];
        String mode = args[1];

        // read the file content
        String content = readFile(inputFile);
        if (content == null) {
            System.err.println("[RenderAPP/src/ReJansi/Render.java] enter main 3");
            return;
            // System.err.println("[RenderAPP/src/ReJansi/Render.java] exit main 3");
        }

        String result = "";

        switch (mode.toLowerCase()) {
            case "strip":
                System.err.println("[RenderAPP/src/ReJansi/Render.java] enter main 4");
                result = stripAnsi(content);
                break;
                // System.err.println("[RenderAPP/src/ReJansi/Render.java] exit main 4");
            case "render":
                System.err.println("[RenderAPP/src/ReJansi/Render.java] enter main 5");
                result = render(content);
                break;
                // System.err.println("[RenderAPP/src/ReJansi/Render.java] exit main 5");
            case "strip-then-render":
                System.err.println("[RenderAPP/src/ReJansi/Render.java] enter main 6");
                result = render(stripAnsi(content));
                break;
                // System.err.println("[RenderAPP/src/ReJansi/Render.java] exit main 6");
            case "render-then-strip":
                System.err.println("[RenderAPP/src/ReJansi/Render.java] enter main 7");
                result = stripAnsi(render(content));
                break;
                // System.err.println("[RenderAPP/src/ReJansi/Render.java] exit main 7");
            default:
                System.err.println("[RenderAPP/src/ReJansi/Render.java] enter main 8");
                System.err.println("Unknown mode: " + mode);
                return;
                // System.err.println("[RenderAPP/src/ReJansi/Render.java] exit main 8");
        }

        System.err.println("[RenderAPP/src/ReJansi/Render.java] enter main 9");
        System.out.println("Result:");
        System.out.println(result);
        // System.err.println("[RenderAPP/src/ReJansi/Render.java] exit main 9");
        // System.err.println("[RenderAPP/src/ReJansi/Render.java] exit main 1");
    }

    private static String readFile(String filePath) {
        System.err.println("[RenderAPP/src/ReJansi/Render.java] enter readFile 1");
        StringBuilder input = new StringBuilder();
        try {
            System.err.println("[RenderAPP/src/ReJansi/Render.java] enter readFile 2");
            File file = new File(filePath);
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                System.err.println("[RenderAPP/src/ReJansi/Render.java] enter readFile 3");
                input.append(line).append("\n");
                // System.err.println("[RenderAPP/src/ReJansi/Render.java] exit readFile 3");
            }
            reader.close();
            System.out.println("Input content: " + input.toString());
            return input.toString();
            // System.err.println("[RenderAPP/src/ReJansi/Render.java] exit readFile 2");
        } catch (IOException e) {
            System.err.println("[RenderAPP/src/ReJansi/Render.java] enter readFile 4");
            System.err.println("File read error: " + e.getMessage());
            return null;
            // System.err.println("[RenderAPP/src/ReJansi/Render.java] exit readFile 4");
        }
        // System.err.println("[RenderAPP/src/ReJansi/Render.java] exit readFile 1");
    }

    private static String stripAnsi(String input) throws IOException {
        System.err.println("[RenderAPP/src/ReJansi/Render.java] enter stripAnsi 1");
        // convert the string to byte array
        byte[] inputBytes = input.getBytes(Charset.forName("UTF-8"));

        // use AnsiOutputStream to strip the ANSI escape sequences
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final AnsiOutputStream ansiOutput = new AnsiOutputStream(baos, null, AnsiMode.Strip, null,
                AnsiType.Emulation, AnsiColors.TrueColor, Charset.forName("UTF-8"), null, null, false);
        ansiOutput.write(inputBytes);
        ansiOutput.close();

        return baos.toString("UTF-8");
        // System.err.println("[RenderAPP/src/ReJansi/Render.java] exit stripAnsi 1");
    }
}
// Total cost: 0.031220
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 90)]
// Total instrumented cost: 0.031220, input tokens: 4, output tokens: 1252, cache read tokens: 0, cache write tokens: 3314

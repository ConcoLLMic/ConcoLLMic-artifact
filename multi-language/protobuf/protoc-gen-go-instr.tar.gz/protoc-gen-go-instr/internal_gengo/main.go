// Copyright 2018 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Package internal_gengo is internal to the protobuf module.
package internal_gengo

import (
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"math"
	"os"
	"strconv"
	"strings"
	"unicode"
	"unicode/utf8"

	"google.golang.org/protobuf/compiler/protogen"
	"google.golang.org/protobuf/internal/editionssupport"
	"google.golang.org/protobuf/internal/encoding/tag"
	"google.golang.org/protobuf/internal/filedesc"
	"google.golang.org/protobuf/internal/genid"
	"google.golang.org/protobuf/internal/version"
	"google.golang.org/protobuf/reflect/protoreflect"
	"google.golang.org/protobuf/runtime/protoimpl"

	"google.golang.org/protobuf/types/descriptorpb"
	"google.golang.org/protobuf/types/gofeaturespb"
	"google.golang.org/protobuf/types/pluginpb"
)

// SupportedFeatures reports the set of supported protobuf language features.
var SupportedFeatures = uint64(pluginpb.CodeGeneratorResponse_FEATURE_PROTO3_OPTIONAL | pluginpb.CodeGeneratorResponse_FEATURE_SUPPORTS_EDITIONS)

var SupportedEditionsMinimum = editionssupport.Minimum
var SupportedEditionsMaximum = editionssupport.Maximum

// GenerateVersionMarkers specifies whether to generate version markers.
var GenerateVersionMarkers = true

// Standard library dependencies.
const (
	base64Package  = protogen.GoImportPath("encoding/base64")
	jsonPackage    = protogen.GoImportPath("encoding/json")
	mathPackage    = protogen.GoImportPath("math")
	reflectPackage = protogen.GoImportPath("reflect")
	sortPackage    = protogen.GoImportPath("sort")
	stringsPackage = protogen.GoImportPath("strings")
	syncPackage    = protogen.GoImportPath("sync")
	timePackage    = protogen.GoImportPath("time")
	utf8Package    = protogen.GoImportPath("unicode/utf8")
	unsafePackage  = protogen.GoImportPath("unsafe")
)

// Protobuf library dependencies.
//
// These are declared as an interface type so that they can be more easily
// patched to support unique build environments that impose restrictions
// on the dependencies of generated source code.
var (
	protoPackage         goImportPath = protogen.GoImportPath("google.golang.org/protobuf/proto")
	protoifacePackage    goImportPath = protogen.GoImportPath("google.golang.org/protobuf/runtime/protoiface")
	protoimplPackage     goImportPath = protogen.GoImportPath("google.golang.org/protobuf/runtime/protoimpl")
	protojsonPackage     goImportPath = protogen.GoImportPath("google.golang.org/protobuf/encoding/protojson")
	protoreflectPackage  goImportPath = protogen.GoImportPath("google.golang.org/protobuf/reflect/protoreflect")
	protoregistryPackage goImportPath = protogen.GoImportPath("google.golang.org/protobuf/reflect/protoregistry")
)

type goImportPath interface {
	String() string
	Ident(string) protogen.GoIdent
}

func setToOpaque(msg *protogen.Message) {
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter setToOpaque 1\n"))
	msg.APILevel = gofeaturespb.GoFeatures_API_OPAQUE
	for _, nested := range msg.Messages {
		nested.APILevel = gofeaturespb.GoFeatures_API_OPAQUE
		setToOpaque(nested)
	}
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit setToOpaque 1\n"))
}

// GenerateFile generates the contents of a .pb.go file.
//
// With the Hybrid API, multiple files are generated (_protoopaque.pb.go variant),
// but only the first file (regular, not a variant) is returned.
func GenerateFile(gen *protogen.Plugin, file *protogen.File) *protogen.GeneratedFile {
	return generateFiles(gen, file)[0]
}

func generateFiles(gen *protogen.Plugin, file *protogen.File) []*protogen.GeneratedFile {
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter generateFiles 1\n"))
	f := newFileInfo(file)
	generated := []*protogen.GeneratedFile{
		generateOneFile(gen, file, f, ""),
	}
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit generateFiles 1\n"))
	
	if f.APILevel == gofeaturespb.GoFeatures_API_HYBRID {
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter generateFiles 2\n"))
		// Update all APILevel fields to OPAQUE
		f.APILevel = gofeaturespb.GoFeatures_API_OPAQUE
		for _, msg := range f.Messages {
			setToOpaque(msg)
		}
		generated = append(generated, generateOneFile(gen, file, f, "_protoopaque"))
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit generateFiles 2\n"))
	}
	
	return generated
}

func generateOneFile(gen *protogen.Plugin, file *protogen.File, f *fileInfo, variant string) *protogen.GeneratedFile {
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter generateOneFile 1\n"))
	filename := file.GeneratedFilenamePrefix + variant + ".pb.go"
	g := gen.NewGeneratedFile(filename, file.GoImportPath)
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit generateOneFile 1\n"))

	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter generateOneFile 2\n"))
	var packageDoc protogen.Comments
	if !gen.InternalStripForEditionsDiff() {
		genStandaloneComments(g, f, int32(genid.FileDescriptorProto_Syntax_field_number))
		genGeneratedHeader(gen, g, f)
		genStandaloneComments(g, f, int32(genid.FileDescriptorProto_Package_field_number))

		packageDoc = genPackageKnownComment(f)
	}
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit generateOneFile 2\n"))
	
	if variant == "_protoopaque" {
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter generateOneFile 3\n"))
		g.P("//go:build protoopaque")
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit generateOneFile 3\n"))
	} else if f.APILevel == gofeaturespb.GoFeatures_API_HYBRID {
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter generateOneFile 4\n"))
		g.P("//go:build !protoopaque")
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit generateOneFile 4\n"))
	}
	
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter generateOneFile 5\n"))
	g.P(packageDoc, "package ", f.GoPackageName)
	g.P()
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit generateOneFile 5\n"))

	// Emit a static check that enforces a minimum version of the proto package.
	if GenerateVersionMarkers {
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter generateOneFile 6\n"))
		g.P("const (")
		g.P("// Verify that this generated code is sufficiently up-to-date.")
		g.P("_ = ", protoimplPackage.Ident("EnforceVersion"), "(", protoimpl.GenVersion, " - ", protoimplPackage.Ident("MinVersion"), ")")
		g.P("// Verify that runtime/protoimpl is sufficiently up-to-date.")
		g.P("_ = ", protoimplPackage.Ident("EnforceVersion"), "(", protoimplPackage.Ident("MaxVersion"), " - ", protoimpl.GenVersion, ")")
		g.P(")")
		g.P()
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit generateOneFile 6\n"))
	}

	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter generateOneFile 7\n"))
	for i, imps := 0, f.Desc.Imports(); i < imps.Len(); i++ {
		genImport(gen, g, f, imps.Get(i))
	}
	for _, enum := range f.allEnums {
		genEnum(g, f, enum)
	}
	for _, message := range f.allMessages {
		genMessage(g, f, message)
	}
	genExtensions(g, f)
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit generateOneFile 7\n"))

	// The descriptor contains a lot of information about the syntax which is
	// quite different between the proto2/3 version of a file and the equivalent
	// editions version. For example, when a proto3 file is translated from
	// proto3 to editions every field in that file that is marked optional in
	// proto3 will have a features.field_presence option set.
	// Another problem is that the descriptor contains implementation details
	// that are not relevant for the semantic. For example, proto3 optional
	// fields are implemented as oneof fields with one case. The descriptor
	// contains different information about oneofs. If the file is translated
	// to editions it no longer is treated as a oneof with one case and thus
	// none of the oneof specific information is generated.
	// To be able to compare the descriptor before and after translation of the
	// associated proto file, we would need to trim many parts. This would lead
	// to a brittle implementation in case the translation ever changes.
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter generateOneFile 8\n"))
	if !g.InternalStripForEditionsDiff() {
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter generateOneFile 9\n"))
		genReflectFileDescriptor(gen, g, f)
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit generateOneFile 9\n"))
	}
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit generateOneFile 8\n"))

	return g
}

// genStandaloneComments prints all leading comments for a FileDescriptorProto
// location identified by the field number n.
func genStandaloneComments(g *protogen.GeneratedFile, f *fileInfo, n int32) {
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genStandaloneComments 1\n"))
	loc := f.Desc.SourceLocations().ByPath(protoreflect.SourcePath{n})
	for _, s := range loc.LeadingDetachedComments {
		g.P(protogen.Comments(s))
		g.P()
	}
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genStandaloneComments 1\n"))
	
	if s := loc.LeadingComments; s != "" {
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genStandaloneComments 2\n"))
		g.P(protogen.Comments(s))
		g.P()
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genStandaloneComments 2\n"))
	}
}

func genGeneratedHeader(gen *protogen.Plugin, g *protogen.GeneratedFile, f *fileInfo) {
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genGeneratedHeader 1\n"))
	g.P("// Code generated by protoc-gen-go. DO NOT EDIT.")
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genGeneratedHeader 1\n"))

	if GenerateVersionMarkers {
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genGeneratedHeader 2\n"))
		g.P("// versions:")
		protocGenGoVersion := version.String()
		protocVersion := "(unknown)"
		if v := gen.Request.GetCompilerVersion(); v != nil {
			protocVersion = fmt.Sprintf("v%v.%v.%v", v.GetMajor(), v.GetMinor(), v.GetPatch())
			if s := v.GetSuffix(); s != "" {
				protocVersion += "-" + s
			}
		}
		g.P("// \tprotoc-gen-go ", protocGenGoVersion)
		g.P("// \tprotoc        ", protocVersion)
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genGeneratedHeader 2\n"))
	}

	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genGeneratedHeader 3\n"))
	if f.Proto.GetOptions().GetDeprecated() {
		g.P("// ", f.Desc.Path(), " is a deprecated file.")
	} else {
		g.P("// source: ", f.Desc.Path())
	}
	g.P()
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genGeneratedHeader 3\n"))
}

func genImport(gen *protogen.Plugin, g *protogen.GeneratedFile, f *fileInfo, imp protoreflect.FileImport) {
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genImport 1\n"))
	impFile, ok := gen.FilesByPath[imp.Path()]
	if !ok {
		return
	}
	if impFile.GoImportPath == f.GoImportPath {
		// Don't generate imports or aliases for types in the same Go package.
		return
	}
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genImport 1\n"))
	
	// Generate imports for all dependencies, even if they are not
	// referenced, because other code and tools depend on having the
	// full transitive closure of protocol buffer types in the binary.
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genImport 2\n"))
	g.Import(impFile.GoImportPath)
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genImport 2\n"))
	
	if !imp.IsPublic {
		return
	}

	// Generate public imports by generating the imported file, parsing it,
	// and extracting every symbol that should receive a forwarding declaration.
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genImport 3\n"))
	impGens := generateFiles(gen, impFile)
	for _, impGen := range impGens {
		impGen.Skip()
	}
	b, err := impGens[0].Content()
	if err != nil {
		gen.Error(err)
		return
	}
	fset := token.NewFileSet()
	astFile, err := parser.ParseFile(fset, "", b, parser.ParseComments)
	if err != nil {
		gen.Error(err)
		return
	}
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genImport 3\n"))
	
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genImport 4\n"))
	genForward := func(tok token.Token, name string, expr ast.Expr) {
		// Don't import unexported symbols.
		r, _ := utf8.DecodeRuneInString(name)
		if !unicode.IsUpper(r) {
			return
		}
		// Don't import the FileDescriptor.
		if name == impFile.GoDescriptorIdent.GoName {
			return
		}
		// Don't import decls referencing a symbol defined in another package.
		// i.e., don't import decls which are themselves public imports:
		//
		//	type T = somepackage.T
		if _, ok := expr.(*ast.SelectorExpr); ok {
			return
		}
		g.P(tok, " ", name, " = ", impFile.GoImportPath.Ident(name))
	}
	g.P("// Symbols defined in public import of ", imp.Path(), ".")
	g.P()
	for _, decl := range astFile.Decls {
		switch decl := decl.(type) {
		case *ast.GenDecl:
			os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genImport 5\n"))
			for _, spec := range decl.Specs {
				switch spec := spec.(type) {
				case *ast.TypeSpec:
					os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genImport 6\n"))
					genForward(decl.Tok, spec.Name.Name, spec.Type)
					os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genImport 6\n"))
				case *ast.ValueSpec:
					os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genImport 7\n"))
					for i, name := range spec.Names {
						var expr ast.Expr
						if i < len(spec.Values) {
							expr = spec.Values[i]
						}
						genForward(decl.Tok, name.Name, expr)
						os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genImport 7\n"))
					}
				case *ast.ImportSpec:
				default:
					os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genImport 8\n"))
					panic(fmt.Sprintf("can't generate forward for spec type %T", spec))
					os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genImport 8\n"))
				}
			}
			os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genImport 5\n"))
		}
	}
	g.P()
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genImport 4\n"))
}

func genEnum(g *protogen.GeneratedFile, f *fileInfo, e *enumInfo) {
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genEnum 1\n"))
	// Enum type declaration.
	g.AnnotateSymbol(e.GoIdent.GoName, protogen.Annotation{Location: e.Location})
	leadingComments := appendDeprecationSuffix(e.Comments.Leading,
		e.Desc.ParentFile(),
		e.Desc.Options().(*descriptorpb.EnumOptions).GetDeprecated())
	g.P(leadingComments,
		"type ", e.GoIdent, " int32")
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genEnum 1\n"))

	// Enum value constants.
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genEnum 2\n"))
	g.P("const (")
	anyOldName := false
	for _, value := range e.Values {
		g.AnnotateSymbol(value.GoIdent.GoName, protogen.Annotation{Location: value.Location})
		leadingComments := appendDeprecationSuffix(value.Comments.Leading,
			value.Desc.ParentFile(),
			value.Desc.Options().(*descriptorpb.EnumValueOptions).GetDeprecated())
		g.P(leadingComments,
			value.GoIdent, " ", e.GoIdent, " = ", value.Desc.Number(),
			trailingComment(value.Comments.Trailing))

		if value.PrefixedAlias.GoName != "" &&
			value.PrefixedAlias.GoName != value.GoIdent.GoName {
			anyOldName = true
		}
	}
	g.P(")")
	g.P()
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genEnum 2\n"))
	
	if anyOldName {
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genEnum 3\n"))
		g.P("// Old (prefixed) names for ", e.GoIdent, " enum values.")
		g.P("const (")
		for _, value := range e.Values {
			if value.PrefixedAlias.GoName != "" &&
				value.PrefixedAlias.GoName != value.GoIdent.GoName {
				g.P(value.PrefixedAlias, " ", e.GoIdent, " = ", value.GoIdent)
			}
		}
		g.P(")")
		g.P()
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genEnum 3\n"))
	}

	// Enum value maps.
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genEnum 4\n"))
	g.P("// Enum value maps for ", e.GoIdent, ".")
	g.P("var (")
	g.P(e.GoIdent.GoName+"_name", " = map[int32]string{")
	for _, value := range e.Values {
		duplicate := ""
		if value.Desc != e.Desc.Values().ByNumber(value.Desc.Number()) {
			duplicate = "// Duplicate value: "
		}
		g.P(duplicate, value.Desc.Number(), ": ", strconv.Quote(string(value.Desc.Name())), ",")
	}
	g.P("}")
	g.P(e.GoIdent.GoName+"_value", " = map[string]int32{")
	for _, value := range e.Values {
		g.P(strconv.Quote(string(value.Desc.Name())), ": ", value.Desc.Number(), ",")
	}
	g.P("}")
	g.P(")")
	g.P()
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genEnum 4\n"))

	// Enum method.
	//
	// NOTE: A pointer value is needed to represent presence in proto2.
	// Since a proto2 message can reference a proto3 enum, it is useful to
	// always generate this method (even on proto3 enums) to support that case.
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genEnum 5\n"))
	g.P("func (x ", e.GoIdent, ") Enum() *", e.GoIdent, " {")
	g.P("p := new(", e.GoIdent, ")")
	g.P("*p = x")
	g.P("return p")
	g.P("}")
	g.P()
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genEnum 5\n"))

	// String method.
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genEnum 6\n"))
	g.P("func (x ", e.GoIdent, ") String() string {")
	g.P("return ", protoimplPackage.Ident("X"), ".EnumStringOf(x.Descriptor(), ", protoreflectPackage.Ident("EnumNumber"), "(x))")
	g.P("}")
	g.P()
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genEnum 6\n"))

	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genEnum 7\n"))
	genEnumReflectMethods(g, f, e)
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genEnum 7\n"))

	// UnmarshalJSON method.
	needsUnmarshalJSONMethod := false
	if fde, ok := e.Desc.(*filedesc.Enum); ok {
		needsUnmarshalJSONMethod = fde.L1.EditionFeatures.GenerateLegacyUnmarshalJSON
	}
	if e.genJSONMethod && needsUnmarshalJSONMethod {
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genEnum 8\n"))
		g.P("// Deprecated: Do not use.")
		g.P("func (x *", e.GoIdent, ") UnmarshalJSON(b []byte) error {")
		g.P("num, err := ", protoimplPackage.Ident("X"), ".UnmarshalJSONEnum(x.Descriptor(), b)")
		g.P("if err != nil {")
		g.P("return err")
		g.P("}")
		g.P("*x = ", e.GoIdent, "(num)")
		g.P("return nil")
		g.P("}")
		g.P()
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genEnum 8\n"))
	}

	// EnumDescriptor method.
	if e.genRawDescMethod {
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genEnum 9\n"))
		var indexes []string
		for i := 1; i < len(e.Location.Path); i += 2 {
			indexes = append(indexes, strconv.Itoa(int(e.Location.Path[i])))
		}
		g.P("// Deprecated: Use ", e.GoIdent, ".Descriptor instead.")
		g.P("func (", e.GoIdent, ") EnumDescriptor() ([]byte, []int) {")
		g.P("return ", rawDescVarName(f), "GZIP(), []int{", strings.Join(indexes, ","), "}")
		g.P("}")
		g.P()
		f.needRawDesc = true
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genEnum 9\n"))
	}
}

func genMessage(g *protogen.GeneratedFile, f *fileInfo, m *messageInfo) {
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessage 1\n"))
	if m.Desc.IsMapEntry() {
		return
	}
	if opaqueGenMessageHook(g, f, m) {
		return
	}
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessage 1\n"))

	// Message type declaration.
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessage 2\n"))
	g.AnnotateSymbol(m.GoIdent.GoName, protogen.Annotation{Location: m.Location})
	leadingComments := appendDeprecationSuffix(m.Comments.Leading,
		m.Desc.ParentFile(),
		m.Desc.Options().(*descriptorpb.MessageOptions).GetDeprecated())
	g.P(leadingComments,
		"type ", m.GoIdent, " struct {")
	genMessageFields(g, f, m)
	g.P("}")
	g.P()
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessage 2\n"))

	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessage 3\n"))
	genMessageKnownFunctions(g, f, m)
	genMessageDefaultDecls(g, f, m)
	genMessageMethods(g, f, m)
	genMessageOneofWrapperTypes(g, f, m)
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessage 3\n"))
}

func genMessageFields(g *protogen.GeneratedFile, f *fileInfo, m *messageInfo) {
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageFields 1\n"))
	sf := f.allMessageFieldsByPtr[m]
	genMessageInternalFields(g, f, m, sf)
	for _, field := range m.Fields {
		genMessageField(g, f, m, field, sf)
	}
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageFields 1\n"))
}

func genMessageInternalFields(g *protogen.GeneratedFile, f *fileInfo, m *messageInfo, sf *structFields) {
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageInternalFields 1\n"))
	g.P(genid.State_goname, " ", protoimplPackage.Ident("MessageState"))
	sf.append(genid.State_goname)
	g.P(genid.SizeCache_goname, " ", protoimplPackage.Ident("SizeCache"))
	sf.append(genid.SizeCache_goname)
	g.P(genid.UnknownFields_goname, " ", protoimplPackage.Ident("UnknownFields"))
	sf.append(genid.UnknownFields_goname)
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageInternalFields 1\n"))
	
	if m.Desc.ExtensionRanges().Len() > 0 {
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageInternalFields 2\n"))
		g.P(genid.ExtensionFields_goname, " ", protoimplPackage.Ident("ExtensionFields"))
		sf.append(genid.ExtensionFields_goname)
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageInternalFields 2\n"))
	}
	
	if sf.count > 0 {
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageInternalFields 3\n"))
		g.P()
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageInternalFields 3\n"))
	}
}

func genMessageField(g *protogen.GeneratedFile, f *fileInfo, m *messageInfo, field *protogen.Field, sf *structFields) {
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageField 1\n"))
	if oneof := field.Oneof; oneof != nil && !oneof.Desc.IsSynthetic() {
		// It would be a bit simpler to iterate over the oneofs below,
		// but generating the field here keeps the contents of the Go
		// struct in the same order as the contents of the source
		// .proto file.
		if oneof.Fields[0] != field {
			return // only generate for first appearance
		}

		tags := structTags{
			{"protobuf_oneof", string(oneof.Desc.Name())},
		}
		if m.isTracked {
			tags = append(tags, gotrackTags...)
		}

		g.AnnotateSymbol(m.GoIdent.GoName+"."+oneof.GoName, protogen.Annotation{Location: oneof.Location})
		leadingComments := oneof.Comments.Leading
		if leadingComments != "" {
			leadingComments += "\n"
		}
		ss := []string{fmt.Sprintf(" Types that are assignable to %s:\n", oneof.GoName)}
		for _, field := range oneof.Fields {
			ss = append(ss, "\t*"+field.GoIdent.GoName+"\n")
		}
		leadingComments += protogen.Comments(strings.Join(ss, ""))
		g.P(leadingComments,
			oneof.GoName, " ", oneofInterfaceName(oneof), tags)
		sf.append(oneof.GoName)
		return
	}
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageField 1\n"))
	
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageField 2\n"))
	goType, pointer := fieldGoType(g, f, field)
	if pointer {
		goType = "*" + goType
	}
	tags := structTags{
		{"protobuf", fieldProtobufTagValue(field)},
		{"json", fieldJSONTagValue(field)},
	}
	if field.Desc.IsMap() {
		key := field.Message.Fields[0]
		val := field.Message.Fields[1]
		tags = append(tags, structTags{
			{"protobuf_key", fieldProtobufTagValue(key)},
			{"protobuf_val", fieldProtobufTagValue(val)},
		}...)
	}
	if m.isTracked {
		tags = append(tags, gotrackTags...)
	}

	name := field.GoName
	g.AnnotateSymbol(m.GoIdent.GoName+"."+name, protogen.Annotation{Location: field.Location})
	leadingComments := appendDeprecationSuffix(field.Comments.Leading,
		field.Desc.ParentFile(),
		field.Desc.Options().(*descriptorpb.FieldOptions).GetDeprecated())
	g.P(leadingComments,
		name, " ", goType, tags,
		trailingComment(field.Comments.Trailing))
	sf.append(field.GoName)
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageField 2\n"))
}

// genMessageDefaultDecls generates consts and vars holding the default
// values of fields.
func genMessageDefaultDecls(g *protogen.GeneratedFile, f *fileInfo, m *messageInfo) {
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageDefaultDecls 1\n"))
	var consts, vars []string
	for _, field := range m.Fields {
		if !field.Desc.HasDefault() {
			continue
		}
		name := "Default_" + m.GoIdent.GoName + "_" + field.GoName
		goType, _ := fieldGoType(g, f, field)
		defVal := field.Desc.Default()
		switch field.Desc.Kind() {
		case protoreflect.StringKind:
			consts = append(consts, fmt.Sprintf("%s = %s(%q)", name, goType, defVal.String()))
		case protoreflect.BytesKind:
			vars = append(vars, fmt.Sprintf("%s = %s(%q)", name, goType, defVal.Bytes()))
		case protoreflect.EnumKind:
			idx := field.Desc.DefaultEnumValue().Index()
			val := field.Enum.Values[idx]
			if val.GoIdent.GoImportPath == f.GoImportPath {
				consts = append(consts, fmt.Sprintf("%s = %s", name, g.QualifiedGoIdent(val.GoIdent)))
			} else {
				// If the enum value is declared in a different Go package,
				// reference it by number since the name may not be correct.
				// See https://github.com/golang/protobuf/issues/513.
				consts = append(consts, fmt.Sprintf("%s = %s(%d) // %s",
					name, g.QualifiedGoIdent(field.Enum.GoIdent), val.Desc.Number(), g.QualifiedGoIdent(val.GoIdent)))
			}
		case protoreflect.FloatKind, protoreflect.DoubleKind:
			if f := defVal.Float(); math.IsNaN(f) || math.IsInf(f, 0) {
				var fn, arg string
				switch f := defVal.Float(); {
				case math.IsInf(f, -1):
					fn, arg = g.QualifiedGoIdent(mathPackage.Ident("Inf")), "-1"
				case math.IsInf(f, +1):
					fn, arg = g.QualifiedGoIdent(mathPackage.Ident("Inf")), "+1"
				case math.IsNaN(f):
					fn, arg = g.QualifiedGoIdent(mathPackage.Ident("NaN")), ""
				}
				vars = append(vars, fmt.Sprintf("%s = %s(%s(%s))", name, goType, fn, arg))
			} else {
				consts = append(consts, fmt.Sprintf("%s = %s(%v)", name, goType, f))
			}
		default:
			consts = append(consts, fmt.Sprintf("%s = %s(%v)", name, goType, defVal.Interface()))
		}
	}
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageDefaultDecls 1\n"))
	
	if len(consts) > 0 {
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageDefaultDecls 2\n"))
		g.P("// Default values for ", m.GoIdent, " fields.")
		g.P("const (")
		for _, s := range consts {
			g.P(s)
		}
		g.P(")")
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageDefaultDecls 2\n"))
	}
	
	if len(vars) > 0 {
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageDefaultDecls 3\n"))
		g.P("// Default values for ", m.GoIdent, " fields.")
		g.P("var (")
		for _, s := range vars {
			g.P(s)
		}
		g.P(")")
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageDefaultDecls 3\n"))
	}
	
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageDefaultDecls 4\n"))
	g.P()
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageDefaultDecls 4\n"))
}

func genMessageMethods(g *protogen.GeneratedFile, f *fileInfo, m *messageInfo) {
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageMethods 1\n"))
	genMessageBaseMethods(g, f, m)
	genMessageGetterMethods(g, f, m)
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageMethods 1\n"))
}
func genMessageBaseMethods(g *protogen.GeneratedFile, f *fileInfo, m *messageInfo) {
	// Reset method.
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageBaseMethods 1\n"))
	g.P("func (x *", m.GoIdent, ") Reset() {")
	g.P("*x = ", m.GoIdent, "{}")
	g.P("mi := &", messageTypesVarName(f), "[", f.allMessagesByPtr[m], "]")
	g.P("ms := ", protoimplPackage.Ident("X"), ".MessageStateOf(", protoimplPackage.Ident("Pointer"), "(x))")
	g.P("ms.StoreMessageInfo(mi)")
	g.P("}")
	g.P()
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageBaseMethods 1\n"))

	// String method.
	g.P("func (x *", m.GoIdent, ") String() string {")
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageBaseMethods 2\n"))
	g.P("return ", protoimplPackage.Ident("X"), ".MessageStringOf(x)")
	g.P("}")
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageBaseMethods 2\n"))
	g.P()

	// ProtoMessage method.
	g.P("func (*", m.GoIdent, ") ProtoMessage() {}")
	g.P()

	// ProtoReflect method.
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageBaseMethods 3\n"))
	genMessageReflectMethods(g, f, m)
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageBaseMethods 3\n"))

	// Descriptor method.
	if m.genRawDescMethod {
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageBaseMethods 4\n"))
		var indexes []string
		for i := 1; i < len(m.Location.Path); i += 2 {
			indexes = append(indexes, strconv.Itoa(int(m.Location.Path[i])))
		}
		g.P("// Deprecated: Use ", m.GoIdent, ".ProtoReflect.Descriptor instead.")
		g.P("func (*", m.GoIdent, ") Descriptor() ([]byte, []int) {")
		g.P("return ", rawDescVarName(f), "GZIP(), []int{", strings.Join(indexes, ","), "}")
		g.P("}")
		g.P()
		f.needRawDesc = true
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageBaseMethods 4\n"))
	}
}

func genMessageGetterMethods(g *protogen.GeneratedFile, f *fileInfo, m *messageInfo) {
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageGetterMethods 1\n"))
	for _, field := range m.Fields {
		genNoInterfacePragma(g, m.isTracked)

		// Getter for parent oneof.
		if oneof := field.Oneof; oneof != nil && oneof.Fields[0] == field && !oneof.Desc.IsSynthetic() {
			os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageGetterMethods 2\n"))
			g.AnnotateSymbol(m.GoIdent.GoName+".Get"+oneof.GoName, protogen.Annotation{Location: oneof.Location})
			g.P("func (m *", m.GoIdent.GoName, ") Get", oneof.GoName, "() ", oneofInterfaceName(oneof), " {")
			g.P("if m != nil {")
			g.P("return m.", oneof.GoName)
			g.P("}")
			g.P("return nil")
			g.P("}")
			g.P()
			os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageGetterMethods 2\n"))
		}

		// Getter for message field.
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageGetterMethods 3\n"))
		goType, pointer := fieldGoType(g, f, field)
		defaultValue := fieldDefaultValue(g, f, m, field)
		g.AnnotateSymbol(m.GoIdent.GoName+".Get"+field.GoName, protogen.Annotation{Location: field.Location})
		leadingComments := appendDeprecationSuffix("",
			field.Desc.ParentFile(),
			field.Desc.Options().(*descriptorpb.FieldOptions).GetDeprecated())
		switch {
		case field.Oneof != nil && !field.Oneof.Desc.IsSynthetic():
			os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageGetterMethods 4\n"))
			g.P(leadingComments, "func (x *", m.GoIdent, ") Get", field.GoName, "() ", goType, " {")
			g.P("if x, ok := x.Get", field.Oneof.GoName, "().(*", field.GoIdent, "); ok {")
			g.P("return x.", field.GoName)
			g.P("}")
			g.P("return ", defaultValue)
			g.P("}")
			os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageGetterMethods 4\n"))
		default:
			os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageGetterMethods 5\n"))
			g.P(leadingComments, "func (x *", m.GoIdent, ") Get", field.GoName, "() ", goType, " {")
			if !field.Desc.HasPresence() || defaultValue == "nil" {
				g.P("if x != nil {")
			} else {
				g.P("if x != nil && x.", field.GoName, " != nil {")
			}
			star := ""
			if pointer {
				star = "*"
			}
			g.P("return ", star, " x.", field.GoName)
			g.P("}")
			g.P("return ", defaultValue)
			g.P("}")
			os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageGetterMethods 5\n"))
		}
		g.P()
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageGetterMethods 3\n"))
	}
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageGetterMethods 1\n"))
}

// fieldGoType returns the Go type used for a field.
//
// If it returns pointer=true, the struct field is a pointer to the type.
func fieldGoType(g *protogen.GeneratedFile, f *fileInfo, field *protogen.Field) (goType string, pointer bool) {
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter fieldGoType 1\n"))
	pointer = field.Desc.HasPresence()
	switch field.Desc.Kind() {
	case protoreflect.BoolKind:
		goType = "bool"
	case protoreflect.EnumKind:
		goType = g.QualifiedGoIdent(field.Enum.GoIdent)
	case protoreflect.Int32Kind, protoreflect.Sint32Kind, protoreflect.Sfixed32Kind:
		goType = "int32"
	case protoreflect.Uint32Kind, protoreflect.Fixed32Kind:
		goType = "uint32"
	case protoreflect.Int64Kind, protoreflect.Sint64Kind, protoreflect.Sfixed64Kind:
		goType = "int64"
	case protoreflect.Uint64Kind, protoreflect.Fixed64Kind:
		goType = "uint64"
	case protoreflect.FloatKind:
		goType = "float32"
	case protoreflect.DoubleKind:
		goType = "float64"
	case protoreflect.StringKind:
		goType = "string"
	case protoreflect.BytesKind:
		goType = "[]byte"
		pointer = false // rely on nullability of slices for presence
	case protoreflect.MessageKind, protoreflect.GroupKind:
		goType = "*" + g.QualifiedGoIdent(field.Message.GoIdent)
		pointer = false // pointer captured as part of the type
	}
	switch {
	case field.Desc.IsList():
		return "[]" + goType, false
	case field.Desc.IsMap():
		keyType, _ := fieldGoType(g, f, field.Message.Fields[0])
		valType, _ := fieldGoType(g, f, field.Message.Fields[1])
		return fmt.Sprintf("map[%v]%v", keyType, valType), false
	}
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit fieldGoType 1\n"))
	return goType, pointer
}

func fieldProtobufTagValue(field *protogen.Field) string {
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter fieldProtobufTagValue 1\n"))
	var enumName string
	if field.Desc.Kind() == protoreflect.EnumKind {
		enumName = protoimpl.X.LegacyEnumName(field.Enum.Desc)
	}
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit fieldProtobufTagValue 1\n"))
	return tag.Marshal(field.Desc, enumName)
}

func fieldDefaultValue(g *protogen.GeneratedFile, f *fileInfo, m *messageInfo, field *protogen.Field) string {
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter fieldDefaultValue 1\n"))
	if field.Desc.IsList() {
		return "nil"
	}
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit fieldDefaultValue 1\n"))
	if field.Desc.HasDefault() {
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter fieldDefaultValue 2\n"))
		defVarName := "Default_" + m.GoIdent.GoName + "_" + field.GoName
		if field.Desc.Kind() == protoreflect.BytesKind {
			return "append([]byte(nil), " + defVarName + "...)"
		}
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit fieldDefaultValue 2\n"))
		return defVarName
	}
	switch field.Desc.Kind() {
	case protoreflect.BoolKind:
		return "false"
	case protoreflect.StringKind:
		return `""`
	case protoreflect.MessageKind, protoreflect.GroupKind, protoreflect.BytesKind:
		return "nil"
	case protoreflect.EnumKind:
		val := field.Enum.Values[0]
		if val.GoIdent.GoImportPath == f.GoImportPath {
			return g.QualifiedGoIdent(val.GoIdent)
		} else {
			// If the enum value is declared in a different Go package,
			// reference it by number since the name may not be correct.
			// See https://github.com/golang/protobuf/issues/513.
			return g.QualifiedGoIdent(field.Enum.GoIdent) + "(" + strconv.FormatInt(int64(val.Desc.Number()), 10) + ")"
		}
	default:
		return "0"
	}
}

func fieldJSONTagValue(field *protogen.Field) string {
	return string(field.Desc.Name()) + ",omitempty"
}

func genExtensions(g *protogen.GeneratedFile, f *fileInfo) {
	if len(f.allExtensions) == 0 {
		return
	}

	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genExtensions 1\n"))
	g.P("var ", extensionTypesVarName(f), " = []", protoimplPackage.Ident("ExtensionInfo"), "{")
	for _, x := range f.allExtensions {
		g.P("{")
		g.P("ExtendedType: (*", x.Extendee.GoIdent, ")(nil),")
		goType, pointer := fieldGoType(g, f, x.Extension)
		if pointer {
			goType = "*" + goType
		}
		g.P("ExtensionType: (", goType, ")(nil),")
		g.P("Field: ", x.Desc.Number(), ",")
		g.P("Name: ", strconv.Quote(string(x.Desc.FullName())), ",")
		g.P("Tag: ", strconv.Quote(fieldProtobufTagValue(x.Extension)), ",")
		g.P("Filename: ", strconv.Quote(f.Desc.Path()), ",")
		g.P("},")
	}
	g.P("}")
	g.P()
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genExtensions 1\n"))

	// Group extensions by the target message.
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genExtensions 2\n"))
	var orderedTargets []protogen.GoIdent
	allExtensionsByTarget := make(map[protogen.GoIdent][]*extensionInfo)
	allExtensionsByPtr := make(map[*extensionInfo]int)
	for i, x := range f.allExtensions {
		target := x.Extendee.GoIdent
		if len(allExtensionsByTarget[target]) == 0 {
			orderedTargets = append(orderedTargets, target)
		}
		allExtensionsByTarget[target] = append(allExtensionsByTarget[target], x)
		allExtensionsByPtr[x] = i
	}
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genExtensions 2\n"))
	
	for _, target := range orderedTargets {
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genExtensions 3\n"))
		g.P("// Extension fields to ", target, ".")
		g.P("var (")
		for _, x := range allExtensionsByTarget[target] {
			xd := x.Desc
			typeName := xd.Kind().String()
			switch xd.Kind() {
			case protoreflect.EnumKind:
				typeName = string(xd.Enum().FullName())
			case protoreflect.MessageKind, protoreflect.GroupKind:
				typeName = string(xd.Message().FullName())
			}
			fieldName := string(xd.Name())

			leadingComments := x.Comments.Leading
			if leadingComments != "" {
				leadingComments += "\n"
			}
			leadingComments += protogen.Comments(fmt.Sprintf(" %v %v %v = %v;\n",
				xd.Cardinality(), typeName, fieldName, xd.Number()))
			leadingComments = appendDeprecationSuffix(leadingComments,
				x.Desc.ParentFile(),
				x.Desc.Options().(*descriptorpb.FieldOptions).GetDeprecated())
			g.P(leadingComments,
				"E_", x.GoIdent, " = &", extensionTypesVarName(f), "[", allExtensionsByPtr[x], "]",
				trailingComment(x.Comments.Trailing))
		}
		g.P(")")
		g.P()
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genExtensions 3\n"))
	}
}

// genMessageOneofWrapperTypes generates the oneof wrapper types and
// associates the types with the parent message type.
func genMessageOneofWrapperTypes(g *protogen.GeneratedFile, f *fileInfo, m *messageInfo) {
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageOneofWrapperTypes 1\n"))
	for _, oneof := range m.Oneofs {
		if oneof.Desc.IsSynthetic() {
			continue
		}
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageOneofWrapperTypes 2\n"))
		ifName := oneofInterfaceName(oneof)
		g.P("type ", ifName, " interface {")
		g.P(ifName, "()")
		g.P("}")
		g.P()
		os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageOneofWrapperTypes 2\n"))
		
		for _, field := range oneof.Fields {
			os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageOneofWrapperTypes 3\n"))
			g.AnnotateSymbol(field.GoIdent.GoName, protogen.Annotation{Location: field.Location})
			g.AnnotateSymbol(field.GoIdent.GoName+"."+field.GoName, protogen.Annotation{Location: field.Location})
			g.P("type ", field.GoIdent, " struct {")
			goType, _ := fieldGoType(g, f, field)
			tags := structTags{
				{"protobuf", fieldProtobufTagValue(field)},
			}
			if m.isTracked {
				tags = append(tags, gotrackTags...)
			}
			leadingComments := appendDeprecationSuffix(field.Comments.Leading,
				field.Desc.ParentFile(),
				field.Desc.Options().(*descriptorpb.FieldOptions).GetDeprecated())
			g.P(leadingComments,
				field.GoName, " ", goType, tags,
				trailingComment(field.Comments.Trailing))
			g.P("}")
			g.P()
			os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageOneofWrapperTypes 3\n"))
		}
		
		for _, field := range oneof.Fields {
			os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genMessageOneofWrapperTypes 4\n"))
			g.P("func (*", field.GoIdent, ") ", ifName, "() {}")
			g.P()
			os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageOneofWrapperTypes 4\n"))
		}
	}
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genMessageOneofWrapperTypes 1\n"))
}

// oneofInterfaceName returns the name of the interface type implemented by
// the oneof field value types.
func oneofInterfaceName(oneof *protogen.Oneof) string {
	os.Stderr.Write([]byte("\n"))
	os.Stderr.Write([]byte("\n"))
	return "is" + oneof.GoIdent.GoName
}

// genNoInterfacePragma generates a standalone "nointerface" pragma to
// decorate methods with field-tracking support.
func genNoInterfacePragma(g *protogen.GeneratedFile, tracked bool) {
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter genNoInterfacePragma 1\n"))
	if tracked {
		g.P("//go:nointerface")
		g.P()
	}
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit genNoInterfacePragma 1\n"))
}

var gotrackTags = structTags{{"go", "track"}}

// structTags is a data structure for build idiomatic Go struct tags.
// Each [2]string is a key-value pair, where value is the unescaped string.
//
// Example: structTags{{"key", "value"}}.String() -> `key:"value"`
type structTags [][2]string

func (tags structTags) String() string {
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter structTags.String 1\n"))
	if len(tags) == 0 {
		return ""
	}
	var ss []string
	for _, tag := range tags {
		// NOTE: When quoting the value, we need to make sure the backtick
		// character does not appear. Convert all cases to the escaped hex form.
		key := tag[0]
		val := strings.Replace(strconv.Quote(tag[1]), "`", `\x60`, -1)
		ss = append(ss, fmt.Sprintf("%s:%s", key, val))
	}
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit structTags.String 1\n"))
	return "`" + strings.Join(ss, " ") + "`"
}

// appendDeprecationSuffix optionally appends a deprecation notice as a suffix.
func appendDeprecationSuffix(prefix protogen.Comments, parentFile protoreflect.FileDescriptor, deprecated bool) protogen.Comments {
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter appendDeprecationSuffix 1\n"))
	fileDeprecated := parentFile.Options().(*descriptorpb.FileOptions).GetDeprecated()
	if !deprecated && !fileDeprecated {
		return prefix
	}
	if prefix != "" {
		prefix += "\n"
	}
	if fileDeprecated {
		return prefix + " Deprecated: The entire proto file " + protogen.Comments(parentFile.Path()) + " is marked as deprecated.\n"
	}
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit appendDeprecationSuffix 1\n"))
	return prefix + " Deprecated: Marked as deprecated in " + protogen.Comments(parentFile.Path()) + ".\n"
}

// trailingComment is like protogen.Comments, but lacks a trailing newline.
type trailingComment protogen.Comments

func (c trailingComment) String() string {
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] enter trailingComment.String 1\n"))
	s := strings.TrimSuffix(protogen.Comments(c).String(), "\n")
	if strings.Contains(s, "\n") {
		// We don't support multi-lined trailing comments as it is unclear
		// how to best render them in the generated code.
		return ""
	}
	os.Stderr.Write([]byte("[protobuf-go/cmd/protoc-gen-go/internal_gengo/main.go] exit trailingComment.String 1\n"))
	return s
}
// Total cost: 0.518057
// Total split cost: 0.181717, input tokens: 41505, output tokens: 969, cache read tokens: 2696, cache write tokens: 13319, split chunks: [(0, 585), (585, 932)]
// Total instrumented cost: 0.336340, input tokens: 16417, output tokens: 15037, cache read tokens: 0, cache write tokens: 16409

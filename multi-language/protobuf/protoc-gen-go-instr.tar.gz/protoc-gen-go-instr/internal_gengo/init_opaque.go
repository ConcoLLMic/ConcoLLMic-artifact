// Copyright 2024 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package internal_gengo

import (
	"fmt"
	"os"
	"google.golang.org/protobuf/types/gofeaturespb"
)

func (m *messageInfo) isOpen() bool {
	return m.Message.APILevel == gofeaturespb.GoFeatures_API_OPEN
}

func (m *messageInfo) isHybrid() bool {
	return m.Message.APILevel == gofeaturespb.GoFeatures_API_HYBRID
}

func (m *messageInfo) isOpaque() bool {
	return m.Message.APILevel == gofeaturespb.GoFeatures_API_OPAQUE
}

func opaqueNewEnumInfoHook(f *fileInfo, e *enumInfo) {
	fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init_opaque.go] enter opaqueNewEnumInfoHook 1\n")
	if f.File.APILevel != gofeaturespb.GoFeatures_API_OPEN {
		fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init_opaque.go] enter opaqueNewEnumInfoHook 2\n")
		e.genJSONMethod = false
		e.genRawDescMethod = false
		fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init_opaque.go] exit opaqueNewEnumInfoHook 2\n")
	}
	fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init_opaque.go] exit opaqueNewEnumInfoHook 1\n")
}

func opaqueNewMessageInfoHook(f *fileInfo, m *messageInfo) {
	fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init_opaque.go] enter opaqueNewMessageInfoHook 1\n")
	if !m.isOpen() {
		fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init_opaque.go] enter opaqueNewMessageInfoHook 2\n")
		m.genRawDescMethod = false
		m.genExtRangeMethod = false
		fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init_opaque.go] exit opaqueNewMessageInfoHook 2\n")
	}
	fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init_opaque.go] exit opaqueNewMessageInfoHook 1\n")
}
// Total cost: 0.013865
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 33)]
// Total instrumented cost: 0.013865, input tokens: 2655, output tokens: 711, cache read tokens: 2280, cache write tokens: 371

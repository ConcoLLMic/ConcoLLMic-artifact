// Copyright 2018 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package internal_gengo

import (
	"bytes"
	"fmt"
	"math"
	"os"
	"strings"
	"unicode/utf8"

	"google.golang.org/protobuf/compiler/protogen"
	"google.golang.org/protobuf/proto"
	"google.golang.org/protobuf/reflect/protopath"
	"google.golang.org/protobuf/reflect/protorange"
	"google.golang.org/protobuf/reflect/protoreflect"

	"google.golang.org/protobuf/types/descriptorpb"
)

func genReflectFileDescriptor(gen *protogen.Plugin, g *protogen.GeneratedFile, f *fileInfo) {
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 1\n")
	g.P("var ", f.GoDescriptorIdent, " ", protoreflectPackage.Ident("FileDescriptor"))
	g.P()
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 1\n")

	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 2\n")
	genFileDescriptor(gen, g, f)
	if len(f.allEnums) > 0 {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 3\n")
		g.P("var ", enumTypesVarName(f), " = make([]", protoimplPackage.Ident("EnumInfo"), ",", len(f.allEnums), ")")
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 3\n")
	}
	if len(f.allMessages) > 0 {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 4\n")
		g.P("var ", messageTypesVarName(f), " = make([]", protoimplPackage.Ident("MessageInfo"), ",", len(f.allMessages), ")")
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 4\n")
	}
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 2\n")

	// Generate a unique list of Go types for all declarations and dependencies,
	// and the associated index into the type list for all dependencies.
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 5\n")
	var goTypes []string
	var depIdxs []string
	seen := map[protoreflect.FullName]int{}
	genDep := func(name protoreflect.FullName, depSource string) {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor.genDep 1\n")
		if depSource != "" {
			os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor.genDep 2\n")
			line := fmt.Sprintf("%d, // %d: %s -> %s", seen[name], len(depIdxs), depSource, name)
			depIdxs = append(depIdxs, line)
			os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor.genDep 2\n")
		}
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor.genDep 1\n")
	}
	genEnum := func(e *protogen.Enum, depSource string) {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor.genEnum 1\n")
		if e != nil {
			os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor.genEnum 2\n")
			name := e.Desc.FullName()
			if _, ok := seen[name]; !ok {
				os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor.genEnum 3\n")
				line := fmt.Sprintf("(%s)(0), // %d: %s", g.QualifiedGoIdent(e.GoIdent), len(goTypes), name)
				goTypes = append(goTypes, line)
				seen[name] = len(seen)
				os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor.genEnum 3\n")
			}
			if depSource != "" {
				os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor.genEnum 4\n")
				genDep(name, depSource)
				os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor.genEnum 4\n")
			}
			os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor.genEnum 2\n")
		}
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor.genEnum 1\n")
	}
	genMessage := func(m *protogen.Message, depSource string) {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor.genMessage 1\n")
		if m != nil {
			os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor.genMessage 2\n")
			name := m.Desc.FullName()
			if _, ok := seen[name]; !ok {
				os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor.genMessage 3\n")
				line := fmt.Sprintf("(*%s)(nil), // %d: %s", g.QualifiedGoIdent(m.GoIdent), len(goTypes), name)
				if m.Desc.IsMapEntry() {
					os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor.genMessage 4\n")
					// Map entry messages have no associated Go type.
					line = fmt.Sprintf("nil, // %d: %s", len(goTypes), name)
					os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor.genMessage 4\n")
				}
				goTypes = append(goTypes, line)
				seen[name] = len(seen)
				os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor.genMessage 3\n")
			}
			if depSource != "" {
				os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor.genMessage 5\n")
				genDep(name, depSource)
				os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor.genMessage 5\n")
			}
			os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor.genMessage 2\n")
		}
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor.genMessage 1\n")
	}
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 5\n")

	// This ordering is significant.
	// See filetype.TypeBuilder.DependencyIndexes.
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 6\n")
	type offsetEntry struct {
		start int
		name  string
	}
	var depOffsets []offsetEntry
	for _, enum := range f.allEnums {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 7\n")
		genEnum(enum.Enum, "")
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 7\n")
	}
	for _, message := range f.allMessages {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 8\n")
		genMessage(message.Message, "")
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 8\n")
	}
	depOffsets = append(depOffsets, offsetEntry{len(depIdxs), "field type_name"})
	for _, message := range f.allMessages {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 9\n")
		for _, field := range message.Fields {
			os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 10\n")
			source := string(field.Desc.FullName())
			genEnum(field.Enum, source+":type_name")
			genMessage(field.Message, source+":type_name")
			os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 10\n")
		}
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 9\n")
	}
	depOffsets = append(depOffsets, offsetEntry{len(depIdxs), "extension extendee"})
	for _, extension := range f.allExtensions {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 11\n")
		source := string(extension.Desc.FullName())
		genMessage(extension.Extendee, source+":extendee")
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 11\n")
	}
	depOffsets = append(depOffsets, offsetEntry{len(depIdxs), "extension type_name"})
	for _, extension := range f.allExtensions {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 12\n")
		source := string(extension.Desc.FullName())
		genEnum(extension.Enum, source+":type_name")
		genMessage(extension.Message, source+":type_name")
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 12\n")
	}
	depOffsets = append(depOffsets, offsetEntry{len(depIdxs), "method input_type"})
	for _, service := range f.Services {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 13\n")
		for _, method := range service.Methods {
			os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 14\n")
			source := string(method.Desc.FullName())
			genMessage(method.Input, source+":input_type")
			os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 14\n")
		}
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 13\n")
	}
	depOffsets = append(depOffsets, offsetEntry{len(depIdxs), "method output_type"})
	for _, service := range f.Services {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 15\n")
		for _, method := range service.Methods {
			os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 16\n")
			source := string(method.Desc.FullName())
			genMessage(method.Output, source+":output_type")
			os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 16\n")
		}
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 15\n")
	}
	depOffsets = append(depOffsets, offsetEntry{len(depIdxs), ""})
	for i := len(depOffsets) - 2; i >= 0; i-- {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 17\n")
		curr, next := depOffsets[i], depOffsets[i+1]
		depIdxs = append(depIdxs, fmt.Sprintf("%d, // [%d:%d] is the sub-list for %s",
			curr.start, curr.start, next.start, curr.name))
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 17\n")
	}
	if len(depIdxs) > math.MaxInt32 {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 18\n")
		panic("too many dependencies") // sanity check
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 18\n")
	}
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 6\n")

	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 19\n")
	g.P("var ", goTypesVarName(f), " = []any{")
	for _, s := range goTypes {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 20\n")
		g.P(s)
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 20\n")
	}
	g.P("}")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 19\n")

	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 21\n")
	g.P("var ", depIdxsVarName(f), " = []int32{")
	for _, s := range depIdxs {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 22\n")
		g.P(s)
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 22\n")
	}
	g.P("}")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 21\n")

	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 23\n")
	g.P("func init() { ", initFuncName(f.File), "() }")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 23\n")

	os.Stderr.WriteString("\n")
	g.P("func ", initFuncName(f.File), "() {")
	g.P("if ", f.GoDescriptorIdent, " != nil {")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 25\n")
	g.P("return")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 25\n")
	g.P("}")

	// Ensure that initialization functions for different files in the same Go
	// package run in the correct order: Call the init funcs for every .proto file
	// imported by this one that is in the same Go package.
	for i, imps := 0, f.Desc.Imports(); i < imps.Len(); i++ {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 26\n")
		impFile := gen.FilesByPath[imps.Get(i).Path()]
		if impFile.GoImportPath != f.GoImportPath {
			os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 27\n")
			continue
			os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 27\n")
		}
		g.P(initFuncName(impFile), "()")
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 26\n")
	}

	if len(f.allMessages) > 0 {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 28\n")
		// Populate MessageInfo.OneofWrappers.
		for _, message := range f.allMessages {
			os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 29\n")
			if len(message.Oneofs) > 0 {
				os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 30\n")
				idx := f.allMessagesByPtr[message]
				typesVar := messageTypesVarName(f)

				// Associate the wrapper types by directly passing them to the MessageInfo.
				g.P(typesVar, "[", idx, "].OneofWrappers = []any {")
				for _, oneof := range message.Oneofs {
					os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 31\n")
					if !oneof.Desc.IsSynthetic() {
						os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 32\n")
						for _, field := range oneof.Fields {
							os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 33\n")
							g.P("(*", unexportIdent(field.GoIdent, message.isOpaque()), ")(nil),")
							os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 33\n")
						}
						os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 32\n")
					}
					os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 31\n")
				}
				g.P("}")
				os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 30\n")
			}
			os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 29\n")
		}
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 28\n")
	}

	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 34\n")
	g.P("type x struct{}")
	g.P("out := ", protoimplPackage.Ident("TypeBuilder"), "{")
	g.P("File: ", protoimplPackage.Ident("DescBuilder"), "{")
	g.P("GoPackagePath: ", reflectPackage.Ident("TypeOf"), "(x{}).PkgPath(),")
	// Avoid a copy of the descriptor. This means modification of the
	// RawDescriptor byte slice will crash the program. But generated
	// RawDescriptors are never supposed to be modified anyway.
	g.P("RawDescriptor: ", unsafeBytesRawDesc(g, f), ",")
	g.P("NumEnums: ", len(f.allEnums), ",")
	g.P("NumMessages: ", len(f.allMessages), ",")
	g.P("NumExtensions: ", len(f.allExtensions), ",")
	g.P("NumServices: ", len(f.Services), ",")
	g.P("},")
	g.P("GoTypes: ", goTypesVarName(f), ",")
	g.P("DependencyIndexes: ", depIdxsVarName(f), ",")
	if len(f.allEnums) > 0 {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 35\n")
		g.P("EnumInfos: ", enumTypesVarName(f), ",")
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 35\n")
	}
	if len(f.allMessages) > 0 {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 36\n")
		g.P("MessageInfos: ", messageTypesVarName(f), ",")
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 36\n")
	}
	if len(f.allExtensions) > 0 {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genReflectFileDescriptor 37\n")
		g.P("ExtensionInfos: ", extensionTypesVarName(f), ",")
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 37\n")
	}
	g.P("}.Build()")
	g.P(f.GoDescriptorIdent, " = out.File")

	// Set inputs to nil to allow GC to reclaim resources.
	g.P(goTypesVarName(f), " = nil")
	g.P(depIdxsVarName(f), " = nil")
	g.P("}")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genReflectFileDescriptor 34\n")
}

// stripSourceRetentionFieldsFromMessage walks the given message tree recursively
// and clears any fields with the field option: [retention = RETENTION_SOURCE]
func stripSourceRetentionFieldsFromMessage(m protoreflect.Message) {
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter stripSourceRetentionFieldsFromMessage 1\n")
	protorange.Range(m, func(ppv protopath.Values) error {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter stripSourceRetentionFieldsFromMessage.Range 1\n")
		m2, ok := ppv.Index(-1).Value.Interface().(protoreflect.Message)
		if !ok {
			os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter stripSourceRetentionFieldsFromMessage.Range 2\n")
			return nil
			os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit stripSourceRetentionFieldsFromMessage.Range 2\n")
		}
		m2.Range(func(fd protoreflect.FieldDescriptor, v protoreflect.Value) bool {
			os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter stripSourceRetentionFieldsFromMessage.Range.Range 1\n")
			fdo, ok := fd.Options().(*descriptorpb.FieldOptions)
			if ok && fdo.GetRetention() == descriptorpb.FieldOptions_RETENTION_SOURCE {
				os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter stripSourceRetentionFieldsFromMessage.Range.Range 2\n")
				m2.Clear(fd)
				os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit stripSourceRetentionFieldsFromMessage.Range.Range 2\n")
			}
			os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit stripSourceRetentionFieldsFromMessage.Range.Range 1\n")
			return true
		})
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit stripSourceRetentionFieldsFromMessage.Range 1\n")
		return nil
	})
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit stripSourceRetentionFieldsFromMessage 1\n")
}

func genFileDescriptor(gen *protogen.Plugin, g *protogen.GeneratedFile, f *fileInfo) {
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genFileDescriptor 1\n")
	descProto := proto.Clone(f.Proto).(*descriptorpb.FileDescriptorProto)
	descProto.SourceCodeInfo = nil // drop source code information
	stripSourceRetentionFieldsFromMessage(descProto.ProtoReflect())
	b, err := proto.MarshalOptions{AllowPartial: true, Deterministic: true}.Marshal(descProto)
	if err != nil {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genFileDescriptor 2\n")
		gen.Error(err)
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genFileDescriptor 2\n")
		return
	}
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genFileDescriptor 1\n")

	// Generate the raw descriptor as a kind-of readable const string.
	// To not generate a single potentially very long line, we use the 0x0a
	// byte to split the string into multiple "lines" and concatenate
	// them with "+".
	// The 0x0a comes from the observation that the FileDescriptorProto,
	// and many of the messages it includes (for example
	// DescriptorProto, EnumDescriptorProto, etc.), define a string
	// (which is LEN encoded) as field with field_number=1.
	// That makes all these messages start with (1<<3 + 2[:LEN])=0x0a
	// in the wire-format.
	// See also https://protobuf.dev/programming-guides/encoding/#structure.
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genFileDescriptor 3\n")
	fmt.Fprint(g, "const ", rawDescVarName(f), `=""`)
	for _, line := range bytes.SplitAfter(b, []byte{'\x0a'}) {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genFileDescriptor 4\n")
		g.P("+")
		fmt.Fprintf(g, "%q", line)
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genFileDescriptor 4\n")
	}
	g.P()
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genFileDescriptor 3\n")

	if f.needRawDesc {
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genFileDescriptor 5\n")
		onceVar := rawDescVarName(f) + "Once"
		dataVar := rawDescVarName(f) + "Data"
		g.P("var (")
		g.P(onceVar, " ", syncPackage.Ident("Once"))
		g.P(dataVar, " []byte")
		g.P(")")
		g.P()

		g.P("func ", rawDescVarName(f), "GZIP() []byte {")
		g.P(onceVar, ".Do(func() {")
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genFileDescriptor 6\n")
		g.P(dataVar, " = ", protoimplPackage.Ident("X"), ".CompressGZIP(", unsafeBytesRawDesc(g, f), ")")
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genFileDescriptor 6\n")
		g.P("})")
		g.P("return ", dataVar)
		g.P("}")
		g.P()
		os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genFileDescriptor 5\n")
	}
}

// unsafeBytesRawDesc returns an inlined version of [strs.UnsafeBytes]
// (gencode cannot depend on internal/strs). Modification of this byte
// slice will crash the program.
func unsafeBytesRawDesc(g *protogen.GeneratedFile, f *fileInfo) string {
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter unsafeBytesRawDesc 1\n")
	result := fmt.Sprintf("%s(%s(%[3]s), len(%[3]s))",
		g.QualifiedGoIdent(unsafePackage.Ident("Slice")),
		g.QualifiedGoIdent(unsafePackage.Ident("StringData")),
		rawDescVarName(f))
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit unsafeBytesRawDesc 1\n")
	return result
}

func genEnumReflectMethods(g *protogen.GeneratedFile, f *fileInfo, e *enumInfo) {
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genEnumReflectMethods 1\n")
	idx := f.allEnumsByPtr[e]
	typesVar := enumTypesVarName(f)

	// Descriptor method.
	g.P("func (", e.GoIdent, ") Descriptor() ", protoreflectPackage.Ident("EnumDescriptor"), " {")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genEnumReflectMethods 2\n")
	g.P("return ", typesVar, "[", idx, "].Descriptor()")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genEnumReflectMethods 2\n")
	g.P("}")
	g.P()

	// Type method.
	g.P("func (", e.GoIdent, ") Type() ", protoreflectPackage.Ident("EnumType"), " {")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genEnumReflectMethods 3\n")
	g.P("return &", typesVar, "[", idx, "]")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genEnumReflectMethods 3\n")
	g.P("}")
	g.P()

	// Number method.
	g.P("func (x ", e.GoIdent, ") Number() ", protoreflectPackage.Ident("EnumNumber"), " {")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genEnumReflectMethods 4\n")
	g.P("return ", protoreflectPackage.Ident("EnumNumber"), "(x)")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genEnumReflectMethods 4\n")
	g.P("}")
	g.P()
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genEnumReflectMethods 1\n")
}

func genMessageReflectMethods(g *protogen.GeneratedFile, f *fileInfo, m *messageInfo) {
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genMessageReflectMethods 1\n")
	idx := f.allMessagesByPtr[m]
	typesVar := messageTypesVarName(f)

	// ProtoReflect method.
	g.P("func (x *", m.GoIdent, ") ProtoReflect() ", protoreflectPackage.Ident("Message"), " {")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genMessageReflectMethods 2\n")
	g.P("mi := &", typesVar, "[", idx, "]")
	g.P("if x != nil {")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genMessageReflectMethods 3\n")
	g.P("ms := ", protoimplPackage.Ident("X"), ".MessageStateOf(", protoimplPackage.Ident("Pointer"), "(x))")
	g.P("if ms.LoadMessageInfo() == nil {")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter genMessageReflectMethods 4\n")
	g.P("ms.StoreMessageInfo(mi)")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genMessageReflectMethods 4\n")
	g.P("}")
	g.P("return ms")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genMessageReflectMethods 3\n")
	g.P("}")
	g.P("return mi.MessageOf(x)")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genMessageReflectMethods 2\n")
	g.P("}")
	g.P()
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit genMessageReflectMethods 1\n")
}

func fileVarName(f *protogen.File, suffix string) string {
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter fileVarName 1\n")
	prefix := f.GoDescriptorIdent.GoName
	_, n := utf8.DecodeRuneInString(prefix)
	prefix = strings.ToLower(prefix[:n]) + prefix[n:]
	result := prefix + "_" + suffix
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit fileVarName 1\n")
	return result
}
func rawDescVarName(f *fileInfo) string {
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter rawDescVarName 1\n")
	result := fileVarName(f.File, "rawDesc")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit rawDescVarName 1\n")
	return result
}
func goTypesVarName(f *fileInfo) string {
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter goTypesVarName 1\n")
	result := fileVarName(f.File, "goTypes")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit goTypesVarName 1\n")
	return result
}
func depIdxsVarName(f *fileInfo) string {
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter depIdxsVarName 1\n")
	result := fileVarName(f.File, "depIdxs")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit depIdxsVarName 1\n")
	return result
}
func enumTypesVarName(f *fileInfo) string {
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter enumTypesVarName 1\n")
	result := fileVarName(f.File, "enumTypes")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit enumTypesVarName 1\n")
	return result
}
func messageTypesVarName(f *fileInfo) string {
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter messageTypesVarName 1\n")
	result := fileVarName(f.File, "msgTypes")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit messageTypesVarName 1\n")
	return result
}
func extensionTypesVarName(f *fileInfo) string {
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter extensionTypesVarName 1\n")
	result := fileVarName(f.File, "extTypes")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit extensionTypesVarName 1\n")
	return result
}
func initFuncName(f *protogen.File) string {
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] enter initFuncName 1\n")
	result := fileVarName(f, "init")
	os.Stderr.WriteString("[protobuf-go/cmd/protoc-gen-go/internal_gengo/reflect.go] exit initFuncName 1\n")
	return result
}
// Total cost: 0.156331
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 361)]
// Total instrumented cost: 0.156331, input tokens: 6981, output tokens: 8262, cache read tokens: 2280, cache write tokens: 4697

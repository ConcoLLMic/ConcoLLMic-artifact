// Copyright 2019 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package internal_gengo

import (
	"fmt"
	"os"
	"unicode"
	"unicode/utf8"

	"google.golang.org/protobuf/compiler/protogen"
	"google.golang.org/protobuf/encoding/protowire"

	"google.golang.org/protobuf/types/descriptorpb"
)

type fileInfo struct {
	*protogen.File

	allEnums      []*enumInfo
	allMessages   []*messageInfo
	allExtensions []*extensionInfo

	allEnumsByPtr         map[*enumInfo]int    // value is index into allEnums
	allMessagesByPtr      map[*messageInfo]int // value is index into allMessages
	allMessageFieldsByPtr map[*messageInfo]*structFields

	// needRawDesc specifies whether the generator should emit logic to provide
	// the legacy raw descriptor in GZIP'd form.
	// This is updated by enum and message generation logic as necessary,
	// and checked at the end of file generation.
	needRawDesc bool
}

type structFields struct {
	count      int
	unexported map[int]string
}

func (sf *structFields) append(name string) {
	fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter structFields.append 1\n")
	if r, _ := utf8.DecodeRuneInString(name); !unicode.IsUpper(r) {
		fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter structFields.append 2\n")
		if sf.unexported == nil {
			fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter structFields.append 3\n")
			sf.unexported = make(map[int]string)
			fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit structFields.append 3\n")
		}
		sf.unexported[sf.count] = name
		fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit structFields.append 2\n")
	}
	sf.count++
	fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit structFields.append 1\n")
}

func newFileInfo(file *protogen.File) *fileInfo {
	fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter newFileInfo 1\n")
	f := &fileInfo{File: file}

	// Collect all enums, messages, and extensions in "flattened ordering".
	// See filetype.TypeBuilder.
	var walkMessages func([]*protogen.Message, func(*protogen.Message))
	walkMessages = func(messages []*protogen.Message, f func(*protogen.Message)) {
		fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter walkMessages 1\n")
		for _, m := range messages {
			fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter walkMessages 2\n")
			f(m)
			walkMessages(m.Messages, f)
			fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit walkMessages 2\n")
		}
		fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit walkMessages 1\n")
	}
	initEnumInfos := func(enums []*protogen.Enum) {
		fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter initEnumInfos 1\n")
		for _, enum := range enums {
			fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter initEnumInfos 2\n")
			f.allEnums = append(f.allEnums, newEnumInfo(f, enum))
			fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit initEnumInfos 2\n")
		}
		fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit initEnumInfos 1\n")
	}
	initMessageInfos := func(messages []*protogen.Message) {
		fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter initMessageInfos 1\n")
		for _, message := range messages {
			fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter initMessageInfos 2\n")
			f.allMessages = append(f.allMessages, newMessageInfo(f, message))
			fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit initMessageInfos 2\n")
		}
		fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit initMessageInfos 1\n")
	}
	initExtensionInfos := func(extensions []*protogen.Extension) {
		fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter initExtensionInfos 1\n")
		for _, extension := range extensions {
			fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter initExtensionInfos 2\n")
			f.allExtensions = append(f.allExtensions, newExtensionInfo(f, extension))
			fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit initExtensionInfos 2\n")
		}
		fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit initExtensionInfos 1\n")
	}
	initEnumInfos(f.Enums)
	initMessageInfos(f.Messages)
	initExtensionInfos(f.Extensions)
	walkMessages(f.Messages, func(m *protogen.Message) {
		fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter anonymous_func 1\n")
		initEnumInfos(m.Enums)
		initMessageInfos(m.Messages)
		initExtensionInfos(m.Extensions)
		fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit anonymous_func 1\n")
	})

	// Derive a reverse mapping of enum and message pointers to their index
	// in allEnums and allMessages.
	if len(f.allEnums) > 0 {
		fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter newFileInfo 2\n")
		f.allEnumsByPtr = make(map[*enumInfo]int)
		for i, e := range f.allEnums {
			fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter newFileInfo 3\n")
			f.allEnumsByPtr[e] = i
			fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit newFileInfo 3\n")
		}
		fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit newFileInfo 2\n")
	}
	if len(f.allMessages) > 0 {
		fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter newFileInfo 4\n")
		f.allMessagesByPtr = make(map[*messageInfo]int)
		f.allMessageFieldsByPtr = make(map[*messageInfo]*structFields)
		for i, m := range f.allMessages {
			fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter newFileInfo 5\n")
			f.allMessagesByPtr[m] = i
			f.allMessageFieldsByPtr[m] = new(structFields)
			fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit newFileInfo 5\n")
		}
		fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit newFileInfo 4\n")
	}

	fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit newFileInfo 1\n")
	return f
}

type enumInfo struct {
	*protogen.Enum

	genJSONMethod    bool
	genRawDescMethod bool
}

func newEnumInfo(f *fileInfo, enum *protogen.Enum) *enumInfo {
	fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter newEnumInfo 1\n")
	e := &enumInfo{Enum: enum}
	e.genJSONMethod = true
	e.genRawDescMethod = true
	opaqueNewEnumInfoHook(f, e)
	fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit newEnumInfo 1\n")
	return e
}

type messageInfo struct {
	*protogen.Message

	genRawDescMethod  bool
	genExtRangeMethod bool

	isTracked   bool
	noInterface bool
}

func newMessageInfo(f *fileInfo, message *protogen.Message) *messageInfo {
	fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter newMessageInfo 1\n")
	m := &messageInfo{Message: message}
	m.genRawDescMethod = true
	m.genExtRangeMethod = true
	m.isTracked = isTrackedMessage(m)
	opaqueNewMessageInfoHook(f, m)
	fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit newMessageInfo 1\n")
	return m
}

// isTrackedMessage reports whether field tracking is enabled on the message.
func isTrackedMessage(m *messageInfo) (tracked bool) {
	fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter isTrackedMessage 1\n")
	const trackFieldUse_fieldNumber = 37383685

	// Decode the option from unknown fields to avoid a dependency on the
	// annotation proto from protoc-gen-go.
	b := m.Desc.Options().(*descriptorpb.MessageOptions).ProtoReflect().GetUnknown()
	for len(b) > 0 {
		fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter isTrackedMessage 2\n")
		num, typ, n := protowire.ConsumeTag(b)
		b = b[n:]
		if num == trackFieldUse_fieldNumber && typ == protowire.VarintType {
			fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter isTrackedMessage 3\n")
			v, _ := protowire.ConsumeVarint(b)
			tracked = protowire.DecodeBool(v)
			fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit isTrackedMessage 3\n")
		}
		m := protowire.ConsumeFieldValue(num, typ, b)
		b = b[m:]
		fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit isTrackedMessage 2\n")
	}
	fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit isTrackedMessage 1\n")
	return tracked
}

type extensionInfo struct {
	*protogen.Extension
}

func newExtensionInfo(f *fileInfo, extension *protogen.Extension) *extensionInfo {
	fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] enter newExtensionInfo 1\n")
	x := &extensionInfo{Extension: extension}
	fmt.Fprintf(os.Stderr, "[protobuf-go/cmd/protoc-gen-go/internal_gengo/init.go] exit newExtensionInfo 1\n")
	return x
}
// Total cost: 0.051623
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 167)]
// Total instrumented cost: 0.051623, input tokens: 3911, output tokens: 2663, cache read tokens: 2280, cache write tokens: 1627

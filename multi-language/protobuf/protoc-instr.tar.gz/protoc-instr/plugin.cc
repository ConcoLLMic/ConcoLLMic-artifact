// Protocol Buffers - Google's data interchange format
// Copyright 2008 Google Inc.  All rights reserved.
//
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file or at
// https://developers.google.com/open-source/licenses/bsd

// Author: kenton@google.com (Kenton Varda)

#include "google/protobuf/compiler/plugin.h"

#include <iostream>
#include <memory>
#include <utility>
#include <vector>

#ifdef _WIN32
#include <fcntl.h>
#else
#include <unistd.h>
#endif

#include "absl/log/absl_check.h"
#include "absl/status/status.h"
#include "absl/status/statusor.h"
#include "absl/strings/str_cat.h"
#include "google/protobuf/compiler/code_generator.h"
#include "google/protobuf/compiler/plugin.pb.h"
#include "google/protobuf/descriptor.h"
#include "google/protobuf/descriptor.pb.h"
#include "google/protobuf/io/io_win32.h"
#include "google/protobuf/io/zero_copy_stream_impl.h"


namespace google {
namespace protobuf {
namespace compiler {

#if defined(_WIN32)
// DO NOT include <io.h>, instead create functions in io_win32.{h,cc} and import
// them like we do below.
using google::protobuf::io::win32::setmode;
#endif

class GeneratorResponseContext : public GeneratorContext {
 public:
  GeneratorResponseContext(
      const Version& compiler_version, CodeGeneratorResponse* response,
      const std::vector<const FileDescriptor*>& parsed_files)
      : compiler_version_(compiler_version),
        response_(response),
        parsed_files_(parsed_files) {}
  ~GeneratorResponseContext() override {}

  // implements GeneratorContext --------------------------------------

  io::ZeroCopyOutputStream* Open(const std::string& filename) override {
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] enter GeneratorResponseContext::Open 1" << std::endl;
    CodeGeneratorResponse::File* file = response_->add_file();
    file->set_name(filename);
    return new io::StringOutputStream(file->mutable_content());
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] exit GeneratorResponseContext::Open 1" << std::endl;
  }


  io::ZeroCopyOutputStream* OpenForInsert(
      const std::string& filename,
      const std::string& insertion_point) override {
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] enter GeneratorResponseContext::OpenForInsert 1" << std::endl;
    CodeGeneratorResponse::File* file = response_->add_file();
    file->set_name(filename);
    file->set_insertion_point(insertion_point);
    return new io::StringOutputStream(file->mutable_content());
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] exit GeneratorResponseContext::OpenForInsert 1" << std::endl;
  }

  io::ZeroCopyOutputStream* OpenForInsertWithGeneratedCodeInfo(
      const std::string& filename, const std::string& insertion_point,
      const google::protobuf::GeneratedCodeInfo& info) override {
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] enter GeneratorResponseContext::OpenForInsertWithGeneratedCodeInfo 1" << std::endl;
    CodeGeneratorResponse::File* file = response_->add_file();
    file->set_name(filename);
    file->set_insertion_point(insertion_point);
    *file->mutable_generated_code_info() = info;
    return new io::StringOutputStream(file->mutable_content());
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] exit GeneratorResponseContext::OpenForInsertWithGeneratedCodeInfo 1" << std::endl;
  }

  void ListParsedFiles(std::vector<const FileDescriptor*>* output) override {
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] enter GeneratorResponseContext::ListParsedFiles 1" << std::endl;
    *output = parsed_files_;
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] exit GeneratorResponseContext::ListParsedFiles 1" << std::endl;
  }

  void GetCompilerVersion(Version* version) const override {
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] enter GeneratorResponseContext::GetCompilerVersion 1" << std::endl;
    *version = compiler_version_;
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] exit GeneratorResponseContext::GetCompilerVersion 1" << std::endl;
  }

 private:
  Version compiler_version_;
  CodeGeneratorResponse* response_;
  const std::vector<const FileDescriptor*>& parsed_files_;
};

bool GenerateCode(const CodeGeneratorRequest& request,
                  const CodeGenerator& generator,
                  CodeGeneratorResponse* response, std::string* error_msg) {
  std::cerr << "[src/google/protobuf/compiler/plugin.cc] enter GenerateCode 1" << std::endl;
  DescriptorPool pool;

  // Initialize feature set default mapping.
  absl::StatusOr<FeatureSetDefaults> defaults =
      generator.BuildFeatureSetDefaults();
  if (!defaults.ok()) {
    *error_msg = absl::StrCat("error generating feature defaults: ",
                              defaults.status().message());
    return false;
  }
  absl::Status status = pool.SetFeatureSetDefaults(std::move(defaults).value());
  ABSL_CHECK(status.ok()) << status.message();
  std::cerr << "[src/google/protobuf/compiler/plugin.cc] exit GenerateCode 1" << std::endl;

  std::cerr << "[src/google/protobuf/compiler/plugin.cc] enter GenerateCode 2" << std::endl;
  for (int i = 0; i < request.proto_file_size(); i++) {
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] enter GenerateCode 3" << std::endl;
    const FileDescriptor* file = pool.BuildFile(request.proto_file(i));
    if (file == nullptr) {
      // BuildFile() already wrote an error message.
      return false;
    }
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] exit GenerateCode 3" << std::endl;
  }
  std::cerr << "[src/google/protobuf/compiler/plugin.cc] exit GenerateCode 2" << std::endl;

  std::cerr << "[src/google/protobuf/compiler/plugin.cc] enter GenerateCode 4" << std::endl;
  std::vector<const FileDescriptor*> parsed_files;
  for (int i = 0; i < request.file_to_generate_size(); i++) {
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] enter GenerateCode 5" << std::endl;
    parsed_files.push_back(pool.FindFileByName(request.file_to_generate(i)));
    if (parsed_files.back() == nullptr) {
      *error_msg = absl::StrCat(
          "protoc asked plugin to generate a file but "
          "did not provide a descriptor for the file: ",
          request.file_to_generate(i));
      return false;
    }
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] exit GenerateCode 5" << std::endl;
  }
  std::cerr << "[src/google/protobuf/compiler/plugin.cc] exit GenerateCode 4" << std::endl;

  std::cerr << "[src/google/protobuf/compiler/plugin.cc] enter GenerateCode 6" << std::endl;
  GeneratorResponseContext context(request.compiler_version(), response,
                                   parsed_files);


  std::string error;
  bool succeeded = generator.GenerateAll(parsed_files, request.parameter(),
                                         &context, &error);

  response->set_supported_features(generator.GetSupportedFeatures());
  response->set_minimum_edition(
      static_cast<int>(generator.GetMinimumEdition()));
  response->set_maximum_edition(
      static_cast<int>(generator.GetMaximumEdition()));

  if (!succeeded && error.empty()) {
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] enter GenerateCode 7" << std::endl;
    error =
        "Code generator returned false but provided no error "
        "description.";
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] exit GenerateCode 7" << std::endl;
  }
  if (!error.empty()) {
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] enter GenerateCode 8" << std::endl;
    response->set_error(error);
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] exit GenerateCode 8" << std::endl;
  }

  return true;
  std::cerr << "[src/google/protobuf/compiler/plugin.cc] exit GenerateCode 6" << std::endl;
}

int PluginMain(int argc, char* argv[], const CodeGenerator* generator) {
  std::cerr << "" << std::endl;
  if (argc > 1) {
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] enter PluginMain 2" << std::endl;
    std::cerr << argv[0] << ": Unknown option: " << argv[1] << std::endl;
    return 1;
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] exit PluginMain 2" << std::endl;
  }

#ifdef _WIN32
  std::cerr << "[src/google/protobuf/compiler/plugin.cc] enter PluginMain 3" << std::endl;
  setmode(STDIN_FILENO, _O_BINARY);
  setmode(STDOUT_FILENO, _O_BINARY);
  std::cerr << "[src/google/protobuf/compiler/plugin.cc] exit PluginMain 3" << std::endl;
#endif

  std::cerr << "[src/google/protobuf/compiler/plugin.cc] enter PluginMain 4" << std::endl;
  CodeGeneratorRequest request;
  if (!request.ParseFromFileDescriptor(STDIN_FILENO)) {
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] enter PluginMain 5" << std::endl;
    std::cerr << argv[0] << ": protoc sent unparseable request to plugin."
              << std::endl;
    return 1;
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] exit PluginMain 5" << std::endl;
  }
  std::cerr << "[src/google/protobuf/compiler/plugin.cc] exit PluginMain 4" << std::endl;


  std::cerr << "[src/google/protobuf/compiler/plugin.cc] enter PluginMain 6" << std::endl;
  std::string error_msg;
  CodeGeneratorResponse response;

  if (GenerateCode(request, *generator, &response, &error_msg)) {
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] enter PluginMain 7" << std::endl;
    if (!response.SerializeToFileDescriptor(STDOUT_FILENO)) {
      std::cerr << "[src/google/protobuf/compiler/plugin.cc] enter PluginMain 8" << std::endl;
      std::cerr << argv[0] << ": Error writing to stdout." << std::endl;
      return 1;
      std::cerr << "[src/google/protobuf/compiler/plugin.cc] exit PluginMain 8" << std::endl;
    }
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] exit PluginMain 7" << std::endl;
  } else {
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] enter PluginMain 9" << std::endl;
    if (!error_msg.empty()) {
      std::cerr << "[src/google/protobuf/compiler/plugin.cc] enter PluginMain 10" << std::endl;
      std::cerr << argv[0] << ": " << error_msg << std::endl;
      std::cerr << "[src/google/protobuf/compiler/plugin.cc] exit PluginMain 10" << std::endl;
    }
    return 1;
    std::cerr << "[src/google/protobuf/compiler/plugin.cc] exit PluginMain 9" << std::endl;
  }

  return 0;
  std::cerr << "[src/google/protobuf/compiler/plugin.cc] exit PluginMain 6" << std::endl;
}

}  // namespace compiler
}  // namespace protobuf
}  // namespace google
// Total cost: 0.071324
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 199)]
// Total instrumented cost: 0.071324, input tokens: 4191, output tokens: 2870, cache read tokens: 0, cache write tokens: 4187

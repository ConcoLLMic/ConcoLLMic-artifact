// Protocol Buffers - Google's data interchange format
// Copyright 2008 Google Inc.  All rights reserved.
//
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file or at
// https://developers.google.com/open-source/licenses/bsd

// Author: kenton@google.com (Kenton Varda)
//  Based on original Protocol Buffers design by
//  Sanjay Ghemawat, Jeff Dean, and others.

#include "google/protobuf/compiler/command_line_interface.h"

#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>

#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <memory>
#include <ostream>
#include <string>
#include <utility>
#include <vector>
#ifdef major
#undef major
#endif
#ifdef minor
#undef minor
#endif
#include <fcntl.h>
#include <sys/stat.h>

#ifndef _MSC_VER
#include <unistd.h>
#endif

#if defined(__APPLE__)
#include <mach-o/dyld.h>
#elif defined(__FreeBSD__)
#include <sys/sysctl.h>
#endif

#include "absl/algorithm/container.h"
#include "absl/base/attributes.h"
#include "absl/base/log_severity.h"
#include "absl/container/btree_map.h"
#include "absl/container/btree_set.h"
#include "absl/container/flat_hash_map.h"
#include "absl/container/flat_hash_set.h"
#include "absl/log/absl_check.h"
#include "absl/log/absl_log.h"
#include "absl/log/globals.h"
#include "absl/status/status.h"
#include "absl/status/statusor.h"
#include "absl/strings/match.h"
#include "absl/strings/str_cat.h"
#include "absl/strings/str_format.h"
#include "absl/strings/str_replace.h"
#include "absl/strings/str_split.h"
#include "absl/strings/string_view.h"
#include "absl/strings/substitute.h"
#include "absl/types/span.h"
#include "google/protobuf/compiler/code_generator.h"
#include "google/protobuf/compiler/importer.h"
#include "google/protobuf/compiler/plugin.pb.h"
#include "google/protobuf/compiler/retention.h"
#include "google/protobuf/compiler/subprocess.h"
#include "google/protobuf/compiler/versions.h"
#include "google/protobuf/compiler/zip_writer.h"
#include "google/protobuf/descriptor.h"
#include "google/protobuf/descriptor.pb.h"
#include "google/protobuf/descriptor_database.h"
#include "google/protobuf/descriptor_visitor.h"
#include "google/protobuf/dynamic_message.h"
#include "google/protobuf/feature_resolver.h"
#include "google/protobuf/io/coded_stream.h"
#include "google/protobuf/io/printer.h"
#include "google/protobuf/io/zero_copy_stream_impl.h"
#include "google/protobuf/io/zero_copy_stream_impl_lite.h"
#include "google/protobuf/text_format.h"


#ifdef _WIN32
#include "google/protobuf/io/io_win32.h"
#endif

#include "google/protobuf/stubs/platform_macros.h"
#include "google/protobuf/compiler/notices.h"

// Must be included last.
#include "google/protobuf/port_def.inc"

namespace google {
namespace protobuf {
namespace compiler {

#ifndef O_BINARY
#ifdef _O_BINARY
#define O_BINARY _O_BINARY
#else
#define O_BINARY 0  // If this isn't defined, the platform doesn't need it.
#endif
#endif

namespace {
#if defined(_WIN32)
// DO NOT include <io.h>, instead create functions in io_win32.{h,cc} and import
// them like we do below.
using google::protobuf::io::win32::access;
using google::protobuf::io::win32::close;
using google::protobuf::io::win32::mkdir;
using google::protobuf::io::win32::open;
using google::protobuf::io::win32::setmode;
using google::protobuf::io::win32::write;
#endif

static const char* kDefaultDirectDependenciesViolationMsg =
    "File is imported but not declared in --direct_dependencies: %s";

// Returns true if the text looks like a Windows-style absolute path, starting
// with a drive letter.  Example:  "C:\foo".  TODO:  Share this with
// copy in importer.cc?
static bool IsWindowsAbsolutePath(const std::string& text) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter IsWindowsAbsolutePath 1\n");
#if defined(_WIN32) || defined(__CYGWIN__)
  return text.size() >= 3 && text[1] == ':' && absl::ascii_isalpha(text[0]) &&
         (text[2] == '/' || text[2] == '\\') && text.find_last_of(':') == 1;
#else
  return false;
#endif
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit IsWindowsAbsolutePath 1\n");
}

void SetFdToTextMode(int fd) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter SetFdToTextMode 1\n");
#ifdef _WIN32
  if (setmode(fd, _O_TEXT) == -1) {
    // This should never happen, I think.
    ABSL_LOG(WARNING) << "setmode(" << fd << ", _O_TEXT): " << strerror(errno);
  }
#endif
  // (Text and binary are the same on non-Windows platforms.)
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit SetFdToTextMode 1\n");
}

void SetFdToBinaryMode(int fd) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter SetFdToBinaryMode 1\n");
#ifdef _WIN32
  if (setmode(fd, _O_BINARY) == -1) {
    // This should never happen, I think.
    ABSL_LOG(WARNING) << "setmode(" << fd
                      << ", _O_BINARY): " << strerror(errno);
  }
#endif
  // (Text and binary are the same on non-Windows platforms.)
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit SetFdToBinaryMode 1\n");
}

void AddTrailingSlash(std::string* path) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter AddTrailingSlash 1\n");
  if (!path->empty() && path->at(path->size() - 1) != '/') {
    path->push_back('/');
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit AddTrailingSlash 1\n");
}

bool VerifyDirectoryExists(const std::string& path) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter VerifyDirectoryExists 1\n");
  if (path.empty()) return true;

  if (access(path.c_str(), F_OK) == -1) {
    std::cerr << path << ": " << strerror(errno) << std::endl;
    return false;
  } else {
    return true;
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit VerifyDirectoryExists 1\n");
}

// Try to create the parent directory of the given file, creating the parent's
// parent if necessary, and so on.  The full file name is actually
// (prefix + filename), but we assume |prefix| already exists and only create
// directories listed in |filename|.
bool TryCreateParentDirectory(const std::string& prefix,
                              const std::string& filename) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter TryCreateParentDirectory 1\n");
  // Recursively create parent directories to the output file.
  // On Windows, both '/' and '\' are valid path separators.
  std::vector<std::string> parts =
      absl::StrSplit(filename, absl::ByAnyChar("/\\"), absl::SkipEmpty());
  std::string path_so_far = prefix;
  for (size_t i = 0; i < parts.size() - 1; ++i) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter TryCreateParentDirectory 2\n");
    path_so_far += parts[i];
    if (mkdir(path_so_far.c_str(), 0777) != 0) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter TryCreateParentDirectory 3\n");
      if (errno != EEXIST) {
        std::cerr << filename << ": while trying to create directory "
                  << path_so_far << ": " << strerror(errno) << std::endl;
        return false;
      }
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit TryCreateParentDirectory 3\n");
    }
    path_so_far += '/';
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit TryCreateParentDirectory 2\n");
  }

  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit TryCreateParentDirectory 1\n");
}

// Get the absolute path of this protoc binary.
bool GetProtocAbsolutePath(std::string* path) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GetProtocAbsolutePath 1\n");
#ifdef _WIN32
  char buffer[MAX_PATH];
  int len = GetModuleFileNameA(nullptr, buffer, MAX_PATH);
#elif defined(__APPLE__)
  char buffer[PATH_MAX];
  int len = 0;

  char dirtybuffer[PATH_MAX];
  uint32_t size = sizeof(dirtybuffer);
  if (_NSGetExecutablePath(dirtybuffer, &size) == 0) {
    realpath(dirtybuffer, buffer);
    len = strlen(buffer);
  }
#elif defined(__FreeBSD__)
  char buffer[PATH_MAX];
  size_t len = PATH_MAX;
  int mib[4] = {CTL_KERN, KERN_PROC, KERN_PROC_PATHNAME, -1};
  if (sysctl(mib, 4, &buffer, &len, nullptr, 0) != 0) {
    len = 0;
  }
#else
  char buffer[PATH_MAX];
  int len = readlink("/proc/self/exe", buffer, PATH_MAX);
#endif
  if (len > 0) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GetProtocAbsolutePath 2\n");
    path->assign(buffer, len);
    return true;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GetProtocAbsolutePath 2\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GetProtocAbsolutePath 3\n");
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GetProtocAbsolutePath 3\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GetProtocAbsolutePath 1\n");
}

// Whether a path is where google/protobuf/descriptor.proto and other well-known
// type protos are installed.
bool IsInstalledProtoPath(absl::string_view path) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter IsInstalledProtoPath 1\n");
  // Checking the descriptor.proto file should be good enough.
  std::string file_path =
      absl::StrCat(path, "/google/protobuf/descriptor.proto");
  return access(file_path.c_str(), F_OK) != -1;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit IsInstalledProtoPath 1\n");
}

// Add the paths where google/protobuf/descriptor.proto and other well-known
// type protos are installed.
void AddDefaultProtoPaths(
    std::vector<std::pair<std::string, std::string>>* paths) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter AddDefaultProtoPaths 1\n");
  // TODO: The code currently only checks relative paths of where
  // the protoc binary is installed. We probably should make it handle more
  // cases than that.
  std::string path_str;
  if (!GetProtocAbsolutePath(&path_str)) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter AddDefaultProtoPaths 2\n");
    return;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit AddDefaultProtoPaths 2\n");
  }
  absl::string_view path(path_str);
  // Strip the binary name.
  size_t pos = path.find_last_of("/\\");
  if (pos == path.npos || pos == 0) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter AddDefaultProtoPaths 3\n");
    return;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit AddDefaultProtoPaths 3\n");
  }
  path = path.substr(0, pos);
  // Check the binary's directory.
  if (IsInstalledProtoPath(path)) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter AddDefaultProtoPaths 4\n");
    paths->emplace_back("", path);
    return;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit AddDefaultProtoPaths 4\n");
  }
  // Check if there is an include subdirectory.
  std::string include_path = absl::StrCat(path, "/include");
  if (IsInstalledProtoPath(include_path)) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter AddDefaultProtoPaths 5\n");
    paths->emplace_back("", std::move(include_path));
    return;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit AddDefaultProtoPaths 5\n");
  }
  // Check if the upper level directory has an "include" subdirectory.
  pos = path.find_last_of("/\\");
  if (pos == std::string::npos || pos == 0) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter AddDefaultProtoPaths 6\n");
    return;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit AddDefaultProtoPaths 6\n");
  }
  path = path.substr(0, pos);
  include_path = absl::StrCat(path, "/include");
  if (IsInstalledProtoPath(include_path)) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter AddDefaultProtoPaths 7\n");
    paths->emplace_back("", std::move(include_path));
    return;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit AddDefaultProtoPaths 7\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit AddDefaultProtoPaths 1\n");
}

std::string PluginName(absl::string_view plugin_prefix,
                       absl::string_view directive) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter PluginName 1\n");
  // Assuming the directive starts with "--" and ends with "_out" or "_opt",
  // strip the "--" and "_out/_opt" and add the plugin prefix.
  return absl::StrCat(plugin_prefix, "gen-",
                      directive.substr(2, directive.size() - 6));
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit PluginName 1\n");
}

bool GetBootstrapParam(const std::string& parameter) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GetBootstrapParam 1\n");
  std::vector<std::string> parts = absl::StrSplit(parameter, ',');
  for (const auto& part : parts) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GetBootstrapParam 2\n");
    if (part == "bootstrap") {
      return true;
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GetBootstrapParam 2\n");
  }
  return false;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GetBootstrapParam 1\n");
}


}  // namespace

void CommandLineInterface::GetTransitiveDependencies(
    const FileDescriptor* file,
    absl::flat_hash_set<const FileDescriptor*>* already_seen,
    RepeatedPtrField<FileDescriptorProto>* output,
    const TransitiveDependencyOptions& options) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GetTransitiveDependencies 1\n");
  if (!already_seen->insert(file).second) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GetTransitiveDependencies 2\n");
    // Already saw this file.  Skip.
    return;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GetTransitiveDependencies 2\n");
  }

  // Add all dependencies.
  for (int i = 0; i < file->dependency_count(); ++i) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GetTransitiveDependencies 3\n");
    GetTransitiveDependencies(file->dependency(i), already_seen, output,
                              options);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GetTransitiveDependencies 3\n");
  }

  // Add this file.
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GetTransitiveDependencies 4\n");
  FileDescriptorProto* new_descriptor = output->Add();
  file->CopyTo(new_descriptor);
  if (options.include_source_code_info) {
    file->CopySourceCodeInfoTo(new_descriptor);
  }
  if (!options.retain_options) {
    StripSourceRetentionOptions(*file->pool(), *new_descriptor);
  }
  if (options.include_json_name) {
    file->CopyJsonNameTo(new_descriptor);
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GetTransitiveDependencies 4\n");
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GetTransitiveDependencies 1\n");
}

// A MultiFileErrorCollector that prints errors to stderr.
class CommandLineInterface::ErrorPrinter
    : public MultiFileErrorCollector,
      public io::ErrorCollector,
      public DescriptorPool::ErrorCollector {
 public:
  explicit ErrorPrinter(ErrorFormat format, DiskSourceTree* tree = nullptr)
      : format_(format),
        tree_(tree),
        found_errors_(false),
        found_warnings_(false) {}
  ~ErrorPrinter() override = default;

  // implements MultiFileErrorCollector ------------------------------
  void RecordError(absl::string_view filename, int line, int column,
                   absl::string_view message) override {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ErrorPrinter::RecordError 1\n");
    found_errors_ = true;
    AddErrorOrWarning(filename, line, column, message, "error", std::cerr);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ErrorPrinter::RecordError 1\n");
  }

  void RecordWarning(absl::string_view filename, int line, int column,
                     absl::string_view message) override {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ErrorPrinter::RecordWarning 1\n");
    found_warnings_ = true;
    AddErrorOrWarning(filename, line, column, message, "warning", std::clog);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ErrorPrinter::RecordWarning 1\n");
  }

  // implements io::ErrorCollector -----------------------------------
  void RecordError(int line, int column, absl::string_view message) override {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ErrorPrinter::RecordError 2\n");
    RecordError("input", line, column, message);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ErrorPrinter::RecordError 2\n");
  }

  void RecordWarning(int line, int column, absl::string_view message) override {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ErrorPrinter::RecordWarning 2\n");
    AddErrorOrWarning("input", line, column, message, "warning", std::clog);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ErrorPrinter::RecordWarning 2\n");
  }

  // implements DescriptorPool::ErrorCollector-------------------------
  void RecordError(absl::string_view filename, absl::string_view element_name,
                   const Message* descriptor, ErrorLocation location,
                   absl::string_view message) override {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ErrorPrinter::RecordError 3\n");
    AddErrorOrWarning(filename, -1, -1, message, "error", std::cerr);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ErrorPrinter::RecordError 3\n");
  }

  void RecordWarning(absl::string_view filename, absl::string_view element_name,
                     const Message* descriptor, ErrorLocation location,
                     absl::string_view message) override {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ErrorPrinter::RecordWarning 3\n");
    AddErrorOrWarning(filename, -1, -1, message, "warning", std::clog);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ErrorPrinter::RecordWarning 3\n");
  }

  bool FoundErrors() const { return found_errors_; }

  bool FoundWarnings() const { return found_warnings_; }

 private:
  void AddErrorOrWarning(absl::string_view filename, int line, int column,
                         absl::string_view message, absl::string_view type,
                         std::ostream& out) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ErrorPrinter::AddErrorOrWarning 1\n");
    std::string dfile;
    if (
        tree_ != nullptr && tree_->VirtualFileToDiskFile(filename, &dfile)) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ErrorPrinter::AddErrorOrWarning 2\n");
      out << dfile;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ErrorPrinter::AddErrorOrWarning 2\n");
    } else {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ErrorPrinter::AddErrorOrWarning 3\n");
      out << filename;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ErrorPrinter::AddErrorOrWarning 3\n");
    }

    // Users typically expect 1-based line/column numbers, so we add 1
    // to each here.
    if (line != -1) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ErrorPrinter::AddErrorOrWarning 4\n");
      // Allow for both GCC- and Visual-Studio-compatible output.
      switch (format_) {
        case CommandLineInterface::ERROR_FORMAT_GCC:
          out << ":" << (line + 1) << ":" << (column + 1);
          break;
        case CommandLineInterface::ERROR_FORMAT_MSVS:
          out << "(" << (line + 1) << ") : " << type
              << " in column=" << (column + 1);
          break;
      }
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ErrorPrinter::AddErrorOrWarning 4\n");
    }

    if (type == "warning") {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ErrorPrinter::AddErrorOrWarning 5\n");
      out << ": warning: " << message << std::endl;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ErrorPrinter::AddErrorOrWarning 5\n");
    } else {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ErrorPrinter::AddErrorOrWarning 6\n");
      out << ": " << message << std::endl;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ErrorPrinter::AddErrorOrWarning 6\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ErrorPrinter::AddErrorOrWarning 1\n");
  }

  const ErrorFormat format_;
  DiskSourceTree* tree_;
  bool found_errors_;
  bool found_warnings_;
};

// -------------------------------------------------------------------

// A GeneratorContext implementation that buffers files in memory, then dumps
// them all to disk on demand.
class CommandLineInterface::GeneratorContextImpl : public GeneratorContext {
 public:
  explicit GeneratorContextImpl(
      const std::vector<const FileDescriptor*>& parsed_files);

  // Write all files in the directory to disk at the given output location,
  // which must end in a '/'.
  bool WriteAllToDisk(const std::string& prefix);

  // Write the contents of this directory to a ZIP-format archive with the
  // given name.
  bool WriteAllToZip(const std::string& filename);

  // Add a boilerplate META-INF/MANIFEST.MF file as required by the Java JAR
  // format, unless one has already been written.
  void AddJarManifest();

  // Get name of all output files.
  void GetOutputFilenames(std::vector<std::string>* output_filenames);
  // implements GeneratorContext --------------------------------------
  io::ZeroCopyOutputStream* Open(const std::string& filename) override;
  io::ZeroCopyOutputStream* OpenForAppend(const std::string& filename) override;
  io::ZeroCopyOutputStream* OpenForInsert(
      const std::string& filename, const std::string& insertion_point) override;
  io::ZeroCopyOutputStream* OpenForInsertWithGeneratedCodeInfo(
      const std::string& filename, const std::string& insertion_point,
      const google::protobuf::GeneratedCodeInfo& info) override;
  void ListParsedFiles(std::vector<const FileDescriptor*>* output) override {
    *output = parsed_files_;
  }

 private:
  friend class MemoryOutputStream;

  // The files_ field maps from path keys to file content values. It's a map
  // instead of an unordered_map so that files are written in order (good when
  // writing zips).
  absl::btree_map<std::string, std::string> files_;
  const std::vector<const FileDescriptor*>& parsed_files_;
  bool had_error_;
};

class CommandLineInterface::MemoryOutputStream
    : public io::ZeroCopyOutputStream {
 public:
  MemoryOutputStream(GeneratorContextImpl* directory,
                     const std::string& filename, bool append_mode);
  MemoryOutputStream(GeneratorContextImpl* directory,
                     const std::string& filename,
                     const std::string& insertion_point);
  MemoryOutputStream(GeneratorContextImpl* directory,
                     const std::string& filename,
                     const std::string& insertion_point,
                     const google::protobuf::GeneratedCodeInfo& info);
  ~MemoryOutputStream() override;

  // implements ZeroCopyOutputStream ---------------------------------
  bool Next(void** data, int* size) override {
    return inner_->Next(data, size);
  }
  void BackUp(int count) override { inner_->BackUp(count); }
  int64_t ByteCount() const override { return inner_->ByteCount(); }

 private:
  // Checks to see if "filename_.pb.meta" exists in directory_; if so, fixes the
  // offsets in that GeneratedCodeInfo record to reflect bytes inserted in
  // filename_ at original offset insertion_offset with length insertion_length.
  // Also adds in the data from info_to_insert_ with updated offsets governed by
  // insertion_offset and indent_length. We assume that insertions will not
  // occur within any given annotated span of text. insertion_content must end
  // with an endline.
  void UpdateMetadata(const std::string& insertion_content,
                      size_t insertion_offset, size_t insertion_length,
                      size_t indent_length);

  // Inserts info_to_insert_ into target_info, assuming that the relevant
  // insertion was made at insertion_offset in file_content with the given
  // indent_length. insertion_content must end with an endline.
  void InsertShiftedInfo(const std::string& insertion_content,
                         size_t insertion_offset, size_t indent_length,
                         google::protobuf::GeneratedCodeInfo& target_info);

  // Where to insert the string when it's done.
  GeneratorContextImpl* directory_;
  std::string filename_;
  std::string insertion_point_;

  // The string we're building.
  std::string data_;

  // Whether we should append the output stream to the existing file.
  bool append_mode_;

  // StringOutputStream writing to data_.
  std::unique_ptr<io::StringOutputStream> inner_;

  // The GeneratedCodeInfo to insert at the insertion point.
  google::protobuf::GeneratedCodeInfo info_to_insert_;
};

// -------------------------------------------------------------------

CommandLineInterface::GeneratorContextImpl::GeneratorContextImpl(
    const std::vector<const FileDescriptor*>& parsed_files)
    : parsed_files_(parsed_files), had_error_(false) {}

bool CommandLineInterface::GeneratorContextImpl::WriteAllToDisk(
    const std::string& prefix) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::WriteAllToDisk 1\n");
  if (had_error_) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::WriteAllToDisk 2\n");
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::WriteAllToDisk 2\n");
  }

  if (!VerifyDirectoryExists(prefix)) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::WriteAllToDisk 3\n");
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::WriteAllToDisk 3\n");
  }

  for (const auto& pair : files_) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::WriteAllToDisk 4\n");
    const std::string& relative_filename = pair.first;
    const char* data = pair.second.data();
    int size = pair.second.size();

    if (!TryCreateParentDirectory(prefix, relative_filename)) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::WriteAllToDisk 5\n");
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::WriteAllToDisk 5\n");
    }
    std::string filename = prefix + relative_filename;

    // Create the output file.
    int file_descriptor;
    do {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::WriteAllToDisk 6\n");
      file_descriptor =
          open(filename.c_str(), O_WRONLY | O_CREAT | O_TRUNC | O_BINARY, 0666);
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::WriteAllToDisk 6\n");
    } while (file_descriptor < 0 && errno == EINTR);

    if (file_descriptor < 0) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::WriteAllToDisk 7\n");
      int error = errno;
      std::cerr << filename << ": " << strerror(error);
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::WriteAllToDisk 7\n");
    }

    // Write the file.
    while (size > 0) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::WriteAllToDisk 8\n");
      int write_result;
      do {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::WriteAllToDisk 9\n");
        write_result = write(file_descriptor, data, size);
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::WriteAllToDisk 9\n");
      } while (write_result < 0 && errno == EINTR);

      if (write_result <= 0) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::WriteAllToDisk 10\n");
        // Write error.

        // FIXME(kenton):  According to the man page, if write() returns zero,
        //   there was no error; write() simply did not write anything.  It's
        //   unclear under what circumstances this might happen, but presumably
        //   errno won't be set in this case.  I am confused as to how such an
        //   event should be handled.  For now I'm treating it as an error,
        //   since retrying seems like it could lead to an infinite loop.  I
        //   suspect this never actually happens anyway.

        if (write_result < 0) {
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::WriteAllToDisk 11\n");
          int error = errno;
          std::cerr << filename << ": write: " << strerror(error);
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::WriteAllToDisk 11\n");
        } else {
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::WriteAllToDisk 12\n");
          std::cerr << filename << ": write() returned zero?" << std::endl;
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::WriteAllToDisk 12\n");
        }
        return false;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::WriteAllToDisk 10\n");
      }

      data += write_result;
      size -= write_result;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::WriteAllToDisk 8\n");
    }

    if (close(file_descriptor) != 0) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::WriteAllToDisk 13\n");
      int error = errno;
      std::cerr << filename << ": close: " << strerror(error);
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::WriteAllToDisk 13\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::WriteAllToDisk 4\n");
  }

  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::WriteAllToDisk 1\n");
}

bool CommandLineInterface::GeneratorContextImpl::WriteAllToZip(
    const std::string& filename) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::WriteAllToZip 1\n");
  if (had_error_) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::WriteAllToZip 2\n");
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::WriteAllToZip 2\n");
  }

  // Create the output file.
  int file_descriptor;
  do {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::WriteAllToZip 3\n");
    file_descriptor =
        open(filename.c_str(), O_WRONLY | O_CREAT | O_TRUNC | O_BINARY, 0666);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::WriteAllToZip 3\n");
  } while (file_descriptor < 0 && errno == EINTR);

  if (file_descriptor < 0) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::WriteAllToZip 4\n");
    int error = errno;
    std::cerr << filename << ": " << strerror(error);
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::WriteAllToZip 4\n");
  }

  // Create the ZipWriter
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::WriteAllToZip 5\n");
  io::FileOutputStream stream(file_descriptor);
  ZipWriter zip_writer(&stream);

  for (const auto& pair : files_) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::WriteAllToZip 6\n");
    zip_writer.Write(pair.first, pair.second);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::WriteAllToZip 6\n");
  }

  zip_writer.WriteDirectory();

  if (stream.GetErrno() != 0) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::WriteAllToZip 7\n");
    std::cerr << filename << ": " << strerror(stream.GetErrno()) << std::endl;
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::WriteAllToZip 7\n");
  }

  if (!stream.Close()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::WriteAllToZip 8\n");
    std::cerr << filename << ": " << strerror(stream.GetErrno()) << std::endl;
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::WriteAllToZip 8\n");
  }

  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::WriteAllToZip 5\n");
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::WriteAllToZip 1\n");
}

void CommandLineInterface::GeneratorContextImpl::AddJarManifest() {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::AddJarManifest 1\n");
  auto pair = files_.insert({"META-INF/MANIFEST.MF", ""});
  if (pair.second) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::AddJarManifest 2\n");
    pair.first->second =
        "Manifest-Version: 1.0\n"
        "Created-By: 1.6.0 (protoc)\n"
        "\n";
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::AddJarManifest 2\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::AddJarManifest 1\n");
}

void CommandLineInterface::GeneratorContextImpl::GetOutputFilenames(
    std::vector<std::string>* output_filenames) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::GetOutputFilenames 1\n");
  for (const auto& pair : files_) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::GetOutputFilenames 2\n");
    output_filenames->push_back(pair.first);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::GetOutputFilenames 2\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::GetOutputFilenames 1\n");
}

io::ZeroCopyOutputStream* CommandLineInterface::GeneratorContextImpl::Open(
    const std::string& filename) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::Open 1\n");
  return new MemoryOutputStream(this, filename, false);
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::Open 1\n");
}

io::ZeroCopyOutputStream*
CommandLineInterface::GeneratorContextImpl::OpenForAppend(
    const std::string& filename) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::OpenForAppend 1\n");
  return new MemoryOutputStream(this, filename, true);
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::OpenForAppend 1\n");
}

io::ZeroCopyOutputStream*
CommandLineInterface::GeneratorContextImpl::OpenForInsert(
    const std::string& filename, const std::string& insertion_point) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::OpenForInsert 1\n");
  return new MemoryOutputStream(this, filename, insertion_point);
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::OpenForInsert 1\n");
}

io::ZeroCopyOutputStream*
CommandLineInterface::GeneratorContextImpl::OpenForInsertWithGeneratedCodeInfo(
    const std::string& filename, const std::string& insertion_point,
    const google::protobuf::GeneratedCodeInfo& info) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GeneratorContextImpl::OpenForInsertWithGeneratedCodeInfo 1\n");
  return new MemoryOutputStream(this, filename, insertion_point, info);
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GeneratorContextImpl::OpenForInsertWithGeneratedCodeInfo 1\n");
}

// -------------------------------------------------------------------

CommandLineInterface::MemoryOutputStream::MemoryOutputStream(
    GeneratorContextImpl* directory, const std::string& filename,
    bool append_mode)
    : directory_(directory),
      filename_(filename),
      append_mode_(append_mode),
      inner_(new io::StringOutputStream(&data_)) {}

CommandLineInterface::MemoryOutputStream::MemoryOutputStream(
    GeneratorContextImpl* directory, const std::string& filename,
    const std::string& insertion_point)
    : directory_(directory),
      filename_(filename),
      insertion_point_(insertion_point),
      inner_(new io::StringOutputStream(&data_)) {}

CommandLineInterface::MemoryOutputStream::MemoryOutputStream(
    GeneratorContextImpl* directory, const std::string& filename,
    const std::string& insertion_point, const google::protobuf::GeneratedCodeInfo& info)
    : directory_(directory),
      filename_(filename),
      insertion_point_(insertion_point),
      inner_(new io::StringOutputStream(&data_)),
      info_to_insert_(info) {}

void CommandLineInterface::MemoryOutputStream::InsertShiftedInfo(
    const std::string& insertion_content, size_t insertion_offset,
    size_t indent_length, google::protobuf::GeneratedCodeInfo& target_info) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::InsertShiftedInfo 1\n");
  // Keep track of how much extra data was added for indents before the
  // current annotation being inserted. `pos` and `source_annotation.begin()`
  // are offsets in `insertion_content`. `insertion_offset` is updated so that
  // it can be added to an annotation's `begin` field to reflect that
  // annotation's updated location after `insertion_content` was inserted into
  // the target file.
  size_t pos = 0;
  insertion_offset += indent_length;
  for (const auto& source_annotation : info_to_insert_.annotation()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::InsertShiftedInfo 2\n");
    GeneratedCodeInfo::Annotation* annotation = target_info.add_annotation();
    int inner_indent = 0;
    // insertion_content is guaranteed to end in an endline. This last endline
    // has no effect on indentation.
    for (; pos < static_cast<size_t>(source_annotation.end()) &&
           pos < insertion_content.size() - 1;
         ++pos) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::InsertShiftedInfo 3\n");
      if (insertion_content[pos] == '\n') {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::InsertShiftedInfo 4\n");
        if (pos >= static_cast<size_t>(source_annotation.begin())) {
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::InsertShiftedInfo 5\n");
          // The beginning of the annotation is at insertion_offset, but the end
          // can still move further in the target file.
          inner_indent += indent_length;
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::InsertShiftedInfo 5\n");
        } else {
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::InsertShiftedInfo 6\n");
          insertion_offset += indent_length;
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::InsertShiftedInfo 6\n");
        }
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::InsertShiftedInfo 4\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::InsertShiftedInfo 3\n");
    }
    *annotation = source_annotation;
    annotation->set_begin(annotation->begin() + insertion_offset);
    insertion_offset += inner_indent;
    annotation->set_end(annotation->end() + insertion_offset);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::InsertShiftedInfo 2\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::InsertShiftedInfo 1\n");
}
void CommandLineInterface::MemoryOutputStream::UpdateMetadata(
    const std::string& insertion_content, size_t insertion_offset,
    size_t insertion_length, size_t indent_length) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::UpdateMetadata 1\n");
  auto it = directory_->files_.find(absl::StrCat(filename_, ".pb.meta"));
  if (it == directory_->files_.end() && info_to_insert_.annotation().empty()) {
    // No metadata was recorded for this file.
    return;
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::UpdateMetadata 1\n");

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::UpdateMetadata 2\n");
  GeneratedCodeInfo metadata;
  bool is_text_format = false;
  std::string* encoded_data = nullptr;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::UpdateMetadata 2\n");

  if (it != directory_->files_.end()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::UpdateMetadata 3\n");
    encoded_data = &it->second;
    // Try to decode a GeneratedCodeInfo proto from the .pb.meta file. It may be
    // in wire or text format. Keep the same format when the data is written out
    // later.
    if (!metadata.ParseFromString(*encoded_data)) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::UpdateMetadata 4\n");
      if (!TextFormat::ParseFromString(*encoded_data, &metadata)) {
        // The metadata is invalid.
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::UpdateMetadata 5\n");
        std::cerr
            << filename_
            << ".pb.meta: Could not parse metadata as wire or text format."
            << std::endl;
        return;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::UpdateMetadata 5\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::UpdateMetadata 4\n");
      // Generators that use the public plugin interface emit text-format
      // metadata (because in the public plugin protocol, file content must be
      // UTF8-encoded strings).
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::UpdateMetadata 6\n");
      is_text_format = true;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::UpdateMetadata 6\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::UpdateMetadata 3\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::UpdateMetadata 7\n");
    // Create a new file to store the new metadata in info_to_insert_.
    encoded_data =
        &directory_->files_.try_emplace(absl::StrCat(filename_, ".pb.meta"), "")
             .first->second;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::UpdateMetadata 7\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::UpdateMetadata 8\n");
  GeneratedCodeInfo new_metadata;
  bool crossed_offset = false;
  size_t to_add = 0;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::UpdateMetadata 8\n");

  for (const auto& source_annotation : metadata.annotation()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::UpdateMetadata 9\n");
    // The first time an annotation at or after the insertion point is found,
    // insert the new metadata from info_to_insert_. Shift all annotations
    // after the new metadata by the length of the text that was inserted
    // (including any additional indent length).
    if (static_cast<size_t>(source_annotation.begin()) >= insertion_offset &&
        !crossed_offset) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::UpdateMetadata 10\n");
      crossed_offset = true;
      InsertShiftedInfo(insertion_content, insertion_offset, indent_length,
                        new_metadata);
      to_add += insertion_length;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::UpdateMetadata 10\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::UpdateMetadata 9\n");

    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::UpdateMetadata 11\n");
    GeneratedCodeInfo::Annotation* annotation = new_metadata.add_annotation();
    *annotation = source_annotation;
    annotation->set_begin(annotation->begin() + to_add);
    annotation->set_end(annotation->end() + to_add);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::UpdateMetadata 11\n");
  }

  // If there were never any annotations at or after the insertion point,
  // make sure to still insert the new metadata from info_to_insert_.
  if (!crossed_offset) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::UpdateMetadata 12\n");
    InsertShiftedInfo(insertion_content, insertion_offset, indent_length,
                      new_metadata);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::UpdateMetadata 12\n");
  }

  if (is_text_format) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::UpdateMetadata 13\n");
    TextFormat::PrintToString(new_metadata, encoded_data);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::UpdateMetadata 13\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::UpdateMetadata 14\n");
    new_metadata.SerializeToString(encoded_data);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::UpdateMetadata 14\n");
  }
}

CommandLineInterface::MemoryOutputStream::~MemoryOutputStream() {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::~MemoryOutputStream 1\n");
  // Make sure all data has been written.
  inner_.reset();

  // Insert into the directory.
  auto pair = directory_->files_.insert({filename_, ""});
  auto it = pair.first;
  bool already_present = !pair.second;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::~MemoryOutputStream 1\n");

  if (insertion_point_.empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::~MemoryOutputStream 2\n");
    // This was just a regular Open().
    if (already_present) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::~MemoryOutputStream 3\n");
      if (append_mode_) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::~MemoryOutputStream 4\n");
        it->second.append(data_);
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::~MemoryOutputStream 4\n");
      } else {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::~MemoryOutputStream 5\n");
        std::cerr << filename_ << ": Tried to write the same file twice."
                  << std::endl;
        directory_->had_error_ = true;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::~MemoryOutputStream 5\n");
      }
      return;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::~MemoryOutputStream 3\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::~MemoryOutputStream 2\n");

    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::~MemoryOutputStream 6\n");
    it->second.swap(data_);
    return;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::~MemoryOutputStream 6\n");
  }
  // This was an OpenForInsert().

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::~MemoryOutputStream 7\n");
  // If the data doesn't end with a clean line break, add one.
  if (!data_.empty() && data_[data_.size() - 1] != '\n') {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::~MemoryOutputStream 8\n");
    data_.push_back('\n');
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::~MemoryOutputStream 8\n");
  }

  // Find the file we are going to insert into.
  if (!already_present) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::~MemoryOutputStream 9\n");
    std::cerr << filename_ << ": Tried to insert into file that doesn't exist."
              << std::endl;
    directory_->had_error_ = true;
    return;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::~MemoryOutputStream 9\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::~MemoryOutputStream 7\n");

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::~MemoryOutputStream 10\n");
  std::string* target = &it->second;

  // Find the insertion point.
  std::string magic_string =
      absl::Substitute("@@protoc_insertion_point($0)", insertion_point_);
  std::string::size_type pos = target->find(magic_string);
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::~MemoryOutputStream 10\n");

  if (pos == std::string::npos) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::~MemoryOutputStream 11\n");
    std::cerr << filename_ << ": insertion point \"" << insertion_point_
              << "\" not found." << std::endl;
    directory_->had_error_ = true;
    return;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::~MemoryOutputStream 11\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::~MemoryOutputStream 12\n");
  if ((pos > 3) && (target->substr(pos - 3, 2) == "/*")) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::~MemoryOutputStream 13\n");
    // Support for inline "/* @@protoc_insertion_point() */"
    pos = pos - 3;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::~MemoryOutputStream 13\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::~MemoryOutputStream 14\n");
    // Seek backwards to the beginning of the line, which is where we will
    // insert the data.  Note that this has the effect of pushing the
    // insertion point down, so the data is inserted before it.  This is
    // intentional because it means that multiple insertions at the same point
    // will end up in the expected order in the final output.
    pos = target->find_last_of('\n', pos);
    if (pos == std::string::npos) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::~MemoryOutputStream 15\n");
      // Insertion point is on the first line.
      pos = 0;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::~MemoryOutputStream 15\n");
    } else {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::~MemoryOutputStream 16\n");
      // Advance to character after '\n'.
      ++pos;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::~MemoryOutputStream 16\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::~MemoryOutputStream 14\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::~MemoryOutputStream 12\n");

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::~MemoryOutputStream 17\n");
  // Extract indent.
  std::string indent_(*target, pos,
                      target->find_first_not_of(" \t", pos) - pos);
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::~MemoryOutputStream 17\n");

  if (indent_.empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::~MemoryOutputStream 18\n");
    // No indent.  This makes things easier.
    target->insert(pos, data_);
    UpdateMetadata(data_, pos, data_.size(), 0);
    return;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::~MemoryOutputStream 18\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::~MemoryOutputStream 19\n");
  // Calculate how much space we need.
  int indent_size = 0;
  for (size_t i = 0; i < data_.size(); ++i) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::~MemoryOutputStream 20\n");
    if (data_[i] == '\n') indent_size += indent_.size();
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::~MemoryOutputStream 20\n");
  }

  // Make a hole for it.
  target->insert(pos, data_.size() + indent_size, '\0');

  // Now copy in the data.
  std::string::size_type data_pos = 0;
  char* target_ptr = &(*target)[pos];
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::~MemoryOutputStream 19\n");

  while (data_pos < data_.size()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::~MemoryOutputStream 21\n");
    // Copy indent.
    memcpy(target_ptr, indent_.data(), indent_.size());
    target_ptr += indent_.size();

    // Copy line from data_.
    // We already guaranteed that data_ ends with a newline (above), so this
    // search can't fail.
    std::string::size_type line_length =
        data_.find_first_of('\n', data_pos) + 1 - data_pos;
    memcpy(target_ptr, data_.data() + data_pos, line_length);
    target_ptr += line_length;
    data_pos += line_length;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::~MemoryOutputStream 21\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MemoryOutputStream::~MemoryOutputStream 22\n");
  ABSL_CHECK_EQ(target_ptr, &(*target)[pos] + data_.size() + indent_size);

  UpdateMetadata(data_, pos, data_.size() + indent_size, indent_.size());
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MemoryOutputStream::~MemoryOutputStream 22\n");
}

// ===================================================================

#if defined(_WIN32) && !defined(__CYGWIN__)
const char* const CommandLineInterface::kPathSeparator = ";";
#else
const char* const CommandLineInterface::kPathSeparator = ":";
#endif

CommandLineInterface::CommandLineInterface()
    : direct_dependencies_violation_msg_(
          kDefaultDirectDependenciesViolationMsg) {}

CommandLineInterface::~CommandLineInterface() = default;

void CommandLineInterface::RegisterGenerator(const std::string& flag_name,
                                             CodeGenerator* generator,
                                             const std::string& help_text) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::RegisterGenerator 1\n");
  GeneratorInfo info;
  info.flag_name = flag_name;
  info.generator = generator;
  info.help_text = help_text;
  generators_by_flag_name_[flag_name] = info;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::RegisterGenerator 1\n");
}

void CommandLineInterface::RegisterGenerator(
    const std::string& flag_name, const std::string& option_flag_name,
    CodeGenerator* generator, const std::string& help_text) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::RegisterGenerator 2\n");
  GeneratorInfo info;
  info.flag_name = flag_name;
  info.option_flag_name = option_flag_name;
  info.generator = generator;
  info.help_text = help_text;
  generators_by_flag_name_[flag_name] = info;
  generators_by_option_name_[option_flag_name] = info;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::RegisterGenerator 2\n");
}

void CommandLineInterface::AllowPlugins(const std::string& exe_name_prefix) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::AllowPlugins 1\n");
  plugin_prefix_ = exe_name_prefix;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::AllowPlugins 1\n");
}

namespace {

bool ContainsProto3Optional(const Descriptor* desc) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ContainsProto3Optional 1\n");
  for (int i = 0; i < desc->field_count(); ++i) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ContainsProto3Optional 2\n");
    if (desc->field(i)->real_containing_oneof() == nullptr &&
        desc->field(i)->containing_oneof() != nullptr) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ContainsProto3Optional 3\n");
      return true;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ContainsProto3Optional 3\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ContainsProto3Optional 2\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ContainsProto3Optional 1\n");

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ContainsProto3Optional 4\n");
  for (int i = 0; i < desc->nested_type_count(); ++i) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ContainsProto3Optional 5\n");
    if (ContainsProto3Optional(desc->nested_type(i))) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ContainsProto3Optional 6\n");
      return true;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ContainsProto3Optional 6\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ContainsProto3Optional 5\n");
  }
  return false;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ContainsProto3Optional 4\n");
}

bool ContainsProto3Optional(Edition edition, const FileDescriptor* file) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ContainsProto3Optional 7\n");
  if (edition == Edition::EDITION_PROTO3) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ContainsProto3Optional 8\n");
    for (int i = 0; i < file->message_type_count(); ++i) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ContainsProto3Optional 9\n");
      if (ContainsProto3Optional(file->message_type(i))) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ContainsProto3Optional 10\n");
        return true;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ContainsProto3Optional 10\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ContainsProto3Optional 9\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ContainsProto3Optional 8\n");
  }
  return false;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ContainsProto3Optional 7\n");
}

bool HasReservedFieldNumber(const FieldDescriptor* field) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter HasReservedFieldNumber 1\n");
  if (field->number() >= FieldDescriptor::kFirstReservedNumber &&
      field->number() <= FieldDescriptor::kLastReservedNumber) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter HasReservedFieldNumber 2\n");
    return true;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit HasReservedFieldNumber 2\n");
  }
  return false;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit HasReservedFieldNumber 1\n");
}

}  // namespace

namespace {
std::unique_ptr<SimpleDescriptorDatabase>
PopulateSingleSimpleDescriptorDatabase(const std::string& descriptor_set_name) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter PopulateSingleSimpleDescriptorDatabase 1\n");
  int fd;
  do {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter PopulateSingleSimpleDescriptorDatabase 2\n");
    fd = open(descriptor_set_name.c_str(), O_RDONLY | O_BINARY);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit PopulateSingleSimpleDescriptorDatabase 2\n");
  } while (fd < 0 && errno == EINTR);
  
  if (fd < 0) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter PopulateSingleSimpleDescriptorDatabase 3\n");
    std::cerr << descriptor_set_name << ": " << strerror(ENOENT) << std::endl;
    return nullptr;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit PopulateSingleSimpleDescriptorDatabase 3\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit PopulateSingleSimpleDescriptorDatabase 1\n");

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter PopulateSingleSimpleDescriptorDatabase 4\n");
  FileDescriptorSet file_descriptor_set;
  bool parsed = file_descriptor_set.ParseFromFileDescriptor(fd);
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit PopulateSingleSimpleDescriptorDatabase 4\n");
  
  if (close(fd) != 0) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter PopulateSingleSimpleDescriptorDatabase 5\n");
    std::cerr << descriptor_set_name << ": close: " << strerror(errno)
              << std::endl;
    return nullptr;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit PopulateSingleSimpleDescriptorDatabase 5\n");
  }

  if (!parsed) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter PopulateSingleSimpleDescriptorDatabase 6\n");
    std::cerr << descriptor_set_name << ": Unable to parse." << std::endl;
    return nullptr;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit PopulateSingleSimpleDescriptorDatabase 6\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter PopulateSingleSimpleDescriptorDatabase 7\n");
  std::unique_ptr<SimpleDescriptorDatabase> database{
      new SimpleDescriptorDatabase()};
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit PopulateSingleSimpleDescriptorDatabase 7\n");

  for (int j = 0; j < file_descriptor_set.file_size(); j++) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter PopulateSingleSimpleDescriptorDatabase 8\n");
    FileDescriptorProto previously_added_file_descriptor_proto;
    if (database->FindFileByName(file_descriptor_set.file(j).name(),
                                 &previously_added_file_descriptor_proto)) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter PopulateSingleSimpleDescriptorDatabase 9\n");
      // already present - skip
      continue;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit PopulateSingleSimpleDescriptorDatabase 9\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit PopulateSingleSimpleDescriptorDatabase 8\n");
    
    if (!database->Add(file_descriptor_set.file(j))) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter PopulateSingleSimpleDescriptorDatabase 10\n");
      return nullptr;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit PopulateSingleSimpleDescriptorDatabase 10\n");
    }
  }
  return database;
}

// Converts the OptionTargetType enum to a string suitable for use in error
// messages.
absl::string_view TargetTypeString(FieldOptions::OptionTargetType target_type) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter TargetTypeString 1\n");
  switch (target_type) {
    case FieldOptions::TARGET_TYPE_FILE:
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter TargetTypeString 2\n");
      return "file";
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit TargetTypeString 2\n");
    case FieldOptions::TARGET_TYPE_EXTENSION_RANGE:
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter TargetTypeString 3\n");
      return "extension range";
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit TargetTypeString 3\n");
    case FieldOptions::TARGET_TYPE_MESSAGE:
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter TargetTypeString 4\n");
      return "message";
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit TargetTypeString 4\n");
    case FieldOptions::TARGET_TYPE_FIELD:
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter TargetTypeString 5\n");
      return "field";
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit TargetTypeString 5\n");
    case FieldOptions::TARGET_TYPE_ONEOF:
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter TargetTypeString 6\n");
      return "oneof";
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit TargetTypeString 6\n");
    case FieldOptions::TARGET_TYPE_ENUM:
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter TargetTypeString 7\n");
      return "enum";
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit TargetTypeString 7\n");
    case FieldOptions::TARGET_TYPE_ENUM_ENTRY:
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter TargetTypeString 8\n");
      return "enum entry";
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit TargetTypeString 8\n");
    case FieldOptions::TARGET_TYPE_SERVICE:
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter TargetTypeString 9\n");
      return "service";
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit TargetTypeString 9\n");
    case FieldOptions::TARGET_TYPE_METHOD:
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter TargetTypeString 10\n");
      return "method";
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit TargetTypeString 10\n");
    default:
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter TargetTypeString 11\n");
      return "unknown";
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit TargetTypeString 11\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit TargetTypeString 1\n");
}

// Indicates whether the field is compatible with the given target type.
bool IsFieldCompatible(const FieldDescriptor& field,
                       FieldOptions::OptionTargetType target_type) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter IsFieldCompatible 1\n");
  const RepeatedField<int>& allowed_targets = field.options().targets();
  bool result = allowed_targets.empty() ||
         absl::c_linear_search(allowed_targets, target_type);
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit IsFieldCompatible 1\n");
  return result;
}

// Recursively validates that the options message (or subpiece of an options
// message) is compatible with the given target type.
bool ValidateTargetConstraintsRecursive(
    const Message& m, DescriptorPool::ErrorCollector& error_collector,
    absl::string_view file_name, FieldOptions::OptionTargetType target_type) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ValidateTargetConstraintsRecursive 1\n");
  std::vector<const FieldDescriptor*> fields;
  const Reflection* reflection = m.GetReflection();
  reflection->ListFields(m, &fields);
  bool success = true;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ValidateTargetConstraintsRecursive 1\n");
  
  for (const auto* field : fields) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ValidateTargetConstraintsRecursive 2\n");
    if (!IsFieldCompatible(*field, target_type)) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ValidateTargetConstraintsRecursive 3\n");
      success = false;
      error_collector.RecordError(
          file_name, "", nullptr, DescriptorPool::ErrorCollector::OPTION_NAME,
          absl::StrCat("Option ", field->full_name(),
                       " cannot be set on an entity of type `",
                       TargetTypeString(target_type), "`."));
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ValidateTargetConstraintsRecursive 3\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ValidateTargetConstraintsRecursive 2\n");
    
    if (field->type() == FieldDescriptor::TYPE_MESSAGE) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ValidateTargetConstraintsRecursive 4\n");
      if (field->is_repeated()) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ValidateTargetConstraintsRecursive 5\n");
        int field_size = reflection->FieldSize(m, field);
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ValidateTargetConstraintsRecursive 5\n");
        
        for (int i = 0; i < field_size; ++i) {
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ValidateTargetConstraintsRecursive 6\n");
          if (!ValidateTargetConstraintsRecursive(
                  reflection->GetRepeatedMessage(m, field, i), error_collector,
                  file_name, target_type)) {
            fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ValidateTargetConstraintsRecursive 7\n");
            success = false;
            fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ValidateTargetConstraintsRecursive 7\n");
          }
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ValidateTargetConstraintsRecursive 6\n");
        }
      } else if (!ValidateTargetConstraintsRecursive(
                     reflection->GetMessage(m, field), error_collector,
                     file_name, target_type)) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ValidateTargetConstraintsRecursive 8\n");
        success = false;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ValidateTargetConstraintsRecursive 8\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ValidateTargetConstraintsRecursive 4\n");
    }
  }
  return success;
}

// Validates that the options message is correct with respect to target
// constraints, returning true if successful. This function converts the
// options message to a DynamicMessage so that we have visibility into custom
// options. We take the element name as a FunctionRef so that we do not have to
// pay the cost of constructing it unless there is an error.
bool ValidateTargetConstraints(const Message& options,
                               const DescriptorPool& pool,
                               DescriptorPool::ErrorCollector& error_collector,
                               absl::string_view file_name,
                               FieldOptions::OptionTargetType target_type) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ValidateTargetConstraints 1\n");
  const Descriptor* descriptor =
      pool.FindMessageTypeByName(options.GetTypeName());
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ValidateTargetConstraints 1\n");
  
  if (descriptor == nullptr) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ValidateTargetConstraints 2\n");
    // We were unable to find the options message in the descriptor pool. This
    // implies that the proto files we are working with do not depend on
    // descriptor.proto, in which case there are no custom options to worry
    // about. We can therefore skip the use of DynamicMessage.
    bool result = ValidateTargetConstraintsRecursive(options, error_collector,
                                              file_name, target_type);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ValidateTargetConstraints 2\n");
    return result;
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ValidateTargetConstraints 3\n");
    DynamicMessageFactory factory;
    std::unique_ptr<Message> dynamic_message(
        factory.GetPrototype(descriptor)->New());
    std::string serialized;
    ABSL_CHECK(options.SerializeToString(&serialized));
    ABSL_CHECK(dynamic_message->ParseFromString(serialized));
    bool result = ValidateTargetConstraintsRecursive(*dynamic_message, error_collector,
                                              file_name, target_type);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ValidateTargetConstraints 3\n");
    return result;
  }
}

// The overloaded GetTargetType() functions below allow us to map from a
// descriptor type to the associated OptionTargetType enum.
FieldOptions::OptionTargetType GetTargetType(const FileDescriptor*) {
  fprintf(stderr, "\n");
  fprintf(stderr, "\n");
  return FieldOptions::TARGET_TYPE_FILE;
}

FieldOptions::OptionTargetType GetTargetType(
    const Descriptor::ExtensionRange*) {
  fprintf(stderr, "\n");
  fprintf(stderr, "\n");
  return FieldOptions::TARGET_TYPE_EXTENSION_RANGE;
}

FieldOptions::OptionTargetType GetTargetType(const Descriptor*) {
  fprintf(stderr, "\n");
  fprintf(stderr, "\n");
  return FieldOptions::TARGET_TYPE_MESSAGE;
}

FieldOptions::OptionTargetType GetTargetType(const FieldDescriptor*) {
  fprintf(stderr, "\n");
  fprintf(stderr, "\n");
  return FieldOptions::TARGET_TYPE_FIELD;
}

FieldOptions::OptionTargetType GetTargetType(const OneofDescriptor*) {
  fprintf(stderr, "\n");
  fprintf(stderr, "\n");
  return FieldOptions::TARGET_TYPE_ONEOF;
}

FieldOptions::OptionTargetType GetTargetType(const EnumDescriptor*) {
  fprintf(stderr, "\n");
  fprintf(stderr, "\n");
  return FieldOptions::TARGET_TYPE_ENUM;
}

FieldOptions::OptionTargetType GetTargetType(const EnumValueDescriptor*) {
  fprintf(stderr, "\n");
  fprintf(stderr, "\n");
  return FieldOptions::TARGET_TYPE_ENUM_ENTRY;
}

FieldOptions::OptionTargetType GetTargetType(const ServiceDescriptor*) {
  fprintf(stderr, "\n");
  fprintf(stderr, "\n");
  return FieldOptions::TARGET_TYPE_SERVICE;
}

FieldOptions::OptionTargetType GetTargetType(const MethodDescriptor*) {
  fprintf(stderr, "\n");
  fprintf(stderr, "\n");
  return FieldOptions::TARGET_TYPE_METHOD;
}
}  // namespace

int CommandLineInterface::Run(int argc, const char* const argv[]) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 1\n");
  Clear();
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 1\n");

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 2\n");
  switch (ParseArguments(argc, argv)) {
    case PARSE_ARGUMENT_DONE_AND_EXIT:
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 3\n");
      return 0;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 3\n");
    case PARSE_ARGUMENT_FAIL:
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 4\n");
      return 1;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 4\n");
    case PARSE_ARGUMENT_DONE_AND_CONTINUE:
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 5\n");
      break;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 5\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 2\n");

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 6\n");
  std::vector<const FileDescriptor*> parsed_files;
  std::unique_ptr<DiskSourceTree> disk_source_tree;
  std::unique_ptr<ErrorPrinter> error_collector;
  std::unique_ptr<DescriptorPool> descriptor_pool;

  // The SimpleDescriptorDatabases here are the constituents of the
  // MergedDescriptorDatabase descriptor_set_in_database, so this vector is for
  // managing their lifetimes. Its scope should match descriptor_set_in_database
  std::vector<std::unique_ptr<SimpleDescriptorDatabase>>
      databases_per_descriptor_set;
  std::unique_ptr<MergedDescriptorDatabase> descriptor_set_in_database;

  std::unique_ptr<SourceTreeDescriptorDatabase> source_tree_database;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 6\n");

  // Any --descriptor_set_in FileDescriptorSet objects will be used as a
  // fallback to input_files on command line, so create that db first.
  if (!descriptor_set_in_names_.empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 7\n");
    for (const std::string& name : descriptor_set_in_names_) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 8\n");
      std::unique_ptr<SimpleDescriptorDatabase> database_for_descriptor_set =
          PopulateSingleSimpleDescriptorDatabase(name);
      if (!database_for_descriptor_set) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 9\n");
        return EXIT_FAILURE;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 9\n");
      }
      databases_per_descriptor_set.push_back(
          std::move(database_for_descriptor_set));
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 8\n");
    }

    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 10\n");
    std::vector<DescriptorDatabase*> raw_databases_per_descriptor_set;
    raw_databases_per_descriptor_set.reserve(
        databases_per_descriptor_set.size());
    for (const std::unique_ptr<SimpleDescriptorDatabase>& db :
         databases_per_descriptor_set) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 11\n");
      raw_databases_per_descriptor_set.push_back(db.get());
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 11\n");
    }
    descriptor_set_in_database = std::make_unique<MergedDescriptorDatabase>(
        raw_databases_per_descriptor_set);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 10\n");
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 7\n");
  }

  if (proto_path_.empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 12\n");
    // If there are no --proto_path flags, then just look in the specified
    // --descriptor_set_in files.  But first, verify that the input files are
    // there.
    if (!VerifyInputFilesInDescriptors(descriptor_set_in_database.get())) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 13\n");
      return 1;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 13\n");
    }

    error_collector = std::make_unique<ErrorPrinter>(error_format_);
    descriptor_pool = std::make_unique<DescriptorPool>(
        descriptor_set_in_database.get(), error_collector.get());
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 12\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 14\n");
    disk_source_tree = std::make_unique<DiskSourceTree>();
    if (!InitializeDiskSourceTree(disk_source_tree.get(),
                                  descriptor_set_in_database.get())) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 15\n");
      return 1;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 15\n");
    }

    error_collector =
        std::make_unique<ErrorPrinter>(error_format_, disk_source_tree.get());

    source_tree_database = std::make_unique<SourceTreeDescriptorDatabase>(
        disk_source_tree.get(), descriptor_set_in_database.get());
    source_tree_database->RecordErrorsTo(error_collector.get());

    descriptor_pool = std::make_unique<DescriptorPool>(
        source_tree_database.get(),
        source_tree_database->GetValidationErrorCollector());
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 14\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 16\n");
  descriptor_pool->EnforceWeakDependencies(true);
  descriptor_pool->EnforceOptionDependencies(true);
  descriptor_pool->EnforceNamingStyle(true);
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 16\n");

  if (!SetupFeatureResolution(*descriptor_pool)) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 17\n");
    return EXIT_FAILURE;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 17\n");
  }

  // Enforce extension declarations only when compiling. We want to skip this
  // enforcement when protoc is just being invoked to encode or decode
  // protos. If allowlist is disabled, we will not check for descriptor
  // extensions declarations, either.
  if (mode_ == MODE_COMPILE) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 18\n");
      descriptor_pool->EnforceExtensionDeclarations(
          ExtDeclEnforcementLevel::kCustomExtensions);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 18\n");
  }
  
  if (!ParseInputFiles(descriptor_pool.get(), disk_source_tree.get(),
                       &parsed_files)) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 19\n");
    return 1;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 19\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 20\n");
  bool validation_error = false;  // Defer exiting so we log more warnings.
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 20\n");

  for (auto& file : parsed_files) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 21\n");
    google::protobuf::internal::VisitDescriptors(
        *file, [&](const FieldDescriptor& field) {
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 22\n");
          if (HasReservedFieldNumber(&field)) {
            fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 23\n");
            const char* error_link = nullptr;
            validation_error = true;
            std::string error;
            if (field.number() >= FieldDescriptor::kFirstReservedNumber &&
                field.number() <= FieldDescriptor::kLastReservedNumber) {
              fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 24\n");
              error = absl::Substitute(
                  "Field numbers $0 through $1 are reserved "
                  "for the protocol buffer library implementation.",
                  FieldDescriptor::kFirstReservedNumber,
                  FieldDescriptor::kLastReservedNumber);
              fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 24\n");
            } else {
              fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 25\n");
              error = absl::Substitute(
                  "Field number $0 is reserved for specific purposes.",
                  field.number());
              fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 25\n");
            }
            if (error_link) {
              fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 26\n");
              absl::StrAppend(&error, "(See ", error_link, ")");
              fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 26\n");
            }
            static_cast<DescriptorPool::ErrorCollector*>(error_collector.get())
                ->RecordError(field.file()->name(), field.full_name(), nullptr,
                              DescriptorPool::ErrorCollector::NUMBER, error);
            fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 23\n");
          }
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 22\n");
        });
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 21\n");
  }

  // We visit one file at a time because we need to provide the file name for
  // error messages. Usually we can get the file name from any descriptor with
  // something like descriptor->file()->name(), but ExtensionRange does not
  // support this.
  for (const google::protobuf::FileDescriptor* file : parsed_files) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 27\n");
    FileDescriptorProto proto;
    file->CopyTo(&proto);
    google::protobuf::internal::VisitDescriptors(
        *file, proto, [&](const auto& descriptor, const auto& proto) {
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 28\n");
          if (!ValidateTargetConstraints(proto.options(), *descriptor_pool,
                                         *error_collector, file->name(),
                                         GetTargetType(&descriptor))) {
            fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 29\n");
            validation_error = true;
            fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 29\n");
          }
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 28\n");
        });
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 27\n");
  }


  if (validation_error) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 30\n");
    return 1;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 30\n");
  }

  if (!EnforceProtocEditionsSupport(parsed_files)) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 31\n");
    return 1;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 31\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 32\n");
  // We construct a separate GeneratorContext for each output location.  Note
  // that two code generators may output to the same location, in which case
  // they should share a single GeneratorContext so that OpenForInsert() works.
  GeneratorContextMap output_directories;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 32\n");

  // Generate output.
  if (mode_ == MODE_COMPILE) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 33\n");
    for (size_t i = 0; i < output_directives_.size(); ++i) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 34\n");
      std::string output_location = output_directives_[i].output_location;
      if (!absl::EndsWith(output_location, ".zip") &&
          !absl::EndsWith(output_location, ".jar") &&
          !absl::EndsWith(output_location, ".srcjar")) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 35\n");
        AddTrailingSlash(&output_location);
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 35\n");
      }

      auto& generator = output_directories[output_location];
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 34\n");

      if (!generator) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 36\n");
        // First time we've seen this output location.
        generator = std::make_unique<GeneratorContextImpl>(parsed_files);
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 36\n");
      }

      if (!GenerateOutput(parsed_files, output_directives_[i],
                          generator.get())) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 37\n");
        return 1;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 37\n");
      }
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 33\n");
  }

  for (const auto& pair : output_directories) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 38\n");
    const std::string& location = pair.first;
    GeneratorContextImpl* directory = pair.second.get();
    if (absl::EndsWith(location, "/")) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 39\n");
      if (!directory->WriteAllToDisk(location)) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 40\n");
        return 1;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 40\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 39\n");
    } else {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 41\n");
      if (absl::EndsWith(location, ".jar")) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 42\n");
        directory->AddJarManifest();
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 42\n");
      }

      if (!directory->WriteAllToZip(location)) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 43\n");
        return 1;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 43\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 41\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 38\n");
  }

  if (!dependency_out_name_.empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 44\n");
    ABSL_DCHECK(disk_source_tree.get());
    if (!GenerateDependencyManifestFile(parsed_files, output_directories,
                                        disk_source_tree.get())) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 45\n");
      return 1;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 45\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 44\n");
  }

  if (!descriptor_set_out_name_.empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 46\n");
    if (!WriteDescriptorSet(parsed_files)) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 47\n");
      return 1;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 47\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 46\n");
  }

  if (!edition_defaults_out_name_.empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 48\n");
    if (!WriteEditionDefaults(*descriptor_pool)) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 49\n");
      return 1;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 49\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 48\n");
  }

  if (mode_ == MODE_ENCODE || mode_ == MODE_DECODE) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 50\n");
    if (codec_type_.empty()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 51\n");
      // HACK:  Define an EmptyMessage type to use for decoding.
      DescriptorPool pool;
      FileDescriptorProto file;
      file.set_name("empty_message.proto");
      file.add_message_type()->set_name("EmptyMessage");
      ABSL_CHECK(pool.BuildFile(file) != nullptr);
      codec_type_ = "EmptyMessage";
      if (!EncodeOrDecode(&pool)) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 52\n");
        return 1;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 52\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 51\n");
    } else {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 53\n");
      if (!EncodeOrDecode(descriptor_pool.get())) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 54\n");
        return 1;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 54\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 53\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 50\n");
  }

  if (error_collector->FoundErrors() ||
      (fatal_warnings_ && error_collector->FoundWarnings())) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 55\n");
    return 1;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 55\n");
  }

  if (mode_ == MODE_PRINT) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 56\n");
    switch (print_mode_) {
      case PRINT_FREE_FIELDS:
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 57\n");
        for (size_t i = 0; i < parsed_files.size(); ++i) {
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 58\n");
          const FileDescriptor* fd = parsed_files[i];
          for (int j = 0; j < fd->message_type_count(); ++j) {
            fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 59\n");
            PrintFreeFieldNumbers(fd->message_type(j));
            fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 59\n");
          }
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 58\n");
        }
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 57\n");
        break;
      case PRINT_NONE:
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::Run 60\n");
        ABSL_LOG(ERROR)
            << "If the code reaches here, it usually means a bug of "
               "flag parsing in the CommandLineInterface.";
        return 1;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 60\n");

        // Do not add a default case.
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::Run 56\n");
  }
  return 0;
}

bool CommandLineInterface::InitializeDiskSourceTree(
    DiskSourceTree* source_tree, DescriptorDatabase* fallback_database) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::InitializeDiskSourceTree 1\n");
  AddDefaultProtoPaths(&proto_path_);

  // Set up the source tree.
  for (size_t i = 0; i < proto_path_.size(); ++i) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::InitializeDiskSourceTree 2\n");
    source_tree->MapPath(proto_path_[i].first, proto_path_[i].second);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::InitializeDiskSourceTree 2\n");
  }

  // Map input files to virtual paths if possible.
  if (!MakeInputsBeProtoPathRelative(source_tree, fallback_database)) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::InitializeDiskSourceTree 3\n");
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::InitializeDiskSourceTree 3\n");
  }

  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::InitializeDiskSourceTree 1\n");
}

bool CommandLineInterface::VerifyInputFilesInDescriptors(
    DescriptorDatabase* database) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::VerifyInputFilesInDescriptors 1\n");
  for (const auto& input_file : input_files_) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::VerifyInputFilesInDescriptors 2\n");
    FileDescriptorProto file_descriptor;
    if (!database->FindFileByName(input_file, &file_descriptor)) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::VerifyInputFilesInDescriptors 3\n");
      std::cerr << "Could not find file in descriptor database: " << input_file
                << ": " << strerror(ENOENT) << std::endl;
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::VerifyInputFilesInDescriptors 3\n");
    }

    // Enforce --disallow_services.
    if (disallow_services_ && file_descriptor.service_size() > 0) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::VerifyInputFilesInDescriptors 4\n");
      std::cerr << file_descriptor.name()
                << ": This file contains services, but "
                   "--disallow_services was used."
                << std::endl;
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::VerifyInputFilesInDescriptors 4\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::VerifyInputFilesInDescriptors 2\n");
  }
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::VerifyInputFilesInDescriptors 1\n");
}
bool CommandLineInterface::SetupFeatureResolution(DescriptorPool& pool) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter SetupFeatureResolution 1\n");
  // Calculate the feature defaults for each built-in generator.  All generators
  // that support editions must agree on the supported edition range.
  std::vector<const FieldDescriptor*> feature_extensions;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit SetupFeatureResolution 1\n");
  
  for (const auto& output : output_directives_) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter SetupFeatureResolution 2\n");
    if (output.generator == nullptr) continue;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit SetupFeatureResolution 2\n");
    
    if (!experimental_editions_ &&
        (output.generator->GetSupportedFeatures() &
         CodeGenerator::FEATURE_SUPPORTS_EDITIONS) != 0) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter SetupFeatureResolution 3\n");
      // Only validate min/max edition on generators that advertise editions
      // support.  Generators still under development will always use the
      // correct values.
      if (output.generator->GetMinimumEdition() != ProtocMinimumEdition()) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter SetupFeatureResolution 4\n");
        ABSL_LOG(ERROR) << "Built-in generator " << output.name
                        << " specifies a minimum edition "
                        << output.generator->GetMinimumEdition()
                        << " which is not the protoc minimum "
                        << ProtocMinimumEdition() << ".";
        return false;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit SetupFeatureResolution 4\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit SetupFeatureResolution 3\n");
      
      if (output.generator->GetMaximumEdition() != ProtocMaximumEdition()) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter SetupFeatureResolution 5\n");
        ABSL_LOG(ERROR) << "Built-in generator " << output.name
                        << " specifies a maximum edition "
                        << output.generator->GetMaximumEdition()
                        << " which is not the protoc maximum "
                        << ProtocMaximumEdition() << ".";
        return false;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit SetupFeatureResolution 5\n");
      }
    }
    
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter SetupFeatureResolution 6\n");
    for (const FieldDescriptor* ext :
         output.generator->GetFeatureExtensions()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter SetupFeatureResolution 7\n");
      if (ext == nullptr) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter SetupFeatureResolution 8\n");
        ABSL_LOG(ERROR) << "Built-in generator " << output.name
                        << " specifies an unknown feature extension.";
        return false;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit SetupFeatureResolution 8\n");
      }
      feature_extensions.push_back(ext);
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit SetupFeatureResolution 7\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit SetupFeatureResolution 6\n");
  }
  
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter SetupFeatureResolution 9\n");
  absl::StatusOr<FeatureSetDefaults> defaults =
      FeatureResolver::CompileDefaults(
          FeatureSet::descriptor(), feature_extensions, ProtocMinimumEdition(),
          MaximumKnownEdition());
  if (!defaults.ok()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter SetupFeatureResolution 10\n");
    ABSL_LOG(ERROR) << defaults.status();
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit SetupFeatureResolution 10\n");
  }
  absl::Status status = pool.SetFeatureSetDefaults(std::move(defaults).value());
  ABSL_CHECK(status.ok()) << status.message();
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit SetupFeatureResolution 9\n");
}

bool CommandLineInterface::ParseInputFiles(
    DescriptorPool* descriptor_pool, DiskSourceTree* source_tree,
    std::vector<const FileDescriptor*>* parsed_files) {
  fprintf(stderr, "\n");

  if (!proto_path_.empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseInputFiles 2\n");
    // Track unused imports in all source files that were loaded from the
    // filesystem. We do not track unused imports for files loaded from
    // descriptor sets as they may be programmatically generated in which case
    // exerting this level of rigor is less desirable. We're also making the
    // assumption that the initial parse of the proto from the filesystem
    // was rigorous in checking unused imports and that the descriptor set
    // being parsed was produced then and that it was subsequent mutations
    // of that descriptor set that left unused imports.
    //
    // Note that relying on proto_path exclusively is limited in that we may
    // be loading descriptors from both the filesystem and descriptor sets
    // depending on the invocation. At least for invocations that are
    // exclusively reading from descriptor sets, we can eliminate this failure
    // condition.
    for (const auto& input_file : input_files_) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseInputFiles 3\n");
      descriptor_pool->AddDirectInputFile(input_file);
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseInputFiles 3\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseInputFiles 2\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseInputFiles 4\n");
  bool result = true;
  // Parse each file.
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseInputFiles 4\n");
  
  for (const auto& input_file : input_files_) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseInputFiles 5\n");
    // Import the file.
    const FileDescriptor* parsed_file =
        descriptor_pool->FindFileByName(input_file);
    if (parsed_file == nullptr) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseInputFiles 6\n");
      result = false;
      break;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseInputFiles 6\n");
    }
    parsed_files->push_back(parsed_file);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseInputFiles 5\n");

    // Enforce --disallow_services.
    if (disallow_services_ && parsed_file->service_count() > 0) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseInputFiles 7\n");
      std::cerr << parsed_file->name()
                << ": This file contains services, but "
                   "--disallow_services was used."
                << std::endl;
      result = false;
      break;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseInputFiles 7\n");
    }

    // Enforce --direct_dependencies
    if (direct_dependencies_explicitly_set_) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseInputFiles 8\n");
      bool indirect_imports = false;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseInputFiles 8\n");
      
      for (int i = 0; i < parsed_file->dependency_count(); ++i) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseInputFiles 9\n");
        if (direct_dependencies_.find(parsed_file->dependency(i)->name()) ==
            direct_dependencies_.end()) {
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseInputFiles 10\n");
          indirect_imports = true;
          std::cerr << parsed_file->name() << ": "
                    << absl::StrReplaceAll(
                           direct_dependencies_violation_msg_,
                           {{"%s", parsed_file->dependency(i)->name()}})
                    << std::endl;
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseInputFiles 10\n");
        }
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseInputFiles 9\n");
      }
      
      if (indirect_imports) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseInputFiles 11\n");
        result = false;
        break;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseInputFiles 11\n");
      }
    }
  }
  
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseInputFiles 12\n");
  descriptor_pool->ClearDirectInputFiles();
  return result;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseInputFiles 12\n");
}

void CommandLineInterface::Clear() {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter Clear 1\n");
  // Clear all members that are set by Run().  Note that we must not clear
  // members which are set by other methods before Run() is called.
  executable_name_.clear();
  proto_path_.clear();
  input_files_.clear();
  direct_dependencies_.clear();
  direct_dependencies_violation_msg_ = kDefaultDirectDependenciesViolationMsg;
  output_directives_.clear();
  codec_type_.clear();
  descriptor_set_in_names_.clear();
  descriptor_set_out_name_.clear();
  dependency_out_name_.clear();

  experimental_editions_ = false;
  edition_defaults_out_name_.clear();
  edition_defaults_minimum_ = EDITION_UNKNOWN;
  edition_defaults_maximum_ = EDITION_UNKNOWN;

  mode_ = MODE_COMPILE;
  print_mode_ = PRINT_NONE;
  imports_in_descriptor_set_ = false;
  source_info_in_descriptor_set_ = false;
  retain_options_in_descriptor_set_ = false;
  disallow_services_ = false;
  direct_dependencies_explicitly_set_ = false;
  deterministic_output_ = false;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit Clear 1\n");
}

bool CommandLineInterface::MakeProtoProtoPathRelative(
    DiskSourceTree* source_tree, std::string* proto,
    DescriptorDatabase* fallback_database) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MakeProtoProtoPathRelative 1\n");
  // If it's in the fallback db, don't report non-existent file errors.
  FileDescriptorProto fallback_file;
  bool in_fallback_database =
      fallback_database != nullptr &&
      fallback_database->FindFileByName(*proto, &fallback_file);
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MakeProtoProtoPathRelative 1\n");

  // If the input file path is not a physical file path, it must be a virtual
  // path.
  if (access(proto->c_str(), F_OK) < 0) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MakeProtoProtoPathRelative 2\n");
    std::string disk_file;
    if (source_tree->VirtualFileToDiskFile(*proto, &disk_file) ||
        in_fallback_database) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MakeProtoProtoPathRelative 3\n");
      return true;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MakeProtoProtoPathRelative 3\n");
    } else {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MakeProtoProtoPathRelative 4\n");
      std::cerr << "Could not make proto path relative: " << *proto << ": "
                << strerror(ENOENT) << std::endl;
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MakeProtoProtoPathRelative 4\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MakeProtoProtoPathRelative 2\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MakeProtoProtoPathRelative 5\n");
  std::string virtual_file, shadowing_disk_file;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MakeProtoProtoPathRelative 5\n");
  
  switch (source_tree->DiskFileToVirtualFile(*proto, &virtual_file,
                                             &shadowing_disk_file)) {
    case DiskSourceTree::SUCCESS:
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MakeProtoProtoPathRelative 6\n");
      *proto = virtual_file;
      break;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MakeProtoProtoPathRelative 6\n");
    case DiskSourceTree::SHADOWED:
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MakeProtoProtoPathRelative 7\n");
      std::cerr << *proto << ": Input is shadowed in the --proto_path by \""
                << shadowing_disk_file
                << "\".  Either use the latter file as your input or reorder "
                   "the --proto_path so that the former file's location "
                   "comes first."
                << std::endl;
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MakeProtoProtoPathRelative 7\n");
    case DiskSourceTree::CANNOT_OPEN: {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MakeProtoProtoPathRelative 8\n");
      if (in_fallback_database) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MakeProtoProtoPathRelative 9\n");
        return true;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MakeProtoProtoPathRelative 9\n");
      }
      std::string error_str = source_tree->GetLastErrorMessage().empty()
                                  ? strerror(errno)
                                  : source_tree->GetLastErrorMessage();
      std::cerr << "Could not map to virtual file: " << *proto << ": "
                << error_str << std::endl;
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MakeProtoProtoPathRelative 8\n");
    }
    case DiskSourceTree::NO_MAPPING: {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MakeProtoProtoPathRelative 10\n");
      // Try to interpret the path as a virtual path.
      std::string disk_file;
      if (source_tree->VirtualFileToDiskFile(*proto, &disk_file) ||
          in_fallback_database) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MakeProtoProtoPathRelative 11\n");
        return true;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MakeProtoProtoPathRelative 11\n");
      } else {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MakeProtoProtoPathRelative 12\n");
        // The input file path can't be mapped to any --proto_path and it also
        // can't be interpreted as a virtual path.
        std::cerr
            << *proto
            << ": File does not reside within any path "
               "specified using --proto_path (or -I).  You must specify a "
               "--proto_path which encompasses this file.  Note that the "
               "proto_path must be an exact prefix of the .proto file "
               "names -- protoc is too dumb to figure out when two paths "
               "(e.g. absolute and relative) are equivalent (it's harder "
               "than you think)."
            << std::endl;
        return false;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MakeProtoProtoPathRelative 12\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MakeProtoProtoPathRelative 10\n");
    }
  }
  
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MakeProtoProtoPathRelative 13\n");
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MakeProtoProtoPathRelative 13\n");
}

bool CommandLineInterface::MakeInputsBeProtoPathRelative(
    DiskSourceTree* source_tree, DescriptorDatabase* fallback_database) {
  fprintf(stderr, "\n");
  for (auto& input_file : input_files_) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MakeInputsBeProtoPathRelative 2\n");
    if (!MakeProtoProtoPathRelative(source_tree, &input_file,
                                    fallback_database)) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MakeInputsBeProtoPathRelative 3\n");
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MakeInputsBeProtoPathRelative 3\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MakeInputsBeProtoPathRelative 2\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter MakeInputsBeProtoPathRelative 4\n");
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit MakeInputsBeProtoPathRelative 4\n");
}


bool CommandLineInterface::ExpandArgumentFile(
    const char* file, std::vector<std::string>* arguments) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ExpandArgumentFile 1\n");
// On windows to force ifstream to handle proper utr-8, we need to convert to
// proper supported utf8 wstring. If we dont then the file can't be opened.
#ifdef _MSC_VER
  // Convert the file name to wide chars.
  int size = MultiByteToWideChar(CP_UTF8, 0, file, strlen(file), nullptr, 0);
  std::wstring file_str;
  file_str.resize(size);
  MultiByteToWideChar(CP_UTF8, 0, file, strlen(file), &file_str[0],
                      file_str.size());
#else
  std::string file_str(file);
#endif
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ExpandArgumentFile 1\n");

  // The argument file is searched in the working directory only. We don't
  // use the proto import path here.
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ExpandArgumentFile 2\n");
  std::ifstream file_stream(file_str.c_str());
  if (!file_stream.is_open()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ExpandArgumentFile 3\n");
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ExpandArgumentFile 3\n");
  }
  std::string argument;
  // We don't support any kind of shell expansion right now.
  while (std::getline(file_stream, argument)) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ExpandArgumentFile 4\n");
    arguments->push_back(argument);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ExpandArgumentFile 4\n");
  }
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ExpandArgumentFile 2\n");
}

CommandLineInterface::ParseArgumentStatus CommandLineInterface::ParseArguments(
    int argc, const char* const argv[]) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 1\n");
  executable_name_ = argv[0];

  std::vector<std::string> arguments;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 1\n");
  
  for (int i = 1; i < argc; ++i) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 2\n");
    if (argv[i][0] == '@') {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 3\n");
      if (!ExpandArgumentFile(argv[i] + 1, &arguments)) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 4\n");
        std::cerr << "Failed to open argument file: " << (argv[i] + 1)
                  << std::endl;
        return PARSE_ARGUMENT_FAIL;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 4\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 3\n");
      continue;
    }
    arguments.push_back(argv[i]);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 2\n");
  }

  // if no arguments are given, show help
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 5\n");
  if (arguments.empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 6\n");
    PrintHelpText();
    return PARSE_ARGUMENT_DONE_AND_EXIT;  // Exit without running compiler.
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 6\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 5\n");

  // Iterate through all arguments and parse them.
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 7\n");
  for (size_t i = 0; i < arguments.size(); ++i) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 8\n");
    std::string name, value;

    if (ParseArgument(arguments[i].c_str(), &name, &value)) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 9\n");
      // Returned true => Use the next argument as the flag value.
      if (i + 1 == arguments.size() || arguments[i + 1][0] == '-') {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 10\n");
        std::cerr << "Missing value for flag: " << name << std::endl;
        if (name == "--decode") {
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 11\n");
          std::cerr << "To decode an unknown message, use --decode_raw."
                    << std::endl;
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 11\n");
        }
        return PARSE_ARGUMENT_FAIL;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 10\n");
      } else {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 12\n");
        ++i;
        value = arguments[i];
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 12\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 9\n");
    }

    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 13\n");
    ParseArgumentStatus status = InterpretArgument(name, value);
    if (status != PARSE_ARGUMENT_DONE_AND_CONTINUE) return status;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 13\n");
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 8\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 7\n");

  // Make sure each plugin option has a matching plugin output.
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 14\n");
  bool foundUnknownPluginOption = false;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 14\n");
  
  for (const auto& kv : plugin_parameters_) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 15\n");
    if (plugins_.find(kv.first) != plugins_.end()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 16\n");
      continue;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 16\n");
    }
    bool foundImplicitPlugin = false;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 15\n");
    
    for (const auto& d : output_directives_) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 17\n");
      if (d.generator == nullptr) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 18\n");
        // Infers the plugin name from the plugin_prefix_ and output directive.
        std::string plugin_name = PluginName(plugin_prefix_, d.name);

        // Since plugin_parameters_ is also inferred from --xxx_opt, we check
        // that it actually matches the plugin name inferred from --xxx_out.
        if (plugin_name == kv.first) {
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 19\n");
          foundImplicitPlugin = true;
          break;
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 19\n");
        }
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 18\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 17\n");
    }

    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 20\n");
    // This is a special case for cc_plugin invocations that are only with
    // "--cpp_opt" but no "--cpp_out". In this case, "--cpp_opt" only serves
    // as passing the arguments to cc_plugins, and no C++ generator is required
    // to be present in the invocation. We didn't have to skip for C++ generator
    // previously because the C++ generator was built-in.
    if (!foundImplicitPlugin &&
        kv.first != absl::StrCat(plugin_prefix_, "gen-cpp")) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 21\n");
      std::cerr << "Unknown flag: "
                // strip prefix + "gen-" and add back "_opt"
                << "--" << kv.first.substr(plugin_prefix_.size() + 4) << "_opt"
                << std::endl;
      foundUnknownPluginOption = true;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 21\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 20\n");
  }
  
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 22\n");
  if (foundUnknownPluginOption) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 23\n");
    return PARSE_ARGUMENT_FAIL;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 23\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 22\n");

  // The --proto_path & --descriptor_set_in flags both specify places to look
  // for proto files. If neither were given, use the current working directory.
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 24\n");
  if (proto_path_.empty() && descriptor_set_in_names_.empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 25\n");
    // Don't use make_pair as the old/default standard library on Solaris
    // doesn't support it without explicit template parameters, which are
    // incompatible with C++0x's make_pair.
    proto_path_.push_back(std::pair<std::string, std::string>("", "."));
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 25\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 24\n");

  // Check error cases that span multiple flag values.
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 26\n");
  bool missing_proto_definitions = false;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 26\n");
  
  switch (mode_) {
    case MODE_COMPILE:
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 27\n");
      missing_proto_definitions = input_files_.empty();
      break;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 27\n");
    case MODE_DECODE:
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 28\n");
      // Handle --decode_raw separately, since it requires that no proto
      // definitions are specified.
      if (codec_type_.empty()) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 29\n");
        if (!input_files_.empty() || !descriptor_set_in_names_.empty()) {
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 30\n");
          std::cerr
              << "When using --decode_raw, no input files should be given."
              << std::endl;
          return PARSE_ARGUMENT_FAIL;
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 30\n");
        }
        missing_proto_definitions = false;
        break;  // only for --decode_raw
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 29\n");
      }
      // --decode (not raw) is handled the same way as the rest of the modes.
      ABSL_FALLTHROUGH_INTENDED;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 28\n");
    case MODE_ENCODE:
    case MODE_PRINT:
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 31\n");
      missing_proto_definitions =
          input_files_.empty() && descriptor_set_in_names_.empty();
      break;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 31\n");
    default:
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 32\n");
      ABSL_LOG(FATAL) << "Unexpected mode: " << mode_;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 32\n");
  }
  
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 33\n");
  if (missing_proto_definitions) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 34\n");
    std::cerr << "Missing input file." << std::endl;
    return PARSE_ARGUMENT_FAIL;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 34\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 33\n");
  
  if (mode_ == MODE_COMPILE && output_directives_.empty() &&
      descriptor_set_out_name_.empty() && edition_defaults_out_name_.empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 35\n");
    std::cerr << "Missing output directives." << std::endl;
    return PARSE_ARGUMENT_FAIL;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 35\n");
  }
  
  if (mode_ != MODE_COMPILE && !dependency_out_name_.empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 36\n");
    std::cerr << "Can only use --dependency_out=FILE when generating code."
              << std::endl;
    return PARSE_ARGUMENT_FAIL;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 36\n");
  }
  
  if (mode_ != MODE_ENCODE && deterministic_output_) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 37\n");
    std::cerr << "Can only use --deterministic_output with --encode."
              << std::endl;
    return PARSE_ARGUMENT_FAIL;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 37\n");
  }
  
  if (!dependency_out_name_.empty() && input_files_.size() > 1) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 38\n");
    std::cerr
        << "Can only process one input file when using --dependency_out=FILE."
        << std::endl;
    return PARSE_ARGUMENT_FAIL;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 38\n");
  }
  
  if (imports_in_descriptor_set_ && descriptor_set_out_name_.empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 39\n");
    std::cerr << "--include_imports only makes sense when combined with "
                 "--descriptor_set_out."
              << std::endl;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 39\n");
  }
  
  if (source_info_in_descriptor_set_ && descriptor_set_out_name_.empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 40\n");
    std::cerr << "--include_source_info only makes sense when combined with "
                 "--descriptor_set_out."
              << std::endl;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 40\n");
  }
  
  if (retain_options_in_descriptor_set_ && descriptor_set_out_name_.empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 41\n");
    std::cerr << "--retain_options only makes sense when combined with "
                 "--descriptor_set_out."
              << std::endl;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 41\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArguments 42\n");
  return PARSE_ARGUMENT_DONE_AND_CONTINUE;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArguments 42\n");
}

bool CommandLineInterface::ParseArgument(const char* arg, std::string* name,
                                         std::string* value) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArgument 1\n");
  bool parsed_value = false;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArgument 1\n");

  if (arg[0] != '-') {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArgument 2\n");
    // Not a flag.
    name->clear();
    parsed_value = true;
    *value = arg;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArgument 2\n");
  } else if (arg[1] == '-') {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArgument 3\n");
    // Two dashes:  Multi-character name, with '=' separating name and
    //   value.
    const char* equals_pos = strchr(arg, '=');
    if (equals_pos != nullptr) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArgument 4\n");
      *name = std::string(arg, equals_pos - arg);
      *value = equals_pos + 1;
      parsed_value = true;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArgument 4\n");
    } else {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArgument 5\n");
      *name = arg;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArgument 5\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArgument 3\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArgument 6\n");
    // One dash:  One-character name, all subsequent characters are the
    //   value.
    if (arg[1] == '\0') {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArgument 7\n");
      // arg is just "-".  We treat this as an input file, except that at
      // present this will just lead to a "file not found" error.
      name->clear();
      *value = arg;
      parsed_value = true;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArgument 7\n");
    } else {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArgument 8\n");
      *name = std::string(arg, 2);
      *value = arg + 2;
      parsed_value = !value->empty();
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArgument 8\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArgument 6\n");
  }

  // Need to return true iff the next arg should be used as the value for this
  // one, false otherwise.
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArgument 9\n");
  if (parsed_value) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArgument 10\n");
    // We already parsed a value for this flag.
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArgument 10\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArgument 9\n");

  if (*name == "-h" || *name == "--help" || *name == "--disallow_services" ||
      *name == "--include_imports" || *name == "--include_source_info" ||
      *name == "--retain_options" || *name == "--version" ||
      *name == "--decode_raw" ||
      *name == "--notices" ||
      *name == "--experimental_editions" ||
      *name == "--print_free_field_numbers" ||
      *name == "--experimental_allow_proto3_optional" ||
      *name == "--deterministic_output" || *name == "--fatal_warnings") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArgument 11\n");
    // HACK:  These are the only flags that don't take a value.
    //   They probably should not be hard-coded like this but for now it's
    //   not worth doing better.
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArgument 11\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter ParseArgument 12\n");
  // Next argument is the flag value.
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit ParseArgument 12\n");
}
CommandLineInterface::ParseArgumentStatus
CommandLineInterface::InterpretArgument(const std::string& name,
                                        const std::string& value) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 1\n");
  if (name.empty()) {
    // Not a flag.  Just a filename.
    if (value.empty()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 2\n");
      std::cerr
          << "You seem to have passed an empty string as one of the "
             "arguments to "
          << executable_name_
          << ".  This is actually "
             "sort of hard to do.  Congrats.  Unfortunately it is not valid "
             "input so the program is going to die now."
          << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 2\n");
    }

#if defined(_WIN32)
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 3\n");
    // On Windows, the shell (typically cmd.exe) does not expand wildcards in
    // file names (e.g. foo\*.proto), so we do it ourselves.
    switch (google::protobuf::io::win32::ExpandWildcards(
        value, [this](const std::string& path) {
          this->input_files_.push_back(path);
        })) {
      case google::protobuf::io::win32::ExpandWildcardsResult::kSuccess:
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 4\n");
        break;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 4\n");
      case google::protobuf::io::win32::ExpandWildcardsResult::kErrorNoMatchingFile:
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 5\n");
        // Path does not exist, is not a file, or it's longer than MAX_PATH and
        // long path handling is disabled.
        std::cerr << "Invalid file name pattern or missing input file \""
                  << value << "\"" << std::endl;
        return PARSE_ARGUMENT_FAIL;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 5\n");
      default:
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 6\n");
        std::cerr << "Cannot convert path \"" << value
                  << "\" to or from Windows style" << std::endl;
        return PARSE_ARGUMENT_FAIL;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 6\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 3\n");
#else   // not _WIN32
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 7\n");
    // On other platforms than Windows (e.g. Linux, Mac OS) the shell (typically
    // Bash) expands wildcards.
    input_files_.push_back(value);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 7\n");
#endif  // _WIN32

  } else if (name == "-I" || name == "--proto_path") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 8\n");
    // Java's -classpath (and some other languages) delimits path components
    // with colons.  Let's accept that syntax too just to make things more
    // intuitive.
    std::vector<std::string> parts = absl::StrSplit(
        value, absl::ByAnyChar(CommandLineInterface::kPathSeparator),
        absl::SkipEmpty());

    for (size_t i = 0; i < parts.size(); ++i) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 9\n");
      std::string virtual_path;
      std::string disk_path;

      std::string::size_type equals_pos = parts[i].find_first_of('=');
      if (equals_pos == std::string::npos) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 10\n");
        virtual_path = "";
        disk_path = parts[i];
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 10\n");
      } else {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 11\n");
        virtual_path = parts[i].substr(0, equals_pos);
        disk_path = parts[i].substr(equals_pos + 1);
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 11\n");
      }

      if (disk_path.empty()) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 12\n");
        std::cerr
            << "--proto_path passed empty directory name.  (Use \".\" for "
               "current directory.)"
            << std::endl;
        return PARSE_ARGUMENT_FAIL;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 12\n");
      }

      // Make sure disk path exists, warn otherwise.
      if (access(disk_path.c_str(), F_OK) < 0) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 13\n");
        // Try the original path; it may have just happened to have a '=' in it.
        if (access(parts[i].c_str(), F_OK) < 0) {
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 14\n");
          std::cerr << disk_path << ": warning: directory does not exist."
                    << std::endl;
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 14\n");
        } else {
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 15\n");
          virtual_path = "";
          disk_path = parts[i];
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 15\n");
        }
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 13\n");
      }

      // Don't use make_pair as the old/default standard library on Solaris
      // doesn't support it without explicit template parameters, which are
      // incompatible with C++0x's make_pair.
      proto_path_.push_back(
          std::pair<std::string, std::string>(virtual_path, disk_path));
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 9\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 8\n");

  } else if (name == "--direct_dependencies") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 16\n");
    if (direct_dependencies_explicitly_set_) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 17\n");
      std::cerr << name
                << " may only be passed once. To specify multiple "
                   "direct dependencies, pass them all as a single "
                   "parameter separated by ':'."
                << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 17\n");
    }

    direct_dependencies_explicitly_set_ = true;
    std::vector<std::string> direct =
        absl::StrSplit(value, ':', absl::SkipEmpty());
    ABSL_DCHECK(direct_dependencies_.empty());
    direct_dependencies_.insert(direct.begin(), direct.end());
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 16\n");

  } else if (name == "--direct_dependencies_violation_msg") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 18\n");
    direct_dependencies_violation_msg_ = value;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 18\n");

  } else if (name == "--descriptor_set_in") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 19\n");
    if (!descriptor_set_in_names_.empty()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 20\n");
      std::cerr << name
                << " may only be passed once. To specify multiple "
                   "descriptor sets, pass them all as a single "
                   "parameter separated by '"
                << CommandLineInterface::kPathSeparator << "'." << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 20\n");
    }
    if (value.empty()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 21\n");
      std::cerr << name << " requires a non-empty value." << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 21\n");
    }
    if (!dependency_out_name_.empty()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 22\n");
      std::cerr << name << " cannot be used with --dependency_out."
                << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 22\n");
    }

    descriptor_set_in_names_ = absl::StrSplit(
        value, absl::ByAnyChar(CommandLineInterface::kPathSeparator),
        absl::SkipEmpty());
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 19\n");

  } else if (name == "-o" || name == "--descriptor_set_out") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 23\n");
    if (!descriptor_set_out_name_.empty()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 24\n");
      std::cerr << name << " may only be passed once." << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 24\n");
    }
    if (value.empty()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 25\n");
      std::cerr << name << " requires a non-empty value." << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 25\n");
    }
    if (mode_ != MODE_COMPILE) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 26\n");
      std::cerr
          << "Cannot use --encode or --decode and generate descriptors at the "
             "same time."
          << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 26\n");
    }
    descriptor_set_out_name_ = value;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 23\n");

  } else if (name == "--dependency_out") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 27\n");
    if (!dependency_out_name_.empty()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 28\n");
      std::cerr << name << " may only be passed once." << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 28\n");
    }
    if (value.empty()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 29\n");
      std::cerr << name << " requires a non-empty value." << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 29\n");
    }
    if (!descriptor_set_in_names_.empty()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 30\n");
      std::cerr << name << " cannot be used with --descriptor_set_in."
                << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 30\n");
    }
    dependency_out_name_ = value;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 27\n");

  } else if (name == "--include_imports") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 31\n");
    if (imports_in_descriptor_set_) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 32\n");
      std::cerr << name << " may only be passed once." << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 32\n");
    }
    imports_in_descriptor_set_ = true;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 31\n");

  } else if (name == "--include_source_info") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 33\n");
    if (source_info_in_descriptor_set_) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 34\n");
      std::cerr << name << " may only be passed once." << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 34\n");
    }
    source_info_in_descriptor_set_ = true;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 33\n");

  } else if (name == "--retain_options") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 35\n");
    if (retain_options_in_descriptor_set_) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 36\n");
      std::cerr << name << " may only be passed once." << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 36\n");
    }
    retain_options_in_descriptor_set_ = true;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 35\n");

  } else if (name == "-h" || name == "--help") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 37\n");
    PrintHelpText();
    return PARSE_ARGUMENT_DONE_AND_EXIT;  // Exit without running compiler.
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 37\n");

  } else if (name == "--version") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 38\n");
    if (!version_info_.empty()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 39\n");
      std::cout << version_info_ << std::endl;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 39\n");
    }
    std::cout << "libprotoc "
              << ::google::protobuf::internal::ProtocVersionString(
                     PROTOBUF_VERSION)
              << PROTOBUF_VERSION_SUFFIX << std::endl;
    return PARSE_ARGUMENT_DONE_AND_EXIT;  // Exit without running compiler.
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 38\n");

  } else if (name == "--disallow_services") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 40\n");
    disallow_services_ = true;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 40\n");
  } else if (name == "--experimental_allow_proto3_optional") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 41\n");
    // Flag is no longer observed, but we allow it for backward compat.
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 41\n");
  } else if (name == "--encode" || name == "--decode" ||
             name == "--decode_raw") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 42\n");
    if (mode_ != MODE_COMPILE) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 43\n");
      std::cerr << "Only one of --encode and --decode can be specified."
                << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 43\n");
    }
    if (!output_directives_.empty() || !descriptor_set_out_name_.empty()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 44\n");
      std::cerr << "Cannot use " << name
                << " and generate code or descriptors at the same time."
                << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 44\n");
    }

    mode_ = (name == "--encode") ? MODE_ENCODE : MODE_DECODE;

    if (value.empty() && name != "--decode_raw") {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 45\n");
      std::cerr << "Type name for " << name << " cannot be blank." << std::endl;
      if (name == "--decode") {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 46\n");
        std::cerr << "To decode an unknown message, use --decode_raw."
                  << std::endl;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 46\n");
      }
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 45\n");
    } else if (!value.empty() && name == "--decode_raw") {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 47\n");
      std::cerr << "--decode_raw does not take a parameter." << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 47\n");
    }

    codec_type_ = value;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 42\n");

  } else if (name == "--deterministic_output") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 48\n");
    deterministic_output_ = true;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 48\n");

  } else if (name == "--error_format") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 49\n");
    if (value == "gcc") {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 50\n");
      error_format_ = ERROR_FORMAT_GCC;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 50\n");
    } else if (value == "msvs") {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 51\n");
      error_format_ = ERROR_FORMAT_MSVS;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 51\n");
    } else {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 52\n");
      std::cerr << "Unknown error format: " << value << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 52\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 49\n");

  } else if (name == "--fatal_warnings") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 53\n");
    if (fatal_warnings_) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 54\n");
      std::cerr << name << " may only be passed once." << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 54\n");
    }
    fatal_warnings_ = true;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 53\n");
  } else if (name == "--plugin") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 55\n");
    if (plugin_prefix_.empty()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 56\n");
      std::cerr << "This compiler does not support plugins." << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 56\n");
    }

    std::string plugin_name;
    std::string path;

    std::string::size_type equals_pos = value.find_first_of('=');
    if (equals_pos == std::string::npos) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 57\n");
      // Use the basename of the file.
      std::string::size_type slash_pos = value.find_last_of('/');
      if (slash_pos == std::string::npos) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 58\n");
        plugin_name = value;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 58\n");
      } else {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 59\n");
        plugin_name = value.substr(slash_pos + 1);
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 59\n");
      }
      path = value;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 57\n");
    } else {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 60\n");
      plugin_name = value.substr(0, equals_pos);
      path = value.substr(equals_pos + 1);
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 60\n");
    }

    plugins_[plugin_name] = path;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 55\n");

  } else if (name == "--print_free_field_numbers") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 61\n");
    if (mode_ != MODE_COMPILE) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 62\n");
      std::cerr << "Cannot use " << name
                << " and use --encode, --decode or print "
                << "other info at the same time." << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 62\n");
    }
    if (!output_directives_.empty() || !descriptor_set_out_name_.empty()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 63\n");
      std::cerr << "Cannot use " << name
                << " and generate code or descriptors at the same time."
                << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 63\n");
    }
    mode_ = MODE_PRINT;
    print_mode_ = PRINT_FREE_FIELDS;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 61\n");
  } else if (name == "--enable_codegen_trace") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 64\n");
    // We use environment variables here so that subprocesses see this setting
    // when we spawn them.
    //
    // Setting environment variables is more-or-less asking for a data race,
    // because C got this wrong and did not mandate synchronization.
    // In practice, this code path is "only" in the main thread of protoc, and
    // it is common knowledge that touching setenv in a library is asking for
    // life-ruining bugs *anyways*. As such, there is a reasonable probability
    // that there isn't another thread kicking environment variables at this
    // moment.

#ifdef _WIN32
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 65\n");
    ::_putenv(absl::StrCat(io::Printer::kProtocCodegenTrace, "=yes").c_str());
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 65\n");
#else
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 66\n");
    ::setenv(io::Printer::kProtocCodegenTrace.data(), "yes", 0);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 66\n");
#endif
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 64\n");
  } else if (name == "--notices") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 67\n");
    std::cout << notices_text << std::endl;
    return PARSE_ARGUMENT_DONE_AND_EXIT;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 67\n");
  } else if (name == "--experimental_editions") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 68\n");
    // If you're reading this, you're probably wondering what
    // --experimental_editions is for and thinking of turning it on. This is an
    // experimental, undocumented, unsupported flag. Enable it at your own risk
    // (or, just don't!).
    experimental_editions_ = true;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 68\n");
  } else if (name == "--edition_defaults_out") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 69\n");
    if (!edition_defaults_out_name_.empty()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 70\n");
      std::cerr << name << " may only be passed once." << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 70\n");
    }
    if (value.empty()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 71\n");
      std::cerr << name << " requires a non-empty value." << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 71\n");
    }
    if (mode_ != MODE_COMPILE) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 72\n");
      std::cerr
          << "Cannot use --encode or --decode and generate defaults at the "
             "same time."
          << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 72\n");
    }
    edition_defaults_out_name_ = value;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 69\n");
  } else if (name == "--edition_defaults_minimum") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 73\n");
    if (edition_defaults_minimum_ != EDITION_UNKNOWN) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 74\n");
      std::cerr << name << " may only be passed once." << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 74\n");
    }
    if (!Edition_Parse(absl::StrCat("EDITION_", value),
                       &edition_defaults_minimum_)) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 75\n");
      std::cerr << name << " unknown edition \"" << value << "\"." << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 75\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 73\n");
  } else if (name == "--edition_defaults_maximum") {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 76\n");
    if (edition_defaults_maximum_ != EDITION_UNKNOWN) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 77\n");
      std::cerr << name << " may only be passed once." << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 77\n");
    }
    if (!Edition_Parse(absl::StrCat("EDITION_", value),
                       &edition_defaults_maximum_)) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 78\n");
      std::cerr << name << " unknown edition \"" << value << "\"." << std::endl;
      return PARSE_ARGUMENT_FAIL;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 78\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 76\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 79\n");
    // Some other flag.  Look it up in the generators list.
    const GeneratorInfo* generator_info = FindGeneratorByFlag(name);
    if (generator_info == nullptr &&
        (plugin_prefix_.empty() || !absl::EndsWith(name, "_out"))) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 80\n");
      // Check if it's a generator option flag.
      generator_info = FindGeneratorByOption(name);
      if (generator_info != nullptr) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 81\n");
        std::string* parameters =
            &generator_parameters_[generator_info->flag_name];
        if (!parameters->empty()) {
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 82\n");
          parameters->append(",");
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 82\n");
        }
        parameters->append(value);
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 81\n");
      } else if (absl::StartsWith(name, "--") && absl::EndsWith(name, "_opt")) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 83\n");
        std::string* parameters =
            &plugin_parameters_[PluginName(plugin_prefix_, name)];
        if (!parameters->empty()) {
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 84\n");
          parameters->append(",");
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 84\n");
        }
        parameters->append(value);
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 83\n");
      } else {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 85\n");
        std::cerr << "Unknown flag: " << name << std::endl;
        return PARSE_ARGUMENT_FAIL;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 85\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 80\n");
    } else {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 86\n");
      // It's an output flag.  Add it to the output directives.
      if (mode_ != MODE_COMPILE) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 87\n");
        std::cerr << "Cannot use --encode, --decode or print .proto info and "
                     "generate code at the same time."
                  << std::endl;
        return PARSE_ARGUMENT_FAIL;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 87\n");
      }

      OutputDirective directive;
      directive.name = name;
      if (generator_info == nullptr) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 88\n");
        directive.generator = nullptr;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 88\n");
      } else {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 89\n");
        directive.generator = generator_info->generator;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 89\n");
      }

      // Split value at ':' to separate the generator parameter from the
      // filename.  However, avoid doing this if the colon is part of a valid
      // Windows-style absolute path.
      std::string::size_type colon_pos = value.find_first_of(':');
      if (colon_pos == std::string::npos || IsWindowsAbsolutePath(value)) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 90\n");
        directive.output_location = value;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 90\n");
      } else {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter InterpretArgument 91\n");
        directive.parameter = value.substr(0, colon_pos);
        directive.output_location = value.substr(colon_pos + 1);
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 91\n");
      }

      output_directives_.push_back(directive);
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 86\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 79\n");
  }

  return PARSE_ARGUMENT_DONE_AND_CONTINUE;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit InterpretArgument 1\n");
}

void CommandLineInterface::PrintHelpText() {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter PrintHelpText 1\n");
  // Sorry for indentation here; line wrapping would be uglier.
  std::cout << "Usage: " << executable_name_ << " [OPTION] PROTO_FILES";
  std::cout << R"(
Parse PROTO_FILES and generate output based on the options given:
  -IPATH, --proto_path=PATH   Specify the directory in which to search for
                              imports.  May be specified multiple times;
                              directories will be searched in order.  If not
                              given, the current working directory is used.
                              If not found in any of the these directories,
                              the --descriptor_set_in descriptors will be
                              checked for required proto file.
  --version                   Show version info and exit.
  -h, --help                  Show this text and exit.
  --encode=MESSAGE_TYPE       Read a text-format message of the given type
                              from standard input and write it in binary
                              to standard output.  The message type must
                              be defined in PROTO_FILES or their imports.
  --deterministic_output      When using --encode, ensure map fields are
                              deterministically ordered. Note that this order
                              is not canonical, and changes across builds or
                              releases of protoc.
  --decode=MESSAGE_TYPE       Read a binary message of the given type from
                              standard input and write it in text format
                              to standard output.  The message type must
                              be defined in PROTO_FILES or their imports.
  --decode_raw                Read an arbitrary protocol message from
                              standard input and write the raw tag/value
                              pairs in text format to standard output.  No
                              PROTO_FILES should be given when using this
                              flag.
  --descriptor_set_in=FILES   Specifies a delimited list of FILES
                              each containing a FileDescriptorSet (a
                              protocol buffer defined in descriptor.proto).
                              The FileDescriptor for each of the PROTO_FILES
                              provided will be loaded from these
                              FileDescriptorSets. If a FileDescriptor
                              appears multiple times, the first occurrence
                              will be used.
  -oFILE,                     Writes a FileDescriptorSet (a protocol buffer,
    --descriptor_set_out=FILE defined in descriptor.proto) containing all of
                              the input files to FILE.
  --include_imports           When using --descriptor_set_out, also include
                              all dependencies of the input files in the
                              set, so that the set is self-contained.
  --include_source_info       When using --descriptor_set_out, do not strip
                              SourceCodeInfo from the FileDescriptorProto.
                              This results in vastly larger descriptors that
                              include information about the original
                              location of each decl in the source file as
                              well as surrounding comments.
  --retain_options            When using --descriptor_set_out, do not strip
                              any options from the FileDescriptorProto.
                              This results in potentially larger descriptors
                              that include information about options that were
                              only meant to be useful during compilation.
  --dependency_out=FILE       Write a dependency output file in the format
                              expected by make. This writes the transitive
                              set of input file paths to FILE
  --error_format=FORMAT       Set the format in which to print errors.
                              FORMAT may be 'gcc' (the default) or 'msvs'
                              (Microsoft Visual Studio format).
  --fatal_warnings            Make warnings be fatal (similar to -Werr in
                              gcc). This flag will make protoc return
                              with a non-zero exit code if any warnings
                              are generated.
  --print_free_field_numbers  Print the free field numbers of the messages
                              defined in the given proto files. Extension ranges
                              are counted as occupied fields numbers.
  --enable_codegen_trace      Enables tracing which parts of protoc are
                              responsible for what codegen output. Not supported
                              by all backends or on all platforms.)";
  std::cout << R"(
  --notices                   Show notice file and exit.)";
  if (!plugin_prefix_.empty()) {
    std::cout << R"(
  --plugin=EXECUTABLE         Specifies a plugin executable to use.
                              Normally, protoc searches the PATH for
                              plugins, but you may specify additional
                              executables not in the path using this flag.
                              Additionally, EXECUTABLE may be of the form
                              NAME=PATH, in which case the given plugin name
                              is mapped to the given executable even if
                              the executable's own name differs.)";
  }

  for (const auto& kv : generators_by_flag_name_) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter PrintHelpText 2\n");
    // FIXME(kenton):  If the text is long enough it will wrap, which is ugly,
    //   but fixing this nicely (e.g. splitting on spaces) is probably more
    //   trouble than it's worth.
    std::cout << std::endl
              << "  " << kv.first << "=OUT_DIR "
              << std::string(19 - kv.first.size(),
                             ' ')  // Spaces for alignment.
              << kv.second.help_text;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit PrintHelpText 2\n");
  }
  std::cout << R"(
  @<filename>                 Read options and filenames from file. If a
                              relative file path is specified, the file
                              will be searched in the working directory.
                              The --proto_path option will not affect how
                              this argument file is searched. Content of
                              the file will be expanded in the position of
                              @<filename> as in the argument list. Note
                              that shell expansion is not applied to the
                              content of the file (i.e., you cannot use
                              quotes, wildcards, escapes, commands, etc.).
                              Each line corresponds to a single argument,
                              even if it contains spaces.)";
  std::cout << std::endl;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit PrintHelpText 1\n");
}

bool CommandLineInterface::EnforceProto3OptionalSupport(
    const std::string& codegen_name, uint64_t supported_features,
    const std::vector<const FileDescriptor*>& parsed_files) const {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter EnforceProto3OptionalSupport 1\n");
  bool supports_proto3_optional =
      supported_features & CodeGenerator::FEATURE_PROTO3_OPTIONAL;
  if (!supports_proto3_optional) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter EnforceProto3OptionalSupport 2\n");
    for (const auto fd : parsed_files) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter EnforceProto3OptionalSupport 3\n");
      if (ContainsProto3Optional(
              ::google::protobuf::internal::InternalFeatureHelper::GetEdition(*fd), fd)) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter EnforceProto3OptionalSupport 4\n");
        std::cerr << fd->name()
                  << ": is a proto3 file that contains optional fields, but "
                     "code generator "
                  << codegen_name
                  << " hasn't been updated to support optional fields in "
                     "proto3. Please ask the owner of this code generator to "
                     "support proto3 optional."
                  << std::endl;
        return false;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit EnforceProto3OptionalSupport 4\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit EnforceProto3OptionalSupport 3\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit EnforceProto3OptionalSupport 2\n");
  }
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit EnforceProto3OptionalSupport 1\n");
}

bool CommandLineInterface::EnforceEditionsSupport(
    const std::string& codegen_name, uint64_t supported_features,
    Edition minimum_edition, Edition maximum_edition,
    const std::vector<const FileDescriptor*>& parsed_files) const {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter EnforceEditionsSupport 1\n");
  if (experimental_editions_) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter EnforceEditionsSupport 2\n");
    // The user has explicitly specified the experimental flag.
    return true;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit EnforceEditionsSupport 2\n");
  }
  for (const auto* fd : parsed_files) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter EnforceEditionsSupport 3\n");
    Edition edition =
        ::google::protobuf::internal::InternalFeatureHelper::GetEdition(*fd);
    if (edition < Edition::EDITION_2023 || CanSkipEditionCheck(fd->name())) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter EnforceEditionsSupport 4\n");
      // Legacy proto2/proto3 or exempted files don't need any checks.
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit EnforceEditionsSupport 4\n");
      continue;
    }

    if ((supported_features & CodeGenerator::FEATURE_SUPPORTS_EDITIONS) == 0) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter EnforceEditionsSupport 5\n");
      std::cerr << absl::Substitute(
          "$0: is an editions file, but code generator $1 hasn't been "
          "updated to support editions yet.  Please ask the owner of this code "
          "generator to add support or switch back to proto2/proto3.\n\nSee "
          "https://protobuf.dev/editions/overview/ for more information.",
          fd->name(), codegen_name);
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit EnforceEditionsSupport 5\n");
    }
    if (edition < minimum_edition) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter EnforceEditionsSupport 6\n");
      std::cerr << absl::Substitute(
          "$0: is a file using edition $2, which isn't supported by code "
          "generator $1.  Please upgrade your file to at least edition $3.",
          fd->name(), codegen_name, edition, minimum_edition);
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit EnforceEditionsSupport 6\n");
    }
    if (edition > maximum_edition) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter EnforceEditionsSupport 7\n");
      std::cerr << absl::Substitute(
          "$0: is a file using edition $2, which isn't supported by code "
          "generator $1.  Please ask the owner of this code generator to add "
          "support or switch back to a maximum of edition $3.",
          fd->name(), codegen_name, edition, maximum_edition);
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit EnforceEditionsSupport 7\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit EnforceEditionsSupport 3\n");
  }
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit EnforceEditionsSupport 1\n");
}

bool CommandLineInterface::EnforceProtocEditionsSupport(
    const std::vector<const FileDescriptor*>& parsed_files) const {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter EnforceProtocEditionsSupport 1\n");
  if (experimental_editions_) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter EnforceProtocEditionsSupport 2\n");
    // The user has explicitly specified the experimental flag.
    return true;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit EnforceProtocEditionsSupport 2\n");
  }
  for (const auto* fd : parsed_files) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter EnforceProtocEditionsSupport 3\n");
    Edition edition =
        ::google::protobuf::internal::InternalFeatureHelper::GetEdition(*fd);
    if (CanSkipEditionCheck(fd->name())) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter EnforceProtocEditionsSupport 4\n");
      // Legacy proto2/proto3 or exempted files don't need any checks.
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit EnforceProtocEditionsSupport 4\n");
      continue;
    }

    if (edition > ProtocMaximumEdition()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter EnforceProtocEditionsSupport 5\n");
      std::cerr << absl::Substitute(
          "$0: is a file using edition $1, which is later than the protoc "
          "maximum supported edition $2.",
          fd->name(), edition, ProtocMaximumEdition());
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit EnforceProtocEditionsSupport 5\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit EnforceProtocEditionsSupport 3\n");
  }
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit EnforceProtocEditionsSupport 1\n");
}

bool CommandLineInterface::GenerateOutput(
    const std::vector<const FileDescriptor*>& parsed_files,
    const OutputDirective& output_directive,
    GeneratorContext* generator_context) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateOutput 1\n");
  // Call the generator.
  std::string error;
  if (output_directive.generator == nullptr) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateOutput 2\n");
    // This is a plugin.
    ABSL_CHECK(absl::StartsWith(output_directive.name, "--") &&
               absl::EndsWith(output_directive.name, "_out"))
        << "Bad name for plugin generator: " << output_directive.name;

    std::string plugin_name = PluginName(plugin_prefix_, output_directive.name);
    std::string parameters = output_directive.parameter;
    if (!plugin_parameters_[plugin_name].empty()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateOutput 3\n");
      if (!parameters.empty()) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateOutput 4\n");
        parameters.append(",");
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateOutput 4\n");
      }
      parameters.append(plugin_parameters_[plugin_name]);
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateOutput 3\n");
    }
    if (!GeneratePluginOutput(parsed_files, plugin_name, parameters,
                              generator_context, &error)) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateOutput 5\n");
      std::cerr << output_directive.name << ": " << error << std::endl;
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateOutput 5\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateOutput 2\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateOutput 6\n");
    // Regular generator.
    std::string parameters = output_directive.parameter;
    if (!generator_parameters_[output_directive.name].empty()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateOutput 7\n");
      if (!parameters.empty()) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateOutput 8\n");
        parameters.append(",");
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateOutput 8\n");
      }
      parameters.append(generator_parameters_[output_directive.name]);
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateOutput 7\n");
    }
    if (!EnforceProto3OptionalSupport(
            output_directive.name,
            output_directive.generator->GetSupportedFeatures(), parsed_files)) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateOutput 9\n");
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateOutput 9\n");
    }

    if (!EnforceEditionsSupport(
            output_directive.name,
            output_directive.generator->GetSupportedFeatures(),
            output_directive.generator->GetMinimumEdition(),
            output_directive.generator->GetMaximumEdition(), parsed_files)) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateOutput 10\n");
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateOutput 10\n");
    }

    if (!output_directive.generator->GenerateAll(parsed_files, parameters,
                                                 generator_context, &error)) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateOutput 11\n");
      // Generator returned an error.
      std::cerr << output_directive.name << ": " << error << std::endl;
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateOutput 11\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateOutput 6\n");
  }

  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateOutput 1\n");
}

bool CommandLineInterface::GenerateDependencyManifestFile(
    const std::vector<const FileDescriptor*>& parsed_files,
    const GeneratorContextMap& output_directories,
    DiskSourceTree* source_tree) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateDependencyManifestFile 1\n");
  FileDescriptorSet file_set;

  absl::flat_hash_set<const FileDescriptor*> already_seen;
  for (size_t i = 0; i < parsed_files.size(); ++i) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateDependencyManifestFile 2\n");
    GetTransitiveDependencies(parsed_files[i], &already_seen,
                              file_set.mutable_file());
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateDependencyManifestFile 2\n");
  }

  std::vector<std::string> output_filenames;
  for (const auto& pair : output_directories) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateDependencyManifestFile 3\n");
    const std::string& location = pair.first;
    GeneratorContextImpl* directory = pair.second.get();
    std::vector<std::string> relative_output_filenames;
    directory->GetOutputFilenames(&relative_output_filenames);
    for (size_t i = 0; i < relative_output_filenames.size(); ++i) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateDependencyManifestFile 4\n");
      std::string output_filename = location + relative_output_filenames[i];
      if (output_filename.compare(0, 2, "./") == 0) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateDependencyManifestFile 5\n");
        output_filename = output_filename.substr(2);
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateDependencyManifestFile 5\n");
      }
      output_filenames.push_back(output_filename);
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateDependencyManifestFile 4\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateDependencyManifestFile 3\n");
  }

  if (!descriptor_set_out_name_.empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateDependencyManifestFile 6\n");
    output_filenames.push_back(descriptor_set_out_name_);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateDependencyManifestFile 6\n");
  }

  if (!edition_defaults_out_name_.empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateDependencyManifestFile 7\n");
    output_filenames.push_back(edition_defaults_out_name_);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateDependencyManifestFile 7\n");
  }

  // Create the depfile, even if it will be empty.
  int fd;
  do {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateDependencyManifestFile 8\n");
    fd = open(dependency_out_name_.c_str(),
              O_WRONLY | O_CREAT | O_TRUNC | O_BINARY, 0666);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateDependencyManifestFile 8\n");
  } while (fd < 0 && errno == EINTR);

  if (fd < 0) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateDependencyManifestFile 9\n");
    perror(dependency_out_name_.c_str());
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateDependencyManifestFile 9\n");
  }

  // Only write to the depfile if there is at least one output_filename.
  // Otherwise, the depfile will be malformed.
  if (!output_filenames.empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateDependencyManifestFile 10\n");
    io::FileOutputStream out(fd);
    io::Printer printer(&out, '$');

    for (size_t i = 0; i < output_filenames.size(); ++i) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateDependencyManifestFile 11\n");
      printer.Print(output_filenames[i]);
      if (i == output_filenames.size() - 1) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateDependencyManifestFile 12\n");
        printer.Print(":");
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateDependencyManifestFile 12\n");
      } else {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateDependencyManifestFile 13\n");
        printer.Print(" \\\n");
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateDependencyManifestFile 13\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateDependencyManifestFile 11\n");
    }

    for (int i = 0; i < file_set.file_size(); ++i) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateDependencyManifestFile 14\n");
      const FileDescriptorProto& file = file_set.file(i);
      const std::string& virtual_file = file.name();
      std::string disk_file;
      if (source_tree &&
          source_tree->VirtualFileToDiskFile(virtual_file, &disk_file)) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateDependencyManifestFile 15\n");
        printer.Print(" $disk_file$", "disk_file", disk_file);
        if (i < file_set.file_size() - 1) printer.Print("\\\n");
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateDependencyManifestFile 15\n");
      } else {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GenerateDependencyManifestFile 16\n");
        std::cerr << "Unable to identify path for file " << virtual_file
                  << std::endl;
        return false;
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateDependencyManifestFile 16\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateDependencyManifestFile 14\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateDependencyManifestFile 10\n");
  }

  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GenerateDependencyManifestFile 1\n");
}
bool CommandLineInterface::GeneratePluginOutput(
    const std::vector<const FileDescriptor*>& parsed_files,
    const std::string& plugin_name, const std::string& parameter,
    GeneratorContext* generator_context, std::string* error) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GeneratePluginOutput 1\n");
  CodeGeneratorRequest request;
  CodeGeneratorResponse response;
  std::string processed_parameter = parameter;

  bool bootstrap = GetBootstrapParam(processed_parameter);
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GeneratePluginOutput 1\n");

  // Build the request.
  if (!processed_parameter.empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GeneratePluginOutput 2\n");
    request.set_parameter(processed_parameter);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GeneratePluginOutput 2\n");
  }


  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GeneratePluginOutput 3\n");
  absl::flat_hash_set<const FileDescriptor*> already_seen;
  for (const FileDescriptor* file : parsed_files) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GeneratePluginOutput 4\n");
    request.add_file_to_generate(file->name());
    GetTransitiveDependencies(file, &already_seen, request.mutable_proto_file(),
                              {/*.include_json_name =*/true,
                               /*.include_source_code_info =*/true,
                               /*.retain_options =*/true});
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GeneratePluginOutput 4\n");
  }

  // Populate source_file_descriptors and remove source-retention options from
  // proto_file.
  ABSL_CHECK(!parsed_files.empty());
  const DescriptorPool* pool = parsed_files[0]->pool();
  absl::flat_hash_set<std::string> files_to_generate(input_files_.begin(),
                                                     input_files_.end());
  static const auto builtin_plugins = new absl::flat_hash_set<std::string>(
      {"protoc-gen-cpp", "protoc-gen-java", "protoc-gen-mutable_java",
       "protoc-gen-python"});
  for (FileDescriptorProto& file_proto : *request.mutable_proto_file()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GeneratePluginOutput 5\n");
    if (files_to_generate.contains(file_proto.name())) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GeneratePluginOutput 6\n");
      const FileDescriptor* file = pool->FindFileByName(file_proto.name());
      *request.add_source_file_descriptors() = std::move(file_proto);
      file->CopyTo(&file_proto);
      // Don't populate source code info or json_name for bootstrap protos.
      if (!bootstrap) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GeneratePluginOutput 7\n");
        file->CopySourceCodeInfoTo(&file_proto);

        // The built-in code generators didn't use the json names.
        if (!builtin_plugins->contains(plugin_name)) {
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GeneratePluginOutput 8\n");
          file->CopyJsonNameTo(&file_proto);
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GeneratePluginOutput 8\n");
        }
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GeneratePluginOutput 7\n");
      }
      StripSourceRetentionOptions(*file->pool(), file_proto);
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GeneratePluginOutput 6\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GeneratePluginOutput 5\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GeneratePluginOutput 3\n");

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GeneratePluginOutput 9\n");
  google::protobuf::compiler::Version* version =
      request.mutable_compiler_version();
  version->set_major(PROTOBUF_VERSION / 1000000);
  version->set_minor(PROTOBUF_VERSION / 1000 % 1000);
  version->set_patch(PROTOBUF_VERSION % 1000);
  version->set_suffix(PROTOBUF_VERSION_SUFFIX);

  // Invoke the plugin.
  Subprocess subprocess;

  if (plugins_.count(plugin_name) > 0) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GeneratePluginOutput 10\n");
    subprocess.Start(plugins_[plugin_name], Subprocess::EXACT_NAME);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GeneratePluginOutput 10\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GeneratePluginOutput 11\n");
    subprocess.Start(plugin_name, Subprocess::SEARCH_PATH);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GeneratePluginOutput 11\n");
  }

  std::string communicate_error;
  if (!subprocess.Communicate(request, &response, &communicate_error)) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GeneratePluginOutput 12\n");
    *error = absl::Substitute("$0: $1", plugin_name, communicate_error);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GeneratePluginOutput 12\n");
    return false;
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GeneratePluginOutput 9\n");

  // Write the files.  We do this even if there was a generator error in order
  // to match the behavior of a compiled-in generator.
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GeneratePluginOutput 13\n");
  std::unique_ptr<io::ZeroCopyOutputStream> current_output;
  for (int i = 0; i < response.file_size(); ++i) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GeneratePluginOutput 14\n");
    const CodeGeneratorResponse::File& output_file = response.file(i);

    if (!output_file.insertion_point().empty()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GeneratePluginOutput 15\n");
      std::string filename = output_file.name();
      // Open a file for insert.
      // We reset current_output to nullptr first so that the old file is closed
      // before the new one is opened.
      current_output.reset();
      current_output.reset(
          generator_context->OpenForInsertWithGeneratedCodeInfo(
              filename, output_file.insertion_point(),
              output_file.generated_code_info()));
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GeneratePluginOutput 15\n");
    } else if (!output_file.name().empty()) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GeneratePluginOutput 16\n");
      // Starting a new file.  Open it.
      // We reset current_output to nullptr first so that the old file is closed
      // before the new one is opened.
      current_output.reset();
      current_output.reset(generator_context->Open(output_file.name()));
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GeneratePluginOutput 16\n");
    } else if (current_output == nullptr) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GeneratePluginOutput 17\n");
      *error = absl::Substitute(
          "$0: First file chunk returned by plugin did not specify a file "
          "name.",
          plugin_name);
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GeneratePluginOutput 17\n");
      return false;
    }

    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GeneratePluginOutput 18\n");
    // Use CodedOutputStream for convenience; otherwise we'd need to provide
    // our own buffer-copying loop.
    io::CodedOutputStream writer(current_output.get());
    writer.WriteString(output_file.content());
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GeneratePluginOutput 18\n");
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GeneratePluginOutput 14\n");
  }

  // Check for errors.
  bool success = true;
  if (!EnforceProto3OptionalSupport(plugin_name, response.supported_features(),
                                    parsed_files)) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GeneratePluginOutput 19\n");
    success = false;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GeneratePluginOutput 19\n");
  }
  if (!EnforceEditionsSupport(plugin_name, response.supported_features(),
                              static_cast<Edition>(response.minimum_edition()),
                              static_cast<Edition>(response.maximum_edition()),
                              parsed_files)) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GeneratePluginOutput 20\n");
    success = false;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GeneratePluginOutput 20\n");
  }
  if (!response.error().empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::GeneratePluginOutput 21\n");
    // Generator returned an error.
    *error = response.error();
    success = false;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GeneratePluginOutput 21\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::GeneratePluginOutput 13\n");
  return success;
}

bool CommandLineInterface::EncodeOrDecode(const DescriptorPool* pool) {
  fprintf(stderr, "\n");
  // Look up the type.
  const Descriptor* type = pool->FindMessageTypeByName(codec_type_);
  if (type == nullptr) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::EncodeOrDecode 2\n");
    std::cerr << "Type not defined: " << codec_type_ << std::endl;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::EncodeOrDecode 2\n");
    return false;
  }

  DynamicMessageFactory dynamic_factory(pool);
  std::unique_ptr<Message> message(dynamic_factory.GetPrototype(type)->New());

  if (mode_ == MODE_ENCODE) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::EncodeOrDecode 3\n");
    SetFdToTextMode(STDIN_FILENO);
    SetFdToBinaryMode(STDOUT_FILENO);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::EncodeOrDecode 3\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::EncodeOrDecode 4\n");
    SetFdToBinaryMode(STDIN_FILENO);
    SetFdToTextMode(STDOUT_FILENO);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::EncodeOrDecode 4\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::EncodeOrDecode 5\n");
  io::FileInputStream in(STDIN_FILENO);
  io::FileOutputStream out(STDOUT_FILENO);

  if (mode_ == MODE_ENCODE) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::EncodeOrDecode 6\n");
    // Input is text.
    ErrorPrinter error_collector(error_format_);
    TextFormat::Parser parser;
    parser.RecordErrorsTo(&error_collector);
    parser.AllowPartialMessage(true);

    if (!parser.Parse(&in, message.get())) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::EncodeOrDecode 7\n");
      std::cerr << "Failed to parse input." << std::endl;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::EncodeOrDecode 7\n");
      return false;
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::EncodeOrDecode 6\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::EncodeOrDecode 8\n");
    // Input is binary.
    if (!message->ParsePartialFromZeroCopyStream(&in)) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::EncodeOrDecode 9\n");
      std::cerr << "Failed to parse input." << std::endl;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::EncodeOrDecode 9\n");
      return false;
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::EncodeOrDecode 8\n");
  }

  if (!message->IsInitialized()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::EncodeOrDecode 10\n");
    std::cerr << "warning:  Input message is missing required fields:  "
              << message->InitializationErrorString() << std::endl;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::EncodeOrDecode 10\n");
  }

  if (mode_ == MODE_ENCODE) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::EncodeOrDecode 11\n");
    // Output is binary.
    io::CodedOutputStream coded_out(&out);
    coded_out.SetSerializationDeterministic(deterministic_output_);
    if (!message->SerializePartialToCodedStream(&coded_out)) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::EncodeOrDecode 12\n");
      std::cerr << "output: I/O error." << std::endl;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::EncodeOrDecode 12\n");
      return false;
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::EncodeOrDecode 11\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::EncodeOrDecode 13\n");
    // Output is text.
    if (!TextFormat::Print(*message, &out)) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::EncodeOrDecode 14\n");
      std::cerr << "output: I/O error." << std::endl;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::EncodeOrDecode 14\n");
      return false;
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::EncodeOrDecode 13\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::EncodeOrDecode 5\n");
  return true;
}

bool CommandLineInterface::WriteDescriptorSet(
    const std::vector<const FileDescriptor*>& parsed_files) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteDescriptorSet 1\n");
  FileDescriptorSet file_set;

  absl::flat_hash_set<const FileDescriptor*> already_seen;
  if (!imports_in_descriptor_set_) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteDescriptorSet 2\n");
    // Since we don't want to output transitive dependencies, but we do want
    // things to be in dependency order, add all dependencies that aren't in
    // parsed_files to already_seen.  This will short circuit the recursion
    // in GetTransitiveDependencies.
    absl::flat_hash_set<const FileDescriptor*> to_output;
    to_output.insert(parsed_files.begin(), parsed_files.end());
    for (size_t i = 0; i < parsed_files.size(); ++i) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteDescriptorSet 3\n");
      const FileDescriptor* file = parsed_files[i];
      for (int j = 0; j < file->dependency_count(); j++) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteDescriptorSet 4\n");
        const FileDescriptor* dependency = file->dependency(j);
        // if the dependency isn't in parsed files, mark it as already seen
        if (to_output.find(dependency) == to_output.end()) {
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteDescriptorSet 5\n");
          already_seen.insert(dependency);
          fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteDescriptorSet 5\n");
        }
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteDescriptorSet 4\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteDescriptorSet 3\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteDescriptorSet 2\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteDescriptorSet 6\n");
  TransitiveDependencyOptions options;
  options.include_json_name = true;
  options.include_source_code_info = source_info_in_descriptor_set_;
  options.retain_options = retain_options_in_descriptor_set_;
  for (size_t i = 0; i < parsed_files.size(); ++i) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteDescriptorSet 7\n");
    GetTransitiveDependencies(parsed_files[i], &already_seen,
                              file_set.mutable_file(), options);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteDescriptorSet 7\n");
  }

  int fd;
  do {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteDescriptorSet 8\n");
    fd = open(descriptor_set_out_name_.c_str(),
              O_WRONLY | O_CREAT | O_TRUNC | O_BINARY, 0666);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteDescriptorSet 8\n");
  } while (fd < 0 && errno == EINTR);

  if (fd < 0) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteDescriptorSet 9\n");
    perror(descriptor_set_out_name_.c_str());
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteDescriptorSet 9\n");
    return false;
  }

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteDescriptorSet 10\n");
  io::FileOutputStream out(fd);

  {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteDescriptorSet 11\n");
    io::CodedOutputStream coded_out(&out);
    // Determinism is useful here because build outputs are sometimes checked
    // into version control.
    coded_out.SetSerializationDeterministic(true);
    if (!file_set.SerializeToCodedStream(&coded_out)) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteDescriptorSet 12\n");
      std::cerr << descriptor_set_out_name_ << ": " << strerror(out.GetErrno())
                << std::endl;
      out.Close();
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteDescriptorSet 12\n");
      return false;
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteDescriptorSet 11\n");
  }

  if (!out.Close()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteDescriptorSet 13\n");
    std::cerr << descriptor_set_out_name_ << ": " << strerror(out.GetErrno())
              << std::endl;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteDescriptorSet 13\n");
    return false;
  }

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteDescriptorSet 10\n");
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteDescriptorSet 6\n");
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteDescriptorSet 1\n");
  return true;
}

bool CommandLineInterface::WriteEditionDefaults(const DescriptorPool& pool) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteEditionDefaults 1\n");
  const Descriptor* feature_set;
  if (opensource_runtime_) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteEditionDefaults 2\n");
    feature_set = pool.FindMessageTypeByName("google.protobuf.FeatureSet");
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteEditionDefaults 2\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteEditionDefaults 3\n");
    feature_set = pool.FindMessageTypeByName("google.protobuf.FeatureSet");
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteEditionDefaults 3\n");
  }
  if (feature_set == nullptr) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteEditionDefaults 4\n");
    std::cerr << edition_defaults_out_name_
              << ": Could not find FeatureSet in descriptor pool.  Please make "
                 "sure descriptor.proto is in your import path"
              << std::endl;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteEditionDefaults 4\n");
    return false;
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteEditionDefaults 5\n");
  std::vector<const FieldDescriptor*> extensions;
  pool.FindAllExtensions(feature_set, &extensions);

  Edition minimum = ProtocMinimumEdition();
  if (edition_defaults_minimum_ != EDITION_UNKNOWN) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteEditionDefaults 6\n");
    minimum = edition_defaults_minimum_;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteEditionDefaults 6\n");
  }
  Edition maximum = ProtocMaximumEdition();
  if (edition_defaults_maximum_ != EDITION_UNKNOWN) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteEditionDefaults 7\n");
    maximum = edition_defaults_maximum_;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteEditionDefaults 7\n");
  }

  absl::StatusOr<FeatureSetDefaults> defaults =
      FeatureResolver::CompileDefaults(feature_set, extensions, minimum,
                                       maximum);
  if (!defaults.ok()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteEditionDefaults 8\n");
    std::cerr << edition_defaults_out_name_ << ": "
              << defaults.status().message() << std::endl;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteEditionDefaults 8\n");
    return false;
  }

  int fd;
  do {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteEditionDefaults 9\n");
    fd = open(edition_defaults_out_name_.c_str(),
              O_WRONLY | O_CREAT | O_TRUNC | O_BINARY, 0666);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteEditionDefaults 9\n");
  } while (fd < 0 && errno == EINTR);

  if (fd < 0) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteEditionDefaults 10\n");
    perror(edition_defaults_out_name_.c_str());
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteEditionDefaults 10\n");
    return false;
  }

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteEditionDefaults 11\n");
  io::FileOutputStream out(fd);

  {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteEditionDefaults 12\n");
    io::CodedOutputStream coded_out(&out);
    // Determinism is useful here because build outputs are sometimes checked
    // into version control.
    coded_out.SetSerializationDeterministic(true);
    if (!defaults->SerializeToCodedStream(&coded_out)) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteEditionDefaults 13\n");
      std::cerr << edition_defaults_out_name_ << ": "
                << strerror(out.GetErrno()) << std::endl;
      out.Close();
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteEditionDefaults 13\n");
      return false;
    }
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteEditionDefaults 12\n");
  }

  if (!out.Close()) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::WriteEditionDefaults 14\n");
    std::cerr << edition_defaults_out_name_ << ": " << strerror(out.GetErrno())
              << std::endl;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteEditionDefaults 14\n");
    return false;
  }

  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteEditionDefaults 11\n");
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteEditionDefaults 5\n");
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::WriteEditionDefaults 1\n");
  return true;
}

const CommandLineInterface::GeneratorInfo*
CommandLineInterface::FindGeneratorByFlag(const std::string& name) const {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::FindGeneratorByFlag 1\n");
  auto it = generators_by_flag_name_.find(name);
  if (it == generators_by_flag_name_.end()) {
    fprintf(stderr, "\n");
    fprintf(stderr, "\n");
    return nullptr;
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::FindGeneratorByFlag 1\n");
  return &it->second;
}

const CommandLineInterface::GeneratorInfo*
CommandLineInterface::FindGeneratorByOption(const std::string& option) const {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::FindGeneratorByOption 1\n");
  auto it = generators_by_option_name_.find(option);
  if (it == generators_by_option_name_.end()) {
    fprintf(stderr, "\n");
    fprintf(stderr, "\n");
    return nullptr;
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::FindGeneratorByOption 1\n");
  return &it->second;
}

namespace {

// Utility function for PrintFreeFieldNumbers.
// Stores occupied ranges into the ranges parameter, and next level of sub
// message types into the nested_messages parameter.  The FieldRange is left
// inclusive, right exclusive. i.e. [a, b).
//
// Nested Messages:
// Note that it only stores the nested message type, iff the nested type is
// either a direct child of the given descriptor, or the nested type is a
// descendant of the given descriptor and all the nodes between the
// nested type and the given descriptor are group types. e.g.
//
// message Foo {
//   message Bar {
//     message NestedBar {}
//   }
//   group Baz = 1 {
//     group NestedBazGroup = 2 {
//       message Quz {
//         message NestedQuz {}
//       }
//     }
//     message NestedBaz {}
//   }
// }
//
// In this case, Bar, Quz and NestedBaz will be added into the nested types.
// Since free field numbers of group types will not be printed, this makes sure
// the nested message types in groups will not be dropped. The nested_messages
// parameter will contain the direct children (when groups are ignored in the
// tree) of the given descriptor for the caller to traverse. The declaration
// order of the nested messages is also preserved.
typedef std::pair<int, int> FieldRange;
void GatherOccupiedFieldRanges(
    const Descriptor* descriptor, absl::btree_set<FieldRange>* ranges,
    std::vector<const Descriptor*>* nested_messages) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GatherOccupiedFieldRanges 1\n");
  for (int i = 0; i < descriptor->field_count(); ++i) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GatherOccupiedFieldRanges 2\n");
    const FieldDescriptor* fd = descriptor->field(i);
    ranges->insert(FieldRange(fd->number(), fd->number() + 1));
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GatherOccupiedFieldRanges 2\n");
  }
  for (int i = 0; i < descriptor->extension_range_count(); ++i) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GatherOccupiedFieldRanges 3\n");
    ranges->insert(FieldRange(descriptor->extension_range(i)->start_number(),
                              descriptor->extension_range(i)->end_number()));
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GatherOccupiedFieldRanges 3\n");
  }
  for (int i = 0; i < descriptor->reserved_range_count(); ++i) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GatherOccupiedFieldRanges 4\n");
    ranges->insert(FieldRange(descriptor->reserved_range(i)->start,
                              descriptor->reserved_range(i)->end));
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GatherOccupiedFieldRanges 4\n");
  }
  // Handle the nested messages/groups in declaration order to make it
  // post-order strict.
  for (int i = 0; i < descriptor->nested_type_count(); ++i) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter GatherOccupiedFieldRanges 5\n");
    const Descriptor* nested_desc = descriptor->nested_type(i);
    nested_messages->push_back(nested_desc);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GatherOccupiedFieldRanges 5\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit GatherOccupiedFieldRanges 1\n");
}

// Utility function for PrintFreeFieldNumbers.
// Actually prints the formatted free field numbers for given message name and
// occupied ranges.
void FormatFreeFieldNumbers(absl::string_view name,
                            const absl::btree_set<FieldRange>& ranges) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter FormatFreeFieldNumbers 1\n");
  std::string output;
  absl::StrAppendFormat(&output, "%-35s free:", name);
  int next_free_number = 1;
  for (const auto& range : ranges) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter FormatFreeFieldNumbers 2\n");
    // This happens when groups re-use parent field numbers, in which
    // case we skip the FieldRange entirely.
    if (next_free_number >= range.second) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter FormatFreeFieldNumbers 3\n");
      continue;
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit FormatFreeFieldNumbers 3\n");
    }

    if (next_free_number < range.first) {
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter FormatFreeFieldNumbers 4\n");
      if (next_free_number + 1 == range.first) {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter FormatFreeFieldNumbers 5\n");
        // Singleton
        absl::StrAppendFormat(&output, " %d", next_free_number);
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit FormatFreeFieldNumbers 5\n");
      } else {
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter FormatFreeFieldNumbers 6\n");
        // Range
        absl::StrAppendFormat(&output, " %d-%d", next_free_number,
                              range.first - 1);
        fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit FormatFreeFieldNumbers 6\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit FormatFreeFieldNumbers 4\n");
    }
    next_free_number = range.second;
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit FormatFreeFieldNumbers 2\n");
  }
  if (next_free_number <= FieldDescriptor::kMaxNumber) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter FormatFreeFieldNumbers 7\n");
    absl::StrAppendFormat(&output, " %d-INF", next_free_number);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit FormatFreeFieldNumbers 7\n");
  }
  std::cout << output << std::endl;
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit FormatFreeFieldNumbers 1\n");
}

}  // namespace

void CommandLineInterface::PrintFreeFieldNumbers(const Descriptor* descriptor) {
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::PrintFreeFieldNumbers 1\n");
  absl::btree_set<FieldRange> ranges;
  std::vector<const Descriptor*> nested_messages;
  GatherOccupiedFieldRanges(descriptor, &ranges, &nested_messages);

  for (size_t i = 0; i < nested_messages.size(); ++i) {
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] enter CommandLineInterface::PrintFreeFieldNumbers 2\n");
    PrintFreeFieldNumbers(nested_messages[i]);
    fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::PrintFreeFieldNumbers 2\n");
  }
  FormatFreeFieldNumbers(descriptor->full_name(), ranges);
  fprintf(stderr, "[src/google/protobuf/compiler/command_line_interface.cc] exit CommandLineInterface::PrintFreeFieldNumbers 1\n");
}


}  // namespace compiler
}  // namespace protobuf
}  // namespace google

#include "google/protobuf/port_undef.inc"
// Total cost: 3.700293
// Total split cost: 1.390704, input tokens: 363989, output tokens: 12483, cache read tokens: 9436, cache write tokens: 36525, split chunks: [(0, 760), (760, 1523), (1523, 2020), (2020, 2784), (2784, 3238)]
// Total instrumented cost: 2.309589, input tokens: 178450, output tokens: 115351, cache read tokens: 96909, cache write tokens: 81501

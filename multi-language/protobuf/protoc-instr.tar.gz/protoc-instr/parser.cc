// Protocol Buffers - Google's data interchange format
// Copyright 2008 Google Inc.  All rights reserved.
//
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file or at
// https://developers.google.com/open-source/licenses/bsd

// Author: kenton@google.com (Kenton Varda)
//  Based on original Protocol Buffers design by
//  Sanjay Ghemawat, Jeff Dean, and others.
//
// Recursive descent FTW.

#include "google/protobuf/compiler/parser.h"

#include <cstddef>
#include <cstdint>
#include <limits>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

#include "absl/cleanup/cleanup.h"
#include "absl/container/flat_hash_map.h"
#include "absl/container/flat_hash_set.h"
#include "absl/log/absl_check.h"
#include "absl/log/absl_log.h"
#include "absl/strings/ascii.h"
#include "absl/strings/escaping.h"
#include "absl/strings/str_cat.h"
#include "absl/strings/str_format.h"
#include "absl/strings/string_view.h"
#include "google/protobuf/descriptor.h"
#include "google/protobuf/descriptor.pb.h"
#include "google/protobuf/io/strtod.h"
#include "google/protobuf/io/tokenizer.h"
#include "google/protobuf/message_lite.h"

// Must be included last.
#include "google/protobuf/port_def.inc"

namespace google {
namespace protobuf {
namespace compiler {
namespace {

using TypeNameMap =
    absl::flat_hash_map<absl::string_view, FieldDescriptorProto::Type>;

const TypeNameMap& GetTypeNameTable() {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter GetTypeNameTable 1\n");
  static auto* table = new auto([]() {
    TypeNameMap result;

    result["double"] = FieldDescriptorProto::TYPE_DOUBLE;
    result["float"] = FieldDescriptorProto::TYPE_FLOAT;
    result["uint64"] = FieldDescriptorProto::TYPE_UINT64;
    result["fixed64"] = FieldDescriptorProto::TYPE_FIXED64;
    result["fixed32"] = FieldDescriptorProto::TYPE_FIXED32;
    result["bool"] = FieldDescriptorProto::TYPE_BOOL;
    result["string"] = FieldDescriptorProto::TYPE_STRING;
    result["group"] = FieldDescriptorProto::TYPE_GROUP;

    result["bytes"] = FieldDescriptorProto::TYPE_BYTES;
    result["uint32"] = FieldDescriptorProto::TYPE_UINT32;
    result["sfixed32"] = FieldDescriptorProto::TYPE_SFIXED32;
    result["sfixed64"] = FieldDescriptorProto::TYPE_SFIXED64;
    result["int32"] = FieldDescriptorProto::TYPE_INT32;
    result["int64"] = FieldDescriptorProto::TYPE_INT64;
    result["sint32"] = FieldDescriptorProto::TYPE_SINT32;
    result["sint64"] = FieldDescriptorProto::TYPE_SINT64;

    return result;
  }());
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit GetTypeNameTable 1\n");
  return *table;
}

// Camel-case the field name and append "Entry" for generated map entry name.
// e.g. map<KeyType, ValueType> foo_map => FooMapEntry
std::string MapEntryName(absl::string_view field_name) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter MapEntryName 1\n");
  std::string result;
  static const char kSuffix[] = "Entry";
  result.reserve(field_name.size() + sizeof(kSuffix));
  bool cap_next = true;
  for (const char field_name_char : field_name) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter MapEntryName 2\n");
    if (field_name_char == '_') {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter MapEntryName 3\n");
      cap_next = true;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit MapEntryName 3\n");
    } else if (cap_next) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter MapEntryName 4\n");
      // Note: Do not use ctype.h due to locales.
      if ('a' <= field_name_char && field_name_char <= 'z') {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter MapEntryName 5\n");
        result.push_back(field_name_char - 'a' + 'A');
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit MapEntryName 5\n");
      } else {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter MapEntryName 6\n");
        result.push_back(field_name_char);
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit MapEntryName 6\n");
      }
      cap_next = false;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit MapEntryName 4\n");
    } else {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter MapEntryName 7\n");
      result.push_back(field_name_char);
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit MapEntryName 7\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit MapEntryName 2\n");
  }
  result.append(kSuffix);
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit MapEntryName 1\n");
  return result;
}

}  // anonymous namespace

// Makes code slightly more readable.  The meaning of "DO(foo)" is
// "Execute foo and fail if it fails.", where failure is indicated by
// returning false.
#define DO(STATEMENT) \
  if (STATEMENT) {    \
  } else              \
    return false

// ===================================================================

Parser::Parser()
    : input_(nullptr),
      error_collector_(nullptr),
      source_location_table_(nullptr),
      had_errors_(false),
      require_syntax_identifier_(false),
      stop_after_syntax_identifier_(false) {
}

Parser::~Parser() = default;
// ===================================================================

inline bool Parser::LookingAt(absl::string_view text) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LookingAt 1\n");
  bool result = input_->current().text == text;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LookingAt 1\n");
  return result;
}

inline bool Parser::LookingAtType(io::Tokenizer::TokenType token_type) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LookingAtType 1\n");
  bool result = input_->current().type == token_type;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LookingAtType 1\n");
  return result;
}

inline bool Parser::AtEnd() { 
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::AtEnd 1\n");
  bool result = LookingAtType(io::Tokenizer::TYPE_END);
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::AtEnd 1\n");
  return result; 
}

bool Parser::TryConsume(absl::string_view text) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::TryConsume 1\n");
  if (LookingAt(text)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::TryConsume 2\n");
    input_->Next();
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::TryConsume 2\n");
    return true;
  } else {
    fprintf(stderr, "\n");
    fprintf(stderr, "\n");
    return false;
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::TryConsume 1\n");
}

bool Parser::Consume(absl::string_view text, ErrorMaker error) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::Consume 1\n");
  if (TryConsume(text)) {
    fprintf(stderr, "\n");
    fprintf(stderr, "\n");
    return true;
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::Consume 3\n");
    RecordError(error);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::Consume 3\n");
    return false;
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::Consume 1\n");
}

bool Parser::Consume(absl::string_view text) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::Consume 4\n");
  bool result = Consume(text,
                 [&] { return absl::StrCat("Expected \"", text, "\"."); });
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::Consume 4\n");
  return result;
}

bool Parser::ConsumeIdentifier(std::string* output, ErrorMaker error) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeIdentifier 1\n");
  if (LookingAtType(io::Tokenizer::TYPE_IDENTIFIER)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeIdentifier 2\n");
    *output = input_->current().text;
    input_->Next();
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeIdentifier 2\n");
    return true;
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeIdentifier 3\n");
    RecordError(error);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeIdentifier 3\n");
    return false;
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeIdentifier 1\n");
}

bool Parser::ConsumeInteger(int* output, ErrorMaker error) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeInteger 1\n");
  if (LookingAtType(io::Tokenizer::TYPE_INTEGER)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeInteger 2\n");
    uint64_t value = 0;
    if (!io::Tokenizer::ParseInteger(input_->current().text,
                                     std::numeric_limits<int32_t>::max(),
                                     &value)) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeInteger 3\n");
      RecordError("Integer out of range.");
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeInteger 3\n");
      // We still return true because we did, in fact, parse an integer.
    }
    *output = value;
    input_->Next();
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeInteger 2\n");
    return true;
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeInteger 4\n");
    RecordError(error);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeInteger 4\n");
    return false;
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeInteger 1\n");
}

bool Parser::ConsumeSignedInteger(int* output, ErrorMaker error) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeSignedInteger 1\n");
  bool is_negative = false;
  uint64_t max_value = std::numeric_limits<int32_t>::max();
  if (TryConsume("-")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeSignedInteger 2\n");
    is_negative = true;
    max_value += 1;
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeSignedInteger 2\n");
  }
  uint64_t value = 0;
  DO(ConsumeInteger64(max_value, &value, error));
  if (is_negative) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeSignedInteger 3\n");
    value *= -1;
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeSignedInteger 3\n");
  }
  *output = value;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeSignedInteger 1\n");
  return true;
}

bool Parser::ConsumeInteger64(uint64_t max_value, uint64_t* output,
                              ErrorMaker error) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeInteger64 1\n");
  if (LookingAtType(io::Tokenizer::TYPE_INTEGER)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeInteger64 2\n");
    if (!io::Tokenizer::ParseInteger(input_->current().text, max_value,
                                     output)) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeInteger64 3\n");
      RecordError("Integer out of range.");
      // We still return true because we did, in fact, parse an integer.
      *output = 0;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeInteger64 3\n");
    }
    input_->Next();
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeInteger64 2\n");
    return true;
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeInteger64 4\n");
    RecordError(error);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeInteger64 4\n");
    return false;
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeInteger64 1\n");
}

bool Parser::TryConsumeInteger64(uint64_t max_value, uint64_t* output) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::TryConsumeInteger64 1\n");
  if (LookingAtType(io::Tokenizer::TYPE_INTEGER) &&
      io::Tokenizer::ParseInteger(input_->current().text, max_value, output)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::TryConsumeInteger64 2\n");
    input_->Next();
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::TryConsumeInteger64 2\n");
    return true;
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::TryConsumeInteger64 1\n");
  return false;
}

bool Parser::ConsumeNumber(double* output, ErrorMaker error) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeNumber 1\n");
  if (LookingAtType(io::Tokenizer::TYPE_FLOAT)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeNumber 2\n");
    *output = io::Tokenizer::ParseFloat(input_->current().text);
    input_->Next();
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeNumber 2\n");
    return true;
  } else if (LookingAtType(io::Tokenizer::TYPE_INTEGER)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeNumber 3\n");
    // Also accept integers.
    uint64_t value = 0;
    if (io::Tokenizer::ParseInteger(input_->current().text,
                                    std::numeric_limits<uint64_t>::max(),
                                    &value)) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeNumber 4\n");
      *output = value;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeNumber 4\n");
    } else if (input_->current().text[0] == '0') {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeNumber 5\n");
      // octal or hexadecimal; don't bother parsing as float
      RecordError("Integer out of range.");
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeNumber 5\n");
      // We still return true because we did, in fact, parse a number.
    } else if (!io::Tokenizer::TryParseFloat(input_->current().text, output)) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeNumber 6\n");
      // out of int range, and not valid float? 🤷
      RecordError("Integer out of range.");
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeNumber 6\n");
      // We still return true because we did, in fact, parse a number.
    }
    input_->Next();
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeNumber 3\n");
    return true;
  } else if (LookingAt("inf")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeNumber 7\n");
    *output = std::numeric_limits<double>::infinity();
    input_->Next();
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeNumber 7\n");
    return true;
  } else if (LookingAt("nan")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeNumber 8\n");
    *output = std::numeric_limits<double>::quiet_NaN();
    input_->Next();
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeNumber 8\n");
    return true;
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeNumber 9\n");
    RecordError(error);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeNumber 9\n");
    return false;
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeNumber 1\n");
}

bool Parser::ConsumeString(std::string* output, ErrorMaker error) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeString 1\n");
  if (LookingAtType(io::Tokenizer::TYPE_STRING)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeString 2\n");
    io::Tokenizer::ParseString(input_->current().text, output);
    input_->Next();
    // Allow C++ like concatenation of adjacent string tokens.
    while (LookingAtType(io::Tokenizer::TYPE_STRING)) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeString 3\n");
      io::Tokenizer::ParseStringAppend(input_->current().text, output);
      input_->Next();
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeString 3\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeString 2\n");
    return true;
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeString 4\n");
    RecordError(error);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeString 4\n");
    return false;
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeString 1\n");
}

bool Parser::TryConsumeEndOfDeclaration(absl::string_view text,
                                        const LocationRecorder* location) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::TryConsumeEndOfDeclaration 1\n");
  if (LookingAt(text)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::TryConsumeEndOfDeclaration 2\n");
    std::string leading, trailing;
    std::vector<std::string> detached;
    input_->NextWithComments(&trailing, &detached, &leading);

    // Save the leading comments for next time, and recall the leading comments
    // from last time.
    leading.swap(upcoming_doc_comments_);

    if (location != nullptr) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::TryConsumeEndOfDeclaration 3\n");
      upcoming_detached_comments_.swap(detached);
      location->AttachComments(&leading, &trailing, &detached);
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::TryConsumeEndOfDeclaration 3\n");
    } else if (text == "}") {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::TryConsumeEndOfDeclaration 4\n");
      // If the current location is null and we are finishing the current scope,
      // drop pending upcoming detached comments.
      upcoming_detached_comments_.swap(detached);
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::TryConsumeEndOfDeclaration 4\n");
    } else {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::TryConsumeEndOfDeclaration 5\n");
      // Otherwise, append the new detached comments to the existing upcoming
      // detached comments.
      upcoming_detached_comments_.insert(upcoming_detached_comments_.end(),
                                         detached.begin(), detached.end());
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::TryConsumeEndOfDeclaration 5\n");
    }

    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::TryConsumeEndOfDeclaration 2\n");
    return true;
  } else {
    fprintf(stderr, "\n");
    fprintf(stderr, "\n");
    return false;
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::TryConsumeEndOfDeclaration 1\n");
}

bool Parser::ConsumeEndOfDeclaration(absl::string_view text,
                                     const LocationRecorder* location) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeEndOfDeclaration 1\n");
  if (TryConsumeEndOfDeclaration(text, location)) {
    fprintf(stderr, "\n");
    fprintf(stderr, "\n");
    return true;
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ConsumeEndOfDeclaration 3\n");
    RecordError([&] { return absl::StrCat("Expected \"", text, "\"."); });
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeEndOfDeclaration 3\n");
    return false;
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ConsumeEndOfDeclaration 1\n");
}

// -------------------------------------------------------------------

void Parser::RecordError(int line, int column, ErrorMaker error) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::RecordError 1\n");
  if (error_collector_ != nullptr) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::RecordError 2\n");
    error_collector_->RecordError(line, column, error.get());
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::RecordError 2\n");
  }
  had_errors_ = true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::RecordError 1\n");
}

void Parser::RecordError(ErrorMaker error) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::RecordError 3\n");
  RecordError(input_->current().line, input_->current().column, error);
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::RecordError 3\n");
}

void Parser::RecordWarning(int line, int column, ErrorMaker error) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::RecordWarning 1\n");
  if (error_collector_ != nullptr) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::RecordWarning 2\n");
    error_collector_->RecordWarning(line, column, error.get());
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::RecordWarning 2\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::RecordWarning 1\n");
}

// Invokes error_collector_->RecordWarning() with the line and column number
// of the current token.
void Parser::RecordWarning(ErrorMaker error) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::RecordWarning 3\n");
  RecordWarning(input_->current().line, input_->current().column, error);
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::RecordWarning 3\n");
}

// -------------------------------------------------------------------

Parser::LocationRecorder::LocationRecorder(Parser* parser)
    : parser_(parser),
      source_code_info_(parser->source_code_info_),
      location_(parser_->source_code_info_->add_location()) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LocationRecorder::LocationRecorder 1\n");
  location_->add_span(parser_->input_->current().line);
  location_->add_span(parser_->input_->current().column);
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LocationRecorder::LocationRecorder 1\n");
}

Parser::LocationRecorder::LocationRecorder(const LocationRecorder& parent) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LocationRecorder::LocationRecorder 2\n");
  Init(parent, parent.source_code_info_);
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LocationRecorder::LocationRecorder 2\n");
}

Parser::LocationRecorder::LocationRecorder(const LocationRecorder& parent,
                                           int path1,
                                           SourceCodeInfo* source_code_info) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LocationRecorder::LocationRecorder 3\n");
  Init(parent, source_code_info);
  AddPath(path1);
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LocationRecorder::LocationRecorder 3\n");
}

Parser::LocationRecorder::LocationRecorder(const LocationRecorder& parent,
                                           int path1) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LocationRecorder::LocationRecorder 4\n");
  Init(parent, parent.source_code_info_);
  AddPath(path1);
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LocationRecorder::LocationRecorder 4\n");
}

Parser::LocationRecorder::LocationRecorder(const LocationRecorder& parent,
                                           int path1, int path2) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LocationRecorder::LocationRecorder 5\n");
  Init(parent, parent.source_code_info_);
  AddPath(path1);
  AddPath(path2);
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LocationRecorder::LocationRecorder 5\n");
}

void Parser::LocationRecorder::Init(const LocationRecorder& parent,
                                    SourceCodeInfo* source_code_info) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LocationRecorder::Init 1\n");
  parser_ = parent.parser_;
  source_code_info_ = source_code_info;

  location_ = source_code_info_->add_location();
  location_->mutable_path()->CopyFrom(parent.location_->path());

  location_->add_span(parser_->input_->current().line);
  location_->add_span(parser_->input_->current().column);
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LocationRecorder::Init 1\n");
}

Parser::LocationRecorder::~LocationRecorder() {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LocationRecorder::~LocationRecorder 1\n");
  if (location_->span_size() <= 2) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LocationRecorder::~LocationRecorder 2\n");
    EndAt(parser_->input_->previous());
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LocationRecorder::~LocationRecorder 2\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LocationRecorder::~LocationRecorder 1\n");
}

void Parser::LocationRecorder::AddPath(int path_component) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LocationRecorder::AddPath 1\n");
  location_->add_path(path_component);
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LocationRecorder::AddPath 1\n");
}

void Parser::LocationRecorder::StartAt(const io::Tokenizer::Token& token) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LocationRecorder::StartAt 1\n");
  location_->set_span(0, token.line);
  location_->set_span(1, token.column);
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LocationRecorder::StartAt 1\n");
}

void Parser::LocationRecorder::StartAt(const LocationRecorder& other) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LocationRecorder::StartAt 2\n");
  location_->set_span(0, other.location_->span(0));
  location_->set_span(1, other.location_->span(1));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LocationRecorder::StartAt 2\n");
}

void Parser::LocationRecorder::EndAt(const io::Tokenizer::Token& token) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LocationRecorder::EndAt 1\n");
  if (token.line != location_->span(0)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LocationRecorder::EndAt 2\n");
    location_->add_span(token.line);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LocationRecorder::EndAt 2\n");
  }
  location_->add_span(token.end_column);
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LocationRecorder::EndAt 1\n");
}

void Parser::LocationRecorder::RecordLegacyLocation(
    const Message* descriptor,
    DescriptorPool::ErrorCollector::ErrorLocation location) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LocationRecorder::RecordLegacyLocation 1\n");
  if (parser_->source_location_table_ != nullptr) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LocationRecorder::RecordLegacyLocation 2\n");
    parser_->source_location_table_->Add(
        descriptor, location, location_->span(0), location_->span(1));
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LocationRecorder::RecordLegacyLocation 2\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LocationRecorder::RecordLegacyLocation 1\n");
}

void Parser::LocationRecorder::RecordLegacyImportLocation(
    const Message* descriptor, const std::string& name) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LocationRecorder::RecordLegacyImportLocation 1\n");
  if (parser_->source_location_table_ != nullptr) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LocationRecorder::RecordLegacyImportLocation 2\n");
    parser_->source_location_table_->AddImport(
        descriptor, name, location_->span(0), location_->span(1));
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LocationRecorder::RecordLegacyImportLocation 2\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LocationRecorder::RecordLegacyImportLocation 1\n");
}

int Parser::LocationRecorder::CurrentPathSize() const {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LocationRecorder::CurrentPathSize 1\n");
  int result = location_->path_size();
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LocationRecorder::CurrentPathSize 1\n");
  return result;
}

void Parser::LocationRecorder::AttachComments(
    std::string* leading, std::string* trailing,
    std::vector<std::string>* detached_comments) const {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LocationRecorder::AttachComments 1\n");
  ABSL_CHECK(!location_->has_leading_comments());
  ABSL_CHECK(!location_->has_trailing_comments());

  if (!leading->empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LocationRecorder::AttachComments 2\n");
    location_->mutable_leading_comments()->swap(*leading);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LocationRecorder::AttachComments 2\n");
  }
  if (!trailing->empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LocationRecorder::AttachComments 3\n");
    location_->mutable_trailing_comments()->swap(*trailing);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LocationRecorder::AttachComments 3\n");
  }
  for (int i = 0; i < detached_comments->size(); ++i) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::LocationRecorder::AttachComments 4\n");
    location_->add_leading_detached_comments()->swap((*detached_comments)[i]);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LocationRecorder::AttachComments 4\n");
  }
  detached_comments->clear();
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::LocationRecorder::AttachComments 1\n");
}

// -------------------------------------------------------------------

void Parser::SkipStatement() {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::SkipStatement 1\n");
  while (true) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::SkipStatement 2\n");
    if (AtEnd()) {
      fprintf(stderr, "\n");
      fprintf(stderr, "\n");
      return;
    } else if (LookingAtType(io::Tokenizer::TYPE_SYMBOL)) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::SkipStatement 4\n");
      if (TryConsumeEndOfDeclaration(";", nullptr)) {
        fprintf(stderr, "\n");
        fprintf(stderr, "\n");
        return;
      } else if (TryConsume("{")) {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::SkipStatement 6\n");
        SkipRestOfBlock();
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::SkipStatement 6\n");
        return;
      } else if (LookingAt("}")) {
        fprintf(stderr, "\n");
        fprintf(stderr, "\n");
        return;
      }
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::SkipStatement 4\n");
    }
    input_->Next();
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::SkipStatement 2\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::SkipStatement 1\n");
}

void Parser::SkipRestOfBlock() {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::SkipRestOfBlock 1\n");
  size_t block_count = 1;
  while (true) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::SkipRestOfBlock 2\n");
    if (AtEnd()) {
      fprintf(stderr, "\n");
      fprintf(stderr, "\n");
      return;
    } else if (LookingAtType(io::Tokenizer::TYPE_SYMBOL)) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::SkipRestOfBlock 4\n");
      if (TryConsumeEndOfDeclaration("}", nullptr)) {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::SkipRestOfBlock 5\n");
        if (--block_count == 0) break;
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::SkipRestOfBlock 5\n");
      } else if (TryConsume("{")) {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::SkipRestOfBlock 6\n");
        ++block_count;
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::SkipRestOfBlock 6\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::SkipRestOfBlock 4\n");
    }
    input_->Next();
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::SkipRestOfBlock 2\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::SkipRestOfBlock 1\n");
}

// ===================================================================

bool Parser::ValidateMessage(const DescriptorProto* proto) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ValidateMessage 1\n");
  for (int i = 0; i < proto->options().uninterpreted_option_size(); i++) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ValidateMessage 2\n");
    const UninterpretedOption& option =
        proto->options().uninterpreted_option(i);
    if (option.name_size() > 0 && !option.name(0).is_extension() &&
        option.name(0).name_part() == "map_entry") {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ValidateMessage 3\n");
      int line = -1, col = 0;  // indicates line and column not known
      if (source_location_table_ != nullptr) {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ValidateMessage 4\n");
        source_location_table_->Find(
            &option, DescriptorPool::ErrorCollector::OPTION_NAME, &line, &col);
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ValidateMessage 4\n");
      }
      RecordError(line, col,
                  "map_entry should not be set explicitly. "
                  "Use map<KeyType, ValueType> instead.");
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ValidateMessage 3\n");
      return false;
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ValidateMessage 2\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ValidateMessage 1\n");
  return true;
}

bool Parser::ValidateEnum(const EnumDescriptorProto* proto) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ValidateEnum 1\n");
  bool has_allow_alias = false;
  bool allow_alias = false;

  for (int i = 0; i < proto->options().uninterpreted_option_size(); i++) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ValidateEnum 2\n");
    const UninterpretedOption option = proto->options().uninterpreted_option(i);
    if (option.name_size() > 1) {
      fprintf(stderr, "\n");
      fprintf(stderr, "\n");
      continue;
    }
    if (!option.name(0).is_extension() &&
        option.name(0).name_part() == "allow_alias") {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ValidateEnum 4\n");
      has_allow_alias = true;
      if (option.identifier_value() == "true") {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ValidateEnum 5\n");
        allow_alias = true;
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ValidateEnum 5\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ValidateEnum 4\n");
      break;
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ValidateEnum 2\n");
  }

  if (has_allow_alias && !allow_alias) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ValidateEnum 6\n");
    // This needlessly clutters declarations with nops.
    RecordError([=] {
      return absl::StrCat(
          "\"", proto->name(),
          "\" declares 'option allow_alias = false;' which has no effect. "
          "Please remove the declaration.");
    });
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ValidateEnum 6\n");
    return false;
  }

  absl::flat_hash_set<int> used_values;
  bool has_duplicates = false;
  for (int i = 0; i < proto->value_size(); ++i) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ValidateEnum 7\n");
    const EnumValueDescriptorProto& enum_value = proto->value(i);
    if (used_values.find(enum_value.number()) != used_values.end()) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ValidateEnum 8\n");
      has_duplicates = true;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ValidateEnum 8\n");
      break;
    } else {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ValidateEnum 9\n");
      used_values.insert(enum_value.number());
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ValidateEnum 9\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ValidateEnum 7\n");
  }
  if (allow_alias && !has_duplicates) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ValidateEnum 10\n");
    // Generate an error if an enum declares support for duplicate enum values
    // and does not use it protect future authors.
    RecordError([=] {
      return absl::StrCat(
          "\"", proto->name(),
          "\" declares support for enum aliases but no enum values share field "
          "numbers. Please remove the unnecessary 'option allow_alias = true;' "
          "declaration.");
    });
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ValidateEnum 10\n");
    return false;
  }

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ValidateEnum 1\n");
  return true;
}

bool Parser::Parse(io::Tokenizer* input, FileDescriptorProto* file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::Parse 1\n");
  input_ = input;
  had_errors_ = false;
  syntax_identifier_.clear();

  // Note that |file| could be NULL at this point if
  // stop_after_syntax_identifier_ is true.  So, we conservatively allocate
  // SourceCodeInfo on the stack, then swap it into the FileDescriptorProto
  // later on.
  SourceCodeInfo source_code_info;
  source_code_info_ = &source_code_info;

  if (LookingAtType(io::Tokenizer::TYPE_START)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::Parse 2\n");
    // Advance to first token.
    input_->NextWithComments(nullptr, &upcoming_detached_comments_,
                             &upcoming_doc_comments_);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::Parse 2\n");
  }

  {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::Parse 3\n");
    LocationRecorder root_location(this);
    root_location.RecordLegacyLocation(file,
                                       DescriptorPool::ErrorCollector::OTHER);

    if (require_syntax_identifier_ || LookingAt("syntax") ||
        LookingAt("edition")) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::Parse 4\n");
      if (!ParseSyntaxIdentifier(file, root_location)) {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::Parse 5\n");
        // Don't attempt to parse the file if we didn't recognize the syntax
        // identifier.
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::Parse 5\n");
        return false;
      }
      // Store the syntax into the file.
      if (file != nullptr) {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::Parse 6\n");
        file->set_syntax(syntax_identifier_);
        if (syntax_identifier_ == "editions") {
          fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::Parse 7\n");
          file->set_edition(edition_);
          fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::Parse 7\n");
        }
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::Parse 6\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::Parse 4\n");
    } else if (!stop_after_syntax_identifier_) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::Parse 8\n");
      ABSL_LOG(WARNING) << "No edition or syntax specified for the proto file: "
                        << file->name() << ". Please use 'edition = \"YYYY\";' "
                        << " to specify a valid edition "
                        << "version. (Defaulted to \"syntax = \"proto2\";\".)";
      syntax_identifier_ = "proto2";
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::Parse 8\n");
    }

    if (stop_after_syntax_identifier_) {
      fprintf(stderr, "\n");
      fprintf(stderr, "\n");
      return !had_errors_;
    }

    // Repeatedly parse statements until we reach the end of the file.
    while (!AtEnd()) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::Parse 10\n");
      if (!ParseTopLevelStatement(file, root_location)) {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::Parse 11\n");
        // This statement failed to parse.  Skip it, but keep looping to parse
        // other statements.
        SkipStatement();

        if (LookingAt("}")) {
          fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::Parse 12\n");
          RecordError("Unmatched \"}\".");
          input_->NextWithComments(nullptr, &upcoming_detached_comments_,
                                   &upcoming_doc_comments_);
          fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::Parse 12\n");
        }
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::Parse 11\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::Parse 10\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::Parse 3\n");
  }

  input_ = nullptr;
  source_code_info_ = nullptr;
  assert(file != nullptr);
  source_code_info.Swap(file->mutable_source_code_info());
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::Parse 1\n");
  return !had_errors_;
}

bool Parser::ParseSyntaxIdentifier(const FileDescriptorProto* file,
                                   const LocationRecorder& parent) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseSyntaxIdentifier 1\n");
  LocationRecorder syntax_location(parent,
                                   FileDescriptorProto::kSyntaxFieldNumber);
  syntax_location.RecordLegacyLocation(
      file, DescriptorPool::ErrorCollector::EDITIONS);
  bool has_edition = false;
  if (TryConsume("edition")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseSyntaxIdentifier 2\n");
    has_edition = true;
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseSyntaxIdentifier 2\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseSyntaxIdentifier 3\n");
    DO(Consume("syntax",
               "File must begin with a syntax statement, e.g. 'syntax = "
               "\"proto2\";'."));
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseSyntaxIdentifier 3\n");
  }

  DO(Consume("="));
  io::Tokenizer::Token syntax_token = input_->current();
  std::string syntax;
  DO(ConsumeString(&syntax, "Expected syntax identifier."));
  DO(ConsumeEndOfDeclaration(";", &syntax_location));

  if (has_edition) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseSyntaxIdentifier 4\n");
    if (!Edition_Parse(absl::StrCat("EDITION_", syntax), &edition_) ||
        edition_ == Edition::EDITION_PROTO2 ||
        edition_ == Edition::EDITION_PROTO3 ||
        edition_ == Edition::EDITION_UNKNOWN) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseSyntaxIdentifier 5\n");
      RecordError(syntax_token.line, syntax_token.column, [&] {
        return absl::StrCat("Unknown edition \"", syntax, "\".");
      });
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseSyntaxIdentifier 5\n");
      return false;
    }
    syntax_identifier_ = "editions";
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseSyntaxIdentifier 4\n");
    return true;
  }

  syntax_identifier_ = syntax;
  if (syntax != "proto2" && syntax != "proto3" &&
      !stop_after_syntax_identifier_) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseSyntaxIdentifier 6\n");
    RecordError(syntax_token.line, syntax_token.column, [&] {
      return absl::StrCat("Unrecognized syntax identifier \"", syntax,
                          "\".  This parser "
                          "only recognizes \"proto2\" and \"proto3\".");
    });
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseSyntaxIdentifier 6\n");
    return false;
  }

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseSyntaxIdentifier 1\n");
  return true;
}

bool Parser::ParseTopLevelStatement(FileDescriptorProto* file,
                                    const LocationRecorder& root_location) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseTopLevelStatement 1\n");
  if (TryConsumeEndOfDeclaration(";", nullptr)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseTopLevelStatement 2\n");
    // empty statement; ignore
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseTopLevelStatement 2\n");
    return true;
  }

  SymbolVisibility visibility = SymbolVisibility::VISIBILITY_UNSET;
  if (LookingAt("export") || LookingAt("local")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseTopLevelStatement 3\n");
    DO(ParseVisibility(file, &visibility));
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseTopLevelStatement 3\n");
  }

  if (LookingAt("message")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseTopLevelStatement 4\n");
    LocationRecorder location(root_location,
                              FileDescriptorProto::kMessageTypeFieldNumber,
                              file->message_type_size());
    // Maximum depth allowed by the DescriptorPool.
    recursion_depth_ = internal::cpp::MaxMessageDeclarationNestingDepth();
    bool result = ParseMessageDefinition(file->add_message_type(), visibility,
                              location, file);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseTopLevelStatement 4\n");
    return result;
  } else if (LookingAt("enum")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseTopLevelStatement 5\n");
    LocationRecorder location(root_location,
                              FileDescriptorProto::kEnumTypeFieldNumber,
                              file->enum_type_size());
    bool result = ParseEnumDefinition(file->add_enum_type(), visibility, location,
                               file);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseTopLevelStatement 5\n");
    return result;
  } else if (LookingAt("service")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseTopLevelStatement 6\n");
    LocationRecorder location(root_location,
                              FileDescriptorProto::kServiceFieldNumber,
                              file->service_size());
    bool result = ParseServiceDefinition(file->add_service(), location, file);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseTopLevelStatement 6\n");
    return result;
  } else if (LookingAt("extend")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseTopLevelStatement 7\n");
    LocationRecorder location(root_location,
                              FileDescriptorProto::kExtensionFieldNumber);
    bool result = ParseExtend(
        file->mutable_extension(), file->mutable_message_type(), root_location,
        FileDescriptorProto::kMessageTypeFieldNumber, location, file);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseTopLevelStatement 7\n");
    return result;
  } else if (LookingAt("import")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseTopLevelStatement 8\n");
    bool result = ParseImport(file->mutable_dependency(),
                       file->mutable_option_dependency(),
                       file->mutable_public_dependency(),
                       file->mutable_weak_dependency(), root_location, file);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseTopLevelStatement 8\n");
    return result;
  } else if (LookingAt("package")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseTopLevelStatement 9\n");
    bool result = ParsePackage(file, root_location, file);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseTopLevelStatement 9\n");
    return result;
  } else if (LookingAt("option")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseTopLevelStatement 10\n");
    LocationRecorder location(root_location,
                              FileDescriptorProto::kOptionsFieldNumber);
    bool result = ParseOption(file->mutable_options(), location, file,
                       OPTION_STATEMENT);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseTopLevelStatement 10\n");
    return result;
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseTopLevelStatement 11\n");
    RecordError("Expected top-level statement (e.g. \"message\").");
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseTopLevelStatement 11\n");
    return false;
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseTopLevelStatement 1\n");
}

// -------------------------------------------------------------------
// Messages

PROTOBUF_NOINLINE static void GenerateSyntheticOneofs(
    DescriptorProto* message) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter GenerateSyntheticOneofs 1\n");
  // Add synthetic one-field oneofs for optional fields, except messages which
  // already have presence in proto3.
  //
  // We have to make sure the oneof names don't conflict with any other
  // field or oneof.
  absl::flat_hash_set<std::string> names;
  for (const auto& field : message->field()) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter GenerateSyntheticOneofs 2\n");
    names.insert(field.name());
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit GenerateSyntheticOneofs 2\n");
  }
  for (const auto& oneof : message->oneof_decl()) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter GenerateSyntheticOneofs 3\n");
    names.insert(oneof.name());
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit GenerateSyntheticOneofs 3\n");
  }

  for (auto& field : *message->mutable_field()) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter GenerateSyntheticOneofs 4\n");
    if (field.proto3_optional()) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter GenerateSyntheticOneofs 5\n");
      std::string oneof_name = field.name();

      // Prepend 'XXXXX_' until we are no longer conflicting.
      // Avoid prepending a double-underscore because such names are
      // reserved in C++.
      if (oneof_name.empty() || oneof_name[0] != '_') {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter GenerateSyntheticOneofs 6\n");
        oneof_name.insert(0, "_");
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit GenerateSyntheticOneofs 6\n");
      }
      while (names.count(oneof_name) > 0) {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter GenerateSyntheticOneofs 7\n");
        oneof_name.insert(0, "X");
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit GenerateSyntheticOneofs 7\n");
      }

      names.insert(oneof_name);
      field.set_oneof_index(message->oneof_decl_size());
      OneofDescriptorProto* oneof = message->add_oneof_decl();
      oneof->set_name(std::move(oneof_name));
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit GenerateSyntheticOneofs 5\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit GenerateSyntheticOneofs 4\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit GenerateSyntheticOneofs 1\n");
}
bool Parser::ParseMessageDefinition(
    DescriptorProto* message, const SymbolVisibility& visibility,
    const LocationRecorder& message_location,
    const FileDescriptorProto* containing_file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMessageDefinition 1\n");
  const auto undo_depth = absl::MakeCleanup([&] { ++recursion_depth_; });
  if (--recursion_depth_ <= 0) {
    RecordError("Reached maximum recursion limit for nested messages.");
    return false;
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMessageDefinition 1\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMessageDefinition 2\n");
  DO(Consume("message"));
  {
    LocationRecorder location(message_location,
                              DescriptorProto::kNameFieldNumber);
    location.RecordLegacyLocation(message,
                                  DescriptorPool::ErrorCollector::NAME);
    DO(ConsumeIdentifier(message->mutable_name(), "Expected message name."));
  }
  DO(ParseMessageBlock(message, message_location, containing_file));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMessageDefinition 2\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMessageDefinition 3\n");
  if (syntax_identifier_ == "proto3") {
    GenerateSyntheticOneofs(message);
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMessageDefinition 3\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMessageDefinition 4\n");
  if (visibility != SymbolVisibility::VISIBILITY_UNSET) {
    message->set_visibility(visibility);
  }

  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMessageDefinition 4\n");
}

namespace {

const int kMaxRangeSentinel = -1;

bool IsMessageSetWireFormatMessage(const DescriptorProto& message) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter IsMessageSetWireFormatMessage 1\n");
  const MessageOptions& options = message.options();
  for (int i = 0; i < options.uninterpreted_option_size(); ++i) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter IsMessageSetWireFormatMessage 2\n");
    const UninterpretedOption& uninterpreted = options.uninterpreted_option(i);
    if (uninterpreted.name_size() == 1 &&
        !uninterpreted.name(0).is_extension() &&
        uninterpreted.name(0).name_part() == "message_set_wire_format" &&
        uninterpreted.identifier_value() == "true") {
      return true;
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit IsMessageSetWireFormatMessage 2\n");
  }
  return false;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit IsMessageSetWireFormatMessage 1\n");
}

// Modifies any extension ranges that specified 'max' as the end of the
// extension range, and sets them to the type-specific maximum. The actual max
// tag number can only be determined after all options have been parsed.
void AdjustExtensionRangesWithMaxEndNumber(DescriptorProto* message) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter AdjustExtensionRangesWithMaxEndNumber 1\n");
  const bool is_message_set = IsMessageSetWireFormatMessage(*message);
  const int max_extension_number = is_message_set
                                       ? std::numeric_limits<int32_t>::max()
                                       : FieldDescriptor::kMaxNumber + 1;
  for (int i = 0; i < message->extension_range_size(); ++i) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter AdjustExtensionRangesWithMaxEndNumber 2\n");
    if (message->extension_range(i).end() == kMaxRangeSentinel) {
      message->mutable_extension_range(i)->set_end(max_extension_number);
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit AdjustExtensionRangesWithMaxEndNumber 2\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit AdjustExtensionRangesWithMaxEndNumber 1\n");
}

// Modifies any reserved ranges that specified 'max' as the end of the
// reserved range, and sets them to the type-specific maximum. The actual max
// tag number can only be determined after all options have been parsed.
void AdjustReservedRangesWithMaxEndNumber(DescriptorProto* message) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter AdjustReservedRangesWithMaxEndNumber 1\n");
  const bool is_message_set = IsMessageSetWireFormatMessage(*message);
  const int max_field_number = is_message_set
                                   ? std::numeric_limits<int32_t>::max()
                                   : FieldDescriptor::kMaxNumber + 1;
  for (int i = 0; i < message->reserved_range_size(); ++i) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter AdjustReservedRangesWithMaxEndNumber 2\n");
    if (message->reserved_range(i).end() == kMaxRangeSentinel) {
      message->mutable_reserved_range(i)->set_end(max_field_number);
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit AdjustReservedRangesWithMaxEndNumber 2\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit AdjustReservedRangesWithMaxEndNumber 1\n");
}

}  // namespace

bool Parser::ParseMessageBlock(DescriptorProto* message,
                               const LocationRecorder& message_location,
                               const FileDescriptorProto* containing_file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMessageBlock 1\n");
  DO(ConsumeEndOfDeclaration("{", &message_location));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMessageBlock 1\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMessageBlock 2\n");
  while (!TryConsumeEndOfDeclaration("}", nullptr)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMessageBlock 3\n");
    if (AtEnd()) {
      RecordError("Reached end of input in message definition (missing '}').");
      return false;
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMessageBlock 3\n");

    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMessageBlock 4\n");
    if (!ParseMessageStatement(message, message_location, containing_file)) {
      // This statement failed to parse.  Skip it, but keep looping to parse
      // other statements.
      SkipStatement();
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMessageBlock 4\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMessageBlock 2\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMessageBlock 5\n");
  if (message->extension_range_size() > 0) {
    AdjustExtensionRangesWithMaxEndNumber(message);
  }
  if (message->reserved_range_size() > 0) {
    AdjustReservedRangesWithMaxEndNumber(message);
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMessageBlock 5\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMessageBlock 6\n");
  DO(ValidateMessage(message));

  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMessageBlock 6\n");
}

bool Parser::ParseMessageStatement(DescriptorProto* message,
                                   const LocationRecorder& message_location,
                                   const FileDescriptorProto* containing_file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMessageStatement 1\n");
  if (TryConsumeEndOfDeclaration(";", nullptr)) {
    // empty statement; ignore
    return true;
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMessageStatement 1\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMessageStatement 2\n");
  SymbolVisibility visibility = SymbolVisibility::VISIBILITY_UNSET;
  if (LookingAt("export") || LookingAt("local")) {
    DO(ParseVisibility(containing_file, &visibility));
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMessageStatement 2\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMessageStatement 3\n");
  if (LookingAt("message")) {
    LocationRecorder location(message_location,
                              DescriptorProto::kNestedTypeFieldNumber,
                              message->nested_type_size());
    return ParseMessageDefinition(message->add_nested_type(), visibility,
                                  location, containing_file);
  } else if (LookingAt("enum")) {
    LocationRecorder location(message_location,
                              DescriptorProto::kEnumTypeFieldNumber,
                              message->enum_type_size());
    return ParseEnumDefinition(message->add_enum_type(), visibility, location,
                               containing_file);
  } else if (LookingAt("extensions")) {
    LocationRecorder location(message_location,
                              DescriptorProto::kExtensionRangeFieldNumber);
    return ParseExtensions(message, location, containing_file);
  } else if (LookingAt("reserved")) {
    return ParseReserved(message, message_location);
  } else if (LookingAt("extend")) {
    LocationRecorder location(message_location,
                              DescriptorProto::kExtensionFieldNumber);
    return ParseExtend(message->mutable_extension(),
                       message->mutable_nested_type(), message_location,
                       DescriptorProto::kNestedTypeFieldNumber, location,
                       containing_file);
  } else if (LookingAt("option")) {
    LocationRecorder location(message_location,
                              DescriptorProto::kOptionsFieldNumber);
    return ParseOption(message->mutable_options(), location, containing_file,
                       OPTION_STATEMENT);
  } else if (LookingAt("oneof")) {
    int oneof_index = message->oneof_decl_size();
    LocationRecorder oneof_location(
        message_location, DescriptorProto::kOneofDeclFieldNumber, oneof_index);

    return ParseOneof(message->add_oneof_decl(), message, oneof_index,
                      oneof_location, message_location, containing_file);
  } else {
    LocationRecorder location(message_location,
                              DescriptorProto::kFieldFieldNumber,
                              message->field_size());
    return ParseMessageField(
        message->add_field(), message->mutable_nested_type(), message_location,
        DescriptorProto::kNestedTypeFieldNumber, location, containing_file);
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMessageStatement 3\n");
}

bool Parser::ParseMessageField(FieldDescriptorProto* field,
                               RepeatedPtrField<DescriptorProto>* messages,
                               const LocationRecorder& parent_location,
                               int location_field_number_for_nested_type,
                               const LocationRecorder& field_location,
                               const FileDescriptorProto* containing_file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMessageField 1\n");
  {
    FieldDescriptorProto::Label label;
    if (ParseLabel(&label, field_location)) {
      field->set_label(label);
      if (label == FieldDescriptorProto::LABEL_OPTIONAL &&
          syntax_identifier_ == "proto3") {
        field->set_proto3_optional(true);
      }
    }
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMessageField 1\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMessageField 2\n");
  return ParseMessageFieldNoLabel(field, messages, parent_location,
                                  location_field_number_for_nested_type,
                                  field_location, containing_file);
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMessageField 2\n");
}

bool Parser::ParseMessageFieldNoLabel(
    FieldDescriptorProto* field, RepeatedPtrField<DescriptorProto>* messages,
    const LocationRecorder& parent_location,
    int location_field_number_for_nested_type,
    const LocationRecorder& field_location,
    const FileDescriptorProto* containing_file) {
  fprintf(stderr, "\n");
  MapField map_field;
  // Parse type.
  {
    LocationRecorder location(field_location);  // add path later
    location.RecordLegacyLocation(field, DescriptorPool::ErrorCollector::TYPE);

    bool type_parsed = false;
    FieldDescriptorProto::Type type = FieldDescriptorProto::TYPE_INT32;
    std::string type_name;

    // Special case map field. We only treat the field as a map field if the
    // field type name starts with the word "map" with a following "<".
    if (TryConsume("map")) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMessageFieldNoLabel 2\n");
      if (LookingAt("<")) {
        map_field.is_map_field = true;
        DO(ParseMapType(&map_field, field, location));
      } else {
        // False positive
        type_parsed = true;
        type_name = "map";
      }
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMessageFieldNoLabel 2\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMessageFieldNoLabel 3\n");
    if (!map_field.is_map_field) {
      // Handle the case where no explicit label is given for a non-map field.
      if (!field->has_label() && DefaultToOptionalFields()) {
        field->set_label(FieldDescriptorProto::LABEL_OPTIONAL);
      }
      if (!field->has_label()) {
        RecordError("Expected \"required\", \"optional\", or \"repeated\".");
        // We can actually reasonably recover here by just assuming the user
        // forgot the label altogether.
        field->set_label(FieldDescriptorProto::LABEL_OPTIONAL);
      }

      // Handle the case where the actual type is a message or enum named
      // "map", which we already consumed in the code above.
      if (!type_parsed) {
        DO(ParseType(&type, &type_name));
      }
      if (type_name.empty()) {
        location.AddPath(FieldDescriptorProto::kTypeFieldNumber);
        field->set_type(type);
      } else {
        location.AddPath(FieldDescriptorProto::kTypeNameFieldNumber);
        field->set_type_name(type_name);
      }
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMessageFieldNoLabel 3\n");
  }

  // Parse name and '='.
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMessageFieldNoLabel 4\n");
  io::Tokenizer::Token name_token = input_->current();
  {
    LocationRecorder location(field_location,
                              FieldDescriptorProto::kNameFieldNumber);
    location.RecordLegacyLocation(field, DescriptorPool::ErrorCollector::NAME);
    DO(ConsumeIdentifier(field->mutable_name(), "Expected field name."));
  }
  DO(Consume("=", "Missing field number."));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMessageFieldNoLabel 4\n");

  // Parse field number.
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMessageFieldNoLabel 5\n");
  {
    LocationRecorder location(field_location,
                              FieldDescriptorProto::kNumberFieldNumber);
    location.RecordLegacyLocation(field,
                                  DescriptorPool::ErrorCollector::NUMBER);
    int number;
    DO(ConsumeInteger(&number, "Expected field number."));
    field->set_number(number);
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMessageFieldNoLabel 5\n");

  // Parse options.
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMessageFieldNoLabel 6\n");
  DO(ParseFieldOptions(field, field_location, containing_file));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMessageFieldNoLabel 6\n");

  // Deal with groups.
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMessageFieldNoLabel 7\n");
  if (field->has_type() && field->type() == FieldDescriptorProto::TYPE_GROUP) {
    // Awkward:  Since a group declares both a message type and a field, we
    //   have to create overlapping locations.
    LocationRecorder group_location(parent_location);
    group_location.StartAt(field_location);
    group_location.AddPath(location_field_number_for_nested_type);
    group_location.AddPath(messages->size());

    DescriptorProto* group = messages->Add();
    group->set_name(field->name());

    // Record name location to match the field name's location.
    {
      LocationRecorder location(group_location,
                                DescriptorProto::kNameFieldNumber);
      location.StartAt(name_token);
      location.EndAt(name_token);
      location.RecordLegacyLocation(group,
                                    DescriptorPool::ErrorCollector::NAME);
    }

    // The field's type_name also comes from the name.  Confusing!
    {
      LocationRecorder location(field_location,
                                FieldDescriptorProto::kTypeNameFieldNumber);
      location.StartAt(name_token);
      location.EndAt(name_token);
    }

    // As a hack for backwards-compatibility, we force the group name to start
    // with a capital letter and lower-case the field name.  New code should
    // not use groups; it should use nested messages.
    if (group->name()[0] < 'A' || 'Z' < group->name()[0]) {
      RecordError(name_token.line, name_token.column,
                  "Group names must start with a capital letter.");
    }
    absl::AsciiStrToLower(field->mutable_name());

    field->set_type_name(group->name());
    if (LookingAt("{")) {
      DO(ParseMessageBlock(group, group_location, containing_file));
    } else {
      RecordError("Missing group body.");
      return false;
    }
  } else {
    DO(ConsumeEndOfDeclaration(";", &field_location));
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMessageFieldNoLabel 7\n");

  // Create a map entry type if this is a map field.
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMessageFieldNoLabel 8\n");
  if (map_field.is_map_field) {
    GenerateMapEntry(map_field, field, messages);
  }

  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMessageFieldNoLabel 8\n");
}

bool Parser::ParseMapType(MapField* map_field, FieldDescriptorProto* field,
                          LocationRecorder& type_name_location) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMapType 1\n");
  if (field->has_oneof_index()) {
    RecordError("Map fields are not allowed in oneofs.");
    return false;
  }
  if (field->has_label()) {
    RecordError(
        "Field labels (required/optional/repeated) are not allowed on "
        "map fields.");
    return false;
  }
  if (field->has_extendee()) {
    RecordError("Map fields are not allowed to be extensions.");
    return false;
  }
  field->set_label(FieldDescriptorProto::LABEL_REPEATED);
  DO(Consume("<"));
  DO(ParseType(&map_field->key_type, &map_field->key_type_name));
  DO(Consume(","));
  DO(ParseType(&map_field->value_type, &map_field->value_type_name));
  DO(Consume(">"));
  // Defer setting of the type name of the map field until the
  // field name is parsed. Add the source location though.
  type_name_location.AddPath(FieldDescriptorProto::kTypeNameFieldNumber);
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMapType 1\n");
}

void Parser::GenerateMapEntry(const MapField& map_field,
                              FieldDescriptorProto* field,
                              RepeatedPtrField<DescriptorProto>* messages) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::GenerateMapEntry 1\n");
  DescriptorProto* entry = messages->Add();
  std::string entry_name = MapEntryName(field->name());
  field->set_type_name(entry_name);
  entry->set_name(entry_name);
  entry->mutable_options()->set_map_entry(true);
  FieldDescriptorProto* key_field = entry->add_field();
  key_field->set_name("key");
  key_field->set_label(FieldDescriptorProto::LABEL_OPTIONAL);
  key_field->set_number(1);
  if (map_field.key_type_name.empty()) {
    key_field->set_type(map_field.key_type);
  } else {
    key_field->set_type_name(map_field.key_type_name);
  }
  FieldDescriptorProto* value_field = entry->add_field();
  value_field->set_name("value");
  value_field->set_label(FieldDescriptorProto::LABEL_OPTIONAL);
  value_field->set_number(2);
  if (map_field.value_type_name.empty()) {
    value_field->set_type(map_field.value_type);
  } else {
    value_field->set_type_name(map_field.value_type_name);
  }
  // Propagate all features to the generated key and value fields. This helps
  // simplify the implementation of code generators and also reflection-based
  // parsing code. Instead of having to implement complex inheritance rules
  // special-casing maps, we can just copy them at generation time.
  //
  // The following definition:
  //   message Foo {
  //     map<string, string> value = 1 [features.some_feature = VALUE];
  //   }
  // will be interpreted as:
  //   message Foo {
  //     message ValueEntry {
  //       option map_entry = true;
  //       string key = 1 [features.some_feature = VALUE];
  //       string value = 2 [features.some_feature = VALUE];
  //     }
  //     repeated ValueEntry value = 1 [features.some_feature = VALUE];
  //  }
  for (int i = 0; i < field->options().uninterpreted_option_size(); ++i) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::GenerateMapEntry 2\n");
    const UninterpretedOption& option =
        field->options().uninterpreted_option(i);
    // Legacy handling for the `enforce_utf8` option, which bears a striking
    // similarity to features in many respects.
    // TODO Delete this once proto2/proto3 have been turned down.
    if (option.name_size() == 1 &&
        option.name(0).name_part() == "enforce_utf8" &&
        !option.name(0).is_extension()) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::GenerateMapEntry 3\n");
      if (key_field->type() == FieldDescriptorProto::TYPE_STRING) {
        *key_field->mutable_options()->add_uninterpreted_option() = option;
      }
      if (value_field->type() == FieldDescriptorProto::TYPE_STRING) {
        *value_field->mutable_options()->add_uninterpreted_option() = option;
      }
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::GenerateMapEntry 3\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::GenerateMapEntry 4\n");
    if (option.name(0).name_part() == "features" &&
        !option.name(0).is_extension()) {
      *key_field->mutable_options()->add_uninterpreted_option() = option;
      *value_field->mutable_options()->add_uninterpreted_option() = option;
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::GenerateMapEntry 4\n");
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::GenerateMapEntry 2\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::GenerateMapEntry 1\n");
}

bool Parser::ParseFieldOptions(FieldDescriptorProto* field,
                               const LocationRecorder& field_location,
                               const FileDescriptorProto* containing_file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseFieldOptions 1\n");
  if (!LookingAt("[")) return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseFieldOptions 1\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseFieldOptions 2\n");
  LocationRecorder location(field_location,
                            FieldDescriptorProto::kOptionsFieldNumber);

  DO(Consume("["));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseFieldOptions 2\n");

  // Parse field options.
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseFieldOptions 3\n");
  do {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseFieldOptions 4\n");
    if (LookingAt("default")) {
      // We intentionally pass field_location rather than location here, since
      // the default value is not actually an option.
      DO(ParseDefaultAssignment(field, field_location, containing_file));
    } else if (LookingAt("json_name")) {
      // Like default value, this "json_name" is not an actual option.
      DO(ParseJsonName(field, field_location, containing_file));
    } else {
      DO(ParseOption(field->mutable_options(), location, containing_file,
                     OPTION_ASSIGNMENT));
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseFieldOptions 4\n");
  } while (TryConsume(","));

  DO(Consume("]"));
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseFieldOptions 3\n");
}

bool Parser::ParseDefaultAssignment(
    FieldDescriptorProto* field, const LocationRecorder& field_location,
    const FileDescriptorProto* containing_file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseDefaultAssignment 1\n");
  if (field->has_default_value()) {
    RecordError("Already set option \"default\".");
    field->clear_default_value();
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseDefaultAssignment 1\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseDefaultAssignment 2\n");
  DO(Consume("default"));
  DO(Consume("="));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseDefaultAssignment 2\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseDefaultAssignment 3\n");
  LocationRecorder location(field_location,
                            FieldDescriptorProto::kDefaultValueFieldNumber);
  location.RecordLegacyLocation(field,
                                DescriptorPool::ErrorCollector::DEFAULT_VALUE);
  std::string* default_value = field->mutable_default_value();
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseDefaultAssignment 3\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseDefaultAssignment 4\n");
  if (!field->has_type()) {
    // The field has a type name, but we don't know if it is a message or an
    // enum yet. (If it were a primitive type, |field| would have a type set
    // already.) In this case, simply take the current string as the default
    // value; we will catch the error later if it is not a valid enum value.
    // (N.B. that we do not check whether the current token is an identifier:
    // doing so throws strange errors when the user mistypes a primitive
    // typename and we assume it's an enum. E.g.: "optional int foo = 1 [default
    // = 42]". In such a case the fundamental error is really that "int" is not
    // a type, not that "42" is not an identifier. See b/12533582.)
    *default_value = input_->current().text;
    input_->Next();
    return true;
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseDefaultAssignment 4\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseDefaultAssignment 5\n");
  switch (field->type()) {
    case FieldDescriptorProto::TYPE_INT32:
    case FieldDescriptorProto::TYPE_INT64:
    case FieldDescriptorProto::TYPE_SINT32:
    case FieldDescriptorProto::TYPE_SINT64:
    case FieldDescriptorProto::TYPE_SFIXED32:
    case FieldDescriptorProto::TYPE_SFIXED64: {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseDefaultAssignment 6\n");
      uint64_t max_value = std::numeric_limits<int64_t>::max();
      if (field->type() == FieldDescriptorProto::TYPE_INT32 ||
          field->type() == FieldDescriptorProto::TYPE_SINT32 ||
          field->type() == FieldDescriptorProto::TYPE_SFIXED32) {
        max_value = std::numeric_limits<int32_t>::max();
      }

      // These types can be negative.
      if (TryConsume("-")) {
        default_value->append("-");
        // Two's complement always has one more negative value than positive.
        ++max_value;
      }
      // Parse the integer to verify that it is not out-of-range.
      uint64_t value;
      DO(ConsumeInteger64(max_value, &value,
                          "Expected integer for field default value."));
      // And stringify it again.
      default_value->append(absl::StrCat(value));
      break;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseDefaultAssignment 6\n");
    }

    case FieldDescriptorProto::TYPE_UINT32:
    case FieldDescriptorProto::TYPE_UINT64:
    case FieldDescriptorProto::TYPE_FIXED32:
    case FieldDescriptorProto::TYPE_FIXED64: {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseDefaultAssignment 7\n");
      uint64_t max_value = std::numeric_limits<uint64_t>::max();
      if (field->type() == FieldDescriptorProto::TYPE_UINT32 ||
          field->type() == FieldDescriptorProto::TYPE_FIXED32) {
        max_value = std::numeric_limits<uint32_t>::max();
      }

      // Numeric, not negative.
      if (TryConsume("-")) {
        RecordError("Unsigned field can't have negative default value.");
      }
      // Parse the integer to verify that it is not out-of-range.
      uint64_t value;
      DO(ConsumeInteger64(max_value, &value,
                          "Expected integer for field default value."));
      // And stringify it again.
      default_value->append(absl::StrCat(value));
      break;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseDefaultAssignment 7\n");
    }

    case FieldDescriptorProto::TYPE_FLOAT:
    case FieldDescriptorProto::TYPE_DOUBLE: {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseDefaultAssignment 8\n");
      // These types can be negative.
      if (TryConsume("-")) {
        default_value->append("-");
      }
      // Parse the integer because we have to convert hex integers to decimal
      // floats.
      double value = 0.0;
      DO(ConsumeNumber(&value, "Expected number."));
      // And stringify it again.
      default_value->append(io::SimpleDtoa(value));
      break;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseDefaultAssignment 8\n");
    }
    case FieldDescriptorProto::TYPE_BOOL:
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseDefaultAssignment 9\n");
      if (TryConsume("true")) {
        default_value->assign("true");
      } else if (TryConsume("false")) {
        default_value->assign("false");
      } else {
        RecordError("Expected \"true\" or \"false\".");
        return false;
      }
      break;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseDefaultAssignment 9\n");

    case FieldDescriptorProto::TYPE_STRING:
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseDefaultAssignment 10\n");
      // Note: When file option java_string_check_utf8 is true, if a
      // non-string representation (eg byte[]) is later supported, it must
      // be checked for UTF-8-ness.
      DO(ConsumeString(default_value,
                       "Expected string for field default "
                       "value."));
      break;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseDefaultAssignment 10\n");

    case FieldDescriptorProto::TYPE_BYTES:
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseDefaultAssignment 11\n");
      DO(ConsumeString(default_value, "Expected string."));
      *default_value = absl::CEscape(*default_value);
      break;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseDefaultAssignment 11\n");

    case FieldDescriptorProto::TYPE_ENUM:
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseDefaultAssignment 12\n");
      DO(ConsumeIdentifier(default_value,
                           "Expected enum identifier for field "
                           "default value."));
      break;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseDefaultAssignment 12\n");

    case FieldDescriptorProto::TYPE_MESSAGE:
    case FieldDescriptorProto::TYPE_GROUP:
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseDefaultAssignment 13\n");
      RecordError("Messages can't have default values.");
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseDefaultAssignment 13\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseDefaultAssignment 5\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseDefaultAssignment 14\n");
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseDefaultAssignment 14\n");
}

bool Parser::ParseJsonName(FieldDescriptorProto* field,
                           const LocationRecorder& field_location,
                           const FileDescriptorProto* containing_file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseJsonName 1\n");
  if (field->has_json_name()) {
    RecordError("Already set option \"json_name\".");
    field->clear_json_name();
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseJsonName 1\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseJsonName 2\n");
  LocationRecorder location(field_location,
                            FieldDescriptorProto::kJsonNameFieldNumber);
  location.RecordLegacyLocation(field,
                                DescriptorPool::ErrorCollector::OPTION_NAME);
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseJsonName 2\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseJsonName 3\n");
  DO(Consume("json_name"));
  DO(Consume("="));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseJsonName 3\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseJsonName 4\n");
  LocationRecorder value_location(location);
  value_location.RecordLegacyLocation(
      field, DescriptorPool::ErrorCollector::OPTION_VALUE);
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseJsonName 4\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseJsonName 5\n");
  DO(ConsumeString(field->mutable_json_name(),
                   "Expected string for JSON name."));
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseJsonName 5\n");
}

bool Parser::ParseOptionNamePart(UninterpretedOption* uninterpreted_option,
                                 const LocationRecorder& part_location,
                                 const FileDescriptorProto* containing_file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseOptionNamePart 1\n");
  UninterpretedOption::NamePart* name = uninterpreted_option->add_name();
  std::string identifier;  // We parse identifiers into this string.
  if (LookingAt("(")) {    // This is an extension.
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseOptionNamePart 2\n");
    DO(Consume("("));

    {
      LocationRecorder location(
          part_location, UninterpretedOption::NamePart::kNamePartFieldNumber);
      // An extension name consists of dot-separated identifiers, and may begin
      // with a dot.
      if (LookingAtType(io::Tokenizer::TYPE_IDENTIFIER)) {
        DO(ConsumeIdentifier(&identifier, "Expected identifier."));
        name->mutable_name_part()->append(identifier);
      }
      while (LookingAt(".")) {
        DO(Consume("."));
        name->mutable_name_part()->append(".");
        DO(ConsumeIdentifier(&identifier, "Expected identifier."));
        name->mutable_name_part()->append(identifier);
      }
    }

    DO(Consume(")"));
    name->set_is_extension(true);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseOptionNamePart 2\n");
  } else {  // This is a regular field.
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseOptionNamePart 3\n");
    LocationRecorder location(
        part_location, UninterpretedOption::NamePart::kNamePartFieldNumber);
    DO(ConsumeIdentifier(&identifier, "Expected identifier."));
    name->mutable_name_part()->append(identifier);
    name->set_is_extension(false);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseOptionNamePart 3\n");
  }
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseOptionNamePart 1\n");
}

bool Parser::ParseUninterpretedBlock(std::string* value) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseUninterpretedBlock 1\n");
  // Note that enclosing braces are not added to *value.
  // We do NOT use ConsumeEndOfStatement for this brace because it's delimiting
  // an expression, not a block of statements.
  DO(Consume("{"));
  int brace_depth = 1;
  while (!AtEnd()) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseUninterpretedBlock 2\n");
    if (LookingAt("{")) {
      brace_depth++;
    } else if (LookingAt("}")) {
      brace_depth--;
      if (brace_depth == 0) {
        input_->Next();
        return true;
      }
    }
    // TODO: Interpret line/column numbers to preserve formatting
    if (!value->empty()) value->push_back(' ');
    value->append(input_->current().text);
    input_->Next();
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseUninterpretedBlock 2\n");
  }
  RecordError("Unexpected end of stream while parsing aggregate value.");
  return false;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseUninterpretedBlock 1\n");
}
// We don't interpret the option here. Instead we store it in an
// UninterpretedOption, to be interpreted later.
bool Parser::ParseOption(Message* options,
                         const LocationRecorder& options_location,
                         const FileDescriptorProto* containing_file,
                         OptionStyle style) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 1\n");
  // Create an entry in the uninterpreted_option field.
  const FieldDescriptor* uninterpreted_option_field =
      options->GetDescriptor()->FindFieldByName("uninterpreted_option");
  ABSL_CHECK(uninterpreted_option_field != nullptr)
      << "No field named \"uninterpreted_option\" in the Options proto.";

  const Reflection* reflection = options->GetReflection();

  LocationRecorder location(
      options_location, uninterpreted_option_field->number(),
      reflection->FieldSize(*options, uninterpreted_option_field));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 1\n");

  if (style == OPTION_STATEMENT) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 2\n");
    DO(Consume("option"));
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 2\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 3\n");
  UninterpretedOption* uninterpreted_option =
      DownCastMessage<UninterpretedOption>(options->GetReflection()->AddMessage(
          options, uninterpreted_option_field));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 3\n");

  // Parse dot-separated name.
  {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 4\n");
    LocationRecorder name_location(location,
                                   UninterpretedOption::kNameFieldNumber);
    name_location.RecordLegacyLocation(
        uninterpreted_option, DescriptorPool::ErrorCollector::OPTION_NAME);

    {
      LocationRecorder part_location(name_location,
                                     uninterpreted_option->name_size());
      DO(ParseOptionNamePart(uninterpreted_option, part_location,
                             containing_file));
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 4\n");

    while (LookingAt(".")) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 5\n");
      DO(Consume("."));
      LocationRecorder part_location(name_location,
                                     uninterpreted_option->name_size());
      DO(ParseOptionNamePart(uninterpreted_option, part_location,
                             containing_file));
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 5\n");
    }
  }

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 6\n");
  DO(Consume("="));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 6\n");

  {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 7\n");
    LocationRecorder value_location(location);
    value_location.RecordLegacyLocation(
        uninterpreted_option, DescriptorPool::ErrorCollector::OPTION_VALUE);

    // All values are a single token, except for negative numbers, which consist
    // of a single '-' symbol, followed by a positive number.
    bool is_negative = TryConsume("-");
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 7\n");

    switch (input_->current().type) {
      case io::Tokenizer::TYPE_START:
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 8\n");
        ABSL_LOG(FATAL)
            << "Trying to read value before any tokens have been read.";
        return false;
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 8\n");

      case io::Tokenizer::TYPE_END:
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 9\n");
        RecordError("Unexpected end of stream while parsing option value.");
        return false;
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 9\n");

      case io::Tokenizer::TYPE_WHITESPACE:
      case io::Tokenizer::TYPE_NEWLINE:
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 10\n");
        ABSL_CHECK(!input_->report_whitespace() && !input_->report_newlines())
            << "Whitespace tokens were not requested.";
        ABSL_LOG(FATAL) << "Tokenizer reported whitespace.";
        return false;
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 10\n");

      case io::Tokenizer::TYPE_IDENTIFIER: {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 11\n");
        value_location.AddPath(
            UninterpretedOption::kIdentifierValueFieldNumber);
        std::string value;
        DO(ConsumeIdentifier(&value, "Expected identifier."));
        if (is_negative) {
          if (value == "inf") {
            fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 12\n");
            uninterpreted_option->set_double_value(
                -std::numeric_limits<double>::infinity());
            fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 12\n");
          } else if (value == "nan") {
            fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 13\n");
            uninterpreted_option->set_double_value(
                std::numeric_limits<double>::quiet_NaN());
            fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 13\n");
          } else {
            fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 14\n");
            RecordError("Identifier after '-' symbol must be inf or nan.");
            return false;
            fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 14\n");
          }
          break;
        }
        uninterpreted_option->set_identifier_value(value);
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 11\n");
        break;
      }

      case io::Tokenizer::TYPE_INTEGER: {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 15\n");
        uint64_t value;
        uint64_t max_value =
            is_negative
                ? static_cast<uint64_t>(std::numeric_limits<int64_t>::max()) + 1
                : std::numeric_limits<uint64_t>::max();
        if (TryConsumeInteger64(max_value, &value)) {
          if (is_negative) {
            fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 16\n");
            value_location.AddPath(
                UninterpretedOption::kNegativeIntValueFieldNumber);
            uninterpreted_option->set_negative_int_value(
                static_cast<int64_t>(0 - value));
            fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 16\n");
          } else {
            fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 17\n");
            value_location.AddPath(
                UninterpretedOption::kPositiveIntValueFieldNumber);
            uninterpreted_option->set_positive_int_value(value);
            fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 17\n");
          }
          break;
        }
        // value too large for an integer; fall through below to treat as
        // floating point
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 15\n");
        ABSL_FALLTHROUGH_INTENDED;
      }

      case io::Tokenizer::TYPE_FLOAT: {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 18\n");
        value_location.AddPath(UninterpretedOption::kDoubleValueFieldNumber);
        double value = 0.0;
        DO(ConsumeNumber(&value, "Expected number."));
        uninterpreted_option->set_double_value(is_negative ? -value : value);
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 18\n");
        break;
      }

      case io::Tokenizer::TYPE_STRING: {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 19\n");
        value_location.AddPath(UninterpretedOption::kStringValueFieldNumber);
        if (is_negative) {
          fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 20\n");
          RecordError("Invalid '-' symbol before string.");
          return false;
          fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 20\n");
        }
        std::string value;
        DO(ConsumeString(&value, "Expected string."));
        uninterpreted_option->set_string_value(value);
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 19\n");
        break;
      }

      case io::Tokenizer::TYPE_SYMBOL:
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 21\n");
        if (LookingAt("{")) {
          fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 22\n");
          value_location.AddPath(
              UninterpretedOption::kAggregateValueFieldNumber);
          DO(ParseUninterpretedBlock(
              uninterpreted_option->mutable_aggregate_value()));
          fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 22\n");
        } else {
          fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 23\n");
          RecordError("Expected option value.");
          return false;
          fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 23\n");
        }
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 21\n");
        break;
    }
  }

  if (style == OPTION_STATEMENT) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 24\n");
    DO(ConsumeEndOfDeclaration(";", &location));
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 24\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOption 25\n");
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOption 25\n");
}

bool Parser::ParseExtensions(DescriptorProto* message,
                             const LocationRecorder& extensions_location,
                             const FileDescriptorProto* containing_file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtensions 1\n");
  // Parse the declaration.
  DO(Consume("extensions"));

  int old_range_size = message->extension_range_size();
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtensions 1\n");

  do {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtensions 2\n");
    // Note that kExtensionRangeFieldNumber was already pushed by the parent.
    LocationRecorder location(extensions_location,
                              message->extension_range_size());

    DescriptorProto::ExtensionRange* range = message->add_extension_range();
    location.RecordLegacyLocation(range,
                                  DescriptorPool::ErrorCollector::NUMBER);

    int start, end;
    io::Tokenizer::Token start_token;

    {
      LocationRecorder start_location(
          location, DescriptorProto::ExtensionRange::kStartFieldNumber);
      start_token = input_->current();
      DO(ConsumeInteger(&start, "Expected field number range."));

      if (start == std::numeric_limits<int>::max()) {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtensions 3\n");
        RecordError("Field number out of bounds.");
        return false;
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtensions 3\n");
      }
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtensions 2\n");

    if (TryConsume("to")) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtensions 4\n");
      LocationRecorder end_location(
          location, DescriptorProto::ExtensionRange::kEndFieldNumber);
      if (TryConsume("max")) {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtensions 5\n");
        // Set to the sentinel value - 1 since we increment the value below.
        // The actual value of the end of the range should be set with
        // AdjustExtensionRangesWithMaxEndNumber.
        end = kMaxRangeSentinel - 1;
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtensions 5\n");
      } else {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtensions 6\n");
        DO(ConsumeInteger(&end, "Expected integer."));

        if (end == std::numeric_limits<int>::max()) {
          fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtensions 7\n");
          RecordError("Field number out of bounds.");
          return false;
          fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtensions 7\n");
        }
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtensions 6\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtensions 4\n");
    } else {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtensions 8\n");
      LocationRecorder end_location(
          location, DescriptorProto::ExtensionRange::kEndFieldNumber);
      end_location.StartAt(start_token);
      end_location.EndAt(start_token);
      end = start;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtensions 8\n");
    }

    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtensions 9\n");
    // Users like to specify inclusive ranges, but in code we like the end
    // number to be exclusive.
    ++end;

    range->set_start(start);
    range->set_end(end);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtensions 9\n");
  } while (TryConsume(","));

  if (LookingAt("[")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtensions 10\n");
    int range_number_index = extensions_location.CurrentPathSize();
    SourceCodeInfo info;

    // Parse extension range options in the first range.
    ExtensionRangeOptions* options =
        message->mutable_extension_range(old_range_size)->mutable_options();

    {
      LocationRecorder index_location(
          extensions_location, 0 /* we fill this in w/ actual index below */,
          &info);
      LocationRecorder location(
          index_location, DescriptorProto::ExtensionRange::kOptionsFieldNumber);
      DO(Consume("["));

      do {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtensions 11\n");
        DO(ParseOption(options, location, containing_file, OPTION_ASSIGNMENT));
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtensions 11\n");
      } while (TryConsume(","));

      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtensions 12\n");
      DO(Consume("]"));
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtensions 12\n");
    }

    // Then copy the extension range options to all of the other ranges we've
    // parsed.
    for (int i = old_range_size + 1; i < message->extension_range_size(); i++) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtensions 13\n");
      *message->mutable_extension_range(i)->mutable_options() = *options;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtensions 13\n");
    }
    // and copy source locations to the other ranges, too
    for (int i = old_range_size; i < message->extension_range_size(); i++) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtensions 14\n");
      for (int j = 0; j < info.location_size(); j++) {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtensions 15\n");
        if (info.location(j).path_size() == range_number_index + 1) {
          fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtensions 16\n");
          // this location's path is up to the extension range index, but
          // doesn't include options; so it's redundant with location above
          continue;
          fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtensions 16\n");
        }
        SourceCodeInfo_Location* dest = source_code_info_->add_location();
        *dest = info.location(j);
        dest->set_path(range_number_index, i);
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtensions 15\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtensions 14\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtensions 10\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtensions 17\n");
  DO(ConsumeEndOfDeclaration(";", &extensions_location));
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtensions 17\n");
}

// This is similar to extension range parsing, except that it accepts field
// name literals.
bool Parser::ParseReserved(DescriptorProto* message,
                           const LocationRecorder& message_location) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReserved 1\n");
  io::Tokenizer::Token start_token = input_->current();
  // Parse the declaration.
  DO(Consume("reserved"));
  if (LookingAtType(io::Tokenizer::TYPE_STRING)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReserved 2\n");
    if (syntax_identifier_ == "editions") {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReserved 3\n");
      RecordError(
          "Reserved names must be identifiers in editions, not string "
          "literals.");
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReserved 3\n");
    }
    LocationRecorder location(message_location,
                              DescriptorProto::kReservedNameFieldNumber);
    location.StartAt(start_token);
    return ParseReservedNames(message, location);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReserved 2\n");
  } else if (LookingAtType(io::Tokenizer::TYPE_IDENTIFIER)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReserved 4\n");
    if (syntax_identifier_ != "editions") {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReserved 5\n");
      RecordError(
          "Reserved names must be string literals. (Only editions supports "
          "identifiers.)");
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReserved 5\n");
    }
    LocationRecorder location(message_location,
                              DescriptorProto::kReservedNameFieldNumber);
    location.StartAt(start_token);
    return ParseReservedIdentifiers(message, location);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReserved 4\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReserved 6\n");
    LocationRecorder location(message_location,
                              DescriptorProto::kReservedRangeFieldNumber);
    location.StartAt(start_token);
    return ParseReservedNumbers(message, location);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReserved 6\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReserved 1\n");
}

bool Parser::ParseReservedName(std::string* name, ErrorMaker error_message) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedName 1\n");
  // Capture the position of the token, in case we have to report an
  // error after it is consumed.
  int line = input_->current().line;
  int col = input_->current().column;
  DO(ConsumeString(name, error_message));
  if (!io::Tokenizer::IsIdentifier(*name)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedName 2\n");
    // Before Edition 2023, it was possible to reserve any string literal. This
    // doesn't really make sense if the string literal wasn't a valid
    // identifier, so warn about it here.
    // Note that this warning is also load-bearing for tests that intend to
    // verify warnings work as expected today.
    RecordWarning(line, col, [=] {
      return absl::StrFormat("Reserved name \"%s\" is not a valid identifier.",
                             *name);
    });
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedName 2\n");
  }
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedName 1\n");
}

bool Parser::ParseReservedNames(DescriptorProto* message,
                                const LocationRecorder& parent_location) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedNames 1\n");
  do {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedNames 2\n");
    LocationRecorder location(parent_location, message->reserved_name_size());
    DO(ParseReservedName(message->add_reserved_name(),
                         "Expected field name string literal."));
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedNames 2\n");
  } while (TryConsume(","));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedNames 3\n");
  DO(ConsumeEndOfDeclaration(";", &parent_location));
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedNames 3\n");
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedNames 1\n");
}

bool Parser::ParseReservedIdentifier(std::string* name,
                                     ErrorMaker error_message) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedIdentifier 1\n");
  DO(ConsumeIdentifier(name, error_message));
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedIdentifier 1\n");
}

bool Parser::ParseReservedIdentifiers(DescriptorProto* message,
                                      const LocationRecorder& parent_location) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedIdentifiers 1\n");
  do {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedIdentifiers 2\n");
    LocationRecorder location(parent_location, message->reserved_name_size());
    DO(ParseReservedIdentifier(message->add_reserved_name(),
                               "Expected field name identifier."));
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedIdentifiers 2\n");
  } while (TryConsume(","));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedIdentifiers 3\n");
  DO(ConsumeEndOfDeclaration(";", &parent_location));
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedIdentifiers 3\n");
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedIdentifiers 1\n");
}

bool Parser::ParseReservedNumbers(DescriptorProto* message,
                                  const LocationRecorder& parent_location) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedNumbers 1\n");
  bool first = true;
  do {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedNumbers 2\n");
    LocationRecorder location(parent_location, message->reserved_range_size());

    DescriptorProto::ReservedRange* range = message->add_reserved_range();
    location.RecordLegacyLocation(range,
                                  DescriptorPool::ErrorCollector::NUMBER);
    int start, end;
    io::Tokenizer::Token start_token;
    {
      LocationRecorder start_location(
          location, DescriptorProto::ReservedRange::kStartFieldNumber);
      start_token = input_->current();
      DO(ConsumeInteger(&start, (first ? "Expected field name or number range."
                                       : "Expected field number range.")));
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedNumbers 2\n");

    if (TryConsume("to")) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedNumbers 3\n");
      LocationRecorder end_location(
          location, DescriptorProto::ReservedRange::kEndFieldNumber);
      if (TryConsume("max")) {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedNumbers 4\n");
        // Set to the sentinel value - 1 since we increment the value below.
        // The actual value of the end of the range should be set with
        // AdjustExtensionRangesWithMaxEndNumber.
        end = kMaxRangeSentinel - 1;
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedNumbers 4\n");
      } else {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedNumbers 5\n");
        DO(ConsumeInteger(&end, "Expected integer."));
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedNumbers 5\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedNumbers 3\n");
    } else {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedNumbers 6\n");
      LocationRecorder end_location(
          location, DescriptorProto::ReservedRange::kEndFieldNumber);
      end_location.StartAt(start_token);
      end_location.EndAt(start_token);
      end = start;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedNumbers 6\n");
    }

    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedNumbers 7\n");
    // Users like to specify inclusive ranges, but in code we like the end
    // number to be exclusive.
    ++end;

    range->set_start(start);
    range->set_end(end);
    first = false;
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedNumbers 7\n");
  } while (TryConsume(","));

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedNumbers 8\n");
  DO(ConsumeEndOfDeclaration(";", &parent_location));
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedNumbers 8\n");
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedNumbers 1\n");
}

bool Parser::ParseReserved(EnumDescriptorProto* proto,
                           const LocationRecorder& enum_location) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReserved_Enum 1\n");
  io::Tokenizer::Token start_token = input_->current();
  // Parse the declaration.
  DO(Consume("reserved"));
  if (LookingAtType(io::Tokenizer::TYPE_STRING)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReserved_Enum 2\n");
    if (syntax_identifier_ == "editions") {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReserved_Enum 3\n");
      RecordError(
          "Reserved names must be identifiers in editions, not string "
          "literals.");
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReserved_Enum 3\n");
    }
    LocationRecorder location(enum_location,
                              EnumDescriptorProto::kReservedNameFieldNumber);
    location.StartAt(start_token);
    return ParseReservedNames(proto, location);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReserved_Enum 2\n");
  } else if (LookingAtType(io::Tokenizer::TYPE_IDENTIFIER)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReserved_Enum 4\n");
    if (syntax_identifier_ != "editions") {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReserved_Enum 5\n");
      RecordError(
          "Reserved names must be string literals. (Only editions supports "
          "identifiers.)");
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReserved_Enum 5\n");
    }
    LocationRecorder location(enum_location,
                              EnumDescriptorProto::kReservedNameFieldNumber);
    location.StartAt(start_token);
    return ParseReservedIdentifiers(proto, location);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReserved_Enum 4\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReserved_Enum 6\n");
    LocationRecorder location(enum_location,
                              EnumDescriptorProto::kReservedRangeFieldNumber);
    location.StartAt(start_token);
    return ParseReservedNumbers(proto, location);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReserved_Enum 6\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReserved_Enum 1\n");
}

bool Parser::ParseReservedNames(EnumDescriptorProto* proto,
                                const LocationRecorder& parent_location) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedNames_Enum 1\n");
  do {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedNames_Enum 2\n");
    LocationRecorder location(parent_location, proto->reserved_name_size());
    DO(ParseReservedName(proto->add_reserved_name(),
                         "Expected enum value string literal."));
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedNames_Enum 2\n");
  } while (TryConsume(","));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedNames_Enum 3\n");
  DO(ConsumeEndOfDeclaration(";", &parent_location));
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedNames_Enum 3\n");
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedNames_Enum 1\n");
}

bool Parser::ParseReservedIdentifiers(EnumDescriptorProto* proto,
                                      const LocationRecorder& parent_location) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedIdentifiers_Enum 1\n");
  do {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedIdentifiers_Enum 2\n");
    LocationRecorder location(parent_location, proto->reserved_name_size());
    DO(ParseReservedIdentifier(proto->add_reserved_name(),
                               "Expected enum value identifier."));
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedIdentifiers_Enum 2\n");
  } while (TryConsume(","));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedIdentifiers_Enum 3\n");
  DO(ConsumeEndOfDeclaration(";", &parent_location));
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedIdentifiers_Enum 3\n");
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedIdentifiers_Enum 1\n");
}

bool Parser::ParseReservedNumbers(EnumDescriptorProto* proto,
                                  const LocationRecorder& parent_location) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedNumbers_Enum 1\n");
  bool first = true;
  do {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedNumbers_Enum 2\n");
    LocationRecorder location(parent_location, proto->reserved_range_size());

    EnumDescriptorProto::EnumReservedRange* range = proto->add_reserved_range();
    location.RecordLegacyLocation(range,
                                  DescriptorPool::ErrorCollector::NUMBER);
    int start, end;
    io::Tokenizer::Token start_token;
    {
      LocationRecorder start_location(
          location, EnumDescriptorProto::EnumReservedRange::kStartFieldNumber);
      start_token = input_->current();
      DO(ConsumeSignedInteger(&start,
                              (first ? "Expected enum value or number range."
                                     : "Expected enum number range.")));
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedNumbers_Enum 2\n");

    if (TryConsume("to")) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedNumbers_Enum 3\n");
      LocationRecorder end_location(
          location, EnumDescriptorProto::EnumReservedRange::kEndFieldNumber);
      if (TryConsume("max")) {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedNumbers_Enum 4\n");
        // This is in the enum descriptor path, which doesn't have the message
        // set duality to fix up, so it doesn't integrate with the sentinel.
        end = INT_MAX;
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedNumbers_Enum 4\n");
      } else {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedNumbers_Enum 5\n");
        DO(ConsumeSignedInteger(&end, "Expected integer."));
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedNumbers_Enum 5\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedNumbers_Enum 3\n");
    } else {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedNumbers_Enum 6\n");
      LocationRecorder end_location(
          location, EnumDescriptorProto::EnumReservedRange::kEndFieldNumber);
      end_location.StartAt(start_token);
      end_location.EndAt(start_token);
      end = start;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedNumbers_Enum 6\n");
    }

    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedNumbers_Enum 7\n");
    range->set_start(start);
    range->set_end(end);
    first = false;
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedNumbers_Enum 7\n");
  } while (TryConsume(","));

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseReservedNumbers_Enum 8\n");
  DO(ConsumeEndOfDeclaration(";", &parent_location));
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedNumbers_Enum 8\n");
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseReservedNumbers_Enum 1\n");
}

bool Parser::ParseExtend(RepeatedPtrField<FieldDescriptorProto>* extensions,
                         RepeatedPtrField<DescriptorProto>* messages,
                         const LocationRecorder& parent_location,
                         int location_field_number_for_nested_type,
                         const LocationRecorder& extend_location,
                         const FileDescriptorProto* containing_file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtend 1\n");
  DO(Consume("extend"));

  // Parse the extendee type.
  io::Tokenizer::Token extendee_start = input_->current();
  std::string extendee;
  DO(ParseUserDefinedType(&extendee));
  io::Tokenizer::Token extendee_end = input_->previous();
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtend 1\n");

  // Parse the block.
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtend 2\n");
  DO(ConsumeEndOfDeclaration("{", &extend_location));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtend 2\n");

  bool is_first = true;

  do {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtend 3\n");
    if (AtEnd()) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtend 4\n");
      RecordError("Reached end of input in extend definition (missing '}').");
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtend 4\n");
    }

    // Note that kExtensionFieldNumber was already pushed by the parent.
    LocationRecorder location(extend_location, extensions->size());

    FieldDescriptorProto* field = extensions->Add();

    {
      LocationRecorder extendee_location(
          location, FieldDescriptorProto::kExtendeeFieldNumber);
      extendee_location.StartAt(extendee_start);
      extendee_location.EndAt(extendee_end);

      if (is_first) {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtend 5\n");
        extendee_location.RecordLegacyLocation(
            field, DescriptorPool::ErrorCollector::EXTENDEE);
        is_first = false;
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtend 5\n");
      }
    }

    field->set_extendee(extendee);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtend 3\n");

    if (!ParseMessageField(field, messages, parent_location,
                           location_field_number_for_nested_type, location,
                           containing_file)) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtend 6\n");
      // This statement failed to parse.  Skip it, but keep looping to parse
      // other statements.
      SkipStatement();
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtend 6\n");
    }
  } while (!TryConsumeEndOfDeclaration("}", nullptr));

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseExtend 7\n");
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseExtend 7\n");
}

bool Parser::ParseOneof(OneofDescriptorProto* oneof_decl,
                        DescriptorProto* containing_type, int oneof_index,
                        const LocationRecorder& oneof_location,
                        const LocationRecorder& containing_type_location,
                        const FileDescriptorProto* containing_file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOneof 1\n");
  DO(Consume("oneof"));

  {
    LocationRecorder name_location(oneof_location,
                                   OneofDescriptorProto::kNameFieldNumber);
    DO(ConsumeIdentifier(oneof_decl->mutable_name(), "Expected oneof name."));
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOneof 1\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOneof 2\n");
  DO(ConsumeEndOfDeclaration("{", &oneof_location));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOneof 2\n");

  do {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOneof 3\n");
    if (AtEnd()) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOneof 4\n");
      RecordError("Reached end of input in oneof definition (missing '}').");
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOneof 4\n");
    }

    if (LookingAt("option")) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOneof 5\n");
      LocationRecorder option_location(
          oneof_location, OneofDescriptorProto::kOptionsFieldNumber);
      if (!ParseOption(oneof_decl->mutable_options(), option_location,
                       containing_file, OPTION_STATEMENT)) {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOneof 6\n");
        return false;
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOneof 6\n");
      }
      continue;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOneof 5\n");
    }

    // Print a nice error if the user accidentally tries to place a label
    // on an individual member of a oneof.
    if (LookingAt("required") || LookingAt("optional") ||
        LookingAt("repeated")) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOneof 7\n");
      RecordError(
          "Fields in oneofs must not have labels (required / optional "
          "/ repeated).");
      // We can continue parsing here because we understand what the user
      // meant.  The error report will still make parsing fail overall.
      input_->Next();
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOneof 7\n");
    }

    LocationRecorder field_location(containing_type_location,
                                    DescriptorProto::kFieldFieldNumber,
                                    containing_type->field_size());

    FieldDescriptorProto* field = containing_type->add_field();
    field->set_label(FieldDescriptorProto::LABEL_OPTIONAL);
    field->set_oneof_index(oneof_index);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOneof 3\n");

    if (!ParseMessageFieldNoLabel(field, containing_type->mutable_nested_type(),
                                  containing_type_location,
                                  DescriptorProto::kNestedTypeFieldNumber,
                                  field_location, containing_file)) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOneof 8\n");
      // This statement failed to parse.  Skip it, but keep looping to parse
      // other statements.
      SkipStatement();
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOneof 8\n");
    }
  } while (!TryConsumeEndOfDeclaration("}", nullptr));

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseOneof 9\n");
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseOneof 9\n");
}

// -------------------------------------------------------------------
// Enums

bool Parser::ParseEnumDefinition(EnumDescriptorProto* enum_type,
                                 const SymbolVisibility& visibility,
                                 const LocationRecorder& enum_location,
                                 const FileDescriptorProto* containing_file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumDefinition 1\n");
  DO(Consume("enum"));

  {
    LocationRecorder location(enum_location,
                              EnumDescriptorProto::kNameFieldNumber);
    location.RecordLegacyLocation(enum_type,
                                  DescriptorPool::ErrorCollector::NAME);
    DO(ConsumeIdentifier(enum_type->mutable_name(), "Expected enum name."));
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumDefinition 1\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumDefinition 2\n");
  DO(ParseEnumBlock(enum_type, enum_location, containing_file));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumDefinition 2\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumDefinition 3\n");
  DO(ValidateEnum(enum_type));

  if (visibility != SymbolVisibility::VISIBILITY_UNSET) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumDefinition 4\n");
    enum_type->set_visibility(visibility);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumDefinition 4\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumDefinition 3\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumDefinition 5\n");
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumDefinition 5\n");
}

bool Parser::ParseEnumBlock(EnumDescriptorProto* enum_type,
                            const LocationRecorder& enum_location,
                            const FileDescriptorProto* containing_file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumBlock 1\n");
  DO(ConsumeEndOfDeclaration("{", &enum_location));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumBlock 1\n");

  while (!TryConsumeEndOfDeclaration("}", nullptr)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumBlock 2\n");
    if (AtEnd()) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumBlock 3\n");
      RecordError("Reached end of input in enum definition (missing '}').");
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumBlock 3\n");
    }

    if (!ParseEnumStatement(enum_type, enum_location, containing_file)) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumBlock 4\n");
      // This statement failed to parse.  Skip it, but keep looping to parse
      // other statements.
      SkipStatement();
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumBlock 4\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumBlock 2\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumBlock 5\n");
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumBlock 5\n");
}

bool Parser::ParseEnumStatement(EnumDescriptorProto* enum_type,
                                const LocationRecorder& enum_location,
                                const FileDescriptorProto* containing_file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumStatement 1\n");
  if (TryConsumeEndOfDeclaration(";", nullptr)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumStatement 2\n");
    // empty statement; ignore
    return true;
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumStatement 2\n");
  } else if (LookingAt("option")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumStatement 3\n");
    LocationRecorder location(enum_location,
                              EnumDescriptorProto::kOptionsFieldNumber);
    return ParseOption(enum_type->mutable_options(), location, containing_file,
                       OPTION_STATEMENT);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumStatement 3\n");
  } else if (LookingAt("reserved")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumStatement 4\n");
    return ParseReserved(enum_type, enum_location);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumStatement 4\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumStatement 5\n");
    LocationRecorder location(enum_location,
                              EnumDescriptorProto::kValueFieldNumber,
                              enum_type->value_size());
    return ParseEnumConstant(enum_type->add_value(), location, containing_file);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumStatement 5\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumStatement 1\n");
}

bool Parser::ParseEnumConstant(EnumValueDescriptorProto* enum_value,
                               const LocationRecorder& enum_value_location,
                               const FileDescriptorProto* containing_file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumConstant 1\n");
  // Parse name.
  {
    LocationRecorder location(enum_value_location,
                              EnumValueDescriptorProto::kNameFieldNumber);
    location.RecordLegacyLocation(enum_value,
                                  DescriptorPool::ErrorCollector::NAME);
    DO(ConsumeIdentifier(enum_value->mutable_name(),
                         "Expected enum constant name."));
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumConstant 1\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumConstant 2\n");
  DO(Consume("=", "Missing numeric value for enum constant."));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumConstant 2\n");

  // Parse value.
  {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumConstant 3\n");
    LocationRecorder location(enum_value_location,
                              EnumValueDescriptorProto::kNumberFieldNumber);
    location.RecordLegacyLocation(enum_value,
                                  DescriptorPool::ErrorCollector::NUMBER);

    int number;
    DO(ConsumeSignedInteger(&number, "Expected integer."));
    enum_value->set_number(number);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumConstant 3\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumConstant 4\n");
  DO(ParseEnumConstantOptions(enum_value, enum_value_location,
                              containing_file));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumConstant 4\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumConstant 5\n");
  DO(ConsumeEndOfDeclaration(";", &enum_value_location));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumConstant 5\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumConstant 6\n");
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumConstant 6\n");
}

bool Parser::ParseEnumConstantOptions(
    EnumValueDescriptorProto* value,
    const LocationRecorder& enum_value_location,
    const FileDescriptorProto* containing_file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumConstantOptions 1\n");
  if (!LookingAt("[")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumConstantOptions 2\n");
    return true;
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumConstantOptions 2\n");
  }

  LocationRecorder location(enum_value_location,
                            EnumValueDescriptorProto::kOptionsFieldNumber);

  DO(Consume("["));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumConstantOptions 1\n");

  do {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumConstantOptions 3\n");
    DO(ParseOption(value->mutable_options(), location, containing_file,
                   OPTION_ASSIGNMENT));
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumConstantOptions 3\n");
  } while (TryConsume(","));

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseEnumConstantOptions 4\n");
  DO(Consume("]"));
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseEnumConstantOptions 4\n");
}

// -------------------------------------------------------------------
// Services

bool Parser::ParseServiceDefinition(
    ServiceDescriptorProto* service, const LocationRecorder& service_location,
    const FileDescriptorProto* containing_file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseServiceDefinition 1\n");
  DO(Consume("service"));

  {
    LocationRecorder location(service_location,
                              ServiceDescriptorProto::kNameFieldNumber);
    location.RecordLegacyLocation(service,
                                  DescriptorPool::ErrorCollector::NAME);
    DO(ConsumeIdentifier(service->mutable_name(), "Expected service name."));
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseServiceDefinition 1\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter ParseServiceDefinition 2\n");
  DO(ParseServiceBlock(service, service_location, containing_file));
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit ParseServiceDefinition 2\n");
}
bool Parser::ParseServiceBlock(ServiceDescriptorProto* service,
                               const LocationRecorder& service_location,
                               const FileDescriptorProto* containing_file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceBlock 1\n");
  DO(ConsumeEndOfDeclaration("{", &service_location));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceBlock 1\n");

  while (!TryConsumeEndOfDeclaration("}", nullptr)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceBlock 2\n");
    if (AtEnd()) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceBlock 3\n");
      RecordError("Reached end of input in service definition (missing '}').");
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceBlock 3\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceBlock 2\n");

    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceBlock 4\n");
    if (!ParseServiceStatement(service, service_location, containing_file)) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceBlock 5\n");
      // This statement failed to parse.  Skip it, but keep looping to parse
      // other statements.
      SkipStatement();
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceBlock 5\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceBlock 4\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceBlock 6\n");
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceBlock 6\n");
}

bool Parser::ParseServiceStatement(ServiceDescriptorProto* service,
                                   const LocationRecorder& service_location,
                                   const FileDescriptorProto* containing_file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceStatement 1\n");
  if (TryConsumeEndOfDeclaration(";", nullptr)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceStatement 2\n");
    // empty statement; ignore
    return true;
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceStatement 2\n");
  } else if (LookingAt("option")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceStatement 3\n");
    LocationRecorder location(service_location,
                              ServiceDescriptorProto::kOptionsFieldNumber);
    return ParseOption(service->mutable_options(), location, containing_file,
                       OPTION_STATEMENT);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceStatement 3\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceStatement 4\n");
    LocationRecorder location(service_location,
                              ServiceDescriptorProto::kMethodFieldNumber,
                              service->method_size());
    return ParseServiceMethod(service->add_method(), location, containing_file);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceStatement 4\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceStatement 1\n");
}

bool Parser::ParseServiceMethod(MethodDescriptorProto* method,
                                const LocationRecorder& method_location,
                                const FileDescriptorProto* containing_file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceMethod 1\n");
  DO(Consume("rpc"));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceMethod 1\n");

  {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceMethod 2\n");
    LocationRecorder location(method_location,
                              MethodDescriptorProto::kNameFieldNumber);
    location.RecordLegacyLocation(method, DescriptorPool::ErrorCollector::NAME);
    DO(ConsumeIdentifier(method->mutable_name(), "Expected method name."));
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceMethod 2\n");
  }

  // Parse input type.
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceMethod 3\n");
  DO(Consume("("));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceMethod 3\n");
  {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceMethod 4\n");
    if (LookingAt("stream")) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceMethod 5\n");
      LocationRecorder location(
          method_location, MethodDescriptorProto::kClientStreamingFieldNumber);
      location.RecordLegacyLocation(method,
                                    DescriptorPool::ErrorCollector::OTHER);
      method->set_client_streaming(true);
      DO(Consume("stream"));
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceMethod 5\n");
    }
    LocationRecorder location(method_location,
                              MethodDescriptorProto::kInputTypeFieldNumber);
    location.RecordLegacyLocation(method,
                                  DescriptorPool::ErrorCollector::INPUT_TYPE);
    DO(ParseUserDefinedType(method->mutable_input_type()));
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceMethod 4\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceMethod 6\n");
  DO(Consume(")"));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceMethod 6\n");

  // Parse output type.
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceMethod 7\n");
  DO(Consume("returns"));
  DO(Consume("("));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceMethod 7\n");
  {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceMethod 8\n");
    if (LookingAt("stream")) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceMethod 9\n");
      LocationRecorder location(
          method_location, MethodDescriptorProto::kServerStreamingFieldNumber);
      location.RecordLegacyLocation(method,
                                    DescriptorPool::ErrorCollector::OTHER);
      DO(Consume("stream"));
      method->set_server_streaming(true);
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceMethod 9\n");
    }
    LocationRecorder location(method_location,
                              MethodDescriptorProto::kOutputTypeFieldNumber);
    location.RecordLegacyLocation(method,
                                  DescriptorPool::ErrorCollector::OUTPUT_TYPE);
    DO(ParseUserDefinedType(method->mutable_output_type()));
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceMethod 8\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceMethod 10\n");
  DO(Consume(")"));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceMethod 10\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceMethod 11\n");
  if (LookingAt("{")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceMethod 12\n");
    // Options!
    DO(ParseMethodOptions(method_location, containing_file,
                          MethodDescriptorProto::kOptionsFieldNumber,
                          method->mutable_options()));
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceMethod 12\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseServiceMethod 13\n");
    DO(ConsumeEndOfDeclaration(";", &method_location));
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceMethod 13\n");
  }

  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseServiceMethod 11\n");
}

bool Parser::ParseMethodOptions(const LocationRecorder& parent_location,
                                const FileDescriptorProto* containing_file,
                                const int optionsFieldNumber,
                                Message* mutable_options) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMethodOptions 1\n");
  // Options!
  ConsumeEndOfDeclaration("{", &parent_location);
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMethodOptions 1\n");
  while (!TryConsumeEndOfDeclaration("}", nullptr)) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMethodOptions 2\n");
    if (AtEnd()) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMethodOptions 3\n");
      RecordError("Reached end of input in method options (missing '}').");
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMethodOptions 3\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMethodOptions 2\n");

    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMethodOptions 4\n");
    if (TryConsumeEndOfDeclaration(";", nullptr)) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMethodOptions 5\n");
      // empty statement; ignore
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMethodOptions 5\n");
    } else {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMethodOptions 6\n");
      LocationRecorder location(parent_location, optionsFieldNumber);
      if (!ParseOption(mutable_options, location, containing_file,
                       OPTION_STATEMENT)) {
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMethodOptions 7\n");
        // This statement failed to parse.  Skip it, but keep looping to
        // parse other statements.
        SkipStatement();
        fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMethodOptions 7\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMethodOptions 6\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMethodOptions 4\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseMethodOptions 8\n");
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseMethodOptions 8\n");
}

// -------------------------------------------------------------------

bool Parser::ParseLabel(FieldDescriptorProto::Label* label,
                        const LocationRecorder& field_location) {
  fprintf(stderr, "\n");
  if (!LookingAt("optional") && !LookingAt("repeated") &&
      !LookingAt("required")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseLabel 2\n");
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseLabel 2\n");
  }
  if (LookingAt("optional") && syntax_identifier_ == "editions") {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseLabel 3\n");
    RecordError(
        "Label \"optional\" is not supported in editions. By default, all "
        "singular fields have presence unless features.field_presence is set.");
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseLabel 3\n");
  }
  if (LookingAt("required") && syntax_identifier_ == "editions") {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseLabel 4\n");
    RecordError(
        "Label \"required\" is not supported in editions, use "
        "features.field_presence = LEGACY_REQUIRED.");
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseLabel 4\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseLabel 5\n");
  LocationRecorder location(field_location,
                            FieldDescriptorProto::kLabelFieldNumber);
  if (TryConsume("optional")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseLabel 6\n");
    *label = FieldDescriptorProto::LABEL_OPTIONAL;
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseLabel 6\n");
  } else if (TryConsume("repeated")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseLabel 7\n");
    *label = FieldDescriptorProto::LABEL_REPEATED;
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseLabel 7\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseLabel 8\n");
    Consume("required");
    *label = FieldDescriptorProto::LABEL_REQUIRED;
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseLabel 8\n");
  }
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseLabel 5\n");
}

bool Parser::ParseType(FieldDescriptorProto::Type* type,
                       std::string* type_name) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseType 1\n");
  const auto& type_names_table = GetTypeNameTable();
  auto iter = type_names_table.find(input_->current().text);
  if (iter != type_names_table.end()) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseType 2\n");
    if (syntax_identifier_ == "editions" &&
        iter->second == FieldDescriptorProto::TYPE_GROUP) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseType 3\n");
      RecordError(
          "Group syntax is no longer supported in editions. To get group "
          "behavior you can specify features.message_encoding = DELIMITED on a "
          "message field.");
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseType 3\n");
    }
    *type = iter->second;
    input_->Next();
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseType 2\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseType 4\n");
    DO(ParseUserDefinedType(type_name));
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseType 4\n");
  }
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseType 1\n");
}

bool Parser::ParseUserDefinedType(std::string* type_name) {
  fprintf(stderr, "\n");
  type_name->clear();

  const auto& type_names_table = GetTypeNameTable();
  auto iter = type_names_table.find(input_->current().text);
  if (iter != type_names_table.end()) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseUserDefinedType 2\n");
    // Note:  The only place enum types are allowed is for field types, but
    //   if we are parsing a field type then we would not get here because
    //   primitives are allowed there as well.  So this error message doesn't
    //   need to account for enums.
    RecordError("Expected message type.");

    // Pretend to accept this type so that we can go on parsing.
    *type_name = input_->current().text;
    input_->Next();
    return true;
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseUserDefinedType 2\n");
  }

  // A leading "." means the name is fully-qualified.
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseUserDefinedType 3\n");
  if (TryConsume(".")) type_name->append(".");
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseUserDefinedType 3\n");

  // Consume the first part of the name.
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseUserDefinedType 4\n");
  std::string identifier;
  DO(ConsumeIdentifier(&identifier, "Expected type name."));
  type_name->append(identifier);
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseUserDefinedType 4\n");

  // Consume more parts.
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseUserDefinedType 5\n");
  while (TryConsume(".")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseUserDefinedType 6\n");
    type_name->append(".");
    DO(ConsumeIdentifier(&identifier, "Expected identifier."));
    type_name->append(identifier);
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseUserDefinedType 6\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseUserDefinedType 5\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseUserDefinedType 7\n");
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseUserDefinedType 7\n");
}

// ===================================================================

bool Parser::ParsePackage(FileDescriptorProto* file,
                          const LocationRecorder& root_location,
                          const FileDescriptorProto* containing_file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParsePackage 1\n");
  if (file->has_package()) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParsePackage 2\n");
    RecordError("Multiple package definitions.");
    // Don't append the new package to the old one.  Just replace it.  Not
    // that it really matters since this is an error anyway.
    file->clear_package();
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParsePackage 2\n");
  }

  LocationRecorder location(root_location,
                            FileDescriptorProto::kPackageFieldNumber);
  location.RecordLegacyLocation(file, DescriptorPool::ErrorCollector::NAME);

  DO(Consume("package"));
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParsePackage 1\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParsePackage 3\n");
  while (true) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParsePackage 4\n");
    std::string identifier;
    DO(ConsumeIdentifier(&identifier, "Expected identifier."));
    file->mutable_package()->append(identifier);
    if (!TryConsume(".")) break;
    file->mutable_package()->append(".");
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParsePackage 4\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParsePackage 3\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParsePackage 5\n");
  DO(ConsumeEndOfDeclaration(";", &location));

  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParsePackage 5\n");
}

bool Parser::ParseImport(RepeatedPtrField<std::string>* dependency,
                         RepeatedPtrField<std::string>* option_dependency,
                         RepeatedField<int32_t>* public_dependency,
                         RepeatedField<int32_t>* weak_dependency,
                         const LocationRecorder& root_location,
                         const FileDescriptorProto* containing_file) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseImport 1\n");
  io::Tokenizer::Token import_start = input_->current();
  DO(Consume("import"));
  std::string import_file;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseImport 1\n");
  
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseImport 2\n");
  if (LookingAt("option")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseImport 3\n");
    LocationRecorder option_import_location(
        root_location, FileDescriptorProto::kOptionDependencyFieldNumber,
        option_dependency->size());
    option_import_location.StartAt(import_start);
    if (edition_ < Edition::EDITION_2024) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseImport 4\n");
      RecordError("option import is not supported before edition 2024.");
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseImport 4\n");
    }
    DO(Consume("option"));
    DO(ConsumeString(&import_file,
                     "Expected a string naming the file to import."));
    *option_dependency->Add() = import_file;

    option_import_location.RecordLegacyImportLocation(containing_file,
                                                      import_file);
    DO(ConsumeEndOfDeclaration(";", &option_import_location));
    return true;
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseImport 3\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseImport 2\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseImport 5\n");
  LocationRecorder import_location(root_location,
                                   FileDescriptorProto::kDependencyFieldNumber,
                                   dependency->size());
  import_location.StartAt(import_start);
  if (!option_dependency->empty()) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseImport 6\n");
    RecordError(
        "imports should precede any option imports to ensure proto files "
        "can roundtrip.");
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseImport 6\n");
  }
  if (LookingAt("public")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseImport 7\n");
    LocationRecorder public_location(
        root_location, FileDescriptorProto::kPublicDependencyFieldNumber,
        public_dependency->size());
    DO(Consume("public"));
    *public_dependency->Add() = dependency->size();
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseImport 7\n");
  } else if (LookingAt("weak")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseImport 8\n");
    LocationRecorder weak_location(
        root_location, FileDescriptorProto::kWeakDependencyFieldNumber,
        weak_dependency->size());
    weak_location.RecordLegacyImportLocation(containing_file, "weak");
    DO(Consume("weak"));
    *weak_dependency->Add() = dependency->size();
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseImport 8\n");
  }
  DO(ConsumeString(&import_file,
                   "Expected a string naming the file to import."));
  *dependency->Add() = import_file;

  import_location.RecordLegacyImportLocation(containing_file, import_file);
  DO(ConsumeEndOfDeclaration(";", &import_location));
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseImport 5\n");
}

bool Parser::ParseVisibility(const FileDescriptorProto* containing_file,
                             SymbolVisibility* out) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseVisibility 1\n");
  if (containing_file == nullptr || out == nullptr) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseVisibility 2\n");
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseVisibility 2\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseVisibility 1\n");

  // Bail out of visibility checks if < 2024
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseVisibility 3\n");
  if (containing_file->edition() <= Edition::EDITION_2023) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseVisibility 4\n");
    return true;
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseVisibility 4\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseVisibility 3\n");

  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseVisibility 5\n");
  if (TryConsume("export")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseVisibility 6\n");
    *out = SymbolVisibility::VISIBILITY_EXPORT;
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseVisibility 6\n");
  } else if (TryConsume("local")) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseVisibility 7\n");
    *out = SymbolVisibility::VISIBILITY_LOCAL;
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseVisibility 7\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseVisibility 5\n");

  // If we set a visibility make sure it's OK.
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseVisibility 8\n");
  if (*out != SymbolVisibility::VISIBILITY_UNSET) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseVisibility 9\n");
    if (!LookingAt("message") && !LookingAt("enum")) {
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter Parser::ParseVisibility 10\n");
      RecordError(
          "'local' and 'export' visibility modifiers are valid only on "
          "'message' "
          "and 'enum'");
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseVisibility 10\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseVisibility 9\n");
  }

  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit Parser::ParseVisibility 8\n");
}

// ===================================================================

SourceLocationTable::SourceLocationTable() {}
SourceLocationTable::~SourceLocationTable() {}

bool SourceLocationTable::Find(
    const Message* descriptor,
    DescriptorPool::ErrorCollector::ErrorLocation location, int* line,
    int* column) const {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter SourceLocationTable::Find 1\n");
  auto it = location_map_.find({descriptor, location});
  if (it == location_map_.end()) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter SourceLocationTable::Find 2\n");
    *line = -1;
    *column = 0;
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit SourceLocationTable::Find 2\n");
  }
  std::tie(*line, *column) = it->second;
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit SourceLocationTable::Find 1\n");
}

bool SourceLocationTable::FindImport(const Message* descriptor,
                                     absl::string_view name, int* line,
                                     int* column) const {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter SourceLocationTable::FindImport 1\n");
  auto it = import_location_map_.find({descriptor, std::string(name)});
  if (it == import_location_map_.end()) {
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter SourceLocationTable::FindImport 2\n");
    *line = -1;
    *column = 0;
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit SourceLocationTable::FindImport 2\n");
  }
  std::tie(*line, *column) = it->second;
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit SourceLocationTable::FindImport 1\n");
}

void SourceLocationTable::Add(
    const Message* descriptor,
    DescriptorPool::ErrorCollector::ErrorLocation location, int line,
    int column) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter SourceLocationTable::Add 1\n");
  location_map_[std::make_pair(descriptor, location)] =
      std::make_pair(line, column);
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit SourceLocationTable::Add 1\n");
}

void SourceLocationTable::AddImport(const Message* descriptor,
                                    const std::string& name, int line,
                                    int column) {
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter SourceLocationTable::AddImport 1\n");
  import_location_map_[std::make_pair(descriptor, name)] =
      std::make_pair(line, column);
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit SourceLocationTable::AddImport 1\n");
}

void SourceLocationTable::Clear() { 
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] enter SourceLocationTable::Clear 1\n");
  location_map_.clear(); 
  fprintf(stderr, "[src/google/protobuf/compiler/parser.cc] exit SourceLocationTable::Clear 1\n");
}

}  // namespace compiler
}  // namespace protobuf
}  // namespace google

#include "google/protobuf/port_undef.inc"
// Total cost: 3.168995
// Total split cost: 0.988191, input tokens: 274158, output tokens: 5453, cache read tokens: 9436, cache write tokens: 29173, split chunks: [(0, 789), (789, 1469), (1469, 2250), (2250, 2645)]
// Total instrumented cost: 2.180804, input tokens: 175914, output tokens: 106244, cache read tokens: 93045, cache write tokens: 82833

// Protocol Buffers - Google's data interchange format
// Copyright 2008 Google Inc.  All rights reserved.
//
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file or at
// https://developers.google.com/open-source/licenses/bsd

// Author: kenton@google.com (Kenton Varda)

#include "google/protobuf/compiler/subprocess.h"

#include <algorithm>
#include <cstring>
#include <string>

#ifndef _WIN32
#include <errno.h>
#include <signal.h>
#include <sys/select.h>
#include <sys/wait.h>
#endif

#include <stdio.h>

#include "absl/log/absl_check.h"
#include "absl/log/absl_log.h"
#include "absl/strings/escaping.h"
#include "absl/strings/str_cat.h"
#include "absl/strings/substitute.h"
#include "google/protobuf/io/io_win32.h"
#include "google/protobuf/message.h"

namespace google {
namespace protobuf {
namespace compiler {

#ifdef _WIN32

static void CloseHandleOrDie(HANDLE handle) {
  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter CloseHandleOrDie 1\n");
  if (!CloseHandle(handle)) {
    ABSL_LOG(FATAL) << "CloseHandle: "
                    << Subprocess::Win32ErrorMessage(GetLastError());
  }
  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit CloseHandleOrDie 1\n");
}

Subprocess::Subprocess()
    : process_start_error_(ERROR_SUCCESS),
      child_handle_(nullptr),
      child_stdin_(nullptr),
      child_stdout_(nullptr) {
  fprintf(stderr, "\n");
  fprintf(stderr, "\n");
}

Subprocess::~Subprocess() {
  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::~Subprocess 1\n");
  if (child_stdin_ != nullptr) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::~Subprocess 2\n");
    CloseHandleOrDie(child_stdin_);
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::~Subprocess 2\n");
  }
  if (child_stdout_ != nullptr) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::~Subprocess 3\n");
    CloseHandleOrDie(child_stdout_);
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::~Subprocess 3\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::~Subprocess 1\n");
}

void Subprocess::Start(const std::string& program, SearchMode search_mode) {
  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Start 1\n");
  // Create the pipes.
  HANDLE stdin_pipe_read;
  HANDLE stdin_pipe_write;
  HANDLE stdout_pipe_read;
  HANDLE stdout_pipe_write;

  if (!CreatePipe(&stdin_pipe_read, &stdin_pipe_write, nullptr, 0)) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Start 2\n");
    ABSL_LOG(FATAL) << "CreatePipe: " << Win32ErrorMessage(GetLastError());
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Start 2\n");
  }
  if (!CreatePipe(&stdout_pipe_read, &stdout_pipe_write, nullptr, 0)) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Start 3\n");
    ABSL_LOG(FATAL) << "CreatePipe: " << Win32ErrorMessage(GetLastError());
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Start 3\n");
  }

  // Make child side of the pipes inheritable.
  if (!SetHandleInformation(stdin_pipe_read, HANDLE_FLAG_INHERIT,
                            HANDLE_FLAG_INHERIT)) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Start 4\n");
    ABSL_LOG(FATAL) << "SetHandleInformation: "
                    << Win32ErrorMessage(GetLastError());
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Start 4\n");
  }
  if (!SetHandleInformation(stdout_pipe_write, HANDLE_FLAG_INHERIT,
                            HANDLE_FLAG_INHERIT)) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Start 5\n");
    ABSL_LOG(FATAL) << "SetHandleInformation: "
                    << Win32ErrorMessage(GetLastError());
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Start 5\n");
  }

  // Setup STARTUPINFO to redirect handles.
  STARTUPINFOW startup_info;
  ZeroMemory(&startup_info, sizeof(startup_info));
  startup_info.cb = sizeof(startup_info);
  startup_info.dwFlags = STARTF_USESTDHANDLES;
  startup_info.hStdInput = stdin_pipe_read;
  startup_info.hStdOutput = stdout_pipe_write;
  startup_info.hStdError = GetStdHandle(STD_ERROR_HANDLE);

  if (startup_info.hStdError == INVALID_HANDLE_VALUE) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Start 6\n");
    ABSL_LOG(FATAL) << "GetStdHandle: " << Win32ErrorMessage(GetLastError());
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Start 6\n");
  }

  // get wide string version of program as the path may contain non-ascii characters
  std::wstring wprogram;
  if (!io::win32::strings::utf8_to_wcs(program.c_str(), &wprogram)) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Start 7\n");
    ABSL_LOG(FATAL) << "utf8_to_wcs: " << Win32ErrorMessage(GetLastError());
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Start 7\n");
  }

  // Invoking cmd.exe allows for '.bat' files from the path as well as '.exe'.
  std::string command_line = absl::StrCat("cmd.exe /c \"", program, "\"");

  // get wide string version of command line as the path may contain non-ascii characters
  std::wstring wcommand_line;
  if (!io::win32::strings::utf8_to_wcs(command_line.c_str(), &wcommand_line)) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Start 8\n");
    ABSL_LOG(FATAL) << "utf8_to_wcs: " << Win32ErrorMessage(GetLastError());
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Start 8\n");
  }

  // Using a malloc'ed string because CreateProcess() can mutate its second
  // parameter.
  wchar_t *wcommand_line_copy = _wcsdup(wcommand_line.c_str());

  // Create the process.
  PROCESS_INFORMATION process_info;

  if (CreateProcessW(
          (search_mode == SEARCH_PATH) ? nullptr : wprogram.c_str(),
          (search_mode == SEARCH_PATH) ? wcommand_line_copy : nullptr,
          nullptr,  // process security attributes
          nullptr,  // thread security attributes
          TRUE,     // inherit handles?
          0,        // obscure creation flags
          nullptr,  // environment (inherit from parent)
          nullptr,  // current directory (inherit from parent)
          &startup_info, &process_info)) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Start 9\n");
    child_handle_ = process_info.hProcess;
    CloseHandleOrDie(process_info.hThread);
    child_stdin_ = stdin_pipe_write;
    child_stdout_ = stdout_pipe_read;
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Start 9\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Start 10\n");
    process_start_error_ = GetLastError();
    CloseHandleOrDie(stdin_pipe_write);
    CloseHandleOrDie(stdout_pipe_read);
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Start 10\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Start 11\n");
  CloseHandleOrDie(stdin_pipe_read);
  CloseHandleOrDie(stdout_pipe_write);
  free(wcommand_line_copy);
  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Start 11\n");
  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Start 1\n");
}

bool Subprocess::Communicate(const Message& input, Message* output,
                             std::string* error) {
  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 1\n");
  if (process_start_error_ != ERROR_SUCCESS) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 2\n");
    *error = Win32ErrorMessage(process_start_error_);
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 2\n");
  }

  ABSL_CHECK(child_handle_ != nullptr) << "Must call Start() first.";

  std::string input_data;
  if (!input.SerializeToString(&input_data)) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 3\n");
    *error = "Failed to serialize request.";
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 3\n");
  }
  std::string output_data;

  int input_pos = 0;

  while (child_stdout_ != nullptr) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 4\n");
    HANDLE handles[2];
    int handle_count = 0;

    if (child_stdin_ != nullptr) {
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 5\n");
      handles[handle_count++] = child_stdin_;
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 5\n");
    }
    if (child_stdout_ != nullptr) {
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 6\n");
      handles[handle_count++] = child_stdout_;
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 6\n");
    }

    DWORD wait_result =
        WaitForMultipleObjects(handle_count, handles, FALSE, INFINITE);

    HANDLE signaled_handle = nullptr;
    if (wait_result >= WAIT_OBJECT_0 &&
        wait_result < WAIT_OBJECT_0 + handle_count) {
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 7\n");
      signaled_handle = handles[wait_result - WAIT_OBJECT_0];
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 7\n");
    } else if (wait_result == WAIT_FAILED) {
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 8\n");
      ABSL_LOG(FATAL) << "WaitForMultipleObjects: "
                      << Win32ErrorMessage(GetLastError());
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 8\n");
    } else {
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 9\n");
      ABSL_LOG(FATAL) << "WaitForMultipleObjects: Unexpected return code: "
                      << wait_result;
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 9\n");
    }

    if (signaled_handle == child_stdin_) {
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 10\n");
      DWORD n;
      if (!WriteFile(child_stdin_, input_data.data() + input_pos,
                     input_data.size() - input_pos, &n, nullptr)) {
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 11\n");
        // Child closed pipe.  Presumably it will report an error later.
        // Pretend we're done for now.
        input_pos = input_data.size();
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 11\n");
      } else {
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 12\n");
        input_pos += n;
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 12\n");
      }

      if (input_pos == input_data.size()) {
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 13\n");
        // We're done writing.  Close.
        CloseHandleOrDie(child_stdin_);
        child_stdin_ = nullptr;
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 13\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 10\n");
    } else if (signaled_handle == child_stdout_) {
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 14\n");
      char buffer[4096];
      DWORD n;

      if (!ReadFile(child_stdout_, buffer, sizeof(buffer), &n, nullptr)) {
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 15\n");
        // We're done reading.  Close.
        CloseHandleOrDie(child_stdout_);
        child_stdout_ = nullptr;
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 15\n");
      } else {
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 16\n");
        output_data.append(buffer, n);
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 16\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 14\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 4\n");
  }

  if (child_stdin_ != nullptr) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 17\n");
    // Child did not finish reading input before it closed the output.
    // Presumably it exited with an error.
    CloseHandleOrDie(child_stdin_);
    child_stdin_ = nullptr;
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 17\n");
  }

  DWORD wait_result = WaitForSingleObject(child_handle_, INFINITE);

  if (wait_result == WAIT_FAILED) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 18\n");
    ABSL_LOG(FATAL) << "WaitForSingleObject: "
                    << Win32ErrorMessage(GetLastError());
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 18\n");
  } else if (wait_result != WAIT_OBJECT_0) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 19\n");
    ABSL_LOG(FATAL) << "WaitForSingleObject: Unexpected return code: "
                    << wait_result;
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 19\n");
  }

  DWORD exit_code;
  if (!GetExitCodeProcess(child_handle_, &exit_code)) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 20\n");
    ABSL_LOG(FATAL) << "GetExitCodeProcess: "
                    << Win32ErrorMessage(GetLastError());
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 20\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 21\n");
  CloseHandleOrDie(child_handle_);
  child_handle_ = nullptr;
  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 21\n");

  if (exit_code != 0) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 22\n");
    *error = absl::Substitute("Plugin failed with status code $0.", exit_code);
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 22\n");
  }

  if (!output->ParseFromString(output_data)) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 23\n");
    *error = absl::StrCat("Plugin output is unparseable: ",
                          absl::CEscape(output_data));
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 23\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 24\n");
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 24\n");
  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 1\n");
}

std::string Subprocess::Win32ErrorMessage(DWORD error_code) {
  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Win32ErrorMessage 1\n");
  char* message;

  // WTF?
  FormatMessageA(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |
                     FORMAT_MESSAGE_IGNORE_INSERTS,
                 nullptr, error_code,
                 MAKELANGID(LANG_ENGLISH, SUBLANG_ENGLISH_US),
                 (LPSTR)&message,  // NOT A BUG!
                 0, nullptr);

  std::string result = message;
  LocalFree(message);
  return result;
  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Win32ErrorMessage 1\n");
}

// ===================================================================

#else  // _WIN32

Subprocess::Subprocess()
    : child_pid_(-1), child_stdin_(-1), child_stdout_(-1) {
  fprintf(stderr, "\n");
  fprintf(stderr, "\n");
}

Subprocess::~Subprocess() {
  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::~Subprocess 1735\n");
  if (child_stdin_ != -1) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::~Subprocess 2670\n");
    close(child_stdin_);
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::~Subprocess 2670\n");
  }
  if (child_stdout_ != -1) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::~Subprocess 354\n");
    close(child_stdout_);
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::~Subprocess 354\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::~Subprocess 1735\n");
}

namespace {
char* portable_strdup(const char* s) {
  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter portable_strdup 1\n");
  char* ns = (char*)malloc(strlen(s) + 1);
  if (ns != nullptr) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter portable_strdup 2\n");
    strcpy(ns, s);
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit portable_strdup 2\n");
  }
  return ns;
  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit portable_strdup 1\n");
}
}  // namespace

void Subprocess::Start(const std::string& program, SearchMode search_mode) {
  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Start 4896\n");
  // Note that we assume that there are no other threads, thus we don't have to
  // do crazy stuff like using socket pairs or avoiding libc locks.

  // [0] is read end, [1] is write end.
  int stdin_pipe[2];
  int stdout_pipe[2];

  ABSL_CHECK(pipe(stdin_pipe) != -1);
  ABSL_CHECK(pipe(stdout_pipe) != -1);

  char* argv[2] = {portable_strdup(program.c_str()), nullptr};

  child_pid_ = fork();
  if (child_pid_ == -1) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Start 4944\n");
    ABSL_LOG(FATAL) << "fork: " << strerror(errno);
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Start 4944\n");
  } else if (child_pid_ == 0) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Start 827\n");
    // We are the child.
    dup2(stdin_pipe[0], STDIN_FILENO);
    dup2(stdout_pipe[1], STDOUT_FILENO);

    close(stdin_pipe[0]);
    close(stdin_pipe[1]);
    close(stdout_pipe[0]);
    close(stdout_pipe[1]);

    switch (search_mode) {
      case SEARCH_PATH:
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Start 2579\n");
        execvp(argv[0], argv);
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Start 2579\n");
        break;
      case EXACT_NAME:
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Start 4738\n");
        execv(argv[0], argv);
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Start 4738\n");
        break;
    }

    // Write directly to STDERR_FILENO to avoid stdio code paths that may do
    // stuff that is unsafe here.
    int ignored;
    ignored = write(STDERR_FILENO, argv[0], strlen(argv[0]));
    const char* message =
        ": program not found or is not executable\n"
        "Please specify a program using absolute path or make sure "
        "the program is available in your PATH system variable\n";
    ignored = write(STDERR_FILENO, message, strlen(message));
    (void)ignored;

    // Must use _exit() rather than exit() to avoid flushing output buffers
    // that will also be flushed by the parent.
    _exit(1);
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Start 827\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Start 1919\n");
    free(argv[0]);

    close(stdin_pipe[0]);
    close(stdout_pipe[1]);

    child_stdin_ = stdin_pipe[1];
    child_stdout_ = stdout_pipe[0];
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Start 1919\n");
  }
  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Start 4896\n");
}

bool Subprocess::Communicate(const Message& input, Message* output,
                             std::string* error) {
  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 3828\n");
  ABSL_CHECK_NE(child_stdin_, -1) << "Must call Start() first.";

  // The "sighandler_t" typedef is GNU-specific, so define our own.
  typedef void SignalHandler(int);

  // Make sure SIGPIPE is disabled so that if the child dies it doesn't kill us.
  SignalHandler* old_pipe_handler = signal(SIGPIPE, SIG_IGN);

  std::string input_data;
  if (!input.SerializeToString(&input_data)) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 1347\n");
    *error = "Failed to serialize request.";
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 1347\n");
  }
  std::string output_data;

  int input_pos = 0;
  int max_fd = std::max(child_stdin_, child_stdout_);

  while (child_stdout_ != -1) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 4206\n");
    fd_set read_fds;
    fd_set write_fds;
    FD_ZERO(&read_fds);
    FD_ZERO(&write_fds);
    if (child_stdout_ != -1) {
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 2338\n");
      FD_SET(child_stdout_, &read_fds);
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 2338\n");
    }
    if (child_stdin_ != -1) {
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 267\n");
      FD_SET(child_stdin_, &write_fds);
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 267\n");
    }

    if (select(max_fd + 1, &read_fds, &write_fds, nullptr, nullptr) < 0) {
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 738\n");
      if (errno == EINTR) {
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 4085\n");
        // Interrupted by signal.  Try again.
        continue;
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 4085\n");
      } else {
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 1740\n");
        ABSL_LOG(FATAL) << "select: " << strerror(errno);
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 1740\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 738\n");
    }

    if (child_stdin_ != -1 && FD_ISSET(child_stdin_, &write_fds)) {
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 2408\n");
      int n = write(child_stdin_, input_data.data() + input_pos,
                    input_data.size() - input_pos);
      if (n < 0) {
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 2318\n");
        // Child closed pipe.  Presumably it will report an error later.
        // Pretend we're done for now.
        input_pos = input_data.size();
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 2318\n");
      } else {
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 1388\n");
        input_pos += n;
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 1388\n");
      }

      if (input_pos == input_data.size()) {
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 657\n");
        // We're done writing.  Close.
        close(child_stdin_);
        child_stdin_ = -1;
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 657\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 2408\n");
    }

    if (child_stdout_ != -1 && FD_ISSET(child_stdout_, &read_fds)) {
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 3368\n");
      char buffer[4096];
      int n = read(child_stdout_, buffer, sizeof(buffer));

      if (n > 0) {
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 3353\n");
        output_data.append(buffer, n);
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 3353\n");
      } else {
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 722\n");
        // We're done reading.  Close.
        close(child_stdout_);
        child_stdout_ = -1;
        fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 722\n");
      }
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 3368\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 4206\n");
  }

  if (child_stdin_ != -1) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 2324\n");
    // Child did not finish reading input before it closed the output.
    // Presumably it exited with an error.
    close(child_stdin_);
    child_stdin_ = -1;
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 2324\n");
  }

  int status;
  while (waitpid(child_pid_, &status, 0) == -1) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 1295\n");
    if (errno != EINTR) {
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 3479\n");
      ABSL_LOG(FATAL) << "waitpid: " << strerror(errno);
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 3479\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 1295\n");
  }

  // Restore SIGPIPE handling.
  signal(SIGPIPE, old_pipe_handler);

  if (WIFEXITED(status)) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 2365\n");
    if (WEXITSTATUS(status) != 0) {
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 4804\n");
      int error_code = WEXITSTATUS(status);
      *error =
          absl::Substitute("Plugin failed with status code $0.", error_code);
      return false;
      fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 4804\n");
    }
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 2365\n");
  } else if (WIFSIGNALED(status)) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 2133\n");
    int signal = WTERMSIG(status);
    *error = absl::Substitute("Plugin killed by signal $0.", signal);
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 2133\n");
  } else {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 4308\n");
    *error = "Neither WEXITSTATUS nor WTERMSIG is true?";
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 4308\n");
  }

  if (!output->ParseFromString(output_data)) {
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 830\n");
    *error = absl::StrCat("Plugin output is unparseable: ",
                          absl::CEscape(output_data));
    return false;
    fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 830\n");
  }

  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] enter Subprocess::Communicate 1864\n");
  return true;
  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 1864\n");
  fprintf(stderr, "[src/google/protobuf/compiler/subprocess.cc] exit Subprocess::Communicate 3828\n");
}

#endif  // !_WIN32

}  // namespace compiler
}  // namespace protobuf
}  // namespace google
// Total cost: 0.162332
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 480)]
// Total instrumented cost: 0.162332, input tokens: 7147, output tokens: 7607, cache read tokens: 0, cache write tokens: 7143

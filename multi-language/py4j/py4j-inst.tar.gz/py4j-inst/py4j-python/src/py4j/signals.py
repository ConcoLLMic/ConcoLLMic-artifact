# -*- coding: UTF-8 -*-
"""Module that provides a simple signals library.

The signals pattern is very similar to the listener/observer pattern.

"""
from inspect import ismethod
from threading import Lock
import sys

from py4j.compat import range


def make_id(func):
    sys.stderr.write("[py4j-python/src/py4j/signals.py] enter make_id 1\n")
    if ismethod(func):
        sys.stderr.write("[py4j-python/src/py4j/signals.py] enter make_id 2\n")
        return (id(func.__self__), id(func.__func__))
        sys.stderr.write("[py4j-python/src/py4j/signals.py] exit make_id 2\n")
    return id(func)
    sys.stderr.write("[py4j-python/src/py4j/signals.py] exit make_id 1\n")


NONE_ID = make_id(None)


class Signal(object):
    """Basic signal class that can register receivers (listeners) and dispatch
    events to these receivers.

    As opposed to many signals libraries, receivers are not stored as weak
    references, so it is us to the client application to unregister them.

    Greatly inspired from Django Signals:
    https://github.com/django/django/blob/master/django/dispatch/dispatcher.py
    """

    def __init__(self):
        sys.stderr.write("[py4j-python/src/py4j/signals.py] enter Signal.__init__ 1\n")
        self.lock = Lock()
        # Someday, we may implement caching, but in practice, we expect the
        # number of receivers to be very small.
        self.receivers = []
        sys.stderr.write("[py4j-python/src/py4j/signals.py] exit Signal.__init__ 1\n")

    def connect(self, receiver, sender=None, unique_id=None):
        """Registers a receiver for this signal.

        The receiver must be a callable (e.g., function or instance method)
        that accepts named arguments (i.e., ``**kwargs``).

        In case that the connect method might be called multiple time, it is
        best to provide the receiver with a unique id to make sure that the
        receiver is not registered more than once.

        :param receiver: The callable that will receive the signal.
        :param sender: The sender to which the receiver will respond to. If
            None, signals from any sender are sent to this receiver
        :param unique_id: The unique id of the callable to make sure it is not
            registered more than once. Optional.
        """
        sys.stderr.write("[py4j-python/src/py4j/signals.py] enter Signal.connect 1\n")
        full_id = self._get_id(receiver, unique_id, sender)

        with self.lock:
            sys.stderr.write("[py4j-python/src/py4j/signals.py] enter Signal.connect 2\n")
            for receiver_id, _ in self.receivers:
                sys.stderr.write("[py4j-python/src/py4j/signals.py] enter Signal.connect 3\n")
                if receiver_id == full_id:
                    sys.stderr.write("[py4j-python/src/py4j/signals.py] enter Signal.connect 4\n")
                    break
                    sys.stderr.write("[py4j-python/src/py4j/signals.py] exit Signal.connect 4\n")
                sys.stderr.write("[py4j-python/src/py4j/signals.py] exit Signal.connect 3\n")
            else:
                sys.stderr.write("[py4j-python/src/py4j/signals.py] enter Signal.connect 5\n")
                self.receivers.append((full_id, receiver))
                sys.stderr.write("[py4j-python/src/py4j/signals.py] exit Signal.connect 5\n")
            sys.stderr.write("[py4j-python/src/py4j/signals.py] exit Signal.connect 2\n")
        sys.stderr.write("[py4j-python/src/py4j/signals.py] exit Signal.connect 1\n")

    def disconnect(self, receiver, sender=None, unique_id=None):
        """Unregisters a receiver for this signal.

        :param receiver: The callable that was registered to receive the
            signal.
        :param unique_id: The unique id of the callable if it was provided.
            Optional.
        :return: True if the receiver was found and disconnected. False
            otherwise.
        :rtype: bool
        """
        sys.stderr.write("[py4j-python/src/py4j/signals.py] enter Signal.disconnect 1\n")
        full_id = self._get_id(receiver, unique_id, sender)
        disconnected = False

        with self.lock:
            sys.stderr.write("[py4j-python/src/py4j/signals.py] enter Signal.disconnect 2\n")
            for index in range(len(self.receivers)):
                sys.stderr.write("[py4j-python/src/py4j/signals.py] enter Signal.disconnect 3\n")
                temp_id = self.receivers[index][0]
                if temp_id == full_id:
                    sys.stderr.write("[py4j-python/src/py4j/signals.py] enter Signal.disconnect 4\n")
                    del self.receivers[index]
                    disconnected = True
                    break
                    sys.stderr.write("[py4j-python/src/py4j/signals.py] exit Signal.disconnect 4\n")
                sys.stderr.write("[py4j-python/src/py4j/signals.py] exit Signal.disconnect 3\n")
            sys.stderr.write("[py4j-python/src/py4j/signals.py] exit Signal.disconnect 2\n")

        return disconnected
        sys.stderr.write("[py4j-python/src/py4j/signals.py] exit Signal.disconnect 1\n")

    def send(self, sender, **params):
        """Sends the signal to all connected receivers.

        If a receiver raises an error, the error is propagated back and
        interrupts the sending processing. It is thus possible that not all
        receivers will receive the signal.

        :param: named parameters to send to the receivers.
        :param: the sender of the signal. Optional.
        :return: List of (receiver, response) from receivers.
        :rtype: list
        """
        sys.stderr.write("[py4j-python/src/py4j/signals.py] enter Signal.send 1\n")
        responses = []
        for receiver in self._get_receivers(sender):
            sys.stderr.write("[py4j-python/src/py4j/signals.py] enter Signal.send 2\n")
            response = receiver(signal=self, sender=sender, **params)
            responses.append((receiver, response))
            sys.stderr.write("[py4j-python/src/py4j/signals.py] exit Signal.send 2\n")
        return responses
        sys.stderr.write("[py4j-python/src/py4j/signals.py] exit Signal.send 1\n")

    def _get_receivers(self, sender):
        """Internal method that may in the future resolve weak references or
        perform other work such as identifying dead receivers.
        """
        sys.stderr.write("[py4j-python/src/py4j/signals.py] enter Signal._get_receivers 1\n")
        sender_id = make_id(sender)
        receivers = []
        with self.lock:
            sys.stderr.write("[py4j-python/src/py4j/signals.py] enter Signal._get_receivers 2\n")
            for ((_, rsender_id), receiver) in self.receivers:
                sys.stderr.write("[py4j-python/src/py4j/signals.py] enter Signal._get_receivers 3\n")
                if rsender_id == NONE_ID or rsender_id == sender_id:
                    sys.stderr.write("[py4j-python/src/py4j/signals.py] enter Signal._get_receivers 4\n")
                    receivers.append(receiver)
                    sys.stderr.write("[py4j-python/src/py4j/signals.py] exit Signal._get_receivers 4\n")
                sys.stderr.write("[py4j-python/src/py4j/signals.py] exit Signal._get_receivers 3\n")
            sys.stderr.write("[py4j-python/src/py4j/signals.py] exit Signal._get_receivers 2\n")
        return receivers
        sys.stderr.write("[py4j-python/src/py4j/signals.py] exit Signal._get_receivers 1\n")

    def _get_id(self, receiver, unique_id, sender):
        sys.stderr.write("[py4j-python/src/py4j/signals.py] enter Signal._get_id 1\n")
        sender_id = make_id(sender)
        if unique_id:
            sys.stderr.write("[py4j-python/src/py4j/signals.py] enter Signal._get_id 2\n")
            full_id = (unique_id, sender_id)
            sys.stderr.write("[py4j-python/src/py4j/signals.py] exit Signal._get_id 2\n")
        else:
            sys.stderr.write("[py4j-python/src/py4j/signals.py] enter Signal._get_id 3\n")
            full_id = (make_id(receiver), sender_id)
            sys.stderr.write("[py4j-python/src/py4j/signals.py] exit Signal._get_id 3\n")
        return full_id
        sys.stderr.write("[py4j-python/src/py4j/signals.py] exit Signal._get_id 1\n")
# Total cost: 0.036091
# Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 124)]
# Total instrumented cost: 0.036091, input tokens: 3421, output tokens: 1848, cache read tokens: 2280, cache write tokens: 1137

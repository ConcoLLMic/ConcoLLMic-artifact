# -*- coding: UTF-8 -*-
"""
Module responsible for converting Java collection classes to Python collection
classes. This module is optional but loaded by default.


Created on Jan 22, 2010

:author: Barthelemy Dagenais
"""
from __future__ import unicode_literals, absolute_import
import sys

# As of Python 3.3, the abstract base classes in the collections module have
# been moved to collections.abc.
# (see https://docs.python.org/3.3/library/collections.abc.html)
try:
    # Python >=3.3
    from collections.abc import (
        MutableMapping, Sequence, MutableSequence,
        MutableSet, Set)
except ImportError:
    # Python <=3.2
    from collections import (
        MutableMapping, Sequence, MutableSequence,
        MutableSet, Set)
import sys

from py4j.compat import (
    iteritems, next, hasattr2, isbytearray,
    ispython3bytestr, basestring)
from py4j.java_gateway import JavaObject, JavaMember, get_method, JavaClass
from py4j import protocol as proto
from py4j.protocol import (
    Py4JError, get_command_part, get_return_value, register_input_converter,
    register_output_converter, Py4JJavaError)


class JavaIterator(JavaObject):
    """Maps a Python list iterator to a Java list iterator.

    The `JavaIterator` follows the Python iterator protocol and raises a
    `StopIteration` error when the iterator can no longer iterate."""
    def __init__(self, target_id, gateway_client):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaIterator.__init__ 1\n")
        JavaObject.__init__(self, target_id, gateway_client)
        self._next_name = "next"
        self._is_instance_of = JavaClass(
            "py4j.reflection.TypeUtil", gateway_client).isInstanceOf
        # To bind lifecycle of this iterator to the java iterator. To prevent
        # gc of the iterator.
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaIterator.__init__ 1\n")

    def __iter__(self):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaIterator.__iter__ 1\n")
        return self
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaIterator.__iter__ 1\n")

    def next(self):
        """This next method wraps the `next` method in Java iterators.

        The `Iterator.next()` method is called and if an exception occur (e.g.,
        NoSuchElementException), a StopIteration exception is raised."""
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaIterator.next 1\n")
        if self._next_name not in self._methods:
            self._methods[self._next_name] = JavaMember(
                self._next_name, self,
                self._target_id, self._gateway_client)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaIterator.next 1\n")
        try:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaIterator.next 2\n")
            return self._methods[self._next_name]()
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaIterator.next 2\n")
        except Py4JJavaError as e:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaIterator.next 3\n")
            if not self._is_instance_of("java.util.NoSuchElementException", e.java_exception):
                raise e
            raise StopIteration()
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaIterator.next 3\n")
        except Py4JError:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaIterator.next 4\n")
            raise StopIteration()
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaIterator.next 4\n")

    __next__ = next


class JavaMap(JavaObject, MutableMapping):
    """Maps a Python Dictionary to a Java Map.

    All operations possible on a Python dict are implemented."""

    def __init__(self, target_id, gateway_client):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaMap.__init__ 1\n")
        JavaObject.__init__(self, target_id, gateway_client)
        self._get = get_method(self, "get")
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaMap.__init__ 1\n")

    def __getitem__(self, key):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaMap.__getitem__ 1\n")
        return self._get(key)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaMap.__getitem__ 1\n")

    def __setitem__(self, key, value):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaMap.__setitem__ 1\n")
        self.put(key, value)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaMap.__setitem__ 1\n")

    def __len__(self):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaMap.__len__ 1\n")
        return self.size()
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaMap.__len__ 1\n")

    def __delitem__(self, key):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaMap.__delitem__ 1\n")
        self.remove(key)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaMap.__delitem__ 1\n")

    def __iter__(self):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaMap.__iter__ 1\n")
        return self.keySet().iterator()
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaMap.__iter__ 1\n")

    def __contains__(self, key):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaMap.__contains__ 1\n")
        return self.containsKey(key)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaMap.__contains__ 1\n")

    def __str__(self):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaMap.__str__ 1\n")
        return self.__repr__()
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaMap.__str__ 1\n")

    def __repr__(self):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaMap.__repr__ 1\n")
        items = (
            "{0}: {1}".format(repr(k), repr(v))
            for k, v in iteritems(self))
        return "{{{0}}}".format(", ".join(items))
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaMap.__repr__ 1\n")


class JavaSet(JavaObject, MutableSet):
    """Maps a Python Set to a Java Set.

    All operations possible on a Python set are implemented."""

    __EMPTY_SET = "set([])" if sys.version_info.major < 3 else "set()"
    __SET_TEMPLATE = "set([{0}])" if sys.version_info.major < 3 else "{{{0}}}"

    def __init__(self, target_id, gateway_client):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaSet.__init__ 1\n")
        JavaObject.__init__(self, target_id, gateway_client)
        self._add = get_method(self, "add")
        self._clear = get_method(self, "clear")
        self._remove = get_method(self, "remove")
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaSet.__init__ 1\n")

    def add(self, value):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaSet.add 1\n")
        self._add(value)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaSet.add 1\n")

    def discard(self, value):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaSet.discard 1\n")
        self.remove(value)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaSet.discard 1\n")

    def remove(self, value):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaSet.remove 1\n")
        if value not in self:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaSet.remove 2\n")
            raise KeyError()
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaSet.remove 2\n")
        else:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaSet.remove 3\n")
            self._remove(value)
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaSet.remove 3\n")
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaSet.remove 1\n")

    def clear(self):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaSet.clear 1\n")
        self._clear()
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaSet.clear 1\n")

    def __len__(self):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaSet.__len__ 1\n")
        return self.size()
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaSet.__len__ 1\n")

    def __iter__(self):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaSet.__iter__ 1\n")
        return self.iterator()
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaSet.__iter__ 1\n")

    def __contains__(self, value):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaSet.__contains__ 1\n")
        return self.contains(value)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaSet.__contains__ 1\n")

    def __str__(self):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaSet.__str__ 1\n")
        return self.__repr__()
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaSet.__str__ 1\n")

    def __repr__(self):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaSet.__repr__ 1\n")
        if len(self):
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaSet.__repr__ 2\n")
            return self.__SET_TEMPLATE.format(", ".join(
                (repr(x) for x in self)))
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaSet.__repr__ 2\n")
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaSet.__repr__ 1\n")
        return self.__EMPTY_SET


class JavaArray(JavaObject, Sequence):
    """Maps a Java Array to a Semi-Mutable Sequence: elements inside the
    sequence can be modified, but the length of the sequence cannot change.

    The backing collection is a Sequence and not a Python array because
    these arrays only accept primitives whereas Java arrays work for any types.
    """

    def __init__(self, target_id, gateway_client):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaArray.__init__ 1\n")
        JavaObject.__init__(self, target_id, gateway_client)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaArray.__init__ 1\n")

    def __compute_index(self, key, adjustLast=False):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaArray.__compute_index 1\n")
        size = len(self)
        if 0 <= key < size:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaArray.__compute_index 2\n")
            return key
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaArray.__compute_index 2\n")
        elif key < 0 and abs(key) <= size:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaArray.__compute_index 3\n")
            return size + key
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaArray.__compute_index 3\n")
        elif adjustLast:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaArray.__compute_index 4\n")
            return size
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaArray.__compute_index 4\n")
        else:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaArray.__compute_index 5\n")
            raise IndexError("list index out of range")
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaArray.__compute_index 5\n")
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaArray.__compute_index 1\n")

    def __compute_item(self, key):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaArray.__compute_item 1\n")
        new_key = self.__compute_index(key)
        command = proto.ARRAY_COMMAND_NAME +\
            proto.ARRAY_GET_SUB_COMMAND_NAME +\
            self._get_object_id() + "\n"
        command += get_command_part(new_key)
        command += proto.END_COMMAND_PART
        answer = self._gateway_client.send_command(command)
        return get_return_value(answer, self._gateway_client)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaArray.__compute_item 1\n")

    def __get_slice(self, indices):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaArray.__get_slice 1\n")
        command = proto.ARRAY_COMMAND_NAME +\
            proto.ARRAY_SLICE_SUB_COMMAND_NAME +\
            self._get_object_id() + "\n"
        for index in indices:
            command += get_command_part(index)
        command += proto.END_COMMAND_PART
        answer = self._gateway_client.send_command(command)
        return get_return_value(answer, self._gateway_client)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaArray.__get_slice 1\n")

    def __getitem__(self, key):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaArray.__getitem__ 1\n")
        if isinstance(key, slice):
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaArray.__getitem__ 2\n")
            indices = key.indices(len(self))
            return self.__get_slice(range(*indices))
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaArray.__getitem__ 2\n")
        elif isinstance(key, int):
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaArray.__getitem__ 3\n")
            return self.__compute_item(key)
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaArray.__getitem__ 3\n")
        else:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaArray.__getitem__ 4\n")
            raise TypeError("array indices must be integers, not {0}".format(
                key.__class__.__name__))
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaArray.__getitem__ 4\n")
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaArray.__getitem__ 1\n")

    def __repl_item_from_slice(self, range, iterable):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaArray.__repl_item_from_slice 1\n")
        value_iter = iter(iterable)
        for i in range:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaArray.__repl_item_from_slice 2\n")
            value = next(value_iter)
            self.__set_item(i, value)
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaArray.__repl_item_from_slice 2\n")
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaArray.__repl_item_from_slice 1\n")

    def __set_item(self, key, value):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaArray.__set_item 1\n")
        new_key = self.__compute_index(key)
        command = proto.ARRAY_COMMAND_NAME +\
            proto.ARRAY_SET_SUB_COMMAND_NAME +\
            self._get_object_id() + "\n"
        command += get_command_part(new_key)
        command += get_command_part(value)
        command += proto.END_COMMAND_PART
        answer = self._gateway_client.send_command(command)
        return get_return_value(answer, self._gateway_client)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaArray.__set_item 1\n")

    def __setitem__(self, key, value):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaArray.__setitem__ 1\n")
        if isinstance(key, slice):
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaArray.__setitem__ 2\n")
            self_len = len(self)
            indices = key.indices(self_len)
            self_range = range(*indices)
            lenr = len(self_range)
            lenv = len(value)
            if lenr != lenv:
                sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaArray.__setitem__ 3\n")
                raise ValueError(
                    "attempt to assign sequence of size "
                    "{0} to extended slice of size {1}".format(lenv, lenr))
                sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaArray.__setitem__ 3\n")
            else:
                sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaArray.__setitem__ 4\n")
                return self.__repl_item_from_slice(self_range, value)
                sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaArray.__setitem__ 4\n")
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaArray.__setitem__ 2\n")
        elif isinstance(key, int):
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaArray.__setitem__ 5\n")
            return self.__set_item(key, value)
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaArray.__setitem__ 5\n")
        else:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaArray.__setitem__ 6\n")
            raise TypeError("list indices must be integers, not {0}".format(
                key.__class__.__name__))
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaArray.__setitem__ 6\n")
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaArray.__setitem__ 1\n")

    def __len__(self):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaArray.__len__ 1\n")
        command = proto.ARRAY_COMMAND_NAME +\
            proto.ARRAY_LEN_SUB_COMMAND_NAME +\
            self._get_object_id() + "\n"
        command += proto.END_COMMAND_PART
        answer = self._gateway_client.send_command(command)
        return get_return_value(answer, self._gateway_client)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaArray.__len__ 1\n")


class JavaList(JavaObject, MutableSequence):
    """Maps a Python list to a Java list.

    All operations possible on a Python list are implemented. For example,
    slicing (e.g., list[1:3]) will create a copy of the list on the JVM.
    Slicing is thus not equivalent to subList(), because a modification to a
    slice such as the addition of a new element will not affect the original
    list."""

    def __init__(self, target_id, gateway_client):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__init__ 1\n")
        JavaObject.__init__(self, target_id, gateway_client)
        self.java_remove = get_method(self, "remove")
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__init__ 1\n")

    def __len__(self):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__len__ 1\n")
        return self.size()
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__len__ 1\n")

    def __iter__(self):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__iter__ 1\n")
        return self.iterator()
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__iter__ 1\n")

    def __compute_index(self, key, adjustLast=False):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__compute_index 1\n")
        size = self.size()
        if 0 <= key < size:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__compute_index 2\n")
            return key
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__compute_index 2\n")
        elif key < 0 and abs(key) <= size:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__compute_index 3\n")
            return size + key
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__compute_index 3\n")
        elif adjustLast:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__compute_index 4\n")
            return size
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__compute_index 4\n")
        else:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__compute_index 5\n")
            raise IndexError("list index out of range")
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__compute_index 5\n")
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__compute_index 1\n")

    def __compute_item(self, key):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__compute_item 1\n")
        new_key = self.__compute_index(key)
        return self.get(new_key)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__compute_item 1\n")

    def __set_item(self, key, value):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__set_item 1\n")
        new_key = self.__compute_index(key)
        self.set(new_key, value)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__set_item 1\n")

    def __set_item_from_slice(self, indices, iterable):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__set_item_from_slice 1\n")
        offset = 0
        last = 0
        value_iter = iter(iterable)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__set_item_from_slice 1\n")

        # First replace and delete if from_slice > to_slice
        for i in range(*indices):
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__set_item_from_slice 2\n")
            try:
                sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__set_item_from_slice 3\n")
                value = next(value_iter)
                self.__set_item(i, value)
                sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__set_item_from_slice 3\n")
            except StopIteration:
                sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__set_item_from_slice 4\n")
                self.__del_item(i)
                offset -= 1
                sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__set_item_from_slice 4\n")
            last = i + 1
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__set_item_from_slice 2\n")

        # Then insert if from_slice < to_slice
        for elem in value_iter:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__set_item_from_slice 5\n")
            self.insert(last, elem)
            last += 1
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__set_item_from_slice 5\n")

    def __insert_item_from_slice(self, indices, iterable):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__insert_item_from_slice 1\n")
        index = indices[0]
        for elem in iterable:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__insert_item_from_slice 2\n")
            self.insert(index, elem)
            index += 1
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__insert_item_from_slice 2\n")
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__insert_item_from_slice 1\n")

    def __repl_item_from_slice(self, range, iterable):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__repl_item_from_slice 1\n")
        value_iter = iter(iterable)
        for i in range:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__repl_item_from_slice 2\n")
            value = next(value_iter)
            self.__set_item(i, value)
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__repl_item_from_slice 2\n")
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__repl_item_from_slice 1\n")

    def __append_item_from_slice(self, range, iterable):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__append_item_from_slice 1\n")
        for value in iterable:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__append_item_from_slice 2\n")
            self.append(value)
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__append_item_from_slice 2\n")
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__append_item_from_slice 1\n")

    def __del_item(self, key):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__del_item 1\n")
        new_key = self.__compute_index(key)
        self.java_remove(new_key)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__del_item 1\n")

    def __setitem__(self, key, value):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__setitem__ 1\n")
        if isinstance(key, slice):
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__setitem__ 2\n")
            self_len = len(self)
            indices = key.indices(self_len)
            if indices[0] >= self_len:
                sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__setitem__ 3\n")
                self.__append_item_from_slice(range, value)
                sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__setitem__ 3\n")
            elif indices[0] == indices[1]:
                sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__setitem__ 4\n")
                self.__insert_item_from_slice(indices, value)
                sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__setitem__ 4\n")
            elif indices[2] == 1:
                sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__setitem__ 5\n")
                self.__set_item_from_slice(indices, value)
                sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__setitem__ 5\n")
            else:
                sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__setitem__ 6\n")
                self_range = range(*indices)
                lenr = len(self_range)
                lenv = len(value)
                if lenr != lenv:
                    sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__setitem__ 7\n")
                    raise ValueError(
                        "attempt to assign sequence of size "
                        "{0} to extended slice of size {1}".format(lenv, lenr))
                    sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__setitem__ 7\n")
                else:
                    sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__setitem__ 8\n")
                    return self.__repl_item_from_slice(self_range, value)
                    sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__setitem__ 8\n")
                sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__setitem__ 6\n")
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__setitem__ 2\n")
        elif isinstance(key, int):
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__setitem__ 9\n")
            return self.__set_item(key, value)
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__setitem__ 9\n")
        else:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__setitem__ 10\n")
            raise TypeError("list indices must be integers, not {0}".format(
                key.__class__.__name__))
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__setitem__ 10\n")
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__setitem__ 1\n")

    def __get_slice(self, indices):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__get_slice 1\n")
        command = proto.LIST_COMMAND_NAME +\
            proto.LIST_SLICE_SUBCOMMAND_NAME +\
            self._get_object_id() + "\n"
        for index in indices:
            command += get_command_part(index)
        command += proto.END_COMMAND_PART
        answer = self._gateway_client.send_command(command)
        return get_return_value(answer, self._gateway_client)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__get_slice 1\n")

    def __getitem__(self, key):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__getitem__ 1\n")
        if isinstance(key, slice):
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__getitem__ 2\n")
            indices = key.indices(len(self))
            return self.__get_slice(range(*indices))
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__getitem__ 2\n")
        elif isinstance(key, int):
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__getitem__ 3\n")
            return self.__compute_item(key)
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__getitem__ 3\n")
        else:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__getitem__ 4\n")
            raise TypeError("list indices must be integers, not {0}".format(
                key.__class__.__name__))
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__getitem__ 4\n")
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__getitem__ 1\n")

    def __delitem__(self, key):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__delitem__ 1\n")
        if isinstance(key, slice):
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__delitem__ 2\n")
            indices = key.indices(len(self))
            offset = 0
            for i in range(*indices):
                sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__delitem__ 3\n")
                self.__del_item(i + offset)
                offset -= 1
                sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__delitem__ 3\n")
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__delitem__ 2\n")
        elif isinstance(key, int):
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__delitem__ 4\n")
            return self.__del_item(key)
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__delitem__ 4\n")
        else:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__delitem__ 5\n")
            raise TypeError("list indices must be integers, not {0}".format(
                key.__class__.__name__))
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__delitem__ 5\n")
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__delitem__ 1\n")

    def __contains__(self, item):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__contains__ 1\n")
        return self.contains(item)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__contains__ 1\n")

    def __add__(self, other):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__add__ 1\n")
        command = proto.LIST_COMMAND_NAME +\
            proto.LIST_CONCAT_SUBCOMMAND_NAME +\
            self._get_object_id() + "\n" + other._get_object_id() +\
            "\n" + proto.END_COMMAND_PART
        answer = self._gateway_client.send_command(command)
        return get_return_value(answer, self._gateway_client)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__add__ 1\n")

    def __radd__(self, other):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__radd__ 1\n")
        return self.__add__(other)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__radd__ 1\n")

    def __iadd__(self, other):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__iadd__ 1\n")
        self.extend(other)
        return self
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__iadd__ 1\n")

    def __mul__(self, other):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__mul__ 1\n")
        command = proto.LIST_COMMAND_NAME + proto.LIST_MULT_SUBCOMMAND_NAME +\
            self._get_object_id() + "\n" + get_command_part(other) +\
            proto.END_COMMAND_PART
        answer = self._gateway_client.send_command(command)
        return get_return_value(answer, self._gateway_client)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__mul__ 1\n")

    def __rmul__(self, other):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__rmul__ 1\n")
        return self.__mul__(other)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__rmul__ 1\n")

    def __imul__(self, other):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__imul__ 1\n")
        command = proto.LIST_COMMAND_NAME +\
            proto.LIST_IMULT_SUBCOMMAND_NAME +\
            self._get_object_id() + "\n" + get_command_part(other) +\
            proto.END_COMMAND_PART
        self._gateway_client.send_command(command)
        return self
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__imul__ 1\n")

    def append(self, value):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.append 1\n")
        self.add(value)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.append 1\n")

    def insert(self, key, value):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.insert 1\n")
        if isinstance(key, int):
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.insert 2\n")
            new_key = self.__compute_index(key, True)
            return self.add(new_key, value)
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.insert 2\n")
        else:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.insert 3\n")
            raise TypeError("list indices must be integers, not {0}".format(
                key.__class__.__name__))
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.insert 3\n")
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.insert 1\n")

    def extend(self, other_list):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.extend 1\n")
        self.addAll(other_list)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.extend 1\n")

    def pop(self, key=None):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.pop 1\n")
        if key is None:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.pop 2\n")
            new_key = self.size() - 1
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.pop 2\n")
        else:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.pop 3\n")
            new_key = self.__compute_index(key)
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.pop 3\n")
        return self.java_remove(new_key)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.pop 1\n")

    def index(self, value):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.index 1\n")
        return self.indexOf(value)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.index 1\n")

    def count(self, value):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.count 1\n")
        command = proto.LIST_COMMAND_NAME +\
            proto.LIST_COUNT_SUBCOMMAND_NAME +\
            self._get_object_id() + "\n" + get_command_part(value) +\
            proto.END_COMMAND_PART
        answer = self._gateway_client.send_command(command)
        return get_return_value(answer, self._gateway_client)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.count 1\n")

    def sort(self):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.sort 1\n")
        command = proto.LIST_COMMAND_NAME + proto.LIST_SORT_SUBCOMMAND_NAME +\
            self._get_object_id() + "\n" + proto.END_COMMAND_PART
        self._gateway_client.send_command(command)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.sort 1\n")

    def reverse(self):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.reverse 1\n")
        command = proto.LIST_COMMAND_NAME +\
            proto.LIST_REVERSE_SUBCOMMAND_NAME +\
            self._get_object_id() + "\n" + proto.END_COMMAND_PART
        self._gateway_client.send_command(command)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.reverse 1\n")

    def remove(self, value):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.remove 1\n")
        # Ensures that we are deleting the int value and not the index
        # (Java API)
        if isinstance(value, int):
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.remove 2\n")
            new_value = self.indexOf(value)
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.remove 2\n")
        else:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.remove 3\n")
            new_value = value
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.remove 3\n")
        success = self.java_remove(new_value)
        if not success:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.remove 4\n")
            raise ValueError("java_list.remove(x): x not in java_list")
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.remove 4\n")
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.remove 1\n")

    def __str__(self):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__str__ 1\n")
        return self.__repr__()
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__str__ 1\n")

    def __repr__(self):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter JavaList.__repr__ 1\n")
        items = (repr(x) for x in self)
        return "[{0}]".format(", ".join(items))
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit JavaList.__repr__ 1\n")


class SetConverter(object):
    def can_convert(self, object):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter SetConverter.can_convert 1\n")
        return isinstance(object, Set)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit SetConverter.can_convert 1\n")

    def convert(self, object, gateway_client):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter SetConverter.convert 1\n")
        JavaSet = JavaClass("java.util.HashSet", gateway_client)
        java_set = JavaSet()
        for element in object:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter SetConverter.convert 2\n")
            java_set.add(element)
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit SetConverter.convert 2\n")
        return java_set
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit SetConverter.convert 1\n")


class ListConverter(object):
    def can_convert(self, object):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter ListConverter.can_convert 1\n")
        # Check for iterator protocol and should not be an instance of byte
        # array (taken care of by protocol)
        return hasattr2(object, "__iter__") and not isbytearray(object) and\
            not ispython3bytestr(object) and not isinstance(object, basestring)
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit ListConverter.can_convert 1\n")

    def convert(self, object, gateway_client):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter ListConverter.convert 1\n")
        ArrayList = JavaClass("java.util.ArrayList", gateway_client)
        java_list = ArrayList()
        for element in object:
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter ListConverter.convert 2\n")
            java_list.add(element)
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit ListConverter.convert 2\n")
        return java_list
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit ListConverter.convert 1\n")


class MapConverter(object):
    def can_convert(self, object):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter MapConverter.can_convert 1\n")
        return hasattr2(object, "keys") and hasattr2(object, "__getitem__")
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit MapConverter.can_convert 1\n")

    def convert(self, object, gateway_client):
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter MapConverter.convert 1\n")
        HashMap = JavaClass("java.util.HashMap", gateway_client)
        java_map = HashMap()
        for key in object.keys():
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter MapConverter.convert 2\n")
            java_map[key] = object[key]
            sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit MapConverter.convert 2\n")
        return java_map
        sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit MapConverter.convert 1\n")


sys.stderr.write("[py4j-python/src/py4j/java_collections.py] enter module 1\n")
register_input_converter(SetConverter())
register_input_converter(MapConverter())
register_input_converter(ListConverter())

register_output_converter(
    proto.MAP_TYPE, lambda target_id, gateway_client:
    JavaMap(target_id, gateway_client))
register_output_converter(
    proto.LIST_TYPE, lambda target_id, gateway_client:
    JavaList(target_id, gateway_client))
register_output_converter(
    proto.ARRAY_TYPE, lambda target_id, gateway_client:
    JavaArray(target_id, gateway_client))
register_output_converter(
    proto.SET_TYPE, lambda target_id, gateway_client:
    JavaSet(target_id, gateway_client))
register_output_converter(
    proto.ITERATOR_TYPE, lambda target_id, gateway_client:
    JavaIterator(target_id, gateway_client))
sys.stderr.write("[py4j-python/src/py4j/java_collections.py] exit module 1\n")
# Total cost: 0.193039
# Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 551)]
# Total instrumented cost: 0.193039, input tokens: 7697, output tokens: 10387, cache read tokens: 2280, cache write tokens: 5413

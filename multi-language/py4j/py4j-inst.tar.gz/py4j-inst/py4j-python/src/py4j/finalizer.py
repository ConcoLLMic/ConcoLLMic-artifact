# -*- coding: UTF-8 -*-
"""
Module that defines a Finalizer class responsible for registering and cleaning
finalizer

Created on Mar 7, 2010

:author: Barthelemy Dagenais
"""
from __future__ import unicode_literals, absolute_import
import sys

from threading import RLock

from py4j.compat import items


class ThreadSafeFinalizer(object):
    """A `ThreadSafeFinalizer` is a global class used to register weak
    reference finalizers (i.e., a weak reference with a callback).

    This class is useful when one wants to register a finalizer of an object
    with circular references.  The finalizer of an object with circular
    references might never be called if the object's finalizer is kept by the
    same object.

    For example, if object A refers to B and B refers to A, A should not keep a
    weak reference to itself.

    `ThreadSafeFinalizer` is thread-safe and uses reentrant lock on each
    operation."""

    finalizers = {}
    lock = RLock()

    @classmethod
    def add_finalizer(cls, id, weak_ref):
        """Registers a finalizer with an id.

        :param id: The id of the object referenced by the weak reference.
        :param weak_ref: The weak reference to register.
        """
        sys.stderr.write("[py4j-python/src/py4j/finalizer.py] enter ThreadSafeFinalizer.add_finalizer 1\n")
        with cls.lock:
            sys.stderr.write("[py4j-python/src/py4j/finalizer.py] enter ThreadSafeFinalizer.add_finalizer 2\n")
            cls.finalizers[id] = weak_ref
            sys.stderr.write("[py4j-python/src/py4j/finalizer.py] exit ThreadSafeFinalizer.add_finalizer 2\n")
        sys.stderr.write("[py4j-python/src/py4j/finalizer.py] exit ThreadSafeFinalizer.add_finalizer 1\n")

    @classmethod
    def remove_finalizer(cls, id):
        """Removes a finalizer associated with this id.

        :param id: The id of the object for which the finalizer will be
            deleted.
        """
        sys.stderr.write("[py4j-python/src/py4j/finalizer.py] enter ThreadSafeFinalizer.remove_finalizer 1\n")
        with cls.lock:
            sys.stderr.write("[py4j-python/src/py4j/finalizer.py] enter ThreadSafeFinalizer.remove_finalizer 2\n")
            cls.finalizers.pop(id, None)
            sys.stderr.write("[py4j-python/src/py4j/finalizer.py] exit ThreadSafeFinalizer.remove_finalizer 2\n")
        sys.stderr.write("[py4j-python/src/py4j/finalizer.py] exit ThreadSafeFinalizer.remove_finalizer 1\n")

    @classmethod
    def clear_finalizers(cls, clear_all=False):
        """Removes all registered finalizers.

        :param clear_all: If `True`, all finalizers are deleted. Otherwise,
            only the finalizers from an empty weak reference are deleted
            (i.e., weak references pointing to inexistent objects).
        """
        sys.stderr.write("[py4j-python/src/py4j/finalizer.py] enter ThreadSafeFinalizer.clear_finalizers 1\n")
        with cls.lock:
            sys.stderr.write("[py4j-python/src/py4j/finalizer.py] enter ThreadSafeFinalizer.clear_finalizers 2\n")
            if clear_all:
                sys.stderr.write("[py4j-python/src/py4j/finalizer.py] enter ThreadSafeFinalizer.clear_finalizers 3\n")
                cls.finalizers.clear()
                sys.stderr.write("[py4j-python/src/py4j/finalizer.py] exit ThreadSafeFinalizer.clear_finalizers 3\n")
            else:
                sys.stderr.write("[py4j-python/src/py4j/finalizer.py] enter ThreadSafeFinalizer.clear_finalizers 4\n")
                for id, ref in items(cls.finalizers):
                    sys.stderr.write("[py4j-python/src/py4j/finalizer.py] enter ThreadSafeFinalizer.clear_finalizers 5\n")
                    if ref() is None:
                        sys.stderr.write("[py4j-python/src/py4j/finalizer.py] enter ThreadSafeFinalizer.clear_finalizers 6\n")
                        cls.finalizers.pop(id, None)
                        sys.stderr.write("[py4j-python/src/py4j/finalizer.py] exit ThreadSafeFinalizer.clear_finalizers 6\n")
                    sys.stderr.write("[py4j-python/src/py4j/finalizer.py] exit ThreadSafeFinalizer.clear_finalizers 5\n")
                sys.stderr.write("[py4j-python/src/py4j/finalizer.py] exit ThreadSafeFinalizer.clear_finalizers 4\n")
            sys.stderr.write("[py4j-python/src/py4j/finalizer.py] exit ThreadSafeFinalizer.clear_finalizers 2\n")
        sys.stderr.write("[py4j-python/src/py4j/finalizer.py] exit ThreadSafeFinalizer.clear_finalizers 1\n")


class Finalizer(object):
    """A `Finalizer` is a global class used to register weak reference finalizers
    (i.e., a weak reference with a callback).

    This class is useful when one wants to register a finalizer of an object
    with circular references.  The finalizer of an object with circular
    references might never be called if the object's finalizer is kept by the
    same object.

    For example, if object A refers to B and B refers to A, A should not keep a
    weak reference to itself.

    `Finalizer` is not thread-safe and should only be used by single-threaded
    programs."""

    finalizers = {}

    @classmethod
    def add_finalizer(cls, id, weak_ref):
        """Registers a finalizer with an id.

        :param id: The id of the object referenced by the weak reference.
        :param weak_ref: The weak reference to register.
        """
        sys.stderr.write("[py4j-python/src/py4j/finalizer.py] enter Finalizer.add_finalizer 1\n")
        cls.finalizers[id] = weak_ref
        sys.stderr.write("[py4j-python/src/py4j/finalizer.py] exit Finalizer.add_finalizer 1\n")

    @classmethod
    def remove_finalizer(cls, id):
        """Removes a finalizer associated with this id.

        :param id: The id of the object for which the finalizer will be
            deleted.
        """
        sys.stderr.write("[py4j-python/src/py4j/finalizer.py] enter Finalizer.remove_finalizer 1\n")
        cls.finalizers.pop(id, None)
        sys.stderr.write("[py4j-python/src/py4j/finalizer.py] exit Finalizer.remove_finalizer 1\n")

    @classmethod
    def clear_finalizers(cls, clear_all=False):
        """Removes all registered finalizers.

        :param clear_all: If `True`, all finalizers are deleted. Otherwise,
            only the finalizers from an empty weak reference are deleted (i.e.,
            weak references pointing to inexistent objects).

        """
        sys.stderr.write("[py4j-python/src/py4j/finalizer.py] enter Finalizer.clear_finalizers 1\n")
        if clear_all:
            sys.stderr.write("[py4j-python/src/py4j/finalizer.py] enter Finalizer.clear_finalizers 2\n")
            cls.finalizers.clear()
            sys.stderr.write("[py4j-python/src/py4j/finalizer.py] exit Finalizer.clear_finalizers 2\n")
        else:
            sys.stderr.write("[py4j-python/src/py4j/finalizer.py] enter Finalizer.clear_finalizers 3\n")
            for id, ref in items(cls.finalizers):
                sys.stderr.write("[py4j-python/src/py4j/finalizer.py] enter Finalizer.clear_finalizers 4\n")
                if ref() is None:
                    sys.stderr.write("[py4j-python/src/py4j/finalizer.py] enter Finalizer.clear_finalizers 5\n")
                    cls.finalizers.pop(id, None)
                    sys.stderr.write("[py4j-python/src/py4j/finalizer.py] exit Finalizer.clear_finalizers 5\n")
                sys.stderr.write("[py4j-python/src/py4j/finalizer.py] exit Finalizer.clear_finalizers 4\n")
            sys.stderr.write("[py4j-python/src/py4j/finalizer.py] exit Finalizer.clear_finalizers 3\n")
        sys.stderr.write("[py4j-python/src/py4j/finalizer.py] exit Finalizer.clear_finalizers 1\n")


def clear_finalizers(clear_all=False):
    """Removes all registered finalizers in :class:`ThreadSafeFinalizer` and
    :class:`Finalizer`.

    :param clear_all: If `True`, all finalizers are deleted. Otherwise, only
        the finalizers from an empty weak reference are deleted (i.e., weak
        references pointing to inexistent objects).

    """
    sys.stderr.write("[py4j-python/src/py4j/finalizer.py] enter clear_finalizers 1\n")
    ThreadSafeFinalizer.clear_finalizers(clear_all)
    Finalizer.clear_finalizers(clear_all)
    sys.stderr.write("[py4j-python/src/py4j/finalizer.py] exit clear_finalizers 1\n")
# Total cost: 0.038881
# Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 134)]
# Total instrumented cost: 0.038881, input tokens: 3481, output tokens: 2007, cache read tokens: 2280, cache write tokens: 1197

# coding: utf-8
"""
Compatibility functions for unified behavior between Python 2.x and 3.x.

:author: Alex Grönholm
"""
from __future__ import unicode_literals, absolute_import

import inspect
import sys
from threading import Thread

version_info = sys.version_info

if version_info.major < 3:
    sys.stderr.write("[py4j-python/src/py4j/compat.py] enter module 1\n")
    def items(d):
        sys.stderr.write("[py4j-python/src/py4j/compat.py] enter items 1\n")
        return d.items()
        sys.stderr.write("[py4j-python/src/py4j/compat.py] exit items 1\n")

    def iteritems(d):
        sys.stderr.write("[py4j-python/src/py4j/compat.py] enter iteritems 1\n")
        return d.iteritems()
        sys.stderr.write("[py4j-python/src/py4j/compat.py] exit iteritems 1\n")

    def next(x):
        sys.stderr.write("[py4j-python/src/py4j/compat.py] enter next 1\n")
        return x.next()
        sys.stderr.write("[py4j-python/src/py4j/compat.py] exit next 1\n")

    range = xrange  # noqa

    long = long  # noqa

    basestring = basestring  # noqa

    unicode = unicode  # noqa

    bytearray2 = bytearray

    unichr = unichr  # noqa

    bytestr = str

    tobytestr = str

    def isbytestr(s):
        sys.stderr.write("[py4j-python/src/py4j/compat.py] enter isbytestr 1\n")
        return isinstance(s, str)
        sys.stderr.write("[py4j-python/src/py4j/compat.py] exit isbytestr 1\n")

    def ispython3bytestr(s):
        sys.stderr.write("[py4j-python/src/py4j/compat.py] enter ispython3bytestr 1\n")
        return False
        sys.stderr.write("[py4j-python/src/py4j/compat.py] exit ispython3bytestr 1\n")

    def isbytearray(s):
        sys.stderr.write("[py4j-python/src/py4j/compat.py] enter isbytearray 1\n")
        return isinstance(s, bytearray)
        sys.stderr.write("[py4j-python/src/py4j/compat.py] exit isbytearray 1\n")

    def bytetoint(b):
        sys.stderr.write("[py4j-python/src/py4j/compat.py] enter bytetoint 1\n")
        return ord(b)
        sys.stderr.write("[py4j-python/src/py4j/compat.py] exit bytetoint 1\n")

    def bytetostr(b):
        sys.stderr.write("[py4j-python/src/py4j/compat.py] enter bytetostr 1\n")
        return b
        sys.stderr.write("[py4j-python/src/py4j/compat.py] exit bytetostr 1\n")

    def strtobyte(b):
        sys.stderr.write("[py4j-python/src/py4j/compat.py] enter strtobyte 1\n")
        return b
        sys.stderr.write("[py4j-python/src/py4j/compat.py] exit strtobyte 1\n")

    import Queue
    Empty = Queue.Empty
    Queue = Queue.Queue
    sys.stderr.write("[py4j-python/src/py4j/compat.py] exit module 1\n")

else:
    sys.stderr.write("[py4j-python/src/py4j/compat.py] enter module 2\n")
    def items(d):
        sys.stderr.write("[py4j-python/src/py4j/compat.py] enter items 2\n")
        return list(d.items())
        sys.stderr.write("[py4j-python/src/py4j/compat.py] exit items 2\n")

    def iteritems(d):
        sys.stderr.write("[py4j-python/src/py4j/compat.py] enter iteritems 2\n")
        return d.items()
        sys.stderr.write("[py4j-python/src/py4j/compat.py] exit iteritems 2\n")

    next = next

    range = range

    long = int

    basestring = str

    unicode = str

    bytearray2 = bytes

    unichr = chr

    bytestr = bytes

    def tobytestr(s):
        sys.stderr.write("[py4j-python/src/py4j/compat.py] enter tobytestr 2\n")
        return bytes(s, "ascii")
        sys.stderr.write("[py4j-python/src/py4j/compat.py] exit tobytestr 2\n")

    def isbytestr(s):
        sys.stderr.write("[py4j-python/src/py4j/compat.py] enter isbytestr 2\n")
        return isinstance(s, bytes)
        sys.stderr.write("[py4j-python/src/py4j/compat.py] exit isbytestr 2\n")

    def ispython3bytestr(s):
        sys.stderr.write("[py4j-python/src/py4j/compat.py] enter ispython3bytestr 2\n")
        return isinstance(s, bytes)
        sys.stderr.write("[py4j-python/src/py4j/compat.py] exit ispython3bytestr 2\n")

    def isbytearray(s):
        sys.stderr.write("[py4j-python/src/py4j/compat.py] enter isbytearray 2\n")
        return isinstance(s, bytearray)
        sys.stderr.write("[py4j-python/src/py4j/compat.py] exit isbytearray 2\n")

    def bytetoint(b):
        sys.stderr.write("[py4j-python/src/py4j/compat.py] enter bytetoint 2\n")
        return b
        sys.stderr.write("[py4j-python/src/py4j/compat.py] exit bytetoint 2\n")

    def bytetostr(b):
        sys.stderr.write("[py4j-python/src/py4j/compat.py] enter bytetostr 2\n")
        return str(b, encoding="ascii")
        sys.stderr.write("[py4j-python/src/py4j/compat.py] exit bytetostr 2\n")

    def strtobyte(s):
        sys.stderr.write("[py4j-python/src/py4j/compat.py] enter strtobyte 2\n")
        return bytes(s, encoding="ascii")
        sys.stderr.write("[py4j-python/src/py4j/compat.py] exit strtobyte 2\n")

    import queue
    Queue = queue.Queue
    Empty = queue.Empty
    sys.stderr.write("[py4j-python/src/py4j/compat.py] exit module 2\n")


if hasattr(inspect, "getattr_static"):
    sys.stderr.write("[py4j-python/src/py4j/compat.py] enter module 3\n")
    def hasattr2(obj, attr):
        sys.stderr.write("[py4j-python/src/py4j/compat.py] enter hasattr2 1\n")
        return bool(inspect.getattr_static(obj, attr, False))
        sys.stderr.write("[py4j-python/src/py4j/compat.py] exit hasattr2 1\n")
    sys.stderr.write("[py4j-python/src/py4j/compat.py] exit module 3\n")
else:
    sys.stderr.write("[py4j-python/src/py4j/compat.py] enter module 4\n")
    hasattr2 = hasattr
    sys.stderr.write("[py4j-python/src/py4j/compat.py] exit module 4\n")


class CompatThread(Thread):
    """Compatibility Thread class.

    Allows Python 2 Thread class to accept daemon kwarg in init.
    """

    def __init__(self, *args, **kwargs):
        sys.stderr.write("[py4j-python/src/py4j/compat.py] enter CompatThread.__init__ 1\n")
        daemon = None
        try:
            sys.stderr.write("[py4j-python/src/py4j/compat.py] enter CompatThread.__init__ 2\n")
            daemon = kwargs.pop("daemon")
            sys.stderr.write("[py4j-python/src/py4j/compat.py] exit CompatThread.__init__ 2\n")
        except KeyError:
            sys.stderr.write("[py4j-python/src/py4j/compat.py] enter CompatThread.__init__ 3\n")
            pass
            sys.stderr.write("[py4j-python/src/py4j/compat.py] exit CompatThread.__init__ 3\n")
        super(CompatThread, self).__init__(*args, **kwargs)

        if daemon:
            sys.stderr.write("[py4j-python/src/py4j/compat.py] enter CompatThread.__init__ 4\n")
            self.daemon = daemon
            sys.stderr.write("[py4j-python/src/py4j/compat.py] exit CompatThread.__init__ 4\n")
        sys.stderr.write("[py4j-python/src/py4j/compat.py] exit CompatThread.__init__ 1\n")
# Total cost: 0.031350
# Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 134)]
# Total instrumented cost: 0.031350, input tokens: 3072, output tokens: 1689, cache read tokens: 2280, cache write tokens: 788

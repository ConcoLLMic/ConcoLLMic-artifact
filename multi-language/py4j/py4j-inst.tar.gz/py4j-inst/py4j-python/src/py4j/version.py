__version__ = '0.10.9.9'
# Total cost: 0.001561
# Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 1)]
# Total instrumented cost: 0.001561, input tokens: 2361, output tokens: 23, cache read tokens: 2280, cache write tokens: 77

# Py4J Package
from __future__ import absolute_import
from . import version

__version__ = version.__version__
# Total cost: 0.001669
# Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 5)]
# Total instrumented cost: 0.001669, input tokens: 2377, output tokens: 23, cache read tokens: 2280, cache write tokens: 93

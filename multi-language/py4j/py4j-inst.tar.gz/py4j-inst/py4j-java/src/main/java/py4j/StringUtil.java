/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j;

/**
 * <p>
 * String utility class providing operations to escape and unescape new lines.
 * </p>
 *
 * @author Barthelemy Dagenais
 *
 */
public class StringUtil {

	public final static char ESCAPE_CHAR = '\\';

	public static String escape(String original) {
		if (original != null) {
			return original.replace("\\", "\\\\").replace("\r", "\\r").replace("\n", "\\n");
		} else {
			return null;
		}
	}

	public static String unescape(String escaped) {
		System.err.println("[py4j-java/src/main/java/py4j/StringUtil.java] enter unescape 1");
		boolean escaping = false;
		StringBuilder newString = new StringBuilder();

		for (char c : escaped.toCharArray()) {
			System.err.println("[py4j-java/src/main/java/py4j/StringUtil.java] enter unescape 2");
			if (!escaping) {
				System.err.println("[py4j-java/src/main/java/py4j/StringUtil.java] enter unescape 3");
				if (c == ESCAPE_CHAR) {
					System.err.println("[py4j-java/src/main/java/py4j/StringUtil.java] enter unescape 4");
					escaping = true;
					System.err.println("[py4j-java/src/main/java/py4j/StringUtil.java] exit unescape 4");
				} else {
					System.err.println("[py4j-java/src/main/java/py4j/StringUtil.java] enter unescape 5");
					newString.append(c);
					System.err.println("[py4j-java/src/main/java/py4j/StringUtil.java] exit unescape 5");
				}
				System.err.println("[py4j-java/src/main/java/py4j/StringUtil.java] exit unescape 3");
			} else {
				System.err.println("[py4j-java/src/main/java/py4j/StringUtil.java] enter unescape 6");
				if (c == 'n') {
					System.err.println("[py4j-java/src/main/java/py4j/StringUtil.java] enter unescape 7");
					newString.append('\n');
					System.err.println("[py4j-java/src/main/java/py4j/StringUtil.java] exit unescape 7");
				} else if (c == 'r') {
					System.err.println("[py4j-java/src/main/java/py4j/StringUtil.java] enter unescape 8");
					newString.append('\r');
					System.err.println("[py4j-java/src/main/java/py4j/StringUtil.java] exit unescape 8");
				} else {
					System.err.println("[py4j-java/src/main/java/py4j/StringUtil.java] enter unescape 9");
					newString.append(c);
					System.err.println("[py4j-java/src/main/java/py4j/StringUtil.java] exit unescape 9");
				}
				escaping = false;
				System.err.println("[py4j-java/src/main/java/py4j/StringUtil.java] exit unescape 6");
			}
			System.err.println("[py4j-java/src/main/java/py4j/StringUtil.java] exit unescape 2");
		}

		System.err.println("[py4j-java/src/main/java/py4j/StringUtil.java] exit unescape 1");
		return newString.toString();
	}
}
// Total cost: 0.037274
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 78)]
// Total instrumented cost: 0.037274, input tokens: 3082, output tokens: 1099, cache read tokens: 0, cache write tokens: 3078

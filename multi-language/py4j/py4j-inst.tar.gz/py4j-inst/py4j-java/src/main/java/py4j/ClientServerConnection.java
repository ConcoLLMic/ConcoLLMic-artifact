/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import py4j.commands.AuthCommand;
import py4j.commands.Command;

public class ClientServerConnection implements Py4JServerConnection, Py4JClientConnection, Runnable {

	private boolean used = false;
	private boolean initiatedFromClient = false;
	protected Socket socket;
	protected BufferedWriter writer;
	protected BufferedReader reader;
	protected final Map<String, Command> commands;
	protected final Logger logger = Logger.getLogger(ClientServerConnection.class.getName());
	protected final Py4JJavaServer javaServer;
	protected final Py4JPythonClientPerThread pythonClient;
	protected final int blockingReadTimeout;
	protected final int nonBlockingReadTimeout;
	protected final String authToken;
	protected final AuthCommand authCommand;
	// Used to terminate the JVM process on command cancellation.
	protected Thread jvmThread;

	public ClientServerConnection(Gateway gateway, Socket socket, List<Class<? extends Command>> customCommands,
			Py4JPythonClientPerThread pythonClient, Py4JJavaServer javaServer, int readTimeout) throws IOException {
		this(gateway, socket, customCommands, pythonClient, javaServer, readTimeout, null);
	}

	public ClientServerConnection(Gateway gateway, Socket socket, List<Class<? extends Command>> customCommands,
			Py4JPythonClientPerThread pythonClient, Py4JJavaServer javaServer, int readTimeout, String authToken)
					throws IOException {
		super();
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter ClientServerConnection 2");
		this.socket = socket;
		this.reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), Charset.forName("UTF-8")));
		this.writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), Charset.forName("UTF-8")));
		this.commands = new HashMap<String, Command>();
		initCommands(gateway, GatewayConnection.getBaseCommands());
		if (customCommands != null) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter ClientServerConnection 3");
			initCommands(gateway, customCommands);
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit ClientServerConnection 3");
		}
		this.javaServer = javaServer;
		this.pythonClient = pythonClient;
		this.blockingReadTimeout = readTimeout;
		if (readTimeout > 0) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter ClientServerConnection 4");
			this.nonBlockingReadTimeout = readTimeout;
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit ClientServerConnection 4");
		} else {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter ClientServerConnection 5");
			this.nonBlockingReadTimeout = CallbackConnection.DEFAULT_NONBLOCKING_SO_TIMEOUT;
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit ClientServerConnection 5");
		}
		this.authToken = authToken;
		if (authToken != null) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter ClientServerConnection 6");
			this.authCommand = new AuthCommand(authToken);
			initCommand(gateway, authCommand);
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit ClientServerConnection 6");
		} else {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter ClientServerConnection 7");
			this.authCommand = null;
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit ClientServerConnection 7");
		}
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit ClientServerConnection 2");
	}

	public void startServerConnection() throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter startServerConnection 1");
		jvmThread = new Thread(this);
		jvmThread.start();
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit startServerConnection 1");
	}

	public void run() {
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter run 1");
		pythonClient.setPerThreadConnection(this);
		waitForCommands();
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit run 1");
	}

	/**
	 * <p>
	 * Override this method to initialize custom commands.
	 * </p>
	 *
	 * @param gateway
	 * @param commandsClazz
	 */
	protected void initCommands(Gateway gateway, List<Class<? extends Command>> commandsClazz) {
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter initCommands 1");
		for (Class<? extends Command> clazz : commandsClazz) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter initCommands 2");
			try {
				System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter initCommands 3");
				Command cmd = clazz.newInstance();
				initCommand(gateway, cmd);
				System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit initCommands 3");
			} catch (Exception e) {
				System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter initCommands 4");
				String name = "null";
				if (clazz != null) {
					System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter initCommands 5");
					name = clazz.getName();
					System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit initCommands 5");
				}
				logger.log(Level.SEVERE, "Could not initialize command " + name, e);
				System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit initCommands 4");
			}
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit initCommands 2");
		}
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit initCommands 1");
	}

	private void initCommand(Gateway gateway, Command cmd) {
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter initCommand 1");
		cmd.init(gateway, this);
		commands.put(cmd.getCommandName(), cmd);
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit initCommand 1");
	}

	protected void fireConnectionStopped() {
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter fireConnectionStopped 1");
		logger.info("Connection Stopped");

		for (GatewayServerListener listener : javaServer.getListeners()) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter fireConnectionStopped 2");
			try {
				System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter fireConnectionStopped 3");
				listener.connectionStopped(this);
				System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit fireConnectionStopped 3");
			} catch (Exception e) {
				System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter fireConnectionStopped 4");
				logger.log(Level.SEVERE, "A listener crashed.", e);
				System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit fireConnectionStopped 4");
			}
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit fireConnectionStopped 2");
		}
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit fireConnectionStopped 1");
	}

	protected void quietSendFatalError(BufferedWriter writer, Throwable exception) {
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter quietSendFatalError 1");
		try {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter quietSendFatalError 2");
			String returnCommand = Protocol.getOutputFatalErrorCommand(exception);
			logger.fine("Trying to return error: " + returnCommand);
			writer.write(returnCommand);
			writer.flush();
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit quietSendFatalError 2");
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter quietSendFatalError 3");
			logger.log(Level.FINEST, "Error in quiet send.", e);
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit quietSendFatalError 3");
		}
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit quietSendFatalError 1");
	}

	@Override
	public Socket getSocket() {
		return socket;
	}

	public void waitForCommands() {
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter waitForCommands 1");
		boolean reset = false;
		boolean executing = false;
		Throwable error = null;
		try {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter waitForCommands 2");
			logger.info("Gateway Connection ready to receive messages");
			String commandLine = null;
			do {
				System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter waitForCommands 3");
				commandLine = reader.readLine();
				executing = true;
				logger.fine("Received command: " + commandLine);
				Command command = commands.get(commandLine);

				if (command != null) {
					System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter waitForCommands 4");
					if (authCommand != null && !authCommand.isAuthenticated()) {
						System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter waitForCommands 5");
						authCommand.execute(commandLine, reader, writer);
						System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit waitForCommands 5");
					} else {
						System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter waitForCommands 6");
						command.execute(commandLine, reader, writer);
						System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit waitForCommands 6");
					}
					executing = false;
					System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit waitForCommands 4");
				} else {
					System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter waitForCommands 7");
					reset = true;
					System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit waitForCommands 7");
					throw new Py4JException("Unknown command received: " + commandLine);
				}
				System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit waitForCommands 3");
			} while (commandLine != null && !commandLine.equals("q"));
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit waitForCommands 2");
		} catch (SocketTimeoutException ste) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter waitForCommands 8");
			logger.log(Level.WARNING, "Timeout occurred while waiting for a command.", ste);
			reset = true;
			error = ste;
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit waitForCommands 8");
		} catch (Py4JAuthenticationException pae) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter waitForCommands 9");
			logger.log(Level.SEVERE, "Authentication error.", pae);
			// We do not store the error because we do not want to
			// send a message to the other side.
			reset = true;
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit waitForCommands 9");
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter waitForCommands 10");
			logger.log(Level.WARNING, "Error occurred while waiting for a command.", e);
			error = e;
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit waitForCommands 10");
		} finally {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter waitForCommands 11");
			if (error != null && executing && writer != null) {
				System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter waitForCommands 12");
				quietSendFatalError(writer, error);
				System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit waitForCommands 12");
			}
			shutdown(reset);
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit waitForCommands 11");
		}
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit waitForCommands 1");
	}

	public String sendCommand(String command) {
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter sendCommand 1");
		String result = this.sendCommand(command, true);
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit sendCommand 1");
		return result;
	}

	public String sendCommand(String command, boolean blocking) {
		// TODO REFACTOR so that we use the same code in sendCommand and wait
		logger.log(Level.INFO, "Sending Python command: " + command);
		String returnCommand = null;
		try {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter sendCommand 3");
			writer.write(command);
			writer.flush();
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit sendCommand 3");
		} catch (Exception e) {
			throw new Py4JNetworkException("Error while sending a command: " + command, e,
					Py4JNetworkException.ErrorTime.ERROR_ON_SEND);
		}

		try {
			while (true) {
				System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter sendCommand 6");
				if (blocking) {
					System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter sendCommand 7");
					returnCommand = this.readBlockingResponse(this.reader);
					System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit sendCommand 7");
				} else {
					System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter sendCommand 8");
					returnCommand = this.readNonBlockingResponse(this.socket, this.reader);
					System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit sendCommand 8");
				}

				if (returnCommand == null || returnCommand.trim().equals("")) {
					// TODO LOG AND DO SOMETHING INTELLIGENT
					throw new Py4JException("Received empty command");
				} else if (Protocol.isReturnMessage(returnCommand)) {
					System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter sendCommand 10");
					returnCommand = returnCommand.substring(1);
					logger.log(Level.INFO, "Returning CB command: " + returnCommand);
					System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit sendCommand 10");
					return returnCommand;
				} else {
					System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter sendCommand 11");
					Command commandObj = commands.get(returnCommand);
					if (commandObj != null) {
						System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter sendCommand 12");
						commandObj.execute(returnCommand, reader, writer);
						System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit sendCommand 12");
					} else {
						System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter sendCommand 13");
						logger.log(Level.WARNING, "Unknown command " + returnCommand);
						// TODO SEND BACK AN ERROR?
						System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit sendCommand 13");
					}
					System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit sendCommand 11");
				}
				System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit sendCommand 6");
			}
		} catch (Exception e) {
			// This will make sure that the connection is shut down and not given back to the connections deque.
			throw new Py4JNetworkException("Error while sending a command: " + command, e,
					Py4JNetworkException.ErrorTime.ERROR_ON_RECEIVE);
		}
	}

	@Override
	public void shutdown() {
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter shutdown 1");
		shutdown(false);
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit shutdown 1");
	}

	@Override
	public void shutdown(boolean reset) {
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter shutdown 2");
		if (reset) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter shutdown 3");
			NetworkUtil.quietlySetLinger(socket);
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit shutdown 3");
		}
		// XXX Close socket first, otherwise, reader.close() will block if stuck on readLine.
		NetworkUtil.quietlyClose(socket);
		NetworkUtil.quietlyClose(reader);
		NetworkUtil.quietlyClose(writer);
		socket = null;
		writer = null;
		reader = null;
		if (!initiatedFromClient) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter shutdown 4");
			// Only fires this event when the connection is created by the JavaServer to respect the protocol.
			fireConnectionStopped();
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit shutdown 4");
		}
		if (jvmThread != null && jvmThread.isAlive()) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter shutdown 5");
			jvmThread.interrupt();
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit shutdown 5");
		}
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit shutdown 2");
	}

	@Override
	public void start() throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter start 1");
		if (authToken != null) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter start 2");
			try {
				System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter start 3");
				// TODO should we receive an AuthException instead of an IOException?
				NetworkUtil.authToServer(reader, writer, authToken);
				System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit start 3");
			} catch (IOException ioe) {
				System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter start 4");
				shutdown(true);
				System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit start 4");
				throw ioe;
			}
			System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit start 2");
		}
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit start 1");
	}

	@Override
	public void setUsed(boolean used) {
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter setUsed 1");
		this.used = used;
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit setUsed 1");
	}

	@Override
	public boolean wasUsed() {
		return used;
	}

	public boolean isInitiatedFromClient() {
		return initiatedFromClient;
	}

	public void setInitiatedFromClient(boolean initiatedFromClient) {
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter setInitiatedFromClient 1");
		this.initiatedFromClient = initiatedFromClient;
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit setInitiatedFromClient 1");
	}

	protected String readBlockingResponse(BufferedReader reader) throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter readBlockingResponse 1");
		String result = reader.readLine();
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit readBlockingResponse 1");
		return result;
	}

	protected String readNonBlockingResponse(Socket socket, BufferedReader reader) throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter readNonBlockingResponse 1");
		String returnCommand = null;

		socket.setSoTimeout(nonBlockingReadTimeout);

		while (true) {
			try {
				System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter readNonBlockingResponse 3");
				returnCommand = reader.readLine();
				System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit readNonBlockingResponse 3");
				break;
			} finally {
				System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] enter readNonBlockingResponse 4");
				// Set back blocking timeout (necessary if
				// sockettimeoutexception is raised and propagated)
				socket.setSoTimeout(blockingReadTimeout);
				System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit readNonBlockingResponse 4");
			}
		}

		// Set back blocking timeout
		socket.setSoTimeout(blockingReadTimeout);

		System.err.println("[py4j-java/src/main/java/py4j/ClientServerConnection.java] exit readNonBlockingResponse 1");
		return returnCommand;
	}

}
// Total cost: 0.116807
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 343)]
// Total instrumented cost: 0.116807, input tokens: 5567, output tokens: 5283, cache read tokens: 0, cache write tokens: 5563

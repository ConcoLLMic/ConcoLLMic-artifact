/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j.commands;

import static py4j.NetworkUtil.safeReadLine;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Logger;

import py4j.Protocol;
import py4j.Py4JException;
import py4j.ReturnObject;

/**
 * <p>
 * A ListCommand is responsible for handling operations on lists (e.g.,
 * slicing).
 * </p>
 * 
 * @author Barthelemy Dagenais
 * 
 */
public class ListCommand extends AbstractCommand {

	private final Logger logger = Logger.getLogger(ListCommand.class.getName());

	public static final String LIST_COMMAND_NAME = "l";

	public static final char LIST_SORT_SUB_COMMAND_NAME = 's';
	public static final char LIST_REVERSE_SUB_COMMAND_NAME = 'r';
	public static final char LIST_MAX_SUB_COMMAND_NAME = 'x';
	public static final char LIST_MIN_SUB_COMMAND_NAME = 'n';
	public static final char LIST_SLICE_SUB_COMMAND_NAME = 'l';

	public static final char LIST_CONCAT_SUB_COMMAND_NAME = 'a';
	public static final char LIST_MULT_SUB_COMMAND_NAME = 'm';
	public static final char LIST_IMULT_SUB_COMMAND_NAME = 'i';
	public static final char LIST_COUNT_SUB_COMMAND_NAME = 'f';

	public static final String RETURN_VOID = Protocol.RETURN_MESSAGE + "" + Protocol.SUCCESS + "" + Protocol.VOID
			+ Protocol.END_OUTPUT;

	public ListCommand() {
		super();
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter ListCommand 1");
		this.commandName = LIST_COMMAND_NAME;
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit ListCommand 1");
	}

	@SuppressWarnings({ "rawtypes" })
	private String call_collections_method(BufferedReader reader, char listCommand) throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter call_collections_method 1");
		String returnCommand;
		String list_id = reader.readLine();

		// Read end of command
		reader.readLine();

		List list = (List) gateway.getObject(list_id);
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit call_collections_method 1");
		try {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter call_collections_method 2");
			if (listCommand == LIST_SORT_SUB_COMMAND_NAME) {
				System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter call_collections_method 3");
				returnCommand = sort_list(list);
				System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit call_collections_method 3");
			} else if (listCommand == LIST_REVERSE_SUB_COMMAND_NAME) {
				System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter call_collections_method 4");
				returnCommand = reverse_list(list);
				System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit call_collections_method 4");
			} else if (listCommand == LIST_MAX_SUB_COMMAND_NAME) {
				System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter call_collections_method 5");
				returnCommand = max_list(list);
				System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit call_collections_method 5");
			} else if (listCommand == LIST_MIN_SUB_COMMAND_NAME) {
				System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter call_collections_method 6");
				returnCommand = min_list(list);
				System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit call_collections_method 6");
			} else {
				System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter call_collections_method 7");
				returnCommand = Protocol.getOutputErrorCommand();
				System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit call_collections_method 7");
			}
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit call_collections_method 2");
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter call_collections_method 8");
			returnCommand = Protocol.getOutputErrorCommand();
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit call_collections_method 8");
		}
		return returnCommand;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private String concat_list(BufferedReader reader) throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter concat_list 1");
		List list1 = (List) gateway.getObject(reader.readLine());
		List list2 = (List) gateway.getObject(reader.readLine());
		// Read end
		reader.readLine();

		List list3 = new ArrayList(list1);
		list3.addAll(list2);
		ReturnObject returnObject = gateway.getReturnObject(list3);
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit concat_list 1");
		return Protocol.getOutputCommand(returnObject);
	}

	@SuppressWarnings("rawtypes")
	private String count_list(BufferedReader reader) throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter count_list 1");
		List list1 = (List) gateway.getObject(reader.readLine());
		Object objectToCount = Protocol.getObject(reader.readLine(), gateway);

		// Read end
		reader.readLine();

		int count = Collections.frequency(list1, objectToCount);
		ReturnObject returnObject = gateway.getReturnObject(count);
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit count_list 1");
		return Protocol.getOutputCommand(returnObject);
	}

	@Override
	public void execute(String commandName, BufferedReader reader, BufferedWriter writer)
			throws Py4JException, IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter execute 1");
		char subCommand = safeReadLine(reader).charAt(0);
		String returnCommand = null;
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit execute 1");
		if (subCommand == LIST_SLICE_SUB_COMMAND_NAME) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter execute 2");
			returnCommand = slice_list(reader);
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit execute 2");
		} else if (subCommand == LIST_CONCAT_SUB_COMMAND_NAME) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter execute 3");
			returnCommand = concat_list(reader);
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit execute 3");
		} else if (subCommand == LIST_MULT_SUB_COMMAND_NAME) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter execute 4");
			returnCommand = mult_list(reader);
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit execute 4");
		} else if (subCommand == LIST_IMULT_SUB_COMMAND_NAME) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter execute 5");
			returnCommand = imult_list(reader);
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit execute 5");
		} else if (subCommand == LIST_COUNT_SUB_COMMAND_NAME) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter execute 6");
			returnCommand = count_list(reader);
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit execute 6");
		} else {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter execute 7");
			returnCommand = call_collections_method(reader, subCommand);
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit execute 7");
		}

		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter execute 8");
		logger.finest("Returning command: " + returnCommand);
		writer.write(returnCommand);
		writer.flush();
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit execute 8");
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private String imult_list(BufferedReader reader) throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter imult_list 1");
		List list1 = (List) gateway.getObject(reader.readLine());
		List tempList = new ArrayList(list1.subList(0, list1.size()));
		int n = Protocol.getInteger(reader.readLine());
		// Read end
		reader.readLine();
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit imult_list 1");

		if (n <= 0) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter imult_list 2");
			list1.clear();
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit imult_list 2");
		} else {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter imult_list 3");
			for (int i = 1; i < n; i++) {
				System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter imult_list 4");
				list1.addAll(tempList);
				System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit imult_list 4");
			}
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit imult_list 3");
		}

		return RETURN_VOID;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private String max_list(List list) {
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter max_list 1");
		Object object = Collections.max(list);
		ReturnObject returnObject = gateway.getReturnObject(object);
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit max_list 1");
		return Protocol.getOutputCommand(returnObject);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private String min_list(List list) {
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter min_list 1");
		Object object = Collections.min(list);
		ReturnObject returnObject = gateway.getReturnObject(object);
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit min_list 1");
		return Protocol.getOutputCommand(returnObject);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private String mult_list(BufferedReader reader) throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter mult_list 1");
		List list1 = (List) gateway.getObject(reader.readLine());
		int n = Protocol.getInteger(reader.readLine());
		// Read end
		reader.readLine();

		List list2 = new ArrayList();
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit mult_list 1");
		for (int i = 0; i < n; i++) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter mult_list 2");
			list2.addAll(list1);
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit mult_list 2");
		}
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter mult_list 3");
		ReturnObject returnObject = gateway.getReturnObject(list2);
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit mult_list 3");
		return Protocol.getOutputCommand(returnObject);
	}

	@SuppressWarnings({ "rawtypes" })
	private String reverse_list(List list) {
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter reverse_list 1");
		Collections.reverse(list);
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit reverse_list 1");
		return RETURN_VOID;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private String slice_list(BufferedReader reader) throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter slice_list 1");
		List list1 = (List) gateway.getObject(reader.readLine());
		List<Object> arguments = getArguments(reader);
		List slice = new ArrayList();
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit slice_list 1");
		for (Object argument : arguments) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter slice_list 2");
			slice.add(list1.get((Integer) argument));
			System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit slice_list 2");
		}
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter slice_list 3");
		ReturnObject returnObject = gateway.getReturnObject(slice);
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit slice_list 3");
		return Protocol.getOutputCommand(returnObject);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private String sort_list(List list) {
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] enter sort_list 1");
		Collections.sort(list);
		System.err.println("[py4j-java/src/main/java/py4j/commands/ListCommand.java] exit sort_list 1");
		return RETURN_VOID;
	}

}
// Total cost: 0.069754
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 229)]
// Total instrumented cost: 0.069754, input tokens: 4806, output tokens: 3469, cache read tokens: 2280, cache write tokens: 2522

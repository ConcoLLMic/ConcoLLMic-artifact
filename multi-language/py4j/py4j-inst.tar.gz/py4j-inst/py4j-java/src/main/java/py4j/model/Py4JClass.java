/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j.model;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import py4j.reflection.TypeUtil;

/**
 * <p>
 * Model of a Java class used to create a help page.
 * </p>
 * 
 * @author Barthelemy Dagenais
 * 
 */
public class Py4JClass extends Py4JMember {

	public final static Py4JClass buildClass(Class<?> clazz) {
		return buildClass(clazz, true);
	}

	public final static Py4JClass buildClass(Class<?> clazz, boolean sort) {
		System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] enter buildClass 2");
		List<Py4JClass> classes = new ArrayList<Py4JClass>();
		List<Py4JMethod> methods = new ArrayList<Py4JMethod>();
		List<Py4JField> fields = new ArrayList<Py4JField>();
		System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] exit buildClass 2");

		for (Class<?> memberClass : clazz.getDeclaredClasses()) {
			System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] enter buildClass 3");
			if (Modifier.isPublic(memberClass.getModifiers())) {
				System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] enter buildClass 4");
				classes.add(Py4JClass.buildClass(memberClass, sort));
				System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] exit buildClass 4");
			}
			System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] exit buildClass 3");
		}

		for (Method method : clazz.getDeclaredMethods()) {
			System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] enter buildClass 5");
			if (Modifier.isPublic(method.getModifiers())) {
				System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] enter buildClass 6");
				methods.add(Py4JMethod.buildMethod(method));
				System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] exit buildClass 6");
			}
			System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] exit buildClass 5");
		}

		for (Field field : clazz.getDeclaredFields()) {
			System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] enter buildClass 7");
			if (Modifier.isPublic(field.getModifiers())) {
				System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] enter buildClass 8");
				fields.add(Py4JField.buildField(field));
				System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] exit buildClass 8");
			}
			System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] exit buildClass 7");
		}

		System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] enter buildClass 9");
		Class<?> superClass = clazz.getSuperclass();
		String extend = null;
		if (superClass != null && superClass != Object.class) {
			System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] enter buildClass 10");
			extend = superClass.getCanonicalName();
			System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] exit buildClass 10");
		}

		Class<?>[] interfaces = clazz.getInterfaces();
		List<String> implementTypes = interfaces != null && interfaces.length > 0 ? TypeUtil.getNames(interfaces)
				: null;

		if (sort) {
			System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] enter buildClass 11");
			Collections.sort(classes);
			Collections.sort(methods);
			Collections.sort(fields);
			System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] exit buildClass 11");
		}

		System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] exit buildClass 9");

		return new Py4JClass(clazz.getCanonicalName(), null, extend, implementTypes,
				Collections.unmodifiableList(methods), Collections.unmodifiableList(fields),
				Collections.unmodifiableList(classes));
	}

	private final String extendType;

	private final List<String> implementTypes;

	private final List<Py4JMethod> methods;

	private final List<Py4JField> fields;

	private final List<Py4JClass> classes;

	public Py4JClass(String name, String javadoc, String extendType, List<String> implementTypes,
			List<Py4JMethod> methods, List<Py4JField> fields, List<Py4JClass> classes) {
		super(name, javadoc);
		System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] enter Py4JClass 1");
		this.extendType = extendType;
		this.implementTypes = implementTypes;
		this.methods = methods;
		this.fields = fields;
		this.classes = classes;
		System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] exit Py4JClass 1");
	}

	public List<Py4JClass> getClasses() {
		return classes;
	}

	public String getExtendType() {
		return extendType;
	}

	public List<Py4JField> getFields() {
		return fields;
	}

	public List<String> getImplementTypes() {
		return implementTypes;
	}

	public List<Py4JMethod> getMethods() {
		return methods;
	}

	@Override
	public String getSignature(boolean shortName) {
		System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] enter getSignature 1");
		StringBuilder builder = new StringBuilder();

		builder.append(TypeUtil.getName(getName(), shortName));
		if (extendType != null) {
			System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] enter getSignature 2");
			builder.append(" extends ");
			builder.append(extendType);
			System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] exit getSignature 2");
		}

		if (implementTypes != null) {
			System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] enter getSignature 3");
			builder.append(" implements ");
			int length = implementTypes.size();
			for (int i = 0; i < length - 1; i++) {
				System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] enter getSignature 4");
				builder.append(implementTypes.get(i));
				builder.append(", ");
				System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] exit getSignature 4");
			}
			builder.append(implementTypes.get(length - 1));
			System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] exit getSignature 3");
		}
		System.err.println("[py4j-java/src/main/java/py4j/model/Py4JClass.java] exit getSignature 1");

		return builder.toString();
	}
}
// Total cost: 0.043975
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 160)]
// Total instrumented cost: 0.043975, input tokens: 3889, output tokens: 2163, cache read tokens: 2280, cache write tokens: 1605

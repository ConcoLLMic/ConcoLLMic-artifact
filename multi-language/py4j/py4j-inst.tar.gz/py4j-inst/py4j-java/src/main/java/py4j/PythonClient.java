/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.net.InetAddress;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import javax.net.SocketFactory;

import py4j.commands.Command;

/**
 * <p>
 * Subclass of CallbackClient that implements the new threading model,
 * ensuring that each thread uses its own connection.
 * </p>
 */
public class PythonClient extends CallbackClient implements Py4JPythonClientPerThread, GatewayServerListener {

	protected Gateway gateway;

	protected List<Class<? extends Command>> customCommands;

	protected final Logger logger = Logger.getLogger(PythonClient.class.getName());

	protected Py4JJavaServer javaServer;

	protected ThreadLocal<WeakReference<ClientServerConnection>> threadConnection;

	protected final int readTimeout;

	/**
	 *
	 * @param gateway The gateway used to pool Java instances created on the Python side.
	 * @param customCommands Optional list of custom commands that can be invoked by the Python side.
	 * @param pythonPort Port the PythonClient should connect to.
	 * @param pythonAddress Address (IP) the PythonClient should connect to.
	 * @param minConnectionTime Minimum time to wait before closing unused connections. Not used with PythonClient.
	 * @param minConnectionTimeUnit Time unit of minConnectionTime
	 * @param socketFactory SocketFactory used to create a socket.
	 * @param javaServer The JavaServer used to receive commands from the Python side.
	 */
	public PythonClient(Gateway gateway, List<Class<? extends Command>> customCommands, int pythonPort,
			InetAddress pythonAddress, long minConnectionTime, TimeUnit minConnectionTimeUnit,
			SocketFactory socketFactory, Py4JJavaServer javaServer) {
		this(gateway, customCommands, pythonPort, pythonAddress, minConnectionTime, minConnectionTimeUnit,
				socketFactory, javaServer, true, GatewayServer.DEFAULT_READ_TIMEOUT);
	}

	/**
	 *
	 * @param gateway The gateway used to pool Java instances created on the Python side.
	 * @param customCommands Optional list of custom commands that can be invoked by the Python side.
	 * @param pythonPort Port the PythonClient should connect to.
	 * @param pythonAddress Address (IP) the PythonClient should connect to.
	 * @param minConnectionTime Minimum time to wait before closing unused connections. Not used with PythonClient.
	 * @param minConnectionTimeUnit Time unit of minConnectionTime
	 * @param socketFactory SocketFactory used to create a socket.
	 * @param javaServer The JavaServer used to receive commands from the Python side.
	 * @param enableMemoryManagement If false, the Java side does not tell the Python side when a Python proxy is
	 *      			garbage collected.
	 * @param readTimeout
	 *            Time in milliseconds (0 = infinite). Once connected to the Python side,
	 *            if the Java side does not receive a response after this time, the connection with the Python
	 *            program is closed. If readTimeout = 0, a default readTimeout of 1000 is used for operations that
	 *            must absolutely be non-blocking.
	 */
	public PythonClient(Gateway gateway, List<Class<? extends Command>> customCommands, int pythonPort,
			InetAddress pythonAddress, long minConnectionTime, TimeUnit minConnectionTimeUnit,
			SocketFactory socketFactory, Py4JJavaServer javaServer, boolean enableMemoryManagement, int readTimeout) {
		this(gateway, customCommands, pythonPort, pythonAddress, minConnectionTime, minConnectionTimeUnit,
				socketFactory, javaServer, enableMemoryManagement, readTimeout, null);
	}

	/**
	 *
	 * @param gateway The gateway used to pool Java instances created on the Python side.
	 * @param customCommands Optional list of custom commands that can be invoked by the Python side.
	 * @param pythonPort Port the PythonClient should connect to.
	 * @param pythonAddress Address (IP) the PythonClient should connect to.
	 * @param minConnectionTime Minimum time to wait before closing unused connections. Not used with PythonClient.
	 * @param minConnectionTimeUnit Time unit of minConnectionTime
	 * @param socketFactory SocketFactory used to create a socket.
	 * @param javaServer The JavaServer used to receive commands from the Python side.
	 * @param enableMemoryManagement If false, the Java side does not tell the Python side when a Python proxy is
	 *      			garbage collected.
	 * @param readTimeout
	 *            Time in milliseconds (0 = infinite). Once connected to the Python side,
	 *            if the Java side does not receive a response after this time, the connection with the Python
	 *            program is closed. If readTimeout = 0, a default readTimeout of 1000 is used for operations that
	 *            must absolutely be non-blocking.
	 * @param authToken
	 *            Token for authenticating with the callback server.
	 */
	public PythonClient(Gateway gateway, List<Class<? extends Command>> customCommands, int pythonPort,
			InetAddress pythonAddress, long minConnectionTime, TimeUnit minConnectionTimeUnit,
			SocketFactory socketFactory, Py4JJavaServer javaServer, boolean enableMemoryManagement, int readTimeout,
			String authToken) {
		super(pythonPort, pythonAddress, authToken, minConnectionTime, minConnectionTimeUnit, socketFactory,
				enableMemoryManagement, readTimeout);
		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter PythonClient 3");
		this.gateway = gateway;
		this.javaServer = javaServer;
		this.customCommands = customCommands;
		this.threadConnection = new ThreadLocal<WeakReference<ClientServerConnection>>();
		this.readTimeout = readTimeout;
		setSelfListener();
		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit PythonClient 3");
	}

	private void setSelfListener() {
		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter setSelfListener 1");
		// Used to know when a connection is closed so we can remove it from our connections list
		if (javaServer != null) {
			System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter setSelfListener 2");
			javaServer.addListener(this);
			System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit setSelfListener 2");
		}
		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit setSelfListener 1");
	}

	@Override
	public ClientServerConnection getPerThreadConnection() {
		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter getPerThreadConnection 1");
		ClientServerConnection connection = null;
		WeakReference<ClientServerConnection> weakConnection = this.threadConnection.get();
		if (weakConnection != null) {
			System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter getPerThreadConnection 2");
			connection = weakConnection.get();
			System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit getPerThreadConnection 2");
		}
		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit getPerThreadConnection 1");
		return connection;
	}

	@Override
	public void setPerThreadConnection(ClientServerConnection clientServerConnection) {
		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter setPerThreadConnection 1");
		threadConnection.set(new WeakReference<ClientServerConnection>(clientServerConnection));
		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit setPerThreadConnection 1");
	}

	public Gateway getGateway() {
		return gateway;
	}

	public void setGateway(Gateway gateway) {
		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter setGateway 1");
		this.gateway = gateway;
		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit setGateway 1");
	}

	public Py4JJavaServer getJavaServer() {
		return javaServer;
	}

	public void setJavaServer(Py4JJavaServer javaServer) {
		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter setJavaServer 1");
		this.javaServer = javaServer;
		setSelfListener();
		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit setJavaServer 1");
	}

	@Override
	public int getReadTimeout() {
		return readTimeout;
	}

	@Override
	protected void setupCleaner() {
		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter setupCleaner 1");
		// Do nothing, we don't need a cleaner.
		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit setupCleaner 1");
	}

	protected Socket startClientSocket() throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter startClientSocket 1");
		logger.info("Starting Python Client connection on " + address + " at " + port);
		Socket socket = socketFactory.createSocket(address, port);
		socket.setSoTimeout(readTimeout);
		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit startClientSocket 1");
		return socket;
	}

	@Override
	protected Py4JClientConnection getConnection() throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter getConnection 1");
		ClientServerConnection connection = null;

		connection = getPerThreadConnection();

		if (connection != null) {
			System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter getConnection 2");
			try {
				System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter getConnection 3");
				lock.lock();
				connections.remove(connection);
				System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit getConnection 3");
			} finally {
				System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter getConnection 4");
				lock.unlock();
				System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit getConnection 4");
			}
			System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit getConnection 2");
		}

		if (connection == null || connection.getSocket() == null) {
			System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter getConnection 5");
			Socket socket = startClientSocket();
			connection = new ClientServerConnection(gateway, socket, customCommands, this, javaServer, readTimeout,
					authToken);
			connection.setInitiatedFromClient(true);
			connection.start();
			setPerThreadConnection(connection);
			System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit getConnection 5");
		}

		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit getConnection 1");
		return connection;
	}

	@Override
	protected boolean shouldRetrySendCommand(Py4JClientConnection cc, Py4JNetworkException pne) {
		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter shouldRetrySendCommand 1");
		boolean shouldRetry = super.shouldRetrySendCommand(cc, pne);

		if (shouldRetry && cc instanceof ClientServerConnection) {
			System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter shouldRetrySendCommand 2");
			ClientServerConnection csc = (ClientServerConnection) cc;
			shouldRetry = csc.isInitiatedFromClient();
			System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit shouldRetrySendCommand 2");
		}

		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit shouldRetrySendCommand 1");
		return shouldRetry;
	}

	@Override
	protected void giveBackConnection(Py4JClientConnection cc) {
		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter giveBackConnection 1");
		try {
			System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter giveBackConnection 2");
			lock.lock();
			connections.addLast(cc);
			System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit giveBackConnection 2");
		} finally {
			System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter giveBackConnection 3");
			lock.unlock();
			System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit giveBackConnection 3");
		}
		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit giveBackConnection 1");
	}

	@Override
	public Py4JPythonClient copyWith(InetAddress pythonAddress, int pythonPort) {
		return new PythonClient(gateway, customCommands, pythonPort, pythonAddress, minConnectionTime,
				minConnectionTimeUnit, socketFactory, javaServer);
	}

	@Override
	public void connectionError(Exception e) {
	}

	@Override
	public void connectionStarted(Py4JServerConnection gatewayConnection) {
	}

	@Override
	public void connectionStopped(Py4JServerConnection gatewayConnection) {
		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter connectionStopped 1");
		try {
			System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter connectionStopped 2");
			// Best effort to remove connections from deque
			// In an ideal world, we should use a lock around connections, but it could be tricky (potential deadlock?)
			lock.lock();
			connections.remove(gatewayConnection);
			System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit connectionStopped 2");
		} catch (Exception e) {
	
	
		} finally {
			System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] enter connectionStopped 4");
			lock.unlock();
			System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit connectionStopped 4");
		}
		System.err.println("[py4j-java/src/main/java/py4j/PythonClient.java] exit connectionStopped 1");
	}

	@Override
	public void serverError(Exception e) {
	}

	@Override
	public void serverPostShutdown() {
	}

	@Override
	public void serverPreShutdown() {
	}

	@Override
	public void serverStarted() {
	}

	@Override
	public void serverStopped() {
	}
}
// Total cost: 0.098567
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 300)]
// Total instrumented cost: 0.098567, input tokens: 5347, output tokens: 4166, cache read tokens: 0, cache write tokens: 5343

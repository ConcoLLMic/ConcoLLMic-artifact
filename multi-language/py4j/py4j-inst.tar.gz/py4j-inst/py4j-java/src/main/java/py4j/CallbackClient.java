/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.net.SocketFactory;

import py4j.reflection.ReflectionUtil;

/**
 * <p>
 * A CallbackClient is responsible for managing communication channels: channels
 * are created as needed (e.g., one per concurrent thread) and are closed after
 * a certain time.
 * </p>
 *
 * @author Barthelemy Dagenais
 *
 */
public class CallbackClient implements Py4JPythonClient {
	public final static String DEFAULT_ADDRESS = "127.0.0.1";

	protected final int port;

	protected final InetAddress address;

	protected final SocketFactory socketFactory;

	protected final Deque<Py4JClientConnection> connections = new ArrayDeque<Py4JClientConnection>();

	protected final Lock lock = new ReentrantLock(true);

	private final Logger logger = Logger.getLogger(CallbackClient.class.getName());

	private boolean isShutdown = false;

	private boolean isShuttingDown = false;

	public final static long DEFAULT_MIN_CONNECTION_TIME = 30;

	public final static TimeUnit DEFAULT_MIN_CONNECTION_TIME_UNIT = TimeUnit.SECONDS;

	private final ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);

	protected final long minConnectionTime;

	protected final TimeUnit minConnectionTimeUnit;

	protected final boolean enableMemoryManagement;

	protected final int readTimeout;

	protected final String authToken;

	public CallbackClient(int port) {
		this(port, GatewayServer.defaultAddress(), DEFAULT_MIN_CONNECTION_TIME, DEFAULT_MIN_CONNECTION_TIME_UNIT,
				SocketFactory.getDefault(), true);
	}

	public CallbackClient(int port, InetAddress address) {
		this(port, address, DEFAULT_MIN_CONNECTION_TIME, DEFAULT_MIN_CONNECTION_TIME_UNIT);
	}

	public CallbackClient(int port, InetAddress address, String authToken) {
		this(port, address, authToken, DEFAULT_MIN_CONNECTION_TIME, DEFAULT_MIN_CONNECTION_TIME_UNIT,
				SocketFactory.getDefault(), true, GatewayServer.DEFAULT_READ_TIMEOUT);
	}

	public CallbackClient(int port, InetAddress address, long minConnectionTime, TimeUnit minConnectionTimeUnit) {
		this(port, address, minConnectionTime, minConnectionTimeUnit, SocketFactory.getDefault());
	}

	/**
	 *
	 * @param port
	 *            The port used by channels to connect to the Python side.
	 * @param address
	 *            The addressed used by channels to connect to the Python side..
	 * @param minConnectionTime
	 *            The minimum connection time: channels are guaranteed to stay
	 *            connected for this time after sending a command.
	 * @param minConnectionTimeUnit
	 *            The minimum coonnection time unit.
	 * @param socketFactory
	 *            The non-{@code null} factory to make {@link Socket}s.
	 */
	public CallbackClient(int port, InetAddress address, long minConnectionTime, TimeUnit minConnectionTimeUnit,
			SocketFactory socketFactory) {
		this(port, address, minConnectionTime, minConnectionTimeUnit, socketFactory, true);
	}

	/**
	 *
	 * @param port
	 *            The port used by channels to connect to the Python side.
	 * @param address
	 *            The addressed used by channels to connect to the Python side..
	 * @param minConnectionTime
	 *            The minimum connection time: channels are guaranteed to stay
	 *            connected for this time after sending a command.
	 * @param minConnectionTimeUnit
	 *            The minimum coonnection time unit.
	 * @param socketFactory
	 *            The non-{@code null} factory to make {@link Socket}s.
	 * @param enableMemoryManagement
	 * 			  If False, we do not send tell the Python side when a PythonProxy
	 * 			  is no longer used by the Java side.
	 */
	public CallbackClient(int port, InetAddress address, long minConnectionTime, TimeUnit minConnectionTimeUnit,
			SocketFactory socketFactory, boolean enableMemoryManagement) {
		this(port, address, minConnectionTime, minConnectionTimeUnit, socketFactory, enableMemoryManagement,
				GatewayServer.DEFAULT_READ_TIMEOUT);
	}

	/**
	 *
	 * @param port
	 *            The port used by channels to connect to the Python side.
	 * @param address
	 *            The addressed used by channels to connect to the Python side..
	 * @param minConnectionTime
	 *            The minimum connection time: channels are guaranteed to stay
	 *            connected for this time after sending a command.
	 * @param minConnectionTimeUnit
	 *            The minimum coonnection time unit.
	 * @param socketFactory
	 *            The non-{@code null} factory to make {@link Socket}s.
	 * @param enableMemoryManagement
	 * 			  If False, we do not send tell the Python side when a PythonProxy
	 * 			  is no longer used by the Java side.
	 * @param readTimeout
	 *            Time in milliseconds (0 = infinite). Once a Python program is
	 *            connected, if a GatewayServer does not receive a request
	 *            (e.g., a method call) after this time, the connection with the
	 *            Python program is closed.
	 */
	public CallbackClient(int port, InetAddress address, long minConnectionTime, TimeUnit minConnectionTimeUnit,
			SocketFactory socketFactory, boolean enableMemoryManagement, int readTimeout) {
		this(port, address, null, minConnectionTime, minConnectionTimeUnit, socketFactory, enableMemoryManagement,
				readTimeout);
	}

	/**
	 *
	 * @param port
	 *            The port used by channels to connect to the Python side.
	 * @param address
	 *            The addressed used by channels to connect to the Python side.
	 * @param authToken
	 *            Token for authenticating with the callback server.
	 * @param minConnectionTime
	 *            The minimum connection time: channels are guaranteed to stay
	 *            connected for this time after sending a command.
	 * @param minConnectionTimeUnit
	 *            The minimum coonnection time unit.
	 * @param socketFactory
	 *            The non-{@code null} factory to make {@link Socket}s.
	 * @param enableMemoryManagement
	 *            If False, we do not send tell the Python side when a PythonProxy
	 *            is no longer used by the Java side.
	 * @param readTimeout
	 *            Time in milliseconds (0 = infinite). Once a Python program is
	 *            connected, if a GatewayServer does not receive a request
	 *            (e.g., a method call) after this time, the connection with the
	 *            Python program is closed.
	 */
	public CallbackClient(int port, InetAddress address, String authToken, long minConnectionTime,
			TimeUnit minConnectionTimeUnit, SocketFactory socketFactory, boolean enableMemoryManagement,
			int readTimeout) {
		super();
		System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter CallbackClient 8");
		this.port = port;
		this.address = address;
		this.minConnectionTime = minConnectionTime;
		this.minConnectionTimeUnit = minConnectionTimeUnit;
		this.socketFactory = socketFactory;
		this.enableMemoryManagement = enableMemoryManagement;
		this.readTimeout = readTimeout;
		this.authToken = StringUtil.escape(authToken);
		setupCleaner();
		System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit CallbackClient 8");
	}

	public InetAddress getAddress() {
		return address;
	}

	@Override
	public boolean isMemoryManagementEnabled() {
		return enableMemoryManagement;
	}

	protected Py4JClientConnection getConnection() throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter getConnection 1");
		Py4JClientConnection connection = null;

		connection = connections.pollLast();
		if (connection == null) {
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter getConnection 2");
			connection = new CallbackConnection(port, address, socketFactory, readTimeout, authToken);
			connection.start();
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit getConnection 2");
		}

		System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit getConnection 1");
		return connection;
	}

	protected Py4JClientConnection getConnectionLock() {
		System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter getConnectionLock 1");
		Py4JClientConnection cc = null;
		try {
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter getConnectionLock 2");
			logger.log(Level.INFO, "Getting CB Connection");
			lock.lock();
			if (!isShutdown) {
				System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter getConnectionLock 3");
				cc = getConnection();
				logger.log(Level.INFO, "Acquired CB Connection");
				System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit getConnectionLock 3");
			} else {
				System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter getConnectionLock 4");
				logger.log(Level.INFO, "Shutting down, no connection can be created.");
				System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit getConnectionLock 4");
			}
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit getConnectionLock 2");
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter getConnectionLock 5");
			logger.log(Level.SEVERE, "Critical error while sending a command", e);
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit getConnectionLock 5");
			throw new Py4JException("Error while obtaining a new communication channel", e);
		} finally {
			lock.unlock();
		}

		System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit getConnectionLock 1");
		return cc;
	}

	public int getPort() {
		return port;
	}

	public int getReadTimeout() {
		return readTimeout;
	}

	/**
	 * <p>
	 * Creates a callback client which connects to the given address and port,
	 * but retains all the other settings (like the {@link #minConnectionTime}
	 * and the {@link #socketFactory}. This method is useful if for some reason
	 * your CallbackServer changes its address or you come to know of the
	 * address after Gateway has already instantiated.
	 * </p>
	 *
	 * @param pythonAddress
	 *            The address used by a PythonProxyHandler to connect to a
	 *            Python gateway.
	 * @param pythonPort
	 *            The port used by a PythonProxyHandler to connect to a Python
	 *            gateway. Essentially the port used for Python callbacks.
	 */
	@Override
	public Py4JPythonClient copyWith(InetAddress pythonAddress, int pythonPort) {
		return new CallbackClient(pythonPort, pythonAddress, authToken, minConnectionTime, minConnectionTimeUnit,
				socketFactory, enableMemoryManagement, readTimeout);
	}

	protected void giveBackConnection(Py4JClientConnection cc) {
		System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter giveBackConnection 1");
		try {
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter giveBackConnection 2");
			lock.lock();
			if (cc != null) {
				System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter giveBackConnection 3");
				if (!isShutdown) {
					System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter giveBackConnection 4");
					connections.addLast(cc);
					System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit giveBackConnection 4");
				} else {
					System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter giveBackConnection 5");
					cc.shutdown();
					System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit giveBackConnection 5");
				}
				System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit giveBackConnection 3");
			}
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit giveBackConnection 2");
		} finally {
			lock.unlock();
		}
		System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit giveBackConnection 1");
	}

	/**
	 * <p>
	 * Closes communication channels that have not been used for a time
	 * specified at the creation of the callback client.
	 * </p>
	 *
	 * <p>
	 * Clients should not directly call this method: it is called by a periodic
	 * cleaner thread.
	 * </p>
	 *
	 */
	public void periodicCleanup() {
		System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter periodicCleanup 1");
		try {
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter periodicCleanup 2");
			lock.lock();
			if (!isShutdown) {
				System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter periodicCleanup 3");
				int size = connections.size();
				for (int i = 0; i < size; i++) {
					System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter periodicCleanup 4");
					Py4JClientConnection cc = connections.pollLast();
					if (cc.wasUsed()) {
						System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter periodicCleanup 5");
						cc.setUsed(false);
						connections.addFirst(cc);
						System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit periodicCleanup 5");
					} else {
						System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter periodicCleanup 6");
						cc.shutdown();
						System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit periodicCleanup 6");
					}
					System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit periodicCleanup 4");
				}
				System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit periodicCleanup 3");
			}
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit periodicCleanup 2");
		} finally {
			lock.unlock();
		}
		System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit periodicCleanup 1");
	}

	/**
	 * <p>
	 * Sends a command to the Python side. This method is typically used by
	 * Python proxies to call Python methods or to request the garbage
	 * collection of a proxy.
	 * </p>
	 *
	 * @param command
	 *            The command to send.
	 * @return The response.
	 */
	@Override
	public String sendCommand(String command) {
		return sendCommand(command, true);
	}

	/**
	 * <p>
	 * Sends a command to the Python side. This method is typically used by
	 * Python proxies to call Python methods or to request the garbage
	 * collection of a proxy.
	 * </p>
	 *
	 * @param command
	 *            The command to send.
	 * @param blocking
	 * 			  If the CallbackClient should wait for an answer (default
	 * 			  should be True, except for critical cases such as a
	 * 			  finalizer sending a command).
	 * @return The response.
	 */
	@Override
	public String sendCommand(String command, boolean blocking) {
		System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter sendCommand 2");
		String returnCommand = null;
		Py4JClientConnection cc = getConnectionLock();

		if (cc == null) {
			throw new Py4JException("Cannot obtain a new communication channel");
		}

		try {
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter sendCommand 4");
			returnCommand = cc.sendCommand(command, blocking);
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit sendCommand 4");
		} catch (Py4JNetworkException pe) {
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter sendCommand 5");
			logger.log(Level.WARNING, "Error while sending a command", pe);
			boolean reset = false;
			if (pe.getCause() instanceof SocketTimeoutException) {
				System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter sendCommand 6");
				reset = true;
				System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit sendCommand 6");
			}
			cc.shutdown(reset);
			if (shouldRetrySendCommand(cc, pe)) {
				System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter sendCommand 7");
				// Retry in case the channel was dead.
				returnCommand = sendCommand(command, blocking);
				System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit sendCommand 7");
			} else {
				System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter sendCommand 8");
				logger.log(Level.SEVERE, "Error while sending a command.", pe);
				System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit sendCommand 8");
				throw new Py4JException("Error while sending a command.", pe);
			}
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit sendCommand 5");
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter sendCommand 9");
			logger.log(Level.SEVERE, "Critical error while sending a command", e);
			cc.shutdown();
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit sendCommand 9");
			throw new Py4JException("Error while sending a command.");
		}

		try {
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter sendCommand 10");
			giveBackConnection(cc);
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit sendCommand 10");
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter sendCommand 11");
			logger.log(Level.SEVERE, "Critical error while giving back connection.", e);
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit sendCommand 11");
			throw new Py4JException("Error while giving back connection.");
		}

		System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit sendCommand 2");
		return returnCommand;
	}

	@Override
	public Object getPythonServerEntryPoint(Gateway gateway,
			@SuppressWarnings("rawtypes") Class[] interfacesToImplement) {
		System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter getPythonServerEntryPoint 1");
		Object proxy = gateway.createProxy(ReflectionUtil.getClassLoader(), interfacesToImplement,
				Protocol.ENTRY_POINT_OBJECT_ID);
		System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit getPythonServerEntryPoint 1");
		return proxy;
	}

	protected boolean shouldRetrySendCommand(Py4JClientConnection cc, Py4JNetworkException pne) {
		return pne.getWhen() == Py4JNetworkException.ErrorTime.ERROR_ON_SEND;
	}

	protected void setupCleaner() {
		System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter setupCleaner 1");
		if (minConnectionTime > 0) {
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter setupCleaner 2");
			executor.scheduleAtFixedRate(new Runnable() {
				public void run() {
					System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter run 1");
					periodicCleanup();
					System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit run 1");
				}
			}, minConnectionTime, minConnectionTime, minConnectionTimeUnit);
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit setupCleaner 2");
		}
		System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit setupCleaner 1");
	}

	/**
	 * <p>
	 * Closes all active channels, stops the periodic cleanup of channels and
	 * mark the client as shutting down.
	 *
	 * No more commands can be sent after this method has been called,
	 * <em>except</em> commands that were initiated before the shutdown method
	 * was called..
	 * </p>
	 */
	@Override
	public void shutdown() {
		System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter shutdown 1");
		logger.info("Shutting down Callback Client");
		try {
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter shutdown 2");
			lock.lock();
			if (isShuttingDown) {
				return;
			}
			isShutdown = true;
			isShuttingDown = true;
			ArrayList<Py4JClientConnection> tempConnections = new ArrayList<Py4JClientConnection>(connections);
			for (Py4JClientConnection cc : tempConnections) {
				System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] enter shutdown 4");
				cc.shutdown();
				System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit shutdown 4");
			}
			executor.shutdownNow();
			connections.clear();
			System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit shutdown 2");
		} finally {
			isShuttingDown = false;
			lock.unlock();
		}
		System.err.println("[py4j-java/src/main/java/py4j/CallbackClient.java] exit shutdown 1");
	}
}
// Total cost: 0.124399
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 468)]
// Total instrumented cost: 0.124399, input tokens: 6937, output tokens: 6153, cache read tokens: 2280, cache write tokens: 4653

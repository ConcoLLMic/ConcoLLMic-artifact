/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j.reflection;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import py4j.Py4JException;

/**
 * <p>
 * The reflection engine is responsible for accessing the classes, the instances
 * and members in a JVM.
 * </p>
 * 
 * @author Barthelemy Dagenais
 * 
 */
public class ReflectionEngine {

	public final static int cacheSize = 100;

	private final Logger logger = Logger.getLogger(ReflectionEngine.class.getName());

	public final static Object RETURN_VOID = new Object();

	private static ThreadLocal<LRUCache<MethodDescriptor, MethodInvoker>> cacheHolder = new ThreadLocal<LRUCache<MethodDescriptor, MethodInvoker>>() {

		@Override
		protected LRUCache<MethodDescriptor, MethodInvoker> initialValue() {
			return new LRUCache<MethodDescriptor, MethodInvoker>(cacheSize);
		}

	};

	public Object createArray(String fqn, int[] dimensions) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter createArray 1");
		Class<?> clazz = null;
		Object returnObject = null;
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit createArray 1");
		try {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter createArray 2");
			clazz = TypeUtil.forName(fqn);
			returnObject = Array.newInstance(clazz, dimensions);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit createArray 2");
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter createArray 3");
			logger.log(Level.WARNING, "Class FQN does not exist: " + fqn, e);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit createArray 3");
			throw new Py4JException(e);
		}
		return returnObject;
	}

	private MethodInvoker getBestConstructor(List<Constructor<?>> acceptableConstructors, Class<?>[] parameters) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getBestConstructor 1");
		MethodInvoker lowestCost = null;
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getBestConstructor 1");

		for (Constructor<?> constructor : acceptableConstructors) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getBestConstructor 2");
			MethodInvoker temp = MethodInvoker.buildInvoker(constructor, parameters);
			int cost = temp.getCost();
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getBestConstructor 2");
			if (cost == -1) {
				continue;
			} else if (cost == 0) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getBestConstructor 4");
				lowestCost = temp;
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getBestConstructor 4");
				break;
			} else if (lowestCost == null || cost < lowestCost.getCost()) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getBestConstructor 5");
				lowestCost = temp;
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getBestConstructor 5");
			}
		}

		return lowestCost;
	}

	private MethodInvoker getBestMethod(List<Method> acceptableMethods, Class<?>[] parameters) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getBestMethod 1");
		MethodInvoker lowestCost = null;
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getBestMethod 1");

		for (Method method : acceptableMethods) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getBestMethod 2");
			MethodInvoker temp = MethodInvoker.buildInvoker(method, parameters);
			int cost = temp.getCost();
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getBestMethod 2");
			if (cost == -1) {
				continue;
			} else if (cost == 0) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getBestMethod 4");
				lowestCost = temp;
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getBestMethod 4");
				break;
			} else if (lowestCost == null || cost < lowestCost.getCost()) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getBestMethod 5");
				lowestCost = temp;
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getBestMethod 5");
			}
		}

		return lowestCost;
	}

	public Class<?> getClass(Class<?> clazz, String name) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getClass 1");
		Class<?> memberClass = null;
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getClass 1");

		try {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getClass 2");
			for (Class<?> tempClass : clazz.getClasses()) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getClass 3");
				if (tempClass.getSimpleName().equals(name)) {
					System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getClass 4");
					memberClass = tempClass;
					System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getClass 4");
					break;
				}
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getClass 3");
			}
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getClass 2");
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getClass 5");
			memberClass = null;
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getClass 5");
		}

		return memberClass;
	}

	public Class<?>[] getClassParameters(Object[] parameters) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getClassParameters 1");
		int size = parameters.length;
		Class<?>[] classes = new Class<?>[size];
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getClassParameters 1");

		for (int i = 0; i < size; i++) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getClassParameters 2");
			if (parameters[i] == null) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getClassParameters 3");
				classes[i] = null;
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getClassParameters 3");
			} else {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getClassParameters 4");
				classes[i] = parameters[i].getClass();
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getClassParameters 4");
			}
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getClassParameters 2");
		}

		return classes;
	}

	public MethodInvoker getConstructor(Class<?> clazz, Class<?>[] parameters) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getConstructor 1");
		MethodDescriptor mDescriptor = new MethodDescriptor(clazz.getName(), clazz, parameters);
		MethodInvoker mInvoker = null;
		List<Constructor<?>> acceptableConstructors = null;
		LRUCache<MethodDescriptor, MethodInvoker> cache = cacheHolder.get();
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getConstructor 1");

		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getConstructor 2");
		mInvoker = cache.get(mDescriptor);
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getConstructor 2");

		if (mInvoker == null) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getConstructor 3");
			acceptableConstructors = getConstructorsByLength(clazz, parameters.length);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getConstructor 3");

			if (acceptableConstructors.size() == 1) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getConstructor 4");
				mInvoker = MethodInvoker.buildInvoker(acceptableConstructors.get(0), parameters);
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getConstructor 4");
			} else {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getConstructor 5");
				mInvoker = getBestConstructor(acceptableConstructors, parameters);
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getConstructor 5");
			}

			if (mInvoker != null && mInvoker.getCost() != -1) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getConstructor 6");
				cache.put(mDescriptor, mInvoker);
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getConstructor 6");
			} else {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getConstructor 7");
				String errorMessage = "Constructor " + clazz.getName() + "(" + Arrays.toString(parameters)
						+ ") does not exist";
				logger.log(Level.WARNING, errorMessage);
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getConstructor 7");
				throw new Py4JException(errorMessage);
			}
		}

		return mInvoker;
	}

	public MethodInvoker getConstructor(String classFQN, Object[] parameters) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getConstructor 9");
		Class<?> clazz = null;
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getConstructor 9");

		try {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getConstructor 10");
			clazz = ReflectionUtil.classForName(classFQN);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getConstructor 10");
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getConstructor 11");
			logger.log(Level.WARNING, "Class FQN does not exist: " + classFQN, e);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getConstructor 11");
			throw new Py4JException(e);
		}

		return getConstructor(clazz, getClassParameters(parameters));
	}

	private List<Constructor<?>> getConstructorsByLength(Class<?> clazz, int length) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getConstructorsByLength 1");
		List<Constructor<?>> methods = new ArrayList<Constructor<?>>();
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getConstructorsByLength 1");

		for (Constructor<?> constructor : clazz.getConstructors()) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getConstructorsByLength 2");
			if (constructor.getParameterTypes().length == length) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getConstructorsByLength 3");
				if (ReflectionShim.trySetAccessible(constructor)) {
					System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getConstructorsByLength 4");
					methods.add(constructor);
					System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getConstructorsByLength 4");
				}
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getConstructorsByLength 3");
			}
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getConstructorsByLength 2");
		}

		return methods;
	}

	/**
	 * 
	 * @param clazz
	 * @param name
	 * @return The field or null if a field with this name does not exist in
	 *         this class or in its hierarchy.
	 */
	public Field getField(Class<?> clazz, String name) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getField 1");
		Field field = null;
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getField 1");

		try {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getField 2");
			field = clazz.getField(name);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getField 2");
			if (!Modifier.isPublic(field.getModifiers()) && !field.isAccessible()) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getField 3");
				field = null;
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getField 3");
			}
		} catch (NoSuchFieldException e) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getField 4");
			field = null;
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getField 4");
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getField 5");
			field = null;
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getField 5");
		}

		return field;
	}

	/**
	 * 
	 * @param obj
	 * @param name
	 * @return The field or null if a field with this name does not exist in the
	 *         class of this object or in its hierarchy.
	 */
	public Field getField(Object obj, String name) {
		return getField(obj.getClass(), name);
	}

	public Field getField(String classFQN, String name) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getField 8");
		Class<?> clazz = null;
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getField 8");

		try {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getField 9");
			clazz = ReflectionUtil.classForName(classFQN);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getField 9");
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getField 10");
			logger.log(Level.WARNING, "Class FQN does not exist: " + classFQN, e);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getField 10");
			throw new Py4JException(e);
		}

		return getField(clazz, name);
	}

	/**
	 * <p>
	 * Wrapper around Field.get
	 * </p>
	 * 
	 * @param obj
	 * @param field
	 * @return
	 */
	public Object getFieldValue(Object obj, Field field) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getFieldValue 1");
		Object fieldValue = null;
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getFieldValue 1");

		try {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getFieldValue 2");
			fieldValue = field.get(obj);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getFieldValue 2");
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getFieldValue 3");
			logger.log(Level.SEVERE, "Error while fetching field value of " + field, e);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getFieldValue 3");
			throw new Py4JException(e);
		}
		return fieldValue;
	}

	public Method getMethod(Class<?> clazz, String name) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethod 1");
		Method m = null;
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethod 1");
		try {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethod 2");
			for (Method tempMethod : clazz.getMethods()) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethod 3");
				if (tempMethod.getName().equals(name)) {
					System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethod 4");
					m = tempMethod;
					System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethod 4");
					break;
				}
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethod 3");
			}
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethod 2");
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethod 5");
			m = null;
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethod 5");
		}
		return m;
	}

	public MethodInvoker getMethod(Class<?> clazz, String name, Class<?>[] parameters) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethod 7");
		MethodDescriptor mDescriptor = new MethodDescriptor(name, clazz, parameters);
		MethodInvoker mInvoker = null;
		List<Method> acceptableMethods = null;
		LRUCache<MethodDescriptor, MethodInvoker> cache = cacheHolder.get();
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethod 7");

		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethod 8");
		mInvoker = cache.get(mDescriptor);
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethod 8");

		if (mInvoker == null) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethod 9");
			acceptableMethods = getMethodsByNameAndLength(clazz, name, parameters.length);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethod 9");

			if (acceptableMethods.size() == 1) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethod 10");
				mInvoker = MethodInvoker.buildInvoker(acceptableMethods.get(0), parameters);
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethod 10");
			} else {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethod 11");
				mInvoker = getBestMethod(acceptableMethods, parameters);
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethod 11");
			}

			if (mInvoker != null && mInvoker.getCost() != -1) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethod 12");
				cache.put(mDescriptor, mInvoker);
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethod 12");
			} else {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethod 13");
				String errorMessage = "Method " + name + "(" + Arrays.toString(parameters) + ") does not exist";
				logger.log(Level.WARNING, errorMessage);
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethod 13");
				throw new Py4JException(errorMessage);
			}
		}

		return mInvoker;
	}

	public MethodInvoker getMethod(Object object, String name, Object[] parameters) {
		return getMethod(object.getClass(), name, getClassParameters(parameters));
	}

	public MethodInvoker getMethod(String classFQN, String name, Object[] parameters) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethod 16");
		Class<?> clazz = null;
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethod 16");

		try {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethod 17");
			clazz = ReflectionUtil.classForName(classFQN);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethod 17");
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethod 18");
			logger.log(Level.WARNING, "Class FQN does not exist: " + classFQN, e);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethod 18");
			throw new Py4JException(e);
		}

		return getMethod(clazz, name, getClassParameters(parameters));
	}

	private List<Method> getMethodsByNameAndLength(Class<?> clazz, String name, int length) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethodsByNameAndLength 1");
		List<Method> methodsToCheck = new ArrayList<Method>();
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethodsByNameAndLength 1");

		while (clazz != null) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethodsByNameAndLength 2");
			methodsToCheck.addAll(Arrays.asList(clazz.getDeclaredMethods()));
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethodsByNameAndLength 2");
			for (Class<?> intf : clazz.getInterfaces()) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethodsByNameAndLength 3");
				methodsToCheck.addAll(Arrays.asList(intf.getDeclaredMethods()));
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethodsByNameAndLength 3");
			}
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethodsByNameAndLength 4");
			clazz = clazz.getSuperclass();
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethodsByNameAndLength 4");
		}

		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethodsByNameAndLength 5");
		List<Method> methods = new ArrayList<Method>();
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethodsByNameAndLength 5");

		for (Method method : methodsToCheck) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethodsByNameAndLength 6");
			if (method.getName().equals(name) && method.getParameterTypes().length == length) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethodsByNameAndLength 7");
				// If it can't be set to accessible, there is
				// not much we can do, other than look further.
				if (ReflectionShim.trySetAccessible(method)) {
					System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getMethodsByNameAndLength 8");
					methods.add(method);
					System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethodsByNameAndLength 8");
				}
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethodsByNameAndLength 7");
			}
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getMethodsByNameAndLength 6");
		}

		return methods;
	}

	public Object invoke(Object object, MethodInvoker invoker, Object[] parameters) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter invoke 1");
		Object returnObject = null;
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit invoke 1");

		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter invoke 2");
		returnObject = invoker.invoke(object, parameters);
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit invoke 2");
		if (invoker.isVoid()) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter invoke 3");
			returnObject = RETURN_VOID;
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit invoke 3");
		}

		return returnObject;
	}

	/**
	 * <p>
	 * Wrapper around Field.set
	 * </p>
	 * 
	 * @param obj
	 * @param field
	 * @param value
	 */
	public void setFieldValue(Object obj, Field field, Object value) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter setFieldValue 1");
		try {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter setFieldValue 2");
			field.set(obj, value);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit setFieldValue 2");
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter setFieldValue 3");
			logger.log(Level.SEVERE, "Error while setting field value of " + field, e);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit setFieldValue 3");
			throw new Py4JException(e);
		}
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit setFieldValue 1");
	}

	/**
	 * Retrieve the names of all the public methods in the obj
	 * @param obj the object to inspect
	 * @return list of all the names of public methods in obj
	 */
	public String[] getPublicMethodNames(Object obj) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getPublicMethodNames 1");
		Method[] methods = obj.getClass().getMethods();
		Set<String> methodNames = new HashSet<String>();
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getPublicMethodNames 1");
		for (Method method : methods) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getPublicMethodNames 2");
			if (Modifier.isPublic(method.getModifiers())) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getPublicMethodNames 3");
				methodNames.add(method.getName());
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getPublicMethodNames 3");
			}
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getPublicMethodNames 2");
		}
		return (String[]) methodNames.toArray(new String[methodNames.size()]);
	}

	/**
	 * Retrieve the names of all the public fields in the obj
	 * @param obj the object to inspect
	 * @return list of all the names of public fields in obj
	 */
	public String[] getPublicFieldNames(Object obj) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getPublicFieldNames 1");
		Field[] fields = obj.getClass().getFields();
		Set<String> fieldNames = new HashSet<String>();
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getPublicFieldNames 1");
		for (Field field : fields) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getPublicFieldNames 2");
			if (Modifier.isPublic(field.getModifiers())) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getPublicFieldNames 3");
				fieldNames.add(field.getName());
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getPublicFieldNames 3");
			}
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getPublicFieldNames 2");
		}
		return (String[]) fieldNames.toArray(new String[fieldNames.size()]);
	}

	/**
	 * Retrieve the names of all the public static fields in the clazz
	 *
	 * @param clazz
	 *            the object to inspect
	 * @return list of all the names of public statics
	 */
	public String[] getPublicStaticFieldNames(Class<?> clazz) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getPublicStaticFieldNames 1");
		Field[] fields = clazz.getFields();
		Set<String> fieldNames = new HashSet<String>();
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getPublicStaticFieldNames 1");
		for (Field field : fields) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getPublicStaticFieldNames 2");
			if (Modifier.isPublic(field.getModifiers()) && Modifier.isStatic(field.getModifiers())) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getPublicStaticFieldNames 3");
				fieldNames.add(field.getName());
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getPublicStaticFieldNames 3");
			}
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getPublicStaticFieldNames 2");
		}
		return (String[]) fieldNames.toArray(new String[fieldNames.size()]);
	}

	/**
	 * Retrieve the names of all the public static methods in the clazz
	 * @param clazz the object to inspect
	 * @return list of all the names of public statics
	 */
	public String[] getPublicStaticMethodNames(Class<?> clazz) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getPublicStaticMethodNames 1");
		Method[] methods = clazz.getMethods();
		Set<String> methodNames = new HashSet<String>();
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getPublicStaticMethodNames 1");
		for (Method method : methods) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getPublicStaticMethodNames 2");
			if (Modifier.isPublic(method.getModifiers()) && Modifier.isStatic(method.getModifiers())) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getPublicStaticMethodNames 3");
				methodNames.add(method.getName());
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getPublicStaticMethodNames 3");
			}
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getPublicStaticMethodNames 2");
		}
		return (String[]) methodNames.toArray(new String[methodNames.size()]);
	}

	/**
	 * Retrieve the names of all the public static classes in the clazz
	 * @param clazz the object to inspect
	 * @return list of all the names of public statics
	 */
	public String[] getPublicStaticClassNames(Class<?> clazz) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getPublicStaticClassNames 1");
		Class<?>[] classes = clazz.getClasses();
		Set<String> classNames = new HashSet<String>();
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getPublicStaticClassNames 1");
		for (Class<?> clazz2 : classes) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getPublicStaticClassNames 2");
			if (Modifier.isPublic(clazz2.getModifiers()) && Modifier.isStatic(clazz2.getModifiers())) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getPublicStaticClassNames 3");
				classNames.add(clazz2.getSimpleName());
				System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getPublicStaticClassNames 3");
			}
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getPublicStaticClassNames 2");
		}
		return (String[]) classNames.toArray(new String[classNames.size()]);
	}

	/**
	 * Retrieve the names of all the public static fields, methods and
	 * classes in the clazz
	 * @param clazz the object to inspect
	 * @return list of all the names of public statics
	 */
	public String[] getPublicStaticNames(Class<?> clazz) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] enter getPublicStaticNames 1");
		Set<String> names = new HashSet<String>();
		names.addAll(Arrays.asList(getPublicStaticClassNames(clazz)));
		names.addAll(Arrays.asList(getPublicStaticFieldNames(clazz)));
		names.addAll(Arrays.asList(getPublicStaticMethodNames(clazz)));
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionEngine.java] exit getPublicStaticNames 1");
		return (String[]) names.toArray(new String[names.size()]);
	}
}
// Total cost: 0.161762
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 495)]
// Total instrumented cost: 0.161762, input tokens: 7210, output tokens: 8521, cache read tokens: 2280, cache write tokens: 4926

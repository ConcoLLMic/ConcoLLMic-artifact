/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j.commands;

import static py4j.NetworkUtil.safeReadLine;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.logging.Logger;

import py4j.GatewayServer;
import py4j.Protocol;
import py4j.Py4JException;

/**
 * <p>
 * The MemoryCommand is responsible for handling garbage collection requests
 * from the Python side, i.e., when a java object is no longer used by the
 * Python program.
 * </p>
 * 
 * @author Barthelemy Dagenais
 * 
 */
public class MemoryCommand extends AbstractCommand {

	private final Logger logger = Logger.getLogger(MemoryCommand.class.getName());

	public final static String MEMORY_COMMAND_NAME = "m";

	public final static String MEMORY_DEL_SUB_COMMAND_NAME = "d";

	public MemoryCommand() {
		super();
		System.err.println("[py4j-java/src/main/java/py4j/commands/MemoryCommand.java] enter MemoryCommand 1");
		this.commandName = MEMORY_COMMAND_NAME;
		System.err.println("[py4j-java/src/main/java/py4j/commands/MemoryCommand.java] exit MemoryCommand 1");
	}

	private String deleteObject(BufferedReader reader) throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/MemoryCommand.java] enter deleteObject 1");
		String objectId = reader.readLine();
		// EoC
		reader.readLine();
		System.err.println("[py4j-java/src/main/java/py4j/commands/MemoryCommand.java] exit deleteObject 1");

		if (objectId != Protocol.ENTRY_POINT_OBJECT_ID && objectId != Protocol.DEFAULT_JVM_OBJECT_ID
				&& objectId != Protocol.GATEWAY_SERVER_ID) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/MemoryCommand.java] enter deleteObject 2");
			gateway.deleteObject(objectId);
			System.err.println("[py4j-java/src/main/java/py4j/commands/MemoryCommand.java] exit deleteObject 2");
		}

		return Protocol.getOutputVoidCommand();
	}

	@Override
	public void execute(String commandName, BufferedReader reader, BufferedWriter writer)
			throws Py4JException, IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/MemoryCommand.java] enter execute 1");
		String returnCommand = null;
		String subCommand = safeReadLine(reader);
		System.err.println("[py4j-java/src/main/java/py4j/commands/MemoryCommand.java] exit execute 1");

		if (subCommand.equals(MEMORY_DEL_SUB_COMMAND_NAME)) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/MemoryCommand.java] enter execute 2");
			returnCommand = deleteObject(reader);
			System.err.println("[py4j-java/src/main/java/py4j/commands/MemoryCommand.java] exit execute 2");
		} else {
			System.err.println("[py4j-java/src/main/java/py4j/commands/MemoryCommand.java] enter execute 3");
			returnCommand = Protocol.getOutputErrorCommand("Unknown Memory SubCommand Name: " + subCommand);
			System.err.println("[py4j-java/src/main/java/py4j/commands/MemoryCommand.java] exit execute 3");
		}
		System.err.println("[py4j-java/src/main/java/py4j/commands/MemoryCommand.java] enter execute 4");
		logger.finest("Returning command: " + returnCommand);
		writer.write(returnCommand);
		writer.flush();
		System.err.println("[py4j-java/src/main/java/py4j/commands/MemoryCommand.java] exit execute 4");
	}

}
// Total cost: 0.025590
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 95)]
// Total instrumented cost: 0.025590, input tokens: 3312, output tokens: 1197, cache read tokens: 2280, cache write tokens: 1028

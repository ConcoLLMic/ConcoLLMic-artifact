/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.net.ServerSocketFactory;

import py4j.commands.Command;

/**
 * <p>
 * This class enables Python programs to access a Java program. When a
 * GatewayServer instance is started, Python programs can connect to the JVM by
 * calling:
 * </p>
 *
 * <p>
 * <code>gateway = JavaGateway()</code>
 * </p>
 *
 * <p>
 * The
 * <code>entryPoint</code> passed to a GatewayServer can be accessed with the <code>entry_point</code>
 * member:
 * </p>
 *
 * <p>
 * <code>gateway.entry_point</code>
 * </p>
 *
 * <p>
 * Technically, a GatewayServer is only responsible for accepting connection.
 * Each connection is then handled by a {@link py4j.GatewayConnection
 * GatewayConnection} instance and the various states (e.g., entryPoint,
 * reference to returned objects) are managed by a {@link py4j.Gateway Gateway}
 * instance.
 * </p>
 *
 * @author Barthelemy Dagenais
 *
 */
public class GatewayServer extends DefaultGatewayServerListener implements Py4JJavaServer, Runnable {

	public static final String DEFAULT_ADDRESS = "127.0.0.1";

	public static final String DEFAULT_IPv6_ADDRESS = "::1";

	public static final int DEFAULT_PORT = 25333;

	public static final int DEFAULT_PYTHON_PORT = 25334;

	public static final int DEFAULT_CONNECT_TIMEOUT = 0;

	public static final int DEFAULT_READ_TIMEOUT = 0;

	public static final String GATEWAY_SERVER_ID = Protocol.GATEWAY_SERVER_ID;

	public static final Logger PY4J_LOGGER = Logger.getLogger("py4j");

	/**
	 * <p>
	 * Utility method to turn logging on. Logging is turned off by default. All
	 * log messages will be logged.
	 * </p>
	 */
	public static void turnAllLoggingOn() {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.turnAllLoggingOn 1");
		PY4J_LOGGER.setLevel(Level.ALL);
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.turnAllLoggingOn 1");
	}

	/**
	 * <p>
	 * Utility method to turn logging off. Logging is turned off by default.
	 * </p>
	 */
	public static void turnLoggingOff() {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.turnLoggingOff 1");
		PY4J_LOGGER.setLevel(Level.OFF);
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.turnLoggingOff 1");
	}

	/**
	 * <p>
	 * Utility method to turn logging on. Logging is turned off by default. Log
	 * messages up to INFO level will be logged.
	 * </p>
	 */
	public static void turnLoggingOn() {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.turnLoggingOn 1");
		PY4J_LOGGER.setLevel(Level.INFO);
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.turnLoggingOn 1");
	}

	private final InetAddress address;

	private final int port;

	private int pythonPort;

	private InetAddress pythonAddress;

	private final Gateway gateway;

	private final int connectTimeout;

	private final int readTimeout;

	private final Logger logger = Logger.getLogger(GatewayServer.class.getName());

	private final List<Py4JServerConnection> connections = new ArrayList<Py4JServerConnection>();

	private final List<Class<? extends Command>> customCommands;

	private final CopyOnWriteArrayList<GatewayServerListener> listeners;

	private final ServerSocketFactory sSocketFactory;

	protected final String authToken;

	private ServerSocket sSocket;

	private boolean isShutdown = false;

	private boolean isShuttingDown = false;

	private final Lock lock = new ReentrantLock(true);

	static {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.static 1");
		GatewayServer.turnLoggingOff();
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.static 1");
	}

	public static InetAddress defaultAddress() {
		try {
			return InetAddress.getByName(DEFAULT_ADDRESS);
		} catch (UnknownHostException e) {
			throw new Py4JNetworkException(e);
		}
	}

	public static InetAddress defaultIPv6Address() {
		try {
			return InetAddress.getByName(DEFAULT_IPv6_ADDRESS);
		} catch (UnknownHostException e) {
			throw new Py4JNetworkException(e);
		}
	}

	/**
	 * <p>
	 * Creates a GatewayServer instance with default port (25333), default
	 * address (127.0.0.1), and default timeout value (no timeout).
	 * </p>
	 */
	public GatewayServer() {
		this(null, DEFAULT_PORT, DEFAULT_CONNECT_TIMEOUT, DEFAULT_READ_TIMEOUT);
	}

	/**
	 * <p>
	 * Creates a GatewayServer instance with default port (25333), default
	 * address (127.0.0.1), and default timeout value (no timeout).
	 * </p>
	 *
	 * @param entryPoint
	 *            The entry point of this Gateway. Can be null.
	 */
	public GatewayServer(Object entryPoint) {
		this(entryPoint, DEFAULT_PORT, DEFAULT_CONNECT_TIMEOUT, DEFAULT_READ_TIMEOUT);
	}

	/**
	 *
	 * @param entryPoint
	 *            The entry point of this Gateway. Can be null.
	 * @param port
	 *            The port the GatewayServer is listening to.
	 */
	public GatewayServer(Object entryPoint, int port) {
		this(entryPoint, port, DEFAULT_CONNECT_TIMEOUT, DEFAULT_READ_TIMEOUT);
	}

	/**
	 *
	 * @param entryPoint
	 *            The entry point of this Gateway. Can be null.
	 * @param port
	 *            The port the GatewayServer is listening to.
	 * @param pythonPort
	 *            The port used by a PythonProxyHandler to connect to a Python
	 *            gateway. Essentially the port used for Python callbacks.
	 * @param address
	 *            The address the GatewayServer is listening to.
	 * @param pythonAddress
	 *            The address used by a PythonProxyHandler to connect to a
	 *            Python gateway.
	 * @param connectTimeout
	 *            Time in milliseconds (0 = infinite). If a GatewayServer does
	 *            not receive a connection request after this time, it closes
	 *            the server socket and no other connection is accepted.
	 * @param readTimeout
	 *            Time in milliseconds (0 = infinite). Once a Python program is
	 *            connected, if a GatewayServer does not receive a request
	 *            (e.g., a method call) after this time, the connection with the
	 *            Python program is closed.
	 * @param customCommands
	 *            A list of custom Command classes to augment the Server
	 *            features. These commands will be accessible from Python
	 *            programs. Can be null.
	 */
	public GatewayServer(Object entryPoint, int port, int pythonPort, InetAddress address, InetAddress pythonAddress,
			int connectTimeout, int readTimeout, List<Class<? extends Command>> customCommands) {
		this(entryPoint, port, address, connectTimeout, readTimeout, customCommands,
				new CallbackClient(pythonPort, pythonAddress), ServerSocketFactory.getDefault());
	}

	/**
	 * <p>
	 * Replace the callback client with the new one which connects to the given address
	 * and port. This method is useful if for some reason your CallbackServer changes its
	 * address or you come to know of the address after Gateway has already instantiated.
	 * </p>
	 *
	 * <p>
	 * This method <strong>is not thread-safe</strong>! Make sure that only
	 * one thread calls this method.
	 * </p>
	 *
	 * @param pythonAddress
	 *            The address used by a PythonProxyHandler to connect to a
	 *            Python gateway.
	 * @param pythonPort
	 *            The port used by a PythonProxyHandler to connect to a Python
	 *            gateway. Essentially the port used for Python callbacks.
	 */
	public void resetCallbackClient(InetAddress pythonAddress, int pythonPort) {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.resetCallbackClient 1");
		gateway.resetCallbackClient(pythonAddress, pythonPort);
		this.pythonPort = pythonPort;
		this.pythonAddress = pythonAddress;
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.resetCallbackClient 1");
	}

	/**
	 *
	 * @param entryPoint
	 *            The entry point of this Gateway. Can be null.
	 * @param port
	 *            The port the GatewayServer is listening to.
	 * @param connectTimeout
	 *            Time in milliseconds (0 = infinite). If a GatewayServer does
	 *            not receive a connection request after this time, it closes
	 *            the server socket and no other connection is accepted.
	 * @param readTimeout
	 *            Time in milliseconds (0 = infinite). Once a Python program is
	 *            connected, if a GatewayServer does not receive a request
	 *            (e.g., a method call) after this time, the connection with the
	 *            Python program is closed.
	 */
	public GatewayServer(Object entryPoint, int port, int connectTimeout, int readTimeout) {
		this(entryPoint, port, DEFAULT_PYTHON_PORT, connectTimeout, readTimeout, null);
	}

	/**
	 *
	 * @param entryPoint
	 *            The entry point of this Gateway. Can be null.
	 * @param port
	 *            The port the GatewayServer is listening to.
	 * @param pythonPort
	 *            The port used by a PythonProxyHandler to connect to a Python
	 *            gateway. Essentially the port used for Python callbacks.
	 * @param connectTimeout
	 *            Time in milliseconds (0 = infinite). If a GatewayServer does
	 *            not receive a connection request after this time, it closes
	 *            the server socket and no other connection is accepted.
	 * @param readTimeout
	 *            Time in milliseconds (0 = infinite). Once a Python program is
	 *            connected, if a GatewayServer does not receive a request
	 *            (e.g., a method call) after this time, the connection with the
	 *            Python program is closed.
	 * @param customCommands
	 *            A list of custom Command classes to augment the Server
	 *            features. These commands will be accessible from Python
	 *            programs. Can be null.
	 */
	public GatewayServer(Object entryPoint, int port, int pythonPort, int connectTimeout, int readTimeout,
			List<Class<? extends Command>> customCommands) {
		this(entryPoint, port, defaultAddress(), connectTimeout, readTimeout, customCommands,
				new CallbackClient(pythonPort, defaultAddress()), ServerSocketFactory.getDefault());
	}

	/**
	 *
	 * @param entryPoint
	 *            The entry point of this Gateway. Can be null.
	 * @param port
	 *            The port the GatewayServer is listening to.
	 * @param connectTimeout
	 *            Time in milliseconds (0 = infinite). If a GatewayServer does
	 *            not receive a connection request after this time, it closes
	 *            the server socket and no other connection is accepted.
	 * @param readTimeout
	 *            Time in milliseconds (0 = infinite). Once a Python program is
	 *            connected, if a GatewayServer does not receive a request
	 *            (e.g., a method call) after this time, the connection with the
	 *            Python program is closed.
	 * @param customCommands
	 *            A list of custom Command classes to augment the Server
	 *            features. These commands will be accessible from Python
	 *            programs. Can be null.
	 * @param cbClient
	 * 			  An instance of a callback client.
	 */
	public GatewayServer(Object entryPoint, int port, int connectTimeout, int readTimeout,
			List<Class<? extends Command>> customCommands, Py4JPythonClient cbClient) {
		this(entryPoint, port, defaultAddress(), connectTimeout, readTimeout, customCommands, cbClient,
				ServerSocketFactory.getDefault());
	}

	/**
	 *
	 * @param entryPoint
	 *            The entry point of this Gateway. Can be null.
	 * @param port
	 *            The port the GatewayServer is listening to.
	 * @param address
	 *            The address the GatewayServer is listening to.
	 * @param connectTimeout
	 *            Time in milliseconds (0 = infinite). If a GatewayServer does
	 *            not receive a connection request after this time, it closes
	 *            the server socket and no other connection is accepted.
	 * @param readTimeout
	 *            Time in milliseconds (0 = infinite). Once a Python program is
	 *            connected, if a GatewayServer does not receive a request
	 *            (e.g., a method call) after this time, the connection with the
	 *            Python program is closed.
	 * @param customCommands
	 *            A list of custom Command classes to augment the Server
	 *            features. These commands will be accessible from Python
	 *            programs. Can be null.
	 * @param cbClient
	 * 			  An instance of a callback client.
	 */
	public GatewayServer(Object entryPoint, int port, InetAddress address, int connectTimeout, int readTimeout,
			List<Class<? extends Command>> customCommands, Py4JPythonClient cbClient) {
		this(entryPoint, port, address, connectTimeout, readTimeout, customCommands, cbClient,
				ServerSocketFactory.getDefault());
	}

	/**
	 *
	 * @param entryPoint
	 *        The entry point of this Gateway. Can be null.
	 * @param port
	 *        The port the GatewayServer is listening to.
	 * @param address
	 *        The address the GatewayServer is listening to.
	 * @param connectTimeout
	 *        Time in milliseconds (0 = infinite). If a GatewayServer does
	 *        not receive a connection request after this time, it closes
	 *        the server socket and no other connection is accepted.
	 * @param readTimeout
	 *        Time in milliseconds (0 = infinite). Once a Python program is
	 *        connected, if a GatewayServer does not receive a request
	 *        (e.g., a method call) after this time, the connection with the
	 *        Python program is closed.
	 * @param customCommands
	 *        A list of custom Command classes to augment the Server
	 *        features. These commands will be accessible from Python
	 *        programs. Can be null.
	 * @param sSocketFactory
	 *        A factory that creates the server sockets that we listen on.
	 */
	public GatewayServer(Object entryPoint, int port, InetAddress address, int connectTimeout, int readTimeout,
			List<Class<? extends Command>> customCommands, Py4JPythonClient cbClient,
			ServerSocketFactory sSocketFactory) {
		this(entryPoint, port, address, connectTimeout, readTimeout, customCommands, cbClient, sSocketFactory, null);
	}

	GatewayServer(Object entryPoint, int port, InetAddress address, int connectTimeout, int readTimeout,
			List<Class<? extends Command>> customCommands, Py4JPythonClient cbClient,
			ServerSocketFactory sSocketFactory, String authToken) {
		super();
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.constructor 1");
		this.port = port;
		this.address = address;
		this.connectTimeout = connectTimeout;
		this.readTimeout = readTimeout;
		this.gateway = new Gateway(entryPoint, cbClient);
		this.pythonPort = cbClient.getPort();
		this.pythonAddress = cbClient.getAddress();
		this.gateway.putObject(GATEWAY_SERVER_ID, this);
		if (customCommands != null) {
			this.customCommands = customCommands;
		} else {
			this.customCommands = new ArrayList<Class<? extends Command>>();
		}
		this.listeners = new CopyOnWriteArrayList<GatewayServerListener>();
		this.sSocketFactory = sSocketFactory;
		this.authToken = authToken;
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.constructor 1");
	}

	/**
	 * @param gateway gateway instance (or subclass).  Must not be <code>null</code>.
	 * @param port the host port to usu
	 * @param address the host address to use
	 * @param connectTimeout the connect timeout (ms)
	 * @param readTimeout the read timeout (ms)
	 * @param customCommands any customCommands to use.  May be <code>null</code>
	 * @param sSocketFactory socketFactory to use.  Must not be <code>null</code>
	 */
	public GatewayServer(Gateway gateway, int port, InetAddress address, int connectTimeout, int readTimeout,
			List<Class<? extends Command>> customCommands, ServerSocketFactory sSocketFactory) {
		this(gateway, port, address, connectTimeout, readTimeout, customCommands, sSocketFactory, null);
	}

	private GatewayServer(Gateway gateway, int port, InetAddress address, int connectTimeout, int readTimeout,
			List<Class<? extends Command>> customCommands, ServerSocketFactory sSocketFactory, String authToken) {
		super();
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.constructor 2");
		this.port = port;
		this.address = address;
		this.connectTimeout = connectTimeout;
		this.readTimeout = readTimeout;
		this.gateway = gateway;
		this.pythonPort = gateway.getCallbackClient().getPort();
		this.pythonAddress = gateway.getCallbackClient().getAddress();
		this.gateway.putObject(GATEWAY_SERVER_ID, this);
		if (customCommands != null) {
			this.customCommands = customCommands;
		} else {
			this.customCommands = new ArrayList<Class<? extends Command>>();
		}
		this.listeners = new CopyOnWriteArrayList<GatewayServerListener>();
		this.sSocketFactory = sSocketFactory;
		this.authToken = authToken;
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.constructor 2");
	}

	public void addListener(GatewayServerListener listener) {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.addListener 1");
		listeners.addIfAbsent(listener);
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.addListener 1");
	}

	public void connectionStopped(Py4JServerConnection gatewayConnection) {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.connectionStopped 1");
		try {
			lock.lock();
			if (!isShutdown) {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.connectionStopped 2");
				connections.remove(gatewayConnection);
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.connectionStopped 2");
			}
		} finally {
			lock.unlock();
		}
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.connectionStopped 1");
	}

	/**
	 * <p>
	 * Creates a server connection from a Python call to the Java side.
	 * </p>
	 *
	 * @param gateway
	 * @param socket
	 * @return
	 * @throws IOException
	 */
	protected Py4JServerConnection createConnection(Gateway gateway, Socket socket) throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.createConnection 1");
		GatewayConnection connection = new GatewayConnection(gateway, socket, authToken, customCommands, listeners);
		connection.startConnection();
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.createConnection 1");

		return connection;
	}

	protected void fireConnectionError(Exception e) {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireConnectionError 1");
		logger.log(Level.SEVERE, "Connection Server Error", e);
		for (GatewayServerListener listener : listeners) {
			try {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireConnectionError 2");
				listener.connectionError(e);
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireConnectionError 2");
			} catch (Exception ex) {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireConnectionError 3");
				logger.log(Level.SEVERE, "A listener crashed.", ex);
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireConnectionError 3");
			}
		}
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireConnectionError 1");
	}

	protected void fireConnectionStarted(Py4JServerConnection gatewayConnection) {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireConnectionStarted 1");
		logger.info("Connection Started");
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireConnectionStarted 1");

		for (GatewayServerListener listener : listeners) {
			try {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireConnectionStarted 2");
				listener.connectionStarted(gatewayConnection);
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireConnectionStarted 2");
			} catch (Exception e) {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireConnectionStarted 3");
				logger.log(Level.SEVERE, "A listener crashed.", e);
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireConnectionStarted 3");
			}
		}
	}

	protected void fireServerError(Exception e) {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireServerError 1");
		boolean sendEvent = false;
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireServerError 1");

		if (e.getMessage().toLowerCase().contains("socket closed")) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireServerError 2");
			// This is just an internal error that will always be thrown when
			// closing a server socket that is accepting a connection
			logger.log(Level.FINE, "Gateway Server Error", e);
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireServerError 2");
		} else {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireServerError 3");
			sendEvent = true;
			logger.log(Level.SEVERE, "Gateway Server Error", e);
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireServerError 3");
		}
		if (sendEvent) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireServerError 4");
			for (GatewayServerListener listener : listeners) {
				try {
					System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireServerError 5");
					listener.serverError(e);
					System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireServerError 5");
				} catch (Exception ex) {
					System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireServerError 6");
					logger.log(Level.SEVERE, "A listener crashed.", ex);
					System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireServerError 6");
				}
			}
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireServerError 4");
		}
	}

	protected void fireServerPostShutdown() {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireServerPostShutdown 1");
		logger.fine("Gateway Server Post Shutdown");
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireServerPostShutdown 1");

		for (GatewayServerListener listener : listeners) {
			try {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireServerPostShutdown 2");
				listener.serverPostShutdown();
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireServerPostShutdown 2");
			} catch (Exception e) {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireServerPostShutdown 3");
				logger.log(Level.SEVERE, "A listener crashed.", e);
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireServerPostShutdown 3");
			}
		}
	}

	protected void fireServerPreShutdown() {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireServerPreShutdown 1");
		logger.fine("Gateway Server Pre Shutdown");
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireServerPreShutdown 1");

		for (GatewayServerListener listener : listeners) {
			try {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireServerPreShutdown 2");
				listener.serverPreShutdown();
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireServerPreShutdown 2");
			} catch (Exception e) {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireServerPreShutdown 3");
				logger.log(Level.SEVERE, "A listener crashed.", e);
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireServerPreShutdown 3");
			}
		}
	}

	protected void fireServerStarted() {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireServerStarted 1");
		logger.info("Gateway Server Started");
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireServerStarted 1");

		for (GatewayServerListener listener : listeners) {
			try {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireServerStarted 2");
				listener.serverStarted();
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireServerStarted 2");
			} catch (Exception e) {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireServerStarted 3");
				logger.log(Level.SEVERE, "A listener crashed.", e);
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireServerStarted 3");
			}
		}
	}

	protected void fireServerStopped() {
		logger.info("Gateway Server Stopped");
		for (GatewayServerListener listener : listeners) {
			try {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireServerStopped 2");
				listener.serverStopped();
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireServerStopped 2");
			} catch (Exception e) {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.fireServerStopped 3");
				logger.log(Level.SEVERE, "A listener crashed.", e);
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.fireServerStopped 3");
			}
		}
	}

	@Override
	public InetAddress getAddress() {
		return address;
	}

	public Py4JPythonClient getCallbackClient() {
		return gateway.getCallbackClient();
	}

	public int getConnectTimeout() {
		return connectTimeout;
	}

	public Gateway getGateway() {
		return gateway;
	}

	/**
	 *
	 * @return The port the server socket is listening on. It will be different
	 *         than the specified port if the socket is listening on an
	 *         ephemeral port (specified port = 0). Returns -1 if the server
	 *         socket is not listening on anything.
	 */
	@Override
	public int getListeningPort() {
		int port = -1;
		try {
			if (sSocket.isBound()) {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.getListeningPort 2");
				port = sSocket.getLocalPort();
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.getListeningPort 2");
			}
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.getListeningPort 3");
			// do nothing
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.getListeningPort 3");
		}
		return port;
	}

	/**
	 *
	 * @return The port specified when the gateway server is initialized. This
	 *         is the port that is passed to the server socket.
	 */
	@Override
	public int getPort() {
		return port;
	}

	@Override
	public InetAddress getPythonAddress() {
		return pythonAddress;
	}

	@Override
	public int getPythonPort() {
		return pythonPort;
	}

	public int getReadTimeout() {
		return readTimeout;
	}

	protected void processSocket(Socket socket) {
		try {
			lock.lock();
			if (!isShutdown) {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.processSocket 2");
				socket.setSoTimeout(readTimeout);
				Py4JServerConnection gatewayConnection = createConnection(gateway, socket);
				connections.add(gatewayConnection);
				fireConnectionStarted(gatewayConnection);
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.processSocket 2");
			}
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.processSocket 3");
			// Error while processing a connection should not be prevent the
			// gateway server from accepting new connections.
			fireConnectionError(e);
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.processSocket 3");
		} finally {
			lock.unlock();
		}
	}

	@Override
	public void removeListener(GatewayServerListener listener) {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.removeListener 1");
		listeners.remove(listener);
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.removeListener 1");
	}

	@Override
	public void run() {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.run 1");
		try {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.run 2");
			gateway.startup();
			fireServerStarted();
			addListener(this);
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.run 2");
			while (!isShutdown) {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.run 3");
				Socket socket = sSocket.accept();
				processSocket(socket);
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.run 3");
			}
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.run 4");
			fireServerError(e);
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.run 4");
		}
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.run 5");
		fireServerStopped();
		removeListener(this);
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.run 5");
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.run 1");
	}

	/**
	 * <p>
	 * Stops accepting connections, closes all current connections, and calls
	 * {@link py4j.Gateway#shutdown() Gateway.shutdown()}
	 * </p>
	 */
	public void shutdown() {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.shutdown 1");
		this.shutdown(true);
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.shutdown 1");
	}

	public void shutdownSocket(String address, int remotePort, int localPort) {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.shutdownSocket 1");
		try {
			lock.lock();
			ArrayList<Py4JServerConnection> tempConnections = new ArrayList<Py4JServerConnection>(connections);
			for (Py4JServerConnection connection : tempConnections) {
				if (connection.getSocket() != null && (connection.getSocket().getPort() == remotePort
						|| connection.getSocket().getLocalPort() == localPort)) {
					System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.shutdownSocket 2");
					connection.shutdown();
					connections.remove(connection);
					System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.shutdownSocket 2");
				}
			}
		} finally {
			lock.unlock();
		}
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.shutdownSocket 1");
	}

	/**
	 * <p>
	 * Stops accepting connections, closes all current connections, and calls
	 * {@link py4j.Gateway#shutdown() Gateway.shutdown()}
	 * </p>
	 *
	 * @param shutdownCallbackClient If True, shuts down the CallbackClient
	 *                                  instance.
	 */
	public void shutdown(boolean shutdownCallbackClient) {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.shutdown 2");
		fireServerPreShutdown();
		try {
			lock.lock();
			if (isShuttingDown) {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.shutdown 3");
				// Prevent call to shutdown by a listener.
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.shutdown 3");
				return;
			}
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.shutdown 4");
			isShutdown = true;
			isShuttingDown = true;
			NetworkUtil.quietlyClose(sSocket);
			ArrayList<Py4JServerConnection> tempConnections = new ArrayList<Py4JServerConnection>(connections);
			for (Py4JServerConnection connection : tempConnections) {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.shutdown 5");
				connection.shutdown();
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.shutdown 5");
			}
			// Clear existing connections
			connections.clear();
			gateway.shutdown(shutdownCallbackClient);
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.shutdown 4");
		} finally {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.shutdown 6");
			// If an error occurs, do not prevent the shutdown method from being called again.
			isShuttingDown = false;
			lock.unlock();
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.shutdown 6");
		}
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.shutdown 7");
		fireServerPostShutdown();
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.shutdown 7");
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.shutdown 2");
	}

	/**
	 * <p>
	 * Starts to accept connections in a second thread (non-blocking call).
	 * </p>
	 */
	public void start() {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.start 1");
		start(true);
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.start 1");
	}

	/**
	 * <p>
	 * Starts to accept connections.
	 * </p>
	 *
	 * @param fork
	 *            If true, the GatewayServer accepts connection in another
	 *            thread and this call is non-blocking. If False, the
	 *            GatewayServer accepts connection in this thread and the call
	 *            is blocking (until the Gateway is shutdown by another thread).
	 * @throws Py4JNetworkException
	 *             If the server socket cannot start.
	 */
	public void start(boolean fork) {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.start 2");
		startSocket();

		if (fork) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.start 3");
			Thread t = new Thread(this);
			t.start();
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.start 3");
		} else {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServer.start 4");
			run();
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.start 4");
		}
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServer.start 2");
	}

	/**
	 * <p>
	 * Starts the ServerSocket.
	 * </p>
	 *
	 * @throws Py4JNetworkException
	 *             If the port is busy.
	 */
	protected void startSocket() throws Py4JNetworkException {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter startSocket 1");
		try {
			sSocket = sSocketFactory.createServerSocket();
			sSocket.setSoTimeout(connectTimeout);
			sSocket.setReuseAddress(true);
			sSocket.bind(new InetSocketAddress(address, port), -1);
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit startSocket 1");
		} catch (IOException e) {
			throw new Py4JNetworkException("Failed to bind to " + address + ":" + port, e);
		}
	}

	/**
	 * <p>
	 * Gets a reference to the entry point on the Python side. This is often
	 * necessary if Java is driving the communication because Java cannot call
	 * static methods, initialize Python objects or load Python modules yet.
	 * </p>
	 *
	 * @param interfacesToImplement
	 * @return
	 */
	public Object getPythonServerEntryPoint(@SuppressWarnings("rawtypes") Class[] interfacesToImplement) {
		return getCallbackClient().getPythonServerEntryPoint(gateway, interfacesToImplement);
	}

	/**
	 * <p>
	 * Main method to start a local GatewayServer on either a given port or the default one.
	 * The listening port is printed to stdout so that clients can start
	 * servers on ephemeral ports.
	 * </p>
	 *
	 * <p>
	 * If authentication is enabled, the server will create an auth secret with 256 bits of entropy
	 * and print it to stdout after the server port. Clients should then provide this secret when
	 * connecting to the server. Note that no second line of output is printed if authentication is
	 * not enabled.
	 * </p>
	 */
	public static void main(String[] args) {
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter main 1");
		int port = DEFAULT_PORT;
		boolean dieOnBrokenPipe = false;
		boolean enableAuth = false;
		String usage = "usage: [--die-on-broken-pipe] [--enable-auth] [port]";
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit main 1");

		for (int i = 0; i < args.length; i++) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter main 2");
			String opt = args[i];
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit main 2");
			if (opt.equals("--die-on-broken-pipe")) {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter main 3");
				dieOnBrokenPipe = true;
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit main 3");
			} else if (opt.equals("--enable-auth")) {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter main 4");
				enableAuth = true;
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit main 4");
			} else {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter main 5");
				try {
					System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter main 6");
					port = Integer.parseInt(opt);
					System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit main 6");
				} catch (NumberFormatException e) {
					System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter main 7");
					System.err.println(usage);
					System.exit(1);
					System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit main 7");
				}
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit main 5");
			}
		}

		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter main 8");
		String authToken = null;
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit main 8");
		
		if (enableAuth) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter main 9");
			SecureRandom rnd = new SecureRandom();
			byte[] token = new byte[256 / Byte.SIZE];
			rnd.nextBytes(token);
			authToken = Base64.encodeToString(token, false);
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit main 9");
		}

		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter main 10");
		GatewayServer gatewayServer = new GatewayServerBuilder().javaPort(port).authToken(authToken).build();
		gatewayServer.start();
		/* Print out the listening port so that clients can discover it. */
		int listening_port = gatewayServer.getListeningPort();
		System.out.println("" + listening_port);
		System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit main 10");

		if (authToken != null) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter main 11");
			System.out.println(authToken);
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit main 11");
		}

		if (dieOnBrokenPipe) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter main 12");
			/* Exit on EOF or broken pipe.  This ensures that the server dies
			 * if its parent program dies. */
			try {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter main 13");
				BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in, Charset.forName("UTF-8")));
				stdin.readLine();
				System.exit(0);
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit main 13");
			} catch (java.io.IOException e) {
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter main 14");
				System.exit(1);
				System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit main 14");
			}
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit main 12");
		}
	}

	/**
	 *
	 * @return An unmodifiable list of custom commands
	 */
	public List<Class<? extends Command>> getCustomCommands() {
		return Collections.unmodifiableList(customCommands);
	}

	/**
	 *
	 * @return An unmodifiable list of listeners
	 */
	public List<GatewayServerListener> getListeners() {
		return Collections.unmodifiableList(listeners);
	}

	/**
	 * Helper class to make it easier and self-documenting how a
	 * {@link GatewayServer} is constructed.
	 */
	public static class GatewayServerBuilder {
		private int javaPort;
		private InetAddress javaAddress;
		private int connectTimeout;
		private int readTimeout;
		private Gateway gateway;
		private ServerSocketFactory serverSocketFactory;
		private Object entryPoint;
		private Py4JPythonClient callbackClient;
		private List<Class<? extends Command>> customCommands;
		private String authToken;

		public GatewayServerBuilder() {
			this(null);
		}

		public GatewayServerBuilder(Object entryPoint) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter GatewayServerBuilder 2");
			javaPort = GatewayServer.DEFAULT_PORT;
			javaAddress = GatewayServer.defaultAddress();
			connectTimeout = GatewayServer.DEFAULT_CONNECT_TIMEOUT;
			readTimeout = GatewayServer.DEFAULT_READ_TIMEOUT;
			serverSocketFactory = ServerSocketFactory.getDefault();
			this.entryPoint = entryPoint;
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit GatewayServerBuilder 2");
		}

		/**
		 * <p>
		 * Builds a GatewayServer instance using the provided parameters. If gateway is provided,
		 * some parameters will be ignored (callbackClient and entryPoint).
		 * </p>
		 *
		 * @return
		 */
		public GatewayServer build() {
			if (gateway == null) {
				if (callbackClient == null) {
					System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter build 3");
					callbackClient = new CallbackClient(GatewayServer.DEFAULT_PYTHON_PORT);
					System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit build 3");
				}
				return new GatewayServer(entryPoint, javaPort, javaAddress, connectTimeout, readTimeout, customCommands,
						callbackClient, serverSocketFactory, authToken);
			} else {
				return new GatewayServer(gateway, javaPort, javaAddress, connectTimeout, readTimeout, customCommands,
						serverSocketFactory, authToken);
			}
		}

		public GatewayServerBuilder gateway(Gateway gateway) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter gateway 1");
			this.gateway = gateway;
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit gateway 1");
			return this;
		}

		public GatewayServerBuilder javaPort(int javaPort) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter javaPort 1");
			this.javaPort = javaPort;
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit javaPort 1");
			return this;
		}

		public GatewayServerBuilder javaAddress(InetAddress javaAddress) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter javaAddress 1");
			this.javaAddress = javaAddress;
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit javaAddress 1");
			return this;
		}

		public GatewayServerBuilder callbackClient(int pythonPort, InetAddress pythonAddress) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter callbackClient 1");
			callbackClient = new CallbackClient(pythonPort, pythonAddress);
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit callbackClient 1");
			return this;
		}

		/**
		 * Set up the callback client to talk to the server running at the given address and port,
		 * authenticating with the given token. If the token is null, no authentication will be
		 * attempted.
		 */
		public GatewayServerBuilder callbackClient(int pythonPort, InetAddress pythonAddress, String authToken) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter callbackClient 2");
			callbackClient = new CallbackClient(pythonPort, pythonAddress, authToken);
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit callbackClient 2");
			return this;
		}

		public GatewayServerBuilder callbackClient(CallbackClient callbackClient) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter callbackClient 3");
			this.callbackClient = callbackClient;
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit callbackClient 3");
			return this;
		}

		public GatewayServerBuilder connectTimeout(int connectTimeout) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter connectTimeout 1");
			this.connectTimeout = connectTimeout;
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit connectTimeout 1");
			return this;
		}

		public GatewayServerBuilder readTimeout(int readTimeout) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter readTimeout 1");
			this.readTimeout = readTimeout;
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit readTimeout 1");
			return this;
		}

		public GatewayServerBuilder serverSocketFactory(ServerSocketFactory serverSocketFactory) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter serverSocketFactory 1");
			this.serverSocketFactory = serverSocketFactory;
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit serverSocketFactory 1");
			return this;
		}

		public GatewayServerBuilder entryPoint(Object entryPoint) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter entryPoint 1");
			this.entryPoint = entryPoint;
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit entryPoint 1");
			return this;
		}

		public GatewayServerBuilder customCommands(List<Class<? extends Command>> customCommands) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter customCommands 1");
			this.customCommands = customCommands;
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit customCommands 1");
			return this;
		}

		/**
		 * Authentication token that clients must provide to the server when connecting. If null,
		 * authentication is disabled.
		 */
		public GatewayServerBuilder authToken(String authToken) {
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] enter authToken 1");
			this.authToken = StringUtil.escape(authToken);
			System.err.println("[py4j-java/src/main/java/py4j/GatewayServer.java] exit authToken 1");
			return this;
		}
	}
}
// Total cost: 0.398567
// Total split cost: 0.104548, input tokens: 36029, output tokens: 1025, cache read tokens: 22926, cache write tokens: 11463, split chunks: [(0, 796), (796, 1024)]
// Total instrumented cost: 0.294019, input tokens: 14617, output tokens: 14006, cache read tokens: 2280, cache write tokens: 12329

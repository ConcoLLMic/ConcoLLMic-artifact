/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j.commands;

import static py4j.NetworkUtil.safeReadLine;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.logging.Logger;

import py4j.Gateway;
import py4j.JVMView;
import py4j.Protocol;
import py4j.Py4JException;
import py4j.Py4JServerConnection;
import py4j.ReturnObject;
import py4j.StringUtil;
import py4j.reflection.ReflectionEngine;

/**
 * <p>
 * A JVMViewCommand is responsible for managing JVM views: creating views,
 * adding imports, searching for fully qualified names.
 * </p>
 *
 * @author Barthelemy Dagenais
 *
 */
public class JVMViewCommand extends AbstractCommand {

	private final Logger logger = Logger.getLogger(JVMViewCommand.class.getName());

	public final static char CREATE_VIEW_SUB_COMMAND_NAME = 'c';

	public final static char IMPORT_SUB_COMMAND_NAME = 'i';

	public final static char REMOVE_IMPORT_SUB_COMMAND_NAME = 'r';

	public final static char SEARCH_SUB_COMMAND_NAME = 's';

	public static final String JVMVIEW_COMMAND_NAME = "j";

	protected ReflectionEngine rEngine;

	public JVMViewCommand() {
		super();
		System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] enter JVMViewCommand 1");
		this.commandName = JVMVIEW_COMMAND_NAME;
		System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] exit JVMViewCommand 1");
	}

	private String createJVMView(BufferedReader reader) throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] enter createJVMView 1");
		String name = StringUtil.unescape(reader.readLine());
		reader.readLine();

		JVMView newView = new JVMView(name, null);
		ReturnObject rObject = gateway.getReturnObject(newView);
		newView.setId(rObject.getName());
		System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] exit createJVMView 1");

		return Protocol.getOutputCommand(rObject);
	}

	private String doImport(BufferedReader reader) throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] enter doImport 1");
		String jvmId = reader.readLine();
		String importString = StringUtil.unescape(reader.readLine());
		reader.readLine();

		JVMView view = (JVMView) Protocol.getObject(jvmId, gateway);
		System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] exit doImport 1");
		if (importString.endsWith("*")) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] enter doImport 2");
			view.addStarImport(importString);
			System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] exit doImport 2");
		} else {
			System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] enter doImport 3");
			view.addSingleImport(importString);
			System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] exit doImport 3");
		}

		return Protocol.getOutputVoidCommand();
	}

	@Override
	public void execute(String commandName, BufferedReader reader, BufferedWriter writer)
			throws Py4JException, IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] enter execute 1");
		char subCommand = safeReadLine(reader).charAt(0);
		String returnCommand = null;
		System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] exit execute 1");

		if (subCommand == CREATE_VIEW_SUB_COMMAND_NAME) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] enter execute 2");
			returnCommand = createJVMView(reader);
			System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] exit execute 2");
		} else if (subCommand == IMPORT_SUB_COMMAND_NAME) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] enter execute 3");
			returnCommand = doImport(reader);
			System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] exit execute 3");
		} else if (subCommand == REMOVE_IMPORT_SUB_COMMAND_NAME) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] enter execute 4");
			returnCommand = removeImport(reader);
			System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] exit execute 4");
		} else if (subCommand == SEARCH_SUB_COMMAND_NAME) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] enter execute 5");
			returnCommand = search(reader);
			System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] exit execute 5");
		} else {
			System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] enter execute 6");
			returnCommand = Protocol.getOutputErrorCommand("Unknown JVM View SubCommand Name: " + subCommand);
			System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] exit execute 6");
		}
		System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] enter execute 7");
		logger.finest("Returning command: " + returnCommand);
		writer.write(returnCommand);
		writer.flush();
		System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] exit execute 7");
	}

	@Override
	public void init(Gateway gateway, Py4JServerConnection connection) {
		System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] enter init 1");
		super.init(gateway, connection);
		rEngine = gateway.getReflectionEngine();
		System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] exit init 1");
	}

	private String removeImport(BufferedReader reader) throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] enter removeImport 1");
		String jvmId = reader.readLine();
		String importString = StringUtil.unescape(reader.readLine());

		reader.readLine();

		JVMView view = (JVMView) Protocol.getObject(jvmId, gateway);
		boolean removed = false;
		System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] exit removeImport 1");
		if (importString.endsWith("*")) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] enter removeImport 2");
			removed = view.removeStarImport(importString);
			System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] exit removeImport 2");
		} else {
			System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] enter removeImport 3");
			removed = view.removeSingleImport(importString);
			System.err.println("[py4j-java/src/main/java/py4j/commands/JVMViewCommand.java] exit removeImport 3");
		}

		return Protocol.getOutputCommand(ReturnObject.getPrimitiveReturnObject(removed));
	}

	private String search(BufferedReader reader) {
		return null;
	}

}
// Total cost: 0.043194
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 153)]
// Total instrumented cost: 0.043194, input tokens: 3900, output tokens: 2106, cache read tokens: 2280, cache write tokens: 1616

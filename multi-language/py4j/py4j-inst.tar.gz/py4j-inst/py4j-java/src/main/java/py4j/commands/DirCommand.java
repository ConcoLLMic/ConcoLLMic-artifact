/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j.commands;

import static py4j.NetworkUtil.safeReadLine;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import py4j.Gateway;
import py4j.JVMView;
import py4j.Protocol;
import py4j.Py4JException;
import py4j.Py4JServerConnection;
import py4j.ReturnObject;
import py4j.reflection.ReflectionEngine;
import py4j.reflection.TypeUtil;

public class DirCommand extends AbstractCommand {

	private final Logger logger = Logger.getLogger(DirCommand.class.getName());

	private ReflectionEngine reflectionEngine;

	public static final String DIR_COMMAND_NAME = "d";
	public static final String DIR_FIELDS_SUBCOMMAND_NAME = "f";
	public static final String DIR_METHODS_SUBCOMMAND_NAME = "m";
	public static final String DIR_STATIC_SUBCOMMAND_NAME = "s";
	public static final String DIR_JVMVIEW_SUBCOMMAND_NAME = "v";

	public DirCommand() {
		System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter DirCommand 1");
		this.commandName = DIR_COMMAND_NAME;
		System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit DirCommand 1");
	}

	@Override
	public void execute(String commandName, BufferedReader reader, BufferedWriter writer)
			throws Py4JException, IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter execute 1");
		String subCommand = safeReadLine(reader);

		boolean unknownSubCommand = false;
		String param = reader.readLine();
		String returnCommand = null;
		System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit execute 1");
		try {
			System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter execute 2");
			final String[] names;
			System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit execute 2");
			if (subCommand.equals(DIR_FIELDS_SUBCOMMAND_NAME)) {
				System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter execute 3");
				Object targetObject = gateway.getObject(param);
				names = reflectionEngine.getPublicFieldNames(targetObject);
				System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit execute 3");
			} else if (subCommand.equals(DIR_METHODS_SUBCOMMAND_NAME)) {
				System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter execute 4");
				Object targetObject = gateway.getObject(param);
				names = reflectionEngine.getPublicMethodNames(targetObject);
				System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit execute 4");
			} else if (subCommand.equals(DIR_STATIC_SUBCOMMAND_NAME)) {
				System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter execute 5");
				Class<?> clazz = TypeUtil.forName(param);
				names = reflectionEngine.getPublicStaticNames(clazz);
				System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit execute 5");
			} else if (subCommand.equals(DIR_JVMVIEW_SUBCOMMAND_NAME)) {
				System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter execute 6");
				names = getJvmViewNames(param, reader);
				System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit execute 6");
			} else {
				System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter execute 7");
				names = null;
				unknownSubCommand = true;
				System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit execute 7");
			}

			System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter execute 8");
			// Read and discard end of command
			reader.readLine();
			System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit execute 8");

			if (unknownSubCommand) {
				System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter execute 9");
				returnCommand = Protocol.getOutputErrorCommand("Unknown Array SubCommand Name: " + subCommand);
				System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit execute 9");
			} else if (names == null) {
				System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter execute 10");
				ReturnObject returnObject = gateway.getReturnObject(null);
				returnCommand = Protocol.getOutputCommand(returnObject);
				System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit execute 10");
			} else {
				System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter execute 11");
				StringBuilder namesJoinedBuilder = new StringBuilder();
				System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit execute 11");
				for (String name : names) {
					System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter execute 12");
					namesJoinedBuilder.append(name);
					namesJoinedBuilder.append("\n");
					System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit execute 12");
				}
				System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter execute 13");
				final String namesJoined;
				System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit execute 13");
				if (namesJoinedBuilder.length() > 0) {
					System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter execute 14");
					namesJoined = namesJoinedBuilder.substring(0, namesJoinedBuilder.length() - 1);
					System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit execute 14");
				} else {
					System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter execute 15");
					namesJoined = "";
					System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit execute 15");
				}

				System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter execute 16");
				ReturnObject returnObject = gateway.getReturnObject(namesJoined);
				returnCommand = Protocol.getOutputCommand(returnObject);
				System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit execute 16");
			}
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter execute 17");
			logger.log(Level.FINEST, "Error in a dir subcommand", e);
			returnCommand = Protocol.getOutputErrorCommand();
			System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit execute 17");
		}

		System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter execute 18");
		logger.finest("Returning command: " + returnCommand);
		writer.write(returnCommand);
		writer.flush();
		System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit execute 18");
	}

	private String[] getJvmViewNames(String jvmId, BufferedReader reader) throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter getJvmViewNames 1");
		String lastSequenceIdString = (String) Protocol.getObject(reader.readLine(), gateway);
		final int lastSequenceId;
		System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit getJvmViewNames 1");
		if (lastSequenceIdString == null) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter getJvmViewNames 2");
			lastSequenceId = 0;
			System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit getJvmViewNames 2");
		} else {
			System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter getJvmViewNames 3");
			lastSequenceId = Integer.parseInt(lastSequenceIdString);
			System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit getJvmViewNames 3");
		}

		System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter getJvmViewNames 4");
		JVMView view = (JVMView) Protocol.getObject(jvmId, gateway);
		int sequenceId = view.getSequenceId();
		System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit getJvmViewNames 4");
		if (lastSequenceId == sequenceId) {
			return null;
		}

		System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter getJvmViewNames 6");
		String[] importedNames = view.getImportedNames();
		String[] returnValue = new String[importedNames.length + 1];
		returnValue[0] = Integer.toString(sequenceId);
		System.arraycopy(importedNames, 0, returnValue, 1, importedNames.length);
		System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit getJvmViewNames 6");

		return returnValue;
	}

	@Override
	public void init(Gateway gateway, Py4JServerConnection connection) {
		System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] enter init 1");
		super.init(gateway, connection);
		reflectionEngine = gateway.getReflectionEngine();
		System.err.println("[py4j-java/src/main/java/py4j/commands/DirCommand.java] exit init 1");
	}

}
// Total cost: 0.049348
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 153)]
// Total instrumented cost: 0.049348, input tokens: 4045, output tokens: 2451, cache read tokens: 2280, cache write tokens: 1761

/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j.reflection;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import py4j.Gateway;
import py4j.Protocol;
import py4j.Py4JException;

/**
 * <p>
 * A PythonProxyHandler is used in place of a Python object. Python programs can
 * send Python objects that implements a Java interface to the JVM: these Python
 * objects are represented by dynamic proxies with a PythonProxyHandler.
 * </p>
 *
 * @author Barthelemy Dagenais
 *
 */
public class PythonProxyHandler implements InvocationHandler {

	private final String id;

	private final Gateway gateway;

	private final Logger logger = Logger.getLogger(PythonProxyHandler.class.getName());

	private final String finalizeCommand;

	public final static String CALL_PROXY_COMMAND_NAME = "c\n";

	public final static String GARBAGE_COLLECT_PROXY_COMMAND_NAME = "g\n";

	public PythonProxyHandler(String id, Gateway gateway) {
		super();
		System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] enter PythonProxyHandler 1");
		this.id = id;
		this.gateway = gateway;
		this.finalizeCommand = GARBAGE_COLLECT_PROXY_COMMAND_NAME + id + "\ne\n";
		System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] exit PythonProxyHandler 1");
	}

	@Override
	protected void finalize() throws Throwable {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] enter finalize 1");
		try {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] enter finalize 2");
			if (gateway.getCallbackClient().isMemoryManagementEnabled() && this.id != Protocol.ENTRY_POINT_OBJECT_ID) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] enter finalize 3");
				logger.fine("Finalizing python proxy id " + this.id);
				gateway.getCallbackClient().sendCommand(finalizeCommand, false);
				System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] exit finalize 3");
			}
			System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] exit finalize 2");
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] enter finalize 4");
			logger.warning("Python Proxy ID could not send a finalize message: " + this.id);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] exit finalize 4");
		} finally {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] enter finalize 5");
			super.finalize();
			System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] exit finalize 5");
		}
		System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] exit finalize 1");
	}

	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] enter invoke 1");
		logger.fine("Method " + method.getName() + " called on Python object " + id);
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append(CALL_PROXY_COMMAND_NAME);
		sBuilder.append(id);
		sBuilder.append("\n");
		sBuilder.append(method.getName());
		sBuilder.append("\n");
		System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] exit invoke 1");

		if (args != null) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] enter invoke 2");
			for (Object arg : args) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] enter invoke 3");
				sBuilder.append(gateway.getReturnObject(arg).getCommandPart());
				sBuilder.append("\n");
				System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] exit invoke 3");
			}
			System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] exit invoke 2");
		}

		System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] enter invoke 4");
		sBuilder.append("e\n");

		String returnCommand = gateway.getCallbackClient().sendCommand(sBuilder.toString());

		Object output = Protocol.getReturnValue(returnCommand, gateway);
		Object convertedOutput = convertOutput(method, output);
		System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] exit invoke 4");
		return convertedOutput;
		
	}

	private Object convertOutput(Method method, Object output) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] enter convertOutput 1");
		Class<?> returnType = method.getReturnType();
		// If output is None/null or expected return type is 
		// Void then return output with no conversion
		if (output == null || returnType.equals(Void.TYPE)) {
			// Do not convert void
			return output;
		}
		System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] exit convertOutput 1");
		
		System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] enter convertOutput 3");
		Class<?> outputType = output.getClass();
		Class<?>[] parameters = { returnType };
		Class<?>[] arguments = { outputType };
		List<TypeConverter> converters = new ArrayList<TypeConverter>();
		int cost = MethodInvoker.buildConverters(converters, parameters, arguments);
		if (cost == -1) {
			// This will be wrapped into Py4JJavaException if the Java code is being called by Python.
			throw new Py4JException(
					"Incompatible output type. Expected: " + returnType.getName() + " Actual: " + outputType.getName());
		}
		System.err.println("[py4j-java/src/main/java/py4j/reflection/PythonProxyHandler.java] exit convertOutput 3");
		
		return converters.get(0).convert(output);
	}

}
// Total cost: 0.038625
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 134)]
// Total instrumented cost: 0.038625, input tokens: 3772, output tokens: 1859, cache read tokens: 2280, cache write tokens: 1488

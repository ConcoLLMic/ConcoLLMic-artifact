/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;

import py4j.commands.AuthCommand;

/**
 * <p>
 * Utility class used to perform network operations.
 * </p>
 *
 * @author Barthelemy Dagenais
 *
 */
public class NetworkUtil {

	private final static Logger logger = Logger.getLogger(NetworkUtil.class.getName());

	/**
	 *
	 * @param reader
	 * @param addSpace
	 * @return A non-null String with an optional space if it is empty.
	 * @throws IOException
	 */
	public static String safeReadLine(BufferedReader reader, boolean addSpace) throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] enter safeReadLine 1");
		String line = reader.readLine();
		if (line == null || (line.length() == 0 && addSpace)) {
			System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] enter safeReadLine 2");
			if (addSpace) {
				System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] enter safeReadLine 3");
				line = " ";
				System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] exit safeReadLine 3");
			} else {
				System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] enter safeReadLine 4");
				line = "";
				System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] exit safeReadLine 4");
			}
			System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] exit safeReadLine 2");
		}
		System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] exit safeReadLine 1");

		return line;
	}

	/**
	 *
	 * @param reader
	 * @return A String of at least one character (space if null or empty).
	 * @throws IOException
	 */
	public static String safeReadLine(BufferedReader reader) throws IOException {
		return safeReadLine(reader, true);
	}

	public static void quietlyClose(Closeable closeable) {
		System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] enter quietlyClose 1");
		try {
			if (closeable != null) {
				System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] enter quietlyClose 2");
				closeable.close();
				System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] exit quietlyClose 2");
			}
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] enter quietlyClose 3");
			logger.log(Level.FINE, "Closeable cannot be closed.", e);
			System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] exit quietlyClose 3");
		}
		System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] exit quietlyClose 1");
	}

	public static void quietlyClose(ServerSocket closeable) {
		System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] enter quietlyClose 4");
		try {
			if (closeable != null) {
				System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] enter quietlyClose 5");
				closeable.close();
				System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] exit quietlyClose 5");
			}
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] enter quietlyClose 6");
			logger.log(Level.FINE, "Socket cannot be closed.", e);
			System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] exit quietlyClose 6");
		}
		System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] exit quietlyClose 4");
	}

	public static void quietlyClose(Socket closeable) {
		System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] enter quietlyClose 7");
		try {
			if (closeable != null) {
				System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] enter quietlyClose 8");
				closeable.close();
				System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] exit quietlyClose 8");
			}
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] enter quietlyClose 9");
			logger.log(Level.FINE, "Socket cannot be closed.", e);
			System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] exit quietlyClose 9");
		}
		System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] exit quietlyClose 7");
	}

	/**
	 * <p>Will send a RST packet on close, which should make both remote
	 * write and read operations fail.</p>
	 *
	 * @param socket
	 */
	public static void quietlySetLinger(Socket socket) {
		try {
			socket.setSoLinger(true, 0);
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] enter quietlySetLinger 2");
			logger.log(Level.FINE, "Cannot set linger on socket.", e);
			System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] exit quietlySetLinger 2");
		}
	}

	/**
	 * <p>Performs authentication on the reader / writer representing a
	 * connection to a server.</p>
	 *
	 * <p>To be reusable, this function performs the read and write through raw sockets,
	 * and inspects the output immediately. It is essential that we do not try to evaluate
	 * the output or we could end up executing a non-authenticated method or raising an
	 * unexpected exception.</p>
	 *
	 * @param reader Reader connected to the remote endpoint.
	 * @param writer Writer connected to the remote endpoint.
	 * @param authToken The auth token.
	 * @throws IOException On I/O error, or if authentication fails.
	 */
	static void authToServer(BufferedReader reader, BufferedWriter writer, String authToken) throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] enter authToServer 1");
		writer.write(Protocol.getAuthCommand(authToken));
		writer.flush();

		String returnCommand = reader.readLine();
		if (returnCommand == null || !returnCommand.equals(Protocol.getOutputVoidCommand().trim())) {
			logger.log(Level.SEVERE, "Could not authenticate connection. Received this response: " + returnCommand);
			throw new IOException("Authentication with callback server unsuccessful.");
		}
		System.err.println("[py4j-java/src/main/java/py4j/NetworkUtil.java] exit authToServer 1");
	}

}
// Total cost: 0.056192
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 155)]
// Total instrumented cost: 0.056192, input tokens: 3807, output tokens: 2034, cache read tokens: 0, cache write tokens: 3803

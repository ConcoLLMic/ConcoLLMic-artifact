/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j.reflection;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class ReflectionShim {

	private static Method trySetAccessible;

	static {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionShim.java] enter ReflectionShim static 1");
		try {
			trySetAccessible = AccessibleObject.class.getDeclaredMethod("trySetAccessible");
		} catch (NoSuchMethodException e) {
			trySetAccessible = null;
		}
		System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionShim.java] exit ReflectionShim static 1");
	}

	/**
	 * If there is `trySetAccessible` method defined in `AccessibleObject`, it should be used;
	 * otherwise, fallback to `setAccessible`.
	 */
	public static boolean trySetAccessible(AccessibleObject accessibleObject) {
		if (trySetAccessible != null) {
			try {
				return (Boolean) trySetAccessible.invoke(accessibleObject);
			} catch (IllegalAccessException e) {
				// won't happen.
				throw new AssertionError(e);
			} catch (InvocationTargetException e) {
				// won't happen.
				throw new AssertionError(e);
			}
		} else {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionShim.java] enter trySetAccessible 6");
			accessibleObject.setAccessible(true);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/ReflectionShim.java] exit trySetAccessible 6");
			return true;
		}
	}
}
// Total cost: 0.020605
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 68)]
// Total instrumented cost: 0.020605, input tokens: 3078, output tokens: 970, cache read tokens: 2280, cache write tokens: 794

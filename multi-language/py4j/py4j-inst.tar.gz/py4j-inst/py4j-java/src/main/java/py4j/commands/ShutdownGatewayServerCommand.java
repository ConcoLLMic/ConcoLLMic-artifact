/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j.commands;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;

import py4j.Gateway;
import py4j.GatewayServer;
import py4j.Py4JException;
import py4j.Py4JJavaServer;
import py4j.Py4JServerConnection;

/**
 * <p>
 * The ShutdownGatewayServerCommand is responsible for shutting down the
 * GatewayServer. This command is useful to shut down the server remotely, i.e.,
 * from the Python side.
 * </p>
 *
 * @author Barthelemy Dagenais
 *
 */
public class ShutdownGatewayServerCommand extends AbstractCommand {

	private Py4JJavaServer gatewayServer;

	public static final String SHUTDOWN_GATEWAY_SERVER_COMMAND_NAME = "s";

	public ShutdownGatewayServerCommand() {
		super();
		System.err.println("[py4j-java/src/main/java/py4j/commands/ShutdownGatewayServerCommand.java] enter ShutdownGatewayServerCommand 1");
		this.commandName = SHUTDOWN_GATEWAY_SERVER_COMMAND_NAME;
		System.err.println("[py4j-java/src/main/java/py4j/commands/ShutdownGatewayServerCommand.java] exit ShutdownGatewayServerCommand 1");
	}

	@Override
	public void execute(String commandName, BufferedReader reader, BufferedWriter writer)
			throws Py4JException, IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/ShutdownGatewayServerCommand.java] enter execute 1");
		this.gatewayServer.shutdown();
		System.err.println("[py4j-java/src/main/java/py4j/commands/ShutdownGatewayServerCommand.java] exit execute 1");
	}

	@Override
	public void init(Gateway gateway, Py4JServerConnection connection) {
		System.err.println("[py4j-java/src/main/java/py4j/commands/ShutdownGatewayServerCommand.java] enter init 1");
		super.init(gateway, connection);
		this.gatewayServer = (Py4JJavaServer) gateway.getObject(GatewayServer.GATEWAY_SERVER_ID);
		System.err.println("[py4j-java/src/main/java/py4j/commands/ShutdownGatewayServerCommand.java] exit init 1");
	}

}
// Total cost: 0.020471
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 75)]
// Total instrumented cost: 0.020471, input tokens: 3167, output tokens: 921, cache read tokens: 2280, cache write tokens: 883

/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j;

/**
 * <p>
 * A client can implement this listener to be notified of Gateway events.
 * </p>
 * 
 * @author Barthelemy Dagenais
 * 
 */
public interface GatewayServerListener {

	void connectionError(Exception e);

	void connectionStarted(Py4JServerConnection gatewayConnection);

	void connectionStopped(Py4JServerConnection gatewayConnection);

	/**
	 * <p>
	 * This method may be called concurrently with serverPostShutdown().
	 * </p>
	 * 
	 * <p>
	 * Typically a one thread calls shutdown() and then, the thread running the
	 * GatewayServer breaks from the connection accept loop.
	 * </p>
	 */
	void serverError(Exception e);

	/**
	 * <p>
	 * This method may be called concurrently with serverStopped() and
	 * serverError().
	 * </p>
	 * 
	 * <p>
	 * Typically a one thread calls shutdown() and then, the thread running the
	 * GatewayServer breaks from the connection accept loop.
	 * </p>
	 */
	void serverPostShutdown();

	void serverPreShutdown();

	void serverStarted();

	/**
	 * <p>
	 * This method may be called concurrently with serverPostShutdown().
	 * </p>
	 * 
	 * <p>
	 * Typically a one thread calls shutdown() and then, the thread running the
	 * GatewayServer breaks from the connection accept loop.
	 * </p>
	 */
	void serverStopped();

}
// Total cost: 0.007305
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 89)]
// Total instrumented cost: 0.007305, input tokens: 3212, output tokens: 23, cache read tokens: 2280, cache write tokens: 928

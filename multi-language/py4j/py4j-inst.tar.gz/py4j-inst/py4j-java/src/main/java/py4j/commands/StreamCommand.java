/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j.commands;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.util.List;

import py4j.Protocol;
import py4j.Py4JException;
import py4j.ReturnObject;

/**
 * <p>
 * A {@link StreamCommand} is like a {@link CallCommand}, but returns
 * the value directly.
 * </p>
 *
 * @author Nick White
 *
 */
public class StreamCommand extends AbstractCommand {
	public final static String STREAM_COMMAND_NAME = "S";

	/**
	 * Usually a page.
	 */
	private final ByteBuffer streamBuffer = ByteBuffer.allocateDirect(4096);

	public StreamCommand() {
		System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] enter StreamCommand 1");
		this.commandName = STREAM_COMMAND_NAME;
		System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] exit StreamCommand 1");
	}

	private void feedException(BufferedWriter writer, ReturnObject e) throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] enter feedException 1");
		writer.write(Protocol.RETURN_MESSAGE);
		writer.write(e.getCommandPart());
		writer.write(Protocol.END_OUTPUT);
		writer.flush();
		System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] exit feedException 1");
	}

	@Override
	public void execute(String commandName, BufferedReader reader, BufferedWriter writer)
			throws Py4JException, IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] enter execute 1");
		String targetObjectId = reader.readLine();
		String methodName = reader.readLine();
		List<Object> arguments = getArguments(reader);

		ReturnObject returnObject = invokeMethod(methodName, targetObjectId, arguments);
		System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] exit execute 1");
		
		if (returnObject.isError()) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] enter execute 2");
			feedException(writer, returnObject);
			System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] exit execute 2");
			return;
		}

		System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] enter execute 3");
		if (!returnObject.isReference()) {
			// No point putting a Py4J protocol message down the socket if the caller
			// is expecting a binary blob.
			feedException(writer, ReturnObject
					.getErrorReturnObject(new ClassCastException("expected the method to return an Object")));
			return;
		}
		System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] exit execute 3");
		
		System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] enter execute 4");
		Object obj = gateway.getObject(returnObject.getName());
		System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] exit execute 4");
		
		if (!(obj instanceof ReadableByteChannel)) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] enter execute 5");
			feedException(writer, ReturnObject.getErrorReturnObject(
					new ClassCastException("expected the method to return a ReadableByteChannel")));
			System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] exit execute 5");
			return;
		}

		System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] enter execute 6");
		writer.write(Protocol.VOID_COMMAND);
		writer.flush();

		// just dump the contents into the Socket
		ReadableByteChannel in = (ReadableByteChannel) obj;
		System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] exit execute 6");
		
		try {
			System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] enter execute 7");
			WritableByteChannel out = Channels.newChannel(connection.getSocket().getOutputStream());
			streamBuffer.rewind();
			System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] exit execute 7");

			while (in.read(streamBuffer) != -1) {
				System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] enter execute 8");
				streamBuffer.flip();
				out.write(streamBuffer);
				streamBuffer.compact();
				System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] exit execute 8");
			}

			System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] enter execute 9");
			// drain the rest
			streamBuffer.flip();
			System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] exit execute 9");
			
			while (streamBuffer.hasRemaining()) {
				System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] enter execute 10");
				out.write(streamBuffer);
				System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] exit execute 10");
			}
		} finally {
			System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] enter execute 11");
			in.close();
			System.err.println("[py4j-java/src/main/java/py4j/commands/StreamCommand.java] exit execute 11");
		}
	}
}
// Total cost: 0.032777
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 124)]
// Total instrumented cost: 0.032777, input tokens: 3550, output tokens: 1569, cache read tokens: 2280, cache write tokens: 1266

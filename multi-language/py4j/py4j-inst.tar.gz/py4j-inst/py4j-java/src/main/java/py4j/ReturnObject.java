/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j;

import java.math.BigDecimal;

/**
 * <p>
 * A ReturnObject wraps a value returned by a method. If the value is a
 * primitive, a primitive wrapper object (e.g., Integer) or a String, the value
 * is kept in the primitiveObject field.
 * </p>
 * 
 * <p>
 * If the return value is an object, a key to the reference is kept in the name
 * field. This value can be retrieved by calling
 * {@link py4j.Gateway#getObject(String)} with the key.
 * </p>
 * 
 * <p>
 * Various methods are defined to determine the type of the return value. For
 * example, if the return value is void, the name and primitiveObject fields are
 * null, but {@link #isVoid()} returns true.
 * </p>
 * 
 * <p>
 * ReturnObject objects can only be constructed through static factory methods
 * such as {@link #getListReturnObject(String, int)}.
 * </p>
 * 
 * @author barthelemy
 * 
 */
public class ReturnObject {

	public static ReturnObject getArrayReturnObject(String name, int size) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter getArrayReturnObject 1");
		ReturnObject rObject = new ReturnObject();
		rObject.name = name;
		rObject.size = size;
		rObject.isArray = true;
		rObject.commandPart = Protocol.ARRAY_TYPE + name;
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit getArrayReturnObject 1");
		return rObject;
	}

	public static ReturnObject getDecimalReturnObject(Object object) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter getDecimalReturnObject 1");
		BigDecimal decimal = (BigDecimal) object;
		ReturnObject rObject = new ReturnObject();
		rObject.isDecimal = true;
		rObject.commandPart = Protocol.DECIMAL_TYPE + decimal.toPlainString();
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit getDecimalReturnObject 1");
		return rObject;
	}

	public static ReturnObject getErrorReferenceReturnObject(String name) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter getErrorReferenceReturnObject 1");
		ReturnObject rObject = new ReturnObject();
		rObject.name = name;
		rObject.isError = true;
		StringBuilder builder = new StringBuilder();
		builder.append(Protocol.ERROR);
		builder.append(Protocol.REFERENCE_TYPE);
		builder.append(name);
		rObject.commandPart = builder.toString();
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit getErrorReferenceReturnObject 1");
		return rObject;
	}

	public static ReturnObject getErrorReturnObject() {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter getErrorReturnObject 1");
		ReturnObject rObject = new ReturnObject();
		rObject.isError = true;
		rObject.commandPart = String.valueOf(Protocol.ERROR);
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit getErrorReturnObject 1");
		return rObject;
	}

	public static ReturnObject getErrorReturnObject(Throwable throwable) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter getErrorReturnObject 2");
		ReturnObject rObject = new ReturnObject();
		rObject.isError = true;
		StringBuilder builder = new StringBuilder();
		builder.append(Protocol.ERROR);
		builder.append(Protocol.STRING_TYPE);
		builder.append(StringUtil.escape(Protocol.getThrowableAsString(throwable)));
		rObject.commandPart = builder.toString();
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit getErrorReturnObject 2");
		return rObject;
	}

	public static ReturnObject getIteratorReturnObject(String name) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter getIteratorReturnObject 1");
		ReturnObject rObject = new ReturnObject();
		rObject.name = name;
		rObject.isIterator = true;
		rObject.commandPart = Protocol.ITERATOR_TYPE + name;
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit getIteratorReturnObject 1");
		return rObject;
	}

	public static ReturnObject getListReturnObject(String name, int size) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter getListReturnObject 1");
		ReturnObject rObject = new ReturnObject();
		rObject.name = name;
		rObject.size = size;
		rObject.isList = true;
		rObject.commandPart = Protocol.LIST_TYPE + name;
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit getListReturnObject 1");
		return rObject;
	}

	public static ReturnObject getMapReturnObject(String name, int size) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter getMapReturnObject 1");
		ReturnObject rObject = new ReturnObject();
		rObject.name = name;
		rObject.size = size;
		rObject.isMap = true;
		rObject.commandPart = Protocol.MAP_TYPE + name;
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit getMapReturnObject 1");
		return rObject;
	}

	public static ReturnObject getNullReturnObject() {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter getNullReturnObject 1");
		ReturnObject rObject = new ReturnObject();
		rObject.isNull = true;
		rObject.commandPart = String.valueOf(Protocol.NULL_TYPE);
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit getNullReturnObject 1");
		return rObject;
	}

	public static ReturnObject getPrimitiveReturnObject(Object primitive) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter getPrimitiveReturnObject 1");
		ReturnObject rObject = new ReturnObject();
		rObject.primitiveObject = primitive;
		char primitiveType = Protocol.getPrimitiveType(primitive);
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit getPrimitiveReturnObject 1");
		if (primitiveType == Protocol.STRING_TYPE) {
			System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter getPrimitiveReturnObject 2");
			rObject.commandPart = primitiveType + StringUtil.escape(primitive.toString());
			System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit getPrimitiveReturnObject 2");
		} else if (primitiveType == Protocol.BYTES_TYPE) {
			System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter getPrimitiveReturnObject 3");
			rObject.commandPart = primitiveType + Protocol.encodeBytes((byte[]) primitive);
			System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit getPrimitiveReturnObject 3");
		} else {
			System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter getPrimitiveReturnObject 4");
			rObject.commandPart = primitiveType + primitive.toString();
			System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit getPrimitiveReturnObject 4");
		}
		return rObject;
	}

	public static ReturnObject getReferenceReturnObject(String name) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter getReferenceReturnObject 1");
		ReturnObject rObject = new ReturnObject();
		rObject.name = name;
		rObject.isReference = true;
		rObject.commandPart = Protocol.REFERENCE_TYPE + name;
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit getReferenceReturnObject 1");
		return rObject;
	}

	public static ReturnObject getSetReturnObject(String name, int size) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter getSetReturnObject 1");
		ReturnObject rObject = new ReturnObject();
		rObject.name = name;
		rObject.size = size;
		rObject.isSet = true;
		rObject.commandPart = Protocol.SET_TYPE + name;
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit getSetReturnObject 1");
		return rObject;
	}

	public static ReturnObject getVoidReturnObject() {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter getVoidReturnObject 1");
		ReturnObject rObject = new ReturnObject();
		rObject.isVoid = true;
		rObject.commandPart = String.valueOf(Protocol.VOID);
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit getVoidReturnObject 1");
		return rObject;
	}

	private String name;
	private Object primitiveObject;

	private boolean isReference;

	private boolean isMap;

	private boolean isList;

	private boolean isNull;

	private boolean isError;

	private boolean isVoid;

	private boolean isArray;

	private boolean isIterator;

	private boolean isSet;

	private boolean isDecimal;

	private int size;

	private String commandPart;

	private ReturnObject() {
	}

	public String getCommandPart() {
		return commandPart;
	}

	public String getName() {
		return name;
	}

	public Object getPrimitiveObject() {
		return primitiveObject;
	}

	public int getSize() {
		return size;
	}

	public boolean isArray() {
		return isArray;
	}

	public boolean isDecimal() {
		return isDecimal;
	}

	public boolean isError() {
		return isError;
	}

	public boolean isIterator() {
		return isIterator;
	}

	public boolean isList() {
		return isList;
	}

	public boolean isMap() {
		return isMap;
	}

	public boolean isNull() {
		return isNull;
	}

	public boolean isReference() {
		return isReference;
	}

	public boolean isSet() {
		return isSet;
	}

	public boolean isVoid() {
		return isVoid;
	}

	public void setArray(boolean isArray) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter setArray 1");
		this.isArray = isArray;
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit setArray 1");
	}

	public void setCommandPart(String commandPart) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter setCommandPart 1");
		this.commandPart = commandPart;
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit setCommandPart 1");
	}

	public void setError(boolean isError) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter setError 1");
		this.isError = isError;
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit setError 1");
	}

	public void setIterator(boolean isIterator) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter setIterator 1");
		this.isIterator = isIterator;
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit setIterator 1");
	}

	public void setList(boolean isList) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter setList 1");
		this.isList = isList;
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit setList 1");
	}

	public void setMap(boolean isMap) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter setMap 1");
		this.isMap = isMap;
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit setMap 1");
	}

	public void setName(String name) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter setName 1");
		this.name = name;
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit setName 1");
	}

	public void setNull(boolean isNull) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter setNull 1");
		this.isNull = isNull;
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit setNull 1");
	}

	public void setPrimitiveObject(Object primitiveObject) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter setPrimitiveObject 1");
		this.primitiveObject = primitiveObject;
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit setPrimitiveObject 1");
	}

	public void setReference(boolean isReference) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter setReference 1");
		this.isReference = isReference;
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit setReference 1");
	}

	public void setSet(boolean isSet) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter setSet 1");
		this.isSet = isSet;
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit setSet 1");
	}

	public void setSize(int size) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter setSize 1");
		this.size = size;
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit setSize 1");
	}

	public void setVoid(boolean isVoid) {
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] enter setVoid 1");
		this.isVoid = isVoid;
		System.err.println("[py4j-java/src/main/java/py4j/ReturnObject.java] exit setVoid 1");
	}

}
// Total cost: 0.078880
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 319)]
// Total instrumented cost: 0.078880, input tokens: 4949, output tokens: 4013, cache read tokens: 2280, cache write tokens: 2665

/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j.commands;

import static py4j.NetworkUtil.safeReadLine;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.logging.Logger;

import py4j.Protocol;
import py4j.Py4JException;
import py4j.ReturnObject;
import py4j.model.HelpPageGenerator;
import py4j.model.Py4JClass;
import py4j.reflection.ReflectionUtil;

/**
 * <p>
 * A HelpPageCommand is responsible for generating a help page for a Java object
 * or Java class. The help page typically list the signature of the members
 * declared in the object/class.
 * </p>
 * 
 * @author Barthelemy Dagenais
 * 
 */
public class HelpPageCommand extends AbstractCommand {
	private final Logger logger = Logger.getLogger(HelpPageCommand.class.getName());

	public final static String HELP_COMMAND_NAME = "h";

	public final static String HELP_OBJECT_SUB_COMMAND_NAME = "o";

	public final static String HELP_CLASS_SUB_COMMAND_NAME = "c";

	public HelpPageCommand() {
		super();
		System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] enter HelpPageCommand 1");
		this.commandName = HELP_COMMAND_NAME;
		System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] exit HelpPageCommand 1");
	}

	@Override
	public void execute(String commandName, BufferedReader reader, BufferedWriter writer)
			throws Py4JException, IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] enter execute 1");
		String returnCommand = null;
		String subCommand = safeReadLine(reader, false);
		System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] exit execute 1");

		if (subCommand.equals(HELP_OBJECT_SUB_COMMAND_NAME)) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] enter execute 2");
			returnCommand = getHelpObject(reader);
			System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] exit execute 2");
		} else if (subCommand.equals(HELP_CLASS_SUB_COMMAND_NAME)) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] enter execute 3");
			returnCommand = getHelpClass(reader);
			System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] exit execute 3");
		} else {
			System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] enter execute 4");
			returnCommand = Protocol.getOutputErrorCommand("Unknown Help SubCommand Name: " + subCommand);
			System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] exit execute 4");
		}
		System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] enter execute 5");
		logger.finest("Returning command: " + returnCommand);
		writer.write(returnCommand);
		writer.flush();
		System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] exit execute 5");
	}

	private String getHelpClass(BufferedReader reader) throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] enter getHelpClass 1");
		String className = reader.readLine();
		String pattern = (String) Protocol.getObject(reader.readLine(), this.gateway);
		String shortName = safeReadLine(reader, false);
		// EoC
		reader.readLine();
		String returnCommand;
		System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] exit getHelpClass 1");

		try {
			System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] enter getHelpClass 2");
			Py4JClass clazz = Py4JClass.buildClass(ReflectionUtil.classForName(className), true);
			boolean isShortName = Protocol.getBoolean(shortName);
			String helpPage = HelpPageGenerator.getHelpPage(clazz, pattern, isShortName);
			ReturnObject rObject = gateway.getReturnObject(helpPage);
			returnCommand = Protocol.getOutputCommand(rObject);
			System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] exit getHelpClass 2");
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] enter getHelpClass 3");
			returnCommand = Protocol.getOutputErrorCommand(e);
			System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] exit getHelpClass 3");
		}

		return returnCommand;
	}

	private String getHelpObject(BufferedReader reader) throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] enter getHelpObject 1");
		String objectId = reader.readLine();
		String pattern = (String) Protocol.getObject(reader.readLine(), this.gateway);
		String shortName = safeReadLine(reader, false);
		// EoC
		reader.readLine();
		String returnCommand;
		System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] exit getHelpObject 1");

		try {
			System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] enter getHelpObject 2");
			Object obj = gateway.getObject(objectId);
			Py4JClass clazz = Py4JClass.buildClass(obj.getClass(), true);
			boolean isShortName = Protocol.getBoolean(shortName);
			String helpPage = HelpPageGenerator.getHelpPage(clazz, pattern, isShortName);
			ReturnObject rObject = gateway.getReturnObject(helpPage);
			returnCommand = Protocol.getOutputCommand(rObject);
			System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] exit getHelpObject 2");
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] enter getHelpObject 3");
			returnCommand = Protocol.getOutputErrorCommand(e);
			System.err.println("[py4j-java/src/main/java/py4j/commands/HelpPageCommand.java] exit getHelpObject 3");
		}

		return returnCommand;
	}

}
// Total cost: 0.038500
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 131)]
// Total instrumented cost: 0.038500, input tokens: 3769, output tokens: 1852, cache read tokens: 2280, cache write tokens: 1485

/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j.commands;

import static py4j.NetworkUtil.safeReadLine;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.logging.Logger;

import py4j.Gateway;
import py4j.JVMView;
import py4j.Protocol;
import py4j.Py4JException;
import py4j.Py4JServerConnection;
import py4j.ReturnObject;
import py4j.reflection.ReflectionEngine;
import py4j.reflection.TypeUtil;

/**
 * <p>
 * The ReflectionCommand is responsible for accessing packages, classes, and
 * static members. This is the command invoked when using the jvm property of a
 * JavaGateway on the Python side.
 * </p>
 *
 * @author Barthelemy Dagenais
 *
 */
public class ReflectionCommand extends AbstractCommand {

	private final Logger logger = Logger.getLogger(ReflectionCommand.class.getName());

	public final static char GET_UNKNOWN_SUB_COMMAND_NAME = 'u';

	public final static char GET_MEMBER_SUB_COMMAND_NAME = 'm';

	public final static char GET_JAVA_LANG_CLASS_SUB_COMMAND_NAME = 'c';

	public static final String REFLECTION_COMMAND_NAME = "r";

	protected ReflectionEngine rEngine;

	public ReflectionCommand() {
		super();
		System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter ReflectionCommand 1");
		this.commandName = REFLECTION_COMMAND_NAME;
		System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit ReflectionCommand 1");
	}

	@Override
	public void execute(String commandName, BufferedReader reader, BufferedWriter writer)
			throws Py4JException, IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter execute 1");
		char subCommand = safeReadLine(reader).charAt(0);
		String returnCommand = null;
		System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit execute 1");

		if (subCommand == GET_UNKNOWN_SUB_COMMAND_NAME) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter execute 2");
			returnCommand = getUnknownMember(reader);
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit execute 2");
		} else if (subCommand == GET_JAVA_LANG_CLASS_SUB_COMMAND_NAME) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter execute 3");
			returnCommand = getJavaLangClass(reader);
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit execute 3");
		} else {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter execute 4");
			returnCommand = getMember(reader);
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit execute 4");
		}

		System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter execute 5");
		logger.finest("Returning command: " + returnCommand);
		writer.write(returnCommand);
		writer.flush();
		System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit execute 5");
	}

	private String getJavaLangClass(BufferedReader reader) throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter getJavaLangClass 1");
		String fqn = reader.readLine();
		reader.readLine();
		String returnCommand = null;
		System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit getJavaLangClass 1");
		try {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter getJavaLangClass 2");
			Class<?> clazz = TypeUtil.forName(fqn);
			ReturnObject rObject = gateway.getReturnObject(clazz);
			returnCommand = Protocol.getOutputCommand(rObject);
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit getJavaLangClass 2");
		} catch (ClassNotFoundException ce) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter getJavaLangClass 3");
			returnCommand = Protocol.getOutputErrorCommand("The class " + fqn + " does not exist.");
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit getJavaLangClass 3");
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter getJavaLangClass 4");
			returnCommand = Protocol.getOutputErrorCommand();
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit getJavaLangClass 4");
		}

		return returnCommand;
	}

	/**
	 * 1- Try fields. 2- If no static field, try methods. 3- If method and
	 * static, return method. 4- If method and not static, then class is
	 * impossible so return exception. 5- If no method, try class.
	 *
	 * @param reader
	 * @return
	 * @throws IOException
	 */
	private String getMember(BufferedReader reader) throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter getMember 1");
		String fqn = reader.readLine();
		String member = reader.readLine();
		reader.readLine();
		String returnCommand = null;
		System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit getMember 1");
		try {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter getMember 2");
			Class<?> clazz = TypeUtil.forName(fqn);
			Field f = rEngine.getField(clazz, member);
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit getMember 2");
			if (f != null && Modifier.isStatic(f.getModifiers())) {
				System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter getMember 3");
				Object obj = rEngine.getFieldValue(null, f);
				ReturnObject rObject = gateway.getReturnObject(obj);
				returnCommand = Protocol.getOutputCommand(rObject);
				System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit getMember 3");
			}

			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter getMember 4");
			if (returnCommand == null) {
				System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter getMember 5");
				Method m = rEngine.getMethod(clazz, member);
				System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit getMember 5");
				if (m != null) {
					System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter getMember 6");
					if (Modifier.isStatic(m.getModifiers())) {
						System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter getMember 7");
						returnCommand = Protocol.getMemberOutputCommand(Protocol.METHOD_TYPE);
						System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit getMember 7");
					} else {
						System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter getMember 8");
						returnCommand = Protocol
								.getOutputErrorCommand("Trying to access a non-static member from a static context.");
						System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit getMember 8");
					}
					System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit getMember 6");
				}
				System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit getMember 4");
			}

			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter getMember 9");
			if (returnCommand == null) {
				System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter getMember 10");
				Class<?> c = rEngine.getClass(clazz, member);
				System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit getMember 10");
				if (c != null) {
					System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter getMember 11");
					returnCommand = Protocol.getMemberOutputCommand(Protocol.CLASS_TYPE);
					System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit getMember 11");
				} else {
					System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter getMember 12");
					returnCommand = Protocol.getOutputErrorCommand();
					System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit getMember 12");
				}
			}
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit getMember 9");
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter getMember 13");
			returnCommand = Protocol.getOutputErrorCommand();
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit getMember 13");
		}

		return returnCommand;
	}

	private String getUnknownMember(BufferedReader reader) throws IOException {
		System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter getUnknownMember 1");
		String fqn = reader.readLine();
		String jvmId = reader.readLine();
		JVMView view = (JVMView) Protocol.getObject(jvmId, this.gateway);
		reader.readLine();
		String returnCommand = null;
		System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit getUnknownMember 1");
		try {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter getUnknownMember 2");
			// TODO APPEND CLASS NAME, because it might not be the fqn, but a
			// new one because of imports!
			String fullyQualifiedName = TypeUtil.forName(fqn, view).getName();
			returnCommand = Protocol.getMemberOutputCommand(Protocol.CLASS_TYPE, fullyQualifiedName);
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit getUnknownMember 2");
		} catch (ClassNotFoundException e) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter getUnknownMember 3");
			returnCommand = Protocol.getMemberOutputCommand(Protocol.PACKAGE_TYPE);
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit getUnknownMember 3");
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter getUnknownMember 4");
			returnCommand = Protocol.getOutputErrorCommand(e);
			System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit getUnknownMember 4");
		}
		return returnCommand;
	}

	@Override
	public void init(Gateway gateway, Py4JServerConnection connection) {
		System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] enter init 1");
		super.init(gateway, connection);
		rEngine = gateway.getReflectionEngine();
		System.err.println("[py4j-java/src/main/java/py4j/commands/ReflectionCommand.java] exit init 1");
	}

}
// Total cost: 0.058314
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 191)]
// Total instrumented cost: 0.058314, input tokens: 4320, output tokens: 2925, cache read tokens: 2280, cache write tokens: 2036

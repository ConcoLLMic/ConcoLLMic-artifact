/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j.model;

import java.lang.reflect.Field;
import java.io.PrintStream;

import py4j.reflection.TypeUtil;

/**
 * <p>
 * Model of a Java field used to create a help page.
 * </p>
 * 
 * @author Barthelemy Dagenais
 * 
 */
public class Py4JField extends Py4JMember {

	public final static Py4JField buildField(Field field) {
		return new Py4JField(field.getName(), null, field.getType().getCanonicalName(),
				field.getDeclaringClass().getCanonicalName());
	}

	private final String type;

	private final String container;

	public Py4JField(String name, String javadoc, String type, String container) {
		super(name, javadoc);
		System.err.println("[py4j-java/src/main/java/py4j/model/Py4JField.java] enter Py4JField 1");
		this.type = type;
		this.container = container;
		System.err.println("[py4j-java/src/main/java/py4j/model/Py4JField.java] exit Py4JField 1");
	}

	public String getContainer() {
		return container;
	}

	@Override
	public String getSignature(boolean shortName) {
		System.err.println("[py4j-java/src/main/java/py4j/model/Py4JField.java] enter getSignature 1");
		StringBuilder builder = new StringBuilder();

		builder.append(getName());
		builder.append(" : ");
		builder.append(TypeUtil.getName(type, shortName));

		System.err.println("[py4j-java/src/main/java/py4j/model/Py4JField.java] exit getSignature 1");

		return builder.toString();
	}

	public String getType() {
		return type;
	}

}
// Total cost: 0.019845
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 80)]
// Total instrumented cost: 0.019845, input tokens: 3092, output tokens: 913, cache read tokens: 2280, cache write tokens: 808

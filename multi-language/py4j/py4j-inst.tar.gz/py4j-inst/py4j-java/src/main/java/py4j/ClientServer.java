/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j;

import java.net.InetAddress;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import javax.net.ServerSocketFactory;
import javax.net.SocketFactory;

/**
 * <p>
 * This class creates the JavaServer and the PythonClient necessary to
 * communicate with a Python virtual machine with the new threading model.
 * </p>
 */
public class ClientServer {

	protected final int javaPort;

	protected final InetAddress javaAddress;

	protected final int pythonPort;

	protected final InetAddress pythonAddress;

	protected final int connectTimeout;

	protected final int readTimeout;

	protected final ServerSocketFactory sSocketFactory;

	protected final SocketFactory socketFactory;

	protected final Gateway gateway;

	protected final Py4JJavaServer javaServer;

	protected final Py4JPythonClientPerThread pythonClient;

	protected final boolean autoStartJavaServer;

	protected final boolean enableMemoryManagement;

	protected final String authToken;

	protected final Logger logger = Logger.getLogger(ClientServer.class.getName());

	/**
	 *
	 * @param entryPoint
	 */
	public ClientServer(Object entryPoint) {
		this(GatewayServer.DEFAULT_PORT, GatewayServer.defaultAddress(), GatewayServer.DEFAULT_PYTHON_PORT,
				GatewayServer.defaultAddress(), GatewayServer.DEFAULT_CONNECT_TIMEOUT,
				GatewayServer.DEFAULT_READ_TIMEOUT, ServerSocketFactory.getDefault(), SocketFactory.getDefault(),
				entryPoint);
	}

	/**
	 *
	 * @param javaPort
	 * @param javaAddress
	 * @param pythonPort
	 * @param pythonAddress
	 * @param connectTimeout
	 * @param readTimeout
	 * @param sSocketFactory
	 * @param socketFactory
	 * @param entryPoint
	 */
	public ClientServer(int javaPort, InetAddress javaAddress, int pythonPort, InetAddress pythonAddress,
			int connectTimeout, int readTimeout, ServerSocketFactory sSocketFactory, SocketFactory socketFactory,
			Object entryPoint) {
		this(javaPort, javaAddress, pythonPort, pythonAddress, connectTimeout, readTimeout, sSocketFactory,
				socketFactory, entryPoint, true, true);
	}

	/**
	 *
	 * @param javaPort
	 * @param javaAddress
	 * @param pythonPort
	 * @param pythonAddress
	 * @param connectTimeout
	 * @param readTimeout
	 * @param sSocketFactory
	 * @param socketFactory
	 * @param entryPoint
	 * @param autoStartJavaServer
	 * @param enableMemoryManagement
	 */
	public ClientServer(int javaPort, InetAddress javaAddress, int pythonPort, InetAddress pythonAddress,
			int connectTimeout, int readTimeout, ServerSocketFactory sSocketFactory, SocketFactory socketFactory,
			Object entryPoint, boolean autoStartJavaServer, boolean enableMemoryManagement) {
		this(javaPort, javaAddress, pythonPort, pythonAddress, connectTimeout, readTimeout, sSocketFactory,
				socketFactory, entryPoint, autoStartJavaServer, enableMemoryManagement, null);
	}

	private ClientServer(int javaPort, InetAddress javaAddress, int pythonPort, InetAddress pythonAddress,
			int connectTimeout, int readTimeout, ServerSocketFactory sSocketFactory, SocketFactory socketFactory,
			Object entryPoint, boolean autoStartJavaServer, boolean enableMemoryManagement, String authToken) {
		System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter ClientServer 4");
		this.javaPort = javaPort;
		this.javaAddress = javaAddress;
		this.pythonPort = pythonPort;
		this.pythonAddress = pythonAddress;
		this.connectTimeout = connectTimeout;
		this.readTimeout = readTimeout;
		this.sSocketFactory = sSocketFactory;
		this.socketFactory = socketFactory;
		this.enableMemoryManagement = enableMemoryManagement;
		this.authToken = authToken;
		this.pythonClient = createPythonClient();
		this.javaServer = createJavaServer(entryPoint, pythonClient);

		this.gateway = javaServer.getGateway();
		pythonClient.setGateway(gateway);
		pythonClient.setJavaServer(javaServer);
		this.autoStartJavaServer = autoStartJavaServer;

		if (autoStartJavaServer) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter ClientServer 5");
			this.javaServer.start();
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit ClientServer 5");
		} else {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter ClientServer 6");
			this.gateway.startup();
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit ClientServer 6");
		}
		System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit ClientServer 4");
	}

	protected Py4JPythonClientPerThread createPythonClient() {
		System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter createPythonClient 1");
		Py4JPythonClientPerThread result = new PythonClient(null, null, pythonPort, pythonAddress, CallbackClient.DEFAULT_MIN_CONNECTION_TIME,
				TimeUnit.SECONDS, this.socketFactory, null, enableMemoryManagement, readTimeout, authToken);
		System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit createPythonClient 1");
		return result;
	}

	protected Py4JJavaServer createJavaServer(Object entryPoint, Py4JPythonClientPerThread pythonClient) {
		System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter createJavaServer 1");
		Py4JJavaServer result = new JavaServer(entryPoint, javaPort, connectTimeout, readTimeout, null, pythonClient, authToken);
		System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit createJavaServer 1");
		return result;
	}

	public Py4JJavaServer getJavaServer() {
		return javaServer;
	}

	public Py4JPythonClient getPythonClient() {
		return pythonClient;
	}

	/**
	 * <p>
	 * Starts the JavaServer on its own thread.
	 * </p>
	 *
	 * <p>
	 * Does nothing if autoStartJavaServer was set to true when constructing the instance.
	 * </p>
	 */
	public void startServer() {
		System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter startServer 1");
		startServer(true);
		System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit startServer 1");
	}

	/**
	 * <p>
	 * Starts the JavaServer, which will handle requests from the Python side.
	 * </p>
	 *
	 * <p>
	 * Does nothing if autoStartJavaServer was set to true when constructing the instance.
	 * </p>
	 *
	 * @param fork If the JavaServer is started in this thread or in its own
	 *                thread.
	 */
	public void startServer(boolean fork) {
		System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter startServer 2");
		if (!autoStartJavaServer) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter startServer 3");
			javaServer.start(fork);
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit startServer 3");
		}
		System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit startServer 2");
	}

	/**
	 * Shuts down the Java Server so that it stops accepting requests and it
	 * closes existing connections.
	 */
	public void shutdown() {
		System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter shutdown 1");
		this.javaServer.shutdown(true);
		System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit shutdown 1");
	}

	/**
	 * <p>
	 * Gets a reference to the entry point on the Python side. This is often
	 * necessary if Java is driving the communication because Java cannot call
	 * static methods, initialize Python objects or load Python modules yet.
	 * </p>
	 *
	 * @param interfacesToImplement
	 * @return
	 */
	public Object getPythonServerEntryPoint(Class[] interfacesToImplement) {
		System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter getPythonServerEntryPoint 1");
		Object result = pythonClient.getPythonServerEntryPoint(gateway, interfacesToImplement);
		System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit getPythonServerEntryPoint 1");
		return result;
	}

	/**
	 * Helper class to make it easier and self-documenting how a
	 * {@link ClientServer} is constructed.
	 */
	public static class ClientServerBuilder {
		private int javaPort;
		private InetAddress javaAddress;
		private int pythonPort;
		private InetAddress pythonAddress;
		private int connectTimeout;
		private int readTimeout;
		private ServerSocketFactory serverSocketFactory;
		private SocketFactory socketFactory;
		private Object entryPoint;
		private boolean autoStartJavaServer;
		private boolean enableMemoryManagement;
		private String authToken;

		public ClientServerBuilder() {
			this(null);
		}

		public ClientServerBuilder(Object entryPoint) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter ClientServerBuilder 2");
			javaPort = GatewayServer.DEFAULT_PORT;
			javaAddress = GatewayServer.defaultAddress();
			pythonPort = GatewayServer.DEFAULT_PYTHON_PORT;
			pythonAddress = GatewayServer.defaultAddress();
			connectTimeout = GatewayServer.DEFAULT_CONNECT_TIMEOUT;
			readTimeout = GatewayServer.DEFAULT_READ_TIMEOUT;
			serverSocketFactory = ServerSocketFactory.getDefault();
			socketFactory = SocketFactory.getDefault();
			this.entryPoint = entryPoint;
			autoStartJavaServer = true;
			enableMemoryManagement = true;
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit ClientServerBuilder 2");
		}

		public ClientServer build() {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter build 1");
			ClientServer result = new ClientServer(javaPort, javaAddress, pythonPort, pythonAddress, connectTimeout, readTimeout,
					serverSocketFactory, socketFactory, entryPoint, autoStartJavaServer, enableMemoryManagement,
					authToken);
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit build 1");
			return result;
		}

		public ClientServerBuilder javaPort(int javaPort) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter javaPort 1");
			this.javaPort = javaPort;
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit javaPort 1");
			return this;
		}

		public ClientServerBuilder javaAddress(InetAddress javaAddress) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter javaAddress 1");
			this.javaAddress = javaAddress;
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit javaAddress 1");
			return this;
		}

		public ClientServerBuilder pythonPort(int pythonPort) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter pythonPort 1");
			this.pythonPort = pythonPort;
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit pythonPort 1");
			return this;
		}

		public ClientServerBuilder pythonAddress(InetAddress pythonAddress) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter pythonAddress 1");
			this.pythonAddress = pythonAddress;
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit pythonAddress 1");
			return this;
		}

		public ClientServerBuilder connectTimeout(int connectTimeout) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter connectTimeout 1");
			this.connectTimeout = connectTimeout;
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit connectTimeout 1");
			return this;
		}

		public ClientServerBuilder readTimeout(int readTimeout) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter readTimeout 1");
			this.readTimeout = readTimeout;
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit readTimeout 1");
			return this;
		}

		public ClientServerBuilder serverSocketFactory(ServerSocketFactory serverSocketFactory) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter serverSocketFactory 1");
			this.serverSocketFactory = serverSocketFactory;
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit serverSocketFactory 1");
			return this;
		}

		public ClientServerBuilder socketFactory(SocketFactory socketFactory) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter socketFactory 1");
			this.socketFactory = socketFactory;
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit socketFactory 1");
			return this;
		}

		public ClientServerBuilder entryPoint(Object entryPoint) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter entryPoint 1");
			this.entryPoint = entryPoint;
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit entryPoint 1");
			return this;
		}

		public ClientServerBuilder autoStartJavaServer(boolean autoStartJavaServer) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter autoStartJavaServer 1");
			this.autoStartJavaServer = autoStartJavaServer;
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit autoStartJavaServer 1");
			return this;
		}

		public ClientServerBuilder enableMemoryManagement(boolean enableMemoryManagement) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter enableMemoryManagement 1");
			this.enableMemoryManagement = enableMemoryManagement;
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit enableMemoryManagement 1");
			return this;
		}

		public ClientServerBuilder authToken(String authToken) {
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] enter authToken 1");
			this.authToken = StringUtil.escape(authToken);
			System.err.println("[py4j-java/src/main/java/py4j/ClientServer.java] exit authToken 1");
			return this;
		}
	}
}
// Total cost: 0.082485
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 328)]
// Total instrumented cost: 0.082485, input tokens: 5432, output tokens: 4036, cache read tokens: 2280, cache write tokens: 3148

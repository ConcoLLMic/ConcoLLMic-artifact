/******************************************************************************
 * Copyright (c) 2009-2022, Barthelemy Dagenais and individual contributors.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * - The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
package py4j.reflection;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import py4j.Py4JException;
import py4j.Py4JJavaException;

/**
 * <p>
 * A MethodInvoker translates a call made in a Python Program into a call to a
 * Java method.
 * </p>
 * <p>
 * A MethodInvoker is tailored to a particular set of actual parameters and
 * indicates how far the calling context is from the method signature.
 * </p>
 * <p>
 * For example, a call to method1(String) from Python can be translated to a
 * call to method1(char) in Java, with a cost of 1.
 * </p>
 * 
 * @author Barthelemy Dagenais
 * 
 */
public class MethodInvoker {

	public final static int INVALID_INVOKER_COST = -1;

	public final static int MAX_DISTANCE = 100000000;

	private static boolean allNoConverter(List<TypeConverter> converters) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter allNoConverter 1");
		boolean allNo = true;
		System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit allNoConverter 1");

		for (TypeConverter converter : converters) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter allNoConverter 2");
			if (converter != TypeConverter.NO_CONVERTER) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter allNoConverter 3");
				allNo = false;
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit allNoConverter 3");
				break;
			}
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit allNoConverter 2");
		}

		return allNo;
	}

	/**
	 * <p>Builds a list of converters used to convert the arguments into the parameters.</p>
	 * @param converters
	 * @param parameters
	 * @param arguments
	 * @return
	 */
	public static int buildConverters(List<TypeConverter> converters, Class<?>[] parameters, Class<?>[] arguments) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildConverters 1");
		int cost = 0;
		int tempCost = -1;
		int size = arguments.length;
		System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildConverters 1");
		for (int i = 0; i < size; i++) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildConverters 2");
			if (arguments[i] == null) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildConverters 3");
				if (parameters[i].isPrimitive()) {
					System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildConverters 4");
					tempCost = -1;
					System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildConverters 4");
				} else {
					System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildConverters 5");
					int distance = TypeUtil.computeDistance(Object.class, parameters[i]);
					tempCost = Math.abs(MAX_DISTANCE - distance);
					converters.add(TypeConverter.NO_CONVERTER);
					System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildConverters 5");
				}
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildConverters 3");
			} else if (parameters[i].isAssignableFrom(arguments[i])) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildConverters 6");
				tempCost = TypeUtil.computeDistance(parameters[i], arguments[i]);
				converters.add(TypeConverter.NO_CONVERTER);
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildConverters 6");
			} else if (TypeUtil.isNumeric(parameters[i]) && TypeUtil.isNumeric(arguments[i])) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildConverters 7");
				tempCost = TypeUtil.computeNumericConversion(parameters[i], arguments[i], converters);
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildConverters 7");
			} else if (TypeUtil.isCharacter(parameters[i])) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildConverters 8");
				tempCost = TypeUtil.computeCharacterConversion(parameters[i], arguments[i], converters);
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildConverters 8");
			} else if (TypeUtil.isBoolean(parameters[i]) && TypeUtil.isBoolean(arguments[i])) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildConverters 9");
				tempCost = 0;
				converters.add(TypeConverter.NO_CONVERTER);
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildConverters 9");
			}

			if (tempCost != -1) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildConverters 10");
				cost += tempCost;
				tempCost = -1;
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildConverters 10");
			} else {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildConverters 11");
				cost = -1;
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildConverters 11");
				break;
			}
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildConverters 2");
		}
		return cost;
	}

	public static MethodInvoker buildInvoker(Constructor<?> constructor, Class<?>[] arguments) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildInvoker 1");
		MethodInvoker invoker = null;
		int size = 0;
		int cost = 0;
		System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildInvoker 1");

		if (arguments != null) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildInvoker 2");
			size = arguments.length;
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildInvoker 2");
		}

		System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildInvoker 3");
		List<TypeConverter> converters = new ArrayList<TypeConverter>();
		System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildInvoker 3");
		if (arguments != null && size > 0) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildInvoker 4");
			cost = buildConverters(converters, constructor.getParameterTypes(), arguments);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildInvoker 4");
		}
		if (cost == -1) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildInvoker 5");
			invoker = INVALID_INVOKER;
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildInvoker 5");
		} else {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildInvoker 6");
			TypeConverter[] convertersArray = null;
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildInvoker 6");
			if (!allNoConverter(converters)) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildInvoker 7");
				convertersArray = converters.toArray(new TypeConverter[0]);
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildInvoker 7");
			}
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildInvoker 8");
			invoker = new MethodInvoker(constructor, convertersArray, cost);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildInvoker 8");
		}

		return invoker;
	}

	public static MethodInvoker buildInvoker(Method method, Class<?>[] arguments) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildInvoker 10");
		MethodInvoker invoker = null;
		int size = 0;
		int cost = 0;
		System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildInvoker 10");

		if (arguments != null) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildInvoker 11");
			size = arguments.length;
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildInvoker 11");
		}

		System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildInvoker 12");
		List<TypeConverter> converters = new ArrayList<TypeConverter>();
		System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildInvoker 12");
		if (arguments != null && size > 0) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildInvoker 13");
			cost = buildConverters(converters, method.getParameterTypes(), arguments);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildInvoker 13");
		}
		if (cost == -1) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildInvoker 14");
			invoker = INVALID_INVOKER;
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildInvoker 14");
		} else {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildInvoker 15");
			TypeConverter[] convertersArray = null;
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildInvoker 15");
			if (!allNoConverter(converters)) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildInvoker 16");
				convertersArray = converters.toArray(new TypeConverter[0]);
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildInvoker 16");
			}
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter buildInvoker 17");
			invoker = new MethodInvoker(method, convertersArray, cost);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit buildInvoker 17");
		}

		return invoker;
	}

	private int cost;

	private List<TypeConverter> converters;

	private Method method;

	private Constructor<?> constructor;

	private final Logger logger = Logger.getLogger(MethodInvoker.class.getName());

	public static final MethodInvoker INVALID_INVOKER = new MethodInvoker((Method) null, null, INVALID_INVOKER_COST);

	public MethodInvoker(Constructor<?> constructor, TypeConverter[] converters, int cost) {
		super();
		System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter MethodInvoker 1");
		this.constructor = constructor;
		System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit MethodInvoker 1");
		if (converters != null) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter MethodInvoker 2");
			this.converters = Collections.unmodifiableList(Arrays.asList(converters));
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit MethodInvoker 2");
		}
		System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter MethodInvoker 3");
		this.cost = cost;
		System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit MethodInvoker 3");
	}

	public MethodInvoker(Method method, TypeConverter[] converters, int cost) {
		super();
		System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter MethodInvoker 4");
		this.method = method;
		System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit MethodInvoker 4");
		if (converters != null) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter MethodInvoker 5");
			this.converters = Collections.unmodifiableList(Arrays.asList(converters));
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit MethodInvoker 5");
		}
		System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter MethodInvoker 6");
		this.cost = cost;
		System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit MethodInvoker 6");
	}

	public Constructor<?> getConstructor() {
		return constructor;
	}

	public List<TypeConverter> getConverters() {
		return converters;
	}

	public int getCost() {
		return cost;
	}

	public Method getMethod() {
		return method;
	}

	public Object invoke(Object obj, Object[] arguments) {
		System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter invoke 1");
		Object returnObject = null;
		System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit invoke 1");

		try {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter invoke 2");
			Object[] newArguments = arguments;
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit invoke 2");

			if (converters != null) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter invoke 3");
				int size = arguments.length;
				newArguments = new Object[size];
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit invoke 3");
				for (int i = 0; i < size; i++) {
					System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter invoke 4");
					newArguments[i] = converters.get(i).convert(arguments[i]);
					System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit invoke 4");
				}
			}
			if (method != null) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter invoke 5");
				AccessController.doPrivileged(new PrivilegedAction<Object>() {
					public Object run() {
						System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter run 1");
						ReflectionShim.trySetAccessible(method);
						System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit run 1");
						return null;
					}
				});
				returnObject = method.invoke(obj, newArguments);
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit invoke 5");
			} else if (constructor != null) {
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter invoke 6");
				ReflectionShim.trySetAccessible(constructor);
				returnObject = constructor.newInstance(newArguments);
				System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit invoke 6");
			}
		} catch (InvocationTargetException ie) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter invoke 7");
			logger.log(Level.WARNING, "Exception occurred in client code.", ie);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit invoke 7");
			throw new Py4JJavaException(ie.getCause());
		} catch (Exception e) {
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] enter invoke 8");
			logger.log(Level.WARNING, "Could not invoke method or received an exception while invoking.", e);
			System.err.println("[py4j-java/src/main/java/py4j/reflection/MethodInvoker.java] exit invoke 8");
			throw new Py4JException(e);
		}

		return returnObject;
	}

	public boolean isVoid() {

		if (constructor != null) {
			return false;
		} else if (method != null) {
			return method.getReturnType().equals(void.class);
		} else {
			throw new Py4JException("Null method or constructor");
		}
	}

}
// Total cost: 0.083125
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 270)]
// Total instrumented cost: 0.083125, input tokens: 4909, output tokens: 4314, cache read tokens: 2280, cache write tokens: 2625

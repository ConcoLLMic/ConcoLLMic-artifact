/*  This file is part of GNU bc.

    Copyright (C) 1991-1994, 1997, 2006, 2008, 2012-2017 Free Software Foundation, Inc.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License , or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; see the file COPYING.  If not, see
    <http://www.gnu.org/licenses>.

    You may contact the author by:
       e-mail:  philnelson@acm.org
      us-mail:  Philip A. Nelson
                Computer Science Department, 9062
                Western Washington University
                Bellingham, WA 98226-9062
       
*************************************************************************/

/* load.c:  This code "loads" code into the code segments. */

#include "bcdefs.h"
#include "proto.h"
#include <stdio.h>

/* Load variables. */

program_counter load_adr;
char load_str;
char load_const;

/* Initialize the load sequence. */
void
init_load (void)
{
  fprintf(stderr, "[bc/load.c] enter init_load 1\n");
  clear_func(0);
  load_adr.pc_func = 0;
  load_adr.pc_addr = 0;
  load_str = FALSE;
  load_const = FALSE;
  fprintf(stderr, "[bc/load.c] exit init_load 1\n");
}

/* addbyte adds one BYTE to the current code segment. */
void
addbyte (unsigned char thebyte)
{
  fprintf(stderr, "[bc/load.c] enter addbyte 1\n");
  unsigned long prog_addr;
  bc_function *f;
  char *new_body;

  /* If there was an error, don't continue. */
  if (had_error) return;
  fprintf(stderr, "[bc/load.c] exit addbyte 1\n");

  /* Calculate the segment and offset. */
  fprintf(stderr, "[bc/load.c] enter addbyte 2\n");
  prog_addr = load_adr.pc_addr++;
  f = &functions[load_adr.pc_func];
  fprintf(stderr, "[bc/load.c] exit addbyte 2\n");

  if (prog_addr >= f->f_body_size)
  {
    fprintf(stderr, "[bc/load.c] enter addbyte 3\n");
    f->f_body_size *= 2;
    new_body = bc_malloc (f->f_body_size);
    memcpy(new_body, f->f_body, f->f_body_size/2);
    free (f->f_body);
    f->f_body = new_body;
    fprintf(stderr, "[bc/load.c] exit addbyte 3\n");
  }

  /* Store the thebyte. */
  fprintf(stderr, "[bc/load.c] enter addbyte 4\n");
  f->f_body[prog_addr] = (char) (thebyte & 0xff);
  f->f_code_size++;
  fprintf(stderr, "[bc/load.c] exit addbyte 4\n");
}


/* Define a label LAB to be the current program counter. */

void
def_label (unsigned long lab)
{
  fprintf(stderr, "[bc/load.c] enter def_label 1\n");
  bc_label_group *temp;
  unsigned long group, offset, func;
    
  /* Get things ready. */
  group = lab >> BC_LABEL_LOG;
  offset = lab % BC_LABEL_GROUP;
  func = load_adr.pc_func;
  fprintf(stderr, "[bc/load.c] exit def_label 1\n");
  
  /* Make sure there is at least one label group. */
  if (functions[func].f_label == NULL)
  {
    fprintf(stderr, "[bc/load.c] enter def_label 2\n");
    functions[func].f_label = bc_malloc (sizeof(bc_label_group));
    functions[func].f_label->l_next = NULL;
    fprintf(stderr, "[bc/load.c] exit def_label 2\n");
  }

  /* Add the label group. */
  fprintf(stderr, "[bc/load.c] enter def_label 3\n");
  temp = functions[func].f_label;
  fprintf(stderr, "[bc/load.c] exit def_label 3\n");
  
  while (group > 0)
  {
    fprintf(stderr, "[bc/load.c] enter def_label 4\n");
    if (temp->l_next == NULL)
    {
      fprintf(stderr, "[bc/load.c] enter def_label 5\n");
      temp->l_next = bc_malloc (sizeof(bc_label_group));
      temp->l_next->l_next = NULL;
      fprintf(stderr, "[bc/load.c] exit def_label 5\n");
    }
    temp = temp->l_next;
    group--;
    fprintf(stderr, "[bc/load.c] exit def_label 4\n");
  }

  /* Define it! */
  fprintf(stderr, "[bc/load.c] enter def_label 7\n");
  temp->l_adrs [offset] = load_adr.pc_addr;
  fprintf(stderr, "[bc/load.c] exit def_label 7\n");
}

/* Several instructions have integers in the code.  They
   are all known to be legal longs.  So, no error code
   is added.  STR is the pointer to the load string and
   must be moved to the last non-digit character. */

long
long_val (const char **str)
{
  fprintf(stderr, "[bc/load.c] enter long_val 1\n");
  int  val = 0;
  char neg = FALSE;
  fprintf(stderr, "[bc/load.c] exit long_val 1\n");

  if (**str == '-')
  {
    fprintf(stderr, "[bc/load.c] enter long_val 2\n");
    neg = TRUE;
    (*str)++;
    fprintf(stderr, "[bc/load.c] exit long_val 2\n");
  }
  
  while (isdigit((int)(**str))) 
  {
    fprintf(stderr, "[bc/load.c] enter long_val 3\n");
    val = val*10 + *(*str)++ - '0';
    fprintf(stderr, "[bc/load.c] exit long_val 3\n");
  }

  if (neg)
  {
    fprintf(stderr, "[bc/load.c] enter long_val 4\n");
    return -val;
    fprintf(stderr, "[bc/load.c] exit long_val 4\n");
  }
  else
  {
    fprintf(stderr, "[bc/load.c] enter long_val 5\n");
    return val;
    fprintf(stderr, "[bc/load.c] exit long_val 5\n");
  }
}


/* load_code loads the CODE into the machine. */

void
load_code (const char *code)
{
  fprintf(stderr, "[bc/load.c] enter load_code 1\n");
  const char *str;
  unsigned long  ap_name;	/* auto or parameter name. */
  unsigned long  label_no;
  unsigned long  vaf_name;	/* variable, array or function number. */
  unsigned long  func;
  static program_counter save_adr;

  /* Initialize. */
  str = code;
  fprintf(stderr, "[bc/load.c] exit load_code 1\n");
   
  /* Scan the code. */
  while (*str != 0)
  {
    fprintf(stderr, "[bc/load.c] enter load_code 2\n");
    /* If there was an error, don't continue. */
    if (had_error) return;
    fprintf(stderr, "[bc/load.c] exit load_code 2\n");

    if (load_str)
    {
      fprintf(stderr, "[bc/load.c] enter load_code 3\n");
      if (*str == '"') load_str = FALSE;
      addbyte (*str++);
      fprintf(stderr, "[bc/load.c] exit load_code 3\n");
    }
    else if (load_const)
    {
      fprintf(stderr, "[bc/load.c] enter load_code 4\n");
      if (*str == '\n') 
      {
        fprintf(stderr, "[bc/load.c] enter load_code 5\n");
        str++;
        fprintf(stderr, "[bc/load.c] exit load_code 5\n");
      }
      else
      {
        fprintf(stderr, "[bc/load.c] enter load_code 6\n");
        if (*str == ':')
        {
          fprintf(stderr, "[bc/load.c] enter load_code 7\n");
          load_const = FALSE;
          addbyte (*str++);
          fprintf(stderr, "[bc/load.c] exit load_code 7\n");
        }
        else if (*str == '.')
        {
          fprintf(stderr, "[bc/load.c] enter load_code 8\n");
          addbyte (*str++);
          fprintf(stderr, "[bc/load.c] exit load_code 8\n");
        }
        else
        {
          fprintf(stderr, "[bc/load.c] enter load_code 9\n");
          if (*str > 'F' && (warn_not_std || std_only))
          {
            fprintf(stderr, "[bc/load.c] enter load_code 10\n");
            if (std_only)
              yyerror ("Error in numeric constant");
            else
              ct_warn ("Non-standard base in numeric constant");
            fprintf(stderr, "[bc/load.c] exit load_code 10\n");
          } 
          if (*str >= 'A')
          {
            fprintf(stderr, "[bc/load.c] enter load_code 11\n");
            addbyte (*str++ + 10 - 'A');
            fprintf(stderr, "[bc/load.c] exit load_code 11\n");
          }
          else
          {
            fprintf(stderr, "[bc/load.c] enter load_code 12\n");
            addbyte (*str++ - '0');
            fprintf(stderr, "[bc/load.c] exit load_code 12\n");
          }
          fprintf(stderr, "[bc/load.c] exit load_code 9\n");
        }
        fprintf(stderr, "[bc/load.c] exit load_code 6\n");
      }
      fprintf(stderr, "[bc/load.c] exit load_code 4\n");
    }
    else
    {
      fprintf(stderr, "[bc/load.c] enter load_code 13\n");
      switch (*str)
      {
        case '"':	/* Starts a string. */
          fprintf(stderr, "[bc/load.c] enter load_code 14\n");
          load_str = TRUE;
          fprintf(stderr, "[bc/load.c] exit load_code 14\n");
          break;

        case 'N': /* A label */
          fprintf(stderr, "[bc/load.c] enter load_code 15\n");
          str++;
          label_no = long_val (&str);
          def_label (label_no);
          fprintf(stderr, "[bc/load.c] exit load_code 15\n");
          break;

        case 'B':  /* Branch to label. */
        case 'J':  /* Jump to label. */
        case 'Z':  /* Branch Zero to label. */
          fprintf(stderr, "[bc/load.c] enter load_code 16\n");
          addbyte(*str++);
          label_no = long_val (&str);
          if (label_no > 65535L)
          {  /* Better message? */
            fprintf(stderr, "[bc/load.c] enter load_code 17\n");
            fprintf (stderr,"Program too big.\n");
            bc_exit(1);
            fprintf(stderr, "[bc/load.c] exit load_code 17\n");
          }
          addbyte ( (char) (label_no & 0xFF));
          addbyte ( (char) (label_no >> 8));
          fprintf(stderr, "[bc/load.c] exit load_code 16\n");
          break;

        case 'F':  /* A function, get the name and initialize it. */
          fprintf(stderr, "[bc/load.c] enter load_code 18\n");
          str++;
          func = long_val (&str);
          clear_func (func);
#if DEBUG > 2
          printf ("Loading function number %d\n", func);
#endif
          fprintf(stderr, "[bc/load.c] exit load_code 18\n");
          /* get the parameters */
          while (*str++ != '.')
          {
            fprintf(stderr, "[bc/load.c] enter load_code 19\n");
            if (*str == '.')
            {
              fprintf(stderr, "[bc/load.c] enter load_code 20\n");
              str++;
              fprintf(stderr, "[bc/load.c] exit load_code 20\n");
              break;
            }
            if (*str == '*')
            {
              fprintf(stderr, "[bc/load.c] enter load_code 21\n");
              str++;
              ap_name = long_val (&str);
#if DEBUG > 2
              printf ("var parameter number %d\n", ap_name);
#endif
              functions[(int)func].f_params = 
                nextarg (functions[(int)func].f_params, ap_name, TRUE);
              fprintf(stderr, "[bc/load.c] exit load_code 21\n");
            }
            else
            {
              fprintf(stderr, "[bc/load.c] enter load_code 22\n");
              ap_name = long_val (&str);
#if DEBUG > 2
              printf ("parameter number %d\n", ap_name);
#endif
              functions[(int)func].f_params = 
                nextarg (functions[(int)func].f_params, ap_name, FALSE);
              fprintf(stderr, "[bc/load.c] exit load_code 22\n");
            }
            fprintf(stderr, "[bc/load.c] exit load_code 19\n");
          }

          /* get the auto vars */
          while (*str != '[')
          {
            fprintf(stderr, "[bc/load.c] enter load_code 23\n");
            if (*str == ',') str++;
            ap_name = long_val (&str);
#if DEBUG > 2
            printf ("auto number %d\n", ap_name);
#endif
            functions[(int)func].f_autos = 
              nextarg (functions[(int)func].f_autos, ap_name, FALSE);
            fprintf(stderr, "[bc/load.c] exit load_code 23\n");
          }
          fprintf(stderr, "[bc/load.c] enter load_code 24\n");
          save_adr = load_adr;
          load_adr.pc_func = func;
          load_adr.pc_addr = 0;
          fprintf(stderr, "[bc/load.c] exit load_code 24\n");
          break;
          
        case ']':  /* A function end */
          fprintf(stderr, "[bc/load.c] enter load_code 25\n");
          functions[load_adr.pc_func].f_defined = TRUE;
          load_adr = save_adr;
          fprintf(stderr, "[bc/load.c] exit load_code 25\n");
          break;

        case 'C':  /* Call a function. */
          fprintf(stderr, "[bc/load.c] enter load_code 26\n");
          addbyte (*str++);
          func = long_val (&str);
          if (func < 128)
          {
            fprintf(stderr, "[bc/load.c] enter load_code 27\n");
            addbyte ( (char) func);
            fprintf(stderr, "[bc/load.c] exit load_code 27\n");
          }
          else
          {
            fprintf(stderr, "[bc/load.c] enter load_code 28\n");
            addbyte (((func >> 8) & 0xff) | 0x80);
            addbyte (func & 0xff);
            fprintf(stderr, "[bc/load.c] exit load_code 28\n");
          }
          if (*str == ',') str++;
          while (*str != ':')
            addbyte (*str++);
          addbyte (':');
          fprintf(stderr, "[bc/load.c] exit load_code 26\n");
          break;
          
        case 'c':  /* Call a special function. */
          fprintf(stderr, "[bc/load.c] enter load_code 29\n");
          addbyte (*str++);
          addbyte (*str);
          fprintf(stderr, "[bc/load.c] exit load_code 29\n");
          break;

        case 'K':  /* A constant.... may have an "F" in it. */
          fprintf(stderr, "[bc/load.c] enter load_code 30\n");
          addbyte (*str);
          load_const = TRUE;
          fprintf(stderr, "[bc/load.c] exit load_code 30\n");
          break;

        case 'd':  /* Decrement. */
        case 'i':  /* Increment. */
        case 'l':  /* Load. */
        case 's':  /* Store. */
        case 'A':  /* Array Increment */
        case 'M':  /* Array Decrement */
        case 'L':  /* Array Load */
        case 'S':  /* Array Store */
          fprintf(stderr, "[bc/load.c] enter load_code 31\n");
          addbyte (*str++);
          vaf_name = long_val (&str);
          if (vaf_name < 128)
          {
            fprintf(stderr, "[bc/load.c] enter load_code 32\n");
            addbyte (vaf_name);
            fprintf(stderr, "[bc/load.c] exit load_code 32\n");
          }
          else
          {
            fprintf(stderr, "[bc/load.c] enter load_code 33\n");
            addbyte (((vaf_name >> 8) & 0xff) | 0x80);
            addbyte (vaf_name & 0xff);
            fprintf(stderr, "[bc/load.c] exit load_code 33\n");
          }
          fprintf(stderr, "[bc/load.c] exit load_code 31\n");
          break;

        case '@':  /* A command! */
          fprintf(stderr, "[bc/load.c] enter load_code 34\n");
          switch (*(++str))
          {
            case 'i':
              fprintf(stderr, "[bc/load.c] enter load_code 35\n");
              init_load ();
              fprintf(stderr, "[bc/load.c] exit load_code 35\n");
              break;
            case 'r':
              fprintf(stderr, "[bc/load.c] enter load_code 36\n");
              execute ();
              fprintf(stderr, "[bc/load.c] exit load_code 36\n");
              break;
          } 
          fprintf(stderr, "[bc/load.c] exit load_code 34\n");
          break;

        case '\n':  /* Ignore the newlines */


          break;
          
        default:   /* Anything else */
          fprintf(stderr, "[bc/load.c] enter load_code 38\n");
          addbyte (*str);
          fprintf(stderr, "[bc/load.c] exit load_code 38\n");
      }
      str++;
      fprintf(stderr, "[bc/load.c] exit load_code 13\n");
    }
  }
}

// Total cost: 0.101406
// Total split cost: 0.000000, input tokens: 0, output tokens: 0. Split chunks: [(0, 353)]
// Total instrumented cost: 0.101406, input tokens: 9942, output tokens: 4772

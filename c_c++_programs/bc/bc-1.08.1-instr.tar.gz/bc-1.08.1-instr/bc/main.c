/*  This file is part of GNU bc.

    Copyright (C) 1991-1994, 1997, 2006, 2008, 2012-2017 Free Software Foundation, Inc.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License , or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; see the file COPYING.  If not, see
    <http://www.gnu.org/licenses>.

    You may contact the author by:
       e-mail:  philnelson@acm.org
      us-mail:  Philip A. Nelson
                Computer Science Department, 9062
                Western Washington University
                Bellingham, WA 98226-9062
       
*************************************************************************/

/* main.c: The main program for bc.  */

#include "bcdefs.h"
#include <signal.h>
#include <errno.h>
#include "proto.h"
#include "getopt.h"


/* Variables for processing multiple files. */
static char first_file;

/* Points to the last node in the file name list for easy adding. */
static file_node *last = NULL;

#if defined(LIBEDIT)
/* The prompt for libedit. */
char el_pmtchars[] = "";
static char *el_pmtfunc(void);
static char *el_pmtfunc(void) 
{ 
  fprintf(stderr, "[bc/main.c] enter el_pmtfunc 1\n");
  return el_pmtchars; 
  fprintf(stderr, "[bc/main.c] exit el_pmtfunc 1\n");
}
#endif

/* long option support */
static struct option long_options[] =
{
  {"compile",     0, &compile_only, TRUE},
  {"help",        0, 0,             'h'},
  {"interactive", 0, 0,             'i'},
  {"mathlib",     0, &use_math,     TRUE},
  {"quiet",       0, &quiet,        TRUE},
  {"standard",    0, &std_only,     TRUE},
  {"version",     0, 0,             'v'},
  {"warn",        0, &warn_not_std, TRUE},

  {0, 0, 0, 0}
};


static void
usage (const char *progname)
{
  fprintf(stderr, "[bc/main.c] enter usage 1\n");
  printf ("usage: %s [options] [file ...]\n%s%s%s%s%s%s%s%s", progname,
          "  -h  --help         print this usage and exit\n",
	  "  -i  --interactive  force interactive mode\n",
	  "  -l  --mathlib      use the predefined math routines\n",
	  "  -q  --quiet        don't print initial banner\n",
	  "  -s  --standard     non-standard bc constructs are errors\n",
	  "  -w  --warn         warn about non-standard bc constructs\n",
	  "  -v  --version      print version information and exit\n",
	  "\nPlease report bugs to <bug-bc@gnu.org>\n");
  fprintf(stderr, "[bc/main.c] exit usage 1\n");
}


static void
parse_args (int argc, char **argv)
{
  fprintf(stderr, "[bc/main.c] enter parse_args 1\n");
  int optch;
  int long_index;
  file_node *temp;

  /* Force getopt to initialize.  Depends on GNU getopt. */
  optind = 0;
  fprintf(stderr, "[bc/main.c] exit parse_args 1\n");

  /* Parse the command line */
  while (1)
    {
      fprintf(stderr, "[bc/main.c] enter parse_args 2\n");
      optch = getopt_long (argc, argv, "chilqswv", long_options, &long_index);

      if (optch == EOF)  /* End of arguments. */
      {
        fprintf(stderr, "[bc/main.c] enter parse_args 3\n");
	break;
        fprintf(stderr, "[bc/main.c] exit parse_args 3\n");
      }
      fprintf(stderr, "[bc/main.c] exit parse_args 2\n");

      switch (optch)
	{
	case 0: /* Long option setting a var. */
	  fprintf(stderr, "[bc/main.c] enter parse_args 4\n");
	  break;
          fprintf(stderr, "[bc/main.c] exit parse_args 4\n");

	case 'c':  /* compile only */
	  fprintf(stderr, "[bc/main.c] enter parse_args 5\n");
	  compile_only = TRUE;
	  break;
          fprintf(stderr, "[bc/main.c] exit parse_args 5\n");

	case 'h':  /* help */
	  fprintf(stderr, "[bc/main.c] enter parse_args 6\n");
	  usage(argv[0]);
	  bc_exit (0);
          fprintf(stderr, "[bc/main.c] exit parse_args 6\n");
	  break;

	case 'i':  /* force interactive */
	  fprintf(stderr, "[bc/main.c] enter parse_args 7\n");
	  interactive = TRUE;
	  break;
          fprintf(stderr, "[bc/main.c] exit parse_args 7\n");

	case 'l':  /* math lib */
	  fprintf(stderr, "[bc/main.c] enter parse_args 8\n");
	  use_math = TRUE;
	  break;
          fprintf(stderr, "[bc/main.c] exit parse_args 8\n");

	case 'q':  /* quiet mode */
	  fprintf(stderr, "[bc/main.c] enter parse_args 9\n");
	  quiet = TRUE;
	  break;
          fprintf(stderr, "[bc/main.c] exit parse_args 9\n");

	case 's':  /* Non standard features give errors. */
	  fprintf(stderr, "[bc/main.c] enter parse_args 10\n");
	  std_only = TRUE;
	  break;
          fprintf(stderr, "[bc/main.c] exit parse_args 10\n");

	case 'v':  /* Print the version. */
	  fprintf(stderr, "[bc/main.c] enter parse_args 11\n");
	  show_bc_version ();
	  bc_exit (0);
          fprintf(stderr, "[bc/main.c] exit parse_args 11\n");
	  break;

	case 'w':  /* Non standard features give warnings. */
	  fprintf(stderr, "[bc/main.c] enter parse_args 12\n");
	  warn_not_std = TRUE;
	  break;
          fprintf(stderr, "[bc/main.c] exit parse_args 12\n");

	default:
	  fprintf(stderr, "[bc/main.c] enter parse_args 13\n");
	  usage(argv[0]);
	  bc_exit (1);
          fprintf(stderr, "[bc/main.c] exit parse_args 13\n");
	}
    }

#ifdef QUIET
  fprintf(stderr, "[bc/main.c] enter parse_args 14\n");
  quiet = TRUE;
  fprintf(stderr, "[bc/main.c] exit parse_args 14\n");
#endif

  /* Add file names to a list of files to process. */
  while (optind < argc)
    {
      fprintf(stderr, "[bc/main.c] enter parse_args 15\n");
      temp = bc_malloc(sizeof(file_node));
      temp->name = argv[optind];
      temp->next = NULL;
      if (last == NULL)
      {
        fprintf(stderr, "[bc/main.c] enter parse_args 16\n");
	file_names = temp;
        fprintf(stderr, "[bc/main.c] exit parse_args 16\n");
      }
      else
      {
        fprintf(stderr, "[bc/main.c] enter parse_args 17\n");
	last->next = temp;
        fprintf(stderr, "[bc/main.c] exit parse_args 17\n");
      }
      last = temp;
      optind++;
      fprintf(stderr, "[bc/main.c] exit parse_args 15\n");
    }
}

/* The main program for bc. */
int
main (int argc, char **argv)
{
  fprintf(stderr, "[bc/main.c] enter main 1\n");
  char *env_value;
  char *env_argv[30];
  int   env_argc;
  fprintf(stderr, "[bc/main.c] exit main 1\n");
  
  /* Interactive? */
  if (isatty(0) && isatty(1)) 
  {
    fprintf(stderr, "[bc/main.c] enter main 2\n");
    interactive = TRUE;
    fprintf(stderr, "[bc/main.c] exit main 2\n");
  }

#ifdef HAVE_SETVBUF
  /* attempt to simplify interaction with applications such as emacs */
  fprintf(stderr, "[bc/main.c] enter main 3\n");
  (void) setvbuf(stdout, NULL, _IOLBF, 0);
  fprintf(stderr, "[bc/main.c] exit main 3\n");
#endif

  /* Environment arguments. */
  fprintf(stderr, "[bc/main.c] enter main 4\n");
  env_value = getenv ("BC_ENV_ARGS");
  fprintf(stderr, "[bc/main.c] exit main 4\n");
  if (env_value != NULL)
    {
      fprintf(stderr, "[bc/main.c] enter main 5\n");
      env_argc = 1;
      env_argv[0] = strdup("BC_ENV_ARGS");
      fprintf(stderr, "[bc/main.c] exit main 5\n");
      while (*env_value != 0)
	{
          fprintf(stderr, "[bc/main.c] enter main 6\n");
	  if (*env_value != ' ')
	    {
              fprintf(stderr, "[bc/main.c] enter main 7\n");
	      env_argv[env_argc++] = env_value;
              fprintf(stderr, "[bc/main.c] exit main 7\n");
	      while (*env_value != ' ' && *env_value != 0)
              {
                fprintf(stderr, "[bc/main.c] enter main 8\n");
		env_value++;
                fprintf(stderr, "[bc/main.c] exit main 8\n");
              }
	      if (*env_value != 0)
		{
                  fprintf(stderr, "[bc/main.c] enter main 9\n");
		  *env_value = 0;
		  env_value++;
                  fprintf(stderr, "[bc/main.c] exit main 9\n");
		}
	    }
	  else
	    {
              fprintf(stderr, "[bc/main.c] enter main 10\n");
	      env_value++;
              fprintf(stderr, "[bc/main.c] exit main 10\n");
            }
          fprintf(stderr, "[bc/main.c] exit main 6\n");
	}
      fprintf(stderr, "[bc/main.c] enter main 11\n");
      parse_args (env_argc, env_argv);
      fprintf(stderr, "[bc/main.c] exit main 11\n");
    }

  /* Command line arguments. */
  fprintf(stderr, "[bc/main.c] enter main 12\n");
  parse_args (argc, argv);
  fprintf(stderr, "[bc/main.c] exit main 12\n");

  /* Other environment processing. */
  fprintf(stderr, "[bc/main.c] enter main 13\n");
  if (getenv ("POSIXLY_CORRECT") != NULL)
  {
    fprintf(stderr, "[bc/main.c] enter main 14\n");
    std_only = TRUE;
    fprintf(stderr, "[bc/main.c] exit main 14\n");
  }
  fprintf(stderr, "[bc/main.c] exit main 13\n");

  fprintf(stderr, "[bc/main.c] enter main 15\n");
  env_value = getenv ("BC_LINE_LENGTH");
  fprintf(stderr, "[bc/main.c] exit main 15\n");
  if (env_value != NULL)
    {
      fprintf(stderr, "[bc/main.c] enter main 16\n");
      line_size = atoi (env_value);
      fprintf(stderr, "[bc/main.c] exit main 16\n");
      if (line_size < 3 && line_size != 0)
      {
        fprintf(stderr, "[bc/main.c] enter main 17\n");
	line_size = 70;
        fprintf(stderr, "[bc/main.c] exit main 17\n");
      }
    }
  else
    {
      fprintf(stderr, "[bc/main.c] enter main 18\n");
      line_size = 70;
      fprintf(stderr, "[bc/main.c] exit main 18\n");
    }

  /* Initialize the machine.  */
  fprintf(stderr, "[bc/main.c] enter main 19\n");
  init_storage();
  init_load();
  fprintf(stderr, "[bc/main.c] exit main 19\n");

  /* Set up interrupts to print a message. */
  if (interactive)
  {
    fprintf(stderr, "[bc/main.c] enter main 20\n");
    signal (SIGINT, use_quit);
    fprintf(stderr, "[bc/main.c] exit main 20\n");
  }

  /* Initialize the front end. */
  fprintf(stderr, "[bc/main.c] enter main 21\n");
  init_tree();
  init_gen ();
  is_std_in = FALSE;
  first_file = TRUE;
  fprintf(stderr, "[bc/main.c] exit main 21\n");
  if (!open_new_file ())
  {
    fprintf(stderr, "[bc/main.c] enter main 22\n");
    bc_exit (1);
    fprintf(stderr, "[bc/main.c] exit main 22\n");
  }

#if defined(LIBEDIT)
  if (interactive) {
    /* Enable libedit support. */
    fprintf(stderr, "[bc/main.c] enter main 23\n");
    edit = el_init ("bc", stdin, stdout, stderr);
    hist = history_init();
    el_set (edit, EL_EDITOR, "emacs");
    el_set (edit, EL_HIST, history, hist);
    el_set (edit, EL_PROMPT, el_pmtfunc);
    el_source (edit, NULL);
    history (hist, &histev, H_SETSIZE, INT_MAX);
    fprintf(stderr, "[bc/main.c] exit main 23\n");
  }
#endif

#if defined(READLINE)
  if (interactive) {
    /* Readline support.  Set both application name and input file. */
    fprintf(stderr, "[bc/main.c] enter main 24\n");
    rl_readline_name = "bc";
    rl_instream = stdin;
    using_history ();
    fprintf(stderr, "[bc/main.c] exit main 24\n");
  }
#endif

  /* Do the parse. */
  fprintf(stderr, "[bc/main.c] enter main 25\n");
  yyparse ();
  fprintf(stderr, "[bc/main.c] exit main 25\n");

  /* End the compile only output with a newline. */
  if (compile_only)
  {
    fprintf(stderr, "[bc/main.c] enter main 26\n");
    printf ("\n");
    fprintf(stderr, "[bc/main.c] exit main 26\n");
  }

  fprintf(stderr, "[bc/main.c] enter main 27\n");
  bc_exit (0);
  return 0; // to keep the compiler from complaining
  fprintf(stderr, "[bc/main.c] exit main 27\n");
}


/* This is the function that opens all the files. 
   It returns TRUE if the file was opened, otherwise
   it returns FALSE. */

int
open_new_file (void)
{
  fprintf(stderr, "[bc/main.c] enter open_new_file 1\n");
  FILE *new_file;
  file_node *temp;

  /* Set the line number. */
  line_no = 1;

  /* Check to see if we are done. */
  if (is_std_in) 
  {
    fprintf(stderr, "[bc/main.c] enter open_new_file 2\n");
    return (FALSE);
    fprintf(stderr, "[bc/main.c] exit open_new_file 2\n");
  }
  fprintf(stderr, "[bc/main.c] exit open_new_file 1\n");

  /* Open the other files. */
  if (use_math && first_file)
    {
      fprintf(stderr, "[bc/main.c] enter open_new_file 3\n");
      /* Load the code from a precompiled version of the math libarary. */
      CONST char **mstr;

      /* These MUST be in the order of first mention of each function.
	 That is why "a" comes before "c" even though "a" is defined after
	 after "c".  "a" is used in "s"! */
      (void) lookup (strdup("e"), FUNCT);
      (void) lookup (strdup("l"), FUNCT);
      (void) lookup (strdup("s"), FUNCT);
      (void) lookup (strdup("a"), FUNCT);
      (void) lookup (strdup("c"), FUNCT);
      (void) lookup (strdup("j"), FUNCT);
      mstr = libmath;
      fprintf(stderr, "[bc/main.c] exit open_new_file 3\n");
      while (*mstr) {
        fprintf(stderr, "[bc/main.c] enter open_new_file 4\n");
        load_code (*mstr);
	mstr++;
        fprintf(stderr, "[bc/main.c] exit open_new_file 4\n");
      }
    }
  
  /* One of the argv values. */
  if (file_names != NULL)
    {
      fprintf(stderr, "[bc/main.c] enter open_new_file 5\n");
      new_file = fopen (file_names->name, "r");
      fprintf(stderr, "[bc/main.c] exit open_new_file 5\n");
      if (new_file != NULL)
	{
          fprintf(stderr, "[bc/main.c] enter open_new_file 6\n");
	  new_yy_file (new_file);
	  temp = file_names;
	  file_name  = temp->name;
	  file_names = temp->next;
	  free (temp);
	  return TRUE;
          fprintf(stderr, "[bc/main.c] exit open_new_file 6\n");
	}
      fprintf(stderr, "[bc/main.c] enter open_new_file 7\n");
      fprintf (stderr, "File %s is unavailable.\n", file_names->name);
      bc_exit (1);
      fprintf(stderr, "[bc/main.c] exit open_new_file 7\n");
    }
  
  /* If we fall through to here, we should return stdin. */
  fprintf(stderr, "[bc/main.c] enter open_new_file 8\n");
  new_yy_file (stdin);
  is_std_in = TRUE;
  return TRUE;
  fprintf(stderr, "[bc/main.c] exit open_new_file 8\n");
}


/* Set yyin to the new file. */

void
new_yy_file (FILE *file)
{
  fprintf(stderr, "[bc/main.c] enter new_yy_file 1\n");
  if (!first_file) 
  {
    fprintf(stderr, "[bc/main.c] enter new_yy_file 2\n");
    fclose (yyin);
    fprintf(stderr, "[bc/main.c] exit new_yy_file 2\n");
  }
  yyin = file;
  first_file = FALSE;
  fprintf(stderr, "[bc/main.c] exit new_yy_file 1\n");
}


/* Message to use quit.  */

void
use_quit (int sig)
{
  fprintf(stderr, "[bc/main.c] enter use_quit 1\n");
#ifdef DONTEXIT
  int save = errno;
  write (1, "\n(interrupt) use quit to exit.\n", 31);
  signal (SIGINT, use_quit);
  errno = save;
#else
  write (1, "\n(interrupt) Exiting bc.\n", 26);
  bc_exit(0);
#endif
  fprintf(stderr, "[bc/main.c] exit use_quit 1\n");
}

// Total cost: 0.088041
// Total split cost: 0.000000, input tokens: 0, output tokens: 0. Split chunks: [(0, 359)]
// Total instrumented cost: 0.088041, input tokens: 5227, output tokens: 4824

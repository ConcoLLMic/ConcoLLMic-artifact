/*  This file is part of GNU bc.

    Copyright (C) 1991-1994, 1997, 2006, 2008, 2012-2017 Free Software Foundation, Inc.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License , or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; see the file COPYING.  If not, see
    <http://www.gnu.org/licenses>.

    You may contact the author by:
       e-mail:  philnelson@acm.org
      us-mail:  Philip A. Nelson
                Computer Science Department, 9062
                Western Washington University
                Bellingham, WA 98226-9062
       
*************************************************************************/
/* execute.c - run a bc program. */

#include "bcdefs.h"
#include <signal.h>
#include <stdio.h>
#include "proto.h"


/* The SIGINT interrupt handling routine. */

int had_sigint;

void
stop_execution ( int sig )
{
  fprintf(stderr, "[bc/execute.c] enter stop_execution 1\n");
  had_sigint = TRUE;
  fprintf(stderr, "[bc/execute.c] exit stop_execution 1\n");
}


/* Get the current byte and advance the PC counter. */

unsigned char
byte ( program_counter *p )
{
  fprintf(stderr, "[bc/execute.c] enter byte 1\n");
  return (functions[p->pc_func].f_body[p->pc_addr++]);
  fprintf(stderr, "[bc/execute.c] exit byte 1\n");
}


/* The routine that actually runs the machine. */

void
execute (void)
{
  fprintf(stderr, "[bc/execute.c] enter execute 1\n");
  unsigned long label_num, l_gp, l_off;
  bc_label_group *gp;
  
  char inst, ch;
  long  new_func;
  long  var_name;

  long const_base;

  bc_num temp_num;
  arg_list *auto_list;

  /* Initialize this run... */
  pc.pc_func = 0;
  pc.pc_addr = 0;
  runtime_error = FALSE;
  bc_init_num (&temp_num);
  fprintf(stderr, "[bc/execute.c] exit execute 1\n");

  /* Set up the interrupt mechanism for an interactive session. */
  if (interactive)
  {
    fprintf(stderr, "[bc/execute.c] enter execute 2\n");
    signal (SIGINT, stop_execution);
    fprintf(stderr, "[bc/execute.c] exit execute 2\n");
  }
   
  fprintf(stderr, "[bc/execute.c] enter execute 3\n");
  had_sigint = FALSE;
  fprintf(stderr, "[bc/execute.c] exit execute 3\n");
  
  while (pc.pc_addr < functions[pc.pc_func].f_code_size
	 && !runtime_error && !had_sigint)
  {
    fprintf(stderr, "[bc/execute.c] enter execute 4\n");
    inst = byte(&pc);

#if DEBUG > 3
      { /* Print out address and the stack before each instruction.*/
	int depth; estack_rec *temp = ex_stack;
	
	printf ("func=%d addr=%d inst=%c\n",pc.pc_func, pc.pc_addr, inst);
	if (temp == NULL) printf ("empty stack.\n", inst);
	else
	  {
	    depth = 1;
	    while (temp != NULL)
	      {
		printf ("  %d = ", depth);
		bc_out_num (temp->s_num, 10, out_char, std_only);
		depth++;
		temp = temp->s_next;
	      }
	    out_char ('\n');
	  }
      }
#endif
    fprintf(stderr, "[bc/execute.c] exit execute 4\n");

    switch (inst)
    {
      case 'A': /* increment array variable (Add one). */
        fprintf(stderr, "[bc/execute.c] enter execute 5\n");
        var_name = byte(&pc);
        if ((var_name & 0x80) != 0)
          var_name = ((var_name & 0x7f) << 8) + byte(&pc);
        incr_array (var_name);
        fprintf(stderr, "[bc/execute.c] exit execute 5\n");
        break;

      case 'B': /* Branch to a label if TOS != 0. Remove value on TOS. */
      case 'Z': /* Branch to a label if TOS == 0. Remove value on TOS. */
        fprintf(stderr, "[bc/execute.c] enter execute 6\n");
        c_code = !bc_is_zero (ex_stack->s_num);
        pop ();
        fprintf(stderr, "[bc/execute.c] exit execute 6\n");
        /*FALLTHROUGH*/ /* common branch and jump code */
      case 'J': /* Jump to a label. */
        fprintf(stderr, "[bc/execute.c] enter execute 7\n");
        label_num = byte(&pc);  /* Low order bits first. */
        label_num += byte(&pc) << 8;
        fprintf(stderr, "[bc/execute.c] exit execute 7\n");
        if (inst == 'J' || (inst == 'B' && c_code)
            || (inst == 'Z' && !c_code)) {
          fprintf(stderr, "[bc/execute.c] enter execute 8\n");
          gp = functions[pc.pc_func].f_label;
          l_gp  = label_num >> BC_LABEL_LOG;
          l_off = label_num % BC_LABEL_GROUP;
          while (l_gp-- > 0) gp = gp->l_next;
          if (gp)
            pc.pc_addr = gp->l_adrs[l_off];
          else {
            rt_error ("Internal error.");
            break;
          }
          fprintf(stderr, "[bc/execute.c] exit execute 8\n");
        }
        break;

      case 'C': /* Call a function. */
        fprintf(stderr, "[bc/execute.c] enter execute 9\n");
        /* Get the function number. */
        new_func = byte(&pc);
        if ((new_func & 0x80) != 0) 
          new_func = ((new_func & 0x7f) << 8) + byte(&pc);
        fprintf(stderr, "[bc/execute.c] exit execute 9\n");

        /* Check to make sure it is defined. */
        if (!functions[new_func].f_defined)
        {
          fprintf(stderr, "[bc/execute.c] enter execute 10\n");
          rt_error ("Function %s not defined.", f_names[new_func]);
          fprintf(stderr, "[bc/execute.c] exit execute 10\n");
          break;
        }

        fprintf(stderr, "[bc/execute.c] enter execute 11\n");
        /* Check and push parameters. */
        process_params (&pc, new_func);

        /* Push auto variables. */
        for (auto_list = functions[new_func].f_autos;
             auto_list != NULL;
             auto_list = auto_list->next)
          auto_var (auto_list->av_name);

        /* Push pc and ibase. */
        fpush (pc.pc_func);
        fpush (pc.pc_addr);
        fpush (i_base);

        /* Reset pc to start of function. */
        pc.pc_func = new_func;
        pc.pc_addr = 0;
        fprintf(stderr, "[bc/execute.c] exit execute 11\n");
        break;

      case 'D': /* Duplicate top of stack */
        fprintf(stderr, "[bc/execute.c] enter execute 12\n");
        push_copy (ex_stack->s_num);
        fprintf(stderr, "[bc/execute.c] exit execute 12\n");
        break;

      case 'K': /* Push a constant */
        fprintf(stderr, "[bc/execute.c] enter execute 13\n");
        /* Get the input base and convert it to a bc number. */
        if (pc.pc_func == 0) 
          const_base = i_base;
        else
          const_base = fn_stack->s_val;
        fprintf(stderr, "[bc/execute.c] exit execute 13\n");
        if (const_base == 10)
        {
          fprintf(stderr, "[bc/execute.c] enter execute 14\n");
          push_b10_const (&pc);
          fprintf(stderr, "[bc/execute.c] exit execute 14\n");
        }
        else
        {
          fprintf(stderr, "[bc/execute.c] enter execute 15\n");
          push_constant (prog_char, const_base);
          fprintf(stderr, "[bc/execute.c] exit execute 15\n");
        }
        break;

      case 'L': /* load array variable */
        fprintf(stderr, "[bc/execute.c] enter execute 16\n");
        var_name = byte(&pc);
        if ((var_name & 0x80) != 0)
          var_name = ((var_name & 0x7f) << 8) + byte(&pc);
        load_array (var_name);
        fprintf(stderr, "[bc/execute.c] exit execute 16\n");
        break;

      case 'M': /* decrement array variable (Minus!) */
        fprintf(stderr, "[bc/execute.c] enter execute 17\n");
        var_name = byte(&pc);
        if ((var_name & 0x80) != 0)
          var_name = ((var_name & 0x7f) << 8) + byte(&pc);
        decr_array (var_name);
        fprintf(stderr, "[bc/execute.c] exit execute 17\n");
        break;

      case 'O': /* Write a string to the output with processing. */
        fprintf(stderr, "[bc/execute.c] enter execute 18\n");
        while ((ch = byte(&pc)) != '"')
          if (ch != '\\')
            out_schar (ch);
          else
          {
            ch = byte(&pc);
            if (ch == '"') break;
            switch (ch)
            {
              case 'a':  out_schar (007); break;
              case 'b':  out_schar ('\b'); break;
              case 'f':  out_schar ('\f'); break;
              case 'n':  out_schar ('\n'); break;
              case 'q':  out_schar ('"'); break;
              case 'r':  out_schar ('\r'); break;
              case 't':  out_schar ('\t'); break;
              case '\\': out_schar ('\\'); break;
              default:  break;
            }
          }
        fflush (stdout);
        fprintf(stderr, "[bc/execute.c] exit execute 18\n");
        break;

      case 'R': /* Return from function */
        fprintf(stderr, "[bc/execute.c] enter execute 19\n");
        if (pc.pc_func != 0)
        {
          fprintf(stderr, "[bc/execute.c] enter execute 20\n");
          /* "Pop" autos and parameters. */
          pop_vars(functions[pc.pc_func].f_autos);
          pop_vars(functions[pc.pc_func].f_params);
          /* reset the pc. */
          fpop ();
          pc.pc_addr = fpop ();
          pc.pc_func = fpop ();
          fprintf(stderr, "[bc/execute.c] exit execute 20\n");
        }
        else
        {
          fprintf(stderr, "[bc/execute.c] enter execute 21\n");
          rt_error ("Return from main program.");
          fprintf(stderr, "[bc/execute.c] exit execute 21\n");
        }
        fprintf(stderr, "[bc/execute.c] exit execute 19\n");
        break;

      case 'S': /* store array variable */
        fprintf(stderr, "[bc/execute.c] enter execute 22\n");
        var_name = byte(&pc);
        if ((var_name & 0x80) != 0)
          var_name = ((var_name & 0x7f ) << 8) + byte(&pc);
        store_array (var_name);
        fprintf(stderr, "[bc/execute.c] exit execute 22\n");
        break;

      case 'T': /* Test tos for zero */
        fprintf(stderr, "[bc/execute.c] enter execute 23\n");
        c_code = bc_is_zero (ex_stack->s_num);
        assign (c_code);
        fprintf(stderr, "[bc/execute.c] exit execute 23\n");
        break;

      case 'W': /* Write the value on the top of the stack. */
      case 'P': /* Write the value on the top of the stack.  No newline. */
        fprintf(stderr, "[bc/execute.c] enter execute 24\n");
        bc_out_num (ex_stack->s_num, o_base, out_char, std_only);
        if (inst == 'W') out_char ('\n');
        store_var (4);  /* Special variable "last". */
        fflush (stdout);
        pop ();
        fprintf(stderr, "[bc/execute.c] exit execute 24\n");
        break;

      case 'c': /* Call special function. */
        fprintf(stderr, "[bc/execute.c] enter execute 25\n");
        new_func = byte(&pc);
        fprintf(stderr, "[bc/execute.c] exit execute 25\n");

        switch (new_func)
        {
          case 'L':  /* Length function. */
            fprintf(stderr, "[bc/execute.c] enter execute 26\n");
            /* For the number 0.xxxx,  0 is not significant. */
            if (ex_stack->s_num->n_len == 1 &&
                ex_stack->s_num->n_scale != 0 &&
                ex_stack->s_num->n_value[0] == 0 )
              bc_int2num (&ex_stack->s_num, ex_stack->s_num->n_scale);
            else
              bc_int2num (&ex_stack->s_num, ex_stack->s_num->n_len
                       + ex_stack->s_num->n_scale);
            fprintf(stderr, "[bc/execute.c] exit execute 26\n");
            break;
            
          case 'S':  /* Scale function. */ 
            fprintf(stderr, "[bc/execute.c] enter execute 27\n");
            bc_int2num (&ex_stack->s_num, ex_stack->s_num->n_scale);
            fprintf(stderr, "[bc/execute.c] exit execute 27\n");
            break;

          case 'R':  /* Square Root function. */
            fprintf(stderr, "[bc/execute.c] enter execute 28\n");
            if (!bc_sqrt (&ex_stack->s_num, scale))
            {
              fprintf(stderr, "[bc/execute.c] enter execute 29\n");
              rt_error ("Square root of a negative number");
              fprintf(stderr, "[bc/execute.c] exit execute 29\n");
            }
            fprintf(stderr, "[bc/execute.c] exit execute 28\n");
            break;

          case 'I': /* Read function. */
            fprintf(stderr, "[bc/execute.c] enter execute 30\n");
            push_constant (input_char, i_base);
            fprintf(stderr, "[bc/execute.c] exit execute 30\n");
            break;

          case 'X': /* Random function. */
            fprintf(stderr, "[bc/execute.c] enter execute 31\n");
            push_copy (_zero_);
            bc_int2num (&ex_stack->s_num, random());
            fprintf(stderr, "[bc/execute.c] exit execute 31\n");
            break;
        }
        break;

      case 'd': /* Decrement number */
        fprintf(stderr, "[bc/execute.c] enter execute 32\n");
        var_name = byte(&pc);
        if ((var_name & 0x80) != 0)
          var_name = ((var_name & 0x7f) << 8) + byte(&pc);
        decr_var (var_name);
        fprintf(stderr, "[bc/execute.c] exit execute 32\n");
        break;
      
      case 'h': /* Halt the machine. */
        fprintf(stderr, "[bc/execute.c] enter execute 33\n");
        bc_exit (0);
        /* NOTREACHED */
        fprintf(stderr, "[bc/execute.c] exit execute 33\n");
        break;

      case 'i': /* increment number */
        fprintf(stderr, "[bc/execute.c] enter execute 34\n");
        var_name = byte(&pc);
        if ((var_name & 0x80) != 0)
          var_name = ((var_name & 0x7f) << 8) + byte(&pc);
        incr_var (var_name);
        fprintf(stderr, "[bc/execute.c] exit execute 34\n");
        break;

      case 'l': /* load variable */
        fprintf(stderr, "[bc/execute.c] enter execute 35\n");
        var_name = byte(&pc);
        if ((var_name & 0x80) != 0)
          var_name = ((var_name & 0x7f) << 8) + byte(&pc);
        load_var (var_name);
        fprintf(stderr, "[bc/execute.c] exit execute 35\n");
        break;

      case 'n': /* Negate top of stack. */
        fprintf(stderr, "[bc/execute.c] enter execute 36\n");
        bc_sub (_zero_, ex_stack->s_num, &ex_stack->s_num, 0);
        fprintf(stderr, "[bc/execute.c] exit execute 36\n");
        break;

      case 'p': /* Pop the execution stack. */
        fprintf(stderr, "[bc/execute.c] enter execute 37\n");
        pop ();
        fprintf(stderr, "[bc/execute.c] exit execute 37\n");
        break;

      case 's': /* store variable */
        fprintf(stderr, "[bc/execute.c] enter execute 38\n");
        var_name = byte(&pc);
        if ((var_name & 0x80) != 0)
          var_name = ((var_name & 0x7f) << 8) + byte(&pc);
        store_var (var_name);
        fprintf(stderr, "[bc/execute.c] exit execute 38\n");
        break;

      case 'w': /* Write a string to the output. */
        fprintf(stderr, "[bc/execute.c] enter execute 39\n");
        while ((ch = byte(&pc)) != '"') out_schar (ch);
        fflush (stdout);
        fprintf(stderr, "[bc/execute.c] exit execute 39\n");
        break;
                   
      case 'x': /* Exchange Top of Stack with the one under the tos. */
        fprintf(stderr, "[bc/execute.c] enter execute 40\n");
        if (check_stack(2)) {
          bc_num temp = ex_stack->s_num;
          ex_stack->s_num = ex_stack->s_next->s_num;
          ex_stack->s_next->s_num = temp;
        }
        fprintf(stderr, "[bc/execute.c] exit execute 40\n");
        break;

      case '0': /* Load Constant 0. */
        fprintf(stderr, "[bc/execute.c] enter execute 41\n");
        push_copy (_zero_);
        fprintf(stderr, "[bc/execute.c] exit execute 41\n");
        break;

      case '1': /* Load Constant 1. */
        fprintf(stderr, "[bc/execute.c] enter execute 42\n");
        push_copy (_one_);
        fprintf(stderr, "[bc/execute.c] exit execute 42\n");
        break;

      case '!': /* Negate the boolean value on top of the stack. */
        fprintf(stderr, "[bc/execute.c] enter execute 43\n");
        c_code = bc_is_zero (ex_stack->s_num);
        assign (c_code);
        fprintf(stderr, "[bc/execute.c] exit execute 43\n");
        break;

      case '&': /* compare greater than */
        fprintf(stderr, "[bc/execute.c] enter execute 44\n");
        if (check_stack(2))
        {
          fprintf(stderr, "[bc/execute.c] enter execute 45\n");
          c_code = !bc_is_zero (ex_stack->s_next->s_num)
            && !bc_is_zero (ex_stack->s_num);
          pop ();
          assign (c_code);
          fprintf(stderr, "[bc/execute.c] exit execute 45\n");
        }
        fprintf(stderr, "[bc/execute.c] exit execute 44\n");
        break;

      case '|': /* compare greater than */
        fprintf(stderr, "[bc/execute.c] enter execute 46\n");
        if (check_stack(2))
        {
          fprintf(stderr, "[bc/execute.c] enter execute 47\n");
          c_code = !bc_is_zero (ex_stack->s_next->s_num)
            || !bc_is_zero (ex_stack->s_num);
          pop ();
          assign (c_code);
          fprintf(stderr, "[bc/execute.c] exit execute 47\n");
        }
        fprintf(stderr, "[bc/execute.c] exit execute 46\n");
        break;

      case '+': /* add */
        fprintf(stderr, "[bc/execute.c] enter execute 48\n");
        if (check_stack(2))
        {
          fprintf(stderr, "[bc/execute.c] enter execute 49\n");
          bc_add (ex_stack->s_next->s_num, ex_stack->s_num, &temp_num, 0);
          pop();
          pop();
          push_num (temp_num);
          bc_init_num (&temp_num);
          fprintf(stderr, "[bc/execute.c] exit execute 49\n");
        }
        fprintf(stderr, "[bc/execute.c] exit execute 48\n");
        break;

      case '-': /* subtract */
        fprintf(stderr, "[bc/execute.c] enter execute 50\n");
        if (check_stack(2))
        {
          fprintf(stderr, "[bc/execute.c] enter execute 51\n");
          bc_sub (ex_stack->s_next->s_num, ex_stack->s_num, &temp_num, 0);
          pop();
          pop();
          push_num (temp_num);
          bc_init_num (&temp_num);
          fprintf(stderr, "[bc/execute.c] exit execute 51\n");
        }
        fprintf(stderr, "[bc/execute.c] exit execute 50\n");
        break;

      case '*': /* multiply */
        fprintf(stderr, "[bc/execute.c] enter execute 52\n");
        if (check_stack(2))
        {
          fprintf(stderr, "[bc/execute.c] enter execute 53\n");
          bc_multiply (ex_stack->s_next->s_num, ex_stack->s_num,
                     &temp_num, scale);
          pop();
          pop();
          push_num (temp_num);
          bc_init_num (&temp_num);
          fprintf(stderr, "[bc/execute.c] exit execute 53\n");
        }
        fprintf(stderr, "[bc/execute.c] exit execute 52\n");
        break;

      case '/': /* divide */
        fprintf(stderr, "[bc/execute.c] enter execute 54\n");
        if (check_stack(2))
        {
          fprintf(stderr, "[bc/execute.c] enter execute 55\n");
          if (bc_divide (ex_stack->s_next->s_num,
                       ex_stack->s_num, &temp_num, scale) == 0)
          {
            fprintf(stderr, "[bc/execute.c] enter execute 56\n");
            pop();
            pop();
            push_num (temp_num);
            bc_init_num (&temp_num);
            fprintf(stderr, "[bc/execute.c] exit execute 56\n");
          }
          else
          {
            fprintf(stderr, "[bc/execute.c] enter execute 57\n");
            rt_error ("Divide by zero");
            fprintf(stderr, "[bc/execute.c] exit execute 57\n");
          }
          fprintf(stderr, "[bc/execute.c] exit execute 55\n");
        }
        fprintf(stderr, "[bc/execute.c] exit execute 54\n");
        break;

      case '%': /* remainder */
        fprintf(stderr, "[bc/execute.c] enter execute 58\n");
        if (check_stack(2))
        {
          fprintf(stderr, "[bc/execute.c] enter execute 59\n");
          if (bc_is_zero (ex_stack->s_num))
          {
            fprintf(stderr, "[bc/execute.c] enter execute 60\n");
            rt_error ("Modulo by zero");
            fprintf(stderr, "[bc/execute.c] exit execute 60\n");
          }
          else
          {
            fprintf(stderr, "[bc/execute.c] enter execute 61\n");
            bc_modulo (ex_stack->s_next->s_num,
                     ex_stack->s_num, &temp_num, scale);
            pop();
            pop();
            push_num (temp_num);
            bc_init_num (&temp_num);
            fprintf(stderr, "[bc/execute.c] exit execute 61\n");
          }
          fprintf(stderr, "[bc/execute.c] exit execute 59\n");
        }
        fprintf(stderr, "[bc/execute.c] exit execute 58\n");
        break;

      case '^': /* raise */
        fprintf(stderr, "[bc/execute.c] enter execute 62\n");
        if (check_stack(2))
        {
          fprintf(stderr, "[bc/execute.c] enter execute 63\n");
          bc_raise (ex_stack->s_next->s_num,
                  ex_stack->s_num, &temp_num, scale);
          if (bc_is_zero (ex_stack->s_next->s_num) && bc_is_neg (ex_stack->s_num))
          {
            fprintf(stderr, "[bc/execute.c] enter execute 64\n");
            rt_error ("divide by zero");
            fprintf(stderr, "[bc/execute.c] exit execute 64\n");
          }
          pop();
          pop();
          push_num (temp_num);
          bc_init_num (&temp_num);
          fprintf(stderr, "[bc/execute.c] exit execute 63\n");
        }
        fprintf(stderr, "[bc/execute.c] exit execute 62\n");
        break;

      case '=': /* compare equal */
        fprintf(stderr, "[bc/execute.c] enter execute 65\n");
        if (check_stack(2))
        {
          fprintf(stderr, "[bc/execute.c] enter execute 66\n");
          c_code = bc_compare (ex_stack->s_next->s_num,
                             ex_stack->s_num) == 0;
          pop ();
          assign (c_code);
          fprintf(stderr, "[bc/execute.c] exit execute 66\n");
        }
        fprintf(stderr, "[bc/execute.c] exit execute 65\n");
        break;

      case '#': /* compare not equal */
        fprintf(stderr, "[bc/execute.c] enter execute 67\n");
        if (check_stack(2))
        {
          fprintf(stderr, "[bc/execute.c] enter execute 68\n");
          c_code = bc_compare (ex_stack->s_next->s_num,
                             ex_stack->s_num) != 0;
          pop ();
          assign (c_code);
          fprintf(stderr, "[bc/execute.c] exit execute 68\n");
        }
        fprintf(stderr, "[bc/execute.c] exit execute 67\n");
        break;

      case '<': /* compare less than */
        fprintf(stderr, "[bc/execute.c] enter execute 69\n");
        if (check_stack(2))
        {
          fprintf(stderr, "[bc/execute.c] enter execute 70\n");
          c_code = bc_compare (ex_stack->s_next->s_num,
                             ex_stack->s_num) == -1;
          pop ();
          assign (c_code);
          fprintf(stderr, "[bc/execute.c] exit execute 70\n");
        }
        fprintf(stderr, "[bc/execute.c] exit execute 69\n");
        break;

      case '{': /* compare less than or equal */
        fprintf(stderr, "[bc/execute.c] enter execute 71\n");
        if (check_stack(2))
        {
          fprintf(stderr, "[bc/execute.c] enter execute 72\n");
          c_code = bc_compare (ex_stack->s_next->s_num,
                             ex_stack->s_num) <= 0;
          pop ();
          assign (c_code);
          fprintf(stderr, "[bc/execute.c] exit execute 72\n");
        }
        fprintf(stderr, "[bc/execute.c] exit execute 71\n");
        break;

      case '>': /* compare greater than */
        fprintf(stderr, "[bc/execute.c] enter execute 73\n");
        if (check_stack(2))
        {
          fprintf(stderr, "[bc/execute.c] enter execute 74\n");
          c_code = bc_compare (ex_stack->s_next->s_num,
                             ex_stack->s_num) == 1;
          pop ();
          assign (c_code);
          fprintf(stderr, "[bc/execute.c] exit execute 74\n");
        }
        fprintf(stderr, "[bc/execute.c] exit execute 73\n");
        break;

      case '}': /* compare greater than or equal */
        fprintf(stderr, "[bc/execute.c] enter execute 75\n");
        if (check_stack(2))
        {
          fprintf(stderr, "[bc/execute.c] enter execute 76\n");
          c_code = bc_compare (ex_stack->s_next->s_num,
                             ex_stack->s_num) >= 0;
          pop ();
          assign (c_code);
          fprintf(stderr, "[bc/execute.c] exit execute 76\n");
        }
        fprintf(stderr, "[bc/execute.c] exit execute 75\n");
        break;

      default: /* error! */
        fprintf(stderr, "[bc/execute.c] enter execute 77\n");
        rt_error ("bad instruction: inst=%c", inst);
        fprintf(stderr, "[bc/execute.c] exit execute 77\n");
    }
  }

  fprintf(stderr, "[bc/execute.c] enter execute 78\n");
  /* Clean up the function stack and pop all autos/parameters. */
  while (pc.pc_func != 0)
  {
    fprintf(stderr, "[bc/execute.c] enter execute 79\n");
    pop_vars(functions[pc.pc_func].f_autos);
    pop_vars(functions[pc.pc_func].f_params);
    fpop ();
    pc.pc_addr = fpop ();
    pc.pc_func = fpop ();
    fprintf(stderr, "[bc/execute.c] exit execute 79\n");
  }

  /* Clean up the execution stack. */ 
  while (ex_stack != NULL) pop();

  /* Clean up the interrupt stuff. */
  if (interactive)
  {
    fprintf(stderr, "[bc/execute.c] enter execute 80\n");
    signal (SIGINT, use_quit);
    if (had_sigint)
    {
      fprintf(stderr, "[bc/execute.c] enter execute 81\n");
      printf ("\ninterrupted execution.\n");
      fprintf(stderr, "[bc/execute.c] exit execute 81\n");
    }
    fprintf(stderr, "[bc/execute.c] exit execute 80\n");
  }
  fprintf(stderr, "[bc/execute.c] exit execute 78\n");
}


/* Prog_char gets another byte from the program.  It is used for
   conversion of text constants in the code to numbers. */

int
prog_char (void)
{
  fprintf(stderr, "[bc/execute.c] enter prog_char 1\n");
  return (int) byte(&pc);
  fprintf(stderr, "[bc/execute.c] exit prog_char 1\n");
}


/* Read a character from the standard input.  This function is used
   by the "read" function. */

int
input_char (void)
{
  fprintf(stderr, "[bc/execute.c] enter input_char 1\n");
  int in_ch;
  
  /* Get a character from the standard input for the read function. */
  in_ch = getchar();
  fprintf(stderr, "[bc/execute.c] exit input_char 1\n");

  /* Check for a \ quoted newline. */
  if (in_ch == '\\')
  {
    fprintf(stderr, "[bc/execute.c] enter input_char 2\n");
    in_ch = getchar();
    fprintf(stderr, "[bc/execute.c] exit input_char 2\n");
    if (in_ch == '\n') {
      fprintf(stderr, "[bc/execute.c] enter input_char 3\n");
      in_ch = getchar();
      out_col = 0;  /* Saw a new line */
      fprintf(stderr, "[bc/execute.c] exit input_char 3\n");
    }
  }

  fprintf(stderr, "[bc/execute.c] enter input_char 4\n");
  /* Classify and preprocess the input character. */
  if (isdigit(in_ch))
  {
    fprintf(stderr, "[bc/execute.c] enter input_char 5\n");
    return (in_ch - '0');
    fprintf(stderr, "[bc/execute.c] exit input_char 5\n");
  }
  if (in_ch >= 'A' && in_ch <= 'Z')
  {
    fprintf(stderr, "[bc/execute.c] enter input_char 6\n");
    return (in_ch + 10 - 'A');
    fprintf(stderr, "[bc/execute.c] exit input_char 6\n");
  }
  if (in_ch >= 'a' && in_ch <= 'z')
  {
    fprintf(stderr, "[bc/execute.c] enter input_char 7\n");
    return (in_ch + 10 - 'a');
    fprintf(stderr, "[bc/execute.c] exit input_char 7\n");
  }
  if (in_ch == '.' || in_ch == '+' || in_ch == '-')
  {
    fprintf(stderr, "[bc/execute.c] enter input_char 8\n");
    return (in_ch);
    fprintf(stderr, "[bc/execute.c] exit input_char 8\n");
  }
  if (in_ch == '~')
  {
    fprintf(stderr, "[bc/execute.c] enter input_char 9\n");
    return (':');
    fprintf(stderr, "[bc/execute.c] exit input_char 9\n");
  }
  if (in_ch <= ' ')
  {
    fprintf(stderr, "[bc/execute.c] enter input_char 10\n");
    return ('~');
    fprintf(stderr, "[bc/execute.c] exit input_char 10\n");
  }
  
  fprintf(stderr, "[bc/execute.c] enter input_char 11\n");
  return (':');
  fprintf(stderr, "[bc/execute.c] exit input_char 11\n");
  fprintf(stderr, "[bc/execute.c] exit input_char 4\n");
}


/* Push_constant converts a sequence of input characters as returned
   by IN_CHAR into a number.  The number is pushed onto the execution
   stack.  The number is converted as a number in base CONV_BASE. */

void
push_constant (int (*in_char)(VOID), int conv_base)
{
  fprintf(stderr, "[bc/execute.c] enter push_constant 1\n");
  int digits;
  bc_num build, temp, result, mult, divisor;
  int   in_ch, first_ch;
  char  negative;

  /* Initialize all bc numbers */
  bc_init_num (&temp);
  bc_init_num (&result);
  bc_init_num (&mult);
  build = bc_copy_num (_zero_);
  negative = FALSE;

  /* The conversion base. */
  bc_int2num (&mult, conv_base);
  fprintf(stderr, "[bc/execute.c] exit push_constant 1\n");
  
  /* Get things ready. */
  fprintf(stderr, "[bc/execute.c] enter push_constant 2\n");
  in_ch = in_char();
  /* ~ is space returned by input_char(), prog_char does not return spaces. */
  while (in_ch == '~')
    in_ch = in_char();
  fprintf(stderr, "[bc/execute.c] exit push_constant 2\n");

  if (in_ch == '+')
  {
    fprintf(stderr, "[bc/execute.c] enter push_constant 3\n");
    in_ch = in_char();
    fprintf(stderr, "[bc/execute.c] exit push_constant 3\n");
  }
  else if (in_ch == '-')
  {
    fprintf(stderr, "[bc/execute.c] enter push_constant 4\n");
    negative = TRUE;
    in_ch = in_char();
    fprintf(stderr, "[bc/execute.c] exit push_constant 4\n");
  }

  /* Check for the special case of a single digit. */
  if (in_ch < 36)
  {
    fprintf(stderr, "[bc/execute.c] enter push_constant 5\n");
    first_ch = in_ch;
    in_ch = in_char();
    if (in_ch < 36 && first_ch >= conv_base)
      first_ch = conv_base - 1;
    bc_int2num (&build, (int) first_ch);
    fprintf(stderr, "[bc/execute.c] exit push_constant 5\n");
  }

  /* Convert the integer part. */
  fprintf(stderr, "[bc/execute.c] enter push_constant 6\n");
  while (in_ch < 36)
  {
    fprintf(stderr, "[bc/execute.c] enter push_constant 7\n");
    if (in_ch < 36 && in_ch >= conv_base) in_ch = conv_base-1;
    bc_multiply (build, mult, &result, 0);
    bc_int2num (&temp, (int) in_ch);
    bc_add (result, temp, &build, 0);
    in_ch = in_char();
    fprintf(stderr, "[bc/execute.c] exit push_constant 7\n");
  }
  fprintf(stderr, "[bc/execute.c] exit push_constant 6\n");
  
  if (in_ch == '.')
  {
    fprintf(stderr, "[bc/execute.c] enter push_constant 8\n");
    in_ch = in_char();
    if (in_ch >= conv_base) in_ch = conv_base-1;
    bc_free_num (&result);
    bc_free_num (&temp);
    divisor = bc_copy_num (_one_);
    result = bc_copy_num (_zero_);
    digits = 0;
    fprintf(stderr, "[bc/execute.c] exit push_constant 8\n");
    
    while (in_ch < 36)
    {
      fprintf(stderr, "[bc/execute.c] enter push_constant 9\n");
      bc_multiply (result, mult, &result, 0);
      bc_int2num (&temp, (int) in_ch);
      bc_add (result, temp, &result, 0);
      bc_multiply (divisor, mult, &divisor, 0);
      digits++;
      in_ch = in_char();
      if (in_ch < 36 && in_ch >= conv_base) in_ch = conv_base-1;
      fprintf(stderr, "[bc/execute.c] exit push_constant 9\n");
    }
    
    fprintf(stderr, "[bc/execute.c] enter push_constant 10\n");
    bc_divide (result, divisor, &result, digits);
    bc_add (build, result, &build, 0);
    fprintf(stderr, "[bc/execute.c] exit push_constant 10\n");
  }
  
  /* Final work.  */
  fprintf(stderr, "[bc/execute.c] enter push_constant 11\n");
  if (negative)
    bc_sub (_zero_, build, &build, 0);

  push_num (build);
  bc_free_num (&temp);
  bc_free_num (&result);
  bc_free_num (&mult);
  fprintf(stderr, "[bc/execute.c] exit push_constant 11\n");
}


/* When converting base 10 constants from the program, we use this
   more efficient way to convert them to numbers.  PC tells where
   the constant starts and is expected to be advanced to after
   the constant. */

void
push_b10_const (program_counter *progctr)
{
  fprintf(stderr, "[bc/execute.c] enter push_b10_const 1\n");
  bc_num build;
  program_counter look_pc;
  int kdigits, kscale;
  unsigned char inchar;
  char *ptr;
  
  /* Count the digits and get things ready. */
  look_pc = *progctr;
  kdigits = 0;
  kscale  = 0;
  inchar = byte (&look_pc);
  while (inchar != '.' && inchar != ':')
  {
    fprintf(stderr, "[bc/execute.c] enter push_b10_const 2\n");
    kdigits++;
    inchar = byte(&look_pc);
    fprintf(stderr, "[bc/execute.c] exit push_b10_const 2\n");
  }
  fprintf(stderr, "[bc/execute.c] exit push_b10_const 1\n");
  
  if (inchar == '.' )
  {
    fprintf(stderr, "[bc/execute.c] enter push_b10_const 3\n");
    inchar = byte(&look_pc);
    while (inchar != ':')
    {
      fprintf(stderr, "[bc/execute.c] enter push_b10_const 4\n");
      kscale++;
      inchar = byte(&look_pc);
      fprintf(stderr, "[bc/execute.c] exit push_b10_const 4\n");
    }
    fprintf(stderr, "[bc/execute.c] exit push_b10_const 3\n");
  }

  /* Get the first character again and move the progctr. */
  fprintf(stderr, "[bc/execute.c] enter push_b10_const 5\n");
  inchar = byte(progctr);
  fprintf(stderr, "[bc/execute.c] exit push_b10_const 5\n");
  
  /* Secial cases of 0, 1, and A-F single inputs. */
  if (kdigits == 1 && kscale == 0)
  {
    fprintf(stderr, "[bc/execute.c] enter push_b10_const 6\n");
    if (inchar == 0)
    {
      fprintf(stderr, "[bc/execute.c] enter push_b10_const 7\n");
      push_copy (_zero_);
      inchar = byte(progctr);
      fprintf(stderr, "[bc/execute.c] exit push_b10_const 7\n");
      return;
    }
    if (inchar == 1) {
      fprintf(stderr, "[bc/execute.c] enter push_b10_const 8\n");
      push_copy (_one_);
      inchar = byte(progctr);
      fprintf(stderr, "[bc/execute.c] exit push_b10_const 8\n");
      return;
    }
    if (inchar > 9)
    {
      fprintf(stderr, "[bc/execute.c] enter push_b10_const 9\n");
      bc_init_num (&build);
      bc_int2num (&build, inchar);
      push_num (build);
      inchar = byte(progctr);
      fprintf(stderr, "[bc/execute.c] exit push_b10_const 9\n");
      return;
    }
    fprintf(stderr, "[bc/execute.c] exit push_b10_const 6\n");
  }

  /* Build the new number. */
  fprintf(stderr, "[bc/execute.c] enter push_b10_const 10\n");
  if (kdigits == 0)
  {
    fprintf(stderr, "[bc/execute.c] enter push_b10_const 11\n");
    build = bc_new_num (1,kscale);
    ptr = build->n_value;
    *ptr++ = 0;
    fprintf(stderr, "[bc/execute.c] exit push_b10_const 11\n");
  }
  else
  {
    fprintf(stderr, "[bc/execute.c] enter push_b10_const 12\n");
    build = bc_new_num (kdigits,kscale);
    ptr = build->n_value;
    fprintf(stderr, "[bc/execute.c] exit push_b10_const 12\n");
  }
  fprintf(stderr, "[bc/execute.c] exit push_b10_const 10\n");

  fprintf(stderr, "[bc/execute.c] enter push_b10_const 13\n");
  while (inchar != ':')
  {
    fprintf(stderr, "[bc/execute.c] enter push_b10_const 14\n");
    if (inchar != '.')
    {
      fprintf(stderr, "[bc/execute.c] enter push_b10_const 15\n");
      if (inchar > 9)
        *ptr++ = 9;
      else
        *ptr++ = inchar;
      fprintf(stderr, "[bc/execute.c] exit push_b10_const 15\n");
    }
    inchar = byte(progctr);
    fprintf(stderr, "[bc/execute.c] exit push_b10_const 14\n");
  }
  push_num (build);
  fprintf(stderr, "[bc/execute.c] exit push_b10_const 13\n");
}


/* Put the correct value on the stack for C_CODE.  Frees TOS num. */

void
assign (char code)
{
  fprintf(stderr, "[bc/execute.c] enter assign 1\n");
  bc_free_num (&ex_stack->s_num);
  if (code)
    ex_stack->s_num = bc_copy_num (_one_);
  else
    ex_stack->s_num = bc_copy_num (_zero_);
  fprintf(stderr, "[bc/execute.c] exit assign 1\n");
}

// Total cost: 0.192192
// Total split cost: 0.000000, input tokens: 0, output tokens: 0. Split chunks: [(0, 795)]
// Total instrumented cost: 0.192192, input tokens: 9604, output tokens: 10892

/*  This file is part of GNU bc.

    Copyright (C) 1991-1994, 1997, 2006, 2008, 2012-2017 Free Software Foundation, Inc.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License , or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; see the file COPYING.  If not, see
    <http://www.gnu.org/licenses>.

    You may contact the author by:
       e-mail:  philnelson@acm.org
      us-mail:  Philip A. Nelson
                Computer Science Department, 9062
                Western Washington University
                Bellingham, WA 98226-9062
       
*************************************************************************/

/* util.c: Utility routines for bc. */

#include "bcdefs.h"
#ifndef VARARGS
#include <stdarg.h>
#else
#include <varargs.h>
#endif
#include "proto.h"
#include <stdio.h>


/* strcopyof mallocs new memory and copies a string to to the new
   memory. */

char *
strcopyof (const char *str)
{
  fprintf(stderr, "[bc/util.c] enter strcopyof 1\n");
  char *temp;

  temp = bc_malloc (strlen (str)+1);
  return (strcpy (temp,str));
  fprintf(stderr, "[bc/util.c] exit strcopyof 1\n");
}


/* nextarg adds another value to the list of arguments. */

arg_list *
nextarg (arg_list *args, int val, int is_var)
{
  fprintf(stderr, "[bc/util.c] enter nextarg 1\n");
  arg_list *temp;

  temp = bc_malloc (sizeof (arg_list));
  temp->av_name = val;
  temp->arg_is_var = is_var;
  temp->next = args;
 
  return (temp);
  fprintf(stderr, "[bc/util.c] exit nextarg 1\n");
}


/* For generate, we must produce a string in the form
    "val,val,...,val".  We also need a couple of static variables
   for retaining old generated strings.  It also uses a recursive
   function that builds the string. */

static char *arglist1 = NULL, *arglist2 = NULL;


/* make_arg_str does the actual construction of the argument string.
   ARGS is the pointer to the list and LEN is the maximum number of
   characters needed.  1 char is the minimum needed. 
 */

static char *make_arg_str (arg_list *args, int len);

static char *
make_arg_str (arg_list *args, int len)
{
  fprintf(stderr, "[bc/util.c] enter make_arg_str 1\n");
  char *temp;
  char sval[30];

  /* Recursive call. */
  if (args != NULL)
  {
    fprintf(stderr, "[bc/util.c] enter make_arg_str 2\n");
    temp = make_arg_str (args->next, len+12);
    fprintf(stderr, "[bc/util.c] exit make_arg_str 2\n");
  }
  else
  {
    fprintf(stderr, "[bc/util.c] enter make_arg_str 3\n");
    temp = bc_malloc (len);
    *temp = 0;
    return temp;
    fprintf(stderr, "[bc/util.c] exit make_arg_str 3\n");
  }

  /* Add the current number to the end of the string. */
  if (args->arg_is_var)
  {
    fprintf(stderr, "[bc/util.c] enter make_arg_str 4\n");
    if (len != 1) 
    {
      fprintf(stderr, "[bc/util.c] enter make_arg_str 5\n");
      snprintf (sval, sizeof(sval), "*%d,", args->av_name);
      fprintf(stderr, "[bc/util.c] exit make_arg_str 5\n");
    }
    else
    {
      fprintf(stderr, "[bc/util.c] enter make_arg_str 6\n");
      snprintf (sval, sizeof(sval), "*%d", args->av_name);
      fprintf(stderr, "[bc/util.c] exit make_arg_str 6\n");
    }
    fprintf(stderr, "[bc/util.c] exit make_arg_str 4\n");
  }
  else
  {
    fprintf(stderr, "[bc/util.c] enter make_arg_str 7\n");
    if (len != 1) 
    {
      fprintf(stderr, "[bc/util.c] enter make_arg_str 8\n");
      snprintf (sval, sizeof(sval), "%d,", args->av_name);
      fprintf(stderr, "[bc/util.c] exit make_arg_str 8\n");
    }
    else
    {
      fprintf(stderr, "[bc/util.c] enter make_arg_str 9\n");
      snprintf (sval, sizeof(sval), "%d", args->av_name);
      fprintf(stderr, "[bc/util.c] exit make_arg_str 9\n");
    }
    fprintf(stderr, "[bc/util.c] exit make_arg_str 7\n");
  }
  temp = strcat (temp, sval);
  return (temp);
  fprintf(stderr, "[bc/util.c] exit make_arg_str 1\n");
}

char *
arg_str (arg_list *args)
{
  fprintf(stderr, "[bc/util.c] enter arg_str 1\n");
  if (arglist2 != NULL) 
  {
    fprintf(stderr, "[bc/util.c] enter arg_str 2\n");
    free (arglist2);
    fprintf(stderr, "[bc/util.c] exit arg_str 2\n");
  }
  arglist2 = arglist1;
  arglist1 = make_arg_str (args, 1);
  return (arglist1);
  fprintf(stderr, "[bc/util.c] exit arg_str 1\n");
}

char *
call_str (arg_list *args)
{
  fprintf(stderr, "[bc/util.c] enter call_str 1\n");
  arg_list *temp;
  int       arg_count;
  int       ix;
  
  if (arglist2 != NULL) 
  {
    fprintf(stderr, "[bc/util.c] enter call_str 2\n");
    free (arglist2);
    fprintf(stderr, "[bc/util.c] exit call_str 2\n");
  }
  arglist2 = arglist1;

  /* Count the number of args and add the 0's and 1's. */
  for (temp = args, arg_count = 0; temp != NULL; temp = temp->next)
  {
    fprintf(stderr, "[bc/util.c] enter call_str 3\n");
    arg_count++;
    fprintf(stderr, "[bc/util.c] exit call_str 3\n");
  }
  arglist1 = bc_malloc(arg_count+1);
  for (temp = args, ix=0; temp != NULL; temp = temp->next)
  {
    fprintf(stderr, "[bc/util.c] enter call_str 4\n");
    arglist1[ix++] = ( temp->av_name ? '1' : '0');
    fprintf(stderr, "[bc/util.c] exit call_str 4\n");
  }
  arglist1[ix] = 0;
      
  return (arglist1);
  fprintf(stderr, "[bc/util.c] exit call_str 1\n");
}

/* free_args frees an argument list ARGS. */

void
free_args (arg_list *args)
{ 
  fprintf(stderr, "[bc/util.c] enter free_args 1\n");
  arg_list *temp;
 
  temp = args;
  while (temp != NULL)
  {
    fprintf(stderr, "[bc/util.c] enter free_args 2\n");
    args = args->next;
    free (temp);
    temp = args;
    fprintf(stderr, "[bc/util.c] exit free_args 2\n");
  }
  fprintf(stderr, "[bc/util.c] exit free_args 1\n");
}


/* Check for valid parameter (PARAMS) and auto (AUTOS) lists.
   There must be no duplicates any where.  Also, this is where
   warnings are generated for array parameters. */

void
check_params (arg_list *params, arg_list *autos)
{
  fprintf(stderr, "[bc/util.c] enter check_params 1\n");
  arg_list *tmp1, *tmp2;

  /* Check for duplicate parameters. */
  if (params != NULL)
  {
    fprintf(stderr, "[bc/util.c] enter check_params 2\n");
    tmp1 = params;
    while (tmp1 != NULL)
    {
      fprintf(stderr, "[bc/util.c] enter check_params 3\n");
      tmp2 = tmp1->next;
      while (tmp2 != NULL)
      {
        fprintf(stderr, "[bc/util.c] enter check_params 4\n");
        if (tmp2->av_name == tmp1->av_name) 
        {
          fprintf(stderr, "[bc/util.c] enter check_params 5\n");
          yyerror ("duplicate parameter names");
          fprintf(stderr, "[bc/util.c] exit check_params 5\n");
        }
        tmp2 = tmp2->next;
        fprintf(stderr, "[bc/util.c] exit check_params 4\n");
      }
      if (tmp1->arg_is_var)
      {
        fprintf(stderr, "[bc/util.c] enter check_params 6\n");
        ct_warn ("Variable array parameter");
        fprintf(stderr, "[bc/util.c] exit check_params 6\n");
      }
      tmp1 = tmp1->next;
      fprintf(stderr, "[bc/util.c] exit check_params 3\n");
    }
    fprintf(stderr, "[bc/util.c] exit check_params 2\n");
  }

  /* Check for duplicate autos. */
  if (autos != NULL)
  {
    fprintf(stderr, "[bc/util.c] enter check_params 7\n");
    tmp1 = autos;
    while (tmp1 != NULL)
    {
      fprintf(stderr, "[bc/util.c] enter check_params 8\n");
      tmp2 = tmp1->next;
      while (tmp2 != NULL)
      {
        fprintf(stderr, "[bc/util.c] enter check_params 9\n");
        if (tmp2->av_name == tmp1->av_name) 
        {
          fprintf(stderr, "[bc/util.c] enter check_params 10\n");
          yyerror ("duplicate auto variable names");
          fprintf(stderr, "[bc/util.c] exit check_params 10\n");
        }
        tmp2 = tmp2->next;
        fprintf(stderr, "[bc/util.c] exit check_params 9\n");
      }
      if (tmp1->arg_is_var)
      {
        fprintf(stderr, "[bc/util.c] enter check_params 11\n");
        yyerror ("* not allowed here");
        fprintf(stderr, "[bc/util.c] exit check_params 11\n");
      }
      tmp1 = tmp1->next;
      fprintf(stderr, "[bc/util.c] exit check_params 8\n");
    }
    fprintf(stderr, "[bc/util.c] exit check_params 7\n");
  }

  /* Check for duplicate between parameters and autos. */
  if ((params != NULL) && (autos != NULL))
  {
    fprintf(stderr, "[bc/util.c] enter check_params 12\n");
    tmp1 = params;
    while (tmp1 != NULL)
    {
      fprintf(stderr, "[bc/util.c] enter check_params 13\n");
      tmp2 = autos;
      while (tmp2 != NULL)
      {
        fprintf(stderr, "[bc/util.c] enter check_params 14\n");
        if (tmp2->av_name == tmp1->av_name) 
        {
          fprintf(stderr, "[bc/util.c] enter check_params 15\n");
          yyerror ("variable in both parameter and auto lists");
          fprintf(stderr, "[bc/util.c] exit check_params 15\n");
        }
        tmp2 = tmp2->next;
        fprintf(stderr, "[bc/util.c] exit check_params 14\n");
      }
      tmp1 = tmp1->next;
      fprintf(stderr, "[bc/util.c] exit check_params 13\n");
    }
    fprintf(stderr, "[bc/util.c] exit check_params 12\n");
  }
  fprintf(stderr, "[bc/util.c] exit check_params 1\n");
}

/* genstr management to avoid buffer overflow. */
void
set_genstr_size (int size)
{
  fprintf(stderr, "[bc/util.c] enter set_genstr_size 1\n");
  if (size > genlen) {
    fprintf(stderr, "[bc/util.c] enter set_genstr_size 2\n");
    if (genstr != NULL)
    {
      fprintf(stderr, "[bc/util.c] enter set_genstr_size 3\n");
      free(genstr);
      fprintf(stderr, "[bc/util.c] exit set_genstr_size 3\n");
    }
    genstr = bc_malloc (size);
    genlen = size;
    fprintf(stderr, "[bc/util.c] exit set_genstr_size 2\n");
  }
  fprintf(stderr, "[bc/util.c] exit set_genstr_size 1\n");
}


/* Initialize the code generator the parser. */

void
init_gen (void)
{
  fprintf(stderr, "[bc/util.c] enter init_gen 1\n");
  /* Get things ready. */
  break_label = 0;
  continue_label = 0;
  next_label  = 1;
  out_count = 2;
  if (compile_only) 
  {
    fprintf(stderr, "[bc/util.c] enter init_gen 2\n");
    printf ("@i");
    fprintf(stderr, "[bc/util.c] exit init_gen 2\n");
  }
  else
  {
    fprintf(stderr, "[bc/util.c] enter init_gen 3\n");
    init_load ();
    fprintf(stderr, "[bc/util.c] exit init_gen 3\n");
  }
  had_error = FALSE;
  did_gen = FALSE;
  set_genstr_size (64);
  fprintf(stderr, "[bc/util.c] exit init_gen 1\n");
}


/* generate code STR for the machine. */

void
generate (const char *str)
{
  fprintf(stderr, "[bc/util.c] enter generate 1\n");
  did_gen = TRUE;
  if (compile_only)
  {
    fprintf(stderr, "[bc/util.c] enter generate 2\n");
    printf ("%s",str);
    out_count += strlen(str);
    if (out_count > 60)
    {
      fprintf(stderr, "[bc/util.c] enter generate 3\n");
      printf ("\n");
      out_count = 0;
      fprintf(stderr, "[bc/util.c] exit generate 3\n");
    }
    fprintf(stderr, "[bc/util.c] exit generate 2\n");
  }
  else
  {
    fprintf(stderr, "[bc/util.c] enter generate 4\n");
    load_code (str);
    fprintf(stderr, "[bc/util.c] exit generate 4\n");
  }
  fprintf(stderr, "[bc/util.c] exit generate 1\n");
}


/* Execute the current code as loaded. */

void
run_code(void)
{
  fprintf(stderr, "[bc/util.c] enter run_code 1\n");
  /* If no compile errors run the current code. */
  if (!had_error && did_gen)
  {
    fprintf(stderr, "[bc/util.c] enter run_code 2\n");
    if (compile_only)
    {
      fprintf(stderr, "[bc/util.c] enter run_code 3\n");
      printf ("@r\n"); 
      out_count = 0;
      fprintf(stderr, "[bc/util.c] exit run_code 3\n");
    }
    else
    {
      fprintf(stderr, "[bc/util.c] enter run_code 4\n");
      execute ();
      fprintf(stderr, "[bc/util.c] exit run_code 4\n");
    }
    fprintf(stderr, "[bc/util.c] exit run_code 2\n");
  }

  /* Reinitialize the code generation and machine. */
  if (did_gen)
  {
    fprintf(stderr, "[bc/util.c] enter run_code 5\n");
    init_gen();
    fprintf(stderr, "[bc/util.c] exit run_code 5\n");
  }
  else
  {
    fprintf(stderr, "[bc/util.c] enter run_code 6\n");
    had_error = FALSE;
    fprintf(stderr, "[bc/util.c] exit run_code 6\n");
  }
  fprintf(stderr, "[bc/util.c] exit run_code 1\n");
}


/* Output routines: Write a character CH to the standard output.
   It keeps track of the number of characters output and may
   break the output with a "\<cr>".  Always used for numbers. */

void
out_char (int ch)
{
  fprintf(stderr, "[bc/util.c] enter out_char 1\n");
  if (ch == '\n')
  {
    fprintf(stderr, "[bc/util.c] enter out_char 2\n");
    out_col = 0;
    putchar ('\n');
    fprintf(stderr, "[bc/util.c] exit out_char 2\n");
  }
  else
  {
    fprintf(stderr, "[bc/util.c] enter out_char 3\n");
    out_col++;
    if (out_col == line_size-1 && line_size != 0)
    {
      fprintf(stderr, "[bc/util.c] enter out_char 4\n");
      putchar ('\\');
      putchar ('\n');
      out_col = 1;
      fprintf(stderr, "[bc/util.c] exit out_char 4\n");
    }
    putchar (ch);
    fprintf(stderr, "[bc/util.c] exit out_char 3\n");
  }
  fprintf(stderr, "[bc/util.c] exit out_char 1\n");
}

/* Output routines: Write a character CH to the standard output.
   It keeps track of the number of characters output and may
   break the output with a "\<cr>".  This one is for strings.
   In POSIX bc, strings are not broken across lines. */

void
out_schar (int ch)
{
  fprintf(stderr, "[bc/util.c] enter out_schar 1\n");
  if (ch == '\n')
  {
    fprintf(stderr, "[bc/util.c] enter out_schar 2\n");
    out_col = 0;
    putchar ('\n');
    fprintf(stderr, "[bc/util.c] exit out_schar 2\n");
  }
  else
  {
    fprintf(stderr, "[bc/util.c] enter out_schar 3\n");
    if (!std_only)
    {
      fprintf(stderr, "[bc/util.c] enter out_schar 4\n");
      out_col++;
      if (out_col == line_size-1 && line_size != 0)
      {
        fprintf(stderr, "[bc/util.c] enter out_schar 5\n");
        putchar ('\\');
        putchar ('\n');
        out_col = 1;
        fprintf(stderr, "[bc/util.c] exit out_schar 5\n");
      }
      fprintf(stderr, "[bc/util.c] exit out_schar 4\n");
    }
    putchar (ch);
    fprintf(stderr, "[bc/util.c] exit out_schar 3\n");
  }
  fprintf(stderr, "[bc/util.c] exit out_schar 1\n");
}


/* The following are "Symbol Table" routines for the parser. */

/*  find_id returns a pointer to node in TREE that has the correct
    ID.  If there is no node in TREE with ID, NULL is returned. */

id_rec *
find_id (id_rec *tree, const char *id)
{
  fprintf(stderr, "[bc/util.c] enter find_id 1\n");
  int cmp_result;
  
  /* Check for an empty tree. */
  if (tree == NULL)
  {
    fprintf(stderr, "[bc/util.c] enter find_id 2\n");
    return NULL;
    fprintf(stderr, "[bc/util.c] exit find_id 2\n");
  }

  /* Recursively search the tree. */
  cmp_result = strcmp (id, tree->id);
  if (cmp_result == 0)
  {
    fprintf(stderr, "[bc/util.c] enter find_id 3\n");
    return tree;  /* This is the item. */
    fprintf(stderr, "[bc/util.c] exit find_id 3\n");
  }
  else if (cmp_result < 0)
  {
    fprintf(stderr, "[bc/util.c] enter find_id 4\n");
    return find_id (tree->left, id);
    fprintf(stderr, "[bc/util.c] exit find_id 4\n");
  }
  else
  {
    fprintf(stderr, "[bc/util.c] enter find_id 5\n");
    return find_id (tree->right, id);  
    fprintf(stderr, "[bc/util.c] exit find_id 5\n");
  }
  fprintf(stderr, "[bc/util.c] exit find_id 1\n");
}


/* insert_id_rec inserts a NEW_ID rec into the tree whose ROOT is
   provided.  insert_id_rec returns TRUE if the tree height from
   ROOT down is increased otherwise it returns FALSE.  This is a
   recursive balanced binary tree insertion algorithm. */

int insert_id_rec (id_rec **root, id_rec *new_id)
{
  fprintf(stderr, "[bc/util.c] enter insert_id_rec 1\n");
  id_rec *A, *B;

  /* If root is NULL, this where it is to be inserted. */
  if (*root == NULL)
  {
    fprintf(stderr, "[bc/util.c] enter insert_id_rec 2\n");
    *root = new_id;
    new_id->left = NULL;
    new_id->right = NULL;
    new_id->balance = 0;
    return (TRUE);
    fprintf(stderr, "[bc/util.c] exit insert_id_rec 2\n");
  }

  /* We need to search for a leaf. */
  if (strcmp (new_id->id, (*root)->id) < 0)
  {
    fprintf(stderr, "[bc/util.c] enter insert_id_rec 3\n");
    /* Insert it on the left. */
    if (insert_id_rec (&((*root)->left), new_id))
    {
      fprintf(stderr, "[bc/util.c] enter insert_id_rec 4\n");
      /* The height increased. */
      (*root)->balance --;
      
      switch ((*root)->balance)
      {
        case  0:  /* no height increase. */
          fprintf(stderr, "[bc/util.c] enter insert_id_rec 5\n");
          return (FALSE);
          fprintf(stderr, "[bc/util.c] exit insert_id_rec 5\n");
        case -1:  /* height increase. */
          fprintf(stderr, "[bc/util.c] enter insert_id_rec 6\n");
          return (TRUE);
          fprintf(stderr, "[bc/util.c] exit insert_id_rec 6\n");
        case -2:  /* we need to do a rebalancing act. */
          fprintf(stderr, "[bc/util.c] enter insert_id_rec 7\n");
          A = *root;
          B = (*root)->left;
          if (B->balance <= 0)
          {
            fprintf(stderr, "[bc/util.c] enter insert_id_rec 8\n");
            /* Single Rotate. */
            A->left = B->right;
            B->right = A;
            *root = B;
            A->balance = 0;
            B->balance = 0;
            fprintf(stderr, "[bc/util.c] exit insert_id_rec 8\n");
          }
          else
          {
            fprintf(stderr, "[bc/util.c] enter insert_id_rec 9\n");
            /* Double Rotate. */
            *root = B->right;
            B->right = (*root)->left;
            A->left = (*root)->right;
            (*root)->left = B;
            (*root)->right = A;
            switch ((*root)->balance)
            {
              case -1:
                fprintf(stderr, "[bc/util.c] enter insert_id_rec 10\n");
                A->balance = 1;
                B->balance = 0;
                fprintf(stderr, "[bc/util.c] exit insert_id_rec 10\n");
                break;
              case  0:
                fprintf(stderr, "[bc/util.c] enter insert_id_rec 11\n");
                A->balance = 0;
                B->balance = 0;
                fprintf(stderr, "[bc/util.c] exit insert_id_rec 11\n");
                break;
              case  1:
                fprintf(stderr, "[bc/util.c] enter insert_id_rec 12\n");
                A->balance = 0;
                B->balance = -1;
                fprintf(stderr, "[bc/util.c] exit insert_id_rec 12\n");
                break;
            }
            (*root)->balance = 0;
            fprintf(stderr, "[bc/util.c] exit insert_id_rec 9\n");
          }
          return (FALSE);
          fprintf(stderr, "[bc/util.c] exit insert_id_rec 7\n");
      }     
      fprintf(stderr, "[bc/util.c] exit insert_id_rec 4\n");
    } 
    return (FALSE);
    fprintf(stderr, "[bc/util.c] exit insert_id_rec 3\n");
  }
  else
  {
    fprintf(stderr, "[bc/util.c] enter insert_id_rec 13\n");
    /* Insert it on the right. */
    if (insert_id_rec (&((*root)->right), new_id))
    {
      fprintf(stderr, "[bc/util.c] enter insert_id_rec 14\n");
      /* The height increased. */
      (*root)->balance ++;

      switch ((*root)->balance)
      {
        case 0:  /* no height increase. */
          fprintf(stderr, "[bc/util.c] enter insert_id_rec 15\n");
          return (FALSE);
          fprintf(stderr, "[bc/util.c] exit insert_id_rec 15\n");
        case 1:  /* height increase. */
          fprintf(stderr, "[bc/util.c] enter insert_id_rec 16\n");
          return (TRUE);
          fprintf(stderr, "[bc/util.c] exit insert_id_rec 16\n");
        case 2:  /* we need to do a rebalancing act. */
          fprintf(stderr, "[bc/util.c] enter insert_id_rec 17\n");
          A = *root;
          B = (*root)->right;
          if (B->balance >= 0)
          {
            fprintf(stderr, "[bc/util.c] enter insert_id_rec 18\n");
            /* Single Rotate. */
            A->right = B->left;
            B->left = A;
            *root = B;
            A->balance = 0;
            B->balance = 0;
            fprintf(stderr, "[bc/util.c] exit insert_id_rec 18\n");
          }
          else
          {
            fprintf(stderr, "[bc/util.c] enter insert_id_rec 19\n");
            /* Double Rotate. */
            *root = B->left;
            B->left = (*root)->right;
            A->right = (*root)->left;
            (*root)->left = A;
            (*root)->right = B;
            switch ((*root)->balance)
            {
              case -1:
                fprintf(stderr, "[bc/util.c] enter insert_id_rec 20\n");
                A->balance = 0;
                B->balance = 1;
                fprintf(stderr, "[bc/util.c] exit insert_id_rec 20\n");
                break;
              case  0:
                fprintf(stderr, "[bc/util.c] enter insert_id_rec 21\n");
                A->balance = 0;
                B->balance = 0;
                fprintf(stderr, "[bc/util.c] exit insert_id_rec 21\n");
                break;
              case  1:
                fprintf(stderr, "[bc/util.c] enter insert_id_rec 22\n");
                A->balance = -1;
                B->balance = 0;
                fprintf(stderr, "[bc/util.c] exit insert_id_rec 22\n");
                break;
            }
            (*root)->balance = 0;
            fprintf(stderr, "[bc/util.c] exit insert_id_rec 19\n");
          }
          return (FALSE);
          fprintf(stderr, "[bc/util.c] exit insert_id_rec 17\n");
      }     
      fprintf(stderr, "[bc/util.c] exit insert_id_rec 14\n");
    } 
    return (FALSE);
    fprintf(stderr, "[bc/util.c] exit insert_id_rec 13\n");
  }
  
  /* If we fall through to here, the tree did not grow in height. */
  return (FALSE);
  fprintf(stderr, "[bc/util.c] exit insert_id_rec 1\n");
}


/* Initialize variables for the symbol table tree. */

void
init_tree(void)
{
  fprintf(stderr, "[bc/util.c] enter init_tree 1\n");
  name_tree  = NULL;
  next_array = 1;
  next_func  = 1;
  /* 0 => ibase, 1 => obase, 2 => scale, 3 => history, 4 => last. */
  next_var   = 5;
  fprintf(stderr, "[bc/util.c] exit init_tree 1\n");
}


/* Lookup routines for symbol table names. */

int
lookup (char *name, int  namekind)
{
  fprintf(stderr, "[bc/util.c] enter lookup 1\n");
  id_rec *id;

  /* Warn about non-standard name. */
  if (strlen(name) != 1)
  {
    fprintf(stderr, "[bc/util.c] enter lookup 2\n");
    ct_warn ("multiple letter name - %s", name);
    fprintf(stderr, "[bc/util.c] exit lookup 2\n");
  }

  /* Look for the id. */
  id = find_id (name_tree, name);
  if (id == NULL)
  {
    fprintf(stderr, "[bc/util.c] enter lookup 3\n");
    /* We need to make a new item. */
    id = bc_malloc (sizeof (id_rec));
    id->id = strcopyof (name);
    id->a_name = 0;
    id->f_name = 0;
    id->v_name = 0;
    insert_id_rec (&name_tree, id);
    fprintf(stderr, "[bc/util.c] exit lookup 3\n");
  }

  /* Return the correct value. */
  switch (namekind)
  {
    case ARRAY:
      fprintf(stderr, "[bc/util.c] enter lookup 4\n");
      /* ARRAY variable numbers are returned as negative numbers. */
      if (id->a_name != 0)
      {
        fprintf(stderr, "[bc/util.c] enter lookup 5\n");
        free (name);
        return (-id->a_name);
        fprintf(stderr, "[bc/util.c] exit lookup 5\n");
      }
      id->a_name = next_array++;
      if (id->a_name < MAX_STORE)
      {
        fprintf(stderr, "[bc/util.c] enter lookup 6\n");
        if (id->a_name >= a_count)
        {
          fprintf(stderr, "[bc/util.c] enter lookup 7\n");
          more_arrays ();
          fprintf(stderr, "[bc/util.c] exit lookup 7\n");
        }
        a_names[id->a_name] = name;
        return (-id->a_name);
        fprintf(stderr, "[bc/util.c] exit lookup 6\n");
      }
      yyerror ("Too many array variables");
      bc_exit (1);
      /*NOTREACHED*/
      fprintf(stderr, "[bc/util.c] exit lookup 4\n");

    case FUNCT:
    case FUNCTDEF:
      fprintf(stderr, "[bc/util.c] enter lookup 8\n");
      if (id->f_name != 0)
      {
        fprintf(stderr, "[bc/util.c] enter lookup 9\n");
        free(name);
        /* Check to see if we are redefining a math lib function. */ 
        if (use_math && namekind == FUNCTDEF && id->f_name <= 6)
        {
          fprintf(stderr, "[bc/util.c] enter lookup 10\n");
          id->f_name = next_func++;
          fprintf(stderr, "[bc/util.c] exit lookup 10\n");
        }
        return (id->f_name);
        fprintf(stderr, "[bc/util.c] exit lookup 9\n");
      }
      id->f_name = next_func++;
      if (id->f_name < MAX_STORE)
      {
        fprintf(stderr, "[bc/util.c] enter lookup 11\n");
        if (id->f_name >= f_count)
        {
          fprintf(stderr, "[bc/util.c] enter lookup 12\n");
          more_functions ();
          fprintf(stderr, "[bc/util.c] exit lookup 12\n");
        }
        f_names[id->f_name] = name;
        return (id->f_name);
        fprintf(stderr, "[bc/util.c] exit lookup 11\n");
      }
      yyerror ("Too many functions");
      bc_exit (1);
      /*NOTREACHED*/
      fprintf(stderr, "[bc/util.c] exit lookup 8\n");

    case SIMPLE:
      fprintf(stderr, "[bc/util.c] enter lookup 13\n");
      if (id->v_name != 0)
      {
        fprintf(stderr, "[bc/util.c] enter lookup 14\n");
        free(name);
        return (id->v_name);
        fprintf(stderr, "[bc/util.c] exit lookup 14\n");
      }
      id->v_name = next_var++;
      if (id->v_name <= MAX_STORE)
      {
        fprintf(stderr, "[bc/util.c] enter lookup 15\n");
        if (id->v_name >= v_count)
        {
          fprintf(stderr, "[bc/util.c] enter lookup 16\n");
          more_variables ();
          fprintf(stderr, "[bc/util.c] exit lookup 16\n");
        }
        v_names[id->v_name - 1] = name;
        return (id->v_name);
        fprintf(stderr, "[bc/util.c] exit lookup 15\n");
      }
      yyerror ("Too many variables");
      bc_exit (1);
      /*NOTREACHED*/
      fprintf(stderr, "[bc/util.c] exit lookup 13\n");
  }

  yyerror ("End of util.c/lookup() reached.  Please report this bug.");
  bc_exit (1);
  /*NOTREACHED*/
  return 0;
  fprintf(stderr, "[bc/util.c] exit lookup 1\n");
}

/* Print out the limits of this program. */

void
limits(void)
{
  fprintf(stderr, "[bc/util.c] enter limits 1\n");
  printf ("BC_BASE_MAX     = %d\n",  BC_BASE_MAX);
  printf ("BC_DIM_MAX      = %ld\n", (long) BC_DIM_MAX);
  printf ("BC_SCALE_MAX    = %d\n",  BC_SCALE_MAX);
  printf ("BC_STRING_MAX   = %d\n",  BC_STRING_MAX);
  printf ("MAX Exponent    = %ld\n", (long) LONG_MAX);
  printf ("Number of vars  = %ld\n", (long) MAX_STORE);
#ifdef OLD_EQ_OP
  printf ("Old assignment operatiors are valid. (=-, =+, ...)\n");
#endif 
  fprintf(stderr, "[bc/util.c] exit limits 1\n");
}

/* bc_malloc will check the return value so all other places do not
   have to do it!  SIZE is the number of bytes to allocate. */

void *
bc_malloc (size_t size)
{
  fprintf(stderr, "[bc/util.c] enter bc_malloc 1\n");
  void *ptr;

  ptr = (void *) malloc (size);
  if (ptr == NULL)
  {
    fprintf(stderr, "[bc/util.c] enter bc_malloc 2\n");
    out_of_memory ();
    fprintf(stderr, "[bc/util.c] exit bc_malloc 2\n");
  }

  return ptr;
  fprintf(stderr, "[bc/util.c] exit bc_malloc 1\n");
}


/* The following routines are error routines for various problems. */

/* Malloc could not get enought memory. */

void
out_of_memory(void)
{
  fprintf(stderr, "[bc/util.c] enter out_of_memory 1\n");
  fprintf (stderr, "Fatal error: Out of memory for malloc.\n");
  bc_exit (1);
  /*NOTREACHED*/
  fprintf(stderr, "[bc/util.c] exit out_of_memory 1\n");
}



/* The standard yyerror routine.  Built with variable number of argumnets. */

#ifndef VARARGS
#ifdef __STDC__
void
yyerror (const char *str, ...)
#else
void
yyerror (str)
     const char *str;
#endif
#else
void
yyerror (str, va_alist)
     const char *str;
#endif
{
  fprintf(stderr, "[bc/util.c] enter yyerror 1\n");
  const char *name;
  va_list args;

#ifndef VARARGS   
   va_start (args, str);
#else
   va_start (args);
#endif
  if (is_std_in)
  {
    fprintf(stderr, "[bc/util.c] enter yyerror 2\n");
    name = "(standard_in)";
    fprintf(stderr, "[bc/util.c] exit yyerror 2\n");
  }
  else
  {
    fprintf(stderr, "[bc/util.c] enter yyerror 3\n");
    name = file_name;
    fprintf(stderr, "[bc/util.c] exit yyerror 3\n");
  }
  fprintf (stderr,"%s %d: ",name,line_no);
  vfprintf (stderr, str, args);
  fprintf (stderr, "\n");
  had_error = TRUE;
  va_end (args);
  fprintf(stderr, "[bc/util.c] exit yyerror 1\n");
}


/* The routine to produce warnings about non-standard features
   found during parsing. */

#ifndef VARARGS
#ifdef __STDC__
void 
ct_warn (const char *mesg, ...)
#else
void
ct_warn (mesg)
     const char *mesg;
#endif
#else
void
ct_warn (mesg, va_alist)
     const char *mesg;
#endif
{
  fprintf(stderr, "[bc/util.c] enter ct_warn 1\n");
  const char *name;
  va_list args;

#ifndef VARARGS   
  va_start (args, mesg);
#else
  va_start (args);
#endif
  if (std_only)
  {
    fprintf(stderr, "[bc/util.c] enter ct_warn 2\n");
    if (is_std_in)
    {
      fprintf(stderr, "[bc/util.c] enter ct_warn 3\n");
      name = "(standard_in)";
      fprintf(stderr, "[bc/util.c] exit ct_warn 3\n");
    }
    else
    {
      fprintf(stderr, "[bc/util.c] enter ct_warn 4\n");
      name = file_name;
      fprintf(stderr, "[bc/util.c] exit ct_warn 4\n");
    }
    fprintf (stderr,"%s %d: Error: ",name,line_no);
    vfprintf (stderr, mesg, args);
    fprintf (stderr, "\n");
    had_error = TRUE;
    fprintf(stderr, "[bc/util.c] exit ct_warn 2\n");
  }
  else if (warn_not_std)
  {
    fprintf(stderr, "[bc/util.c] enter ct_warn 5\n");
    if (is_std_in)
    {
      fprintf(stderr, "[bc/util.c] enter ct_warn 6\n");
      name = "(standard_in)";
      fprintf(stderr, "[bc/util.c] exit ct_warn 6\n");
    }
    else
    {
      fprintf(stderr, "[bc/util.c] enter ct_warn 7\n");
      name = file_name;
      fprintf(stderr, "[bc/util.c] exit ct_warn 7\n");
    }
    fprintf (stderr,"%s %d: (Warning) ",name,line_no);
    vfprintf (stderr, mesg, args);
    fprintf (stderr, "\n");
    fprintf(stderr, "[bc/util.c] exit ct_warn 5\n");
  }
  va_end (args);
  fprintf(stderr, "[bc/util.c] exit ct_warn 1\n");
}

/* Runtime error will  print a message and stop the machine. */

#ifndef VARARGS
#ifdef __STDC__
void
rt_error (const char *mesg, ...)
#else
void
rt_error (mesg)
     const char *mesg;
#endif
#else
void
rt_error (mesg, va_alist)
     const char *mesg;
#endif
{
  fprintf(stderr, "[bc/util.c] enter rt_error 1\n");
  va_list args;

  fprintf (stderr, "Runtime error (func=%s, adr=%d): ",
	   f_names[pc.pc_func], pc.pc_addr);
#ifndef VARARGS   
  va_start (args, mesg);
#else
  va_start (args);
#endif
  vfprintf (stderr, mesg, args);
  va_end (args);
  
  fprintf (stderr, "\n");
  runtime_error = TRUE;
  fprintf(stderr, "[bc/util.c] exit rt_error 1\n");
}


/* A runtime warning tells of some action taken by the processor that
   may change the program execution but was not enough of a problem
   to stop the execution. */


#ifndef VARARGS
#ifdef __STDC__
void
rt_warn (const char *mesg, ...)
#else
void
rt_warn (const char *mesg)
#endif
#else
void
rt_warn (const char *mesg)
#endif
{
  fprintf(stderr, "[bc/util.c] enter rt_warn 1\n");
  va_list args;

  fprintf (stderr, "Runtime warning (func=%s, adr=%d): ",
	   f_names[pc.pc_func], pc.pc_addr);
#ifndef VARARGS   
  va_start (args, mesg);
#else
  va_start (args);
#endif
  vfprintf (stderr, mesg, args);
  va_end (args);

  fprintf (stderr, "\n");
  fprintf(stderr, "[bc/util.c] exit rt_warn 1\n");
}

/* bc_exit: Make sure to reset the edit state. */

void bc_exit(int val)
{
  fprintf(stderr, "[bc/util.c] enter bc_exit 1\n");
#if defined(LIBEDIT)
  if (edit != NULL)
  {
    fprintf(stderr, "[bc/util.c] enter bc_exit 2\n");
    el_end(edit);
    fprintf(stderr, "[bc/util.c] exit bc_exit 2\n");
  }
#endif
  exit(val);
  fprintf(stderr, "[bc/util.c] exit bc_exit 1\n");
  /*NOTREACHED*/
}

// Total cost: 0.223548
// Total split cost: 0.033975, input tokens: 10935, output tokens: 78. Split chunks: [(0, 799), (799, 838)]
// Total instrumented cost: 0.189573, input tokens: 10876, output tokens: 10463

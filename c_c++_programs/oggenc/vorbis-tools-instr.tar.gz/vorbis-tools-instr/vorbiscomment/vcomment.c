/* This program is licensed under the GNU General Public License,
 * version 2, a copy of which is included with this program.
 *
 * (c) 2000-2002 Michael Smith <msmith@xiph.org>
 * (c) 2001      Ralph Giles <giles@xiph.org>
 * (c) 2017-2020 Philipp Schafft <phschafft@de.loewenfelsen.net>
 *
 * Front end to show how to use vcedit;
 * Of limited usability on its own, but could be useful.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <locale.h>

#if HAVE_STAT && HAVE_CHMOD
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#endif

#include "getopt.h"
#include "utf8.h"
#include "i18n.h"

#include "vcedit.h"


/* getopt format struct */
static const struct option long_options[] = {
    {"list",        no_argument,        0, 'l'},
    {"append",      no_argument,        0, 'a'},
    {"tag",         required_argument,  0, 't'},
    {"rm",          required_argument,  0, 'd'},
    {"write",       no_argument,        0, 'w'},
    {"help",        no_argument,        0, 'h'},
    {"quiet",       no_argument,        0, 'q'},  /* unused */
    {"version",     no_argument,        0, 'V'},
    {"commentfile", required_argument,  0, 'c'},
    {"raw",         no_argument,        0, 'R'},
    {"escapes",     no_argument,        0, 'e'},
    {NULL, 0, 0, 0}
};

/* local parameter storage from parsed options */
typedef struct {
    /* mode and flags */
    int mode;
    int raw;
    int escapes;

    /* file names and handles */
    char    *infilename, *outfilename;
    char    *commentfilename;
    FILE    *in, *out, *com;
    int tempoutfile;

    /* comments */
    int commentcount;
    char    **comments;
    int     *changetypes;
} param_t;

#define MODE_NONE  0
#define MODE_LIST  1
#define MODE_WRITE 2
#define MODE_APPEND 3

#define CHANGETYPE_ADD 0
#define CHANGETYPE_REMOVE 1

/* prototypes */
void usage(void);
void print_comments(FILE *out, vorbis_comment *vc, int raw, int escapes);
int  alter_comment(char *line, vorbis_comment *vc, int raw, int escapes, int changetype);

char *escape(const char *from, int fromsize);
char *unescape(const char *from, int *tosize);

param_t *new_param(void);
void free_param(param_t *param);
void parse_options(int argc, char *argv[], param_t *param);
void open_files(param_t *p);
void close_files(param_t *p, int output_written);

static void _vorbis_comment_rm_tag(vorbis_comment *vc, const char *tag, const char *contents);

char * read_line (FILE *input)
{
    fprintf(stderr, "[vorbiscomment/vcomment.c] enter read_line 1\n");
    /* Construct a list of buffers. Each buffer will hold 1024 bytes. If
     * more is required, it is easier to extend the list than to extend
     * a massive buffer. When all the bytes up to a newline have been
     * retrieved, join the buffers together
    **/
    int buffer_count = 0, max_buffer_count = 10, buffer_size = 1024;
    int ii;
    char **buffers = 0, *buffer;

    /* Start with room for 10 buffers */
    buffers = malloc (sizeof (char *) * max_buffer_count);
    fprintf(stderr, "[vorbiscomment/vcomment.c] exit read_line 1\n");

    while (1)
    {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter read_line 2\n");
        char *retval;

        /* Increase the max buffer count in increments of 10 */
        if (buffer_count == max_buffer_count)
        {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter read_line 3\n");
            max_buffer_count = buffer_count + 10;
            buffers = realloc (buffers, sizeof (char *) * max_buffer_count);
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit read_line 3\n");
        }

        buffer = malloc (sizeof (char) * (buffer_size + 1));
        retval = fgets (buffer, (buffer_size + 1), input);

        if (retval)
        {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter read_line 4\n");
            buffers[buffer_count] = buffer;
            buffer_count++;

            if (retval[strlen (retval) - 1] == '\n')
            {
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter read_line 5\n");
                /* End of the line */
                break;
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit read_line 5\n");
            }
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit read_line 4\n");
        }
        else
        {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter read_line 6\n");
            /* End of the file */
            free (buffer);
            break;
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit read_line 6\n");
        }
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit read_line 2\n");
    }

    if (buffer_count == 0)
    {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter read_line 7\n");
        /* No more data to read */
        free (buffers);
        return 0;
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit read_line 7\n");
    }

    fprintf(stderr, "[vorbiscomment/vcomment.c] enter read_line 8\n");
    /* Create one giant buffer to contain all the retrieved text */
    buffer = malloc (sizeof (char) * (buffer_count * (buffer_size + 1)));

    /* Copy buffer data and free memory */
    for (ii = 0; ii < buffer_count; ii++)
    {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter read_line 9\n");
        strncpy (buffer + (ii * buffer_size), buffers[ii], buffer_size);
        free (buffers[ii]);
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit read_line 9\n");
    }

    free (buffers);
    buffer[buffer_count * (buffer_size + 1) - 1] = 0;
    return buffer;
    fprintf(stderr, "[vorbiscomment/vcomment.c] exit read_line 8\n");
}

/**********

   Delete a comment from the comment list.

   This deletes a comment from the list.
   We implement this here as libvorbis does not provide it.
   Also this is very inefficent as we need to copy the compelet structure.
   But it is only called once for each file and each deleted key so that is
   not much of a problem.

***********/

static void _vorbis_comment_rm_tag(vorbis_comment *vc, const char *tag, const char *contents)
{
    fprintf(stderr, "[vorbiscomment/vcomment.c] enter _vorbis_comment_rm_tag 1\n");
    vorbis_comment vc_tmp;
    size_t taglen;
    int i;
    const char *p;
    int match;

    taglen = strlen(tag);

    vorbis_comment_init(&vc_tmp);
    fprintf(stderr, "[vorbiscomment/vcomment.c] exit _vorbis_comment_rm_tag 1\n");

    for (i = 0; i < vc->comments; i++)
    {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter _vorbis_comment_rm_tag 2\n");
        p = vc->user_comments[i];
        match = 0;

        do {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter _vorbis_comment_rm_tag 3\n");
            if (strncasecmp(p, tag, taglen) != 0) {
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter _vorbis_comment_rm_tag 4\n");
                break;
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit _vorbis_comment_rm_tag 4\n");
            }
            p += taglen;
            if (*p != '=') {
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter _vorbis_comment_rm_tag 5\n");
                break;
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit _vorbis_comment_rm_tag 5\n");
            }
            p++;
            if (contents) {
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter _vorbis_comment_rm_tag 6\n");
                if (strcmp(p, contents) != 0) {
                    fprintf(stderr, "[vorbiscomment/vcomment.c] enter _vorbis_comment_rm_tag 7\n");
                    break;
                    fprintf(stderr, "[vorbiscomment/vcomment.c] exit _vorbis_comment_rm_tag 7\n");
                }
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit _vorbis_comment_rm_tag 6\n");
            }

            match = 1;
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit _vorbis_comment_rm_tag 3\n");
        } while (0);

        if (!match) {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter _vorbis_comment_rm_tag 8\n");
            vorbis_comment_add(&vc_tmp, vc->user_comments[i]);
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit _vorbis_comment_rm_tag 8\n");
        }
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit _vorbis_comment_rm_tag 2\n");
    }

    fprintf(stderr, "[vorbiscomment/vcomment.c] enter _vorbis_comment_rm_tag 9\n");
    vorbis_comment_clear(vc);

    *vc = vc_tmp;
    fprintf(stderr, "[vorbiscomment/vcomment.c] exit _vorbis_comment_rm_tag 9\n");
}

/**********
   main.c

   This is the main function where options are read and written
   you should be able to just read this function and see how
   to call the vcedit routines. Details of how to pack/unpack the
   vorbis_comment structure itself are in the following two routines.
   The rest of the file is ui dressing so make the program minimally
   useful as a command line utility and can generally be ignored.

***********/

int main(int argc, char **argv)
{
    fprintf(stderr, "[vorbiscomment/vcomment.c] enter main 1\n");
    vcedit_state *state;
    vorbis_comment *vc;
    param_t *param;
    int i;

    setlocale(LC_ALL, "");
    bindtextdomain(PACKAGE, LOCALEDIR);
    textdomain(PACKAGE);

    /* initialize the cmdline interface */
    param = new_param();
    parse_options(argc, argv, param);

    /* take care of opening the requested files */
    /* relevent file pointers are returned in the param struct */
    open_files(param);
    fprintf(stderr, "[vorbiscomment/vcomment.c] exit main 1\n");

    /* which mode are we in? */

    if (param->mode == MODE_LIST) {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter main 2\n");
        state = vcedit_new_state();

        if (vcedit_open(state, param->in) < 0)
        {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter main 3\n");
            fprintf(stderr, _("Failed to open file as Vorbis: %s\n"),
                    vcedit_error(state));
            close_files(param, 0);
            free_param(param);
            vcedit_clear(state);
            convert_free_charset();
            return 1;
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit main 3\n");
        }

        /* extract and display the comments */
        vc = vcedit_comments(state);
        print_comments(param->com, vc, param->raw, param->escapes);

        /* done */
        vcedit_clear(state);

        close_files(param, 0);
        free_param(param);
        convert_free_charset();
        return 0;
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit main 2\n");
    }

    if (param->mode == MODE_WRITE || param->mode == MODE_APPEND) {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter main 4\n");
        state = vcedit_new_state();

        if (vcedit_open(state, param->in) < 0)
        {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter main 5\n");
            fprintf(stderr, _("Failed to open file as Vorbis: %s\n"),
                    vcedit_error(state));
            close_files(param, 0);
            free_param(param);
            vcedit_clear(state);
            convert_free_charset();
            return 1;
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit main 5\n");
        }

        /* grab and clear the exisiting comments */
        vc = vcedit_comments(state);
        if (param->mode != MODE_APPEND)
        {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter main 6\n");
            vorbis_comment_clear(vc);
            vorbis_comment_init(vc);
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit main 6\n");
        }

        for (i=0; i < param->commentcount; i++)
        {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter main 7\n");
            if (alter_comment(param->comments[i], vc,
                    param->raw, param->escapes, param->changetypes[i]) < 0) {
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter main 8\n");
                fprintf(stderr, _("Bad comment: \"%s\"\n"), param->comments[i]);
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit main 8\n");
            }
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit main 7\n");
        }

        /* build the replacement structure */
        if (param->commentcount==0) {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter main 9\n");
            char *comment;

            while ((comment = read_line (param->com))) {
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter main 10\n");
                if (alter_comment(comment, vc, param->raw, param->escapes, CHANGETYPE_ADD) < 0) {
                    fprintf(stderr, "[vorbiscomment/vcomment.c] enter main 11\n");
                    fprintf (stderr, _("bad comment: \"%s\"\n"),
                            comment);
                    fprintf(stderr, "[vorbiscomment/vcomment.c] exit main 11\n");
                }
                free (comment);
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit main 10\n");
            }
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit main 9\n");
        }

        /* write out the modified stream */
        if (vcedit_write(state, param->out) < 0) {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter main 12\n");
            fprintf(stderr, _("Failed to write comments to output file: %s\n"),
                    vcedit_error(state));
            close_files(param, 0);
            free_param(param);
            vcedit_clear(state);
            convert_free_charset();
            return 1;
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit main 12\n");
        }

        /* done */
        vcedit_clear(state);

        close_files(param, 1);
        free_param(param);
        convert_free_charset();
        return 0;
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit main 4\n");
    }

    /* should never reach this point */
    fprintf(stderr, "[vorbiscomment/vcomment.c] enter main 13\n");
    fprintf(stderr, _("no action specified\n"));
    free_param(param);
    param = NULL;
    convert_free_charset();
    return 1;
    fprintf(stderr, "[vorbiscomment/vcomment.c] exit main 13\n");
}

/**********

   Print out the comments from the vorbis structure

   this version just dumps the raw strings
   a more elegant version would use vorbis_comment_query()

***********/

void print_comments(FILE *out, vorbis_comment *vc, int raw, int escapes)
{
    fprintf(stderr, "[vorbiscomment/vcomment.c] enter print_comments 1\n");
    int i;
    char *escaped_value, *decoded_value;

    for (i = 0; i < vc->comments; i++) {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter print_comments 2\n");
        if (escapes) {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter print_comments 3\n");
            escaped_value = escape(vc->user_comments[i], vc->comment_lengths[i]);
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit print_comments 3\n");
        } else {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter print_comments 4\n");
            escaped_value = vc->user_comments[i];
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit print_comments 4\n");
        }

        if (!raw && utf8_decode(escaped_value, &decoded_value) >= 0) {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter print_comments 5\n");
            fprintf(out, "%s\n", decoded_value);
            free(decoded_value);
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit print_comments 5\n");
        } else {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter print_comments 6\n");
            fprintf(out, "%s\n", escaped_value);
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit print_comments 6\n");
        }

        if (escapes) {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter print_comments 7\n");
            free(escaped_value);
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit print_comments 7\n");
        }
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit print_comments 2\n");
    }
    fprintf(stderr, "[vorbiscomment/vcomment.c] exit print_comments 1\n");
}

/**********

   Take a line of the form "TAG=value string", parse it, convert the
   value to UTF-8, and add or remove it from vc comment block.
   Error checking is performed (return 0 if OK, negative on error).

   Note that this assumes a null-terminated string, which may cause
   problems with > 8-bit character sets!

***********/

int  alter_comment(char *line, vorbis_comment *vc, int raw, int escapes, int changetype)
{
    fprintf(stderr, "[vorbiscomment/vcomment.c] enter alter_comment 1\n");
    char *mark, *value, *utf8_value, *unescaped_value;
    int unescaped_len;
    int allow_empty = 0;
    int is_empty = 0;

    if (changetype != CHANGETYPE_ADD &&
        changetype != CHANGETYPE_REMOVE) {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter alter_comment 2\n");
        return -1;
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit alter_comment 2\n");
    }

    if (changetype == CHANGETYPE_REMOVE) {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter alter_comment 3\n");
        allow_empty = 1;
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit alter_comment 3\n");
    }

    /* strip any terminal newline */
    {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter alter_comment 4\n");
        int len = strlen(line);
        if (line[len-1] == '\n') line[len-1] = '\0';
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit alter_comment 4\n");
    }

    /* validation: basically, we assume it's a tag
     * if if has an '=' after valid tag characters,
     * or if it just contains valid tag characters
     * and we're allowing empty values. */

    mark = strchr(line, '=');
    if (mark == NULL) {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter alter_comment 5\n");
        if (allow_empty) {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter alter_comment 6\n");
            mark = line + strlen(line);
            is_empty = 1;
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit alter_comment 6\n");
        } else {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter alter_comment 7\n");
            return -1;
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit alter_comment 7\n");
        }
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit alter_comment 5\n");
    }

    value = line;
    while (value < mark) {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter alter_comment 8\n");
        if (*value < 0x20 || *value > 0x7d || *value == 0x3d) {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter alter_comment 9\n");
            return -1;
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit alter_comment 9\n");
        }
        value++;
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit alter_comment 8\n");
    }

    if (is_empty) {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter alter_comment 10\n");
        unescaped_value = NULL;
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit alter_comment 10\n");
    } else {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter alter_comment 11\n");
        /* split the line by turning the '=' in to a null */
        *mark = '\0';
        value++;

        if (raw) {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter alter_comment 12\n");
            if (!utf8_validate(value)) {
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter alter_comment 13\n");
                fprintf(stderr, _("'%s' is not valid UTF-8, cannot add\n"), line);
                return -1;
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit alter_comment 13\n");
            }
            utf8_value = value;
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit alter_comment 12\n");
        } else {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter alter_comment 14\n");
            /* convert the value from the native charset to UTF-8 */
            if (utf8_encode(value, &utf8_value) < 0) {
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter alter_comment 15\n");
                fprintf(stderr,
                        _("Couldn't convert comment to UTF-8, cannot add\n"));
                return -1;
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit alter_comment 15\n");
            }
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit alter_comment 14\n");
        }

        if (escapes) {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter alter_comment 16\n");
            unescaped_value = unescape(utf8_value, &unescaped_len);
            /*
              NOTE: unescaped_len remains unused; to write comments with embeded
              \0's one would need to access the vc struct directly -- see
              vorbis_comment_add() in vorbis/lib/info.c for details, but use mem*
              instead of str*...
            */
            if (unescaped_value == NULL) {
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter alter_comment 17\n");
                fprintf(stderr,
                        _("Couldn't un-escape comment, cannot add\n"));
                if (!raw)
                    free(utf8_value);
                return -1;
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit alter_comment 17\n");
            }
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit alter_comment 16\n");
        } else {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter alter_comment 18\n");
            unescaped_value = utf8_value;
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit alter_comment 18\n");
        }
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit alter_comment 11\n");
    }

    /* append or delete the comment and return */
    switch (changetype) {
    case CHANGETYPE_ADD:
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter alter_comment 19\n");
        vorbis_comment_add_tag(vc, line, unescaped_value);
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit alter_comment 19\n");
        break;
    case CHANGETYPE_REMOVE:
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter alter_comment 20\n");
        _vorbis_comment_rm_tag(vc, line, unescaped_value);
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit alter_comment 20\n");
        break;
    }

    if (escapes) {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter alter_comment 21\n");
        free(unescaped_value);
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit alter_comment 21\n");
    }
    if (!raw && !is_empty) {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter alter_comment 22\n");
        free(utf8_value);
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit alter_comment 22\n");
    }
    return 0;
    fprintf(stderr, "[vorbiscomment/vcomment.c] exit alter_comment 1\n");
}


/*** Escaping routines. ***/

/**********

   Convert raw comment content to a safely escaped single-line 0-terminated
   string.  The raw comment can contain null bytes and thus requires an
   explicit size argument.  The size argument doesn't include a trailing '\0'
   (the vorbis bitstream doesn't use one).

   Returns the address of a newly allocated string - caller is responsible to
   free it.

***********/

char *escape(const char *from, int fromsize)
{
    fprintf(stderr, "\n");
    /* worst-case allocation, will be trimmed when done */
    char *to = malloc(fromsize * 2 + 1);

    char *s;
    for (s = to; fromsize > 0; fromsize--, from++) {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter escape 2\n");
        switch (*from) {
        case '\n':
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter escape 3\n");
            *s++ = '\\';
            *s++ = 'n';
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit escape 3\n");
            break;
        case '\r':
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter escape 4\n");
            *s++ = '\\';
            *s++ = 'r';
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit escape 4\n");
            break;
        case '\0':
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter escape 5\n");
            *s++ = '\\';
            *s++ = '0';
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit escape 5\n");
            break;
        case '\\':
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter escape 6\n");
            *s++ = '\\';
            *s++ = '\\';
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit escape 6\n");
            break;
        default:
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter escape 7\n");
            /* normal character */
            *s++ = *from;
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit escape 7\n");
            break;
        }
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit escape 2\n");
    }

    fprintf(stderr, "[vorbiscomment/vcomment.c] enter escape 8\n");
    *s++ = '\0';
    to = realloc(to, s - to);   /* free unused space */
    return to;
    fprintf(stderr, "[vorbiscomment/vcomment.c] exit escape 8\n");
}

/**********

   Convert a safely escaped 0-terminated string to raw comment content.  The
   result can contain null bytes, so the the result's length is written into
   *tosize.  This size doesn't include a trailing '\0' (the vorbis bitstream
   doesn't use one) but we do append it for convenience since
   vorbis_comment_add[_tag]() has a null-terminated interface.

   Returns the address of a newly allocated string - caller is responsible to
   free it.  Returns NULL in case of error (if the input is mal-formed).

***********/

char *unescape(const char *from, int *tosize)
{
    fprintf(stderr, "\n");
    /* worst-case allocation, will be trimmed when done */
    char *to = malloc(strlen(from) + 1);

    char *s;
    for (s = to; *from != '\0'; ) {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter unescape 2\n");
        if (*from == '\\') {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter unescape 3\n");
            from++;
            switch (*from++) {
            case 'n':
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter unescape 4\n");
                *s++ = '\n';
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit unescape 4\n");
                break;
            case 'r':
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter unescape 5\n");
                *s++ = '\r';
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit unescape 5\n");
                break;
            case '0':
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter unescape 6\n");
                *s++ = '\0';
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit unescape 6\n");
                break;
            case '\\':
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter unescape 7\n");
                *s++ = '\\';
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit unescape 7\n");
                break;
            case '\0':
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter unescape 8\n");
                /* A backslash as the last character of the string is an error. */
                /* FALL-THROUGH */
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit unescape 8\n");
            default:
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter unescape 9\n");
                /* We consider any unrecognized escape as an error.  This is
                   good in general and reserves them for future expansion. */
                free(to);
                return NULL;
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit unescape 9\n");
            }
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit unescape 3\n");
        } else {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter unescape 10\n");
            /* normal character */
            *s++ = *from++;
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit unescape 10\n");
        }
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit unescape 2\n");
    }

    fprintf(stderr, "[vorbiscomment/vcomment.c] enter unescape 11\n");
    *tosize = s - to;           /* excluding '\0' */

    *s++ = '\0';
    to = realloc(to, s - to);   /* free unused space */
    return to;
    fprintf(stderr, "[vorbiscomment/vcomment.c] exit unescape 11\n");
}


/*** ui-specific routines ***/

/**********

   Print out to usage summary for the cmdline interface (ui)

***********/

/* XXX: -q is unused
  printf (_("  -q, --quiet             Don't display comments while editing\n"));
*/

void usage(void)
{
    fprintf(stderr, "[vorbiscomment/vcomment.c] enter usage 1\n");
    printf (_("vorbiscomment from %s %s\n"
            " by the Xiph.Org Foundation (http://www.xiph.org/)\n\n"), PACKAGE, VERSION);

    printf (_("List or edit comments in Ogg Vorbis files.\n"));
    printf ("\n");

    printf (_("Usage: \n"
        "  vorbiscomment [-Vh]\n"
        "  vorbiscomment [-lRe] inputfile\n"
        "  vorbiscomment <-a|-w> [-Re] [-c file] [-t tag] inputfile [outputfile]\n"));
    printf ("\n");

    printf (_("Listing options\n"));
    printf (_("  -l, --list              List the comments (default if no options are given)\n"));
    printf ("\n");

    printf (_("Editing options\n"));
    printf (_("  -a, --append            Update comments\n"));
    printf (_("  -t \"name=value\", --tag \"name=value\"\n"
            "                          Specify a comment tag on the commandline\n"));
    printf (_("  -d \"name[=value]\", --rm \"name[=value]\"\n"
            "                          Specify a comment tag on the commandline to remove\n"
            "                          If no value is given all tags with that name are removed\n"
            "                          This implies -a,\n"));
    printf (_("  -w, --write             Write comments, replacing the existing ones\n"));
    printf ("\n");

    printf (_("Miscellaneous options\n"));
    printf (_("  -c file, --commentfile file\n"
            "                          When listing, write comments to the specified file.\n"
            "                          When editing, read comments from the specified file.\n"));
    printf (_("  -R, --raw               Read and write comments in UTF-8\n"));
    printf (_("  -e, --escapes           Use \\n-style escapes to allow multiline comments.\n"));
    printf ("\n");

    printf (_("  -h, --help              Display this help\n"));
    printf (_("  -V, --version           Output version information and exit\n"));
    printf ("\n");

    printf (_("If no output file is specified, vorbiscomment will modify the input file. This\n"
            "is handled via temporary file, such that the input file is not modified if any\n"
            "errors are encountered during processing.\n"));
    printf ("\n");

    printf (_("vorbiscomment handles comments in the format \"name=value\", one per line. By\n"
            "default, comments are written to stdout when listing, and read from stdin when\n"
            "editing. Alternatively, a file can be specified with the -c option, or tags\n"
            "can be given on the commandline with -t \"name=value\". Use of either -c or -t\n"
            "disables reading from stdin.\n"));
    printf ("\n");

    printf (_("Examples:\n"
            "  vorbiscomment -a in.ogg -c comments.txt\n"
            "  vorbiscomment -a in.ogg -t \"ARTIST=Some Guy\" -t \"TITLE=A Title\"\n"));
    printf ("\n");

    printf (_("NOTE: Raw mode (--raw, -R) will read and write comments in UTF-8 rather than\n"
        "converting to the user's character set, which is useful in scripts. However,\n"
        "this is not sufficient for general round-tripping of comments in all cases,\n"
        "since comments can contain newlines. To handle that, use escaping (-e,\n"
        "--escape).\n"));
    fprintf(stderr, "[vorbiscomment/vcomment.c] exit usage 1\n");
}

void free_param(param_t *param)
{
    fprintf(stderr, "[vorbiscomment/vcomment.c] enter free_param 1\n");
    free(param->infilename);
    param->infilename = NULL;
    free(param->outfilename);
    param->outfilename = NULL;
    free(param->commentfilename);
    param->commentfilename = NULL;

    for (int i=0;i<param->commentcount;i++) {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter free_param 2\n");
        free(param->comments[i]);
        param->comments[i] = NULL;
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit free_param 2\n");
    }
    free(param->comments);
    param->comments = NULL;
    free(param->changetypes);
    param->changetypes = NULL;
    param->commentcount=0;

    free(param);
    fprintf(stderr, "[vorbiscomment/vcomment.c] exit free_param 1\n");
}

/**********

   allocate and initialize a the parameter struct

***********/

param_t *new_param(void)
{
    fprintf(stderr, "[vorbiscomment/vcomment.c] enter new_param 1\n");
    param_t *param = (param_t *)malloc(sizeof(param_t));

    /* mode and flags */
    param->mode = MODE_LIST;
    param->raw = 0;
    param->escapes = 0;

    /* filenames */
    param->infilename  = NULL;
    param->outfilename = NULL;
    param->commentfilename = strdup("-");   /* default, must be free()'d */

    /* file pointers */
    param->in = param->out = NULL;
    param->com = NULL;
    param->tempoutfile=0;

    /* comments */
    param->commentcount=0;
    param->comments=NULL;
    param->changetypes=NULL;

    return param;
    fprintf(stderr, "[vorbiscomment/vcomment.c] exit new_param 1\n");
}

/**********
   parse_options()

   This function takes care of parsing the command line options
   with getopt() and fills out the param struct with the mode,
   flags, and filenames.

***********/
void parse_options(int argc, char *argv[], param_t *param)
{
    fprintf(stderr, "[vorbiscomment/vcomment.c] enter parse_options 1\n");
    int ret;
    int option_index = 1;

    setlocale(LC_ALL, "");
    fprintf(stderr, "[vorbiscomment/vcomment.c] exit parse_options 1\n");

    while ((ret = getopt_long(argc, argv, "alwhqVc:t:d:Re",
            long_options, &option_index)) != -1) {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter parse_options 2\n");
        switch (ret) {
            case 0:
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter parse_options 3\n");
                fprintf(stderr, _("Internal error parsing command options\n"));
                exit(1);
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit parse_options 3\n");
                break;
            case 'l':
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter parse_options 4\n");
                param->mode = MODE_LIST;
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit parse_options 4\n");
                break;
            case 'R':
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter parse_options 5\n");
                param->raw = 1;
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit parse_options 5\n");
                break;
            case 'e':
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter parse_options 6\n");
                param->escapes = 1;
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit parse_options 6\n");
                break;
            case 'w':
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter parse_options 7\n");
                param->mode = MODE_WRITE;
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit parse_options 7\n");
                break;
            case 'a':
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter parse_options 8\n");
                param->mode = MODE_APPEND;
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit parse_options 8\n");
                break;
            case 'V':
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter parse_options 9\n");
                fprintf(stderr, _("vorbiscomment from vorbis-tools " VERSION "\n"));
                exit(0);
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit parse_options 9\n");
                break;
            case 'h':
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter parse_options 10\n");
                usage();
                exit(0);
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit parse_options 10\n");
                break;
            case 'q':
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter parse_options 11\n");
                /* set quiet flag: unused */
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit parse_options 11\n");
                break;
            case 'c':
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter parse_options 12\n");
                free(param->commentfilename);
                param->commentfilename = strdup(optarg);
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit parse_options 12\n");
                break;
            case 't':
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter parse_options 13\n");
                param->comments = realloc(param->comments,
                        (param->commentcount+1)*sizeof(char *));
                param->changetypes = realloc(param->changetypes,
                        (param->commentcount+1)*sizeof(int));
                param->comments[param->commentcount] = strdup(optarg);
                param->changetypes[param->commentcount] = CHANGETYPE_ADD;
                param->commentcount++;
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit parse_options 13\n");
                break;
            case 'd':
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter parse_options 14\n");
                param->comments = realloc(param->comments,
                        (param->commentcount+1)*sizeof(char *));
                param->changetypes = realloc(param->changetypes,
                        (param->commentcount+1)*sizeof(int));
                param->comments[param->commentcount] = strdup(optarg);
                param->changetypes[param->commentcount] = CHANGETYPE_REMOVE;
                param->commentcount++;
                param->mode = MODE_APPEND;
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit parse_options 14\n");
                break;
            default:
                fprintf(stderr, "[vorbiscomment/vcomment.c] enter parse_options 15\n");
                usage();
                exit(1);
                fprintf(stderr, "[vorbiscomment/vcomment.c] exit parse_options 15\n");
        }
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit parse_options 2\n");
    }

    fprintf(stderr, "[vorbiscomment/vcomment.c] enter parse_options 16\n");
    /* remaining bits must be the filenames */
    if ((param->mode == MODE_LIST && (argc-optind) != 1) ||
       ((param->mode == MODE_WRITE || param->mode == MODE_APPEND) &&
       ((argc-optind) < 1 || (argc-optind) > 2))) {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter parse_options 17\n");
            usage();
            exit(1);
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit parse_options 17\n");
    }

    param->infilename = strdup(argv[optind]);
    if (param->mode == MODE_WRITE || param->mode == MODE_APPEND) {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter parse_options 18\n");
        if (argc-optind == 1)
        {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter parse_options 19\n");
            param->tempoutfile = 1;
            param->outfilename = malloc(strlen(param->infilename)+8);
            strcpy(param->outfilename, param->infilename);
            strcat(param->outfilename, ".vctemp");
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit parse_options 19\n");
        } else {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter parse_options 20\n");
            param->outfilename = strdup(argv[optind+1]);
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit parse_options 20\n");
        }
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit parse_options 18\n");
    }
    fprintf(stderr, "[vorbiscomment/vcomment.c] exit parse_options 16\n");
}

/**********
   open_files()

   This function takes care of opening the appropriate files
   based on the mode and filenames in the param structure.
   A filename of '-' is interpreted as stdin/out.

   The idea is just to hide the tedious checking so main()
   is easier to follow as an example.

***********/

void open_files(param_t *p)
{
    fprintf(stderr, "[vorbiscomment/vcomment.c] enter open_files 1\n");
    /* for all modes, open the input file */

    if (strncmp(p->infilename,"-",2) == 0) {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter open_files 2\n");
        p->in = stdin;
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit open_files 2\n");
    } else {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter open_files 3\n");
        p->in = fopen(p->infilename, "rb");
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit open_files 3\n");
    }
    if (p->in == NULL) {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter open_files 4\n");
        fprintf(stderr,
            _("Error opening input file '%s'.\n"),
            p->infilename);
        exit(1);
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit open_files 4\n");
    }

    if (p->mode == MODE_WRITE || p->mode == MODE_APPEND) {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter open_files 5\n");

        /* open output for write mode */
        if (!strcmp(p->infilename, p->outfilename)) {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter open_files 6\n");
            fprintf(stderr, _("Input filename may not be the same as output filename\n"));
            exit(1);
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit open_files 6\n");
        }

        if (strncmp(p->outfilename,"-",2) == 0) {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter open_files 7\n");
            p->out = stdout;
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit open_files 7\n");
        } else {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter open_files 8\n");
            p->out = fopen(p->outfilename, "wb");
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit open_files 8\n");
        }
        if (p->out == NULL) {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter open_files 9\n");
            fprintf(stderr,
                _("Error opening output file '%s'.\n"),
                p->outfilename);
            exit(1);
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit open_files 9\n");
        }

        /* commentfile is input */

        if ((p->commentfilename == NULL) ||
                (strncmp(p->commentfilename,"-",2) == 0)) {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter open_files 10\n");
            p->com = stdin;
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit open_files 10\n");
        } else {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter open_files 11\n");
            p->com = fopen(p->commentfilename, "r");
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit open_files 11\n");
        }
        if (p->com == NULL) {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter open_files 12\n");
            fprintf(stderr,
                _("Error opening comment file '%s'.\n"),
                p->commentfilename);
            exit(1);
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit open_files 12\n");
        }
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit open_files 5\n");

    } else {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter open_files 13\n");

        /* in list mode, commentfile is output */

        if ((p->commentfilename == NULL) ||
                (strncmp(p->commentfilename,"-",2) == 0)) {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter open_files 14\n");
            p->com = stdout;
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit open_files 14\n");
        } else {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter open_files 15\n");
            p->com = fopen(p->commentfilename, "w");
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit open_files 15\n");
        }
        if (p->com == NULL) {
            fprintf(stderr, "[vorbiscomment/vcomment.c] enter open_files 16\n");
            fprintf(stderr,
                _("Error opening comment file '%s'\n"),
                p->commentfilename);
            exit(1);
            fprintf(stderr, "[vorbiscomment/vcomment.c] exit open_files 16\n");
        }
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit open_files 13\n");
    }

    /* all done */
    fprintf(stderr, "[vorbiscomment/vcomment.c] exit open_files 1\n");
}

/**********
   close_files()

   Do some quick clean-up.

***********/

void close_files(param_t *p, int output_written)
{
  fprintf(stderr, "[vorbiscomment/vcomment.c] enter close_files 1\n");
  if (p->in != NULL && p->in != stdin) fclose(p->in);
  if (p->out != NULL && p->out != stdout) fclose(p->out);
  if (p->com != NULL && p->com != stdout && p->com != stdin) fclose(p->com);

  if (p->tempoutfile) {
    fprintf(stderr, "[vorbiscomment/vcomment.c] enter close_files 2\n");
#if HAVE_STAT && HAVE_CHMOD
    struct stat st;
    stat (p->infilename, &st);
#endif

    if (output_written) {
      fprintf(stderr, "[vorbiscomment/vcomment.c] enter close_files 3\n");
      /* Some platforms fail to rename a file if the new name already
       * exists, so we need to remove, then rename. How stupid.
       */
      if (rename(p->outfilename, p->infilename)) {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter close_files 4\n");
        if (remove(p->infilename))
          fprintf(stderr, _("Error removing old file %s\n"), p->infilename);
        else if (rename(p->outfilename, p->infilename))
          fprintf(stderr, _("Error renaming %s to %s\n"), p->outfilename,
                  p->infilename);
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit close_files 4\n");
      } else {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter close_files 5\n");
#if HAVE_STAT && HAVE_CHMOD
        chmod (p->infilename, st.st_mode);
#endif
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit close_files 5\n");
      }
      fprintf(stderr, "[vorbiscomment/vcomment.c] exit close_files 3\n");
    } else {
      fprintf(stderr, "[vorbiscomment/vcomment.c] enter close_files 6\n");
      if (remove(p->outfilename)) {
        fprintf(stderr, "[vorbiscomment/vcomment.c] enter close_files 7\n");
        fprintf(stderr, _("Error removing erroneous temporary file %s\n"),
                    p->outfilename);
        fprintf(stderr, "[vorbiscomment/vcomment.c] exit close_files 7\n");
      }
      fprintf(stderr, "[vorbiscomment/vcomment.c] exit close_files 6\n");
    }
    fprintf(stderr, "[vorbiscomment/vcomment.c] exit close_files 2\n");
  }
  fprintf(stderr, "[vorbiscomment/vcomment.c] exit close_files 1\n");
}
// Total cost: 0.493413
// Total split cost: 0.231840, input tokens: 74862, output tokens: 1001, cache read tokens: 16680, cache write tokens: 9940, split chunks: [(0, 749), (749, 966)]
// Total instrumented cost: 0.261573, input tokens: 13088, output tokens: 12531, cache read tokens: 2280, cache write tokens: 10800

typedef struct vcedit_page_buffer {
    char *data;
    size_t data_len;
} vcedit_page_buffer;

typedef struct vcedit_buffer_chain {
    struct vcedit_buffer_chain *next;
    struct vcedit_page_buffer buffer;
} vcedit_buffer_chain;
// Total cost: 0.002060
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 9)]
// Total instrumented cost: 0.002060, input tokens: 2435, output tokens: 23, cache read tokens: 2280, cache write tokens: 151

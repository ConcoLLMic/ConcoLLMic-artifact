/* This program is licensed under the GNU Library General Public License, version 2,
 * a copy of which is included with this program (LICENCE.LGPL).
 *
 * (c) 2000-2001 Michael Smith <msmith@xiph.org>
 * (c) 2020      Philipp Schafft <lion@lion.leolix.org>
 *
 *
 * Comment editing backend, suitable for use by nice frontend interfaces.
 *
 * last modified: $Id$
 */

/* Handle muxed streams and the Vorbis renormalization without having
 * to understand remuxing:
 * Linked list of buffers (buffer_chain).  Start a link and whenever
 * you encounter an unknown page from the current stream (ie we found
 * its bos in the bos section) push it onto the current buffer.  Whenever
 * you encounter the stream being renormalized create a new link in the
 * chain.
 * On writing, write the contents of the first link before every Vorbis
 * page written, and move to the next link.  Assuming the Vorbis pages
 * in match vorbis pages out, the order of pages from different logical
 * streams will be unchanged.
 * Special case: header. After writing the vorbis headers, and before
 * starting renormalization, flush accumulated links (takes care of
 * situations where number of secondary vorbis header pages changes due
 * to remuxing.  Similarly flush links at the end of renormalization
 * and before the start of the next chain is written.
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <ogg/ogg.h>
#include <vorbis/codec.h>

#include "vcedit.h"
#include "vceditaux.h"
#include "i18n.h"


#define CHUNKSIZE 4096
#define BUFFERCHUNK CHUNKSIZE

/* Helper function, shouldn't need to call directly */
static int page_buffer_push(vcedit_buffer_chain *bufferlink, ogg_page *og) {
	fprintf(stderr, "[vorbiscomment/vcedit.c] enter page_buffer_push 1\n");
	int result=0;
	char *tmp;
	vcedit_page_buffer *buffer;

	buffer = &bufferlink->buffer;
	tmp = realloc(buffer->data,
		      buffer->data_len + og->header_len + og->body_len);
	if (tmp) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter page_buffer_push 2\n");
		buffer->data = tmp;
		memcpy(buffer->data + buffer->data_len, og->header,
		       og->header_len);
		buffer->data_len += og->header_len;
		memcpy(buffer->data + buffer->data_len, og->body,
	       og->body_len);
		result = 1;
		buffer->data_len += og->body_len;
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit page_buffer_push 2\n");
	} else {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter page_buffer_push 3\n");
		result = -1;
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit page_buffer_push 3\n");
	}

	fprintf(stderr, "[vorbiscomment/vcedit.c] exit page_buffer_push 1\n");
	return result;
}

/* Write and free the first link using callbacks */
static int buffer_chain_writelink(vcedit_state *state, void *out) {
    fprintf(stderr, "[vorbiscomment/vcedit.c] enter buffer_chain_writelink 1\n");
    int result = 0;
    vcedit_buffer_chain *tmpchain;
    vcedit_page_buffer *tmpbuffer;

    tmpchain = state->sidebuf;
    tmpbuffer = &tmpchain->buffer;
    if (tmpbuffer->data_len) {
        fprintf(stderr, "[vorbiscomment/vcedit.c] enter buffer_chain_writelink 2\n");
        if (state->write(tmpbuffer->data,1,tmpbuffer->data_len, out) !=
                (size_t) tmpbuffer->data_len) {
            fprintf(stderr, "[vorbiscomment/vcedit.c] enter buffer_chain_writelink 3\n");
            result = -1;
            fprintf(stderr, "[vorbiscomment/vcedit.c] exit buffer_chain_writelink 3\n");
        } else {
            fprintf(stderr, "[vorbiscomment/vcedit.c] enter buffer_chain_writelink 4\n");
            result = 1;
            fprintf(stderr, "[vorbiscomment/vcedit.c] exit buffer_chain_writelink 4\n");
        }
        fprintf(stderr, "[vorbiscomment/vcedit.c] exit buffer_chain_writelink 2\n");
    }

    fprintf(stderr, "[vorbiscomment/vcedit.c] enter buffer_chain_writelink 5\n");
    free(tmpbuffer->data);
    state->sidebuf = tmpchain->next;
    free(tmpchain);
    fprintf(stderr, "[vorbiscomment/vcedit.c] exit buffer_chain_writelink 5\n");
    fprintf(stderr, "[vorbiscomment/vcedit.c] exit buffer_chain_writelink 1\n");
    return result;
}


static int buffer_chain_newlink(vcedit_state *state) {
	fprintf(stderr, "[vorbiscomment/vcedit.c] enter buffer_chain_newlink 1\n");
	int result = 1;
	vcedit_buffer_chain *bufferlink;

	if (!state->sidebuf) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter buffer_chain_newlink 2\n");
		state->sidebuf = malloc(sizeof *state->sidebuf);
		if (state->sidebuf) {
			fprintf(stderr, "[vorbiscomment/vcedit.c] enter buffer_chain_newlink 3\n");
			bufferlink = state->sidebuf;
			fprintf(stderr, "[vorbiscomment/vcedit.c] exit buffer_chain_newlink 3\n");
		} else {
			fprintf(stderr, "[vorbiscomment/vcedit.c] enter buffer_chain_newlink 4\n");
			result = -1;
			fprintf(stderr, "[vorbiscomment/vcedit.c] exit buffer_chain_newlink 4\n");
		}
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit buffer_chain_newlink 2\n");
	} else {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter buffer_chain_newlink 5\n");
		bufferlink=state->sidebuf;
		while (bufferlink->next) {
			fprintf(stderr, "[vorbiscomment/vcedit.c] enter buffer_chain_newlink 6\n");
			bufferlink = bufferlink->next;
			fprintf(stderr, "[vorbiscomment/vcedit.c] exit buffer_chain_newlink 6\n");
		}
		bufferlink->next = malloc(sizeof *bufferlink->next);
		if (bufferlink->next) {
			fprintf(stderr, "[vorbiscomment/vcedit.c] enter buffer_chain_newlink 7\n");
			bufferlink = bufferlink->next;
			fprintf(stderr, "[vorbiscomment/vcedit.c] exit buffer_chain_newlink 7\n");
		} else {
			fprintf(stderr, "[vorbiscomment/vcedit.c] enter buffer_chain_newlink 8\n");
			result = -1;
			fprintf(stderr, "[vorbiscomment/vcedit.c] exit buffer_chain_newlink 8\n");
		}
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit buffer_chain_newlink 5\n");
	}

	if (result > 0) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter buffer_chain_newlink 9\n");
		bufferlink->next = 0;
		bufferlink->buffer.data = 0;
		bufferlink->buffer.data_len = 0;
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit buffer_chain_newlink 9\n");
	} else {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter buffer_chain_newlink 10\n");
		state->lasterror =
			_("Couldn't get enough memory for input buffering.");
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit buffer_chain_newlink 10\n");
    }

	fprintf(stderr, "[vorbiscomment/vcedit.c] exit buffer_chain_newlink 1\n");
	return result;
}


/* Push page onto the end of the buffer chain */
static int buffer_chain_push(vcedit_state *state, ogg_page *og) {
    fprintf(stderr, "[vorbiscomment/vcedit.c] enter buffer_chain_push 1\n");
    /* If there is no sidebuffer yet we need to create one, otherwise
     * traverse to the last buffer and push the new page onto it. */
    int result=1;
    vcedit_buffer_chain *bufferlink;

    if (!state->sidebuf) {
        fprintf(stderr, "[vorbiscomment/vcedit.c] enter buffer_chain_push 2\n");
        result = buffer_chain_newlink(state);
        fprintf(stderr, "[vorbiscomment/vcedit.c] exit buffer_chain_push 2\n");
    }

    if (result > 0) {
        fprintf(stderr, "[vorbiscomment/vcedit.c] enter buffer_chain_push 3\n");
        bufferlink = state->sidebuf;
        while (bufferlink->next) {
            fprintf(stderr, "[vorbiscomment/vcedit.c] enter buffer_chain_push 4\n");
            bufferlink = bufferlink->next;
            fprintf(stderr, "[vorbiscomment/vcedit.c] exit buffer_chain_push 4\n");
        }
        result = page_buffer_push(bufferlink, og);
        fprintf(stderr, "[vorbiscomment/vcedit.c] exit buffer_chain_push 3\n");
    }

    if (result < 0) {
        fprintf(stderr, "[vorbiscomment/vcedit.c] enter buffer_chain_push 5\n");
        state->lasterror =
            _("Couldn't get enough memory for input buffering.");
        fprintf(stderr, "[vorbiscomment/vcedit.c] exit buffer_chain_push 5\n");
    }

    fprintf(stderr, "[vorbiscomment/vcedit.c] exit buffer_chain_push 1\n");
    return result;
}



static int vcedit_supported_stream(vcedit_state *state, ogg_page *og) {
	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_supported_stream 1\n");
	ogg_stream_state os;
	vorbis_info vi;
	vorbis_comment vc;
	ogg_packet header;
	int result = 0;

	ogg_stream_init(&os, ogg_page_serialno(og));
	vorbis_info_init(&vi);
	vorbis_comment_init(&vc);

	if (!ogg_page_bos(og)) {
        fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_supported_stream 2\n");
        result = -1;
        fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_supported_stream 2\n");
    }

	if (result >= 0 && ogg_stream_pagein(&os, og) < 0) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_supported_stream 3\n");
		state->lasterror =
			_("Error reading first page of Ogg bitstream.");
		result = -1;
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_supported_stream 3\n");
	}

	if (result >= 0 && ogg_stream_packetout(&os, &header) != 1) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_supported_stream 4\n");
		state->lasterror = _("Error reading initial header packet.");
		result = -1;
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_supported_stream 4\n");
	}

	if (result >= 0 && vorbis_synthesis_headerin(&vi, &vc, &header) >= 0) {
        fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_supported_stream 5\n");
        result = 1;
        fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_supported_stream 5\n");
	} else {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_supported_stream 6\n");
		/* Not vorbis, may eventually become a chain of checks (Speex,
		 * Theora), but for the moment return 0, bos scan will push
         * the current page onto the buffer.
		 */
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_supported_stream 6\n");
	}

    fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_supported_stream 7\n");
    ogg_stream_clear(&os);
    vorbis_info_clear(&vi);
    vorbis_comment_clear(&vc);
    fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_supported_stream 7\n");
    fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_supported_stream 1\n");
    return result;
}


static int vcedit_contains_serial (vcedit_state *state, int serialno) {
	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_contains_serial 1\n");
	int result = 0;
	size_t count;

	for (count=0; count < state->serials.streams_len; count++) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_contains_serial 2\n");
		if (*(state->serials.streams + count) == serialno) {
			fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_contains_serial 3\n");
			result = 1;
			fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_contains_serial 3\n");
		}
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_contains_serial 2\n");
	}

	fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_contains_serial 1\n");
	return result;
}


static int vcedit_add_serial (vcedit_state *state, long serial) {
    fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_add_serial 1\n");
    int result = 0;
    long *tmp;

    if ( vcedit_contains_serial(state, serial) ) {
        fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_add_serial 2\n");
        result = 1;
        fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_add_serial 2\n");
    } else {
        fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_add_serial 3\n");
        tmp   = realloc(state->serials.streams,
                (state->serials.streams_len + 1) * sizeof *tmp);
        if (tmp) {
            fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_add_serial 4\n");
            state->serials.streams = tmp;
            *(state->serials.streams +
                    state->serials.streams_len) = serial;
            state->serials.streams_len += 1;
            result = 1;
            fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_add_serial 4\n");
        } else {
            fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_add_serial 5\n");
            state->lasterror =
                _("Couldn't get enough memory to register new stream serial number.");
            result = -1;
            fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_add_serial 5\n");
        }
        fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_add_serial 3\n");
    }
    fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_add_serial 1\n");
    return result;
}


/* For the benefit of the secondary header read only.  Quietly creates
 * newlinks and pushes pages onto the buffer in the right way */
static int vcedit_target_pageout (vcedit_state *state, ogg_page *og) {
	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_target_pageout 1\n");
	int result = 0;
	int pageout_result;

	pageout_result = ogg_sync_pageout(state->oy, og);
	if (pageout_result > 0) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_target_pageout 2\n");
		if (state->serial == ogg_page_serialno(og)) {
			fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_target_pageout 3\n");
			result = buffer_chain_newlink(state);
			fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_target_pageout 3\n");
		} else {
			fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_target_pageout 4\n");
			result = buffer_chain_push(state, og);
			fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_target_pageout 4\n");
		}
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_target_pageout 2\n");
	} else if (pageout_result < 0) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_target_pageout 5\n");
		/* Vorbis comment traditionally ignores the not-synced
		 * error from pageout, so give it a different code. */
		result = -2;
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_target_pageout 5\n");
	}
	fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_target_pageout 1\n");
	return result;
}


vcedit_state *vcedit_new_state(void) {
	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_new_state 1\n");
	vcedit_state *state = calloc(1, sizeof(vcedit_state));
	fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_new_state 1\n");
	return state;
}

const char *vcedit_error(vcedit_state *state) {
	fprintf(stderr, "\n");
	fprintf(stderr, "\n");
	return state->lasterror;
}

vorbis_comment *vcedit_comments(vcedit_state *state) {
	fprintf(stderr, "\n");
	fprintf(stderr, "\n");
	return state->vc;
}

static void vcedit_clear_internals(vcedit_state *state) {
    fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_clear_internals 1\n");
    char *tmp;

	if (state->vc) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_clear_internals 2\n");
		vorbis_comment_clear(state->vc);
		free(state->vc);
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_clear_internals 2\n");
	}
	if (state->os) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_clear_internals 3\n");
		ogg_stream_clear(state->os);
		free(state->os);
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_clear_internals 3\n");
	}
	if (state->oy) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_clear_internals 4\n");
		ogg_sync_clear(state->oy);
		free(state->oy);
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_clear_internals 4\n");
	}
	if (state->serials.streams_len) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_clear_internals 5\n");
		free(state->serials.streams);
		state->serials.streams_len = 0;
		state->serials.streams = 0;
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_clear_internals 5\n");
	}
	while (state->sidebuf) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_clear_internals 6\n");
		vcedit_buffer_chain *tmpbuffer;
		tmpbuffer = state->sidebuf;
		state->sidebuf = tmpbuffer->next;
		free(tmpbuffer->buffer.data);
		free(tmpbuffer);
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_clear_internals 6\n");
	}
	if (state->vendor) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_clear_internals 7\n");
		free(state->vendor);
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_clear_internals 7\n");
	}
    if (state->mainbuf) {
        fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_clear_internals 8\n");
        free(state->mainbuf);
        fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_clear_internals 8\n");
    }
    if (state->bookbuf) {
        fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_clear_internals 9\n");
        free(state->bookbuf);
        fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_clear_internals 9\n");
    }
    if (state->vi) {
        fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_clear_internals 10\n");
       	vorbis_info_clear(state->vi);
        free(state->vi);
        fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_clear_internals 10\n");
    }

    fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_clear_internals 11\n");
    tmp = state->lasterror;
    memset(state, 0, sizeof(*state));
    state->lasterror = tmp;
    fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_clear_internals 11\n");
    fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_clear_internals 1\n");
}

void vcedit_clear(vcedit_state *state)
{
	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_clear 1\n");
	if (state) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_clear 2\n");
		vcedit_clear_internals(state);
		free(state);
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_clear 2\n");
	}
	fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_clear 1\n");
}

/* Next two functions pulled straight from libvorbis, apart from one change
 * - we don't want to overwrite the vendor string.
 */
static void _v_writestring(oggpack_buffer *o, const char *s, size_t len)
{
	fprintf(stderr, "[vorbiscomment/vcedit.c] enter _v_writestring 1\n");
	while (len--) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter _v_writestring 2\n");
		oggpack_write(o, *s++ ,8);
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit _v_writestring 2\n");
	}
	fprintf(stderr, "[vorbiscomment/vcedit.c] exit _v_writestring 1\n");
}

static int _commentheader_out(vorbis_comment *vc, char *vendor, ogg_packet *op)
{
	fprintf(stderr, "[vorbiscomment/vcedit.c] enter _commentheader_out 1\n");
	oggpack_buffer opb;

	oggpack_writeinit(&opb);

	/* preamble */
	oggpack_write(&opb, 0x03, 8);
	_v_writestring(&opb, "vorbis", 6);

	/* vendor */
	oggpack_write(&opb, strlen(vendor), 32);
	_v_writestring(&opb, vendor, strlen(vendor));

	/* comments */
	oggpack_write(&opb, vc->comments, 32);
	if (vc->comments) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter _commentheader_out 2\n");
		int i;

		for (i = 0; i < vc->comments; i++) {
			fprintf(stderr, "[vorbiscomment/vcedit.c] enter _commentheader_out 3\n");
			if (vc->user_comments[i]){
				fprintf(stderr, "[vorbiscomment/vcedit.c] enter _commentheader_out 4\n");
				oggpack_write(&opb,vc->comment_lengths[i], 32);
				_v_writestring(&opb, vc->user_comments[i], vc->comment_lengths[i]);
				fprintf(stderr, "[vorbiscomment/vcedit.c] exit _commentheader_out 4\n");
			}else{
				fprintf(stderr, "[vorbiscomment/vcedit.c] enter _commentheader_out 5\n");
				oggpack_write(&opb, 0, 32);
				fprintf(stderr, "[vorbiscomment/vcedit.c] exit _commentheader_out 5\n");
			}
			fprintf(stderr, "[vorbiscomment/vcedit.c] exit _commentheader_out 3\n");
		}
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit _commentheader_out 2\n");
	}
	oggpack_write(&opb, 1, 1);

	fprintf(stderr, "[vorbiscomment/vcedit.c] enter _commentheader_out 6\n");
	op->packet = malloc(oggpack_bytes(&opb));
	memcpy(op->packet, opb.buffer, oggpack_bytes(&opb));

	op->bytes = oggpack_bytes(&opb);
	op->b_o_s = 0;
	op->e_o_s = 0;
	op->granulepos = 0;

	oggpack_writeclear(&opb);
	fprintf(stderr, "[vorbiscomment/vcedit.c] exit _commentheader_out 6\n");
	fprintf(stderr, "[vorbiscomment/vcedit.c] exit _commentheader_out 1\n");
	return 0;
}

static int _blocksize(vcedit_state *s, ogg_packet *p)
{
	fprintf(stderr, "[vorbiscomment/vcedit.c] enter _blocksize 1\n");
	int this = vorbis_packet_blocksize(s->vi, p);
	int ret = (this + s->prevW)/4;

	if (!s->prevW) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter _blocksize 2\n");
		s->prevW = this;
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit _blocksize 2\n");
		return 0;
	}

	fprintf(stderr, "[vorbiscomment/vcedit.c] enter _blocksize 3\n");
	s->prevW = this;
	fprintf(stderr, "[vorbiscomment/vcedit.c] exit _blocksize 3\n");
	fprintf(stderr, "[vorbiscomment/vcedit.c] exit _blocksize 1\n");
	return ret;
}

static int _fetch_next_packet(vcedit_state *s, ogg_packet *p, ogg_page *page)
{
	fprintf(stderr, "[vorbiscomment/vcedit.c] enter _fetch_next_packet 1\n");
	int result;
	char *buffer;
	int bytes;
	int serialno;

	result = ogg_stream_packetout(s->os, p);

	if (result > 0) {
		fprintf(stderr, "\n");
		fprintf(stderr, "\n");
		return 1;
    } else {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter _fetch_next_packet 3\n");
		while (1) {
			fprintf(stderr, "[vorbiscomment/vcedit.c] enter _fetch_next_packet 4\n");
			if (s->eosin) {
				fprintf(stderr, "\n");
				fprintf(stderr, "\n");
				return 0;
			}

			while (ogg_sync_pageout(s->oy, page) <= 0) {
				fprintf(stderr, "[vorbiscomment/vcedit.c] enter _fetch_next_packet 6\n");
				buffer = ogg_sync_buffer(s->oy, CHUNKSIZE);
				bytes = s->read(buffer,1, CHUNKSIZE, s->in);
				ogg_sync_wrote(s->oy, bytes);
				if (bytes == 0) {
					fprintf(stderr, "\n");
					fprintf(stderr, "\n");
					return 0;
				}
				fprintf(stderr, "[vorbiscomment/vcedit.c] exit _fetch_next_packet 6\n");
			}

			fprintf(stderr, "[vorbiscomment/vcedit.c] enter _fetch_next_packet 8\n");
			serialno = ogg_page_serialno(page);
			if (ogg_page_serialno(page) != s->serial) {
				fprintf(stderr, "[vorbiscomment/vcedit.c] enter _fetch_next_packet 9\n");
				if (vcedit_contains_serial(s, serialno)) {
					fprintf(stderr, "[vorbiscomment/vcedit.c] enter _fetch_next_packet 10\n");
					result = buffer_chain_push(s, page);
					if (result < 0) {
						fprintf(stderr, "\n");
						fprintf(stderr, "\n");
						return result;
					}
					fprintf(stderr, "[vorbiscomment/vcedit.c] exit _fetch_next_packet 10\n");
				} else {
					fprintf(stderr, "[vorbiscomment/vcedit.c] enter _fetch_next_packet 12\n");
					s->eosin = 1;
					s->extrapage = 1;
					fprintf(stderr, "[vorbiscomment/vcedit.c] exit _fetch_next_packet 12\n");
					return 0;
				}
				fprintf(stderr, "[vorbiscomment/vcedit.c] exit _fetch_next_packet 9\n");
			} else {
				fprintf(stderr, "[vorbiscomment/vcedit.c] enter _fetch_next_packet 13\n");
				ogg_stream_pagein(s->os, page);
				result = buffer_chain_newlink(s);
				if (result < 0) {
					fprintf(stderr, "\n");
					fprintf(stderr, "\n");
					return result;
				}

				if (ogg_page_eos(page)) {
					fprintf(stderr, "[vorbiscomment/vcedit.c] enter _fetch_next_packet 15\n");
					s->eosin = 1;
					fprintf(stderr, "[vorbiscomment/vcedit.c] exit _fetch_next_packet 15\n");
				}
				fprintf(stderr, "[vorbiscomment/vcedit.c] exit _fetch_next_packet 13\n");
			}
			result = ogg_stream_packetout(s->os, p);
			if (result > 0) {
				fprintf(stderr, "\n");
				fprintf(stderr, "\n");
				return 1;
			}
			fprintf(stderr, "[vorbiscomment/vcedit.c] exit _fetch_next_packet 8\n");
			fprintf(stderr, "[vorbiscomment/vcedit.c] exit _fetch_next_packet 4\n");
		}
		/* Here == trouble */
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit _fetch_next_packet 3\n");
		return 0;
	}
	fprintf(stderr, "[vorbiscomment/vcedit.c] exit _fetch_next_packet 1\n");
}

int vcedit_open(vcedit_state *state, FILE *in)
{
	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open 1\n");
	int result = vcedit_open_callbacks(state, (void *)in,
			(vcedit_read_func)fread, (vcedit_write_func)fwrite);
	fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open 1\n");
	return result;
}

int vcedit_open_callbacks(vcedit_state *state, void *in,
		                  vcedit_read_func read_func,
                          vcedit_write_func write_func)
{
	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 1\n");
	char *buffer;
	int bytes, i;
	int chunks = 0;
	int read_bos, test_supported, page_pending;
	int have_vorbis;
	ogg_packet *header;
	ogg_packet	header_main;
	ogg_packet  header_comments;
	ogg_packet	header_codebooks;
	ogg_page    og;

	state->in = in;
	state->read = read_func;
	state->write = write_func;

	state->oy = malloc(sizeof(ogg_sync_state));
	ogg_sync_init(state->oy);

    while (1) {
    	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 2\n");
    	buffer = ogg_sync_buffer(state->oy, CHUNKSIZE);
	    bytes = state->read(buffer, 1, CHUNKSIZE, state->in);

    	ogg_sync_wrote(state->oy, bytes);

        if (ogg_sync_pageout(state->oy, &og) == 1) {
        	fprintf(stderr, "\n");
        	fprintf(stderr, "\n");
            break;
        }

        if (chunks++ >= 10) {
            fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 4\n");
            /* Bail if we don't find data in the first 40 kB */

            if (bytes<CHUNKSIZE) {
            	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 5\n");
                state->lasterror = _("Input truncated or empty.");
                fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 5\n");
            } else {
            	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 6\n");
                state->lasterror = _("Input is not an Ogg bitstream.");
                fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 6\n");
            }
            goto err;
            fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 4\n");
        }
        fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 2\n");
    }

    fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 7\n");
    /* BOS loop, starting with a loaded ogg page. */
    if (buffer_chain_newlink(state) < 0) {
    	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 8\n");
	    goto err;
	    fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 8\n");
    }

    for (read_bos = 1, have_vorbis = 0; read_bos;) {
    	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 9\n");
	    test_supported = vcedit_supported_stream(state, &og);
	    if (test_supported < 0) {
	    	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 10\n");
		    goto err;
		    fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 10\n");
	    } else if (test_supported == 0 || have_vorbis) {
	    	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 11\n");
		    if (vcedit_add_serial(state, ogg_page_serialno(&og)) < 0) {
		    	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 12\n");
			    goto err;
			    fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 12\n");
		    }
		    if (buffer_chain_push(state, &og) < 0) {
		    	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 13\n");
			    goto err;
			    fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 13\n");
		    }
		    fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 11\n");
	    } else if (test_supported > 0) {
	    	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 14\n");
		    if (buffer_chain_newlink(state) < 0) {
		    	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 15\n");
			    goto err;
			    fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 15\n");
		    }
		    state->serial = ogg_page_serialno(&og);
		    if (vcedit_add_serial(state, ogg_page_serialno(&og)) < 0) {
		    	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 16\n");
		       goto err;
		       fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 16\n");
		    }

		    state->os = malloc(sizeof(ogg_stream_state));
		    ogg_stream_init(state->os, state->serial);

		    state->vi = malloc(sizeof(vorbis_info));
		    vorbis_info_init(state->vi);

		    state->vc = malloc(sizeof(vorbis_comment));
		    vorbis_comment_init(state->vc);

		    if (ogg_stream_pagein(state->os, &og) < 0) {
		    	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 17\n");
			    state->lasterror =
				    _("Error reading first page of Ogg bitstream.");
			    goto err;
			    fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 17\n");
		    }

		    if (ogg_stream_packetout(state->os, &header_main) != 1) {
		    	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 18\n");
			    state->lasterror =
				    _("Error reading initial header packet.");
			    goto err;
			    fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 18\n");
		    }

		    if (vorbis_synthesis_headerin(state->vi, state->vc, &header_main) < 0) {
		    	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 19\n");
			    state->lasterror =
				    _("Ogg bitstream does not contain Vorbis data.");
			    goto err;
			    fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 19\n");
		    }
		    have_vorbis = 1;
		    fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 14\n");
	    }
	    while (1) {
	    	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 20\n");
		    if (ogg_sync_pageout(state->oy, &og) == 1) {
		    	fprintf(stderr, "\n");
		    	fprintf(stderr, "\n");
			    break;
		    }

		    buffer = ogg_sync_buffer(state->oy, CHUNKSIZE);
		    bytes = state->read(buffer, 1, CHUNKSIZE, state->in);

		    if (bytes == 0) {
		    	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 22\n");
			    state->lasterror =
				    _("EOF before recognised stream.");
			    goto err;
			    fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 22\n");
		    }

		    ogg_sync_wrote(state->oy, bytes);
		    fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 20\n");
	    }
	    if (!ogg_page_bos(&og)) {
	    	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 23\n");
		    read_bos = 0;
		    page_pending = 1;
		    fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 23\n");
	    }
	    fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 9\n");
    }

    if (!state->os) {
        fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 24\n");
        state->lasterror = _("Ogg bitstream does not contain a supported data-type.");
        goto err;
        fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 24\n");
    }

	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 25\n");
	state->mainlen = header_main.bytes;
	state->mainbuf = malloc(state->mainlen);
	memcpy(state->mainbuf, header_main.packet, header_main.bytes);

	if (ogg_page_serialno(&og) == state->serial) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 26\n");
		if (buffer_chain_newlink(state) < 0) {
			fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 27\n");
			goto err;
			fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 27\n");
		}
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 26\n");
	} else {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 28\n");
		if (buffer_chain_push(state, &og) < 0) {
			fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 29\n");
			goto err;
			fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 29\n");
		}
		page_pending = 0;
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 28\n");
	}

	i = 0;
	header = &header_comments;
	while (i < 2) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 30\n");
		while (i < 2) {
			fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 31\n");
			int result;

			if (!page_pending) {
				fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 32\n");
				result = vcedit_target_pageout(state, &og);
				fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 32\n");
			} else {
				fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 33\n");
				result = 1;
				page_pending = 0;
				fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 33\n");
			}

			if (result == 0 || result == -2) {
                fprintf(stderr, "\n");
                fprintf(stderr, "\n");
                break; /* Too little data so far */
            } else if (result == -1) {
                fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 35\n");
                goto err;
                fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 35\n");
			} else if (result == 1) {
				fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 36\n");
				ogg_stream_pagein(state->os, &og);
				while (i<2) {
					fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 37\n");
					result = ogg_stream_packetout(state->os, header);
					if (result == 0) {
                        fprintf(stderr, "\n");
                        fprintf(stderr, "\n");
                        break;
                    }
					if (result == -1) {
						fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 39\n");
						state->lasterror = _("Corrupt secondary header.");
						goto err;
						fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 39\n");
					}
					vorbis_synthesis_headerin(state->vi, state->vc, header);
					if (i == 1) {
						fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 40\n");
						state->booklen = header->bytes;
						state->bookbuf = malloc(state->booklen);
						memcpy(state->bookbuf, header->packet,
								header->bytes);
						fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 40\n");
					}
					i++;
					header = &header_codebooks;
					fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 37\n");
				}
				fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 36\n");
			}
			fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 31\n");
		}

		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 41\n");
		buffer = ogg_sync_buffer(state->oy, CHUNKSIZE);
		bytes = state->read(buffer, 1, CHUNKSIZE, state->in);
		if (bytes == 0 && i < 2) {
			fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 42\n");
			state->lasterror = _("EOF before end of Vorbis headers.");
			goto err;
			fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 42\n");
		}
		ogg_sync_wrote(state->oy, bytes);
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 41\n");
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 30\n");
	}

	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 43\n");
	/* Copy the vendor tag */
	state->vendor = malloc(strlen(state->vc->vendor) +1);
	strcpy(state->vendor, state->vc->vendor);

	/* Headers are done! */
	fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 43\n");
	fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 25\n");
	fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 7\n");
	fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 1\n");
	return 0;

err:
	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_open_callbacks 44\n");
	vcedit_clear_internals(state);
	fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_open_callbacks 44\n");
	return -1;
}
int vcedit_write(vcedit_state *state, void *out)
{
	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 1\n");
	ogg_stream_state streamout;
	ogg_packet header_main;
	ogg_packet header_comments;
	ogg_packet header_codebooks;

	ogg_page ogout, ogin;
	ogg_packet op;
	ogg_int64_t granpos = 0;
	int result;
	char *buffer;
	int bytes;
	int needflush=0, needout=0;

	state->eosin = 0;
	state->extrapage = 0;

	header_main.bytes = state->mainlen;
	header_main.packet = state->mainbuf;
	header_main.b_o_s = 1;
	header_main.e_o_s = 0;
	header_main.granulepos = 0;

	header_codebooks.bytes = state->booklen;
	header_codebooks.packet = state->bookbuf;
	header_codebooks.b_o_s = 0;
	header_codebooks.e_o_s = 0;
	header_codebooks.granulepos = 0;

	ogg_stream_init(&streamout, state->serial);

	_commentheader_out(state->vc, state->vendor, &header_comments);

	ogg_stream_packetin(&streamout, &header_main);
	ogg_stream_packetin(&streamout, &header_comments);
	ogg_stream_packetin(&streamout, &header_codebooks);
	fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 1\n");

	while ((result = ogg_stream_flush(&streamout, &ogout))) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 2\n");
		if (state->sidebuf && buffer_chain_writelink(state, out) < 0)
			goto cleanup;
		if (state->write(ogout.header, 1, ogout.header_len, out) != (size_t)ogout.header_len)
			goto cleanup;
		if (state->write(ogout.body, 1, ogout.body_len, out) != (size_t)ogout.body_len)
			goto cleanup;
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 2\n");
	}

	while (state->sidebuf) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 3\n");
		if (buffer_chain_writelink(state, out) < 0)
			goto cleanup;
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 3\n");
	}
	
	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 4\n");
	if (buffer_chain_newlink(state) < 0)
		goto cleanup;
	fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 4\n");

	while (_fetch_next_packet(state, &op, &ogin)) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 5\n");
		int size;
		size = _blocksize(state, &op);
		granpos += size;
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 5\n");

		if (needflush) {
			fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 6\n");
			if (ogg_stream_flush(&streamout, &ogout)) {
				fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 7\n");
				if (state->sidebuf &&
				   buffer_chain_writelink(state, out) < 0)
					goto cleanup;
				if (state->write(ogout.header,1,ogout.header_len,
							out) != (size_t) ogout.header_len)
					goto cleanup;
				if (state->write(ogout.body,1,ogout.body_len,
							out) != (size_t) ogout.body_len)
					goto cleanup;
				fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 7\n");
			}
			fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 6\n");
		} else if (needout) {
			fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 8\n");
			if (ogg_stream_pageout(&streamout, &ogout)) {
				fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 9\n");
				if (state->sidebuf &&
				   buffer_chain_writelink(state, out) < 0)
					goto cleanup;
				if (state->write(ogout.header,1,ogout.header_len,
							out) != (size_t) ogout.header_len)
					goto cleanup;
				if (state->write(ogout.body,1,ogout.body_len,
							out) != (size_t) ogout.body_len)
					goto cleanup;
				fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 9\n");
			}
			fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 8\n");
		}

		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 10\n");
		needflush=needout=0;
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 10\n");

		if (op.granulepos == -1) {
			fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 11\n");
			op.granulepos = granpos;
			ogg_stream_packetin(&streamout, &op);
			fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 11\n");
		} else {
			fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 12\n");
            /* granulepos is set, validly. Use it, and force a flush to
             * account for shortened blocks (vcut) when appropriate */
			fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 12\n");

			if (granpos > op.granulepos) {
				fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 13\n");
				granpos = op.granulepos;
				ogg_stream_packetin(&streamout, &op);
				needflush = 1;
				fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 13\n");
			} else {
				fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 14\n");
				ogg_stream_packetin(&streamout, &op);
				needout = 1;
				fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 14\n");
			}
		}
	}

	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 15\n");
	streamout.e_o_s = 1;
	fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 15\n");
	
	while (ogg_stream_flush(&streamout, &ogout)) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 16\n");
		if (state->sidebuf && buffer_chain_writelink(state, out) < 0)
			goto cleanup;
		if (state->write(ogout.header, 1, ogout.header_len, out) != (size_t)ogout.header_len)
			goto cleanup;
		if (state->write(ogout.body, 1, ogout.body_len, out) != (size_t)ogout.body_len)
			goto cleanup;
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 16\n");
	}

	if (state->extrapage) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 17\n");
		/* This is the first page of a new chain, get rid of the
		 * sidebuffer */
		while (state->sidebuf) {
			fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 18\n");
			if (buffer_chain_writelink(state, out) < 0)
				goto cleanup;
			fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 18\n");
		}
		if (state->write(ogin.header, 1, ogin.header_len, out) != (size_t)ogin.header_len)
			goto cleanup;
		if (state->write(ogin.body, 1, ogin.body_len, out) != (size_t)ogin.body_len)
			goto cleanup;
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 17\n");
	}

	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 19\n");
	state->eosin = 0; /* clear it, because not all paths to here do */
	fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 19\n");
	
	while (!state->eosin) /* We reached eos, not eof */
	{
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 20\n");
		/* We copy the rest of the stream (other logical streams)
		 * through, a page at a time. */
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 20\n");
		
		while (1) {
			fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 21\n");
			result = ogg_sync_pageout(state->oy, &ogout);
			fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 21\n");
			
			if (result==0)
                break;
			if (result<0) {
				fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 22\n");
				state->lasterror = _("Corrupt or missing data, continuing...");
				fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 22\n");
			} else {
				fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 23\n");
				/* Don't bother going through the rest, we can just
				 * write the page out now */
				if (state->write(ogout.header,1,ogout.header_len,
						out) != (size_t) ogout.header_len) {
					goto cleanup;
                }
				if (state->write(ogout.body,1,ogout.body_len, out) !=
						(size_t) ogout.body_len) {
					goto cleanup;
                }
				fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 23\n");
			}
		}
		
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 24\n");
		buffer = ogg_sync_buffer(state->oy, CHUNKSIZE);
		bytes = state->read(buffer,1, CHUNKSIZE, state->in);
		ogg_sync_wrote(state->oy, bytes);
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 24\n");
		
		if (bytes == 0) {
			fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 25\n");
			state->eosin = 1;
			break;
			fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 25\n");
		}
	}


cleanup:
	fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 26\n");
	ogg_stream_clear(&streamout);

    /* We don't ogg_packet_clear() this, because the memory was allocated in
       _commentheader_out(), so we mirror that here */
    _ogg_free(header_comments.packet);

	free(state->mainbuf);
	free(state->bookbuf);
    state->mainbuf = state->bookbuf = NULL;

	if (!state->eosin) {
		fprintf(stderr, "[vorbiscomment/vcedit.c] enter vcedit_write 27\n");
		state->lasterror =
			_("Error writing stream to output. "
			"Output stream may be corrupted or truncated.");
		return -1;
		fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 27\n");
	}

	return 0;
	fprintf(stderr, "[vorbiscomment/vcedit.c] exit vcedit_write 26\n");
}
// Total cost: 0.647358
// Total split cost: 0.124019, input tokens: 39576, output tokens: 754, cache read tokens: 13525, cache write tokens: 8133, split chunks: [(0, 647), (647, 828)]
// Total instrumented cost: 0.523339, input tokens: 32430, output tokens: 25832, cache read tokens: 12868, cache write tokens: 19550

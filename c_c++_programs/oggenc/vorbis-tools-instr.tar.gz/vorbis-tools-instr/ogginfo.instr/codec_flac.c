/* Ogginfo
 *
 * A tool to describe ogg file contents and metadata.
 *
 * This file handles codecs we have no specific handling for.
 *
 * Copyright 2002-2005 Michael Smith <msmith@xiph.org>
 * Copyright 2020-2021 Philipp Schafft <lion@lion.leolix.org>
 * Licensed under the GNU GPL, distributed with this program.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>

#include <ogg/ogg.h>

#include "i18n.h"

#include "private.h"

typedef struct {
    bool seen_streaminfo;
    bool seen_data;
    bool headers_done;
    ogg_int64_t bytes;
    ogg_int64_t rate;
    ogg_int64_t lastgranulepos;
} misc_flac_info;

static inline ogg_int64_t read_intNbe(const unsigned char *in, int bits, int offset)
{
    fprintf(stderr, "[ogginfo/codec_flac.c] enter read_intNbe 1\n");
    ogg_int64_t ret = 0;
    int have = 0;

    ret = *(in++);
    have = 8;

    if (offset) {
        fprintf(stderr, "[ogginfo/codec_flac.c] enter read_intNbe 2\n");
        ret = ((ret << offset) & 0xFF) >> offset;
        have -= offset;
        fprintf(stderr, "[ogginfo/codec_flac.c] exit read_intNbe 2\n");
    }

    while (have < bits) {
        fprintf(stderr, "[ogginfo/codec_flac.c] enter read_intNbe 3\n");
        ret <<= 8;
        ret |= *(in++);
        have += 8;
        fprintf(stderr, "[ogginfo/codec_flac.c] exit read_intNbe 3\n");
    }

    ret >>= (have - bits);

    return ret;
    fprintf(stderr, "[ogginfo/codec_flac.c] exit read_intNbe 1\n");
}

static void flac_process_streaminfo(stream_processor *stream, misc_flac_info *self, ogg_packet *packet)
{
    fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process_streaminfo 1\n");
    self->rate = read_intNbe(&(packet->packet[27]), 20, 0);

    info(_("Channels: %d\n"), (long int)read_intNbe(&(packet->packet[29]), 3, 4) + 1);
    info(_("Bist per sample: %d\n"), (long int)read_intNbe(&(packet->packet[29]), 5, 7) + 1);
    info(_("Rate: %ld\n\n"), (long int)self->rate);

    self->seen_streaminfo = true;
    fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process_streaminfo 1\n");
}

static void flac_process_padding(stream_processor *stream, misc_flac_info *self, ogg_packet *packet)
{
    fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process_padding 1\n");
    info(_("Padding: %ld bytes\n"), (long int)(packet->bytes - 4));
    fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process_padding 1\n");
}

static inline const char * application_type_name(ogg_int64_t type)
{
    fprintf(stderr, "[ogginfo/codec_flac.c] enter application_type_name 1\n");
    return "<unknown>";
    fprintf(stderr, "[ogginfo/codec_flac.c] exit application_type_name 1\n");
}

static void flac_process_application(stream_processor *stream, misc_flac_info *self, ogg_packet *packet)
{
    fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process_application 1\n");
    ogg_int64_t type = read_intNbe(&(packet->packet[4]), 32, 0);
    info(_("Application data: %d (%s)\n"), (int)type, application_type_name(type));
    fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process_application 1\n");
}

static void flac_process_vorbis_comments(stream_processor *stream, misc_flac_info *self, ogg_packet *packet)
{
    fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process_vorbis_comments 1\n");
    size_t end;

    if (packet->bytes > 4) {
        fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process_vorbis_comments 2\n");
        if (handle_vorbis_comments(stream, packet->packet + 4, packet->bytes - 4, &end) == -1) {
            fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process_vorbis_comments 3\n");
            warn(_("WARNING: invalid Vorbis comments on stream %d: packet too short\n"), stream->num);
            fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process_vorbis_comments 3\n");
        }
        fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process_vorbis_comments 2\n");
    } else {
        fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process_vorbis_comments 4\n");
        warn(_("WARNING: invalid Vorbis comments on stream %d: packet too short\n"), stream->num);
        fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process_vorbis_comments 4\n");
    }
    fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process_vorbis_comments 1\n");
}

static void flac_process_picture(stream_processor *stream, misc_flac_info *self, ogg_packet *packet)
{
    fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process_picture 1\n");
    flac_picture_t *picture = NULL;

    if (packet->bytes > 4) {
        fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process_picture 2\n");
        picture = flac_picture_parse_from_blob(&(packet->packet[4]), packet->bytes - 4);
        fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process_picture 2\n");
    }
    check_flac_picture(picture, NULL);
    flac_picture_free(picture);
    fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process_picture 1\n");
}

static void flac_process_data(stream_processor *stream, misc_flac_info *self, ogg_packet *packet)
{
    fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process_data 1\n");
    if (packet->granulepos != -1) {
        fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process_data 2\n");
        self->lastgranulepos = packet->granulepos;
        fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process_data 2\n");
    }
    self->seen_data = true;
    fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process_data 1\n");
}

static void flac_process(stream_processor *stream, ogg_page *page)
{
    fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process 1\n");
    misc_flac_info *self = stream->data;

    ogg_stream_pagein(&stream->os, page);

    while (1) {
        fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process 2\n");
        ogg_packet packet;
        int res = ogg_stream_packetout(&stream->os, &packet);

        if (res < 0) {
           fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process 3\n");
           warn(_("WARNING: discontinuity in stream (%d)\n"), stream->num);
           fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process 3\n");
           continue;
        } else if (res == 0) {
            fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process 4\n");
            break;
            fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process 4\n");
        }

        if (packet.bytes < 1) {
            fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process 5\n");
            warn(_("WARNING: Invalid zero size packet in stream (%d)\n"), stream->num);
            break;
            fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process 5\n");
        }

        if (packet.packetno == 0) {
            fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process 6\n");
            flac_process_streaminfo(stream, self, &packet);
            fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process 6\n");
        } else if (!self->headers_done) {
            fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process 7\n");
            switch (packet.packet[0] & 0x7F) {
                case 1:
                    fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process 8\n");
                    flac_process_padding(stream, self, &packet);
                    fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process 8\n");
                    break;
                case 2:
                    fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process 9\n");
                    flac_process_application(stream, self, &packet);
                    fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process 9\n");
                    break;
                case 3:
                    fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process 10\n");
                    /* no-op: seek table */
                    fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process 10\n");
                    break;
                case 4:
                    fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process 11\n");
                    flac_process_vorbis_comments(stream, self, &packet);
                    fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process 11\n");
                    break;
                case 5:
                    fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process 12\n");
                    /* no-op: cue sheet */
                    fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process 12\n");
                    break;
                case 6:
                    fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process 13\n");
                    flac_process_picture(stream, self, &packet);
                    fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process 13\n");
                    break;
                default:
                    fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process 14\n");
                    warn(_("WARNING: Invalid header of type %d in stream (%d)\n"), (int)(packet.packet[0] & 0x7F), stream->num);
                    fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process 14\n");
                    break;
            }

            if (packet.packet[0] & 0x80) {
                fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process 15\n");
                self->headers_done = true;
                fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process 15\n");
            }
            fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process 7\n");
        } else {
            fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process 16\n");
            flac_process_data(stream, self, &packet);
            fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process 16\n");
        }
        fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process 2\n");
    }

    if (self->headers_done) {
        fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_process 17\n");
        self->bytes += page->header_len + page->body_len;
        fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process 17\n");
    }
    fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_process 1\n");
}

static void flac_end(stream_processor *stream)
{
    fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_end 1\n");
    misc_flac_info *self = stream->data;

    if (!self->seen_streaminfo) {
        fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_end 2\n");
        warn(_("WARNING: stream (%d) did not contain STREAMINFO\n"), stream->num);
        fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_end 2\n");
    }

    if (!self->seen_data) {
        fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_end 3\n");
        warn(_("WARNING: stream (%d) did not contain data packets\n"), stream->num);
        fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_end 3\n");
    }

    /* This should be lastgranulepos - startgranulepos, or something like that*/
    print_summary(stream, self->bytes, (double)self->lastgranulepos / self->rate);

    free(stream->data);
    fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_end 1\n");
}

void flac_start(stream_processor *stream)
{
    fprintf(stderr, "[ogginfo/codec_flac.c] enter flac_start 1\n");
    stream->type = "FLAC";
    stream->process_page = flac_process;
    stream->process_end = flac_end;
    stream->data = calloc(1, sizeof(misc_flac_info));
    fprintf(stderr, "[ogginfo/codec_flac.c] exit flac_start 1\n");
}
// Total cost: 0.063404
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 198)]
// Total instrumented cost: 0.063404, input tokens: 4263, output tokens: 3290, cache read tokens: 2280, cache write tokens: 1979

/* Ogginfo
 *
 * A tool to describe ogg file contents and metadata.
 *
 * This file handles codecs we have no specific handling for.
 *
 * Copyright 2002-2005 Michael Smith <msmith@xiph.org>
 * Copyright 2020      Philipp Schafft <lion@lion.leolix.org>
 * Licensed under the GNU GPL, distributed with this program.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <ogg/ogg.h>
#include <stdio.h>

#include "private.h"

static void process_other(stream_processor *stream, ogg_page *page)
{
    fprintf(stderr, "[ogginfo/codec_other.c] enter process_other 1\n");
    ogg_packet packet;

    ogg_stream_pagein(&stream->os, page);
    fprintf(stderr, "[ogginfo/codec_other.c] exit process_other 1\n");

    while (ogg_stream_packetout(&stream->os, &packet) > 0) {
        fprintf(stderr, "[ogginfo/codec_other.c] enter process_other 2\n");
        /* Should we do anything here? Currently, we don't */
        fprintf(stderr, "[ogginfo/codec_other.c] exit process_other 2\n");
    }
}

void other_start(stream_processor *stream, const char *type)
{
    fprintf(stderr, "[ogginfo/codec_other.c] enter other_start 1\n");
    if (type) {
        fprintf(stderr, "[ogginfo/codec_other.c] enter other_start 2\n");
        stream->type = type;
        fprintf(stderr, "[ogginfo/codec_other.c] exit other_start 2\n");
    } else {
        fprintf(stderr, "[ogginfo/codec_other.c] enter other_start 3\n");
        stream->type = "unknown";
        fprintf(stderr, "[ogginfo/codec_other.c] exit other_start 3\n");
    }
    stream->process_page = process_other;
    stream->process_end = NULL;
    fprintf(stderr, "[ogginfo/codec_other.c] exit other_start 1\n");
}
// Total cost: 0.010799
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 40)]
// Total instrumented cost: 0.010799, input tokens: 2663, output tokens: 503, cache read tokens: 2280, cache write tokens: 379

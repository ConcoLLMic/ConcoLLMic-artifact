/* Ogginfo
 *
 * A tool to describe ogg file contents and metadata.
 *
 * This file handles skeleton streams.
 * See also:
 *  https://wiki.xiph.org/Ogg_Skeleton
 *  https://wiki.xiph.org/Ogg_Skeleton_3
 *  https://wiki.xiph.org/SkeletonHeaders
 *
 * Copyright 2002-2005 Michael Smith <msmith@xiph.org>
 * Copyright 2020-2021 Philipp Schafft <lion@lion.leolix.org>
 * Licensed under the GNU GPL, distributed with this program.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdbool.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>

#include <ogg/ogg.h>

#include "i18n.h"
#include "utf8.h"

#include "private.h"

typedef struct {
    bool supported;
    uint16_t version_major;
    uint16_t version_minor;
    uint64_t presentationtime_numerator;
    uint64_t presentationtime_denominator;
    uint64_t basetime_numerator;
    uint64_t basetime_denominator;
} misc_skeleton_info;

static const char hexchar[] = "0123456789abcdef";

static inline uint16_t read16le(unsigned char *in)
{
    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter read16le 1\n");
    return (((uint16_t)in[1]) << 8) | ((uint16_t)in[0]);
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit read16le 1\n");
}

static inline uint32_t read32le(unsigned char *in)
{
    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter read32le 1\n");
    return (((uint32_t)in[3]) << 24) | (((uint32_t)in[2]) << 16) | (((uint32_t)in[1]) << 8) | ((uint32_t)in[0]);
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit read32le 1\n");
}

static inline uint64_t read64le(unsigned char *in)
{
    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter read64le 1\n");
    return (((uint64_t)in[7]) << 56) | (((uint64_t)in[6]) << 48) | (((uint64_t)in[5]) << 40) | (((uint64_t)in[4]) << 32) |
           (((uint64_t)in[3]) << 24) | (((uint64_t)in[2]) << 16) | (((uint64_t)in[1]) << 8) | ((uint64_t)in[0]);
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit read64le 1\n");
}

static void skeleton_process_fishead_utc(ogg_packet *packet)
{
    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fishead_utc 1\n");
    bool is_null = true;
    size_t i, j;
    char buf[2 + 2*20 + 1] = "0x";
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fishead_utc 1\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fishead_utc 2\n");
    for (i = 44, j = 2; i < 64; i++) {
        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fishead_utc 3\n");
        if (packet->packet[i])
            is_null = false;
        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fishead_utc 3\n");

        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fishead_utc 4\n");
        buf[j++] = hexchar[(packet->packet[i] >> 4) & 0x0F];
        buf[j++] = hexchar[packet->packet[i] & 0x0F];
        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fishead_utc 4\n");
    }
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fishead_utc 2\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fishead_utc 5\n");
    buf[j] = 0;
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fishead_utc 5\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fishead_utc 6\n");
    if (is_null) {
        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fishead_utc 7\n");
        info(_("Wall clock time (UTC) unset.\n"));
        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fishead_utc 7\n");
    } else {
        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fishead_utc 8\n");
        info(_("Wall clock time (UTC): %s\n"), buf);
        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fishead_utc 8\n");
    }
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fishead_utc 6\n");
}

static void skeleton_process_fishead(misc_skeleton_info *self, ogg_packet *packet)
{
    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fishead 1\n");
    if (packet->bytes < 64) {
        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fishead 2\n");
        warn(_("WARNING: Invalid short packet in %s stream.\n"), "skeleton");
        return;
        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fishead 2\n");
    }
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fishead 1\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fishead 3\n");
    self->version_major = read16le(&(packet->packet[8]));
    self->version_minor = read16le(&(packet->packet[10]));
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fishead 3\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fishead 4\n");
    info(_("Version: %d.%d\n"), (int)self->version_major, (int)self->version_minor);
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fishead 4\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fishead 5\n");
    self->supported = (self->version_major == 3 && self->version_minor == 0) || (self->version_major == 4 && self->version_minor == 0);
    if (!self->supported) {
        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fishead 6\n");
        warn(_("WARNING: %s version not supported.\n"), "skeleton");
        return;
        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fishead 6\n");
    }
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fishead 5\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fishead 7\n");
    self->presentationtime_numerator = read64le(&(packet->packet[12]));
    self->presentationtime_denominator = read64le(&(packet->packet[20]));
    self->basetime_numerator = read64le(&(packet->packet[28]));
    self->basetime_denominator = read64le(&(packet->packet[36]));
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fishead 7\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fishead 8\n");
    if (!self->presentationtime_denominator)
        warn(_("WARNING: Presentation time denominator is zero.\n"));
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fishead 8\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fishead 9\n");
    if (!self->basetime_denominator)
        warn(_("WARNING: Presentation time denominator is zero.\n"));
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fishead 9\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fishead 10\n");
    skeleton_process_fishead_utc(packet);
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fishead 10\n");
}

static void skeleton_process_fisbone_message_header(char *header)
{
    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone_message_header 1\n");
    char *decoded;
    char *sep;
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone_message_header 1\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone_message_header 2\n");
    if (utf8_decode(header, &decoded) < 0) {
        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone_message_header 3\n");
        warn(_("WARNING: Invalid fishbone message header field.\n"));
        return;
        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone_message_header 3\n");
    }
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone_message_header 2\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone_message_header 4\n");
    sep = strstr(decoded, ": ");
    if (sep) {
        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone_message_header 5\n");
        *sep = 0;
        sep += 2;
        info("\t%s=%s\n", decoded, sep);
        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone_message_header 5\n");
    } else {
        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone_message_header 6\n");
        warn(_("WARNING: Invalid fishbone message header field.\n"));
        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone_message_header 6\n");
    }
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone_message_header 4\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone_message_header 7\n");
    free(decoded);
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone_message_header 7\n");
}

static void skeleton_process_fisbone_message_headers(misc_skeleton_info *self, ogg_packet *packet, size_t offset)
{
    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone_message_headers 1\n");
    size_t left = packet->bytes - offset;
    const char *p = (const char *)&(packet->packet[offset]);
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone_message_headers 1\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone_message_headers 2\n");
    while (left) {
        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone_message_headers 3\n");
        const char *end;
        size_t len;
        bool seen_cr = false;
        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone_message_headers 3\n");

        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone_message_headers 4\n");
        for (end = p, len = 0; len < left; len++, end++) {
            fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone_message_headers 5\n");
            if (seen_cr) {
                fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone_message_headers 6\n");
                if (*end == '\n') {
                    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone_message_headers 7\n");
                    char *tmp = malloc(len);
                    if (!tmp) {
                        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone_message_headers 8\n");
                        error(_("ERROR: Out of memory.\n"));
                        return;
                        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone_message_headers 8\n");
                    }
                    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone_message_headers 7\n");
                    
                    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone_message_headers 9\n");
                    memcpy(tmp, p, len - 1);
                    tmp[len - 1] = 0;
                    skeleton_process_fisbone_message_header(tmp);
                    free(tmp);
                    // found one.
                    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone_message_headers 9\n");
                } else {
                    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone_message_headers 10\n");
                    warn(_("WARNING: Invalid fishbone message header field.\n"));
                    return;
                    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone_message_headers 10\n");
                }
                fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone_message_headers 6\n");
            } else {
                fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone_message_headers 11\n");
                if (*end == '\r') {
                    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone_message_headers 12\n");
                    seen_cr = true;
                    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone_message_headers 12\n");
                } else if (*end == '\n') {
                    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone_message_headers 13\n");
                    warn(_("WARNING: Invalid fishbone message header field.\n"));
                    return;
                    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone_message_headers 13\n");
                }
                fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone_message_headers 11\n");
            }
            fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone_message_headers 5\n");
        }
        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone_message_headers 4\n");

        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone_message_headers 14\n");
        left -= len;
        p += len;
        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone_message_headers 14\n");
    }
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone_message_headers 2\n");
}

static void skeleton_process_fisbone(misc_skeleton_info *self, ogg_packet *packet)
{
    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone 1\n");
    uint32_t offset_message_headers;
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone 1\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone 2\n");
    if (packet->bytes < 52) {
        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone 3\n");
        warn(_("WARNING: Invalid short packet in %s stream.\n"), "skeleton");
        return;
        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone 3\n");
    }
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone 2\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone 4\n");
    offset_message_headers = read32le(&(packet->packet[8]));
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone 4\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone 5\n");
    if (packet->bytes < (offset_message_headers + 8)) {
        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone 6\n");
        warn(_("WARNING: Invalid short packet in %s stream.\n"), "skeleton");
        return;
        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone 6\n");
    }
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone 5\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone 7\n");
    info(_("Fishbone: For stream %08x\n"), read32le(&(packet->packet[12])));
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone 7\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_fisbone 8\n");
    skeleton_process_fisbone_message_headers(self, packet, offset_message_headers + 8);
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_fisbone 8\n");
}

static void skeleton_process_index(misc_skeleton_info *self, ogg_packet *packet)
{
    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_index 1\n");
    if (self->version_major == 3) {
        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_index 2\n");
        // Index packets are not yet defined in version 3.
        warn(_("Invalid packet in %s stream.\n"), "skeleton");
        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_index 2\n");
    }
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_index 1\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_index 3\n");
    if (packet->bytes < 42) {
        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process_index 4\n");
        warn(_("WARNING: Invalid short packet in %s stream.\n"), "skeleton");
        return;
        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_index 4\n");
    }
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process_index 3\n");
}

static void skeleton_process(stream_processor *stream, ogg_page *page)
{
    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process 1\n");
    misc_skeleton_info *self = stream->data;
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process 1\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process 2\n");
    ogg_stream_pagein(&stream->os, page);
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process 2\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process 3\n");
    while (1) {
        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process 4\n");
        ogg_packet packet;
        int res = ogg_stream_packetout(&stream->os, &packet);
        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process 4\n");

        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process 5\n");
        if (res < 0) {
           fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process 6\n");
           warn(_("WARNING: discontinuity in stream (%d)\n"), stream->num);
           continue;
           fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process 6\n");
        } else if (res == 0) {
            fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process 7\n");
            break;
            fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process 7\n");
        }
        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process 5\n");

        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process 8\n");
        if (!self->supported)
            continue;
        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process 8\n");

        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process 9\n");
        if (packet.bytes == 0 && packet.e_o_s)
            continue;
        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process 9\n");

        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process 10\n");
        if (packet.bytes < 8) {
            fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process 11\n");
            warn(_("WARNING: Invalid short packet in %s stream.\n"), "skeleton");
            continue;
            fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process 11\n");
        }
        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process 10\n");

        fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process 12\n");
        if (memcmp(packet.packet, "fishead\0", 8) == 0) {
            fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process 13\n");
            skeleton_process_fishead(self, &packet);
            fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process 13\n");
        } else if (memcmp(packet.packet, "fisbone\0", 8) == 0) {
            fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process 14\n");
            skeleton_process_fisbone(self, &packet);
            fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process 14\n");
        } else if (memcmp(packet.packet, "index\0", 6) == 0) {
            fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process 15\n");
            skeleton_process_index(self, &packet);
            fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process 15\n");
        } else {
            fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_process 16\n");
            warn(_("Invalid packet in %s stream.\n"), "skeleton");
            fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process 16\n");
        }
        fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process 12\n");
    }
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_process 3\n");
}

static void skeleton_end(stream_processor *stream)
{
    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_end 1\n");
    free(stream->data);
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_end 1\n");
}

void skeleton_start(stream_processor *stream)
{
    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_start 1\n");
    misc_skeleton_info *self;
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_start 1\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_start 2\n");
    stream->type = "skeleton";
    stream->process_page = skeleton_process;
    stream->process_end = skeleton_end;
    stream->data = calloc(1, sizeof(misc_skeleton_info));
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_start 2\n");

    fprintf(stderr, "[ogginfo/codec_skeleton.c] enter skeleton_start 3\n");
    self = stream->data;
    self->supported = true;
    fprintf(stderr, "[ogginfo/codec_skeleton.c] exit skeleton_start 3\n");
}
// Total cost: 0.100835
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 269)]
// Total instrumented cost: 0.100835, input tokens: 4915, output tokens: 5492, cache read tokens: 2280, cache write tokens: 2631

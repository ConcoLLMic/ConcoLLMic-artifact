/* Ogginfo
 *
 * A tool to describe ogg file contents and metadata.
 *
 * This file handles invalid streams.
 *
 * Copyright 2002-2005 Michael Smith <msmith@xiph.org>
 * Copyright 2020      Philipp Schafft <lion@lion.leolix.org>
 * Licensed under the GNU GPL, distributed with this program.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <ogg/ogg.h>
#include <stdio.h>

#include "private.h"

static void process_invalid(stream_processor *stream, ogg_page *page)
{
    fprintf(stderr, "[ogginfo/codec_invalid.c] enter process_invalid 1\n");
    /* This is for invalid streams. */
    fprintf(stderr, "[ogginfo/codec_invalid.c] exit process_invalid 1\n");
}

void invalid_start(stream_processor *stream)
{
    fprintf(stderr, "[ogginfo/codec_invalid.c] enter invalid_start 1\n");
    stream->process_end = NULL;
    stream->type = "invalid";
    stream->process_page = process_invalid;
    fprintf(stderr, "[ogginfo/codec_invalid.c] exit invalid_start 1\n");
}
// Total cost: 0.007380
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 30)]
// Total instrumented cost: 0.007380, input tokens: 2572, output tokens: 316, cache read tokens: 2280, cache write tokens: 288

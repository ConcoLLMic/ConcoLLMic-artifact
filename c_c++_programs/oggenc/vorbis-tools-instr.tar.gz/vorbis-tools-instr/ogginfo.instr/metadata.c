/* Ogginfo
 *
 * A tool to describe ogg file contents and metadata.
 *
 * Copyright 2002-2005 Michael Smith <msmith@xiph.org>
 * Copyright 2020-2021 Philipp Schafft <lion@lion.leolix.org>
 * Licensed under the GNU GPL, distributed with this program.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include <ogg/ogg.h>

#include "utf8.h"
#include "i18n.h"

#include "private.h"

static void print_vendor(const unsigned char *str, size_t len)
{
    fprintf(stderr, "[ogginfo/metadata.c] enter print_vendor 1\n");
    char *buf = malloc(len + 1);
    if (buf) {
        fprintf(stderr, "[ogginfo/metadata.c] enter print_vendor 2\n");
        memcpy(buf, str, len);
        buf[len] = 0;
        info(_("Vendor: %s\n"), buf);
        free(buf);
        fprintf(stderr, "[ogginfo/metadata.c] exit print_vendor 2\n");
    }
    fprintf(stderr, "[ogginfo/metadata.c] exit print_vendor 1\n");
}

int handle_vorbis_comments(stream_processor *stream, const unsigned char *in, size_t length, size_t *end)
{
    fprintf(stderr, "[ogginfo/metadata.c] enter handle_vorbis_comments 1\n");
    ogg_uint32_t vendor_string_length;
    ogg_uint32_t user_comment_list_length;
    ogg_uint32_t i;

    if (length < 8)
        return -1;
    fprintf(stderr, "[ogginfo/metadata.c] exit handle_vorbis_comments 1\n");

    fprintf(stderr, "[ogginfo/metadata.c] enter handle_vorbis_comments 2\n");
    vendor_string_length = read_u32le(in);
    if (length < (8 + vendor_string_length))
        return -1;
    fprintf(stderr, "[ogginfo/metadata.c] exit handle_vorbis_comments 2\n");

    fprintf(stderr, "[ogginfo/metadata.c] enter handle_vorbis_comments 3\n");
    print_vendor(in + 4, vendor_string_length);

    user_comment_list_length = read_u32le(in + 4 + vendor_string_length);

    if (user_comment_list_length)
        info(_("User comments section follows...\n"));

    *end = 8 + vendor_string_length;
    fprintf(stderr, "[ogginfo/metadata.c] exit handle_vorbis_comments 3\n");
    
    for (i = 0; i < user_comment_list_length; i++) {
        fprintf(stderr, "[ogginfo/metadata.c] enter handle_vorbis_comments 4\n");
        ogg_uint32_t user_comment_string_length = read_u32le(in + *end);
        char *buf;

        (*end) += 4;

        if (length < (*end + user_comment_string_length))
            return -1;

        buf = malloc(user_comment_string_length + 1);
        if (buf) {
            fprintf(stderr, "[ogginfo/metadata.c] enter handle_vorbis_comments 5\n");
            memcpy(buf, in + *end, user_comment_string_length);
            buf[user_comment_string_length] = 0;
            check_xiph_comment(stream, i, buf, user_comment_string_length);
            free(buf);
            fprintf(stderr, "[ogginfo/metadata.c] exit handle_vorbis_comments 5\n");
        }

        (*end) += user_comment_string_length;
        fprintf(stderr, "[ogginfo/metadata.c] exit handle_vorbis_comments 4\n");
    }

    fprintf(stderr, "[ogginfo/metadata.c] enter handle_vorbis_comments 6\n");
    return 0;
    fprintf(stderr, "[ogginfo/metadata.c] exit handle_vorbis_comments 6\n");
}

void check_xiph_comment(stream_processor *stream, int i, const char *comment, int comment_length)
{
    fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 1\n");
    char *sep = strchr(comment, '=');
    char *decoded;
    int j;
    int broken = 0;
    unsigned char *val;
    int bytes;
    int remaining;

    if (sep == NULL) {
        fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 2\n");
        warn(_("WARNING: Comment %d in stream %d has invalid "
               "format, does not contain '=': \"%s\"\n"),
               i, stream->num, comment);
        return;
        fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 2\n");
    }
    fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 1\n");

    fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 3\n");
    for (j=0; j < sep-comment; j++) {
        fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 4\n");
        if (comment[j] < 0x20 || comment[j] > 0x7D) {
            fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 5\n");
            warn(_("WARNING: Invalid comment fieldname in "
                   "comment %d (stream %d): \"%s\"\n"),
                   i, stream->num, comment);
            broken = 1;
            break;
            fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 5\n");
        }
        fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 4\n");
    }

    if (broken)
        return;
    fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 3\n");

    fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 6\n");
    val = (unsigned char *)comment;

    j = sep-comment+1;
    fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 6\n");
    
    while (j < comment_length)
    {
        fprintf(stderr, "\n");
        remaining = comment_length - j;
        if ((val[j] & 0x80) == 0) {
            fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 8\n");
            bytes = 1;
            fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 8\n");
        } else if ((val[j] & 0x40) == 0x40) {
            fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 9\n");
            if ((val[j] & 0x20) == 0)
                bytes = 2;
            else if ((val[j] & 0x10) == 0)
                bytes = 3;
            else if ((val[j] & 0x08) == 0)
                bytes = 4;
            else if ((val[j] & 0x04) == 0)
                bytes = 5;
            else if ((val[j] & 0x02) == 0)
                bytes = 6;
            else {
                fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 10\n");
                warn(_("WARNING: Illegal UTF-8 sequence in "
                    "comment %d (stream %d): length marker wrong\n"),
                    i, stream->num);
                broken = 1;
                break;
                fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 10\n");
            }
            fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 9\n");
        } else {
            fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 11\n");
            warn(_("WARNING: Illegal UTF-8 sequence in comment "
                "%d (stream %d): length marker wrong\n"), i, stream->num);
            broken = 1;
            break;
            fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 11\n");
        }

        if (bytes > remaining) {
            fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 12\n");
            warn(_("WARNING: Illegal UTF-8 sequence in comment "
                "%d (stream %d): too few bytes\n"), i, stream->num);
            broken = 1;
            break;
            fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 12\n");
        }

        switch(bytes) {
            case 1:
                fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 13\n");
                /* No more checks needed */
                fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 13\n");
                break;
            case 2:
                fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 14\n");
                if ((val[j+1] & 0xC0) != 0x80)
                    broken = 1;
                if ((val[j] & 0xFE) == 0xC0)
                    broken = 1;
                fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 14\n");
                break;
            case 3:
                fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 15\n");
                if (!((val[j] == 0xE0 && val[j+1] >= 0xA0 && val[j+1] <= 0xBF &&
                         (val[j+2] & 0xC0) == 0x80) ||
                     (val[j] >= 0xE1 && val[j] <= 0xEC &&
                         (val[j+1] & 0xC0) == 0x80 &&
                         (val[j+2] & 0xC0) == 0x80) ||
                     (val[j] == 0xED && val[j+1] >= 0x80 &&
                         val[j+1] <= 0x9F &&
                         (val[j+2] & 0xC0) == 0x80) ||
                     (val[j] >= 0xEE && val[j] <= 0xEF &&
                         (val[j+1] & 0xC0) == 0x80 &&
                         (val[j+2] & 0xC0) == 0x80)))
                     broken = 1;
                 if (val[j] == 0xE0 && (val[j+1] & 0xE0) == 0x80)
                     broken = 1;
                 fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 15\n");
                 break;
            case 4:
                 fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 16\n");
                 if (!((val[j] == 0xF0 && val[j+1] >= 0x90 &&
                         val[j+1] <= 0xBF &&
                         (val[j+2] & 0xC0) == 0x80 &&
                         (val[j+3] & 0xC0) == 0x80) ||
                     (val[j] >= 0xF1 && val[j] <= 0xF3 &&
                         (val[j+1] & 0xC0) == 0x80 &&
                         (val[j+2] & 0xC0) == 0x80 &&
                         (val[j+3] & 0xC0) == 0x80) ||
                     (val[j] == 0xF4 && val[j+1] >= 0x80 &&
                         val[j+1] <= 0x8F &&
                         (val[j+2] & 0xC0) == 0x80 &&
                         (val[j+3] & 0xC0) == 0x80)))
                     broken = 1;
                 if (val[j] == 0xF0 && (val[j+1] & 0xF0) == 0x80)
                     broken = 1;
                 fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 16\n");
                 break;
             /* 5 and 6 aren't actually allowed at this point */
             case 5:
                 fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 17\n");
                 broken = 1;
                 fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 17\n");
                 break;
             case 6:
                 fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 18\n");
                 broken = 1;
                 fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 18\n");
                 break;
         }

         if (broken) {
             fprintf(stderr, "\n");
             char *simple = malloc (comment_length + 1);
             char *seq = malloc (comment_length * 3 + 1);
             static char hex[] = {'0', '1', '2', '3', '4', '5', '6', '7',
                                  '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
             int i, c1 = 0, c2 = 0;
             for (i = 0; i < comment_length; i++) {
               fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 20\n");
               seq[c1++] = hex[((unsigned char)comment[i]) >> 4];
               seq[c1++] = hex[((unsigned char)comment[i]) & 0xf];
               seq[c1++] = ' ';

               if (comment[i] < 0x20 || comment[i] > 0x7D) {
                 fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 21\n");
                 simple[c2++] = '?';
                 fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 21\n");
               } else {
                 fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 22\n");
                 simple[c2++] = comment[i];
                 fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 22\n");
               }
               fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 20\n");
             }
             fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 23\n");
             seq[c1] = 0;
             simple[c2] = 0;
             warn(_("WARNING: Illegal UTF-8 sequence in comment "
                   "%d (stream %d): invalid sequence \"%s\": %s\n"), i,
                   stream->num, simple, seq);
             broken = 1;
             free (simple);
             free (seq);
             break;
             fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 23\n");
         }

         fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 24\n");
         j += bytes;
         fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 24\n");
     }

    if (!broken) {
        fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 25\n");
        if (utf8_decode(sep+1, &decoded) < 0) {
            fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 26\n");
            warn(_("WARNING: Failure in UTF-8 decoder. This should not be possible\n"));
            return;
            fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 26\n");
        }
        fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 25\n");
        
        fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 27\n");
        *sep = 0;
        if (!broken) {
            fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 28\n");
            info("\t%s=%s\n", comment, decoded);
            if (strcasecmp(comment, "METADATA_BLOCK_PICTURE") == 0) {
                fprintf(stderr, "[ogginfo/metadata.c] enter check_xiph_comment 29\n");
                flac_picture_t *picture = flac_picture_parse_from_base64(decoded);
                check_flac_picture(picture, "\t");
                flac_picture_free(picture);
                fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 29\n");
            }
            free(decoded);
            fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 28\n");
        }
        fprintf(stderr, "[ogginfo/metadata.c] exit check_xiph_comment 27\n");
    }
}

void check_flac_picture(flac_picture_t *picture, const char *prefix)
{
    fprintf(stderr, "[ogginfo/metadata.c] enter check_flac_picture 1\n");
    if (!prefix)
        prefix = "";

    if (!picture) {
        fprintf(stderr, "[ogginfo/metadata.c] enter check_flac_picture 2\n");
        warn("%s%s\n", prefix, _("Picture: <corrupted>"));
        return;
        fprintf(stderr, "[ogginfo/metadata.c] exit check_flac_picture 2\n");
    }
    fprintf(stderr, "[ogginfo/metadata.c] exit check_flac_picture 1\n");

    fprintf(stderr, "[ogginfo/metadata.c] enter check_flac_picture 3\n");
    info("%s", prefix);
    info(_("Picture: %d (%s)\n"), (int)picture->type, flac_picture_type_string(picture->type));
    fprintf(stderr, "[ogginfo/metadata.c] exit check_flac_picture 3\n");

    if (picture->media_type) {
        fprintf(stderr, "[ogginfo/metadata.c] enter check_flac_picture 4\n");
        info("%s", prefix);
        info(_("\tMIME-Type: %s\n"), picture->media_type);
        fprintf(stderr, "[ogginfo/metadata.c] exit check_flac_picture 4\n");
    }

    if (picture->description) {
        fprintf(stderr, "[ogginfo/metadata.c] enter check_flac_picture 5\n");
        info("%s", prefix);
        info(_("\tDescription: %s\n"), picture->description);
        fprintf(stderr, "[ogginfo/metadata.c] exit check_flac_picture 5\n");
    }

    fprintf(stderr, "[ogginfo/metadata.c] enter check_flac_picture 6\n");
    info("%s", prefix);
    info(_("\tWidth: %ld\n"), (long int)picture->width);
    info("%s", prefix);
    info(_("\tHeight: %ld\n"), (long int)picture->height);
    info("%s", prefix);
    info(_("\tColor depth: %ld\n"), (long int)picture->depth);
    fprintf(stderr, "[ogginfo/metadata.c] exit check_flac_picture 6\n");
    
    if (picture->colors) {
        fprintf(stderr, "[ogginfo/metadata.c] enter check_flac_picture 7\n");
        info("%s", prefix);
        info(_("\tUsed colors: %ld\n"), (long int)picture->colors);
        fprintf(stderr, "[ogginfo/metadata.c] exit check_flac_picture 7\n");
    }

    if (picture->uri) {
        fprintf(stderr, "[ogginfo/metadata.c] enter check_flac_picture 8\n");
        info("%s", prefix);
        info(_("\tURL: %s\n"), picture->uri);
        fprintf(stderr, "[ogginfo/metadata.c] exit check_flac_picture 8\n");
    }

    if (picture->binary_length) {
        fprintf(stderr, "[ogginfo/metadata.c] enter check_flac_picture 9\n");
        info("%s", prefix);
        info(_("\tSize: %ld bytes\n"), (long int)picture->binary_length);
        fprintf(stderr, "[ogginfo/metadata.c] exit check_flac_picture 9\n");
    }
}
// Total cost: 0.096287
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 294)]
// Total instrumented cost: 0.096287, input tokens: 5510, output tokens: 4921, cache read tokens: 2280, cache write tokens: 3226

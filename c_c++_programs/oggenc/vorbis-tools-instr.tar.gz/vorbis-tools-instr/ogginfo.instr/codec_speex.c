/* Ogginfo
 *
 * A tool to describe ogg file contents and metadata.
 *
 * This file handles codecs we have no specific handling for.
 *
 * Copyright 2002-2005 Michael Smith <msmith@xiph.org>
 * Copyright 2020      Philipp Schafft <lion@lion.leolix.org>
 * Licensed under the GNU GPL, distributed with this program.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>

#include <ogg/ogg.h>

#include "i18n.h"

#include "private.h"

typedef struct {
    bool seen_speex_header;
    bool seen_vorbis_comments;
    bool seen_data;
} misc_speex_info;

static inline const char *mode_name(const unsigned char *in)
{
    fprintf(stderr, "[ogginfo/codec_speex.c] enter mode_name 1\n");
    switch (read_u32le(in)) {
        case 0:
            fprintf(stderr, "[ogginfo/codec_speex.c] enter mode_name 2\n");
            return "narrowband";
            fprintf(stderr, "[ogginfo/codec_speex.c] exit mode_name 2\n");
            break;
        case 1:
            fprintf(stderr, "[ogginfo/codec_speex.c] enter mode_name 3\n");
            return "wideband";
            fprintf(stderr, "[ogginfo/codec_speex.c] exit mode_name 3\n");
            break;
        case 2:
            fprintf(stderr, "[ogginfo/codec_speex.c] enter mode_name 4\n");
            return "ultra-wideband";
            fprintf(stderr, "[ogginfo/codec_speex.c] exit mode_name 4\n");
            break;
        default:
            fprintf(stderr, "[ogginfo/codec_speex.c] enter mode_name 5\n");
            return "<invalid>";
            fprintf(stderr, "[ogginfo/codec_speex.c] exit mode_name 5\n");
            break;
    }
    fprintf(stderr, "[ogginfo/codec_speex.c] exit mode_name 1\n");
}

static void speex_process_header(stream_processor *stream, misc_speex_info *self, ogg_packet *packet)
{
    fprintf(stderr, "[ogginfo/codec_speex.c] enter speex_process_header 1\n");
    if (packet->bytes == 80) {
        fprintf(stderr, "[ogginfo/codec_speex.c] enter speex_process_header 2\n");
        if (read_u32le(&(packet->packet[32])) == 80) {
            fprintf(stderr, "[ogginfo/codec_speex.c] enter speex_process_header 3\n");
            char version[21];
            memcpy(version, &(packet->packet[8]), 20);
            version[20] = 0;
            info(_("Version: %d (%s)\n"), (int)read_u32le(&(packet->packet[28])), version);
            info(_("Mode: %ld (%s)\n"), (long int)read_u32le(&(packet->packet[40])), mode_name(&(packet->packet[40])));
            info(_("Channels: %d\n"), (int)read_u32le(&(packet->packet[48])));
            info(_("Rate: %ld\n\n"), (long int)read_u32le(&(packet->packet[36])));
            fprintf(stderr, "[ogginfo/codec_speex.c] exit speex_process_header 3\n");
        } else {
            fprintf(stderr, "[ogginfo/codec_speex.c] enter speex_process_header 4\n");
            warn(_("WARNING: invalid Speex header on stream %d: header size does not match packet size\n"), stream->num);
            fprintf(stderr, "[ogginfo/codec_speex.c] exit speex_process_header 4\n");
        }
        fprintf(stderr, "[ogginfo/codec_speex.c] exit speex_process_header 2\n");
    } else {
        fprintf(stderr, "[ogginfo/codec_speex.c] enter speex_process_header 5\n");
        warn(_("WARNING: invalid Speex header on stream %d: packet of wrong size\n"), stream->num);
        fprintf(stderr, "[ogginfo/codec_speex.c] exit speex_process_header 5\n");
    }
    self->seen_speex_header = true;
    fprintf(stderr, "[ogginfo/codec_speex.c] exit speex_process_header 1\n");
}

static void speex_process_vorbis_comments(stream_processor *stream, misc_speex_info *self, ogg_packet *packet)
{
    fprintf(stderr, "[ogginfo/codec_speex.c] enter speex_process_vorbis_comments 1\n");
    size_t end;

    if (handle_vorbis_comments(stream, packet->packet, packet->bytes, &end) == -1) {
        fprintf(stderr, "[ogginfo/codec_speex.c] enter speex_process_vorbis_comments 2\n");
        warn(_("WARNING: invalid Vorbis comments on stream %d: packet too short\n"), stream->num);
        fprintf(stderr, "[ogginfo/codec_speex.c] exit speex_process_vorbis_comments 2\n");
    }

    self->seen_vorbis_comments = true;
    fprintf(stderr, "[ogginfo/codec_speex.c] exit speex_process_vorbis_comments 1\n");
}

static void speex_process_data(stream_processor *stream, misc_speex_info *self, ogg_packet *packet)
{
    fprintf(stderr, "[ogginfo/codec_speex.c] enter speex_process_data 1\n");
    self->seen_data = true;
    fprintf(stderr, "[ogginfo/codec_speex.c] exit speex_process_data 1\n");
}

static void speex_process(stream_processor *stream, ogg_page *page)
{
    fprintf(stderr, "[ogginfo/codec_speex.c] enter speex_process 1\n");
    misc_speex_info *self = stream->data;

    ogg_stream_pagein(&stream->os, page);
    fprintf(stderr, "[ogginfo/codec_speex.c] exit speex_process 1\n");

    while (1) {
        fprintf(stderr, "[ogginfo/codec_speex.c] enter speex_process 2\n");
        ogg_packet packet;
        int res = ogg_stream_packetout(&stream->os, &packet);

        if (res < 0) {
           fprintf(stderr, "[ogginfo/codec_speex.c] enter speex_process 3\n");
           warn(_("WARNING: discontinuity in stream (%d)\n"), stream->num);
           fprintf(stderr, "[ogginfo/codec_speex.c] exit speex_process 3\n");
           continue;
        } else if (res == 0) {
            fprintf(stderr, "[ogginfo/codec_speex.c] enter speex_process 4\n");
            break;
            fprintf(stderr, "[ogginfo/codec_speex.c] exit speex_process 4\n");
        }

        switch (packet.packetno) {
            case 0:
                fprintf(stderr, "[ogginfo/codec_speex.c] enter speex_process 5\n");
                speex_process_header(stream, self, &packet);
                fprintf(stderr, "[ogginfo/codec_speex.c] exit speex_process 5\n");
                break;
            case 1:
                fprintf(stderr, "[ogginfo/codec_speex.c] enter speex_process 6\n");
                speex_process_vorbis_comments(stream, self, &packet);
                fprintf(stderr, "[ogginfo/codec_speex.c] exit speex_process 6\n");
                break;
            default:
                fprintf(stderr, "[ogginfo/codec_speex.c] enter speex_process 7\n");
                speex_process_data(stream, self, &packet);
                fprintf(stderr, "[ogginfo/codec_speex.c] exit speex_process 7\n");
                break;
        }
        fprintf(stderr, "[ogginfo/codec_speex.c] exit speex_process 2\n");
    }
}

static void speex_end(stream_processor *stream)
{
    fprintf(stderr, "[ogginfo/codec_speex.c] enter speex_end 1\n");
    misc_speex_info *self = stream->data;

    if (!self->seen_speex_header) {
        fprintf(stderr, "[ogginfo/codec_speex.c] enter speex_end 2\n");
        warn(_("WARNING: stream (%d) did not contain Speex header\n"), stream->num);
        fprintf(stderr, "[ogginfo/codec_speex.c] exit speex_end 2\n");
    }

    if (!self->seen_vorbis_comments) {
        fprintf(stderr, "[ogginfo/codec_speex.c] enter speex_end 3\n");
        warn(_("WARNING: stream (%d) did not contain Vorbis comments header\n"), stream->num);
        fprintf(stderr, "[ogginfo/codec_speex.c] exit speex_end 3\n");
    }

    if (!self->seen_data) {
        fprintf(stderr, "[ogginfo/codec_speex.c] enter speex_end 4\n");
        warn(_("WARNING: stream (%d) did not contain data packets\n"), stream->num);
        fprintf(stderr, "[ogginfo/codec_speex.c] exit speex_end 4\n");
    }

    free(stream->data);
    fprintf(stderr, "[ogginfo/codec_speex.c] exit speex_end 1\n");
}

void speex_start(stream_processor *stream)
{
    fprintf(stderr, "[ogginfo/codec_speex.c] enter speex_start 1\n");
    stream->type = "speex";
    stream->process_page = speex_process;
    stream->process_end = speex_end;
    stream->data = calloc(1, sizeof(misc_speex_info));
    fprintf(stderr, "[ogginfo/codec_speex.c] exit speex_start 1\n");
}
// Total cost: 0.043520
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 138)]
// Total instrumented cost: 0.043520, input tokens: 3655, output tokens: 2238, cache read tokens: 2280, cache write tokens: 1371

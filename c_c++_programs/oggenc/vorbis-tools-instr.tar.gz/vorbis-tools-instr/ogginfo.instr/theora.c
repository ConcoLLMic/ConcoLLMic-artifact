/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE OggTheora SOFTWARE CODEC SOURCE CODE.   *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS LIBRARY SOURCE IS     *
 * GOVERNED BY A BSD-STYLE SOURCE LICENSE INCLUDED WITH THIS SOURCE *
 * IN 'COPYING'. PLEASE READ THESE TERMS BEFORE DISTRIBUTING.       *
 *                                                                  *
 * THE Theora SOURCE CODE IS COPYRIGHT (C) 2002-2003                *
 * by the Xiph.Org Foundation http://www.xiph.org/                  *
 *                                                                  *
 ********************************************************************

  function:
  last mod: $Id$

 ********************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "theora.h"

#define theora_read(x,y,z) ( *z = oggpackB_read(x,y) )

static void _tp_readbuffer(oggpack_buffer *opb, char *buf, const long len)
{
  fprintf(stderr, "[ogginfo/theora.c] enter _tp_readbuffer 1\n");
  long i;
  long ret;

  for (i = 0; i < len; i++) {
    fprintf(stderr, "[ogginfo/theora.c] enter _tp_readbuffer 2\n");
    theora_read(opb, 8, &ret);
    *buf++=(char)ret;
    fprintf(stderr, "[ogginfo/theora.c] exit _tp_readbuffer 2\n");
  }
  fprintf(stderr, "[ogginfo/theora.c] exit _tp_readbuffer 1\n");
}

static void _tp_readlsbint(oggpack_buffer *opb, long *value)
{
  fprintf(stderr, "[ogginfo/theora.c] enter _tp_readlsbint 1\n");
  int i;
  long ret[4];

  for (i = 0; i < 4; i++) {
    fprintf(stderr, "[ogginfo/theora.c] enter _tp_readlsbint 2\n");
    theora_read(opb,8,&ret[i]);
    fprintf(stderr, "[ogginfo/theora.c] exit _tp_readlsbint 2\n");
  }
  *value = ret[0]|ret[1]<<8|ret[2]<<16|ret[3]<<24;
  fprintf(stderr, "[ogginfo/theora.c] exit _tp_readlsbint 1\n");
}

void theora_info_clear(theora_info *c) {
  fprintf(stderr, "[ogginfo/theora.c] enter theora_info_clear 1\n");
  memset(c,0,sizeof(*c));
  fprintf(stderr, "[ogginfo/theora.c] exit theora_info_clear 1\n");
}

static int _theora_unpack_info(theora_info *ci, oggpack_buffer *opb){
  fprintf(stderr, "[ogginfo/theora.c] enter _theora_unpack_info 1\n");
  long ret;

  theora_read(opb,8,&ret);
  ci->version_major=(unsigned char)ret;
  theora_read(opb,8,&ret);
  ci->version_minor=(unsigned char)ret;
  theora_read(opb,8,&ret);
  ci->version_subminor=(unsigned char)ret;

  theora_read(opb,16,&ret);
  ci->width=ret<<4;
  theora_read(opb,16,&ret);
  ci->height=ret<<4;
  theora_read(opb,24,&ret);
  ci->frame_width=ret;
  theora_read(opb,24,&ret);
  ci->frame_height=ret;
  theora_read(opb,8,&ret);
  ci->offset_x=ret;
  theora_read(opb,8,&ret);
  ci->offset_y=ret;

  theora_read(opb,32,&ret);
  ci->fps_numerator=ret;
  theora_read(opb,32,&ret);
  ci->fps_denominator=ret;
  theora_read(opb,24,&ret);
  ci->aspect_numerator=ret;
  theora_read(opb,24,&ret);
  ci->aspect_denominator=ret;

  theora_read(opb,8,&ret);
  ci->colorspace=ret;
  theora_read(opb,24,&ret);
  ci->target_bitrate=ret;
  theora_read(opb,6,&ret);
  ci->quality=ret;

  theora_read(opb,5,&ret);
  ci->granule_shift = ret;

  theora_read(opb,2,&ret);
  ci->pixelformat=ret;

  /* spare configuration bits */
  if ( theora_read(opb,3,&ret) == -1 ) {
    fprintf(stderr, "[ogginfo/theora.c] enter _theora_unpack_info 2\n");
    return (OC_BADHEADER);
    fprintf(stderr, "[ogginfo/theora.c] exit _theora_unpack_info 2\n");
  }

  return(0);
  fprintf(stderr, "[ogginfo/theora.c] exit _theora_unpack_info 1\n");
}

void theora_comment_clear(theora_comment *tc){
  fprintf(stderr, "[ogginfo/theora.c] enter theora_comment_clear 1\n");
  if(tc){
    fprintf(stderr, "[ogginfo/theora.c] enter theora_comment_clear 2\n");
    long i;
    for(i=0;i<tc->comments;i++) {
      fprintf(stderr, "[ogginfo/theora.c] enter theora_comment_clear 3\n");
      if(tc->user_comments[i]) {
        fprintf(stderr, "[ogginfo/theora.c] enter theora_comment_clear 4\n");
        _ogg_free(tc->user_comments[i]);
        fprintf(stderr, "[ogginfo/theora.c] exit theora_comment_clear 4\n");
      }
      fprintf(stderr, "[ogginfo/theora.c] exit theora_comment_clear 3\n");
    }
    if(tc->user_comments) {
      fprintf(stderr, "[ogginfo/theora.c] enter theora_comment_clear 5\n");
      _ogg_free(tc->user_comments);
      fprintf(stderr, "[ogginfo/theora.c] exit theora_comment_clear 5\n");
    }
    if(tc->comment_lengths) {
      fprintf(stderr, "[ogginfo/theora.c] enter theora_comment_clear 6\n");
      _ogg_free(tc->comment_lengths);
      fprintf(stderr, "[ogginfo/theora.c] exit theora_comment_clear 6\n");
    }
    if(tc->vendor) {
      fprintf(stderr, "[ogginfo/theora.c] enter theora_comment_clear 7\n");
      _ogg_free(tc->vendor);
      fprintf(stderr, "[ogginfo/theora.c] exit theora_comment_clear 7\n");
    }
    memset(tc,0,sizeof(*tc));
    fprintf(stderr, "[ogginfo/theora.c] exit theora_comment_clear 2\n");
  }
  fprintf(stderr, "[ogginfo/theora.c] exit theora_comment_clear 1\n");
}

static int _theora_unpack_comment(theora_comment *tc, oggpack_buffer *opb){
  fprintf(stderr, "[ogginfo/theora.c] enter _theora_unpack_comment 1\n");
  int i;
  long len;

  _tp_readlsbint(opb,&len);
  if(len<0) {
    fprintf(stderr, "[ogginfo/theora.c] enter _theora_unpack_comment 2\n");
    return(OC_BADHEADER);
    fprintf(stderr, "[ogginfo/theora.c] exit _theora_unpack_comment 2\n");
  }
  tc->vendor=_ogg_calloc(1,len+1);
  _tp_readbuffer(opb,tc->vendor, len);
  tc->vendor[len]='\0';

  _tp_readlsbint(opb,(long *) &tc->comments);
  if(tc->comments<0) {
    fprintf(stderr, "[ogginfo/theora.c] enter _theora_unpack_comment 3\n");
    goto parse_err;
    fprintf(stderr, "[ogginfo/theora.c] exit _theora_unpack_comment 3\n");
  }
  tc->user_comments=_ogg_calloc(tc->comments,sizeof(*tc->user_comments));
  tc->comment_lengths=_ogg_calloc(tc->comments,sizeof(*tc->comment_lengths));
  for(i=0;i<tc->comments;i++){
    fprintf(stderr, "[ogginfo/theora.c] enter _theora_unpack_comment 4\n");
    _tp_readlsbint(opb,&len);
    if(len<0) {
      fprintf(stderr, "[ogginfo/theora.c] enter _theora_unpack_comment 5\n");
      goto parse_err;
      fprintf(stderr, "[ogginfo/theora.c] exit _theora_unpack_comment 5\n");
    }
    tc->user_comments[i]=_ogg_calloc(1,len+1);
    _tp_readbuffer(opb,tc->user_comments[i],len);
    tc->user_comments[i][len]='\0';
    tc->comment_lengths[i]=len;
    fprintf(stderr, "[ogginfo/theora.c] exit _theora_unpack_comment 4\n");
  }
  return(0);
  fprintf(stderr, "[ogginfo/theora.c] exit _theora_unpack_comment 1\n");

parse_err:
  fprintf(stderr, "[ogginfo/theora.c] enter _theora_unpack_comment 6\n");
  theora_comment_clear(tc);
  return(OC_BADHEADER);
  fprintf(stderr, "[ogginfo/theora.c] exit _theora_unpack_comment 6\n");
}

static int _theora_unpack_tables(theora_info *c, oggpack_buffer *opb){
  fprintf(stderr, "[ogginfo/theora.c] enter _theora_unpack_tables 1\n");
  /* NOP: ogginfo doesn't use this information */
  return 0;
  fprintf(stderr, "[ogginfo/theora.c] exit _theora_unpack_tables 1\n");
}

int theora_decode_header(theora_info *ci, theora_comment *cc, ogg_packet *op){
  fprintf(stderr, "\n");
  long ret;
  oggpack_buffer *opb;

  if(!op) {
    fprintf(stderr, "[ogginfo/theora.c] enter theora_decode_header 2\n");
    return OC_BADHEADER;
    fprintf(stderr, "[ogginfo/theora.c] exit theora_decode_header 2\n");
  }

  opb = _ogg_malloc(sizeof(oggpack_buffer));
  oggpackB_readinit(opb,op->packet,op->bytes);
  {
    fprintf(stderr, "[ogginfo/theora.c] enter theora_decode_header 3\n");
    char id[6];
    int typeflag;

    theora_read(opb,8,&ret);
    typeflag = ret;
    if(!(typeflag&0x80)) {
      fprintf(stderr, "[ogginfo/theora.c] enter theora_decode_header 4\n");
      free(opb);
      return(OC_NOTFORMAT);
      fprintf(stderr, "[ogginfo/theora.c] exit theora_decode_header 4\n");
    }

    _tp_readbuffer(opb,id,6);
    if(memcmp(id,"theora",6)) {
      fprintf(stderr, "[ogginfo/theora.c] enter theora_decode_header 5\n");
      free(opb);
      return(OC_NOTFORMAT);
      fprintf(stderr, "[ogginfo/theora.c] exit theora_decode_header 5\n");
    }

    switch(typeflag){
    case 0x80:
      fprintf(stderr, "[ogginfo/theora.c] enter theora_decode_header 6\n");
      if(!op->b_o_s){
        fprintf(stderr, "[ogginfo/theora.c] enter theora_decode_header 7\n");
        /* Not the initial packet */
        free(opb);
        return(OC_BADHEADER);
        fprintf(stderr, "[ogginfo/theora.c] exit theora_decode_header 7\n");
      }
      if(ci->version_major!=0){
        fprintf(stderr, "[ogginfo/theora.c] enter theora_decode_header 8\n");
        /* previously initialized info header */
        free(opb);
        return OC_BADHEADER;
        fprintf(stderr, "[ogginfo/theora.c] exit theora_decode_header 8\n");
      }

      ret = _theora_unpack_info(ci,opb);
      free(opb);
      return(ret);
      fprintf(stderr, "[ogginfo/theora.c] exit theora_decode_header 6\n");

    case 0x81:
      fprintf(stderr, "[ogginfo/theora.c] enter theora_decode_header 9\n");
      if(ci->version_major==0){
        fprintf(stderr, "[ogginfo/theora.c] enter theora_decode_header 10\n");
        /* um... we didn't get the initial header */
        free(opb);
        return(OC_BADHEADER);
        fprintf(stderr, "[ogginfo/theora.c] exit theora_decode_header 10\n");
      }

      ret = _theora_unpack_comment(cc,opb);
      free(opb);
      return(ret);
      fprintf(stderr, "[ogginfo/theora.c] exit theora_decode_header 9\n");

    case 0x82:
      fprintf(stderr, "[ogginfo/theora.c] enter theora_decode_header 11\n");
      if(ci->version_major==0 || cc->vendor==NULL){
        fprintf(stderr, "[ogginfo/theora.c] enter theora_decode_header 12\n");
        /* um... we didn't get the initial header or comments yet */
        free(opb);
        return(OC_BADHEADER);
        fprintf(stderr, "[ogginfo/theora.c] exit theora_decode_header 12\n");
      }

      ret = _theora_unpack_tables(ci,opb);
      free(opb);
      return(ret);
      fprintf(stderr, "[ogginfo/theora.c] exit theora_decode_header 11\n");

    default:
      fprintf(stderr, "[ogginfo/theora.c] enter theora_decode_header 13\n");
      free(opb);
      /* ignore any trailing header packets for forward compatibility */
      return(OC_NEWPACKET);
      fprintf(stderr, "[ogginfo/theora.c] exit theora_decode_header 13\n");
    }
    fprintf(stderr, "[ogginfo/theora.c] exit theora_decode_header 3\n");
  }
  /* I don't think it's possible to get this far, but better safe.. */
  fprintf(stderr, "[ogginfo/theora.c] enter theora_decode_header 14\n");
  free(opb);
  return(OC_BADHEADER);
  fprintf(stderr, "[ogginfo/theora.c] exit theora_decode_header 14\n");
}
// Total cost: 0.070736
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 225)]
// Total instrumented cost: 0.070736, input tokens: 4558, output tokens: 3646, cache read tokens: 2280, cache write tokens: 2274

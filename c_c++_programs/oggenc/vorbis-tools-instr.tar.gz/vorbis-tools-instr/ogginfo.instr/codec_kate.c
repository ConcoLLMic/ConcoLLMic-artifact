/* Ogginfo
 *
 * A tool to describe ogg file contents and metadata.
 *
 * This file handles kate streams.
 *
 * Copyright 2002-2005 Michael Smith <msmith@xiph.org>
 * Copyright 2020      Philipp Schafft <lion@lion.leolix.org>
 * Licensed under the GNU GPL, distributed with this program.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include <stdio.h>

#include <ogg/ogg.h>

#ifdef HAVE_KATE
#include <kate/oggkate.h>
#endif

#include "i18n.h"

#include "private.h"

typedef struct {
#ifdef HAVE_KATE
    kate_info ki;
    kate_comment kc;
#else
    int num_headers;
#endif

    int major;
    int minor;
    char language[16];
    char category[16];

    ogg_int64_t bytes;
    ogg_int64_t lastgranulepos;
    ogg_int64_t firstgranulepos;

    int doneheaders;
} misc_kate_info;


static void kate_process(stream_processor *stream, ogg_page *page )
{
    fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 1\n");
    ogg_packet packet;
    misc_kate_info *inf = stream->data;
    int header=0, packets=0;
    int res;
#ifdef HAVE_KATE
    int i;
    const char *encoding = NULL, *directionality = NULL;
#endif

    ogg_stream_pagein(&stream->os, page);
    if (!inf->doneheaders)
        header = 1;
    fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 1\n");

    while (1) {
        fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 2\n");
        res = ogg_stream_packetout(&stream->os, &packet);
        if (res < 0) {
           fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 3\n");
           warn(_("WARNING: discontinuity in stream (%d)\n"), stream->num);
           continue;
           fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 3\n");
        } else if (res == 0) {
            fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 4\n");
            break;
            fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 4\n");
        }

        packets++;
        if (!inf->doneheaders) {
            fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 5\n");
#ifdef HAVE_KATE
            int ret = kate_ogg_decode_headerin(&inf->ki, &inf->kc, &packet);
            if (ret < 0) {
                fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 6\n");
                warn(_("WARNING: Could not decode Kate header "
                            "packet %d - invalid Kate stream (%d)\n"),
                        packet.packetno, stream->num);
                continue;
                fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 6\n");
            } else if (ret > 0) {
                fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 7\n");
                inf->doneheaders=1;
                fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 7\n");
            }
#else
            /* if we're not building against libkate, do some limited checks */
            if (packet.bytes<64 || memcmp(packet.packet+1, "kate\0\0\0", 7)) {
                fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 8\n");
                warn(_("WARNING: packet %d does not seem to be a Kate header - "
                            "invalid Kate stream (%d)\n"),
                        packet.packetno, stream->num);
                continue;
                fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 8\n");
            }
            if (packet.packetno==inf->num_headers) {
                fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 9\n");
                inf->doneheaders=1;
                fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 9\n");
            }
#endif

            if (packet.packetno==0) {
                fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 10\n");
#ifdef HAVE_KATE
                inf->major = inf->ki.bitstream_version_major;
                inf->minor = inf->ki.bitstream_version_minor;
                memcpy(inf->language, inf->ki.language, 16);
                inf->language[15] = 0;
                memcpy(inf->category, inf->ki.category, 16);
                inf->category[15] = 0;
#else
                inf->major = packet.packet[9];
                inf->minor = packet.packet[10];
                inf->num_headers = packet.packet[11];
                memcpy(inf->language, packet.packet+32, 16);
                inf->language[15] = 0;
                memcpy(inf->category, packet.packet+48, 16);
                inf->category[15] = 0;
#endif
                fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 10\n");
            }

            if (inf->doneheaders) {
                fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 11\n");
                if (ogg_page_granulepos(page) != 0 || ogg_stream_packetpeek(&stream->os, NULL) == 1)
                    warn(_("WARNING: Kate stream %d does not have headers "
                                "correctly framed. Terminal header page contains "
                                "additional packets or has non-zero granulepos\n"),
                            stream->num);
                info(_("Kate headers parsed for stream %d, "
                            "information follows...\n"), stream->num);

                info(_("Version: %d.%d\n"), inf->major, inf->minor);
#ifdef HAVE_KATE
                info(_("Vendor: %s\n"), inf->kc.vendor);
#endif

                if (*inf->language) {
                    fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 12\n");
                    info(_("Language: %s\n"), inf->language);
                    fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 12\n");
                } else {
                    fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 13\n");
                    info(_("No language set\n"));
                    fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 13\n");
                }

                if (*inf->category) {
                    fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 14\n");
                    info(_("Category: %s\n"), inf->category);
                    fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 14\n");
                } else {
                    fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 15\n");
                    info(_("No category set\n"));
                    fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 15\n");
                }

#ifdef HAVE_KATE
                switch (inf->ki.text_encoding) {
                    case kate_utf8: 
                        fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 16\n");
                        encoding=_("utf-8"); 
                        break;
                        fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 16\n");
                    default: 
                        fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 17\n");
                        encoding=NULL; 
                        break;
                        fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 17\n");
                }

                if (encoding) {
                    fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 18\n");
                    info(_("Character encoding: %s\n"),encoding);
                    fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 18\n");
                } else {
                    fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 19\n");
                    info(_("Unknown character encoding\n"));
                    fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 19\n");
                }

                if (printlots) {
                    fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 20\n");
                    switch (inf->ki.text_directionality) {
                        case kate_l2r_t2b: 
                            fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 21\n");
                            directionality=_("left to right, top to bottom"); 
                            break;
                            fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 21\n");
                        case kate_r2l_t2b: 
                            fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 22\n");
                            directionality=_("right to left, top to bottom"); 
                            break;
                            fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 22\n");
                        case kate_t2b_r2l: 
                            fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 23\n");
                            directionality=_("top to bottom, right to left"); 
                            break;
                            fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 23\n");
                        case kate_t2b_l2r: 
                            fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 24\n");
                            directionality=_("top to bottom, left to right"); 
                            break;
                            fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 24\n");
                        default: 
                            fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 25\n");
                            directionality=NULL; 
                            break;
                            fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 25\n");
                    }

                    if (directionality) {
                        fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 26\n");
                        info(_("Text directionality: %s\n"),directionality);
                        fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 26\n");
                    } else {
                        fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 27\n");
                        info(_("Unknown text directionality\n"));
                        fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 27\n");
                    }

                    info("%u regions, %u styles, %u curves, %u motions, %u palettes,\n"
                            "%u bitmaps, %u font ranges, %u font mappings\n",
                            inf->ki.nregions, inf->ki.nstyles,
                            inf->ki.ncurves, inf->ki.nmotions,
                            inf->ki.npalettes, inf->ki.nbitmaps,
                            inf->ki.nfont_ranges, inf->ki.nfont_mappings);
                    fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 20\n");
                }

                if (inf->ki.gps_numerator == 0 || inf->ki.gps_denominator == 0) {
                    fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 28\n");
                    warn(_("Invalid zero granulepos rate\n"));
                    fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 28\n");
                } else {
                    fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 29\n");
                    info(_("Granulepos rate %d/%d (%.02f gps)\n"),
                            inf->ki.gps_numerator, inf->ki.gps_denominator,
                            (float)inf->ki.gps_numerator/(float)inf->ki.gps_denominator);
                    fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 29\n");
                }

                if (inf->kc.comments > 0) {
                    fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 30\n");
                    info(_("User comments section follows...\n"));
                    fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 30\n");
                }

                for (i=0; i < inf->kc.comments; i++) {
                    fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 31\n");
                    const char *comment = inf->kc.user_comments[i];
                    check_xiph_comment(stream, i, comment,
                            inf->kc.comment_lengths[i]);
                    fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 31\n");
                }
#endif
                info(_("\n"));
                fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 11\n");
            }
            fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 5\n");
        }
        fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 2\n");
    }

    if (!header) {
        fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 32\n");
        ogg_int64_t gp = ogg_page_granulepos(page);
        if (gp > 0) {
            fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 33\n");
            if (gp < inf->lastgranulepos) {
                fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 34\n");
                warn(_("WARNING: granulepos in stream %d decreases from %"
                        PRId64 " to %" PRId64 "\n" ),
                        stream->num, inf->lastgranulepos, gp);
                fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 34\n");
            }
            inf->lastgranulepos = gp;
            fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 33\n");
        } else if (packets && gp<0) { /* zero granpos on data is valid for kate */
            fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_process 35\n");
            /* Only do this if we saw at least one packet ending on this page.
             * It's legal (though very unusual) to have no packets in a page at
             * all - this is occasionally used to have an empty EOS page */
            warn(_("Negative granulepos (%" PRId64 ") on Kate stream outside of headers. This file was created by a buggy encoder\n"), gp);
            fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 35\n");
        }
        if (inf->firstgranulepos < 0) { /* Not set yet */
            fprintf(stderr, "\n");
            fprintf(stderr, "\n");
        }
        inf->bytes += page->header_len + page->body_len;
        fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_process 32\n");
    }
}

#ifdef HAVE_KATE
static void kate_end(stream_processor *stream)
{
    fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_end 1\n");
    misc_kate_info *inf = stream->data;
    long minutes, seconds, milliseconds;
    double bitrate, time;

    /* This should be lastgranulepos - startgranulepos, or something like that*/
    //time = (double)(inf->lastgranulepos>>inf->ki.granule_shift) * inf->ki.gps_denominator / inf->ki.gps_numerator;
    ogg_int64_t gbase=inf->lastgranulepos>>inf->ki.granule_shift;
    ogg_int64_t goffset=inf->lastgranulepos-(gbase<<inf->ki.granule_shift);
    time = (double)(gbase+goffset) / ((float)inf->ki.gps_numerator/(float)inf->ki.gps_denominator);
    minutes = (long)time / 60;
    seconds = (long)time - minutes*60;
    milliseconds = (long)((time - minutes*60 - seconds)*1000);
    bitrate = inf->bytes*8 / time / 1000.0;

    info(_("Kate stream %d:\n"
           "\tTotal data length: %" PRId64 " bytes\n"
           "\tPlayback length: %ldm:%02ld.%03lds\n"
           "\tAverage bitrate: %f kb/s\n"),
            stream->num,inf->bytes, minutes, seconds, milliseconds, bitrate);

    kate_comment_clear(&inf->kc);
    kate_info_clear(&inf->ki);

    free(stream->data);
    fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_end 1\n");
}
#else
static void kate_end(stream_processor *stream)
{
    fprintf(stderr, "\n");
    fprintf(stderr, "\n");
}
#endif

void kate_start(stream_processor *stream)
{
    fprintf(stderr, "[ogginfo/codec_kate.c] enter kate_start 1\n");
#ifdef HAVE_KATE
    misc_kate_info *info;
#endif /* HAVE_KATE */

    stream->type = "kate";
    stream->process_page = kate_process;
    stream->process_end = kate_end;

    stream->data = calloc(1, sizeof(misc_kate_info));

#ifdef HAVE_KATE
    info = stream->data;
    kate_comment_init(&info->kc);
    kate_info_init(&info->ki);
#endif /* HAVE_KATE */
    fprintf(stderr, "[ogginfo/codec_kate.c] exit kate_start 1\n");
}
// Total cost: 0.084658
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 275)]
// Total instrumented cost: 0.084658, input tokens: 5245, output tokens: 4265, cache read tokens: 2280, cache write tokens: 2961

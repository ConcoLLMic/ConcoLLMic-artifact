/* Ogginfo
 *
 * A tool to describe ogg file contents and metadata.
 *
 * This file handles theora streams.
 *
 * Copyright 2002-2005 Michael Smith <msmith@xiph.org>
 * Copyright 2020      Philipp Schafft <lion@lion.leolix.org>
 * Licensed under the GNU GPL, distributed with this program.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdlib.h>
#include <inttypes.h>
#include <math.h>
#include <stdio.h>

#include <ogg/ogg.h>

#include "i18n.h"

#include "theora.h"
#include "private.h"

typedef struct {
    theora_info ti;
    theora_comment tc;

    ogg_int64_t bytes;
    ogg_int64_t lastgranulepos;
    ogg_int64_t firstgranulepos;

    int doneheaders;

    ogg_int64_t framenum_expected;
} misc_theora_info;


static void theora_process(stream_processor *stream, ogg_page *page)
{
    fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 1\n");
    ogg_packet packet;
    misc_theora_info *inf = stream->data;
    int i, header=0;
    int res;

    ogg_stream_pagein(&stream->os, page);
    if (inf->doneheaders < 3)
        header = 1;
    fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 1\n");

    while (1) {
        fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 2\n");
        res = ogg_stream_packetout(&stream->os, &packet);
        if (res < 0) {
            fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 3\n");
            warn(_("WARNING: discontinuity in stream (%d)\n"), stream->num);
            fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 3\n");
            continue;
        } else if (res == 0) {
            fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 4\n");
            break;
            fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 4\n");
        }
        fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 2\n");

        if (inf->doneheaders < 3) {
            fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 5\n");
            if (theora_decode_header(&inf->ti, &inf->tc, &packet) < 0) {
                fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 6\n");
                warn(_("WARNING: Could not decode Theora header "
                            "packet - invalid Theora stream (%d)\n"), stream->num);
                fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 6\n");
                continue;
            }
            inf->doneheaders++;
            if (inf->doneheaders == 3) {
                fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 7\n");
                if (ogg_page_granulepos(page) != 0 || ogg_stream_packetpeek(&stream->os, NULL) == 1)
                    warn(_("WARNING: Theora stream %d does not have headers "
                                "correctly framed. Terminal header page contains "
                                "additional packets or has non-zero granulepos\n"),
                            stream->num);
                info(_("Theora headers parsed for stream %d, "
                            "information follows...\n"), stream->num);

                info(_("Version: %d.%d.%d\n"), inf->ti.version_major, inf->ti.version_minor, inf->ti.version_subminor);

                info(_("Vendor: %s\n"), inf->tc.vendor);
                info(_("Width: %d\n"), inf->ti.frame_width);
                info(_("Height: %d\n"), inf->ti.frame_height);
                info(_("Total image: %d by %d, crop offset (%d, %d)\n"),
                        inf->ti.width, inf->ti.height, inf->ti.offset_x, inf->ti.offset_y);
                if (inf->ti.offset_x + inf->ti.frame_width > inf->ti.width) {
                    fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 8\n");
                    warn(_("Frame offset/size invalid: width incorrect\n"));
                    fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 8\n");
                }
                if (inf->ti.offset_y + inf->ti.frame_height > inf->ti.height) {
                    fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 9\n");
                    warn(_("Frame offset/size invalid: height incorrect\n"));
                    fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 9\n");
                }

                if (inf->ti.fps_numerator == 0 || inf->ti.fps_denominator == 0) {
                    fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 10\n");
                    warn(_("Invalid zero framerate\n"));
                    fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 10\n");
                } else {
                    fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 11\n");
                    info(_("Framerate %d/%d (%.02f fps)\n"), inf->ti.fps_numerator, inf->ti.fps_denominator, (float)inf->ti.fps_numerator/(float)inf->ti.fps_denominator);
                    fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 11\n");
                }

                if (inf->ti.aspect_numerator == 0 || inf->ti.aspect_denominator == 0) {
                    fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 12\n");
                    info(_("Aspect ratio undefined\n"));
                    fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 12\n");
                } else {
                    fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 13\n");
                    float frameaspect = (float)inf->ti.frame_width/(float)inf->ti.frame_height * (float)inf->ti.aspect_numerator/(float)inf->ti.aspect_denominator;
                    info(_("Pixel aspect ratio %d:%d (%f:1)\n"), inf->ti.aspect_numerator, inf->ti.aspect_denominator, (float)inf->ti.aspect_numerator/(float)inf->ti.aspect_denominator);
                    if (fabs(frameaspect - 4.0/3.0) < 0.02) {
                        fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 14\n");
                        info(_("Frame aspect 4:3\n"));
                        fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 14\n");
                    }
                    else if (fabs(frameaspect - 16.0/9.0) < 0.02) {
                        fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 15\n");
                        info(_("Frame aspect 16:9\n"));
                        fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 15\n");
                    }
                    else {
                        fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 16\n");
                        info(_("Frame aspect %f:1\n"), frameaspect);
                        fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 16\n");
                    }
                    fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 13\n");
                }

                if (inf->ti.colorspace == OC_CS_ITU_REC_470M) {
                    fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 17\n");
                    info(_("Colourspace: Rec. ITU-R BT.470-6 System M (NTSC)\n"));
                    fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 17\n");
                }
                else if (inf->ti.colorspace == OC_CS_ITU_REC_470BG) {
                    fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 18\n");
                    info(_("Colourspace: Rec. ITU-R BT.470-6 Systems B and G (PAL)\n"));
                    fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 18\n");
                }
                else {
                    fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 19\n");
                    info(_("Colourspace unspecified\n"));
                    fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 19\n");
                }

                if (inf->ti.pixelformat == OC_PF_420) {
                    fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 20\n");
                    info(_("Pixel format 4:2:0\n"));
                    fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 20\n");
                }
                else if (inf->ti.pixelformat == OC_PF_422) {
                    fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 21\n");
                    info(_("Pixel format 4:2:2\n"));
                    fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 21\n");
                }
                else if (inf->ti.pixelformat == OC_PF_444) {
                    fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 22\n");
                    info(_("Pixel format 4:4:4\n"));
                    fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 22\n");
                }
                else {
                    fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 23\n");
                    warn(_("Pixel format invalid\n"));
                    fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 23\n");
                }

                info(_("Target bitrate: %d kbps\n"), inf->ti.target_bitrate/1000);
                info(_("Nominal quality setting (0-63): %d\n"), inf->ti.quality);

                if (inf->tc.comments > 0) {
                    fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 24\n");
                    info(_("User comments section follows...\n"));
                    fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 24\n");
                }

                for (i=0; i < inf->tc.comments; i++) {
                    fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 25\n");
                    char *comment = inf->tc.user_comments[i];
                    check_xiph_comment(stream, i, comment,
                            inf->tc.comment_lengths[i]);
                    fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 25\n");
                }
                fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 7\n");
            }
            fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 5\n");
        }
        else {
            fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 26\n");
            ogg_int64_t framenum;
            ogg_int64_t iframe,pframe;
            ogg_int64_t gp = packet.granulepos;

            if (gp > 0) {
                fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 27\n");
                iframe=gp>>inf->ti.granule_shift;
                pframe=gp-(iframe<<inf->ti.granule_shift);
                framenum = iframe+pframe;
                if (inf->framenum_expected >= 0 &&
                        inf->framenum_expected != framenum)
                {
                    fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 28\n");
                    warn(_("WARNING: Expected frame %" PRId64
                                ", got %" PRId64 "\n"),
                            inf->framenum_expected, framenum);
                    fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 28\n");
                }
                inf->framenum_expected = framenum + 1;
                fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 27\n");
            } else if (inf->framenum_expected >= 0) {
                fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 29\n");
                inf->framenum_expected++;
                fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 29\n");
            }
            fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 26\n");
        }
    }

    if (!header) {
        fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 30\n");
        ogg_int64_t gp = ogg_page_granulepos(page);
        if (gp > 0) {
            fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 31\n");
            if (gp < inf->lastgranulepos) {
                fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_process 32\n");
                warn(_("WARNING: granulepos in stream %d decreases from %"
                            PRId64 " to %" PRId64 "\n"),
                        stream->num, inf->lastgranulepos, gp);
                fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 32\n");
            }
            inf->lastgranulepos = gp;
            fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 31\n");
        }
        if (inf->firstgranulepos < 0) { /* Not set yet */
            fprintf(stderr, "\n");
            fprintf(stderr, "\n");
        }
        inf->bytes += page->header_len + page->body_len;
        fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_process 30\n");
    }
}

static void theora_end(stream_processor *stream)
{
    fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_end 1\n");
    misc_theora_info *inf = stream->data;
    long minutes, seconds, milliseconds;
    double bitrate, time;
    int new_gp;
    new_gp = inf->ti.version_major > 3
       || (inf->ti.version_major == 3 && (inf->ti.version_minor > 2
       || (inf->ti.version_minor == 2 && inf->ti.version_subminor > 0)));

    /* This should be lastgranulepos - startgranulepos, or something like that*/
    ogg_int64_t iframe=inf->lastgranulepos>>inf->ti.granule_shift;
    ogg_int64_t pframe=inf->lastgranulepos-(iframe<<inf->ti.granule_shift);
    /* The granule position starts at 0 for stream version 3.2.0, but starts at
       1 for version 3.2.1 and above. In the former case, we need to add one
       to the final granule position to get the frame count. */
    time = (double)(iframe+pframe+!new_gp) /
	((float)inf->ti.fps_numerator/(float)inf->ti.fps_denominator);
    minutes = (long)time / 60;
    seconds = (long)time - minutes*60;
    milliseconds = (long)((time - minutes*60 - seconds)*1000);
    bitrate = inf->bytes*8 / time / 1000.0;

    info(_("Theora stream %d:\n"
           "\tTotal data length: %" PRId64 " bytes\n"
           "\tPlayback length: %ldm:%02ld.%03lds\n"
           "\tAverage bitrate: %f kb/s\n"),
            stream->num,inf->bytes, minutes, seconds, milliseconds, bitrate);

    theora_comment_clear(&inf->tc);
    theora_info_clear(&inf->ti);

    free(stream->data);
    fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_end 1\n");
}


void theora_start(stream_processor *stream)
{
    fprintf(stderr, "[ogginfo/codec_theora.c] enter theora_start 1\n");
    misc_theora_info *info;

    stream->type = "theora";
    stream->process_page = theora_process;
    stream->process_end = theora_end;

    stream->data = calloc(1, sizeof(misc_theora_info));
    info = stream->data;
    info->framenum_expected = -1;
    fprintf(stderr, "[ogginfo/codec_theora.c] exit theora_start 1\n");
}
// Total cost: 0.081325
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 222)]
// Total instrumented cost: 0.081325, input tokens: 5129, output tokens: 4095, cache read tokens: 2280, cache write tokens: 2845

/* Ogginfo
 *
 * A tool to describe ogg file contents and metadata.
 *
 * This file handles opus streams.
 *
 * Copyright 2002-2005 Michael Smith <msmith@xiph.org>
 * Copyright 2020      Philipp Schafft <lion@lion.leolix.org>
 * Licensed under the GNU GPL, distributed with this program.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>

#include <ogg/ogg.h>

#include "i18n.h"

#include "private.h"

typedef struct {
    bool seen_opushead;
    bool seen_opustags;
    bool seen_data;

    ogg_int64_t bytes;

    /* from OpusHead */
    int version;
    int channel_count;
    ogg_uint16_t pre_skip;
    ogg_uint32_t input_sample_rate;
    ogg_int16_t output_gain;
    int mapping_family;

    /* from OpusTags */

    /* from data */
    ogg_int64_t lastgranulepos;
    ogg_int64_t firstgranulepos;
} misc_opus_info;

static inline const char * mapping_family_name(int mapping_family)
{
    fprintf(stderr, "[ogginfo/codec_opus.c] enter mapping_family_name 1\n");
    switch (mapping_family) {
        case 0:
            fprintf(stderr, "[ogginfo/codec_opus.c] enter mapping_family_name 2\n");
            return "RTP mapping";
            fprintf(stderr, "[ogginfo/codec_opus.c] exit mapping_family_name 2\n");
            break;
        case 1:
            fprintf(stderr, "[ogginfo/codec_opus.c] enter mapping_family_name 3\n");
            return "Vorbis mapping";
            fprintf(stderr, "[ogginfo/codec_opus.c] exit mapping_family_name 3\n");
            break;
        case 2:
            fprintf(stderr, "[ogginfo/codec_opus.c] enter mapping_family_name 4\n");
            return "Ambisonic mapping 2";
            fprintf(stderr, "[ogginfo/codec_opus.c] exit mapping_family_name 4\n");
            break;
        case 3:
            fprintf(stderr, "[ogginfo/codec_opus.c] enter mapping_family_name 5\n");
            return "Ambisonic mapping 3";
            fprintf(stderr, "[ogginfo/codec_opus.c] exit mapping_family_name 5\n");
            break;
        case 255:
            fprintf(stderr, "[ogginfo/codec_opus.c] enter mapping_family_name 6\n");
            return "unidentified mapping";
            fprintf(stderr, "[ogginfo/codec_opus.c] exit mapping_family_name 6\n");
            break;
        default:
            fprintf(stderr, "[ogginfo/codec_opus.c] enter mapping_family_name 7\n");
            return "<unknown>";
            fprintf(stderr, "[ogginfo/codec_opus.c] exit mapping_family_name 7\n");
            break;
    }
    fprintf(stderr, "[ogginfo/codec_opus.c] exit mapping_family_name 1\n");
}

static void opus_process_opushead(stream_processor *stream, misc_opus_info *self, ogg_packet *packet)
{
    fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process_opushead 1\n");
    if (packet->bytes >= 19) {
        fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process_opushead 2\n");
        self->version = (unsigned int)packet->packet[8];
        if (self->version < 16) {
            fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process_opushead 3\n");
            self->channel_count = (unsigned int)packet->packet[9];
            self->pre_skip = read_u16le(&(packet->packet[10]));
            self->input_sample_rate = read_u16le(&(packet->packet[12]));
            self->output_gain = read_u16le(&(packet->packet[16]));
            self->mapping_family = (unsigned int)packet->packet[18];
            info(_("Version: %d\n"), self->version);
            info(_("Channels: %d\n"), self->channel_count);
            info(_("Preskip: %d (%.1fms)\n"), (int)self->pre_skip, (self->pre_skip / 48.));
            info(_("Output gain: %.1fdB\n"), self->output_gain / 256.);
            info(_("Mapping family: %d (%s)\n"), self->mapping_family, mapping_family_name(self->mapping_family));
            /*
             * Not reported as per discussion in #xiph on 2020-12-19 -- phschafft
            if (self->input_sample_rate)
                info(_("Input rate: %ld\n"), (long int)self->input_sample_rate);
            info(_("Rate: %ld\n\n"), (long int)48000);
            */
            fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process_opushead 3\n");
        } else {
            fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process_opushead 4\n");
            warn(_("WARNING: invalid OpusHead version %d on stream %d\n"), self->version, stream->num);
            fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process_opushead 4\n");
        }
        fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process_opushead 2\n");
    } else {
        fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process_opushead 5\n");
        warn(_("WARNING: invalid OpusHead on stream %d: packet too short\n"), stream->num);
        fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process_opushead 5\n");
    }
    self->seen_opushead = true;
    fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process_opushead 1\n");
}

static void opus_process_opustags(stream_processor *stream, misc_opus_info *self, ogg_packet *packet)
{
    fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process_opustags 1\n");
    bool too_short = false;

    do {
        fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process_opustags 2\n");
        size_t offset;

        if (packet->bytes < 16) {
            fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process_opustags 3\n");
            too_short = true;
            break;
            fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process_opustags 3\n");
        }

        if (handle_vorbis_comments(stream, &(packet->packet[8]), packet->bytes - 8, &offset) == -1) {
            fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process_opustags 4\n");
            too_short = true;
            break;
            fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process_opustags 4\n");
        }

        offset += 8;

        if (packet->bytes - offset - 1) {
            fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process_opustags 5\n");
            if (packet->packet[offset] & 0x1) {
                fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process_opustags 6\n");
                info(_("Extra metadata: %ld bytes\n"), (long int)(packet->bytes - offset - 1));
                fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process_opustags 6\n");
            } else {
                fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process_opustags 7\n");
                info(_("Padding: %ld bytes\n"), (long int)(packet->bytes - offset - 1));
                fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process_opustags 7\n");
            }
            fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process_opustags 5\n");
        }
        fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process_opustags 2\n");
    } while (0);

    if (too_short) {
        fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process_opustags 8\n");
        warn(_("WARNING: invalid OpusTags on stream %d: packet too short\n"), stream->num);
        fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process_opustags 8\n");
    }

    self->seen_opustags = true;
    fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process_opustags 1\n");
}

static void opus_process_data(stream_processor *stream, misc_opus_info *self, ogg_packet *packet)
{
    fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process_data 1\n");
    if (packet->granulepos != -1) {
        fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process_data 2\n");
        if (!self->seen_data) {
            fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process_data 3\n");
            self->firstgranulepos = packet->granulepos;
            fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process_data 3\n");
        }

        self->lastgranulepos = packet->granulepos;
        fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process_data 2\n");
    }

    self->seen_data = true;
    fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process_data 1\n");
}

static void opus_process(stream_processor *stream, ogg_page *page)
{
    fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process 1\n");
    misc_opus_info *self = stream->data;

    ogg_stream_pagein(&stream->os, page);

    while (1) {
        fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process 2\n");
        ogg_packet packet;
        int res = ogg_stream_packetout(&stream->os, &packet);

        if (res < 0) {
           fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process 3\n");
           warn(_("WARNING: discontinuity in stream (%d)\n"), stream->num);
           continue;
           fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process 3\n");
        } else if (res == 0) {
            fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process 4\n");
            break;
            fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process 4\n");
        }

        if (packet.bytes >= 8 && strncmp((const char *)packet.packet, "OpusHead", 8) == 0) {
            fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process 5\n");
            opus_process_opushead(stream, self, &packet);
            fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process 5\n");
        } else if (packet.bytes >= 8 && strncmp((const char *)packet.packet, "OpusTags", 8) == 0) {
            fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process 6\n");
            opus_process_opustags(stream, self, &packet);
            fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process 6\n");
        } else {
            fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process 7\n");
            opus_process_data(stream, self, &packet);
            fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process 7\n");
        }
        fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process 2\n");
    }

    if (self->seen_data) {
        fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_process 8\n");
        self->bytes += page->header_len + page->body_len;
        fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process 8\n");
    }
    fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_process 1\n");
}

static void opus_end(stream_processor *stream)
{
    fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_end 1\n");
    misc_opus_info *self = stream->data;

    if (!self->seen_opushead) {
        fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_end 2\n");
        warn(_("WARNING: stream (%d) did not contain OpusHead header\n"), stream->num);
        fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_end 2\n");
    }

    if (!self->seen_opustags) {
        fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_end 3\n");
        warn(_("WARNING: stream (%d) did not contain OpusTags header\n"), stream->num);
        fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_end 3\n");
    }

    if (!self->seen_data) {
        fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_end 4\n");
        warn(_("WARNING: stream (%d) did not contain data packets\n"), stream->num);
        fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_end 4\n");
    }

    print_summary(stream, self->bytes, (double)(self->lastgranulepos - self->firstgranulepos - self->pre_skip) / 48000.);

    free(stream->data);
    fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_end 1\n");
}

void opus_start(stream_processor *stream)
{
    fprintf(stderr, "[ogginfo/codec_opus.c] enter opus_start 1\n");
    misc_opus_info *self;

    stream->type = "Opus";
    stream->process_page = opus_process;
    stream->process_end = opus_end;

    stream->data = calloc(1, sizeof(misc_opus_info));
    self = stream->data;

    self->version = -1;
    fprintf(stderr, "[ogginfo/codec_opus.c] exit opus_start 1\n");
}
// Total cost: 0.064435
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 209)]
// Total instrumented cost: 0.064435, input tokens: 4329, output tokens: 3329, cache read tokens: 2280, cache write tokens: 2045

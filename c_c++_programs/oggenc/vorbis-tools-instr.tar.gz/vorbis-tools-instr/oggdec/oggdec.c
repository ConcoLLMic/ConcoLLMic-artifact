/* OggDec
 *
 * This program is distributed under the GNU General Public License, version 2.
 * A copy of this license is included with this source.
 *
 * Copyright 2002, Michael Smith <msmith@xiph.org>
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdlib.h>
#include <stdio.h>
#include <getopt.h>
#include <errno.h>
#include <string.h>
#include <locale.h>

#if defined(_WIN32) || defined(__EMX__) || defined(__WATCOMC__)
#include <fcntl.h>
#include <io.h>
#endif

#include <vorbis/vorbisfile.h>

#include "i18n.h"

struct option long_options[] = {
    {"quiet", no_argument, NULL, 'Q'},
    {"help", no_argument, NULL, 'h'},
    {"version", no_argument, NULL, 'V'},
    {"bits", required_argument, NULL, 'b'},
    {"endianness", required_argument, NULL, 'e'},
    {"raw", no_argument, NULL, 'R'},
    {"sign", required_argument, NULL, 's'},
    {"output", required_argument, NULL, 'o'},
    {NULL,0,NULL,0}
};

static int quiet = 0;
static int bits = 16;
static int endian = 0;
static int raw = 0;
static int sign = 1;
unsigned char headbuf[44]; /* The whole buffer */
char *outfilename = NULL;

static void version (void) {
    fprintf(stderr, "[oggdec/oggdec.c] enter version 1\n");
    fprintf(stderr, _("oggdec from %s %s\n"), PACKAGE, VERSION);
    fprintf(stderr, "[oggdec/oggdec.c] exit version 1\n");
}

static void usage(void)
{
    fprintf(stderr, "[oggdec/oggdec.c] enter usage 1\n");
    version ();
    fprintf(stdout, _(" by the Xiph.Org Foundation (https://www.xiph.org/)\n"));
    fprintf(stdout, _(" using decoder %s.\n\n"), vorbis_version_string());
    fprintf(stdout, _("Usage: oggdec [options] file1.ogg [file2.ogg ... fileN.ogg]\n\n"));
    fprintf(stdout, _("Supported options:\n"));
    fprintf(stdout, _(" --quiet, -Q      Quiet mode. No console output.\n"));
    fprintf(stdout, _(" --help,  -h      Produce this help message.\n"));
    fprintf(stdout, _(" --version, -V    Print out version number.\n"));
    fprintf(stdout, _(" --bits, -b       Bit depth for output (8 and 16 supported)\n"));
    fprintf(stdout, _(" --endianness, -e Output endianness for 16-bit output; 0 for\n"
                      "                  little endian (default), 1 for big endian.\n"));
    fprintf(stdout, _(" --sign, -s       Sign for output PCM; 0 for unsigned, 1 for\n"
                      "                  signed (default 1).\n"));
    fprintf(stdout, _(" --raw, -R        Raw (headerless) output.\n"));
    fprintf(stdout, _(" --output, -o     Output to given filename. May only be used\n"
                      "                  if there is only one input file, except in\n"
                      "                  raw mode.\n"));
    fprintf(stderr, "[oggdec/oggdec.c] exit usage 1\n");
}

static void parse_options(int argc, char **argv)
{
    fprintf(stderr, "[oggdec/oggdec.c] enter parse_options 1\n");
    int option_index = 1;
    int ret;
    fprintf(stderr, "[oggdec/oggdec.c] exit parse_options 1\n");

    while((ret = getopt_long(argc, argv, "QhVb:e:Rs:o:", 
                    long_options, &option_index)) != -1)
    {
        fprintf(stderr, "[oggdec/oggdec.c] enter parse_options 2\n");
        switch(ret)
        {
            case 'Q':
                fprintf(stderr, "[oggdec/oggdec.c] enter parse_options 3\n");
                quiet = 1;
                fprintf(stderr, "[oggdec/oggdec.c] exit parse_options 3\n");
                break;
            case 'h':
                fprintf(stderr, "[oggdec/oggdec.c] enter parse_options 4\n");
                usage();
                exit(0);
                fprintf(stderr, "[oggdec/oggdec.c] exit parse_options 4\n");
                break;
            case 'V':
                fprintf(stderr, "[oggdec/oggdec.c] enter parse_options 5\n");
                version();
                exit(0);
                fprintf(stderr, "[oggdec/oggdec.c] exit parse_options 5\n");
                break;
            case 's':
                fprintf(stderr, "[oggdec/oggdec.c] enter parse_options 6\n");
                sign = atoi(optarg);
                fprintf(stderr, "[oggdec/oggdec.c] exit parse_options 6\n");
                break;
            case 'b':
                fprintf(stderr, "[oggdec/oggdec.c] enter parse_options 7\n");
                bits = atoi(optarg);
                fprintf(stderr, "[oggdec/oggdec.c] exit parse_options 7\n");
                if(bits <= 8)
                {
                    fprintf(stderr, "[oggdec/oggdec.c] enter parse_options 8\n");
                    bits = 8;
                    fprintf(stderr, "[oggdec/oggdec.c] exit parse_options 8\n");
                }
                else
                {
                    fprintf(stderr, "[oggdec/oggdec.c] enter parse_options 9\n");
                    bits = 16;
                    fprintf(stderr, "[oggdec/oggdec.c] exit parse_options 9\n");
                }
                break;
            case 'e':
                fprintf(stderr, "[oggdec/oggdec.c] enter parse_options 10\n");
                endian = atoi(optarg);
                fprintf(stderr, "[oggdec/oggdec.c] exit parse_options 10\n");
                break;
            case 'o':
                fprintf(stderr, "[oggdec/oggdec.c] enter parse_options 11\n");
                outfilename = strdup(optarg);
                fprintf(stderr, "[oggdec/oggdec.c] exit parse_options 11\n");
                break;
            case 'R':
                fprintf(stderr, "[oggdec/oggdec.c] enter parse_options 12\n");
                raw = 1;
                fprintf(stderr, "[oggdec/oggdec.c] exit parse_options 12\n");
                break;
            default:
                fprintf(stderr, "[oggdec/oggdec.c] enter parse_options 13\n");
                fprintf(stderr, _("Internal error: Unrecognised argument\n"));
                fprintf(stderr, "[oggdec/oggdec.c] exit parse_options 13\n");
                break;
        }
        fprintf(stderr, "[oggdec/oggdec.c] exit parse_options 2\n");
    }
}

#define WRITE_U32(buf, x) *(buf)     = (unsigned char)((x)&0xff);\
                          *((buf)+1) = (unsigned char)(((x)>>8)&0xff);\
                          *((buf)+2) = (unsigned char)(((x)>>16)&0xff);\
                          *((buf)+3) = (unsigned char)(((x)>>24)&0xff);

#define WRITE_U16(buf, x) *(buf)     = (unsigned char)((x)&0xff);\
                          *((buf)+1) = (unsigned char)(((x)>>8)&0xff);

/* Some of this based on ao/src/ao_wav.c */
int write_prelim_header(OggVorbis_File *vf, FILE *out, ogg_int64_t knownlength) {
    fprintf(stderr, "[oggdec/oggdec.c] enter write_prelim_header 1\n");
    unsigned int size = 0x7fffffff;
    int channels = ov_info(vf,0)->channels;
    int samplerate = ov_info(vf,0)->rate;
    int bytespersec = channels*samplerate*bits/8;
    int align = channels*bits/8;
    int samplesize = bits;
    fprintf(stderr, "[oggdec/oggdec.c] exit write_prelim_header 1\n");

    if(knownlength && knownlength*bits/8*channels < size)
    {
        fprintf(stderr, "[oggdec/oggdec.c] enter write_prelim_header 2\n");
        size = (unsigned int)(knownlength*bits/8*channels+44);
        fprintf(stderr, "[oggdec/oggdec.c] exit write_prelim_header 2\n");
    }

    fprintf(stderr, "[oggdec/oggdec.c] enter write_prelim_header 3\n");
    memcpy(headbuf, "RIFF", 4);
    WRITE_U32(headbuf+4, size-8);
    memcpy(headbuf+8, "WAVE", 4);
    memcpy(headbuf+12, "fmt ", 4);
    WRITE_U32(headbuf+16, 16);
    WRITE_U16(headbuf+20, 1); /* format */
    WRITE_U16(headbuf+22, channels);
    WRITE_U32(headbuf+24, samplerate);
    WRITE_U32(headbuf+28, bytespersec);
    WRITE_U16(headbuf+32, align);
    WRITE_U16(headbuf+34, samplesize);
    memcpy(headbuf+36, "data", 4);
    WRITE_U32(headbuf+40, size - 44);
    fprintf(stderr, "[oggdec/oggdec.c] exit write_prelim_header 3\n");

    if(fwrite(headbuf, 1, 44, out) != 44) {
        fprintf(stderr, "[oggdec/oggdec.c] enter write_prelim_header 4\n");
        fprintf(stderr, _("ERROR: Failed to write Wave header: %s\n"), strerror(errno));
        return 1;
        fprintf(stderr, "[oggdec/oggdec.c] exit write_prelim_header 4\n");
    }

    fprintf(stderr, "[oggdec/oggdec.c] enter write_prelim_header 5\n");
    return 0;
    fprintf(stderr, "[oggdec/oggdec.c] exit write_prelim_header 5\n");
}

int rewrite_header(FILE *out, unsigned int written) 
{
    fprintf(stderr, "[oggdec/oggdec.c] enter rewrite_header 1\n");
    unsigned int length = written;

    length += 44;

    WRITE_U32(headbuf+4, length-8);
    WRITE_U32(headbuf+40, length-44);
    fprintf(stderr, "[oggdec/oggdec.c] exit rewrite_header 1\n");
    if(fseek(out, 0, SEEK_SET) != 0)
    {
        fprintf(stderr, "[oggdec/oggdec.c] enter rewrite_header 2\n");
        return 1;
        fprintf(stderr, "[oggdec/oggdec.c] exit rewrite_header 2\n");
    }

    fprintf(stderr, "[oggdec/oggdec.c] enter rewrite_header 3\n");
    if(fwrite(headbuf, 1, 44, out) != 44) {
        fprintf(stderr, "[oggdec/oggdec.c] enter rewrite_header 4\n");
        fprintf(stderr, _("ERROR: Failed to write Wave header: %s\n"), strerror(errno));
        return 1;
        fprintf(stderr, "[oggdec/oggdec.c] exit rewrite_header 4\n");
    }
    return 0;
    fprintf(stderr, "[oggdec/oggdec.c] exit rewrite_header 3\n");
}

static FILE *open_input(char *infile) 
{
    fprintf(stderr, "[oggdec/oggdec.c] enter open_input 1\n");
    FILE *in;
    fprintf(stderr, "[oggdec/oggdec.c] exit open_input 1\n");

    if(!infile) {
        fprintf(stderr, "[oggdec/oggdec.c] enter open_input 2\n");
#ifdef __BORLANDC__
        setmode(fileno(stdin), O_BINARY);
#elif _WIN32
        _setmode(_fileno(stdin), _O_BINARY);
#endif
        in = stdin;
        fprintf(stderr, "[oggdec/oggdec.c] exit open_input 2\n");
    }
    else {
        fprintf(stderr, "[oggdec/oggdec.c] enter open_input 3\n");
        in = fopen(infile, "rb");
        fprintf(stderr, "[oggdec/oggdec.c] exit open_input 3\n");
        if(!in) {
            fprintf(stderr, "[oggdec/oggdec.c] enter open_input 4\n");
            fprintf(stderr, _("ERROR: Failed to open input file: %s\n"), strerror(errno));
            return NULL;
            fprintf(stderr, "[oggdec/oggdec.c] exit open_input 4\n");
        }
    }

    fprintf(stderr, "[oggdec/oggdec.c] enter open_input 5\n");
    return in;
    fprintf(stderr, "[oggdec/oggdec.c] exit open_input 5\n");
}

static FILE *open_output(char *outfile) 
{
    fprintf(stderr, "[oggdec/oggdec.c] enter open_output 1\n");
    FILE *out;
    fprintf(stderr, "[oggdec/oggdec.c] exit open_output 1\n");
    if(!outfile) {
        fprintf(stderr, "[oggdec/oggdec.c] enter open_output 2\n");
#ifdef __BORLANDC__
        setmode(fileno(stdout), O_BINARY);
#elif _WIN32
        _setmode(_fileno(stdout), _O_BINARY);
#endif
        out = stdout;
        fprintf(stderr, "[oggdec/oggdec.c] exit open_output 2\n");
    }
    else {
        fprintf(stderr, "[oggdec/oggdec.c] enter open_output 3\n");
        out = fopen(outfile, "wb");
        fprintf(stderr, "[oggdec/oggdec.c] exit open_output 3\n");
        if(!out) {
            fprintf(stderr, "[oggdec/oggdec.c] enter open_output 4\n");
            fprintf(stderr, _("ERROR: Failed to open output file: %s\n"), strerror(errno));
            return NULL;
            fprintf(stderr, "[oggdec/oggdec.c] exit open_output 4\n");
        }
    }

    fprintf(stderr, "[oggdec/oggdec.c] enter open_output 5\n");
    return out;
    fprintf(stderr, "[oggdec/oggdec.c] exit open_output 5\n");
}

static void
permute_channels(char *in, char *out, int len, int channels, int bytespersample)
{
    fprintf(stderr, "[oggdec/oggdec.c] enter permute_channels 1\n");
    int permute[6][6] = {{0}, {0,1}, {0,2,1}, {0,1,2,3}, {0,1,2,3,4}, 
        {0,2,1,5,3,4}};
    int i,j,k;
    int samples = len/channels/bytespersample;
    fprintf(stderr, "[oggdec/oggdec.c] exit permute_channels 1\n");

    /* Can't handle, don't try */
    if (channels > 6)
    {
        fprintf(stderr, "[oggdec/oggdec.c] enter permute_channels 2\n");
        return;
        fprintf(stderr, "[oggdec/oggdec.c] exit permute_channels 2\n");
    }

    fprintf(stderr, "[oggdec/oggdec.c] enter permute_channels 3\n");
    for (i=0; i < samples; i++) {
        for (j=0; j < channels; j++) {
            for (k=0; k < bytespersample; k++) {
                out[i*bytespersample*channels + 
                    bytespersample*permute[channels-1][j] + k] = 
                    in[i*bytespersample*channels + bytespersample*j + k];
            }
        }
    }
    fprintf(stderr, "[oggdec/oggdec.c] exit permute_channels 3\n");
}

static int decode_file(FILE *in, FILE *out, char *infile, char *outfile)
{
    fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 1\n");
    OggVorbis_File vf;
    int bs = 0;
    char buf[8192], outbuf[8192];
    char *p_outbuf;
    int buflen = 8192;
    unsigned int written = 0;
    int ret;
    ogg_int64_t length = 0;
    ogg_int64_t done = 0;
    int size = 0;
    int seekable = 0;
    int percent = 0;
    int channels;
    int samplerate;
    fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 1\n");

    if (ov_open_callbacks(in, &vf, NULL, 0, OV_CALLBACKS_DEFAULT) < 0) {
        fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 2\n");
        fprintf(stderr, _("ERROR: Failed to open input as Vorbis\n"));
        fclose(in);
        return 1;
        fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 2\n");
    }

    fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 3\n");
    channels = ov_info(&vf,0)->channels;
    samplerate = ov_info(&vf,0)->rate;
    fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 3\n");

    if(ov_seekable(&vf)) {
        fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 4\n");
        int link;
        int chainsallowed = 0;
        fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 4\n");
        for(link = 0; link < ov_streams(&vf); link++) {
            fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 5\n");
            if(ov_info(&vf, link)->channels == channels && 
                    ov_info(&vf, link)->rate == samplerate)
            {
                fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 6\n");
                chainsallowed = 1;
                fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 6\n");
            }
            fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 5\n");
        }

        fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 7\n");
        seekable = 1;
        fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 7\n");
        if(chainsallowed)
        {
            fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 8\n");
            length = ov_pcm_total(&vf, -1);
            fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 8\n");
        }
        else
        {
            fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 9\n");
            length = ov_pcm_total(&vf, 0);
            fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 9\n");
        }
        fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 10\n");
        size = bits/8 * channels;
        fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 10\n");
        if(!quiet)
        {
            fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 11\n");
            fprintf(stderr, _("Decoding \"%s\" to \"%s\"\n"), 
                    infile?infile:_("standard input"), 
                    outfile?outfile:_("standard output"));
            fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 11\n");
        }
    }

    if(!raw) {
        fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 12\n");
        if(write_prelim_header(&vf, out, length)) {
            fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 13\n");
            ov_clear(&vf);
            return 1;
            fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 13\n");
        }
        fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 12\n");
    }

    fprintf(stderr, "\n");
    while((ret = ov_read(&vf, buf, buflen, endian, bits/8, sign, &bs)) != 0) {
        fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 15\n");
        if(bs != 0) {
            fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 16\n");
            vorbis_info *vi = ov_info(&vf, -1);
            fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 16\n");
            if(channels != vi->channels || samplerate != vi->rate) {
                fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 17\n");
                fprintf(stderr, _("Logical bitstreams with changing parameters are not supported\n"));
                break;
                fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 17\n");
            }
        }

        if(ret == OV_HOLE) {
            fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 18\n");
            if(!quiet) {
                fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 19\n");
                fprintf(stderr, _("WARNING: hole in data (%d)\n"), ret);
                fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 19\n");
            }
            continue;
            fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 18\n");
        }
        else if(ret < 0) {
            fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 20\n");
            if(!quiet) {
                fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 21\n");
                fprintf(stderr, _("=== Vorbis library reported a stream error.\n"));
                fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 21\n");
            }
            ov_clear(&vf);
            return 1;
            fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 20\n");
        }

        if(channels > 2 && !raw) {
            fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 22\n");
            /* Then permute! */
            permute_channels(buf, outbuf, ret, channels, bits/8);
            p_outbuf = outbuf;
            fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 22\n");
        }
        else {
            fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 23\n");
            p_outbuf = buf;
            fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 23\n");
        }

        if(fwrite(p_outbuf, 1, ret, out) != ret) {
            fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 24\n");
            fprintf(stderr, _("Error writing to file: %s\n"), strerror(errno));
            ov_clear(&vf);
            return 1;
            fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 24\n");
        }

        fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 25\n");
        written += ret;
        fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 25\n");
        if(!quiet && seekable) {
            fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 26\n");
            done += ret/size;
            fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 26\n");
            if((double)done/(double)length * 200. > (double)percent) {
                fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 27\n");
                percent = (int)((double)done/(double)length *200);
                fprintf(stderr, "\r\t[%5.1f%%]", (double)percent/2.);
                fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 27\n");
            }
        }
        fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 15\n");
    }

    if(seekable && !quiet)
    {
        fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 28\n");
        fprintf(stderr, "\n");
        fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 28\n");
    }

    if(!raw)
    {
        fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 29\n");
        rewrite_header(out, written); /* We don't care if it fails, too late */
        fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 29\n");
    }

    fprintf(stderr, "[oggdec/oggdec.c] enter decode_file 30\n");
    ov_clear(&vf);

    return 0;
    fprintf(stderr, "[oggdec/oggdec.c] exit decode_file 30\n");
}

int main(int argc, char **argv)
{
    fprintf(stderr, "[oggdec/oggdec.c] enter main 1\n");
    int i;

    setlocale(LC_ALL, "");
    bindtextdomain(PACKAGE, LOCALEDIR);
    textdomain(PACKAGE);
    fprintf(stderr, "[oggdec/oggdec.c] exit main 1\n");

    if(argc == 1) {
        fprintf(stderr, "[oggdec/oggdec.c] enter main 2\n");
        usage();
        return 1;
        fprintf(stderr, "[oggdec/oggdec.c] exit main 2\n");
    }

    fprintf(stderr, "[oggdec/oggdec.c] enter main 3\n");
    parse_options(argc,argv);
    fprintf(stderr, "[oggdec/oggdec.c] exit main 3\n");

    if(!quiet)
    {
        fprintf(stderr, "[oggdec/oggdec.c] enter main 4\n");
        version();
        fprintf(stderr, "[oggdec/oggdec.c] exit main 4\n");
    }

    if(optind >= argc) {
        fprintf(stderr, "[oggdec/oggdec.c] enter main 5\n");
        fprintf(stderr, _("ERROR: No input files specified. Use -h for help\n"));
        return 1;
        fprintf(stderr, "[oggdec/oggdec.c] exit main 5\n");
    }

    if(argc - optind > 1 && outfilename && !raw) {
        fprintf(stderr, "[oggdec/oggdec.c] enter main 6\n");
        fprintf(stderr, _("ERROR: Can only specify one input file if output filename is specified\n"));
        return 1;
        fprintf(stderr, "[oggdec/oggdec.c] exit main 6\n");
    }

    if(outfilename && raw) {
        fprintf(stderr, "[oggdec/oggdec.c] enter main 7\n");
        FILE *infile, *outfile;
        char *infilename;
        fprintf(stderr, "[oggdec/oggdec.c] exit main 7\n");

        if(!strcmp(outfilename, "-")) {
            fprintf(stderr, "[oggdec/oggdec.c] enter main 8\n");
            free(outfilename);
            outfilename = NULL;
            fprintf(stderr, "[oggdec/oggdec.c] exit main 8\n");
        }
        fprintf(stderr, "[oggdec/oggdec.c] enter main 9\n");
        outfile = open_output(outfilename);
        fprintf(stderr, "[oggdec/oggdec.c] exit main 9\n");

        if(!outfile)
        {
            fprintf(stderr, "[oggdec/oggdec.c] enter main 10\n");
            return 1;
            fprintf(stderr, "[oggdec/oggdec.c] exit main 10\n");
        }

        for(i=optind; i < argc; i++) {
            fprintf(stderr, "\n");
            if(!strcmp(argv[i], "-")) {
                fprintf(stderr, "[oggdec/oggdec.c] enter main 12\n");
                infilename = NULL;
                infile = open_input(NULL);
                fprintf(stderr, "[oggdec/oggdec.c] exit main 12\n");
            }
            else {
                fprintf(stderr, "[oggdec/oggdec.c] enter main 13\n");
                infilename = argv[i];
                infile = open_input(argv[i]);
                fprintf(stderr, "[oggdec/oggdec.c] exit main 13\n");
            }

            if(!infile) {
                fprintf(stderr, "[oggdec/oggdec.c] enter main 14\n");
                fclose(outfile);
                free(outfilename);
                return 1;
                fprintf(stderr, "[oggdec/oggdec.c] exit main 14\n");
            }
            fprintf(stderr, "[oggdec/oggdec.c] enter main 15\n");
            if(decode_file(infile, outfile, infilename, outfilename)) {
                fprintf(stderr, "[oggdec/oggdec.c] enter main 16\n");
                fclose(outfile);
                return 1;
                fprintf(stderr, "[oggdec/oggdec.c] exit main 16\n");
            }
            fprintf(stderr, "[oggdec/oggdec.c] exit main 15\n");
        }

        fprintf(stderr, "[oggdec/oggdec.c] enter main 17\n");
        fclose(outfile);
        fprintf(stderr, "[oggdec/oggdec.c] exit main 17\n");
    }
    else {
        fprintf(stderr, "[oggdec/oggdec.c] enter main 18\n");
        for(i=optind; i < argc; i++) {
            fprintf(stderr, "[oggdec/oggdec.c] enter main 19\n");
            char *in, *out;
            FILE *infile, *outfile;
            fprintf(stderr, "[oggdec/oggdec.c] exit main 19\n");

            if(!strcmp(argv[i], "-"))
            {
                fprintf(stderr, "[oggdec/oggdec.c] enter main 20\n");
                in = NULL;
                fprintf(stderr, "[oggdec/oggdec.c] exit main 20\n");
            }
            else
            {
                fprintf(stderr, "[oggdec/oggdec.c] enter main 21\n");
                in = argv[i];
                fprintf(stderr, "[oggdec/oggdec.c] exit main 21\n");
            }

            if(outfilename) {
                fprintf(stderr, "[oggdec/oggdec.c] enter main 22\n");
                if(!strcmp(outfilename, "-"))
                {
                    fprintf(stderr, "[oggdec/oggdec.c] enter main 23\n");
                    out = NULL;
                    fprintf(stderr, "[oggdec/oggdec.c] exit main 23\n");
                }
                else
                {
                    fprintf(stderr, "[oggdec/oggdec.c] enter main 24\n");
                    out = outfilename;
                    fprintf(stderr, "[oggdec/oggdec.c] exit main 24\n");
                }
                fprintf(stderr, "[oggdec/oggdec.c] exit main 22\n");
            }
            else {
                fprintf(stderr, "[oggdec/oggdec.c] enter main 25\n");
                if(!strcmp(argv[i], "-")) {
                    fprintf(stderr, "[oggdec/oggdec.c] enter main 26\n");
                    out = NULL;
                    fprintf(stderr, "[oggdec/oggdec.c] exit main 26\n");
                }
                else {
                    fprintf(stderr, "[oggdec/oggdec.c] enter main 27\n");
                    char *end = strrchr(argv[i], '.');
                    end = end?end:(argv[i] + strlen(argv[i]) + 1);

                    out = malloc(strlen(argv[i]) + 10);
                    strncpy(out, argv[i], end-argv[i]);
                    out[end-argv[i]] = 0;
                    fprintf(stderr, "[oggdec/oggdec.c] exit main 27\n");
                    if(raw)
                    {
                        fprintf(stderr, "[oggdec/oggdec.c] enter main 28\n");
                        strcat(out, ".raw");
                        fprintf(stderr, "[oggdec/oggdec.c] exit main 28\n");
                    }
                    else
                    {
                        fprintf(stderr, "[oggdec/oggdec.c] enter main 29\n");
                        strcat(out, ".wav");
                        fprintf(stderr, "[oggdec/oggdec.c] exit main 29\n");
                    }
                }
                fprintf(stderr, "[oggdec/oggdec.c] exit main 25\n");
            }

            fprintf(stderr, "[oggdec/oggdec.c] enter main 30\n");
            infile = open_input(in);
            fprintf(stderr, "[oggdec/oggdec.c] exit main 30\n");
            if(!infile) {
                fprintf(stderr, "[oggdec/oggdec.c] enter main 31\n");
                if(outfilename)
                {
                    fprintf(stderr, "[oggdec/oggdec.c] enter main 32\n");
                    free(outfilename);
                    fprintf(stderr, "[oggdec/oggdec.c] exit main 32\n");
                }
                return 1;
                fprintf(stderr, "[oggdec/oggdec.c] exit main 31\n");
            }
            fprintf(stderr, "[oggdec/oggdec.c] enter main 33\n");
            outfile = open_output(out);
            fprintf(stderr, "[oggdec/oggdec.c] exit main 33\n");
            if(!outfile) {
                fprintf(stderr, "[oggdec/oggdec.c] enter main 34\n");
                fclose(infile);
                return 1;
                fprintf(stderr, "[oggdec/oggdec.c] exit main 34\n");
            }

            fprintf(stderr, "[oggdec/oggdec.c] enter main 35\n");
            if(decode_file(infile, outfile, in, out)) {
                fprintf(stderr, "[oggdec/oggdec.c] enter main 36\n");
                fclose(outfile);
                return 1;
                fprintf(stderr, "[oggdec/oggdec.c] exit main 36\n");
            }
            fprintf(stderr, "[oggdec/oggdec.c] exit main 35\n");

            if(!outfilename && out)
            {
                fprintf(stderr, "[oggdec/oggdec.c] enter main 37\n");
                free(out);
                fprintf(stderr, "[oggdec/oggdec.c] exit main 37\n");
            }

            fprintf(stderr, "[oggdec/oggdec.c] enter main 38\n");
            fclose(outfile);
            fprintf(stderr, "[oggdec/oggdec.c] exit main 38\n");
        }
        fprintf(stderr, "[oggdec/oggdec.c] exit main 18\n");
    }

    if(outfilename)
    {
        fprintf(stderr, "[oggdec/oggdec.c] enter main 39\n");
        free(outfilename);
        fprintf(stderr, "[oggdec/oggdec.c] exit main 39\n");
    }

    fprintf(stderr, "[oggdec/oggdec.c] enter main 40\n");
    return 0;
    fprintf(stderr, "[oggdec/oggdec.c] exit main 40\n");
}
// Total cost: 0.121748
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 492)]
// Total instrumented cost: 0.121748, input tokens: 6890, output tokens: 7978, cache read tokens: 6886, cache write tokens: 0

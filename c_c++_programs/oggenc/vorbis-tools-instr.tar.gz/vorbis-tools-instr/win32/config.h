#ifndef CONFIG_H
#define CONFIG_H 1

#define PACKAGE "vorbis-tools"
#define VERSION "1.4.3"

#endif /* CONFIG_H */
// Total cost: 0.001770
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 7)]
// Total instrumented cost: 0.001770, input tokens: 2392, output tokens: 23, cache read tokens: 2280, cache write tokens: 108

/* getopt_long and getopt_long_only entry points for GNU getopt.
   Copyright (C) 1987,88,89,90,91,92,93,94,96,97,98
     Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with the GNU C Library; see the file COPYING.LIB.  If not,
   write to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "getopt.h"

#if !defined __STDC__ || !__STDC__
/* This is a separate conditional since some stdc systems
   reject `defined (const)'.  */
#ifndef const
#define const
#endif
#endif

#include <stdio.h>

/* Comment out all this code if we are using the GNU C Library, and are not
   actually compiling the library itself.  This code is part of the GNU C
   Library, but also included in many other GNU distributions.  Compiling
   and linking in this code is a waste when using the GNU C library
   (especially if it is a shared library).  Rather than having every GNU
   program understand `configure --with-gnu-libc' and omit the object files,
   it is simpler to just do this in the source for each such file.  */

#define GETOPT_INTERFACE_VERSION 2
#if !defined _LIBC && defined __GLIBC__ && __GLIBC__ >= 2
#include <gnu-versions.h>
#if _GNU_GETOPT_INTERFACE_VERSION == GETOPT_INTERFACE_VERSION
#define ELIDE_CODE
#endif
#endif

#ifndef ELIDE_CODE


/* This needs to come after some library #include
   to get __GNU_LIBRARY__ defined.  */
#ifdef __GNU_LIBRARY__
#include <stdlib.h>
#endif

#ifndef	NULL
#define NULL 0
#endif

int
getopt_long (argc, argv, options, long_options, opt_index)
     int argc;
     char *const *argv;
     const char *options;
     const struct option *long_options;
     int *opt_index;
{
  fprintf(stderr, "[share/getopt1.c] enter getopt_long 1\n");
  return _getopt_internal (argc, argv, options, long_options, opt_index, 0);
  fprintf(stderr, "[share/getopt1.c] exit getopt_long 1\n");
}

/* Like getopt_long, but '-' as well as '--' can indicate a long option.
   If an option that starts with '-' (not '--') doesn't match a long option,
   but does match a short option, it is parsed as a short option
   instead.  */

int
getopt_long_only (argc, argv, options, long_options, opt_index)
     int argc;
     char *const *argv;
     const char *options;
     const struct option *long_options;
     int *opt_index;
{
  fprintf(stderr, "[share/getopt1.c] enter getopt_long_only 1\n");
  return _getopt_internal (argc, argv, options, long_options, opt_index, 1);
  fprintf(stderr, "[share/getopt1.c] exit getopt_long_only 1\n");
}


#endif	/* Not ELIDE_CODE.  */

#ifdef TEST

#include <stdio.h>

int
main (argc, argv)
     int argc;
     char **argv;
{
  fprintf(stderr, "[share/getopt1.c] enter main 1\n");
  int c;
  int digit_optind = 0;
  fprintf(stderr, "[share/getopt1.c] exit main 1\n");

  while (1)
    {
      fprintf(stderr, "[share/getopt1.c] enter main 2\n");
      int this_option_optind = optind ? optind : 1;
      int option_index = 0;
      static struct option long_options[] =
      {
	{"add", 1, 0, 0},
	{"append", 0, 0, 0},
	{"delete", 1, 0, 0},
	{"verbose", 0, 0, 0},
	{"create", 0, 0, 0},
	{"file", 1, 0, 0},
	{0, 0, 0, 0}
      };

      c = getopt_long (argc, argv, "abc:d:0123456789",
		       long_options, &option_index);
      fprintf(stderr, "[share/getopt1.c] exit main 2\n");
      
      if (c == -1)
      {
        fprintf(stderr, "[share/getopt1.c] enter main 3\n");
        break;
        fprintf(stderr, "[share/getopt1.c] exit main 3\n");
      }

      switch (c)
	{
	case 0:
	  fprintf(stderr, "[share/getopt1.c] enter main 4\n");
	  printf ("option %s", long_options[option_index].name);
	  if (optarg)
	    printf (" with arg %s", optarg);
	  printf ("\n");
	  fprintf(stderr, "[share/getopt1.c] exit main 4\n");
	  break;

	case '0':
	case '1':
	case '2':
	case '3':
	case '4':
	case '5':
	case '6':
	case '7':
	case '8':
	case '9':
	  fprintf(stderr, "[share/getopt1.c] enter main 5\n");
	  if (digit_optind != 0 && digit_optind != this_option_optind)
	    printf ("digits occur in two different argv-elements.\n");
	  digit_optind = this_option_optind;
	  printf ("option %c\n", c);
	  fprintf(stderr, "[share/getopt1.c] exit main 5\n");
	  break;

	case 'a':
	  fprintf(stderr, "[share/getopt1.c] enter main 6\n");
	  printf ("option a\n");
	  fprintf(stderr, "[share/getopt1.c] exit main 6\n");
	  break;

	case 'b':
	  fprintf(stderr, "[share/getopt1.c] enter main 7\n");
	  printf ("option b\n");
	  fprintf(stderr, "[share/getopt1.c] exit main 7\n");
	  break;

	case 'c':
	  fprintf(stderr, "[share/getopt1.c] enter main 8\n");
	  printf ("option c with value `%s'\n", optarg);
	  fprintf(stderr, "[share/getopt1.c] exit main 8\n");
	  break;

	case 'd':
	  fprintf(stderr, "[share/getopt1.c] enter main 9\n");
	  printf ("option d with value `%s'\n", optarg);
	  fprintf(stderr, "[share/getopt1.c] exit main 9\n");
	  break;

	case '?':
	  fprintf(stderr, "\n");
	  fprintf(stderr, "\n");
	  break;

	default:
	  fprintf(stderr, "[share/getopt1.c] enter main 11\n");
	  printf ("?? getopt returned character code 0%o ??\n", c);
	  fprintf(stderr, "[share/getopt1.c] exit main 11\n");
	}
    }

  if (optind < argc)
    {
      fprintf(stderr, "[share/getopt1.c] enter main 12\n");
      printf ("non-option ARGV-elements: ");
      while (optind < argc)
      {
        fprintf(stderr, "[share/getopt1.c] enter main 13\n");
	printf ("%s ", argv[optind++]);
        fprintf(stderr, "[share/getopt1.c] exit main 13\n");
      }
      printf ("\n");
      fprintf(stderr, "[share/getopt1.c] exit main 12\n");
    }

  fprintf(stderr, "[share/getopt1.c] enter main 14\n");
  exit (0);
  fprintf(stderr, "[share/getopt1.c] exit main 14\n");
}

#endif /* TEST */
// Total cost: 0.042892
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 188)]
// Total instrumented cost: 0.042892, input tokens: 3913, output tokens: 2080, cache read tokens: 2280, cache write tokens: 1629

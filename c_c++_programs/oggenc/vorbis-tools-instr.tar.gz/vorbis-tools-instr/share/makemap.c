/*
 * Copyright (C) 2001 Edmund Grimley Evans <edmundo@rano.org>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <errno.h>
#include <iconv.h>
#include <stdio.h>

int main(int argc, char *argv[])
{
  fprintf(stderr, "[share/makemap.c] enter main 1\n");
  iconv_t cd;
  const char *ib;
  char *ob;
  size_t ibl, obl, k;
  unsigned char c, buf[4];
  int i, wc;
  fprintf(stderr, "[share/makemap.c] exit main 1\n");

  if (argc != 2) {
    fprintf(stderr, "[share/makemap.c] enter main 2\n");
    printf("Usage: %s ENCODING\n", argv[0]);
    printf("Output a charset map for the 8-bit ENCODING.\n");
    return 1;
    fprintf(stderr, "[share/makemap.c] exit main 2\n");
  }

  fprintf(stderr, "[share/makemap.c] enter main 3\n");
  cd = iconv_open("UCS-4", argv[1]);
  fprintf(stderr, "[share/makemap.c] exit main 3\n");
  
  if (cd == (iconv_t)(-1)) {
    fprintf(stderr, "[share/makemap.c] enter main 4\n");
    perror("iconv_open");
    return 1;
    fprintf(stderr, "[share/makemap.c] exit main 4\n");
  }

  fprintf(stderr, "\n");
  for (i = 0; i < 256; i++) {
    fprintf(stderr, "[share/makemap.c] enter main 6\n");
    c = i;
    ib = &c;
    ibl = 1;
    ob = buf;
    obl = 4;
    k = iconv(cd, &ib, &ibl, &ob, &obl);
    fprintf(stderr, "[share/makemap.c] exit main 6\n");
    
    if (!k && !ibl && !obl) {
      fprintf(stderr, "[share/makemap.c] enter main 7\n");
      wc = (buf[0] << 24) + (buf[1] << 16) + (buf[2] << 8) + buf[3];
      fprintf(stderr, "[share/makemap.c] exit main 7\n");
      
      if (wc >= 0xffff) {
        fprintf(stderr, "[share/makemap.c] enter main 8\n");
        printf("Dodgy value.\n");
        return 1;
        fprintf(stderr, "[share/makemap.c] exit main 8\n");
      }
    }
    else if (k == (size_t)(-1) && errno == EILSEQ) {
      fprintf(stderr, "[share/makemap.c] enter main 9\n");
      wc = 0xffff;
      fprintf(stderr, "[share/makemap.c] exit main 9\n");
    }
    else {
      fprintf(stderr, "[share/makemap.c] enter main 10\n");
      printf("Non-standard iconv.\n");
      return 1;
      fprintf(stderr, "[share/makemap.c] exit main 10\n");
    }

    fprintf(stderr, "[share/makemap.c] enter main 11\n");
    if (i % 8 == 0) {
      fprintf(stderr, "[share/makemap.c] enter main 12\n");
      printf("  ");
      fprintf(stderr, "[share/makemap.c] exit main 12\n");
    }
    
    printf("0x%04x", wc);
    
    if (i == 255) {
      fprintf(stderr, "[share/makemap.c] enter main 13\n");
      printf("\n");
      fprintf(stderr, "[share/makemap.c] exit main 13\n");
    }
    else if (i % 8 == 7) {
      fprintf(stderr, "[share/makemap.c] enter main 14\n");
      printf(",\n");
      fprintf(stderr, "[share/makemap.c] exit main 14\n");
    }
    else {
      fprintf(stderr, "[share/makemap.c] enter main 15\n");
      printf(", ");
      fprintf(stderr, "[share/makemap.c] exit main 15\n");
    }
    fprintf(stderr, "[share/makemap.c] exit main 11\n");
  }

  fprintf(stderr, "[share/makemap.c] enter main 16\n");
  return 0;
  fprintf(stderr, "[share/makemap.c] exit main 16\n");
}
// Total cost: 0.024796
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 81)]
// Total instrumented cost: 0.024796, input tokens: 3101, output tokens: 1239, cache read tokens: 2280, cache write tokens: 817

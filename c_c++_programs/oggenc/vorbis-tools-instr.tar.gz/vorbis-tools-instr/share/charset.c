/*
 * Copyright (C) 2001 Edmund Grimley Evans <edmundo@rano.org>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/*
 * See the corresponding header file for a description of the functions
 * that this file provides.
 *
 * This was first written for Ogg Vorbis but could be of general use.
 *
 * The only deliberate assumption about data sizes is that a short has
 * at least 16 bits, but this code has only been tested on systems with
 * 8-bit char, 16-bit short and 32-bit int.
 */

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#ifndef HAVE_ICONV /* should be ifdef USE_CHARSET_CONVERT */

#include <stdlib.h>
#include <stdio.h>

#include "charset.h"

#include "charmaps.h"

/*
 * This is like the standard strcasecmp, but it does not depend
 * on the locale. Locale-dependent functions can be dangerous:
 * we once had a bug involving strcasecmp("iso", "ISO") in a
 * Turkish locale!
 *
 * (I'm not really sure what the official standard says
 * about the sign of strcasecmp("Z", "["), but usually
 * we're only interested in whether it's zero.)
 */

static int ascii_strcasecmp(const char *s1, const char *s2)
{
  fprintf(stderr, "[share/charset.c] enter ascii_strcasecmp 1\n");
  char c1, c2;

  for (;; s1++, s2++) {
    fprintf(stderr, "[share/charset.c] enter ascii_strcasecmp 2\n");
    if (!*s1 || !*s2)
      break;
    if (*s1 == *s2)
      continue;
    c1 = *s1;
    if ('a' <= c1 && c1 <= 'z')
      c1 += 'A' - 'a';
    c2 = *s2;
    if ('a' <= c2 && c2 <= 'z')
      c2 += 'A' - 'a';
    if (c1 != c2)
      break;
    fprintf(stderr, "[share/charset.c] exit ascii_strcasecmp 2\n");
  }
  fprintf(stderr, "[share/charset.c] enter ascii_strcasecmp 3\n");
  return (unsigned char)*s1 - (unsigned char)*s2;
  fprintf(stderr, "[share/charset.c] exit ascii_strcasecmp 3\n");
  fprintf(stderr, "[share/charset.c] exit ascii_strcasecmp 1\n");
}

/*
 * UTF-8 equivalents of the C library's wctomb() and mbtowc().
 */

int utf8_mbtowc(int *pwc, const char *s, size_t n)
{
  fprintf(stderr, "[share/charset.c] enter utf8_mbtowc 1\n");
  unsigned char c;
  int wc, i, k;

  if (!n || !s)
  {
    fprintf(stderr, "[share/charset.c] enter utf8_mbtowc 2\n");
    return 0;
    fprintf(stderr, "[share/charset.c] exit utf8_mbtowc 2\n");
  }

  c = *s;
  if (c < 0x80) {
    fprintf(stderr, "[share/charset.c] enter utf8_mbtowc 3\n");
    if (pwc)
      *pwc = c;
    return c ? 1 : 0;
    fprintf(stderr, "[share/charset.c] exit utf8_mbtowc 3\n");
  }
  else if (c < 0xc2)
  {
    fprintf(stderr, "[share/charset.c] enter utf8_mbtowc 4\n");
    return -1;
    fprintf(stderr, "[share/charset.c] exit utf8_mbtowc 4\n");
  }
  else if (c < 0xe0) {
    fprintf(stderr, "[share/charset.c] enter utf8_mbtowc 5\n");
    if (n >= 2 && (s[1] & 0xc0) == 0x80) {
      fprintf(stderr, "[share/charset.c] enter utf8_mbtowc 6\n");
      if (pwc)
	*pwc = ((c & 0x1f) << 6) | (s[1] & 0x3f);
      return 2;
      fprintf(stderr, "[share/charset.c] exit utf8_mbtowc 6\n");
    }
    else
    {
      fprintf(stderr, "[share/charset.c] enter utf8_mbtowc 7\n");
      return -1;
      fprintf(stderr, "[share/charset.c] exit utf8_mbtowc 7\n");
    }
    fprintf(stderr, "[share/charset.c] exit utf8_mbtowc 5\n");
  }
  else if (c < 0xf0)
  {
    fprintf(stderr, "[share/charset.c] enter utf8_mbtowc 8\n");
    k = 3;
    fprintf(stderr, "[share/charset.c] exit utf8_mbtowc 8\n");
  }
  else if (c < 0xf8)
  {
    fprintf(stderr, "[share/charset.c] enter utf8_mbtowc 9\n");
    k = 4;
    fprintf(stderr, "[share/charset.c] exit utf8_mbtowc 9\n");
  }
  else if (c < 0xfc)
  {
    fprintf(stderr, "[share/charset.c] enter utf8_mbtowc 10\n");
    k = 5;
    fprintf(stderr, "[share/charset.c] exit utf8_mbtowc 10\n");
  }
  else if (c < 0xfe)
  {
    fprintf(stderr, "[share/charset.c] enter utf8_mbtowc 11\n");
    k = 6;
    fprintf(stderr, "[share/charset.c] exit utf8_mbtowc 11\n");
  }
  else
  {
    fprintf(stderr, "[share/charset.c] enter utf8_mbtowc 12\n");
    return -1;
    fprintf(stderr, "[share/charset.c] exit utf8_mbtowc 12\n");
  }

  fprintf(stderr, "[share/charset.c] enter utf8_mbtowc 13\n");
  if (n < k)
  {
    fprintf(stderr, "[share/charset.c] enter utf8_mbtowc 14\n");
    return -1;
    fprintf(stderr, "[share/charset.c] exit utf8_mbtowc 14\n");
  }
  wc = *s++ & ((1 << (7 - k)) - 1);
  for (i = 1; i < k; i++) {
    fprintf(stderr, "[share/charset.c] enter utf8_mbtowc 15\n");
    if ((*s & 0xc0) != 0x80)
    {
      fprintf(stderr, "[share/charset.c] enter utf8_mbtowc 16\n");
      return -1;
      fprintf(stderr, "[share/charset.c] exit utf8_mbtowc 16\n");
    }
    wc = (wc << 6) | (*s++ & 0x3f);
    fprintf(stderr, "[share/charset.c] exit utf8_mbtowc 15\n");
  }
  if (wc < (1 << (5 * k - 4)))
  {
    fprintf(stderr, "[share/charset.c] enter utf8_mbtowc 17\n");
    return -1;
    fprintf(stderr, "[share/charset.c] exit utf8_mbtowc 17\n");
  }
  if (pwc)
    *pwc = wc;
  return k;
  fprintf(stderr, "[share/charset.c] exit utf8_mbtowc 13\n");
  fprintf(stderr, "[share/charset.c] exit utf8_mbtowc 1\n");
}

int utf8_wctomb(char *s, int wc1)
{
  fprintf(stderr, "[share/charset.c] enter utf8_wctomb 1\n");
  unsigned int wc = wc1;

  if (!s)
  {
    fprintf(stderr, "[share/charset.c] enter utf8_wctomb 2\n");
    return 0;
    fprintf(stderr, "[share/charset.c] exit utf8_wctomb 2\n");
  }
  if (wc < (1 << 7)) {
    fprintf(stderr, "[share/charset.c] enter utf8_wctomb 3\n");
    *s++ = wc;
    return 1;
    fprintf(stderr, "[share/charset.c] exit utf8_wctomb 3\n");
  }
  else if (wc < (1 << 11)) {
    fprintf(stderr, "[share/charset.c] enter utf8_wctomb 4\n");
    *s++ = 0xc0 | (wc >> 6);
    *s++ = 0x80 | (wc & 0x3f);
    return 2;
    fprintf(stderr, "[share/charset.c] exit utf8_wctomb 4\n");
  }
  else if (wc < (1 << 16)) {
    fprintf(stderr, "[share/charset.c] enter utf8_wctomb 5\n");
    *s++ = 0xe0 | (wc >> 12);
    *s++ = 0x80 | ((wc >> 6) & 0x3f);
    *s++ = 0x80 | (wc & 0x3f);
    return 3;
    fprintf(stderr, "[share/charset.c] exit utf8_wctomb 5\n");
  }
  else if (wc < (1 << 21)) {
    fprintf(stderr, "[share/charset.c] enter utf8_wctomb 6\n");
    *s++ = 0xf0 | (wc >> 18);
    *s++ = 0x80 | ((wc >> 12) & 0x3f);
    *s++ = 0x80 | ((wc >> 6) & 0x3f);
    *s++ = 0x80 | (wc & 0x3f);
    return 4;
    fprintf(stderr, "[share/charset.c] exit utf8_wctomb 6\n");
  }
  else if (wc < (1 << 26)) {
    fprintf(stderr, "[share/charset.c] enter utf8_wctomb 7\n");
    *s++ = 0xf8 | (wc >> 24);
    *s++ = 0x80 | ((wc >> 18) & 0x3f);
    *s++ = 0x80 | ((wc >> 12) & 0x3f);
    *s++ = 0x80 | ((wc >> 6) & 0x3f);
    *s++ = 0x80 | (wc & 0x3f);
    return 5;
    fprintf(stderr, "[share/charset.c] exit utf8_wctomb 7\n");
  }
  else if (wc < (1 << 31)) {
    fprintf(stderr, "[share/charset.c] enter utf8_wctomb 8\n");
    *s++ = 0xfc | (wc >> 30);
    *s++ = 0x80 | ((wc >> 24) & 0x3f);
    *s++ = 0x80 | ((wc >> 18) & 0x3f);
    *s++ = 0x80 | ((wc >> 12) & 0x3f);
    *s++ = 0x80 | ((wc >> 6) & 0x3f);
    *s++ = 0x80 | (wc & 0x3f);
    return 6;
    fprintf(stderr, "[share/charset.c] exit utf8_wctomb 8\n");
  }
  else
  {
    fprintf(stderr, "[share/charset.c] enter utf8_wctomb 9\n");
    return -1;
    fprintf(stderr, "[share/charset.c] exit utf8_wctomb 9\n");
  }
  fprintf(stderr, "[share/charset.c] exit utf8_wctomb 1\n");
}

/*
 * The charset "object" and methods.
 */

struct charset {
  int max;
  int (*mbtowc)(void *table, int *pwc, const char *s, size_t n);
  int (*wctomb)(void *table, char *s, int wc);
  void *map;
};

int charset_mbtowc(struct charset *charset, int *pwc, const char *s, size_t n)
{
  fprintf(stderr, "[share/charset.c] enter charset_mbtowc 1\n");
  return (*charset->mbtowc)(charset->map, pwc, s, n);
  fprintf(stderr, "[share/charset.c] exit charset_mbtowc 1\n");
}

int charset_wctomb(struct charset *charset, char *s, int wc)
{
  fprintf(stderr, "[share/charset.c] enter charset_wctomb 1\n");
  return (*charset->wctomb)(charset->map, s, wc);
  fprintf(stderr, "[share/charset.c] exit charset_wctomb 1\n");
}

int charset_max(struct charset *charset)
{
  fprintf(stderr, "[share/charset.c] enter charset_max 1\n");
  return charset->max;
  fprintf(stderr, "[share/charset.c] exit charset_max 1\n");
}

/*
 * Implementation of UTF-8.
 */

static int mbtowc_utf8(void *map, int *pwc, const char *s, size_t n)
{
  fprintf(stderr, "[share/charset.c] enter mbtowc_utf8 1\n");
  return utf8_mbtowc(pwc, s, n);
  fprintf(stderr, "[share/charset.c] exit mbtowc_utf8 1\n");
}

static int wctomb_utf8(void *map, char *s, int wc)
{
  fprintf(stderr, "[share/charset.c] enter wctomb_utf8 1\n");
  return utf8_wctomb(s, wc);
  fprintf(stderr, "[share/charset.c] exit wctomb_utf8 1\n");
}

/*
 * Implementation of US-ASCII.
 * Probably on most architectures this compiles to less than 256 bytes
 * of code, so we can save space by not having a table for this one.
 */

static int mbtowc_ascii(void *map, int *pwc, const char *s, size_t n)
{
  fprintf(stderr, "[share/charset.c] enter mbtowc_ascii 1\n");
  int wc;

  if (!n || !s)
  {
    fprintf(stderr, "[share/charset.c] enter mbtowc_ascii 2\n");
    return 0;
    fprintf(stderr, "[share/charset.c] exit mbtowc_ascii 2\n");
  }
  wc = (unsigned char)*s;
  if (wc & ~0x7f)
  {
    fprintf(stderr, "[share/charset.c] enter mbtowc_ascii 3\n");
    return -1;
    fprintf(stderr, "[share/charset.c] exit mbtowc_ascii 3\n");
  }
  if (pwc)
    *pwc = wc;
  return wc ? 1 : 0;
  fprintf(stderr, "[share/charset.c] exit mbtowc_ascii 1\n");
}

static int wctomb_ascii(void *map, char *s, int wc)
{
  fprintf(stderr, "[share/charset.c] enter wctomb_ascii 1\n");
  if (!s)
  {
    fprintf(stderr, "[share/charset.c] enter wctomb_ascii 2\n");
    return 0;
    fprintf(stderr, "[share/charset.c] exit wctomb_ascii 2\n");
  }
  if (wc & ~0x7f)
  {
    fprintf(stderr, "[share/charset.c] enter wctomb_ascii 3\n");
    return -1;
    fprintf(stderr, "[share/charset.c] exit wctomb_ascii 3\n");
  }
  *s = wc;
  return 1;
  fprintf(stderr, "[share/charset.c] exit wctomb_ascii 1\n");
}

/*
 * Implementation of ISO-8859-1.
 * Probably on most architectures this compiles to less than 256 bytes
 * of code, so we can save space by not having a table for this one.
 */

static int mbtowc_iso1(void *map, int *pwc, const char *s, size_t n)
{
  fprintf(stderr, "[share/charset.c] enter mbtowc_iso1 1\n");
  int wc;

  if (!n || !s)
  {
    fprintf(stderr, "[share/charset.c] enter mbtowc_iso1 2\n");
    return 0;
    fprintf(stderr, "[share/charset.c] exit mbtowc_iso1 2\n");
  }
  wc = (unsigned char)*s;
  if (wc & ~0xff)
  {
    fprintf(stderr, "[share/charset.c] enter mbtowc_iso1 3\n");
    return -1;
    fprintf(stderr, "[share/charset.c] exit mbtowc_iso1 3\n");
  }
  if (pwc)
    *pwc = wc;
  return wc ? 1 : 0;
  fprintf(stderr, "[share/charset.c] exit mbtowc_iso1 1\n");
}

static int wctomb_iso1(void *map, char *s, int wc)
{
  fprintf(stderr, "[share/charset.c] enter wctomb_iso1 1\n");
  if (!s)
  {
    fprintf(stderr, "[share/charset.c] enter wctomb_iso1 2\n");
    return 0;
    fprintf(stderr, "[share/charset.c] exit wctomb_iso1 2\n");
  }
  if (wc & ~0xff)
  {
    fprintf(stderr, "[share/charset.c] enter wctomb_iso1 3\n");
    return -1;
    fprintf(stderr, "[share/charset.c] exit wctomb_iso1 3\n");
  }
  *s = wc;
  return 1;
  fprintf(stderr, "[share/charset.c] exit wctomb_iso1 1\n");
}

/*
 * Implementation of any 8-bit charset.
 */

struct map {
  const unsigned short *from;
  struct inverse_map *to;
};

static int mbtowc_8bit(void *map1, int *pwc, const char *s, size_t n)
{
  fprintf(stderr, "[share/charset.c] enter mbtowc_8bit 1\n");
  struct map *map = map1;
  unsigned short wc;

  if (!n || !s)
  {
    fprintf(stderr, "[share/charset.c] enter mbtowc_8bit 2\n");
    return 0;
    fprintf(stderr, "[share/charset.c] exit mbtowc_8bit 2\n");
  }
  wc = map->from[(unsigned char)*s];
  if (wc == 0xffff)
  {
    fprintf(stderr, "[share/charset.c] enter mbtowc_8bit 3\n");
    return -1;
    fprintf(stderr, "[share/charset.c] exit mbtowc_8bit 3\n");
  }
  if (pwc)
    *pwc = (int)wc;
  return wc ? 1 : 0;
  fprintf(stderr, "[share/charset.c] exit mbtowc_8bit 1\n");
}

/*
 * For the inverse map we use a hash table, which has the advantages
 * of small constant memory requirement and simple memory allocation,
 * but the disadvantage of slow conversion in the worst case.
 * If you need real-time performance while letting a potentially
 * malicious user define their own map, then the method used in
 * linux/drivers/char/consolemap.c would be more appropriate.
 */

struct inverse_map {
  unsigned char first[256];
  unsigned char next[256];
};

/*
 * The simple hash is good enough for this application.
 * Use the alternative trivial hashes for testing.
 */
#define HASH(i) ((i) & 0xff)
/* #define HASH(i) 0 */
/* #define HASH(i) 99 */

static struct inverse_map *make_inverse_map(const unsigned short *from)
{
  fprintf(stderr, "[share/charset.c] enter make_inverse_map 1\n");
  struct inverse_map *to;
  char used[256];
  int i, j, k;

  to = (struct inverse_map *)malloc(sizeof(struct inverse_map));
  if (!to)
  {
    fprintf(stderr, "[share/charset.c] enter make_inverse_map 2\n");
    return 0;
    fprintf(stderr, "[share/charset.c] exit make_inverse_map 2\n");
  }
  fprintf(stderr, "[share/charset.c] enter make_inverse_map 3\n");
  for (i = 0; i < 256; i++)
    to->first[i] = to->next[i] = used[i] = 0;
  fprintf(stderr, "[share/charset.c] exit make_inverse_map 3\n");
  
  fprintf(stderr, "[share/charset.c] enter make_inverse_map 4\n");
  for (i = 255; i >= 0; i--)
    if (from[i] != 0xffff) {
      fprintf(stderr, "[share/charset.c] enter make_inverse_map 5\n");
      k = HASH(from[i]);
      to->next[i] = to->first[k];
      to->first[k] = i;
      used[k] = 1;
      fprintf(stderr, "[share/charset.c] exit make_inverse_map 5\n");
    }
  fprintf(stderr, "[share/charset.c] exit make_inverse_map 4\n");

  /* Point the empty buckets at an empty list. */
  fprintf(stderr, "[share/charset.c] enter make_inverse_map 6\n");
  for (i = 0; i < 256; i++)
    if (!to->next[i])
      break;
  fprintf(stderr, "[share/charset.c] exit make_inverse_map 6\n");
  
  fprintf(stderr, "[share/charset.c] enter make_inverse_map 7\n");
  if (i < 256)
    for (j = 0; j < 256; j++)
      if (!used[j])
	to->first[j] = i;
  fprintf(stderr, "[share/charset.c] exit make_inverse_map 7\n");

  return to;
  fprintf(stderr, "[share/charset.c] exit make_inverse_map 1\n");
}

int wctomb_8bit(void *map1, char *s, int wc1)
{
  fprintf(stderr, "[share/charset.c] enter wctomb_8bit 1\n");
  struct map *map = map1;
  unsigned short wc = wc1;
  int i;

  if (!s)
  {
    fprintf(stderr, "[share/charset.c] enter wctomb_8bit 2\n");
    return 0;
    fprintf(stderr, "[share/charset.c] exit wctomb_8bit 2\n");
  }

  if (wc1 & ~0xffff)
  {
    fprintf(stderr, "[share/charset.c] enter wctomb_8bit 3\n");
    return -1;
    fprintf(stderr, "[share/charset.c] exit wctomb_8bit 3\n");
  }

  if (1) /* Change 1 to 0 to test the case where malloc fails. */
    if (!map->to)
    {
      fprintf(stderr, "[share/charset.c] enter wctomb_8bit 4\n");
      map->to = make_inverse_map(map->from);
      fprintf(stderr, "[share/charset.c] exit wctomb_8bit 4\n");
    }

  if (map->to) {
    fprintf(stderr, "[share/charset.c] enter wctomb_8bit 5\n");
    /* Use the inverse map. */
    i = map->to->first[HASH(wc)];
    for (;;) {
      fprintf(stderr, "[share/charset.c] enter wctomb_8bit 6\n");
      if (map->from[i] == wc) {
        fprintf(stderr, "[share/charset.c] enter wctomb_8bit 7\n");
        *s = i;
        return 1;
        fprintf(stderr, "[share/charset.c] exit wctomb_8bit 7\n");
      }
      if (!(i = map->to->next[i]))
        break;
      fprintf(stderr, "[share/charset.c] exit wctomb_8bit 6\n");
    }
    fprintf(stderr, "[share/charset.c] exit wctomb_8bit 5\n");
  }
  else {
    fprintf(stderr, "[share/charset.c] enter wctomb_8bit 8\n");
    /* We don't have an inverse map, so do a linear search. */
    for (i = 0; i < 256; i++)
      if (map->from[i] == wc) {
        fprintf(stderr, "[share/charset.c] enter wctomb_8bit 9\n");
        *s = i;
        return 1;
        fprintf(stderr, "[share/charset.c] exit wctomb_8bit 9\n");
      }
    fprintf(stderr, "[share/charset.c] exit wctomb_8bit 8\n");
  }

  fprintf(stderr, "[share/charset.c] enter wctomb_8bit 10\n");
  return -1;
  fprintf(stderr, "[share/charset.c] exit wctomb_8bit 10\n");
  fprintf(stderr, "[share/charset.c] exit wctomb_8bit 1\n");
}

/*
 * The "constructor" charset_find().
 */

struct charset charset_utf8 = {
  6,
  &mbtowc_utf8,
  &wctomb_utf8,
  0
};

struct charset charset_iso1 = {
  1,
  &mbtowc_iso1,
  &wctomb_iso1,
  0
};

struct charset charset_ascii = {
  1,
  &mbtowc_ascii,
  &wctomb_ascii,
  0
};

struct charset *charset_find(const char *code)
{
  fprintf(stderr, "[share/charset.c] enter charset_find 1\n");
  int i;

  /* Find good (MIME) name. */
  fprintf(stderr, "[share/charset.c] enter charset_find 2\n");
  for (i = 0; names[i].bad; i++)
    if (!ascii_strcasecmp(code, names[i].bad)) {
      fprintf(stderr, "[share/charset.c] enter charset_find 3\n");
      code = names[i].good;
      break;
      fprintf(stderr, "[share/charset.c] exit charset_find 3\n");
    }
  fprintf(stderr, "[share/charset.c] exit charset_find 2\n");

  /* Recognise some charsets for which we avoid using a table. */
  if (!ascii_strcasecmp(code, "UTF-8"))
  {
    fprintf(stderr, "[share/charset.c] enter charset_find 4\n");
    return &charset_utf8;
    fprintf(stderr, "[share/charset.c] exit charset_find 4\n");
  }
  if (!ascii_strcasecmp(code, "US-ASCII"))
  {
    fprintf(stderr, "[share/charset.c] enter charset_find 5\n");
    return &charset_ascii;
    fprintf(stderr, "[share/charset.c] exit charset_find 5\n");
  }
  if (!ascii_strcasecmp(code, "ISO-8859-1"))
  {
    fprintf(stderr, "[share/charset.c] enter charset_find 6\n");
    return &charset_iso1;
    fprintf(stderr, "[share/charset.c] exit charset_find 6\n");
  }

  /* Look for a mapping for a simple 8-bit encoding. */
  fprintf(stderr, "[share/charset.c] enter charset_find 7\n");
  for (i = 0; maps[i].name; i++)
    if (!ascii_strcasecmp(code, maps[i].name)) {
      fprintf(stderr, "[share/charset.c] enter charset_find 8\n");
      if (!maps[i].charset) {
        fprintf(stderr, "[share/charset.c] enter charset_find 9\n");
        maps[i].charset = (struct charset *)malloc(sizeof(struct charset));
        if (maps[i].charset) {
          fprintf(stderr, "[share/charset.c] enter charset_find 10\n");
          struct map *map = (struct map *)malloc(sizeof(struct map));
          if (!map) {
            fprintf(stderr, "[share/charset.c] enter charset_find 11\n");
            free(maps[i].charset);
            maps[i].charset = 0;
            fprintf(stderr, "[share/charset.c] exit charset_find 11\n");
          }
          else {
            fprintf(stderr, "[share/charset.c] enter charset_find 12\n");
            maps[i].charset->max = 1;
            maps[i].charset->mbtowc = &mbtowc_8bit;
            maps[i].charset->wctomb = &wctomb_8bit;
            maps[i].charset->map = map;
            map->from = maps[i].map;
            map->to = 0; /* inverse mapping is created when required */
            fprintf(stderr, "[share/charset.c] exit charset_find 12\n");
          }
          fprintf(stderr, "[share/charset.c] exit charset_find 10\n");
        }
        fprintf(stderr, "[share/charset.c] exit charset_find 9\n");
      }
      return maps[i].charset;
      fprintf(stderr, "[share/charset.c] exit charset_find 8\n");
    }
  fprintf(stderr, "[share/charset.c] exit charset_find 7\n");

  fprintf(stderr, "[share/charset.c] enter charset_find 13\n");
  return 0;
  fprintf(stderr, "[share/charset.c] exit charset_find 13\n");
  fprintf(stderr, "[share/charset.c] exit charset_find 1\n");
}

/*
 * Function to convert a buffer from one encoding to another.
 * Invalid bytes are replaced by '#', and characters that are
 * not available in the target encoding are replaced by '?'.
 * Each of TO and TOLEN may be zero, if the result is not needed.
 * The output buffer is null-terminated, so it is all right to
 * use charset_convert(fromcode, tocode, s, strlen(s), &t, 0).
 */

int charset_convert(const char *fromcode, const char *tocode,
		    const char *from, size_t fromlen,
		    char **to, size_t *tolen)
{
  fprintf(stderr, "[share/charset.c] enter charset_convert 1\n");
  int ret = 0;
  struct charset *charset1, *charset2;
  char *tobuf, *p, *newbuf;
  int i, j, wc;

  charset1 = charset_find(fromcode);
  charset2 = charset_find(tocode);
  if (!charset1 || !charset2 )
  {
    fprintf(stderr, "[share/charset.c] enter charset_convert 2\n");
    return -1;
    fprintf(stderr, "[share/charset.c] exit charset_convert 2\n");
  }

  tobuf = (char *)malloc(fromlen * charset2->max + 1);
  if (!tobuf)
  {
    fprintf(stderr, "[share/charset.c] enter charset_convert 3\n");
    return -2;
    fprintf(stderr, "[share/charset.c] exit charset_convert 3\n");
  }

  fprintf(stderr, "[share/charset.c] enter charset_convert 4\n");
  for (p = tobuf; fromlen; from += i, fromlen -= i, p += j) {
    fprintf(stderr, "[share/charset.c] enter charset_convert 5\n");
    i = charset_mbtowc(charset1, &wc, from, fromlen);
    if (!i)
    {
      fprintf(stderr, "[share/charset.c] enter charset_convert 6\n");
      i = 1;
      fprintf(stderr, "[share/charset.c] exit charset_convert 6\n");
    }
    else if (i == -1) {
      fprintf(stderr, "[share/charset.c] enter charset_convert 7\n");
      i  = 1;
      wc = '#';
      ret = 2;
      fprintf(stderr, "[share/charset.c] exit charset_convert 7\n");
    }
    j = charset_wctomb(charset2, p, wc);
    if (j == -1) {
      fprintf(stderr, "[share/charset.c] enter charset_convert 8\n");
      if (!ret)
        ret = 1;
      j = charset_wctomb(charset2, p, '?');
      if (j == -1)
        j = 0;
      fprintf(stderr, "[share/charset.c] exit charset_convert 8\n");
    }
    fprintf(stderr, "[share/charset.c] exit charset_convert 5\n");
  }
  fprintf(stderr, "[share/charset.c] exit charset_convert 4\n");

  fprintf(stderr, "[share/charset.c] enter charset_convert 9\n");
  if (tolen)
    *tolen = p - tobuf;
  *p++ = '\0';
  if (to) {
    fprintf(stderr, "[share/charset.c] enter charset_convert 10\n");
    newbuf = realloc(tobuf, p - tobuf);
    *to = newbuf ? newbuf : tobuf;
    fprintf(stderr, "[share/charset.c] exit charset_convert 10\n");
  }
  else
  {
    fprintf(stderr, "[share/charset.c] enter charset_convert 11\n");
    free(tobuf);
    fprintf(stderr, "[share/charset.c] exit charset_convert 11\n");
  }

  return ret;
  fprintf(stderr, "[share/charset.c] exit charset_convert 9\n");
  fprintf(stderr, "[share/charset.c] exit charset_convert 1\n");
}

#endif /* USE_CHARSET_ICONV */
// Total cost: 0.158706
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 525)]
// Total instrumented cost: 0.158706, input tokens: 7164, output tokens: 8338, cache read tokens: 2280, cache write tokens: 4880

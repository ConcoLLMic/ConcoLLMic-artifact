/*
 * Copyright (C) 2021 Philipp Schafft <lion@lion.leolix.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>

#include "base64.h"
#include "picture.h"

const char * flac_picture_type_string(flac_picture_type type)
{
    switch (type) {
        case FLAC_PICTURE_OTHER:
            fprintf(stderr, "[share/picture.c] enter flac_picture_type_string 1\n");
            return "Other";
            fprintf(stderr, "[share/picture.c] exit flac_picture_type_string 1\n");
            break;
        case FLAC_PICTURE_FILE_ICON:
            fprintf(stderr, "[share/picture.c] enter flac_picture_type_string 2\n");
            return "32x32 pixels file icon (PNG)";
            fprintf(stderr, "[share/picture.c] exit flac_picture_type_string 2\n");
            break;
        case FLAC_PICTURE_OTHER_FILE_ICON:
            fprintf(stderr, "[share/picture.c] enter flac_picture_type_string 3\n");
            return "Other file icon";
            fprintf(stderr, "[share/picture.c] exit flac_picture_type_string 3\n");
            break;
        case FLAC_PICTURE_COVER_FRONT:
            fprintf(stderr, "[share/picture.c] enter flac_picture_type_string 4\n");
            return "Cover (front)";
            fprintf(stderr, "[share/picture.c] exit flac_picture_type_string 4\n");
            break;
        case FLAC_PICTURE_COVER_BACK:
            fprintf(stderr, "[share/picture.c] enter flac_picture_type_string 5\n");
            return "Cover (back)";
            fprintf(stderr, "[share/picture.c] exit flac_picture_type_string 5\n");
            break;
        case FLAC_PICTURE_LEAFLET_PAGE:
            fprintf(stderr, "[share/picture.c] enter flac_picture_type_string 6\n");
            return "Leaflet page";
            fprintf(stderr, "[share/picture.c] exit flac_picture_type_string 6\n");
            break;
        case FLAC_PICTURE_MEDIA:
            fprintf(stderr, "[share/picture.c] enter flac_picture_type_string 7\n");
            return "Media";
            fprintf(stderr, "[share/picture.c] exit flac_picture_type_string 7\n");
            break;
        case FLAC_PICTURE_LEAD:
            fprintf(stderr, "[share/picture.c] enter flac_picture_type_string 8\n");
            return "Lead artist/lead performer/soloist";
            fprintf(stderr, "[share/picture.c] exit flac_picture_type_string 8\n");
            break;
        case FLAC_PICTURE_ARTIST:
            fprintf(stderr, "[share/picture.c] enter flac_picture_type_string 9\n");
            return "Artist/performer";
            fprintf(stderr, "[share/picture.c] exit flac_picture_type_string 9\n");
            break;
        case FLAC_PICTURE_CONDUCTOR:
            fprintf(stderr, "[share/picture.c] enter flac_picture_type_string 10\n");
            return "Conductor";
            fprintf(stderr, "[share/picture.c] exit flac_picture_type_string 10\n");
            break;
        case FLAC_PICTURE_BAND:
            fprintf(stderr, "[share/picture.c] enter flac_picture_type_string 11\n");
            return "Band/Orchestra";
            fprintf(stderr, "[share/picture.c] exit flac_picture_type_string 11\n");
            break;
        case FLAC_PICTURE_COMPOSER:
            fprintf(stderr, "[share/picture.c] enter flac_picture_type_string 12\n");
            return "Composer";
            fprintf(stderr, "[share/picture.c] exit flac_picture_type_string 12\n");
            break;
        case FLAC_PICTURE_LYRICIST:
            fprintf(stderr, "[share/picture.c] enter flac_picture_type_string 13\n");
            return "Lyricist/text writer";
            fprintf(stderr, "[share/picture.c] exit flac_picture_type_string 13\n");
            break;
        case FLAC_PICTURE_RECORDING_LOCATION:
            fprintf(stderr, "[share/picture.c] enter flac_picture_type_string 14\n");
            return "Recording Location";
            fprintf(stderr, "[share/picture.c] exit flac_picture_type_string 14\n");
            break;
        case FLAC_PICTURE_DURING_RECORDING:
            fprintf(stderr, "[share/picture.c] enter flac_picture_type_string 15\n");
            return "During recording";
            fprintf(stderr, "[share/picture.c] exit flac_picture_type_string 15\n");
            break;
        case FLAC_PICTURE_DURING_PREFORMANCE:
            fprintf(stderr, "[share/picture.c] enter flac_picture_type_string 16\n");
            return "During performance";
            fprintf(stderr, "[share/picture.c] exit flac_picture_type_string 16\n");
            break;
        case FLAC_PICTURE_SCREEN_CAPTURE:
            fprintf(stderr, "[share/picture.c] enter flac_picture_type_string 17\n");
            return "Movie/video screen capture";
            fprintf(stderr, "[share/picture.c] exit flac_picture_type_string 17\n");
            break;
        case FLAC_PICTURE_A_BRIGHT_COLOURED_FISH:
            fprintf(stderr, "[share/picture.c] enter flac_picture_type_string 18\n");
            return "A bright coloured fish";
            fprintf(stderr, "[share/picture.c] exit flac_picture_type_string 18\n");
            break;
        case FLAC_PICTURE_ILLUSTRATION:
            fprintf(stderr, "[share/picture.c] enter flac_picture_type_string 19\n");
            return "Illustration";
            fprintf(stderr, "[share/picture.c] exit flac_picture_type_string 19\n");
            break;
        case FLAC_PICTURE_BAND_LOGOTYPE:
            fprintf(stderr, "[share/picture.c] enter flac_picture_type_string 20\n");
            return "Band/artist logotype";
            fprintf(stderr, "[share/picture.c] exit flac_picture_type_string 20\n");
            break;
        case FLAC_PICTURE_PUBLISHER_LOGOTYPE:
            fprintf(stderr, "[share/picture.c] enter flac_picture_type_string 21\n");
            return "Publisher/Studio logotype";
            fprintf(stderr, "[share/picture.c] exit flac_picture_type_string 21\n");
            break;
        default:
            fprintf(stderr, "[share/picture.c] enter flac_picture_type_string 22\n");
            return "<unknown>";
            fprintf(stderr, "[share/picture.c] exit flac_picture_type_string 22\n");
            break;
    }
}

static uint32_t read32be(unsigned char *buf)
{
    fprintf(stderr, "[share/picture.c] enter read32be 1\n");
    uint32_t ret = 0;

    ret = (ret << 8) | *buf++;
    ret = (ret << 8) | *buf++;
    ret = (ret << 8) | *buf++;
    ret = (ret << 8) | *buf++;

    return ret;
    fprintf(stderr, "[share/picture.c] exit read32be 1\n");
}

static flac_picture_t * flac_picture_parse_eat(void *data, size_t len)
{
    fprintf(stderr, "[share/picture.c] enter flac_picture_parse_eat 1\n");
    size_t expected_length = 32; // 8*32 bit
    size_t offset = 0;
    flac_picture_t *ret;
    uint32_t tmp;
    fprintf(stderr, "[share/picture.c] exit flac_picture_parse_eat 1\n");

    if (len < expected_length)
    {
        fprintf(stderr, "[share/picture.c] enter flac_picture_parse_eat 2\n");
        return NULL;
        fprintf(stderr, "[share/picture.c] exit flac_picture_parse_eat 2\n");
    }

    fprintf(stderr, "[share/picture.c] enter flac_picture_parse_eat 3\n");
    ret = calloc(1, sizeof(*ret));
    fprintf(stderr, "[share/picture.c] exit flac_picture_parse_eat 3\n");
    if (!ret)
    {
        fprintf(stderr, "[share/picture.c] enter flac_picture_parse_eat 4\n");
        return NULL;
        fprintf(stderr, "[share/picture.c] exit flac_picture_parse_eat 4\n");
    }

    fprintf(stderr, "[share/picture.c] enter flac_picture_parse_eat 5\n");
    ret->private_data = data;
    ret->private_data_length = len;

    ret->type = read32be(data);

    /*
    const char *media_type;
    const char *description;
    unsigned int width;
    unsigned int height;
    unsigned int depth;
    unsigned int colors;
    const void *binary;
    size_t binary_length;
    const char *uri;
    */
    tmp = read32be(data+4);
    expected_length += tmp;
    fprintf(stderr, "[share/picture.c] exit flac_picture_parse_eat 5\n");
    if (len < expected_length) {
        fprintf(stderr, "[share/picture.c] enter flac_picture_parse_eat 6\n");
        free(ret);
        return NULL;
        fprintf(stderr, "[share/picture.c] exit flac_picture_parse_eat 6\n");
    }

    fprintf(stderr, "[share/picture.c] enter flac_picture_parse_eat 7\n");
    ret->media_type = data + 8;
    offset = 8 + tmp;
    tmp = read32be(data + offset);
    expected_length += tmp;
    fprintf(stderr, "[share/picture.c] exit flac_picture_parse_eat 7\n");
    if (len < expected_length) {
        fprintf(stderr, "[share/picture.c] enter flac_picture_parse_eat 8\n");
        free(ret);
        return NULL;
        fprintf(stderr, "[share/picture.c] exit flac_picture_parse_eat 8\n");
    }

    fprintf(stderr, "[share/picture.c] enter flac_picture_parse_eat 9\n");
    *(char*)(data + offset) = 0;
    offset += 4;
    ret->description = data + offset;
    offset += tmp;
    ret->width = read32be(data + offset);
    *(char*)(data + offset) = 0;
    offset += 4;
    ret->height = read32be(data + offset);
    offset += 4;
    ret->depth = read32be(data + offset);
    offset += 4;
    ret->colors = read32be(data + offset);
    offset += 4;
    ret->binary_length = read32be(data + offset);
    expected_length += ret->binary_length;
    fprintf(stderr, "[share/picture.c] exit flac_picture_parse_eat 9\n");
    if (len < expected_length) {
        fprintf(stderr, "[share/picture.c] enter flac_picture_parse_eat 10\n");
        free(ret);
        return NULL;
        fprintf(stderr, "[share/picture.c] exit flac_picture_parse_eat 10\n");
    }

    fprintf(stderr, "[share/picture.c] enter flac_picture_parse_eat 11\n");
    offset += 4;
    ret->binary = data + offset;
    fprintf(stderr, "[share/picture.c] exit flac_picture_parse_eat 11\n");

    if (strcmp(ret->media_type, "-->") == 0) {
        fprintf(stderr, "[share/picture.c] enter flac_picture_parse_eat 12\n");
        // Note: it is ensured ret->binary[ret->binary_length] == 0.
        ret->media_type = NULL;
        ret->uri = ret->binary;
        ret->binary = NULL;
        ret->binary_length = 0;
        fprintf(stderr, "[share/picture.c] exit flac_picture_parse_eat 12\n");
    }

    fprintf(stderr, "[share/picture.c] enter flac_picture_parse_eat 13\n");
    return ret;
    fprintf(stderr, "[share/picture.c] exit flac_picture_parse_eat 13\n");
}

flac_picture_t * flac_picture_parse_from_base64(const char *str)
{
    fprintf(stderr, "[share/picture.c] enter flac_picture_parse_from_base64 1\n");
    flac_picture_t *ret;
    void *data;
    size_t len;
    fprintf(stderr, "[share/picture.c] exit flac_picture_parse_from_base64 1\n");
    
    if (!str || !*str)
    {
        fprintf(stderr, "[share/picture.c] enter flac_picture_parse_from_base64 2\n");
        return NULL;
        fprintf(stderr, "[share/picture.c] exit flac_picture_parse_from_base64 2\n");
    }

    fprintf(stderr, "[share/picture.c] enter flac_picture_parse_from_base64 3\n");
    if (base64_decode(str, &data, &len) != 0)
    {
        fprintf(stderr, "[share/picture.c] enter flac_picture_parse_from_base64 4\n");
        return NULL;
        fprintf(stderr, "[share/picture.c] exit flac_picture_parse_from_base64 4\n");
    }
    fprintf(stderr, "[share/picture.c] exit flac_picture_parse_from_base64 3\n");

    fprintf(stderr, "[share/picture.c] enter flac_picture_parse_from_base64 5\n");
    ret = flac_picture_parse_eat(data, len);
    fprintf(stderr, "[share/picture.c] exit flac_picture_parse_from_base64 5\n");

    if (!ret) {
        fprintf(stderr, "[share/picture.c] enter flac_picture_parse_from_base64 6\n");
        free(data);
        return NULL;
        fprintf(stderr, "[share/picture.c] exit flac_picture_parse_from_base64 6\n");
    }

    fprintf(stderr, "[share/picture.c] enter flac_picture_parse_from_base64 7\n");
    return ret;
    fprintf(stderr, "[share/picture.c] exit flac_picture_parse_from_base64 7\n");
}

flac_picture_t * flac_picture_parse_from_blob(const void *in, size_t len)
{
    fprintf(stderr, "[share/picture.c] enter flac_picture_parse_from_blob 1\n");
    flac_picture_t *ret;
    void *data;
    fprintf(stderr, "[share/picture.c] exit flac_picture_parse_from_blob 1\n");

    if (!in || !len)
    {
        fprintf(stderr, "[share/picture.c] enter flac_picture_parse_from_blob 2\n");
        return NULL;
        fprintf(stderr, "[share/picture.c] exit flac_picture_parse_from_blob 2\n");
    }

    fprintf(stderr, "[share/picture.c] enter flac_picture_parse_from_blob 3\n");
    data = calloc(1, len + 1);
    fprintf(stderr, "[share/picture.c] exit flac_picture_parse_from_blob 3\n");
    if (!data)
    {
        fprintf(stderr, "[share/picture.c] enter flac_picture_parse_from_blob 4\n");
        return NULL;
        fprintf(stderr, "[share/picture.c] exit flac_picture_parse_from_blob 4\n");
    }

    fprintf(stderr, "[share/picture.c] enter flac_picture_parse_from_blob 5\n");
    memcpy(data, in, len);
    fprintf(stderr, "[share/picture.c] exit flac_picture_parse_from_blob 5\n");

    fprintf(stderr, "[share/picture.c] enter flac_picture_parse_from_blob 6\n");
    ret = flac_picture_parse_eat(data, len);
    fprintf(stderr, "[share/picture.c] exit flac_picture_parse_from_blob 6\n");

    if (!ret) {
        fprintf(stderr, "[share/picture.c] enter flac_picture_parse_from_blob 7\n");
        free(data);
        return NULL;
        fprintf(stderr, "[share/picture.c] exit flac_picture_parse_from_blob 7\n");
    }

    fprintf(stderr, "[share/picture.c] enter flac_picture_parse_from_blob 8\n");
    return ret;
    fprintf(stderr, "[share/picture.c] exit flac_picture_parse_from_blob 8\n");
}

void flac_picture_free(flac_picture_t *picture)
{
    fprintf(stderr, "[share/picture.c] enter flac_picture_free 1\n");
    if (!picture)
    {
        fprintf(stderr, "[share/picture.c] enter flac_picture_free 2\n");
        return;
        fprintf(stderr, "[share/picture.c] exit flac_picture_free 2\n");
    }
    fprintf(stderr, "[share/picture.c] exit flac_picture_free 1\n");

    fprintf(stderr, "[share/picture.c] enter flac_picture_free 3\n");
    free(picture->private_data);
    free(picture);
    fprintf(stderr, "[share/picture.c] exit flac_picture_free 3\n");
}
// Total cost: 0.079501
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 242)]
// Total instrumented cost: 0.079501, input tokens: 4301, output tokens: 4346, cache read tokens: 2280, cache write tokens: 2017

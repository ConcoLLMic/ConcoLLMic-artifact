/*
 * Copyright (C) 2001 Peter Harris <peter.harris@hummingbird.com>
 * Copyright (C) 2001 Edmund Grimley Evans <edmundo@rano.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/*
 * Convert a string between UTF-8 and the locale's charset.
 */

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "utf8.h"


#ifdef _WIN32

	/* Thanks to Peter Harris <peter.harris@hummingbird.com> for this win32
	 * code.
	 */

#include <stdio.h>
#include <windows.h>

static unsigned char *make_utf8_string(const wchar_t *unicode)
{
    fprintf(stderr, "[share/utf8.c] enter make_utf8_string 1\n");
    int size = 0, index = 0, out_index = 0;
    unsigned char *out;
    unsigned short c;

    /* first calculate the size of the target string */
    c = unicode[index++];
    fprintf(stderr, "[share/utf8.c] exit make_utf8_string 1\n");
    while(c) {
        fprintf(stderr, "[share/utf8.c] enter make_utf8_string 2\n");
        if(c < 0x0080) {
            fprintf(stderr, "[share/utf8.c] enter make_utf8_string 3\n");
            size += 1;
            fprintf(stderr, "[share/utf8.c] exit make_utf8_string 3\n");
        } else if(c < 0x0800) {
            fprintf(stderr, "[share/utf8.c] enter make_utf8_string 4\n");
            size += 2;
            fprintf(stderr, "[share/utf8.c] exit make_utf8_string 4\n");
        } else {
            fprintf(stderr, "[share/utf8.c] enter make_utf8_string 5\n");
            size += 3;
            fprintf(stderr, "[share/utf8.c] exit make_utf8_string 5\n");
        }
        c = unicode[index++];
        fprintf(stderr, "[share/utf8.c] exit make_utf8_string 2\n");
    }	

    fprintf(stderr, "[share/utf8.c] enter make_utf8_string 6\n");
    out = malloc(size + 1);
    if (out == NULL)
    {
        fprintf(stderr, "[share/utf8.c] enter make_utf8_string 7\n");
        return NULL;
        fprintf(stderr, "[share/utf8.c] exit make_utf8_string 7\n");
    }
    index = 0;

    c = unicode[index++];
    fprintf(stderr, "[share/utf8.c] exit make_utf8_string 6\n");
    while(c)
    {
        fprintf(stderr, "[share/utf8.c] enter make_utf8_string 8\n");
        if(c < 0x080) {
            fprintf(stderr, "[share/utf8.c] enter make_utf8_string 9\n");
            out[out_index++] = (unsigned char)c;
            fprintf(stderr, "[share/utf8.c] exit make_utf8_string 9\n");
        } else if(c < 0x800) {
            fprintf(stderr, "[share/utf8.c] enter make_utf8_string 10\n");
            out[out_index++] = 0xc0 | (c >> 6);
            out[out_index++] = 0x80 | (c & 0x3f);
            fprintf(stderr, "[share/utf8.c] exit make_utf8_string 10\n");
        } else {
            fprintf(stderr, "[share/utf8.c] enter make_utf8_string 11\n");
            out[out_index++] = 0xe0 | (c >> 12);
            out[out_index++] = 0x80 | ((c >> 6) & 0x3f);
            out[out_index++] = 0x80 | (c & 0x3f);
            fprintf(stderr, "[share/utf8.c] exit make_utf8_string 11\n");
        }
        c = unicode[index++];
        fprintf(stderr, "[share/utf8.c] exit make_utf8_string 8\n");
    }
    fprintf(stderr, "[share/utf8.c] enter make_utf8_string 12\n");
    out[out_index] = 0x00;

    return out;
    fprintf(stderr, "[share/utf8.c] exit make_utf8_string 12\n");
}

static wchar_t *make_unicode_string(const unsigned char *utf8)
{
    fprintf(stderr, "[share/utf8.c] enter make_unicode_string 1\n");
    int size = 0, index = 0, out_index = 0;
    wchar_t *out;
    unsigned char c;

    /* first calculate the size of the target string */
    c = utf8[index++];
    fprintf(stderr, "[share/utf8.c] exit make_unicode_string 1\n");
    while(c) {
        fprintf(stderr, "[share/utf8.c] enter make_unicode_string 2\n");
        if((c & 0x80) == 0) {
            fprintf(stderr, "[share/utf8.c] enter make_unicode_string 3\n");
            index += 0;
            fprintf(stderr, "[share/utf8.c] exit make_unicode_string 3\n");
        } else if((c & 0xe0) == 0xe0) {
            fprintf(stderr, "[share/utf8.c] enter make_unicode_string 4\n");
            index += 2;
            fprintf(stderr, "[share/utf8.c] exit make_unicode_string 4\n");
        } else {
            fprintf(stderr, "[share/utf8.c] enter make_unicode_string 5\n");
            index += 1;
            fprintf(stderr, "[share/utf8.c] exit make_unicode_string 5\n");
        }
        size += 1;
        c = utf8[index++];
        fprintf(stderr, "[share/utf8.c] exit make_unicode_string 2\n");
    }	

    fprintf(stderr, "[share/utf8.c] enter make_unicode_string 6\n");
    out = malloc((size + 1) * sizeof(wchar_t));
    if (out == NULL)
    {
        fprintf(stderr, "[share/utf8.c] enter make_unicode_string 7\n");
        return NULL;
        fprintf(stderr, "[share/utf8.c] exit make_unicode_string 7\n");
    }
    index = 0;

    c = utf8[index++];
    fprintf(stderr, "[share/utf8.c] exit make_unicode_string 6\n");
    while(c)
    {
        fprintf(stderr, "[share/utf8.c] enter make_unicode_string 8\n");
        if((c & 0x80) == 0) {
            fprintf(stderr, "[share/utf8.c] enter make_unicode_string 9\n");
            out[out_index++] = c;
            fprintf(stderr, "[share/utf8.c] exit make_unicode_string 9\n");
        } else if((c & 0xe0) == 0xe0) {
            fprintf(stderr, "[share/utf8.c] enter make_unicode_string 10\n");
            out[out_index] = (c & 0x1F) << 12;
	        c = utf8[index++];
            out[out_index] |= (c & 0x3F) << 6;
	        c = utf8[index++];
            out[out_index++] |= (c & 0x3F);
            fprintf(stderr, "[share/utf8.c] exit make_unicode_string 10\n");
        } else {
            fprintf(stderr, "[share/utf8.c] enter make_unicode_string 11\n");
            out[out_index] = (c & 0x3F) << 6;
	        c = utf8[index++];
            out[out_index++] |= (c & 0x3F);
            fprintf(stderr, "[share/utf8.c] exit make_unicode_string 11\n");
        }
        c = utf8[index++];
        fprintf(stderr, "[share/utf8.c] exit make_unicode_string 8\n");
    }
    fprintf(stderr, "[share/utf8.c] enter make_unicode_string 12\n");
    out[out_index] = 0;

    return out;
    fprintf(stderr, "[share/utf8.c] exit make_unicode_string 12\n");
}

int utf8_encode(const char *from, char **to)
{
    fprintf(stderr, "[share/utf8.c] enter utf8_encode 1\n");
	wchar_t *unicode;
	int wchars, err;

	wchars = MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, from,
			strlen(from), NULL, 0);

	if(wchars == 0)
	{
        fprintf(stderr, "[share/utf8.c] enter utf8_encode 2\n");
		fprintf(stderr, "Unicode translation error %d\n", GetLastError());
		return -1;
        fprintf(stderr, "[share/utf8.c] exit utf8_encode 2\n");
	}

	unicode = calloc(wchars + 1, sizeof(unsigned short));
	if(unicode == NULL) 
	{
        fprintf(stderr, "[share/utf8.c] enter utf8_encode 3\n");
		fprintf(stderr, "Out of memory processing string to UTF8\n");
		return -1;
        fprintf(stderr, "[share/utf8.c] exit utf8_encode 3\n");
	}

	err = MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, from, 
			strlen(from), unicode, wchars);
	if(err != wchars)
	{
        fprintf(stderr, "[share/utf8.c] enter utf8_encode 4\n");
		free(unicode);
		fprintf(stderr, "Unicode translation error %d\n", GetLastError());
		return -1;
        fprintf(stderr, "[share/utf8.c] exit utf8_encode 4\n");
	}

	/* On NT-based windows systems, we could use WideCharToMultiByte(), but 
	 * MS doesn't actually have a consistent API across win32.
	 */
	*to = make_utf8_string(unicode);

	free(unicode);
	return 0;
    fprintf(stderr, "[share/utf8.c] exit utf8_encode 1\n");
}

int utf8_decode(const char *from, char **to)
{
    fprintf(stderr, "[share/utf8.c] enter utf8_decode 1\n");
    wchar_t *unicode;
    int chars, err;

    /* On NT-based windows systems, we could use MultiByteToWideChar(CP_UTF8), but 
     * MS doesn't actually have a consistent API across win32.
     */
    unicode = make_unicode_string(from);
    if(unicode == NULL) 
    {
        fprintf(stderr, "[share/utf8.c] enter utf8_decode 2\n");
        fprintf(stderr, "Out of memory processing string from UTF8 to UNICODE16\n");
        return -1;
        fprintf(stderr, "[share/utf8.c] exit utf8_decode 2\n");
    }

    chars = WideCharToMultiByte(CP_ACP, WC_COMPOSITECHECK, unicode,
            -1, NULL, 0, NULL, NULL);

    if(chars == 0)
    {
        fprintf(stderr, "[share/utf8.c] enter utf8_decode 3\n");
        fprintf(stderr, "Unicode translation error %d\n", GetLastError());
        free(unicode);
        return -1;
        fprintf(stderr, "[share/utf8.c] exit utf8_decode 3\n");
    }

    *to = calloc(chars + 1, sizeof(unsigned char));
    if(*to == NULL) 
    {
        fprintf(stderr, "[share/utf8.c] enter utf8_decode 4\n");
        fprintf(stderr, "Out of memory processing string to local charset\n");
        free(unicode);
        return -1;
        fprintf(stderr, "[share/utf8.c] exit utf8_decode 4\n");
    }

    err = WideCharToMultiByte(CP_ACP, WC_COMPOSITECHECK, unicode, 
            -1, *to, chars, NULL, NULL);
    if(err != chars)
    {
        fprintf(stderr, "[share/utf8.c] enter utf8_decode 5\n");
        fprintf(stderr, "Unicode translation error %d\n", GetLastError());
        free(unicode);
        free(*to);
        *to = NULL;
        return -1;
        fprintf(stderr, "[share/utf8.c] exit utf8_decode 5\n");
    }

    free(unicode);
    return 0;
    fprintf(stderr, "[share/utf8.c] exit utf8_decode 1\n");
}

#else /* End win32. Rest is for real operating systems */


#ifdef HAVE_LANGINFO_CODESET
#include <langinfo.h>
#endif

int iconvert(const char *fromcode, const char *tocode,
	     const char *from, size_t fromlen,
	     char **to, size_t *tolen);

static char *current_charset = 0; /* means "US-ASCII" */

void convert_set_charset(const char *charset)
{
    fprintf(stderr, "[share/utf8.c] enter convert_set_charset 1\n");
    if (!charset)
        charset = getenv("CHARSET");

#ifdef HAVE_LANGINFO_CODESET
    if (!charset)
        charset = nl_langinfo(CODESET);
#endif

    free(current_charset);
    current_charset = 0;
    if (charset && *charset)
        current_charset = strdup(charset);
    fprintf(stderr, "[share/utf8.c] exit convert_set_charset 1\n");
}

void convert_free_charset(void)
{
    fprintf(stderr, "[share/utf8.c] enter convert_free_charset 1\n");
    free(current_charset);
    current_charset = 0;
    fprintf(stderr, "[share/utf8.c] exit convert_free_charset 1\n");
}

static int convert_buffer(const char *fromcode, const char *tocode,
			  const char *from, size_t fromlen,
			  char **to, size_t *tolen)
{
    fprintf(stderr, "[share/utf8.c] enter convert_buffer 1\n");
    int ret = -1;

#ifdef HAVE_ICONV
    ret = iconvert(fromcode, tocode, from, fromlen, to, tolen);
    if (ret != -1)
    {
        fprintf(stderr, "[share/utf8.c] enter convert_buffer 2\n");
        return ret;
        fprintf(stderr, "[share/utf8.c] exit convert_buffer 2\n");
    }
#endif

#ifndef HAVE_ICONV /* should be ifdef USE_CHARSET_CONVERT */
    ret = charset_convert(fromcode, tocode, from, fromlen, to, tolen);
    if (ret != -1)
    {
        fprintf(stderr, "[share/utf8.c] enter convert_buffer 3\n");
        return ret;
        fprintf(stderr, "[share/utf8.c] exit convert_buffer 3\n");
    }
#endif

    return ret;
    fprintf(stderr, "[share/utf8.c] exit convert_buffer 1\n");
}

static int convert_string(const char *fromcode, const char *tocode,
			  const char *from, char **to, char replace)
{
    fprintf(stderr, "[share/utf8.c] enter convert_string 1\n");
    int ret;
    size_t fromlen;
    char *s;

    fromlen = strlen(from);
    ret = convert_buffer(fromcode, tocode, from, fromlen, to, 0);
    if (ret == -2)
    {
        fprintf(stderr, "[share/utf8.c] enter convert_string 2\n");
        return -1;
        fprintf(stderr, "[share/utf8.c] exit convert_string 2\n");
    }
    if (ret != -1)
    {
        fprintf(stderr, "[share/utf8.c] enter convert_string 3\n");
        return ret;
        fprintf(stderr, "[share/utf8.c] exit convert_string 3\n");
    }

    s = malloc(fromlen + 1);
    if (!s)
    {
        fprintf(stderr, "[share/utf8.c] enter convert_string 4\n");
        return -1;
        fprintf(stderr, "[share/utf8.c] exit convert_string 4\n");
    }
    strcpy(s, from);
    *to = s;
    for (; *s; s++)
    {
        fprintf(stderr, "[share/utf8.c] enter convert_string 5\n");
        if (*s & ~0x7f)
            *s = replace;
        fprintf(stderr, "[share/utf8.c] exit convert_string 5\n");
    }
    return 3;
    fprintf(stderr, "[share/utf8.c] exit convert_string 1\n");
}

int utf8_encode(const char *from, char **to)
{
    fprintf(stderr, "[share/utf8.c] enter utf8_encode 2747\n");
    char *charset;

    if (!current_charset)
        convert_set_charset(0);
    charset = current_charset ? current_charset : "US-ASCII";
    return convert_string(charset, "UTF-8", from, to, '#');
    fprintf(stderr, "[share/utf8.c] exit utf8_encode 2747\n");
}

int utf8_decode(const char *from, char **to)
{
    fprintf(stderr, "[share/utf8.c] enter utf8_decode 2184\n");
    char *charset;

    if(*from == 0) {
        fprintf(stderr, "[share/utf8.c] enter utf8_decode 3160\n");
        *to = malloc(1);
        **to = 0;
        return 1;
        fprintf(stderr, "[share/utf8.c] exit utf8_decode 3160\n");
    }

    if (!current_charset)
        convert_set_charset(0);
    charset = current_charset ? current_charset : "US-ASCII";
    return convert_string("UTF-8", charset, from, to, '?');
    fprintf(stderr, "[share/utf8.c] exit utf8_decode 2184\n");
}

#endif

/* Quick and dirty UTF-8 validation: */


/* check the first "count" bytes of "s" to make
   sure they are all valid UTF-8 "continuation" bytes */
static int checknext(const char *s, int count)
{
    fprintf(stderr, "[share/utf8.c] enter checknext 1\n");
    int i;
    for (i = 0; i < count; i++) {
        fprintf(stderr, "[share/utf8.c] enter checknext 2\n");
	    if ((s[i] & 0xc0) != 0x80)
        {
            fprintf(stderr, "[share/utf8.c] enter checknext 3\n");
	        return 0;
            fprintf(stderr, "[share/utf8.c] exit checknext 3\n");
        }
        fprintf(stderr, "[share/utf8.c] exit checknext 2\n");
    }
    return 1;
    fprintf(stderr, "[share/utf8.c] exit checknext 1\n");
}

static struct {
    char mask;
    char value;
    unsigned after;
} test[] = {
    { 0x80,    0, 0 }, /* 7-bit ASCII - One byte sequence */
    { 0xe0, 0xc0, 1 }, /* Two byte sequence */
    { 0xf0, 0xe0, 2 }, /* Three byte sequence */
    { 0xf8, 0xf0, 3 }, /* Four byte sequence */
    { 0xfc, 0xf8, 4 }, /* Five byte sequence */
    { 0xfe, 0xfc, 5 }, /* Six byte sequence */
    /* All other values are not valid UTF-8 */
};

#define NUM_TESTS (sizeof(test)/sizeof(test[0]))

/* Returns true if the C-string is a valid UTF-8 sequence
   Returns false otherwise */
int utf8_validate(const char *s)
{
    fprintf(stderr, "[share/utf8.c] enter utf8_validate 1\n");
    size_t len = strlen(s);

    while (len) {
        fprintf(stderr, "[share/utf8.c] enter utf8_validate 2\n");
	    int i;
	    for (i = 0; i < NUM_TESTS; i++) {
            fprintf(stderr, "[share/utf8.c] enter utf8_validate 3\n");
	        if ((s[0] & test[i].mask) == test[i].value) {
                fprintf(stderr, "[share/utf8.c] enter utf8_validate 4\n");
		        unsigned after = test[i].after;

		        if (len < after + 1)
                {
                    fprintf(stderr, "[share/utf8.c] enter utf8_validate 5\n");
		            return 0;
                    fprintf(stderr, "[share/utf8.c] exit utf8_validate 5\n");
                }

		        if (!checknext(s+1, after))
                {
                    fprintf(stderr, "[share/utf8.c] enter utf8_validate 6\n");
		            return 0;
                    fprintf(stderr, "[share/utf8.c] exit utf8_validate 6\n");
                }

		        s += after + 1;
		        len -= after + 1;
		        goto next;
                fprintf(stderr, "[share/utf8.c] exit utf8_validate 4\n");
	        }
            fprintf(stderr, "[share/utf8.c] exit utf8_validate 3\n");
	    }
	    /* If none of the tests match, invalid UTF-8 */
        fprintf(stderr, "[share/utf8.c] enter utf8_validate 7\n");
	    return 0;
        fprintf(stderr, "[share/utf8.c] exit utf8_validate 7\n");
next:   ;
        fprintf(stderr, "[share/utf8.c] exit utf8_validate 2\n");
    }

    /* Zero bytes left, and all test pass. Valid UTF-8. */
    return 1;
    fprintf(stderr, "[share/utf8.c] exit utf8_validate 1\n");
}
// Total cost: 0.104627
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 393)]
// Total instrumented cost: 0.104627, input tokens: 5679, output tokens: 5401, cache read tokens: 2280, cache write tokens: 3395

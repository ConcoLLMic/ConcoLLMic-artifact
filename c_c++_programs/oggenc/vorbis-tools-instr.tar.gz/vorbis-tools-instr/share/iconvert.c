/*
 * Copyright (C) 2001 Edmund Grimley Evans <edmundo@rano.org>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#ifdef HAVE_ICONV

#include <assert.h>
#include <errno.h>
#include <iconv.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

/*
 * Convert data from one encoding to another. Return:
 *
 *  -2 : memory allocation failed
 *  -1 : unknown encoding
 *   0 : data was converted exactly
 *   1 : data was converted inexactly
 *   2 : data was invalid (but still converted)
 *
 * We convert in two steps, via UTF-8, as this is the only
 * reliable way of distinguishing between invalid input
 * and valid input which iconv refuses to transliterate.
 * We convert from UTF-8 twice, because we have no way of
 * knowing whether the conversion was exact if iconv returns
 * E2BIG (due to a bug in the specification of iconv).
 * An alternative approach is to assume that the output of
 * iconv is never more than 4 times as long as the input,
 * but I prefer to avoid that assumption if possible.
 */

int iconvert(const char *fromcode, const char *tocode,
	     const char *from, size_t fromlen,
	     char **to, size_t *tolen)
{
  fprintf(stderr, "[share/iconvert.c] enter iconvert 1\n");
  int ret = 0;
  iconv_t cd1, cd2;
  char *ib;
  char *ob;
  char *utfbuf = 0, *outbuf, *newbuf;
  size_t utflen, outlen, ibl, obl, k;
  char tbuf[2048];
  fprintf(stderr, "[share/iconvert.c] exit iconvert 1\n");

  cd1 = iconv_open("UTF-8", fromcode);
  fprintf(stderr, "[share/iconvert.c] enter iconvert 2\n");
  if (cd1 == (iconv_t)(-1))
    return -1;
  fprintf(stderr, "[share/iconvert.c] exit iconvert 2\n");

  fprintf(stderr, "[share/iconvert.c] enter iconvert 3\n");
  cd2 = (iconv_t)(-1);
  fprintf(stderr, "[share/iconvert.c] exit iconvert 3\n");
  
  /* Don't use strcasecmp() as it's locale-dependent. */
  fprintf(stderr, "[share/iconvert.c] enter iconvert 4\n");
  if (!strchr("Uu", tocode[0]) ||
      !strchr("Tt", tocode[1]) ||
      !strchr("Ff", tocode[2]) ||
      tocode[3] != '-' ||
      tocode[4] != '8' ||
      tocode[5] != '\0') {
    fprintf(stderr, "[share/iconvert.c] enter iconvert 5\n");
    char *tocode1;

    /*
     * Try using this non-standard feature of glibc and libiconv.
     * This is deliberately not a config option as people often
     * change their iconv library without rebuilding applications.
     */
    tocode1 = (char *)malloc(strlen(tocode) + 11);
    if (!tocode1)
      goto fail;
    fprintf(stderr, "[share/iconvert.c] exit iconvert 5\n");

    fprintf(stderr, "[share/iconvert.c] enter iconvert 6\n");
    strcpy(tocode1, tocode);
    strcat(tocode1, "//TRANSLIT");
    cd2 = iconv_open(tocode1, "UTF-8");
    free(tocode1);
    fprintf(stderr, "[share/iconvert.c] exit iconvert 6\n");

    fprintf(stderr, "[share/iconvert.c] enter iconvert 7\n");
    if (cd2 == (iconv_t)(-1))
      cd2 = iconv_open(tocode, fromcode);
    fprintf(stderr, "[share/iconvert.c] exit iconvert 7\n");

    fprintf(stderr, "[share/iconvert.c] enter iconvert 8\n");
    if (cd2 == (iconv_t)(-1)) {
      fprintf(stderr, "[share/iconvert.c] enter iconvert 9\n");
      iconv_close(cd1);
      return -1;
      fprintf(stderr, "[share/iconvert.c] exit iconvert 9\n");
    }
    fprintf(stderr, "[share/iconvert.c] exit iconvert 8\n");
  }
  fprintf(stderr, "[share/iconvert.c] exit iconvert 4\n");

  fprintf(stderr, "[share/iconvert.c] enter iconvert 10\n");
  utflen = 1; /*fromlen * 2 + 1; XXX */
  utfbuf = (char *)malloc(utflen);
  if (!utfbuf)
    goto fail;
  fprintf(stderr, "[share/iconvert.c] exit iconvert 10\n");

  /* Convert to UTF-8 */
  fprintf(stderr, "[share/iconvert.c] enter iconvert 11\n");
  ib = (char *)from;
  ibl = fromlen;
  ob = utfbuf;
  obl = utflen;
  fprintf(stderr, "[share/iconvert.c] exit iconvert 11\n");
  
  for (;;) {
    fprintf(stderr, "[share/iconvert.c] enter iconvert 12\n");
    k = iconv(cd1, &ib, &ibl, &ob, &obl);
    assert((k != (size_t)(-1) && !ibl) ||
	   (k == (size_t)(-1) && errno == E2BIG && ibl && obl < 6) ||
	   (k == (size_t)(-1) &&
	    (errno == EILSEQ || errno == EINVAL) && ibl));
    if (!ibl)
      break;
    fprintf(stderr, "[share/iconvert.c] exit iconvert 12\n");
    
    fprintf(stderr, "[share/iconvert.c] enter iconvert 13\n");
    if (obl < 6) {
      fprintf(stderr, "[share/iconvert.c] enter iconvert 14\n");
      /* Enlarge the buffer */
      ptrdiff_t obcount = ob - utfbuf;
      utflen *= 2;
      newbuf = (char *)realloc(utfbuf, utflen);
      if (!newbuf)
	goto fail;
      ob = newbuf + obcount;
      obl = utflen - (ob - newbuf);
      utfbuf = newbuf;
      fprintf(stderr, "[share/iconvert.c] exit iconvert 14\n");
    }
    else {
      fprintf(stderr, "[share/iconvert.c] enter iconvert 15\n");
      /* Invalid input */
      ib++, ibl--;
      *ob++ = '#', obl--;
      ret = 2;
      //iconv(cd1, 0, 0, 0, 0); # in theory commenting this line prevents a segfault
      fprintf(stderr, "[share/iconvert.c] exit iconvert 15\n");
    }
    fprintf(stderr, "[share/iconvert.c] exit iconvert 13\n");
  }

  fprintf(stderr, "[share/iconvert.c] enter iconvert 16\n");
  if (cd2 == (iconv_t)(-1)) {
    fprintf(stderr, "[share/iconvert.c] enter iconvert 17\n");
    ptrdiff_t obcount = ob - utfbuf;
    /* The target encoding was UTF-8 */
    if (tolen)
      *tolen = obcount;
    if (!to) {
      fprintf(stderr, "[share/iconvert.c] enter iconvert 18\n");
      free(utfbuf);
      iconv_close(cd1);
      return ret;
      fprintf(stderr, "[share/iconvert.c] exit iconvert 18\n");
    }
    fprintf(stderr, "[share/iconvert.c] exit iconvert 17\n");
    
    fprintf(stderr, "[share/iconvert.c] enter iconvert 19\n");
    newbuf = (char *)realloc(utfbuf, obcount + 1);
    if (!newbuf)
      goto fail;
    ob = newbuf + obcount;
    *ob = '\0';
    *to = newbuf;
    iconv_close(cd1);
    return ret;
    fprintf(stderr, "[share/iconvert.c] exit iconvert 19\n");
  }
  fprintf(stderr, "[share/iconvert.c] exit iconvert 16\n");

  /* Truncate the buffer to be tidy */
  fprintf(stderr, "[share/iconvert.c] enter iconvert 20\n");
  utflen = ob - utfbuf;
  newbuf = (char *)realloc(utfbuf, utflen);
  if (!newbuf)
    goto fail;
  utfbuf = newbuf;
  fprintf(stderr, "[share/iconvert.c] exit iconvert 20\n");

  /* Convert from UTF-8 to discover how long the output is */
  fprintf(stderr, "[share/iconvert.c] enter iconvert 21\n");
  outlen = 0;
  ib = utfbuf;
  ibl = utflen;
  fprintf(stderr, "[share/iconvert.c] exit iconvert 21\n");
  
  while (ibl) {
    fprintf(stderr, "[share/iconvert.c] enter iconvert 22\n");
    ob = tbuf;
    obl = sizeof(tbuf);
    k = iconv(cd2, &ib, &ibl, &ob, &obl);
    assert((k != (size_t)(-1) && !ibl) ||
	   (k == (size_t)(-1) && errno == E2BIG && ibl) ||
	   (k == (size_t)(-1) && errno == EILSEQ && ibl));
    fprintf(stderr, "[share/iconvert.c] exit iconvert 22\n");
    
    fprintf(stderr, "\n");
    if (ibl && !(k == (size_t)(-1) && errno == E2BIG)) {
      fprintf(stderr, "[share/iconvert.c] enter iconvert 24\n");
      /* Replace one character */
      char *tb = "?";
      size_t tbl = 1;

      outlen += ob - tbuf;
      ob = tbuf;
      obl = sizeof(tbuf);
      k = iconv(cd2, &tb, &tbl, &ob, &obl);
      assert((k != (size_t)(-1) && !tbl) ||
	     (k == (size_t)(-1) && errno == EILSEQ && tbl));
      for (++ib, --ibl; ibl && (*ib & 0x80); ib++, ibl--)
	;
      fprintf(stderr, "[share/iconvert.c] exit iconvert 24\n");
    }
    fprintf(stderr, "[share/iconvert.c] enter iconvert 25\n");
    outlen += ob - tbuf;
    fprintf(stderr, "[share/iconvert.c] exit iconvert 25\n");
  }
  
  fprintf(stderr, "[share/iconvert.c] enter iconvert 26\n");
  ob = tbuf;
  obl = sizeof(tbuf);
  k = iconv(cd2, 0, 0, &ob, &obl);
  assert(k != (size_t)(-1));
  outlen += ob - tbuf;
  fprintf(stderr, "[share/iconvert.c] exit iconvert 26\n");

  /* Convert from UTF-8 for real */
  fprintf(stderr, "[share/iconvert.c] enter iconvert 27\n");
  outbuf = (char *)malloc(outlen + 1);
  if (!outbuf)
    goto fail;
  ib = utfbuf;
  ibl = utflen;
  ob = outbuf;
  obl = outlen;
  fprintf(stderr, "[share/iconvert.c] exit iconvert 27\n");
  
  while (ibl) {
    fprintf(stderr, "[share/iconvert.c] enter iconvert 28\n");
    k = iconv(cd2, &ib, &ibl, &ob, &obl);
    assert((k != (size_t)(-1) && !ibl) ||
	   (k == (size_t)(-1) && errno == EILSEQ && ibl));
    if (k && !ret)
      ret = 1;
    fprintf(stderr, "[share/iconvert.c] exit iconvert 28\n");
    
    fprintf(stderr, "[share/iconvert.c] enter iconvert 29\n");
    if (ibl && !(k == (size_t)(-1) && errno == E2BIG)) {
      fprintf(stderr, "[share/iconvert.c] enter iconvert 30\n");
      /* Replace one character */
      char *tb = "?";
      size_t tbl = 1;

      k = iconv(cd2, &tb, &tbl, &ob, &obl);
      assert((k != (size_t)(-1) && !tbl) ||
	     (k == (size_t)(-1) && errno == EILSEQ && tbl));
      for (++ib, --ibl; ibl && (*ib & 0x80); ib++, ibl--)
	;
      fprintf(stderr, "[share/iconvert.c] exit iconvert 30\n");
    }
    fprintf(stderr, "[share/iconvert.c] exit iconvert 29\n");
  }
  
  fprintf(stderr, "[share/iconvert.c] enter iconvert 31\n");
  k = iconv(cd2, 0, 0, &ob, &obl);
  assert(k != (size_t)(-1));
  assert(!obl);
  *ob = '\0';

  free(utfbuf);
  iconv_close(cd1);
  iconv_close(cd2);
  if (tolen)
    *tolen = outlen;
  if (!to) {
    fprintf(stderr, "[share/iconvert.c] enter iconvert 32\n");
    free(outbuf);
    return ret;
    fprintf(stderr, "[share/iconvert.c] exit iconvert 32\n");
  }
  fprintf(stderr, "[share/iconvert.c] exit iconvert 31\n");
  
  fprintf(stderr, "[share/iconvert.c] enter iconvert 33\n");
  *to = outbuf;
  return ret;
  fprintf(stderr, "[share/iconvert.c] exit iconvert 33\n");

 fail:
  fprintf(stderr, "[share/iconvert.c] enter iconvert 34\n");
  free(utfbuf);
  iconv_close(cd1);
  if (cd2 != (iconv_t)(-1))
    iconv_close(cd2);
  return -2;
  fprintf(stderr, "[share/iconvert.c] exit iconvert 34\n");
}

#endif /* HAVE_ICONV */
// Total cost: 0.075273
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 250)]
// Total instrumented cost: 0.075273, input tokens: 5028, output tokens: 3737, cache read tokens: 2280, cache write tokens: 2744

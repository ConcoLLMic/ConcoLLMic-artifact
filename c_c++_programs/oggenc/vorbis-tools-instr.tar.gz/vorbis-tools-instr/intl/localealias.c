/* Handle aliases for locale names.
   Copyright (C) 1995-1999, 2000-2001, 2003, 2005-2006 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU Library General Public License as published
   by the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301,
   USA.  */

/* Tell glibc's <string.h> to provide a prototype for mempcpy().
   This must come before <config.h> because <config.h> may include
   <features.h>, and once <features.h> has been included, it's too late.  */
#ifndef _GNU_SOURCE
# define _GNU_SOURCE    1
#endif

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <ctype.h>
#include <stdio.h>
#if defined _LIBC || defined HAVE___FSETLOCKING
# include <stdio_ext.h>
#endif
#include <sys/types.h>

#ifdef __GNUC__
# undef alloca
# define alloca __builtin_alloca
# define HAVE_ALLOCA 1
#else
# ifdef _MSC_VER
#  include <malloc.h>
#  define alloca _alloca
# else
#  if defined HAVE_ALLOCA_H || defined _LIBC
#   include <alloca.h>
#  else
#   ifdef _AIX
 #pragma alloca
#   else
#    ifndef alloca
char *alloca ();
#    endif
#   endif
#  endif
# endif
#endif

#include <stdlib.h>
#include <string.h>

#include "gettextP.h"

#if ENABLE_RELOCATABLE
# include "relocatable.h"
#else
# define relocate(pathname) (pathname)
#endif

/* @@ end of prolog @@ */

#ifdef _LIBC
/* Rename the non ANSI C functions.  This is required by the standard
   because some ANSI C functions will require linking with this object
   file and the name space must not be polluted.  */
# define strcasecmp __strcasecmp

# ifndef mempcpy
#  define mempcpy __mempcpy
# endif
# define HAVE_MEMPCPY	1
# define HAVE___FSETLOCKING	1
#endif

/* Handle multi-threaded applications.  */
#ifdef _LIBC
# include <bits/libc-lock.h>
#else
# include "lock.h"
#endif

#ifndef internal_function
# define internal_function
#endif

/* Some optimizations for glibc.  */
#ifdef _LIBC
# define FEOF(fp)		feof_unlocked (fp)
# define FGETS(buf, n, fp)	fgets_unlocked (buf, n, fp)
#else
# define FEOF(fp)		feof (fp)
# define FGETS(buf, n, fp)	fgets (buf, n, fp)
#endif

/* For those losing systems which don't have `alloca' we have to add
   some additional code emulating it.  */
#ifdef HAVE_ALLOCA
# define freea(p) /* nothing */
#else
# define alloca(n) malloc (n)
# define freea(p) free (p)
#endif

#if defined _LIBC_REENTRANT || HAVE_DECL_FGETS_UNLOCKED
# undef fgets
# define fgets(buf, len, s) fgets_unlocked (buf, len, s)
#endif
#if defined _LIBC_REENTRANT || HAVE_DECL_FEOF_UNLOCKED
# undef feof
# define feof(s) feof_unlocked (s)
#endif


__libc_lock_define_initialized (static, lock)


struct alias_map
{
  const char *alias;
  const char *value;
};


#ifndef _LIBC
# define libc_freeres_ptr(decl) decl
#endif

libc_freeres_ptr (static char *string_space);
static size_t string_space_act;
static size_t string_space_max;
libc_freeres_ptr (static struct alias_map *map);
static size_t nmap;
static size_t maxmap;


/* Prototypes for local functions.  */
static size_t read_alias_file (const char *fname, int fname_len)
     internal_function;
static int extend_alias_table (void);
static int alias_compare (const struct alias_map *map1,
			  const struct alias_map *map2);


const char *
_nl_expand_alias (const char *name)
{
  fprintf(stderr, "[intl/localealias.c] enter _nl_expand_alias 1\n");
  static const char *locale_alias_path;
  struct alias_map *retval;
  const char *result = NULL;
  size_t added;

  __libc_lock_lock (lock);
  fprintf(stderr, "[intl/localealias.c] exit _nl_expand_alias 1\n");

  if (locale_alias_path == NULL)
  {
    fprintf(stderr, "[intl/localealias.c] enter _nl_expand_alias 2\n");
    locale_alias_path = LOCALE_ALIAS_PATH;
    fprintf(stderr, "[intl/localealias.c] exit _nl_expand_alias 2\n");
  }

  do
  {
    fprintf(stderr, "[intl/localealias.c] enter _nl_expand_alias 3\n");
    struct alias_map item;

    item.alias = name;
    fprintf(stderr, "[intl/localealias.c] exit _nl_expand_alias 3\n");

    if (nmap > 0)
    {
      fprintf(stderr, "[intl/localealias.c] enter _nl_expand_alias 4\n");
      retval = (struct alias_map *) bsearch (&item, map, nmap,
					       sizeof (struct alias_map),
					       (int (*) (const void *,
							 const void *)
						) alias_compare);
      fprintf(stderr, "[intl/localealias.c] exit _nl_expand_alias 4\n");
    }
    else
    {
      fprintf(stderr, "[intl/localealias.c] enter _nl_expand_alias 5\n");
      retval = NULL;
      fprintf(stderr, "[intl/localealias.c] exit _nl_expand_alias 5\n");
    }

    /* We really found an alias.  Return the value.  */
    if (retval != NULL)
    {
      fprintf(stderr, "[intl/localealias.c] enter _nl_expand_alias 6\n");
      result = retval->value;
      break;
      fprintf(stderr, "[intl/localealias.c] exit _nl_expand_alias 6\n");
    }

    /* Perhaps we can find another alias file.  */
    fprintf(stderr, "[intl/localealias.c] enter _nl_expand_alias 7\n");
    added = 0;
    fprintf(stderr, "[intl/localealias.c] exit _nl_expand_alias 7\n");
    while (added == 0 && locale_alias_path[0] != '\0')
    {
      fprintf(stderr, "[intl/localealias.c] enter _nl_expand_alias 8\n");
      const char *start;
      fprintf(stderr, "[intl/localealias.c] exit _nl_expand_alias 8\n");

      while (locale_alias_path[0] == PATH_SEPARATOR)
      {
        fprintf(stderr, "[intl/localealias.c] enter _nl_expand_alias 9\n");
        ++locale_alias_path;
        fprintf(stderr, "[intl/localealias.c] exit _nl_expand_alias 9\n");
      }
      
      fprintf(stderr, "[intl/localealias.c] enter _nl_expand_alias 10\n");
      start = locale_alias_path;
      fprintf(stderr, "[intl/localealias.c] exit _nl_expand_alias 10\n");

      while (locale_alias_path[0] != '\0'
	     && locale_alias_path[0] != PATH_SEPARATOR)
      {
        fprintf(stderr, "[intl/localealias.c] enter _nl_expand_alias 11\n");
        ++locale_alias_path;
        fprintf(stderr, "[intl/localealias.c] exit _nl_expand_alias 11\n");
      }

      if (start < locale_alias_path)
      {
        fprintf(stderr, "[intl/localealias.c] enter _nl_expand_alias 12\n");
        added = read_alias_file (start, locale_alias_path - start);
        fprintf(stderr, "[intl/localealias.c] exit _nl_expand_alias 12\n");
      }
    }
  }
  while (added != 0);

  fprintf(stderr, "[intl/localealias.c] enter _nl_expand_alias 13\n");
  __libc_lock_unlock (lock);

  return result;
  fprintf(stderr, "[intl/localealias.c] exit _nl_expand_alias 13\n");
}


static size_t
internal_function
read_alias_file (const char *fname, int fname_len)
{
  fprintf(stderr, "[intl/localealias.c] enter read_alias_file 1\n");
  FILE *fp;
  char *full_fname;
  size_t added;
  static const char aliasfile[] = "/locale.alias";

  full_fname = (char *) alloca (fname_len + sizeof aliasfile);
  fprintf(stderr, "[intl/localealias.c] exit read_alias_file 1\n");
  
#ifdef HAVE_MEMPCPY
  fprintf(stderr, "[intl/localealias.c] enter read_alias_file 2\n");
  mempcpy (mempcpy (full_fname, fname, fname_len),
	   aliasfile, sizeof aliasfile);
  fprintf(stderr, "[intl/localealias.c] exit read_alias_file 2\n");
#else
  fprintf(stderr, "[intl/localealias.c] enter read_alias_file 3\n");
  memcpy (full_fname, fname, fname_len);
  memcpy (&full_fname[fname_len], aliasfile, sizeof aliasfile);
  fprintf(stderr, "[intl/localealias.c] exit read_alias_file 3\n");
#endif

#ifdef _LIBC
  /* Note the file is opened with cancellation in the I/O functions
     disabled.  */
  fprintf(stderr, "[intl/localealias.c] enter read_alias_file 4\n");
  fp = fopen (relocate (full_fname), "rc");
  fprintf(stderr, "[intl/localealias.c] exit read_alias_file 4\n");
#else
  fprintf(stderr, "[intl/localealias.c] enter read_alias_file 5\n");
  fp = fopen (relocate (full_fname), "r");
  fprintf(stderr, "[intl/localealias.c] exit read_alias_file 5\n");
#endif
  
  fprintf(stderr, "[intl/localealias.c] enter read_alias_file 6\n");
  freea (full_fname);
  fprintf(stderr, "[intl/localealias.c] exit read_alias_file 6\n");
  
  if (fp == NULL)
  {
    fprintf(stderr, "[intl/localealias.c] enter read_alias_file 7\n");
    return 0;
    fprintf(stderr, "[intl/localealias.c] exit read_alias_file 7\n");
  }

#ifdef HAVE___FSETLOCKING
  /* No threads present.  */
  fprintf(stderr, "[intl/localealias.c] enter read_alias_file 8\n");
  __fsetlocking (fp, FSETLOCKING_BYCALLER);
  fprintf(stderr, "[intl/localealias.c] exit read_alias_file 8\n");
#endif

  fprintf(stderr, "[intl/localealias.c] enter read_alias_file 9\n");
  added = 0;
  fprintf(stderr, "[intl/localealias.c] exit read_alias_file 9\n");
  
  while (!FEOF (fp))
  {
    fprintf(stderr, "[intl/localealias.c] enter read_alias_file 10\n");
    /* It is a reasonable approach to use a fix buffer here because
       a) we are only interested in the first two fields
       b) these fields must be usable as file names and so must not
	  be that long
       We avoid a multi-kilobyte buffer here since this would use up
       stack space which we might not have if the program ran out of
       memory.  */
    char buf[400];
    char *alias;
    char *value;
    char *cp;
    int complete_line;

    if (FGETS (buf, sizeof buf, fp) == NULL)
    {
      /* EOF reached.  */
      break;
    }

    /* Determine whether the line is complete.  */
    complete_line = strchr (buf, '\n') != NULL;

    cp = buf;
    /* Ignore leading white space.  */
    while (isspace ((unsigned char) cp[0]))
    {
      ++cp;
    }
    fprintf(stderr, "[intl/localealias.c] exit read_alias_file 10\n");

    /* A leading '#' signals a comment line.  */
    if (cp[0] != '\0' && cp[0] != '#')
    {
      fprintf(stderr, "[intl/localealias.c] enter read_alias_file 11\n");
      alias = cp++;
      while (cp[0] != '\0' && !isspace ((unsigned char) cp[0]))
      {
        ++cp;
      }
      /* Terminate alias name.  */
      if (cp[0] != '\0')
      {
        *cp++ = '\0';
      }

      /* Now look for the beginning of the value.  */
      while (isspace ((unsigned char) cp[0]))
      {
        ++cp;
      }
      fprintf(stderr, "[intl/localealias.c] exit read_alias_file 11\n");

      if (cp[0] != '\0')
      {
        fprintf(stderr, "[intl/localealias.c] enter read_alias_file 12\n");
        value = cp++;
        while (cp[0] != '\0' && !isspace ((unsigned char) cp[0]))
        {
          ++cp;
        }
        /* Terminate value.  */
        if (cp[0] == '\n')
        {
          /* This has to be done to make the following test
             for the end of line possible.  We are looking for
             the terminating '\n' which do not overwrite here.  */
          *cp++ = '\0';
          *cp = '\n';
        }
        else if (cp[0] != '\0')
        {
          *cp++ = '\0';
        }
        fprintf(stderr, "[intl/localealias.c] exit read_alias_file 12\n");

#ifdef IN_LIBGLOCALE
        /* glibc's locale.alias contains entries for ja_JP and ko_KR
           that make it impossible to use a Japanese or Korean UTF-8
           locale under the name "ja_JP" or "ko_KR".  Ignore these
           entries.  */
        if (strchr (alias, '_') == NULL)
#endif
        {
          fprintf(stderr, "[intl/localealias.c] enter read_alias_file 13\n");
          size_t alias_len;
          size_t value_len;

          if (nmap >= maxmap)
          {
            if (__builtin_expect (extend_alias_table (), 0))
            {
              goto out;
            }
          }

          alias_len = strlen (alias) + 1;
          value_len = strlen (value) + 1;
          fprintf(stderr, "[intl/localealias.c] exit read_alias_file 13\n");

          if (string_space_act + alias_len + value_len > string_space_max)
          {
            fprintf(stderr, "[intl/localealias.c] enter read_alias_file 14\n");
            /* Increase size of memory pool.  */
            size_t new_size = (string_space_max
                               + (alias_len + value_len > 1024
                                  ? alias_len + value_len : 1024));
            char *new_pool = (char *) realloc (string_space, new_size);
            if (new_pool == NULL)
            {
              goto out;
            }
            fprintf(stderr, "[intl/localealias.c] exit read_alias_file 14\n");

            if (__builtin_expect (string_space != new_pool, 0))
            {
              fprintf(stderr, "[intl/localealias.c] enter read_alias_file 15\n");
              size_t i;

              for (i = 0; i < nmap; i++)
              {
                map[i].alias += new_pool - string_space;
                map[i].value += new_pool - string_space;
              }
              fprintf(stderr, "[intl/localealias.c] exit read_alias_file 15\n");
            }

            fprintf(stderr, "[intl/localealias.c] enter read_alias_file 16\n");
            string_space = new_pool;
            string_space_max = new_size;
            fprintf(stderr, "[intl/localealias.c] exit read_alias_file 16\n");
          }

          fprintf(stderr, "[intl/localealias.c] enter read_alias_file 17\n");
          map[nmap].alias =
            (const char *) memcpy (&string_space[string_space_act],
                                   alias, alias_len);
          string_space_act += alias_len;

          map[nmap].value =
            (const char *) memcpy (&string_space[string_space_act],
                                   value, value_len);
          string_space_act += value_len;

          ++nmap;
          ++added;
          fprintf(stderr, "[intl/localealias.c] exit read_alias_file 17\n");
        }
      }
    }

    /* Possibly not the whole line fits into the buffer.  Ignore
       the rest of the line.  */
    if (! complete_line)
    {
      fprintf(stderr, "[intl/localealias.c] enter read_alias_file 18\n");
      do
      {
        if (FGETS (buf, sizeof buf, fp) == NULL)
        {
          /* Make sure the inner loop will be left.  The outer loop
             will exit at the `feof' test.  */
          break;
        }
      }
      while (strchr (buf, '\n') == NULL);
      fprintf(stderr, "[intl/localealias.c] exit read_alias_file 18\n");
    }
  }

 out:
  fprintf(stderr, "[intl/localealias.c] enter read_alias_file 19\n");
  /* Should we test for ferror()?  I think we have to silently ignore
     errors.  --drepper  */
  fclose (fp);

  if (added > 0)
  {
    qsort (map, nmap, sizeof (struct alias_map),
           (int (*) (const void *, const void *)) alias_compare);
  }

  return added;
  fprintf(stderr, "[intl/localealias.c] exit read_alias_file 19\n");
}


static int
extend_alias_table ()
{
  fprintf(stderr, "[intl/localealias.c] enter extend_alias_table 1\n");
  size_t new_size;
  struct alias_map *new_map;

  new_size = maxmap == 0 ? 100 : 2 * maxmap;
  new_map = (struct alias_map *) realloc (map, (new_size
						* sizeof (struct alias_map)));
  fprintf(stderr, "[intl/localealias.c] exit extend_alias_table 1\n");
  
  if (new_map == NULL)
  {
    fprintf(stderr, "[intl/localealias.c] enter extend_alias_table 2\n");
    /* Simply don't extend: we don't have any more core.  */
    return -1;
    fprintf(stderr, "[intl/localealias.c] exit extend_alias_table 2\n");
  }

  fprintf(stderr, "[intl/localealias.c] enter extend_alias_table 3\n");
  map = new_map;
  maxmap = new_size;
  return 0;
  fprintf(stderr, "[intl/localealias.c] exit extend_alias_table 3\n");
}


static int
alias_compare (const struct alias_map *map1, const struct alias_map *map2)
{
#if defined _LIBC || defined HAVE_STRCASECMP
  fprintf(stderr, "[intl/localealias.c] enter alias_compare 1\n");
  return strcasecmp (map1->alias, map2->alias);
  fprintf(stderr, "[intl/localealias.c] exit alias_compare 1\n");
#else
  fprintf(stderr, "[intl/localealias.c] enter alias_compare 2\n");
  const unsigned char *p1 = (const unsigned char *) map1->alias;
  const unsigned char *p2 = (const unsigned char *) map2->alias;
  unsigned char c1, c2;

  if (p1 == p2)
  {
    return 0;
  }
  fprintf(stderr, "[intl/localealias.c] exit alias_compare 2\n");

  do
  {
    fprintf(stderr, "[intl/localealias.c] enter alias_compare 3\n");
    /* I know this seems to be odd but the tolower() function in
       some systems libc cannot handle nonalpha characters.  */
    c1 = isupper (*p1) ? tolower (*p1) : *p1;
    c2 = isupper (*p2) ? tolower (*p2) : *p2;
    if (c1 == '\0')
    {
      break;
    }
    ++p1;
    ++p2;
    fprintf(stderr, "[intl/localealias.c] exit alias_compare 3\n");
  }
  while (c1 == c2);

  fprintf(stderr, "[intl/localealias.c] enter alias_compare 4\n");
  return c1 - c2;
  fprintf(stderr, "[intl/localealias.c] exit alias_compare 4\n");
#endif
}
// Total cost: 0.106886
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 439)]
// Total instrumented cost: 0.106886, input tokens: 6167, output tokens: 5332, cache read tokens: 2280, cache write tokens: 3883

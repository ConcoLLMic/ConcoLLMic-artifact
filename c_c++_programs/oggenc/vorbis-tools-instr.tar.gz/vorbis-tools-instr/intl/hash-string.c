/* Implements a string hashing function.
   Copyright (C) 1995, 1997, 1998, 2000, 2003 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, write to the Free
   Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

/* Specification.  */
#include "hash-string.h"
#include <stdio.h>


/* Defines the so called `hashpjw' function by P.J. Weinberger
   [see Aho/Sethi/Ullman, COMPILERS: Principles, Techniques and Tools,
   1986, 1987 Bell Telephone Laboratories, Inc.]  */
unsigned long int
__hash_string (const char *str_param)
{
  fprintf(stderr, "[intl/hash-string.c] enter __hash_string 1\n");
  unsigned long int hval, g;
  const char *str = str_param;

  /* Compute the hash value for the given string.  */
  hval = 0;
  fprintf(stderr, "[intl/hash-string.c] exit __hash_string 1\n");
  
  while (*str != '\0')
    {
      fprintf(stderr, "[intl/hash-string.c] enter __hash_string 2\n");
      hval <<= 4;
      hval += (unsigned char) *str++;
      g = hval & ((unsigned long int) 0xf << (HASHWORDBITS - 4));
      fprintf(stderr, "[intl/hash-string.c] exit __hash_string 2\n");
      
      if (g != 0)
	{
	  fprintf(stderr, "[intl/hash-string.c] enter __hash_string 3\n");
	  hval ^= g >> (HASHWORDBITS - 8);
	  hval ^= g;
	  fprintf(stderr, "[intl/hash-string.c] exit __hash_string 3\n");
	}
    }
  
  fprintf(stderr, "[intl/hash-string.c] enter __hash_string 4\n");
  return hval;
  fprintf(stderr, "[intl/hash-string.c] exit __hash_string 4\n");
}
// Total cost: 0.015018
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 51)]
// Total instrumented cost: 0.015018, input tokens: 2868, output tokens: 692, cache read tokens: 2280, cache write tokens: 584

/* OS/2 compatibility functions.
   Copyright (C) 2001-2002 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU Library General Public License as published
   by the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301,
   USA.  */

#define OS2_AWARE
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdlib.h>
#include <string.h>
#include <sys/param.h>
#include <stdio.h>

/* A version of getenv() that works from DLLs */
extern unsigned long DosScanEnv (const unsigned char *pszName, unsigned char **ppszValue);

char *
_nl_getenv (const char *name)
{
  fprintf(stderr, "[intl/os2compat.c] enter _nl_getenv 1\n");
  unsigned char *value;
  if (DosScanEnv (name, &value))
  {
    fprintf(stderr, "[intl/os2compat.c] enter _nl_getenv 2\n");
    return NULL;
    fprintf(stderr, "[intl/os2compat.c] exit _nl_getenv 2\n");
  }
  else
  {
    fprintf(stderr, "[intl/os2compat.c] enter _nl_getenv 3\n");
    return value;
    fprintf(stderr, "[intl/os2compat.c] exit _nl_getenv 3\n");
  }
  fprintf(stderr, "[intl/os2compat.c] exit _nl_getenv 1\n");
}

/* A fixed size buffer.  */
char libintl_nl_default_dirname[MAXPATHLEN+1];

char *_nlos2_libdir = NULL;
char *_nlos2_localealiaspath = NULL;
char *_nlos2_localedir = NULL;

static __attribute__((constructor)) void
nlos2_initialize ()
{
  fprintf(stderr, "[intl/os2compat.c] enter nlos2_initialize 1\n");
  char *root = getenv ("UNIXROOT");
  char *gnulocaledir = getenv ("GNULOCALEDIR");

  _nlos2_libdir = gnulocaledir;
  if (!_nlos2_libdir)
  {
    fprintf(stderr, "[intl/os2compat.c] enter nlos2_initialize 2\n");
    if (root)
    {
      fprintf(stderr, "[intl/os2compat.c] enter nlos2_initialize 3\n");
      size_t sl = strlen (root);
      _nlos2_libdir = (char *) malloc (sl + strlen (LIBDIR) + 1);
      memcpy (_nlos2_libdir, root, sl);
      memcpy (_nlos2_libdir + sl, LIBDIR, strlen (LIBDIR) + 1);
      fprintf(stderr, "[intl/os2compat.c] exit nlos2_initialize 3\n");
    }
    else
    {
      fprintf(stderr, "[intl/os2compat.c] enter nlos2_initialize 4\n");
      _nlos2_libdir = LIBDIR;
      fprintf(stderr, "[intl/os2compat.c] exit nlos2_initialize 4\n");
    }
    fprintf(stderr, "[intl/os2compat.c] exit nlos2_initialize 2\n");
  }

  _nlos2_localealiaspath = gnulocaledir;
  if (!_nlos2_localealiaspath)
  {
    fprintf(stderr, "[intl/os2compat.c] enter nlos2_initialize 5\n");
    if (root)
    {
      fprintf(stderr, "[intl/os2compat.c] enter nlos2_initialize 6\n");
      size_t sl = strlen (root);
      _nlos2_localealiaspath = (char *) malloc (sl + strlen (LOCALE_ALIAS_PATH) + 1);
      memcpy (_nlos2_localealiaspath, root, sl);
      memcpy (_nlos2_localealiaspath + sl, LOCALE_ALIAS_PATH, strlen (LOCALE_ALIAS_PATH) + 1);
      fprintf(stderr, "[intl/os2compat.c] exit nlos2_initialize 6\n");
    }
    else
    {
      fprintf(stderr, "[intl/os2compat.c] enter nlos2_initialize 7\n");
      _nlos2_localealiaspath = LOCALE_ALIAS_PATH;
      fprintf(stderr, "[intl/os2compat.c] exit nlos2_initialize 7\n");
    }
    fprintf(stderr, "[intl/os2compat.c] exit nlos2_initialize 5\n");
  }

  _nlos2_localedir = gnulocaledir;
  if (!_nlos2_localedir)
  {
    fprintf(stderr, "[intl/os2compat.c] enter nlos2_initialize 8\n");
    if (root)
    {
      fprintf(stderr, "[intl/os2compat.c] enter nlos2_initialize 9\n");
      size_t sl = strlen (root);
      _nlos2_localedir = (char *) malloc (sl + strlen (LOCALEDIR) + 1);
      memcpy (_nlos2_localedir, root, sl);
      memcpy (_nlos2_localedir + sl, LOCALEDIR, strlen (LOCALEDIR) + 1);
      fprintf(stderr, "[intl/os2compat.c] exit nlos2_initialize 9\n");
    }
    else
    {
      fprintf(stderr, "[intl/os2compat.c] enter nlos2_initialize 10\n");
      _nlos2_localedir = LOCALEDIR;
      fprintf(stderr, "[intl/os2compat.c] exit nlos2_initialize 10\n");
    }
    fprintf(stderr, "[intl/os2compat.c] exit nlos2_initialize 8\n");
  }

  if (strlen (_nlos2_localedir) <= MAXPATHLEN)
  {
    fprintf(stderr, "[intl/os2compat.c] enter nlos2_initialize 11\n");
    strcpy (libintl_nl_default_dirname, _nlos2_localedir);
    fprintf(stderr, "[intl/os2compat.c] exit nlos2_initialize 11\n");
  }
  fprintf(stderr, "[intl/os2compat.c] exit nlos2_initialize 1\n");
}
// Total cost: 0.030992
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 98)]
// Total instrumented cost: 0.030992, input tokens: 3330, output tokens: 1549, cache read tokens: 2280, cache write tokens: 1046

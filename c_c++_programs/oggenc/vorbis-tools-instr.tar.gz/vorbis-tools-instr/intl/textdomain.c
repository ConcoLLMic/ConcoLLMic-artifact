/* Implementation of the textdomain(3) function.
   Copyright (C) 1995-1998, 2000-2003, 2005-2006 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU Library General Public License as published
   by the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301,
   USA.  */

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "gettextP.h"
#ifdef _LIBC
# include <libintl.h>
#else
# include "libgnuintl.h"
#endif

/* Handle multi-threaded applications.  */
#ifdef _LIBC
# include <bits/libc-lock.h>
# define gl_rwlock_define __libc_rwlock_define
# define gl_rwlock_wrlock __libc_rwlock_wrlock
# define gl_rwlock_unlock __libc_rwlock_unlock
#else
# include "lock.h"
#endif

/* @@ end of prolog @@ */


/* Names for the libintl functions are a problem.  They must not clash
   with existing names and they should follow ANSI C.  But this source
   code is also used in GNU C Library where the names have a __
   prefix.  So we have to make a difference here.  */
#ifdef _LIBC
# define TEXTDOMAIN __textdomain
# ifndef strdup
#  define strdup(str) __strdup (str)
# endif
#else
# define TEXTDOMAIN libintl_textdomain
#endif

/* Lock variable to protect the global data in the gettext implementation.  */
gl_rwlock_define (extern, _nl_state_lock attribute_hidden)

/* Set the current default message catalog to DOMAINNAME.
   If DOMAINNAME is null, return the current default.
   If DOMAINNAME is "", reset to the default of "messages".  */
char *
TEXTDOMAIN (const char *domainname)
{
  fprintf(stderr, "[intl/textdomain.c] enter TEXTDOMAIN 1\n");
  char *new_domain;
  char *old_domain;
  fprintf(stderr, "[intl/textdomain.c] exit TEXTDOMAIN 1\n");

  /* A NULL pointer requests the current setting.  */
  if (domainname == NULL)
  {
    fprintf(stderr, "[intl/textdomain.c] enter TEXTDOMAIN 2\n");
    return (char *) _nl_current_default_domain;
    fprintf(stderr, "[intl/textdomain.c] exit TEXTDOMAIN 2\n");
  }

  fprintf(stderr, "[intl/textdomain.c] enter TEXTDOMAIN 3\n");
  gl_rwlock_wrlock (_nl_state_lock);

  old_domain = (char *) _nl_current_default_domain;
  fprintf(stderr, "[intl/textdomain.c] exit TEXTDOMAIN 3\n");

  /* If domain name is the null string set to default domain "messages".  */
  if (domainname[0] == '\0'
      || strcmp (domainname, _nl_default_default_domain) == 0)
  {
    fprintf(stderr, "[intl/textdomain.c] enter TEXTDOMAIN 4\n");
    _nl_current_default_domain = _nl_default_default_domain;
    new_domain = (char *) _nl_current_default_domain;
    fprintf(stderr, "[intl/textdomain.c] exit TEXTDOMAIN 4\n");
  }
  else if (strcmp (domainname, old_domain) == 0)
  {
    fprintf(stderr, "[intl/textdomain.c] enter TEXTDOMAIN 5\n");
    /* This can happen and people will use it to signal that some
       environment variable changed.  */
    new_domain = old_domain;
    fprintf(stderr, "[intl/textdomain.c] exit TEXTDOMAIN 5\n");
  }
  else
  {
    fprintf(stderr, "[intl/textdomain.c] enter TEXTDOMAIN 6\n");
    /* If the following malloc fails `_nl_current_default_domain'
       will be NULL.  This value will be returned and so signals we
       are out of core.  */
#if defined _LIBC || defined HAVE_STRDUP
    new_domain = strdup (domainname);
#else
    size_t len = strlen (domainname) + 1;
    new_domain = (char *) malloc (len);
    if (new_domain != NULL)
    {
      fprintf(stderr, "[intl/textdomain.c] enter TEXTDOMAIN 7\n");
      memcpy (new_domain, domainname, len);
      fprintf(stderr, "[intl/textdomain.c] exit TEXTDOMAIN 7\n");
    }
#endif

    if (new_domain != NULL)
    {
      fprintf(stderr, "[intl/textdomain.c] enter TEXTDOMAIN 8\n");
      _nl_current_default_domain = new_domain;
      fprintf(stderr, "[intl/textdomain.c] exit TEXTDOMAIN 8\n");
    }
    fprintf(stderr, "[intl/textdomain.c] exit TEXTDOMAIN 6\n");
  }

  /* We use this possibility to signal a change of the loaded catalogs
     since this is most likely the case and there is no other easy we
     to do it.  Do it only when the call was successful.  */
  if (new_domain != NULL)
  {
    fprintf(stderr, "[intl/textdomain.c] enter TEXTDOMAIN 9\n");
    ++_nl_msg_cat_cntr;

    if (old_domain != new_domain && old_domain != _nl_default_default_domain)
    {
      fprintf(stderr, "[intl/textdomain.c] enter TEXTDOMAIN 10\n");
      free (old_domain);
      fprintf(stderr, "[intl/textdomain.c] exit TEXTDOMAIN 10\n");
    }
    fprintf(stderr, "[intl/textdomain.c] exit TEXTDOMAIN 9\n");
  }

  fprintf(stderr, "[intl/textdomain.c] enter TEXTDOMAIN 11\n");
  gl_rwlock_unlock (_nl_state_lock);

  return new_domain;
  fprintf(stderr, "[intl/textdomain.c] exit TEXTDOMAIN 11\n");
}

#ifdef _LIBC
/* Alias for function name in GNU C Library.  */
weak_alias (__textdomain, textdomain);
#endif
// Total cost: 0.034243
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 127)]
// Total instrumented cost: 0.034243, input tokens: 3574, output tokens: 1656, cache read tokens: 2280, cache write tokens: 1290

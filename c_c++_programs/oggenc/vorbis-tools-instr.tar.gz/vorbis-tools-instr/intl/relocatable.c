/* Provide relocatable packages.
   Copyright (C) 2003-2006 Free Software Foundation, Inc.
   Written by Bruno Haible <bruno@clisp.org>, 2003.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU Library General Public License as published
   by the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301,
   USA.  */


/* Tell glibc's <stdio.h> to provide a prototype for getline().
   This must come before <config.h> because <config.h> may include
   <features.h>, and once <features.h> has been included, it's too late.  */
#ifndef _GNU_SOURCE
# define _GNU_SOURCE	1
#endif

#include <config.h>

/* Specification.  */
#include "relocatable.h"

#if ENABLE_RELOCATABLE

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef NO_XMALLOC
# define xmalloc malloc
#else
# include "xalloc.h"
#endif

#if defined _WIN32 || defined __WIN32__ || defined __CYGWIN__
# define WIN32_LEAN_AND_MEAN
# include <windows.h>
#endif

#if DEPENDS_ON_LIBCHARSET
# include <libcharset.h>
#endif
#if DEPENDS_ON_LIBICONV && HAVE_ICONV
# include <iconv.h>
#endif
#if DEPENDS_ON_LIBINTL && ENABLE_NLS
# include <libintl.h>
#endif

/* Faked cheap 'bool'.  */
#undef bool
#undef false
#undef true
#define bool int
#define false 0
#define true 1

/* Pathname support.
   ISSLASH(C)           tests whether C is a directory separator character.
   IS_PATH_WITH_DIR(P)  tests whether P contains a directory specification.
 */
#if defined _WIN32 || defined __WIN32__ || defined __CYGWIN__ || defined __EMX__ || defined __DJGPP__
  /* Win32, Cygwin, OS/2, DOS */
# define ISSLASH(C) ((C) == '/' || (C) == '\\')
# define HAS_DEVICE(P) \
    ((((P)[0] >= 'A' && (P)[0] <= 'Z') || ((P)[0] >= 'a' && (P)[0] <= 'z')) \
     && (P)[1] == ':')
# define IS_PATH_WITH_DIR(P) \
    (strchr (P, '/') != NULL || strchr (P, '\\') != NULL || HAS_DEVICE (P))
# define FILE_SYSTEM_PREFIX_LEN(P) (HAS_DEVICE (P) ? 2 : 0)
#else
  /* Unix */
# define ISSLASH(C) ((C) == '/')
# define IS_PATH_WITH_DIR(P) (strchr (P, '/') != NULL)
# define FILE_SYSTEM_PREFIX_LEN(P) 0
#endif

/* Original installation prefix.  */
static char *orig_prefix;
static size_t orig_prefix_len;
/* Current installation prefix.  */
static char *curr_prefix;
static size_t curr_prefix_len;
/* These prefixes do not end in a slash.  Anything that will be concatenated
   to them must start with a slash.  */

/* Sets the original and the current installation prefix of this module.
   Relocation simply replaces a pathname starting with the original prefix
   by the corresponding pathname with the current prefix instead.  Both
   prefixes should be directory names without trailing slash (i.e. use ""
   instead of "/").  */
static void
set_this_relocation_prefix (const char *orig_prefix_arg,
			    const char *curr_prefix_arg)
{
  fprintf(stderr, "[intl/relocatable.c] enter set_this_relocation_prefix 1\n");
  if (orig_prefix_arg != NULL && curr_prefix_arg != NULL
      /* Optimization: if orig_prefix and curr_prefix are equal, the
	 relocation is a nop.  */
      && strcmp (orig_prefix_arg, curr_prefix_arg) != 0)
    {
      fprintf(stderr, "[intl/relocatable.c] enter set_this_relocation_prefix 2\n");
      /* Duplicate the argument strings.  */
      char *memory;

      orig_prefix_len = strlen (orig_prefix_arg);
      curr_prefix_len = strlen (curr_prefix_arg);
      memory = (char *) xmalloc (orig_prefix_len + 1 + curr_prefix_len + 1);
      fprintf(stderr, "[intl/relocatable.c] exit set_this_relocation_prefix 2\n");
#ifdef NO_XMALLOC
      if (memory != NULL)
#endif
	{
          fprintf(stderr, "[intl/relocatable.c] enter set_this_relocation_prefix 3\n");
	  memcpy (memory, orig_prefix_arg, orig_prefix_len + 1);
	  orig_prefix = memory;
	  memory += orig_prefix_len + 1;
	  memcpy (memory, curr_prefix_arg, curr_prefix_len + 1);
	  curr_prefix = memory;
	  fprintf(stderr, "[intl/relocatable.c] exit set_this_relocation_prefix 3\n");
	  return;
	}
    }
  fprintf(stderr, "[intl/relocatable.c] enter set_this_relocation_prefix 4\n");
  orig_prefix = NULL;
  curr_prefix = NULL;
  /* Don't worry about wasted memory here - this function is usually only
     called once.  */
  fprintf(stderr, "[intl/relocatable.c] exit set_this_relocation_prefix 4\n");
  fprintf(stderr, "[intl/relocatable.c] exit set_this_relocation_prefix 1\n");
}

/* Sets the original and the current installation prefix of the package.
   Relocation simply replaces a pathname starting with the original prefix
   by the corresponding pathname with the current prefix instead.  Both
   prefixes should be directory names without trailing slash (i.e. use ""
   instead of "/").  */
void
set_relocation_prefix (const char *orig_prefix_arg, const char *curr_prefix_arg)
{
  fprintf(stderr, "[intl/relocatable.c] enter set_relocation_prefix 1\n");
  set_this_relocation_prefix (orig_prefix_arg, curr_prefix_arg);

  /* Now notify all dependent libraries.  */
#if DEPENDS_ON_LIBCHARSET
  libcharset_set_relocation_prefix (orig_prefix_arg, curr_prefix_arg);
#endif
#if DEPENDS_ON_LIBICONV && HAVE_ICONV && _LIBICONV_VERSION >= 0x0109
  libiconv_set_relocation_prefix (orig_prefix_arg, curr_prefix_arg);
#endif
#if DEPENDS_ON_LIBINTL && ENABLE_NLS && defined libintl_set_relocation_prefix
  libintl_set_relocation_prefix (orig_prefix_arg, curr_prefix_arg);
#endif
  fprintf(stderr, "[intl/relocatable.c] exit set_relocation_prefix 1\n");
}

#if !defined IN_LIBRARY || (defined PIC && defined INSTALLDIR)

/* Convenience function:
   Computes the current installation prefix, based on the original
   installation prefix, the original installation directory of a particular
   file, and the current pathname of this file.  Returns NULL upon failure.  */
#ifdef IN_LIBRARY
#define compute_curr_prefix local_compute_curr_prefix
static
#endif
const char *
compute_curr_prefix (const char *orig_installprefix,
		     const char *orig_installdir,
		     const char *curr_pathname)
{
  fprintf(stderr, "[intl/relocatable.c] enter compute_curr_prefix 1\n");
  const char *curr_installdir;
  const char *rel_installdir;

  if (curr_pathname == NULL)
  {
    fprintf(stderr, "\n");
    fprintf(stderr, "\n");
    return NULL;
  }

  /* Determine the relative installation directory, relative to the prefix.
     This is simply the difference between orig_installprefix and
     orig_installdir.  */
  if (strncmp (orig_installprefix, orig_installdir, strlen (orig_installprefix))
      != 0)
  {
    fprintf(stderr, "[intl/relocatable.c] enter compute_curr_prefix 3\n");
    /* Shouldn't happen - nothing should be installed outside $(prefix).  */
    fprintf(stderr, "[intl/relocatable.c] exit compute_curr_prefix 3\n");
    return NULL;
  }
  fprintf(stderr, "[intl/relocatable.c] enter compute_curr_prefix 4\n");
  rel_installdir = orig_installdir + strlen (orig_installprefix);
  fprintf(stderr, "[intl/relocatable.c] exit compute_curr_prefix 4\n");

  /* Determine the current installation directory.  */
  {
    fprintf(stderr, "[intl/relocatable.c] enter compute_curr_prefix 5\n");
    const char *p_base = curr_pathname + FILE_SYSTEM_PREFIX_LEN (curr_pathname);
    const char *p = curr_pathname + strlen (curr_pathname);
    char *q;

    while (p > p_base)
      {
        p--;
	if (ISSLASH (*p))
	  break;
      }

    q = (char *) xmalloc (p - curr_pathname + 1);
#ifdef NO_XMALLOC
    if (q == NULL)
    {
      fprintf(stderr, "\n");
      fprintf(stderr, "\n");
      return NULL;
    }
#endif
    fprintf(stderr, "[intl/relocatable.c] enter compute_curr_prefix 7\n");
    memcpy (q, curr_pathname, p - curr_pathname);
    q[p - curr_pathname] = '\0';
    curr_installdir = q;
    fprintf(stderr, "[intl/relocatable.c] exit compute_curr_prefix 7\n");
    fprintf(stderr, "[intl/relocatable.c] exit compute_curr_prefix 5\n");
  }

  /* Compute the current installation prefix by removing the trailing
     rel_installdir from it.  */
  {
    fprintf(stderr, "[intl/relocatable.c] enter compute_curr_prefix 8\n");
    const char *rp = rel_installdir + strlen (rel_installdir);
    const char *cp = curr_installdir + strlen (curr_installdir);
    const char *cp_base =
      curr_installdir + FILE_SYSTEM_PREFIX_LEN (curr_installdir);

    while (rp > rel_installdir && cp > cp_base)
      {
	bool same = false;
	const char *rpi = rp;
	const char *cpi = cp;

	while (rpi > rel_installdir && cpi > cp_base)
	  {
	    rpi--;
	    cpi--;
	    if (ISSLASH (*rpi) || ISSLASH (*cpi))
	      {
		if (ISSLASH (*rpi) && ISSLASH (*cpi))
		  same = true;
		break;
	      }
	    /* Do case-insensitive comparison if the filesystem is always or
	       often case-insensitive.  It's better to accept the comparison
	       if the difference is only in case, rather than to fail.  */
#if defined _WIN32 || defined __WIN32__ || defined __CYGWIN__ || defined __EMX__ || defined __DJGPP__
	    /* Win32, Cygwin, OS/2, DOS - case insignificant filesystem */
	    if ((*rpi >= 'a' && *rpi <= 'z' ? *rpi - 'a' + 'A' : *rpi)
		!= (*cpi >= 'a' && *cpi <= 'z' ? *cpi - 'a' + 'A' : *cpi))
	      break;
#else
	    if (*rpi != *cpi)
	      break;
#endif
	  }
	if (!same)
	  break;
	/* The last pathname component was the same.  opi and cpi now point
	   to the slash before it.  */
	rp = rpi;
	cp = cpi;
      }

    if (rp > rel_installdir)
    {
      fprintf(stderr, "[intl/relocatable.c] enter compute_curr_prefix 9\n");
      /* Unexpected: The curr_installdir does not end with rel_installdir.  */
      fprintf(stderr, "[intl/relocatable.c] exit compute_curr_prefix 9\n");
      return NULL;
    }

    {
      fprintf(stderr, "[intl/relocatable.c] enter compute_curr_prefix 10\n");
      size_t curr_prefix_len = cp - curr_installdir;
      char *curr_prefix;

      curr_prefix = (char *) xmalloc (curr_prefix_len + 1);
#ifdef NO_XMALLOC
      if (curr_prefix == NULL)
      {
        fprintf(stderr, "\n");
        fprintf(stderr, "\n");
	return NULL;
      }
#endif
      fprintf(stderr, "[intl/relocatable.c] enter compute_curr_prefix 12\n");
      memcpy (curr_prefix, curr_installdir, curr_prefix_len);
      curr_prefix[curr_prefix_len] = '\0';
      fprintf(stderr, "[intl/relocatable.c] exit compute_curr_prefix 12\n");

      fprintf(stderr, "[intl/relocatable.c] exit compute_curr_prefix 10\n");
      return curr_prefix;
    }
    fprintf(stderr, "[intl/relocatable.c] exit compute_curr_prefix 8\n");
  }
  fprintf(stderr, "[intl/relocatable.c] exit compute_curr_prefix 1\n");
}

#endif /* !IN_LIBRARY || PIC */

#if defined PIC && defined INSTALLDIR

/* Full pathname of shared library, or NULL.  */
static char *shared_library_fullname;

#if defined _WIN32 || defined __WIN32__ || defined __CYGWIN__

/* Determine the full pathname of the shared library when it is loaded.  */

BOOL WINAPI
DllMain (HINSTANCE module_handle, DWORD event, LPVOID reserved)
{
  fprintf(stderr, "[intl/relocatable.c] enter DllMain 1\n");
  (void) reserved;

  if (event == DLL_PROCESS_ATTACH)
    {
      fprintf(stderr, "[intl/relocatable.c] enter DllMain 2\n");
      /* The DLL is being loaded into an application's address range.  */
      static char location[MAX_PATH];

      if (!GetModuleFileName (module_handle, location, sizeof (location)))
      {
        fprintf(stderr, "[intl/relocatable.c] enter DllMain 3\n");
	/* Shouldn't happen.  */
        fprintf(stderr, "[intl/relocatable.c] exit DllMain 3\n");
	return FALSE;
      }

      if (!IS_PATH_WITH_DIR (location))
      {
        fprintf(stderr, "[intl/relocatable.c] enter DllMain 4\n");
	/* Shouldn't happen.  */
        fprintf(stderr, "[intl/relocatable.c] exit DllMain 4\n");
	return FALSE;
      }

      {
        fprintf(stderr, "[intl/relocatable.c] enter DllMain 5\n");
#if defined __CYGWIN__
	/* On Cygwin, we need to convert paths coming from Win32 system calls
	   to the Unix-like slashified notation.  */
	static char location_as_posix_path[2 * MAX_PATH];
	/* There's no error return defined for cygwin_conv_to_posix_path.
	   See cygwin-api/func-cygwin-conv-to-posix-path.html.
	   Does it overflow the buffer of expected size MAX_PATH or does it
	   truncate the path?  I don't know.  Let's catch both.  */
	cygwin_conv_to_posix_path (location, location_as_posix_path);
	location_as_posix_path[MAX_PATH - 1] = '\0';
	if (strlen (location_as_posix_path) >= MAX_PATH - 1)
	{
          fprintf(stderr, "[intl/relocatable.c] enter DllMain 6\n");
	  /* A sign of buffer overflow or path truncation.  */
          fprintf(stderr, "[intl/relocatable.c] exit DllMain 6\n");
	  return FALSE;
        }
        fprintf(stderr, "[intl/relocatable.c] enter DllMain 7\n");
	shared_library_fullname = strdup (location_as_posix_path);
        fprintf(stderr, "[intl/relocatable.c] exit DllMain 7\n");
#else
        fprintf(stderr, "[intl/relocatable.c] enter DllMain 8\n");
	shared_library_fullname = strdup (location);
        fprintf(stderr, "[intl/relocatable.c] exit DllMain 8\n");
#endif
        fprintf(stderr, "[intl/relocatable.c] exit DllMain 5\n");
      }
      fprintf(stderr, "[intl/relocatable.c] exit DllMain 2\n");
    }

  fprintf(stderr, "[intl/relocatable.c] exit DllMain 1\n");
  return TRUE;
}

#else /* Unix except Cygwin */

static void
find_shared_library_fullname ()
{
  fprintf(stderr, "[intl/relocatable.c] enter find_shared_library_fullname 1\n");
#if defined __linux__ && __GLIBC__ >= 2
  /* Linux has /proc/self/maps. glibc 2 has the getline() function.  */
  FILE *fp;

  /* Open the current process' maps file.  It describes one VMA per line.  */
  fp = fopen ("/proc/self/maps", "r");
  if (fp)
    {
      fprintf(stderr, "[intl/relocatable.c] enter find_shared_library_fullname 2\n");
      unsigned long address = (unsigned long) &find_shared_library_fullname;
      for (;;)
	{
          fprintf(stderr, "[intl/relocatable.c] enter find_shared_library_fullname 3\n");
	  unsigned long start, end;
	  int c;

	  if (fscanf (fp, "%lx-%lx", &start, &end) != 2)
	  {
            fprintf(stderr, "\n");
            fprintf(stderr, "\n");
	    break;
          }
	  if (address >= start && address <= end - 1)
	    {
              fprintf(stderr, "[intl/relocatable.c] enter find_shared_library_fullname 5\n");
	      /* Found it.  Now see if this line contains a filename.  */
	      while (c = getc (fp), c != EOF && c != '\n' && c != '/')
		continue;
	      if (c == '/')
		{
                  fprintf(stderr, "[intl/relocatable.c] enter find_shared_library_fullname 6\n");
		  size_t size;
		  int len;

		  ungetc (c, fp);
		  shared_library_fullname = NULL; size = 0;
		  len = getline (&shared_library_fullname, &size, fp);
		  if (len >= 0)
		    {
                      fprintf(stderr, "[intl/relocatable.c] enter find_shared_library_fullname 7\n");
		      /* Success: filled shared_library_fullname.  */
		      if (len > 0 && shared_library_fullname[len - 1] == '\n')
			shared_library_fullname[len - 1] = '\0';
                      fprintf(stderr, "[intl/relocatable.c] exit find_shared_library_fullname 7\n");
		    }
                  fprintf(stderr, "[intl/relocatable.c] exit find_shared_library_fullname 6\n");
		}
              fprintf(stderr, "[intl/relocatable.c] exit find_shared_library_fullname 5\n");
	      break;
	    }
          fprintf(stderr, "[intl/relocatable.c] enter find_shared_library_fullname 8\n");
	  while (c = getc (fp), c != EOF && c != '\n')
	    continue;
          fprintf(stderr, "[intl/relocatable.c] exit find_shared_library_fullname 8\n");
          fprintf(stderr, "[intl/relocatable.c] exit find_shared_library_fullname 3\n");
	}
      fprintf(stderr, "[intl/relocatable.c] enter find_shared_library_fullname 9\n");
      fclose (fp);
      fprintf(stderr, "[intl/relocatable.c] exit find_shared_library_fullname 9\n");
      fprintf(stderr, "[intl/relocatable.c] exit find_shared_library_fullname 2\n");
    }
#endif
  fprintf(stderr, "[intl/relocatable.c] exit find_shared_library_fullname 1\n");
}

#endif /* (WIN32 or Cygwin) / (Unix except Cygwin) */

/* Return the full pathname of the current shared library.
   Return NULL if unknown.
   Guaranteed to work only on Linux, Cygwin and Woe32.  */
static char *
get_shared_library_fullname ()
{
  fprintf(stderr, "[intl/relocatable.c] enter get_shared_library_fullname 1\n");
#if !(defined _WIN32 || defined __WIN32__ || defined __CYGWIN__)
  static bool tried_find_shared_library_fullname;
  if (!tried_find_shared_library_fullname)
    {
      fprintf(stderr, "[intl/relocatable.c] enter get_shared_library_fullname 2\n");
      find_shared_library_fullname ();
      tried_find_shared_library_fullname = true;
      fprintf(stderr, "[intl/relocatable.c] exit get_shared_library_fullname 2\n");
    }
#endif
  fprintf(stderr, "[intl/relocatable.c] exit get_shared_library_fullname 1\n");
  return shared_library_fullname;
}

#endif /* PIC */

/* Returns the pathname, relocated according to the current installation
   directory.  */
const char *
relocate (const char *pathname)
{
  fprintf(stderr, "[intl/relocatable.c] enter relocate 1\n");
#if defined PIC && defined INSTALLDIR
  static int initialized;

  /* Initialization code for a shared library.  */
  if (!initialized)
    {
      fprintf(stderr, "[intl/relocatable.c] enter relocate 2\n");
      /* At this point, orig_prefix and curr_prefix likely have already been
	 set through the main program's set_program_name_and_installdir
	 function.  This is sufficient in the case that the library has
	 initially been installed in the same orig_prefix.  But we can do
	 better, to also cover the cases that 1. it has been installed
	 in a different prefix before being moved to orig_prefix and (later)
	 to curr_prefix, 2. unlike the program, it has not moved away from
	 orig_prefix.  */
      const char *orig_installprefix = INSTALLPREFIX;
      const char *orig_installdir = INSTALLDIR;
      const char *curr_prefix_better;

      curr_prefix_better =
	compute_curr_prefix (orig_installprefix, orig_installdir,
			     get_shared_library_fullname ());
      if (curr_prefix_better == NULL)
      {
        fprintf(stderr, "[intl/relocatable.c] enter relocate 3\n");
	curr_prefix_better = curr_prefix;
        fprintf(stderr, "[intl/relocatable.c] exit relocate 3\n");
      }

      fprintf(stderr, "[intl/relocatable.c] enter relocate 4\n");
      set_relocation_prefix (orig_installprefix, curr_prefix_better);

      initialized = 1;
      fprintf(stderr, "[intl/relocatable.c] exit relocate 4\n");
      fprintf(stderr, "[intl/relocatable.c] exit relocate 2\n");
    }
#endif

  /* Note: It is not necessary to perform case insensitive comparison here,
     even for DOS-like filesystems, because the pathname argument was
     typically created from the same Makefile variable as orig_prefix came
     from.  */
  fprintf(stderr, "[intl/relocatable.c] enter relocate 5\n");
  if (orig_prefix != NULL && curr_prefix != NULL
      && strncmp (pathname, orig_prefix, orig_prefix_len) == 0)
    {
      fprintf(stderr, "[intl/relocatable.c] enter relocate 6\n");
      if (pathname[orig_prefix_len] == '\0')
	{
          fprintf(stderr, "[intl/relocatable.c] enter relocate 7\n");
	  /* pathname equals orig_prefix.  */
          fprintf(stderr, "[intl/relocatable.c] exit relocate 7\n");
	  return curr_prefix;
        }
      if (ISSLASH (pathname[orig_prefix_len]))
	{
          fprintf(stderr, "[intl/relocatable.c] enter relocate 8\n");
	  /* pathname starts with orig_prefix.  */
	  const char *pathname_tail = &pathname[orig_prefix_len];
	  char *result =
	    (char *) xmalloc (curr_prefix_len + strlen (pathname_tail) + 1);

#ifdef NO_XMALLOC
	  if (result != NULL)
#endif
	    {
              fprintf(stderr, "[intl/relocatable.c] enter relocate 9\n");
	      memcpy (result, curr_prefix, curr_prefix_len);
	      strcpy (result + curr_prefix_len, pathname_tail);
              fprintf(stderr, "[intl/relocatable.c] exit relocate 9\n");
	      return result;
	    }
          fprintf(stderr, "[intl/relocatable.c] exit relocate 8\n");
	}
      fprintf(stderr, "[intl/relocatable.c] exit relocate 6\n");
    }
  /* Nothing to relocate.  */
  fprintf(stderr, "[intl/relocatable.c] exit relocate 5\n");
  fprintf(stderr, "[intl/relocatable.c] exit relocate 1\n");
  return pathname;
}

#endif
// Total cost: 0.413403
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 468)]
// Total instrumented cost: 0.413403, input tokens: 42470, output tokens: 20628, cache read tokens: 28317, cache write tokens: 14141

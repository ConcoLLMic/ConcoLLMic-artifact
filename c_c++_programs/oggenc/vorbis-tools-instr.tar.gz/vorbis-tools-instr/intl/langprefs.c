/* Determine the user's language preferences.
   Copyright (C) 2004-2006 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU Library General Public License as published
   by the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301,
   USA.  */

/* Written by Bruno Haible <bruno@clisp.org>.  */

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <stdlib.h>
#include <stdio.h>

#if HAVE_CFPREFERENCESCOPYAPPVALUE
# include <string.h>
# include <CoreFoundation/CFPreferences.h>
# include <CoreFoundation/CFPropertyList.h>
# include <CoreFoundation/CFArray.h>
# include <CoreFoundation/CFString.h>
extern void _nl_locale_name_canonicalize (char *name);
#endif

/* Determine the user's language preferences, as a colon separated list of
   locale names in XPG syntax
     language[_territory][.codeset][@modifier]
   The result must not be freed; it is statically allocated.
   The LANGUAGE environment variable does not need to be considered; it is
   already taken into account by the caller.  */

const char *
_nl_language_preferences_default (void)
{
  fprintf(stderr, "\n");
#if HAVE_CFPREFERENCESCOPYAPPVALUE /* MacOS X 10.2 or newer */
  {
    /* Cache the preferences list, since CoreFoundation calls are expensive.  */
    static const char *cached_languages;
    static int cache_initialized;

    if (!cache_initialized)
    {
      fprintf(stderr, "[intl/langprefs.c] enter _nl_language_preferences_default 2\n");
      CFTypeRef preferences =
        CFPreferencesCopyAppValue (CFSTR ("AppleLanguages"),
                                   kCFPreferencesCurrentApplication);
      if (preferences != NULL
          && CFGetTypeID (preferences) == CFArrayGetTypeID ())
      {
        fprintf(stderr, "[intl/langprefs.c] enter _nl_language_preferences_default 3\n");
        CFArrayRef prefArray = (CFArrayRef)preferences;
        int n = CFArrayGetCount (prefArray);
        char buf[256];
        size_t size = 0;
        int i;

        for (i = 0; i < n; i++)
        {
          fprintf(stderr, "[intl/langprefs.c] enter _nl_language_preferences_default 4\n");
          CFTypeRef element = CFArrayGetValueAtIndex (prefArray, i);
          if (element != NULL
              && CFGetTypeID (element) == CFStringGetTypeID ()
              && CFStringGetCString ((CFStringRef)element,
                                     buf, sizeof (buf),
                                     kCFStringEncodingASCII))
          {
            fprintf(stderr, "[intl/langprefs.c] enter _nl_language_preferences_default 5\n");
            _nl_locale_name_canonicalize (buf);
            size += strlen (buf) + 1;
            /* Most GNU programs use msgids in English and don't ship
               an en.mo message catalog.  Therefore when we see "en"
               in the preferences list, arrange for gettext() to
               return the msgid, and ignore all further elements of
               the preferences list.  */
            if (strcmp (buf, "en") == 0)
            {
              fprintf(stderr, "[intl/langprefs.c] enter _nl_language_preferences_default 6\n");
              break;
              fprintf(stderr, "[intl/langprefs.c] exit _nl_language_preferences_default 6\n");
            }
            fprintf(stderr, "[intl/langprefs.c] exit _nl_language_preferences_default 5\n");
          }
          else
          {
            fprintf(stderr, "[intl/langprefs.c] enter _nl_language_preferences_default 7\n");
            break;
            fprintf(stderr, "[intl/langprefs.c] exit _nl_language_preferences_default 7\n");
          }
          fprintf(stderr, "[intl/langprefs.c] exit _nl_language_preferences_default 4\n");
        }
        if (size > 0)
        {
          fprintf(stderr, "[intl/langprefs.c] enter _nl_language_preferences_default 8\n");
          char *languages = (char *) malloc (size);

          if (languages != NULL)
          {
            fprintf(stderr, "[intl/langprefs.c] enter _nl_language_preferences_default 9\n");
            char *p = languages;

            for (i = 0; i < n; i++)
            {
              fprintf(stderr, "[intl/langprefs.c] enter _nl_language_preferences_default 10\n");
              CFTypeRef element =
                CFArrayGetValueAtIndex (prefArray, i);
              if (element != NULL
                  && CFGetTypeID (element) == CFStringGetTypeID ()
                  && CFStringGetCString ((CFStringRef)element,
                                         buf, sizeof (buf),
                                         kCFStringEncodingASCII))
              {
                fprintf(stderr, "[intl/langprefs.c] enter _nl_language_preferences_default 11\n");
                _nl_locale_name_canonicalize (buf);
                strcpy (p, buf);
                p += strlen (buf);
                *p++ = ':';
                if (strcmp (buf, "en") == 0)
                {
                  fprintf(stderr, "[intl/langprefs.c] enter _nl_language_preferences_default 12\n");
                  break;
                  fprintf(stderr, "[intl/langprefs.c] exit _nl_language_preferences_default 12\n");
                }
                fprintf(stderr, "[intl/langprefs.c] exit _nl_language_preferences_default 11\n");
              }
              else
              {
                fprintf(stderr, "[intl/langprefs.c] enter _nl_language_preferences_default 13\n");
                break;
                fprintf(stderr, "[intl/langprefs.c] exit _nl_language_preferences_default 13\n");
              }
              fprintf(stderr, "[intl/langprefs.c] exit _nl_language_preferences_default 10\n");
            }
            *--p = '\0';

            cached_languages = languages;
            fprintf(stderr, "[intl/langprefs.c] exit _nl_language_preferences_default 9\n");
          }
          fprintf(stderr, "[intl/langprefs.c] exit _nl_language_preferences_default 8\n");
        }
        fprintf(stderr, "[intl/langprefs.c] exit _nl_language_preferences_default 3\n");
      }
      cache_initialized = 1;
      fprintf(stderr, "[intl/langprefs.c] exit _nl_language_preferences_default 2\n");
    }
    if (cached_languages != NULL)
    {
      fprintf(stderr, "[intl/langprefs.c] enter _nl_language_preferences_default 14\n");
      return cached_languages;
      fprintf(stderr, "[intl/langprefs.c] exit _nl_language_preferences_default 14\n");
    }
  }
#endif

  fprintf(stderr, "[intl/langprefs.c] enter _nl_language_preferences_default 15\n");
  return NULL;
  fprintf(stderr, "[intl/langprefs.c] exit _nl_language_preferences_default 15\n");
}
// Total cost: 0.036692
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 130)]
// Total instrumented cost: 0.036692, input tokens: 3550, output tokens: 1830, cache read tokens: 2280, cache write tokens: 1266

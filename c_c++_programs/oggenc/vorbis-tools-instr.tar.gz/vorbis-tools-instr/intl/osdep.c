#include <stdio.h>

/* OS dependent parts of libintl.
   Copyright (C) 2001-2002, 2006 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU Library General Public License as published
   by the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301,
   USA.  */

#if defined __CYGWIN__
fprintf(stderr, "[intl/osdep.c] enter module 1\n");
# include "intl-exports.c"
fprintf(stderr, "[intl/osdep.c] exit module 1\n");
#elif defined __EMX__
fprintf(stderr, "[intl/osdep.c] enter module 2\n");
# include "os2compat.c"
fprintf(stderr, "[intl/osdep.c] exit module 2\n");
#else
fprintf(stderr, "[intl/osdep.c] enter module 3\n");
/* Avoid AIX compiler warning.  */
typedef int dummy;
fprintf(stderr, "[intl/osdep.c] exit module 3\n");
#endif
// Total cost: 0.008407
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 26)]
// Total instrumented cost: 0.008407, input tokens: 2613, output tokens: 366, cache read tokens: 2280, cache write tokens: 329

/* Log file output.
   Copyright (C) 2003, 2005 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU Library General Public License as published
   by the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301,
   USA.  */

/* Written by Bruno Haible <bruno@clisp.org>.  */

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Handle multi-threaded applications.  */
#ifdef _LIBC
# include <bits/libc-lock.h>
#else
# include "lock.h"
#endif

/* Print an ASCII string with quotes and escape sequences where needed.  */
static void
print_escaped (FILE *stream, const char *str)
{
  fprintf(stderr, "[intl/log.c] enter print_escaped 1\n");
  putc ('"', stream);
  for (; *str != '\0'; str++)
    if (*str == '\n')
      {
        fprintf(stderr, "[intl/log.c] enter print_escaped 2\n");
	fputs ("\\n\"", stream);
	if (str[1] == '\0')
	  return;
        fprintf(stderr, "[intl/log.c] exit print_escaped 2\n");
	fputs ("\n\"", stream);
      }
    else
      {
        fprintf(stderr, "[intl/log.c] enter print_escaped 3\n");
	if (*str == '"' || *str == '\\')
	  putc ('\\', stream);
	putc (*str, stream);
        fprintf(stderr, "[intl/log.c] exit print_escaped 3\n");
      }
  putc ('"', stream);
  fprintf(stderr, "[intl/log.c] exit print_escaped 1\n");
}

static char *last_logfilename = NULL;
static FILE *last_logfile = NULL;
__libc_lock_define_initialized (static, lock)

static inline void
_nl_log_untranslated_locked (const char *logfilename, const char *domainname,
			     const char *msgid1, const char *msgid2, int plural)
{
  fprintf(stderr, "[intl/log.c] enter _nl_log_untranslated_locked 1\n");
  FILE *logfile;

  /* Can we reuse the last opened logfile?  */
  if (last_logfilename == NULL || strcmp (logfilename, last_logfilename) != 0)
    {
      fprintf(stderr, "[intl/log.c] enter _nl_log_untranslated_locked 2\n");
      /* Close the last used logfile.  */
      if (last_logfilename != NULL)
	{
          fprintf(stderr, "[intl/log.c] enter _nl_log_untranslated_locked 3\n");
	  if (last_logfile != NULL)
	    {
              fprintf(stderr, "[intl/log.c] enter _nl_log_untranslated_locked 4\n");
	      fclose (last_logfile);
	      last_logfile = NULL;
              fprintf(stderr, "[intl/log.c] exit _nl_log_untranslated_locked 4\n");
	    }
	  free (last_logfilename);
	  last_logfilename = NULL;
          fprintf(stderr, "[intl/log.c] exit _nl_log_untranslated_locked 3\n");
	}
      /* Open the logfile.  */
      last_logfilename = (char *) malloc (strlen (logfilename) + 1);
      if (last_logfilename == NULL)
	return;
      fprintf(stderr, "[intl/log.c] exit _nl_log_untranslated_locked 2\n");
      strcpy (last_logfilename, logfilename);
      last_logfile = fopen (logfilename, "a");
      if (last_logfile == NULL)
	return;
    }
  logfile = last_logfile;

  fprintf (logfile, "domain ");
  print_escaped (logfile, domainname);
  fprintf (logfile, "\nmsgid ");
  print_escaped (logfile, msgid1);
  if (plural)
    {
      fprintf(stderr, "[intl/log.c] enter _nl_log_untranslated_locked 5\n");
      fprintf (logfile, "\nmsgid_plural ");
      print_escaped (logfile, msgid2);
      fprintf (logfile, "\nmsgstr[0] \"\"\n");
      fprintf(stderr, "[intl/log.c] exit _nl_log_untranslated_locked 5\n");
    }
  else
    {
      fprintf(stderr, "[intl/log.c] enter _nl_log_untranslated_locked 6\n");
      fprintf (logfile, "\nmsgstr \"\"\n");
      fprintf(stderr, "[intl/log.c] exit _nl_log_untranslated_locked 6\n");
    }
  putc ('\n', logfile);
  fprintf(stderr, "[intl/log.c] exit _nl_log_untranslated_locked 1\n");
}

/* Add to the log file an entry denoting a failed translation.  */
void
_nl_log_untranslated (const char *logfilename, const char *domainname,
		      const char *msgid1, const char *msgid2, int plural)
{
  fprintf(stderr, "[intl/log.c] enter _nl_log_untranslated 1\n");
  __libc_lock_lock (lock);
  _nl_log_untranslated_locked (logfilename, domainname, msgid1, msgid2, plural);
  __libc_lock_unlock (lock);
  fprintf(stderr, "[intl/log.c] exit _nl_log_untranslated 1\n");
}
// Total cost: 0.031349
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 116)]
// Total instrumented cost: 0.031349, input tokens: 3423, output tokens: 1531, cache read tokens: 2280, cache write tokens: 1139

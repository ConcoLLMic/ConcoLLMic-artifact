/* Decomposed printf argument list.
   Copyright (C) 1999, 2002-2003, 2005-2007 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU Library General Public License as published
   by the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301,
   USA.  */

/* This file can be parametrized with the following macros:
     ENABLE_UNISTDIO    Set to 1 to enable the unistdio extensions.
     PRINTF_FETCHARGS   Name of the function to be defined.
     STATIC             Set to 'static' to declare the function static.  */

#ifndef PRINTF_FETCHARGS
# include <config.h>
#endif

/* Specification.  */
#ifndef PRINTF_FETCHARGS
# include "printf-args.h"
#endif

#include <stdio.h>

#ifdef STATIC
STATIC
#endif
int
PRINTF_FETCHARGS (va_list args, arguments *a)
{
  fprintf(stderr, "\n");
  size_t i;
  argument *ap;

  for (i = 0, ap = &a->arg[0]; i < a->count; i++, ap++)
  {
    fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 2\n");
    switch (ap->type)
      {
      case TYPE_SCHAR:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 3\n");
        ap->a.a_schar = va_arg (args, /*signed char*/ int);
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 3\n");
      case TYPE_UCHAR:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 4\n");
        ap->a.a_uchar = va_arg (args, /*unsigned char*/ int);
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 4\n");
      case TYPE_SHORT:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 5\n");
        ap->a.a_short = va_arg (args, /*short*/ int);
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 5\n");
      case TYPE_USHORT:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 6\n");
        ap->a.a_ushort = va_arg (args, /*unsigned short*/ int);
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 6\n");
      case TYPE_INT:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 7\n");
        ap->a.a_int = va_arg (args, int);
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 7\n");
      case TYPE_UINT:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 8\n");
        ap->a.a_uint = va_arg (args, unsigned int);
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 8\n");
      case TYPE_LONGINT:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 9\n");
        ap->a.a_longint = va_arg (args, long int);
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 9\n");
      case TYPE_ULONGINT:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 10\n");
        ap->a.a_ulongint = va_arg (args, unsigned long int);
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 10\n");
#if HAVE_LONG_LONG_INT
      case TYPE_LONGLONGINT:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 11\n");
        ap->a.a_longlongint = va_arg (args, long long int);
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 11\n");
      case TYPE_ULONGLONGINT:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 12\n");
        ap->a.a_ulonglongint = va_arg (args, unsigned long long int);
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 12\n");
#endif
      case TYPE_DOUBLE:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 13\n");
        ap->a.a_double = va_arg (args, double);
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 13\n");
      case TYPE_LONGDOUBLE:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 14\n");
        ap->a.a_longdouble = va_arg (args, long double);
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 14\n");
      case TYPE_CHAR:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 15\n");
        ap->a.a_char = va_arg (args, int);
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 15\n");
#if HAVE_WINT_T
      case TYPE_WIDE_CHAR:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 16\n");
        /* Although ISO C 99 7.24.1.(2) says that wint_t is "unchanged by
           default argument promotions", this is not the case in mingw32,
           where wint_t is 'unsigned short'.  */
        ap->a.a_wide_char =
          (sizeof (wint_t) < sizeof (int)
           ? va_arg (args, int)
           : va_arg (args, wint_t));
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 16\n");
#endif
      case TYPE_STRING:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 17\n");
        ap->a.a_string = va_arg (args, const char *);
        /* A null pointer is an invalid argument for "%s", but in practice
           it occurs quite frequently in printf statements that produce
           debug output.  Use a fallback in this case.  */
        if (ap->a.a_string == NULL)
        {
          fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 18\n");
          ap->a.a_string = "(NULL)";
          fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 18\n");
        }
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 17\n");
#if HAVE_WCHAR_T
      case TYPE_WIDE_STRING:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 19\n");
        ap->a.a_wide_string = va_arg (args, const wchar_t *);
        /* A null pointer is an invalid argument for "%ls", but in practice
           it occurs quite frequently in printf statements that produce
           debug output.  Use a fallback in this case.  */
        if (ap->a.a_wide_string == NULL)
        {
          fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 20\n");
          static const wchar_t wide_null_string[] =
            {
              (wchar_t)'(',
              (wchar_t)'N', (wchar_t)'U', (wchar_t)'L', (wchar_t)'L',
              (wchar_t)')',
              (wchar_t)0
            };
          ap->a.a_wide_string = wide_null_string;
          fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 20\n");
        }
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 19\n");
#endif
      case TYPE_POINTER:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 21\n");
        ap->a.a_pointer = va_arg (args, void *);
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 21\n");
      case TYPE_COUNT_SCHAR_POINTER:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 22\n");
        ap->a.a_count_schar_pointer = va_arg (args, signed char *);
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 22\n");
      case TYPE_COUNT_SHORT_POINTER:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 23\n");
        ap->a.a_count_short_pointer = va_arg (args, short *);
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 23\n");
      case TYPE_COUNT_INT_POINTER:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 24\n");
        ap->a.a_count_int_pointer = va_arg (args, int *);
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 24\n");
      case TYPE_COUNT_LONGINT_POINTER:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 25\n");
        ap->a.a_count_longint_pointer = va_arg (args, long int *);
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 25\n");
#if HAVE_LONG_LONG_INT
      case TYPE_COUNT_LONGLONGINT_POINTER:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 26\n");
        ap->a.a_count_longlongint_pointer = va_arg (args, long long int *);
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 26\n");
#endif
#if ENABLE_UNISTDIO
      /* The unistdio extensions.  */
      case TYPE_U8_STRING:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 27\n");
        ap->a.a_u8_string = va_arg (args, const uint8_t *);
        /* A null pointer is an invalid argument for "%U", but in practice
           it occurs quite frequently in printf statements that produce
           debug output.  Use a fallback in this case.  */
        if (ap->a.a_u8_string == NULL)
        {
          fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 28\n");
          static const uint8_t u8_null_string[] =
            { '(', 'N', 'U', 'L', 'L', ')', 0 };
          ap->a.a_u8_string = u8_null_string;
          fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 28\n");
        }
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 27\n");
      case TYPE_U16_STRING:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 29\n");
        ap->a.a_u16_string = va_arg (args, const uint16_t *);
        /* A null pointer is an invalid argument for "%lU", but in practice
           it occurs quite frequently in printf statements that produce
           debug output.  Use a fallback in this case.  */
        if (ap->a.a_u16_string == NULL)
        {
          fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 30\n");
          static const uint16_t u16_null_string[] =
            { '(', 'N', 'U', 'L', 'L', ')', 0 };
          ap->a.a_u16_string = u16_null_string;
          fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 30\n");
        }
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 29\n");
      case TYPE_U32_STRING:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 31\n");
        ap->a.a_u32_string = va_arg (args, const uint32_t *);
        /* A null pointer is an invalid argument for "%llU", but in practice
           it occurs quite frequently in printf statements that produce
           debug output.  Use a fallback in this case.  */
        if (ap->a.a_u32_string == NULL)
        {
          fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 32\n");
          static const uint32_t u32_null_string[] =
            { '(', 'N', 'U', 'L', 'L', ')', 0 };
          ap->a.a_u32_string = u32_null_string;
          fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 32\n");
        }
        break;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 31\n");
#endif
      default:
        fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 33\n");
        /* Unknown type.  */
        return -1;
        fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 33\n");
      }
    fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 2\n");
  }
  fprintf(stderr, "[intl/printf-args.c] enter PRINTF_FETCHARGS 34\n");
  return 0;
  fprintf(stderr, "[intl/printf-args.c] exit PRINTF_FETCHARGS 34\n");
}
// Total cost: 0.068422
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 188)]
// Total instrumented cost: 0.068422, input tokens: 4562, output tokens: 3490, cache read tokens: 2280, cache write tokens: 2278


#if @HAVE_VISIBILITY@ && BUILDING_LIBINTL
#define LIBINTL_DLL_EXPORTED __attribute__((__visibility__("default")))
#else
#define LIBINTL_DLL_EXPORTED
#endif
// Total cost: 0.001871
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 6)]
// Total instrumented cost: 0.001871, input tokens: 2407, output tokens: 23, cache read tokens: 2280, cache write tokens: 123

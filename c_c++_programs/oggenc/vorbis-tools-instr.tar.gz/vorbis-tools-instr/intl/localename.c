/* Determine name of the currently selected locale.
   Copyright (C) 1995-1999, 2000-2007 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU Library General Public License as published
   by the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301,
   USA.  */

/* Written by Ulrich Drepper <drepper@gnu.org>, 1995.  */
/* Win32 code written by Tor Lillqvist <tml@iki.fi>.  */
/* MacOS X code written by Bruno Haible <bruno@clisp.org>.  */

#include <config.h>

/* Specification.  */
#ifdef IN_LIBINTL
# include "gettextP.h"
#else
# include "localename.h"
#endif

#include <stdlib.h>
#include <locale.h>

#if HAVE_CFLOCALECOPYCURRENT || HAVE_CFPREFERENCESCOPYAPPVALUE
# include <string.h>
# include <CoreFoundation/CFString.h>
# if HAVE_CFLOCALECOPYCURRENT
#  include <CoreFoundation/CFLocale.h>
# elif HAVE_CFPREFERENCESCOPYAPPVALUE
#  include <CoreFoundation/CFPreferences.h>
# endif
#endif

#if defined _WIN32 || defined __WIN32__
# define WIN32_NATIVE
#endif

#ifdef WIN32_NATIVE
# define WIN32_LEAN_AND_MEAN
# include <windows.h>
/* List of language codes, sorted by value:
   0x01 LANG_ARABIC
   0x02 LANG_BULGARIAN
   0x03 LANG_CATALAN
   0x04 LANG_CHINESE
   0x05 LANG_CZECH
   0x06 LANG_DANISH
   0x07 LANG_GERMAN
   0x08 LANG_GREEK
   0x09 LANG_ENGLISH
   0x0a LANG_SPANISH
   0x0b LANG_FINNISH
   0x0c LANG_FRENCH
   0x0d LANG_HEBREW
   0x0e LANG_HUNGARIAN
   0x0f LANG_ICELANDIC
   0x10 LANG_ITALIAN
   0x11 LANG_JAPANESE
   0x12 LANG_KOREAN
   0x13 LANG_DUTCH
   0x14 LANG_NORWEGIAN
   0x15 LANG_POLISH
   0x16 LANG_PORTUGUESE
   0x17 LANG_RHAETO_ROMANCE
   0x18 LANG_ROMANIAN
   0x19 LANG_RUSSIAN
   0x1a LANG_CROATIAN == LANG_SERBIAN
   0x1b LANG_SLOVAK
   0x1c LANG_ALBANIAN
   0x1d LANG_SWEDISH
   0x1e LANG_THAI
   0x1f LANG_TURKISH
   0x20 LANG_URDU
   0x21 LANG_INDONESIAN
   0x22 LANG_UKRAINIAN
   0x23 LANG_BELARUSIAN
   0x24 LANG_SLOVENIAN
   0x25 LANG_ESTONIAN
   0x26 LANG_LATVIAN
   0x27 LANG_LITHUANIAN
   0x28 LANG_TAJIK
   0x29 LANG_FARSI
   0x2a LANG_VIETNAMESE
   0x2b LANG_ARMENIAN
   0x2c LANG_AZERI
   0x2d LANG_BASQUE
   0x2e LANG_SORBIAN
   0x2f LANG_MACEDONIAN
   0x30 LANG_SUTU
   0x31 LANG_TSONGA
   0x32 LANG_TSWANA
   0x33 LANG_VENDA
   0x34 LANG_XHOSA
   0x35 LANG_ZULU
   0x36 LANG_AFRIKAANS
   0x37 LANG_GEORGIAN
   0x38 LANG_FAEROESE
   0x39 LANG_HINDI
   0x3a LANG_MALTESE
   0x3b LANG_SAAMI
   0x3c LANG_GAELIC
   0x3d LANG_YIDDISH
   0x3e LANG_MALAY
   0x3f LANG_KAZAK
   0x40 LANG_KYRGYZ
   0x41 LANG_SWAHILI
   0x42 LANG_TURKMEN
   0x43 LANG_UZBEK
   0x44 LANG_TATAR
   0x45 LANG_BENGALI
   0x46 LANG_PUNJABI
   0x47 LANG_GUJARATI
   0x48 LANG_ORIYA
   0x49 LANG_TAMIL
   0x4a LANG_TELUGU
   0x4b LANG_KANNADA
   0x4c LANG_MALAYALAM
   0x4d LANG_ASSAMESE
   0x4e LANG_MARATHI
   0x4f LANG_SANSKRIT
   0x50 LANG_MONGOLIAN
   0x51 LANG_TIBETAN
   0x52 LANG_WELSH
   0x53 LANG_CAMBODIAN
   0x54 LANG_LAO
   0x55 LANG_BURMESE
   0x56 LANG_GALICIAN
   0x57 LANG_KONKANI
   0x58 LANG_MANIPURI
   0x59 LANG_SINDHI
   0x5a LANG_SYRIAC
   0x5b LANG_SINHALESE
   0x5c LANG_CHEROKEE
   0x5d LANG_INUKTITUT
   0x5e LANG_AMHARIC
   0x5f LANG_TAMAZIGHT
   0x60 LANG_KASHMIRI
   0x61 LANG_NEPALI
   0x62 LANG_FRISIAN
   0x63 LANG_PASHTO
   0x64 LANG_TAGALOG
   0x65 LANG_DIVEHI
   0x66 LANG_EDO
   0x67 LANG_FULFULDE
   0x68 LANG_HAUSA
   0x69 LANG_IBIBIO
   0x6a LANG_YORUBA
   0x70 LANG_IGBO
   0x71 LANG_KANURI
   0x72 LANG_OROMO
   0x73 LANG_TIGRINYA
   0x74 LANG_GUARANI
   0x75 LANG_HAWAIIAN
   0x76 LANG_LATIN
   0x77 LANG_SOMALI
   0x78 LANG_YI
   0x79 LANG_PAPIAMENTU
*/
/* Mingw headers don't have latest language and sublanguage codes.  */
# ifndef LANG_AFRIKAANS
# define LANG_AFRIKAANS 0x36
# endif
# ifndef LANG_ALBANIAN
# define LANG_ALBANIAN 0x1c
# endif
# ifndef LANG_AMHARIC
# define LANG_AMHARIC 0x5e
# endif
# ifndef LANG_ARABIC
# define LANG_ARABIC 0x01
# endif
# ifndef LANG_ARMENIAN
# define LANG_ARMENIAN 0x2b
# endif
# ifndef LANG_ASSAMESE
# define LANG_ASSAMESE 0x4d
# endif
# ifndef LANG_AZERI
# define LANG_AZERI 0x2c
# endif
# ifndef LANG_BASQUE
# define LANG_BASQUE 0x2d
# endif
# ifndef LANG_BELARUSIAN
# define LANG_BELARUSIAN 0x23
# endif
# ifndef LANG_BENGALI
# define LANG_BENGALI 0x45
# endif
# ifndef LANG_BURMESE
# define LANG_BURMESE 0x55
# endif
# ifndef LANG_CAMBODIAN
# define LANG_CAMBODIAN 0x53
# endif
# ifndef LANG_CATALAN
# define LANG_CATALAN 0x03
# endif
# ifndef LANG_CHEROKEE
# define LANG_CHEROKEE 0x5c
# endif
# ifndef LANG_DIVEHI
# define LANG_DIVEHI 0x65
# endif
# ifndef LANG_EDO
# define LANG_EDO 0x66
# endif
# ifndef LANG_ESTONIAN
# define LANG_ESTONIAN 0x25
# endif
# ifndef LANG_FAEROESE
# define LANG_FAEROESE 0x38
# endif
# ifndef LANG_FARSI
# define LANG_FARSI 0x29
# endif
# ifndef LANG_FRISIAN
# define LANG_FRISIAN 0x62
# endif
# ifndef LANG_FULFULDE
# define LANG_FULFULDE 0x67
# endif
# ifndef LANG_GAELIC
# define LANG_GAELIC 0x3c
# endif
# ifndef LANG_GALICIAN
# define LANG_GALICIAN 0x56
# endif
# ifndef LANG_GEORGIAN
# define LANG_GEORGIAN 0x37
# endif
# ifndef LANG_GUARANI
# define LANG_GUARANI 0x74
# endif
# ifndef LANG_GUJARATI
# define LANG_GUJARATI 0x47
# endif
# ifndef LANG_HAUSA
# define LANG_HAUSA 0x68
# endif
# ifndef LANG_HAWAIIAN
# define LANG_HAWAIIAN 0x75
# endif
# ifndef LANG_HEBREW
# define LANG_HEBREW 0x0d
# endif
# ifndef LANG_HINDI
# define LANG_HINDI 0x39
# endif
# ifndef LANG_IBIBIO
# define LANG_IBIBIO 0x69
# endif
# ifndef LANG_IGBO
# define LANG_IGBO 0x70
# endif
# ifndef LANG_INDONESIAN
# define LANG_INDONESIAN 0x21
# endif
# ifndef LANG_INUKTITUT
# define LANG_INUKTITUT 0x5d
# endif
# ifndef LANG_KANNADA
# define LANG_KANNADA 0x4b
# endif
# ifndef LANG_KANURI
# define LANG_KANURI 0x71
# endif
# ifndef LANG_KASHMIRI
# define LANG_KASHMIRI 0x60
# endif
# ifndef LANG_KAZAK
# define LANG_KAZAK 0x3f
# endif
# ifndef LANG_KONKANI
# define LANG_KONKANI 0x57
# endif
# ifndef LANG_KYRGYZ
# define LANG_KYRGYZ 0x40
# endif
# ifndef LANG_LAO
# define LANG_LAO 0x54
# endif
# ifndef LANG_LATIN
# define LANG_LATIN 0x76
# endif
# ifndef LANG_LATVIAN
# define LANG_LATVIAN 0x26
# endif
# ifndef LANG_LITHUANIAN
# define LANG_LITHUANIAN 0x27
# endif
# ifndef LANG_MACEDONIAN
# define LANG_MACEDONIAN 0x2f
# endif
# ifndef LANG_MALAY
# define LANG_MALAY 0x3e
# endif
# ifndef LANG_MALAYALAM
# define LANG_MALAYALAM 0x4c
# endif
# ifndef LANG_MALTESE
# define LANG_MALTESE 0x3a
# endif
# ifndef LANG_MANIPURI
# define LANG_MANIPURI 0x58
# endif
# ifndef LANG_MARATHI
# define LANG_MARATHI 0x4e
# endif
# ifndef LANG_MONGOLIAN
# define LANG_MONGOLIAN 0x50
# endif
# ifndef LANG_NEPALI
# define LANG_NEPALI 0x61
# endif
# ifndef LANG_ORIYA
# define LANG_ORIYA 0x48
# endif
# ifndef LANG_OROMO
# define LANG_OROMO 0x72
# endif
# ifndef LANG_PAPIAMENTU
# define LANG_PAPIAMENTU 0x79
# endif
# ifndef LANG_PASHTO
# define LANG_PASHTO 0x63
# endif
# ifndef LANG_PUNJABI
# define LANG_PUNJABI 0x46
# endif
# ifndef LANG_RHAETO_ROMANCE
# define LANG_RHAETO_ROMANCE 0x17
# endif
# ifndef LANG_SAAMI
# define LANG_SAAMI 0x3b
# endif
# ifndef LANG_SANSKRIT
# define LANG_SANSKRIT 0x4f
# endif
# ifndef LANG_SERBIAN
# define LANG_SERBIAN 0x1a
# endif
# ifndef LANG_SINDHI
# define LANG_SINDHI 0x59
# endif
# ifndef LANG_SINHALESE
# define LANG_SINHALESE 0x5b
# endif
# ifndef LANG_SLOVAK
# define LANG_SLOVAK 0x1b
# endif
# ifndef LANG_SOMALI
# define LANG_SOMALI 0x77
# endif
# ifndef LANG_SORBIAN
# define LANG_SORBIAN 0x2e
# endif
# ifndef LANG_SUTU
# define LANG_SUTU 0x30
# endif
# ifndef LANG_SWAHILI
# define LANG_SWAHILI 0x41
# endif
# ifndef LANG_SYRIAC
# define LANG_SYRIAC 0x5a
# endif
# ifndef LANG_TAGALOG
# define LANG_TAGALOG 0x64
# endif
# ifndef LANG_TAJIK
# define LANG_TAJIK 0x28
# endif
# ifndef LANG_TAMAZIGHT
# define LANG_TAMAZIGHT 0x5f
# endif
# ifndef LANG_TAMIL
# define LANG_TAMIL 0x49
# endif
# ifndef LANG_TATAR
# define LANG_TATAR 0x44
# endif
# ifndef LANG_TELUGU
# define LANG_TELUGU 0x4a
# endif
# ifndef LANG_THAI
# define LANG_THAI 0x1e
# endif
# ifndef LANG_TIBETAN
# define LANG_TIBETAN 0x51
# endif
# ifndef LANG_TIGRINYA
# define LANG_TIGRINYA 0x73
# endif
# ifndef LANG_TSONGA
# define LANG_TSONGA 0x31
# endif
# ifndef LANG_TSWANA
# define LANG_TSWANA 0x32
# endif
# ifndef LANG_TURKMEN
# define LANG_TURKMEN 0x42
# endif
# ifndef LANG_UKRAINIAN
# define LANG_UKRAINIAN 0x22
# endif
# ifndef LANG_URDU
# define LANG_URDU 0x20
# endif
# ifndef LANG_UZBEK
# define LANG_UZBEK 0x43
# endif
# ifndef LANG_VENDA
# define LANG_VENDA 0x33
# endif
# ifndef LANG_VIETNAMESE
# define LANG_VIETNAMESE 0x2a
# endif
# ifndef LANG_WELSH
# define LANG_WELSH 0x52
# endif
# ifndef LANG_XHOSA
# define LANG_XHOSA 0x34
# endif
# ifndef LANG_YI
# define LANG_YI 0x78
# endif
# ifndef LANG_YIDDISH
# define LANG_YIDDISH 0x3d
# endif
# ifndef LANG_YORUBA
# define LANG_YORUBA 0x6a
# endif
# ifndef LANG_ZULU
# define LANG_ZULU 0x35
# endif
# ifndef SUBLANG_ARABIC_SAUDI_ARABIA
# define SUBLANG_ARABIC_SAUDI_ARABIA 0x01
# endif
# ifndef SUBLANG_ARABIC_IRAQ
# define SUBLANG_ARABIC_IRAQ 0x02
# endif
# ifndef SUBLANG_ARABIC_EGYPT
# define SUBLANG_ARABIC_EGYPT 0x03
# endif
# ifndef SUBLANG_ARABIC_LIBYA
# define SUBLANG_ARABIC_LIBYA 0x04
# endif
# ifndef SUBLANG_ARABIC_ALGERIA
# define SUBLANG_ARABIC_ALGERIA 0x05
# endif
# ifndef SUBLANG_ARABIC_MOROCCO
# define SUBLANG_ARABIC_MOROCCO 0x06
# endif
# ifndef SUBLANG_ARABIC_TUNISIA
# define SUBLANG_ARABIC_TUNISIA 0x07
# endif
# ifndef SUBLANG_ARABIC_OMAN
# define SUBLANG_ARABIC_OMAN 0x08
# endif
# ifndef SUBLANG_ARABIC_YEMEN
# define SUBLANG_ARABIC_YEMEN 0x09
# endif
# ifndef SUBLANG_ARABIC_SYRIA
# define SUBLANG_ARABIC_SYRIA 0x0a
# endif
# ifndef SUBLANG_ARABIC_JORDAN
# define SUBLANG_ARABIC_JORDAN 0x0b
# endif
# ifndef SUBLANG_ARABIC_LEBANON
# define SUBLANG_ARABIC_LEBANON 0x0c
# endif
# ifndef SUBLANG_ARABIC_KUWAIT
# define SUBLANG_ARABIC_KUWAIT 0x0d
# endif
# ifndef SUBLANG_ARABIC_UAE
# define SUBLANG_ARABIC_UAE 0x0e
# endif
# ifndef SUBLANG_ARABIC_BAHRAIN
# define SUBLANG_ARABIC_BAHRAIN 0x0f
# endif
# ifndef SUBLANG_ARABIC_QATAR
# define SUBLANG_ARABIC_QATAR 0x10
# endif
# ifndef SUBLANG_AZERI_LATIN
# define SUBLANG_AZERI_LATIN 0x01
# endif
# ifndef SUBLANG_AZERI_CYRILLIC
# define SUBLANG_AZERI_CYRILLIC 0x02
# endif
# ifndef SUBLANG_BENGALI_INDIA
# define SUBLANG_BENGALI_INDIA 0x01
# endif
# ifndef SUBLANG_BENGALI_BANGLADESH
# define SUBLANG_BENGALI_BANGLADESH 0x02
# endif
# ifndef SUBLANG_CHINESE_MACAU
# define SUBLANG_CHINESE_MACAU 0x05
# endif
# ifndef SUBLANG_ENGLISH_SOUTH_AFRICA
# define SUBLANG_ENGLISH_SOUTH_AFRICA 0x07
# endif
# ifndef SUBLANG_ENGLISH_JAMAICA
# define SUBLANG_ENGLISH_JAMAICA 0x08
# endif
# ifndef SUBLANG_ENGLISH_CARIBBEAN
# define SUBLANG_ENGLISH_CARIBBEAN 0x09
# endif
# ifndef SUBLANG_ENGLISH_BELIZE
# define SUBLANG_ENGLISH_BELIZE 0x0a
# endif
# ifndef SUBLANG_ENGLISH_TRINIDAD
# define SUBLANG_ENGLISH_TRINIDAD 0x0b
# endif
# ifndef SUBLANG_ENGLISH_ZIMBABWE
# define SUBLANG_ENGLISH_ZIMBABWE 0x0c
# endif
# ifndef SUBLANG_ENGLISH_PHILIPPINES
# define SUBLANG_ENGLISH_PHILIPPINES 0x0d
# endif
# ifndef SUBLANG_ENGLISH_INDONESIA
# define SUBLANG_ENGLISH_INDONESIA 0x0e
# endif
# ifndef SUBLANG_ENGLISH_HONGKONG
# define SUBLANG_ENGLISH_HONGKONG 0x0f
# endif
# ifndef SUBLANG_ENGLISH_INDIA
# define SUBLANG_ENGLISH_INDIA 0x10
# endif
# ifndef SUBLANG_ENGLISH_MALAYSIA
# define SUBLANG_ENGLISH_MALAYSIA 0x11
# endif
# ifndef SUBLANG_ENGLISH_SINGAPORE
# define SUBLANG_ENGLISH_SINGAPORE 0x12
# endif
# ifndef SUBLANG_FRENCH_LUXEMBOURG
# define SUBLANG_FRENCH_LUXEMBOURG 0x05
# endif
# ifndef SUBLANG_FRENCH_MONACO
# define SUBLANG_FRENCH_MONACO 0x06
# endif
# ifndef SUBLANG_FRENCH_WESTINDIES
# define SUBLANG_FRENCH_WESTINDIES 0x07
# endif
# ifndef SUBLANG_FRENCH_REUNION
# define SUBLANG_FRENCH_REUNION 0x08
# endif
# ifndef SUBLANG_FRENCH_CONGO
# define SUBLANG_FRENCH_CONGO 0x09
# endif
# ifndef SUBLANG_FRENCH_SENEGAL
# define SUBLANG_FRENCH_SENEGAL 0x0a
# endif
# ifndef SUBLANG_FRENCH_CAMEROON
# define SUBLANG_FRENCH_CAMEROON 0x0b
# endif
# ifndef SUBLANG_FRENCH_COTEDIVOIRE
# define SUBLANG_FRENCH_COTEDIVOIRE 0x0c
# endif
# ifndef SUBLANG_FRENCH_MALI
# define SUBLANG_FRENCH_MALI 0x0d
# endif
# ifndef SUBLANG_FRENCH_MOROCCO
# define SUBLANG_FRENCH_MOROCCO 0x0e
# endif
# ifndef SUBLANG_FRENCH_HAITI
# define SUBLANG_FRENCH_HAITI 0x0f
# endif
# ifndef SUBLANG_GERMAN_LUXEMBOURG
# define SUBLANG_GERMAN_LUXEMBOURG 0x04
# endif
# ifndef SUBLANG_GERMAN_LIECHTENSTEIN
# define SUBLANG_GERMAN_LIECHTENSTEIN 0x05
# endif
# ifndef SUBLANG_KASHMIRI_INDIA
# define SUBLANG_KASHMIRI_INDIA 0x02
# endif
# ifndef SUBLANG_MALAY_MALAYSIA
# define SUBLANG_MALAY_MALAYSIA 0x01
# endif
# ifndef SUBLANG_MALAY_BRUNEI_DARUSSALAM
# define SUBLANG_MALAY_BRUNEI_DARUSSALAM 0x02
# endif
# ifndef SUBLANG_NEPALI_INDIA
# define SUBLANG_NEPALI_INDIA 0x02
# endif
# ifndef SUBLANG_PUNJABI_INDIA
# define SUBLANG_PUNJABI_INDIA 0x01
# endif
# ifndef SUBLANG_PUNJABI_PAKISTAN
# define SUBLANG_PUNJABI_PAKISTAN 0x02
# endif
# ifndef SUBLANG_ROMANIAN_ROMANIA
# define SUBLANG_ROMANIAN_ROMANIA 0x01
# endif
# ifndef SUBLANG_ROMANIAN_MOLDOVA
# define SUBLANG_ROMANIAN_MOLDOVA 0x02
# endif
# ifndef SUBLANG_SERBIAN_LATIN
# define SUBLANG_SERBIAN_LATIN 0x02
# endif
# ifndef SUBLANG_SERBIAN_CYRILLIC
# define SUBLANG_SERBIAN_CYRILLIC 0x03
# endif
# ifndef SUBLANG_SINDHI_PAKISTAN
# define SUBLANG_SINDHI_PAKISTAN 0x01
# endif
# ifndef SUBLANG_SINDHI_AFGHANISTAN
# define SUBLANG_SINDHI_AFGHANISTAN 0x02
# endif
# ifndef SUBLANG_SPANISH_GUATEMALA
# define SUBLANG_SPANISH_GUATEMALA 0x04
# endif
# ifndef SUBLANG_SPANISH_COSTA_RICA
# define SUBLANG_SPANISH_COSTA_RICA 0x05
# endif
# ifndef SUBLANG_SPANISH_PANAMA
# define SUBLANG_SPANISH_PANAMA 0x06
# endif
# ifndef SUBLANG_SPANISH_DOMINICAN_REPUBLIC
# define SUBLANG_SPANISH_DOMINICAN_REPUBLIC 0x07
# endif
# ifndef SUBLANG_SPANISH_VENEZUELA
# define SUBLANG_SPANISH_VENEZUELA 0x08
# endif
# ifndef SUBLANG_SPANISH_COLOMBIA
# define SUBLANG_SPANISH_COLOMBIA 0x09
# endif
# ifndef SUBLANG_SPANISH_PERU
# define SUBLANG_SPANISH_PERU 0x0a
# endif
# ifndef SUBLANG_SPANISH_ARGENTINA
# define SUBLANG_SPANISH_ARGENTINA 0x0b
# endif
# ifndef SUBLANG_SPANISH_ECUADOR
# define SUBLANG_SPANISH_ECUADOR 0x0c
# endif
# ifndef SUBLANG_SPANISH_CHILE
# define SUBLANG_SPANISH_CHILE 0x0d
# endif
# ifndef SUBLANG_SPANISH_URUGUAY
# define SUBLANG_SPANISH_URUGUAY 0x0e
# endif
# ifndef SUBLANG_SPANISH_PARAGUAY
# define SUBLANG_SPANISH_PARAGUAY 0x0f
# endif
# ifndef SUBLANG_SPANISH_BOLIVIA
# define SUBLANG_SPANISH_BOLIVIA 0x10
# endif
# ifndef SUBLANG_SPANISH_EL_SALVADOR
# define SUBLANG_SPANISH_EL_SALVADOR 0x11
# endif
# ifndef SUBLANG_SPANISH_HONDURAS
# define SUBLANG_SPANISH_HONDURAS 0x12
# endif
# ifndef SUBLANG_SPANISH_NICARAGUA
# define SUBLANG_SPANISH_NICARAGUA 0x13
# endif
# ifndef SUBLANG_SPANISH_PUERTO_RICO
# define SUBLANG_SPANISH_PUERTO_RICO 0x14
# endif
# ifndef SUBLANG_SWEDISH_FINLAND
# define SUBLANG_SWEDISH_FINLAND 0x02
# endif
# ifndef SUBLANG_TAMAZIGHT_ARABIC
# define SUBLANG_TAMAZIGHT_ARABIC 0x01
# endif
# ifndef SUBLANG_TAMAZIGHT_ALGERIA_LATIN
# define SUBLANG_TAMAZIGHT_ALGERIA_LATIN 0x02
# endif
# ifndef SUBLANG_TIGRINYA_ETHIOPIA
# define SUBLANG_TIGRINYA_ETHIOPIA 0x01
# endif
# ifndef SUBLANG_TIGRINYA_ERITREA
# define SUBLANG_TIGRINYA_ERITREA 0x02
# endif
# ifndef SUBLANG_URDU_PAKISTAN
# define SUBLANG_URDU_PAKISTAN 0x01
# endif
# ifndef SUBLANG_URDU_INDIA
# define SUBLANG_URDU_INDIA 0x02
# endif
# ifndef SUBLANG_UZBEK_LATIN
# define SUBLANG_UZBEK_LATIN 0x01
# endif
# ifndef SUBLANG_UZBEK_CYRILLIC
# define SUBLANG_UZBEK_CYRILLIC 0x02
# endif
#endif

# if HAVE_CFLOCALECOPYCURRENT || HAVE_CFPREFERENCESCOPYAPPVALUE
/* MacOS X 10.2 or newer */

/* Canonicalize a MacOS X locale name to a Unix locale name.
   NAME is a sufficiently large buffer.
   On input, it contains the MacOS X locale name.
   On output, it contains the Unix locale name.  */
#  if !defined IN_LIBINTL
static
#  endif
void
gl_locale_name_canonicalize (char *name)
{
  /* This conversion is based on a posting by
     Deborah GoldSmith <goldsmit@apple.com> on 2005-03-08,
     http://lists.apple.com/archives/carbon-dev/2005/Mar/msg00293.html */

  /* Convert legacy (NeXTstep inherited) English names to Unix (ISO 639 and
     ISO 3166) names.  Prior to MacOS X 10.3, there is no API for doing this.
     Therefore we do it ourselves, using a table based on the results of the
     MacOS X 10.3.8 function
     CFLocaleCreateCanonicalLocaleIdentifierFromString().  */
  typedef struct { const char legacy[21+1]; const char unixy[5+1]; }
	  legacy_entry;
  static const legacy_entry legacy_table[] = {
    { "Afrikaans",             "af" },
    { "Albanian",              "sq" },
    { "Amharic",               "am" },
    { "Arabic",                "ar" },
    { "Armenian",              "hy" },
    { "Assamese",              "as" },
    { "Aymara",                "ay" },
    { "Azerbaijani",           "az" },
    { "Basque",                "eu" },
    { "Belarusian",            "be" },
    { "Belorussian",           "be" },
    { "Bengali",               "bn" },
    { "Brazilian Portugese",   "pt_BR" },
    { "Brazilian Portuguese",  "pt_BR" },
    { "Breton",                "br" },
    { "Bulgarian",             "bg" },
    { "Burmese",               "my" },
    { "Byelorussian",          "be" },
    { "Catalan",               "ca" },
    { "Chewa",                 "ny" },
    { "Chichewa",              "ny" },
    { "Chinese",               "zh" },
    { "Chinese, Simplified",   "zh_CN" },
    { "Chinese, Traditional",  "zh_TW" },
    { "Chinese, Tradtional",   "zh_TW" },
    { "Croatian",              "hr" },
    { "Czech",                 "cs" },
    { "Danish",                "da" },
    { "Dutch",                 "nl" },
    { "Dzongkha",              "dz" },
    { "English",               "en" },
    { "Esperanto",             "eo" },
    { "Estonian",              "et" },
    { "Faroese",               "fo" },
    { "Farsi",                 "fa" },
    { "Finnish",               "fi" },
    { "Flemish",               "nl_BE" },
    { "French",                "fr" },
    { "Galician",              "gl" },
    { "Gallegan",              "gl" },
    { "Georgian",              "ka" },
    { "German",                "de" },
    { "Greek",                 "el" },
    { "Greenlandic",           "kl" },
    { "Guarani",               "gn" },
    { "Gujarati",              "gu" },
    { "Hawaiian",              "haw" }, /* Yes, "haw", not "cpe".  */
    { "Hebrew",                "he" },
    { "Hindi",                 "hi" },
    { "Hungarian",             "hu" },
    { "Icelandic",             "is" },
    { "Indonesian",            "id" },
    { "Inuktitut",             "iu" },
    { "Irish",                 "ga" },
    { "Italian",               "it" },
    { "Japanese",              "ja" },
    { "Javanese",              "jv" },
    { "Kalaallisut",           "kl" },
    { "Kannada",               "kn" },
    { "Kashmiri",              "ks" },
    { "Kazakh",                "kk" },
    { "Khmer",                 "km" },
    { "Kinyarwanda",           "rw" },
    { "Kirghiz",               "ky" },
    { "Korean",                "ko" },
    { "Kurdish",               "ku" },
    { "Latin",                 "la" },
    { "Latvian",               "lv" },
    { "Lithuanian",            "lt" },
    { "Macedonian",            "mk" },
    { "Malagasy",              "mg" },
    { "Malay",                 "ms" },
    { "Malayalam",             "ml" },
    { "Maltese",               "mt" },
    { "Manx",                  "gv" },
    { "Marathi",               "mr" },
    { "Moldavian",             "mo" },
    { "Mongolian",             "mn" },
    { "Nepali",                "ne" },
    { "Norwegian",             "nb" }, /* Yes, "nb", not the obsolete "no".  */
    { "Nyanja",                "ny" },
    { "Nynorsk",               "nn" },
    { "Oriya",                 "or" },
    { "Oromo",                 "om" },
    { "Panjabi",               "pa" },
    { "Pashto",                "ps" },
    { "Persian",               "fa" },
    { "Polish",                "pl" },
    { "Portuguese",            "pt" },
    { "Portuguese, Brazilian", "pt_BR" },
    { "Punjabi",               "pa" },
    { "Pushto",                "ps" },
    { "Quechua",               "qu" },
    { "Romanian",              "ro" },
    { "Ruanda",                "rw" },
    { "Rundi",                 "rn" },
    { "Russian",               "ru" },
    { "Sami",                  "se_NO" }, /* Not just "se".  */
    { "Sanskrit",              "sa" },
    { "Scottish",              "gd" },
    { "Serbian",               "sr" },
    { "Simplified Chinese",    "zh_CN" },
    { "Sindhi",                "sd" },
    { "Sinhalese",             "si" },
    { "Slovak",                "sk" },
    { "Slovenian",             "sl" },
    { "Somali",                "so" },
    { "Spanish",               "es" },
    { "Sundanese",             "su" },
    { "Swahili",               "sw" },
    { "Swedish",               "sv" },
    { "Tagalog",               "tl" },
    { "Tajik",                 "tg" },
    { "Tajiki",                "tg" },
    { "Tamil",                 "ta" },
    { "Tatar",                 "tt" },
    { "Telugu",                "te" },
    { "Thai",                  "th" },
    { "Tibetan",               "bo" },
    { "Tigrinya",              "ti" },
    { "Tongan",                "to" },
    { "Traditional Chinese",   "zh_TW" },
    { "Turkish",               "tr" },
    { "Turkmen",               "tk" },
    { "Uighur",                "ug" },
    { "Ukrainian",             "uk" },
    { "Urdu",                  "ur" },
    { "Uzbek",                 "uz" },
    { "Vietnamese",            "vi" },
    { "Welsh",                 "cy" },
    { "Yiddish",               "yi" }
  };

  /* Convert new-style locale names with language tags (ISO 639 and ISO 15924)
     to Unix (ISO 639 and ISO 3166) names.  */
  typedef struct { const char langtag[7+1]; const char unixy[12+1]; }
	  langtag_entry;
  static const langtag_entry langtag_table[] = {
    /* MacOS X has "az-Arab", "az-Cyrl", "az-Latn".
       The default script for az on Unix is Latin.  */
    { "az-Latn", "az" },
    /* MacOS X has "ga-dots".  Does not yet exist on Unix.  */
    { "ga-dots", "ga" },
    /* MacOS X has "kk-Cyrl".  Does not yet exist on Unix.  */
    /* MacOS X has "mn-Cyrl", "mn-Mong".
       The default script for mn on Unix is Cyrillic.  */
    { "mn-Cyrl", "mn" },
    /* MacOS X has "ms-Arab", "ms-Latn".
       The default script for ms on Unix is Latin.  */
    { "ms-Latn", "ms" },
    /* MacOS X has "tg-Cyrl".
       The default script for tg on Unix is Cyrillic.  */
    { "tg-Cyrl", "tg" },
    /* MacOS X has "tk-Cyrl".  Does not yet exist on Unix.  */
    /* MacOS X has "tt-Cyrl".
       The default script for tt on Unix is Cyrillic.  */
    { "tt-Cyrl", "tt" },
    /* MacOS X has "zh-Hans", "zh-Hant".
       Country codes are used to distinguish these on Unix.  */
    { "zh-Hans", "zh_CN" },
    { "zh-Hant", "zh_TW" }
  };

  /* Convert script names (ISO 15924) to Unix conventions.
     See http://www.unicode.org/iso15924/iso15924-codes.html  */
  typedef struct { const char script[4+1]; const char unixy[9+1]; }
	  script_entry;
  static const script_entry script_table[] = {
    { "Arab", "arabic" },
    { "Cyrl", "cyrillic" },
    { "Mong", "mongolian" }
  };

  fprintf(stderr, "[intl/localename.c] enter gl_locale_name_canonicalize 1\n");
  /* Step 1: Convert using legacy_table.  */
  if (name[0] >= 'A' && name[0] <= 'Z')
  {
    fprintf(stderr, "[intl/localename.c] enter gl_locale_name_canonicalize 2\n");
    unsigned int i1, i2;
    i1 = 0;
    i2 = sizeof (legacy_table) / sizeof (legacy_entry);
    fprintf(stderr, "[intl/localename.c] exit gl_locale_name_canonicalize 2\n");
    while (i2 - i1 > 1)
    {
      fprintf(stderr, "[intl/localename.c] enter gl_locale_name_canonicalize 3\n");
      /* At this point we know that if name occurs in legacy_table,
         its index must be >= i1 and < i2.  */
      unsigned int i = (i1 + i2) >> 1;
      const legacy_entry *p = &legacy_table[i];
      if (strcmp (name, p->legacy) < 0)
        i2 = i;
      else
        i1 = i;
      fprintf(stderr, "[intl/localename.c] exit gl_locale_name_canonicalize 3\n");
    }
    fprintf(stderr, "[intl/localename.c] enter gl_locale_name_canonicalize 4\n");
    if (strcmp (name, legacy_table[i1].legacy) == 0)
    {
      fprintf(stderr, "[intl/localename.c] enter gl_locale_name_canonicalize 5\n");
      strcpy (name, legacy_table[i1].unixy);
      return;
      fprintf(stderr, "[intl/localename.c] exit gl_locale_name_canonicalize 5\n");
    }
    fprintf(stderr, "[intl/localename.c] exit gl_locale_name_canonicalize 4\n");
  }
  fprintf(stderr, "[intl/localename.c] exit gl_locale_name_canonicalize 1\n");

  fprintf(stderr, "[intl/localename.c] enter gl_locale_name_canonicalize 6\n");
  /* Step 2: Convert using langtag_table and script_table.  */
  if (strlen (name) == 7 && name[2] == '-')
  {
    fprintf(stderr, "[intl/localename.c] enter gl_locale_name_canonicalize 7\n");
    unsigned int i1, i2;
    i1 = 0;
    i2 = sizeof (langtag_table) / sizeof (langtag_entry);
    fprintf(stderr, "[intl/localename.c] exit gl_locale_name_canonicalize 7\n");
    while (i2 - i1 > 1)
    {
      fprintf(stderr, "[intl/localename.c] enter gl_locale_name_canonicalize 8\n");
      /* At this point we know that if name occurs in langtag_table,
         its index must be >= i1 and < i2.  */
      unsigned int i = (i1 + i2) >> 1;
      const langtag_entry *p = &langtag_table[i];
      if (strcmp (name, p->langtag) < 0)
        i2 = i;
      else
        i1 = i;
      fprintf(stderr, "[intl/localename.c] exit gl_locale_name_canonicalize 8\n");
    }
    fprintf(stderr, "[intl/localename.c] enter gl_locale_name_canonicalize 9\n");
    if (strcmp (name, langtag_table[i1].langtag) == 0)
    {
      fprintf(stderr, "[intl/localename.c] enter gl_locale_name_canonicalize 10\n");
      strcpy (name, langtag_table[i1].unixy);
      return;
      fprintf(stderr, "[intl/localename.c] exit gl_locale_name_canonicalize 10\n");
    }
    fprintf(stderr, "[intl/localename.c] exit gl_locale_name_canonicalize 9\n");

    fprintf(stderr, "[intl/localename.c] enter gl_locale_name_canonicalize 11\n");
    i1 = 0;
    i2 = sizeof (script_table) / sizeof (script_entry);
    fprintf(stderr, "[intl/localename.c] exit gl_locale_name_canonicalize 11\n");
    while (i2 - i1 > 1)
    {
      fprintf(stderr, "[intl/localename.c] enter gl_locale_name_canonicalize 12\n");
      /* At this point we know that if (name + 3) occurs in script_table,
         its index must be >= i1 and < i2.  */
      unsigned int i = (i1 + i2) >> 1;
      const script_entry *p = &script_table[i];
      if (strcmp (name + 3, p->script) < 0)
        i2 = i;
      else
        i1 = i;
      fprintf(stderr, "[intl/localename.c] exit gl_locale_name_canonicalize 12\n");
    }
    fprintf(stderr, "[intl/localename.c] enter gl_locale_name_canonicalize 13\n");
    if (strcmp (name + 3, script_table[i1].script) == 0)
    {
      fprintf(stderr, "[intl/localename.c] enter gl_locale_name_canonicalize 14\n");
      name[2] = '@';
      strcpy (name + 3, script_table[i1].unixy);
      return;
      fprintf(stderr, "[intl/localename.c] exit gl_locale_name_canonicalize 14\n");
    }
    fprintf(stderr, "[intl/localename.c] exit gl_locale_name_canonicalize 13\n");
  }
  fprintf(stderr, "[intl/localename.c] exit gl_locale_name_canonicalize 6\n");

  fprintf(stderr, "[intl/localename.c] enter gl_locale_name_canonicalize 15\n");
  /* Step 3: Convert new-style dash to Unix underscore. */
  {
    char *p;
    for (p = name; *p != '\0'; p++)
      if (*p == '-')
        *p = '_';
  }
  fprintf(stderr, "[intl/localename.c] exit gl_locale_name_canonicalize 15\n");
}

#endif

/* XPG3 defines the result of 'setlocale (category, NULL)' as:
   "Directs 'setlocale()' to query 'category' and return the current
    setting of 'local'."
   However it does not specify the exact format.  Neither do SUSV2 and
   ISO C 99.  So we can use this feature only on selected systems (e.g.
   those using GNU C Library).  */
#if defined _LIBC || (defined __GLIBC__ && __GLIBC__ >= 2)
# define HAVE_LOCALE_NULL
#endif

/* Determine the current locale's name, and canonicalize it into XPG syntax
     language[_territory][.codeset][@modifier]
   The codeset part in the result is not reliable; the locale_charset()
   should be used for codeset information instead.
   The result must not be freed; it is statically allocated.  */

const char *
gl_locale_name_posix (int category, const char *categoryname)
{
  /* Use the POSIX methods of looking to 'LC_ALL', 'LC_xxx', and 'LANG'.
     On some systems this can be done by the 'setlocale' function itself.  */
#if defined HAVE_SETLOCALE && defined HAVE_LC_MESSAGES && defined HAVE_LOCALE_NULL
  fprintf(stderr, "[intl/localename.c] enter gl_locale_name_posix 1\n");
  return setlocale (category, NULL);
  fprintf(stderr, "[intl/localename.c] exit gl_locale_name_posix 1\n");
#else
  fprintf(stderr, "[intl/localename.c] enter gl_locale_name_posix 2\n");
  const char *retval;

  /* Setting of LC_ALL overrides all other.  */
  retval = getenv ("LC_ALL");
  if (retval != NULL && retval[0] != '\0')
  {
    fprintf(stderr, "[intl/localename.c] enter gl_locale_name_posix 3\n");
    return retval;
    fprintf(stderr, "[intl/localename.c] exit gl_locale_name_posix 3\n");
  }
  /* Next comes the name of the desired category.  */
  retval = getenv (categoryname);
  if (retval != NULL && retval[0] != '\0')
  {
    fprintf(stderr, "[intl/localename.c] enter gl_locale_name_posix 4\n");
    return retval;
    fprintf(stderr, "[intl/localename.c] exit gl_locale_name_posix 4\n");
  }
  /* Last possibility is the LANG environment variable.  */
  retval = getenv ("LANG");
  if (retval != NULL && retval[0] != '\0')
  {
    fprintf(stderr, "[intl/localename.c] enter gl_locale_name_posix 5\n");
    return retval;
    fprintf(stderr, "[intl/localename.c] exit gl_locale_name_posix 5\n");
  }

  return NULL;
  fprintf(stderr, "[intl/localename.c] exit gl_locale_name_posix 2\n");
#endif
}

const char *
gl_locale_name_default (void)
{
  /* POSIX:2001 says:
     "All implementations shall define a locale as the default locale, to be
      invoked when no environment variables are set, or set to the empty
      string.  This default locale can be the POSIX locale or any other
      implementation-defined locale.  Some implementations may provide
      facilities for local installation administrators to set the default
      locale, customizing it for each location.  POSIX:2001 does not require
      such a facility.  */

#if !(HAVE_CFLOCALECOPYCURRENT || HAVE_CFPREFERENCESCOPYAPPVALUE || defined(WIN32_NATIVE))

  fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 1\n");
  /* The system does not have a way of setting the locale, other than the
     POSIX specified environment variables.  We use C as default locale.  */
  return "C";
  fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 1\n");

#else

  /* Return an XPG style locale name language[_territory][@modifier].
     Don't even bother determining the codeset; it's not useful in this
     context, because message catalogs are not specific to a single
     codeset.  */

# if HAVE_CFLOCALECOPYCURRENT || HAVE_CFPREFERENCESCOPYAPPVALUE
  fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 2\n");
  /* MacOS X 10.2 or newer */
  {
    /* Cache the locale name, since CoreFoundation calls are expensive.  */
    static const char *cached_localename;

    if (cached_localename == NULL)
    {
      fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 3\n");
      char namebuf[256];
#  if HAVE_CFLOCALECOPYCURRENT /* MacOS X 10.3 or newer */
      CFLocaleRef locale = CFLocaleCopyCurrent ();
      CFStringRef name = CFLocaleGetIdentifier (locale);

      if (CFStringGetCString (name, namebuf, sizeof(namebuf),
                kCFStringEncodingASCII))
      {
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 4\n");
        gl_locale_name_canonicalize (namebuf);
        cached_localename = strdup (namebuf);
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 4\n");
      }
      CFRelease (locale);
#  elif HAVE_CFPREFERENCESCOPYAPPVALUE /* MacOS X 10.2 or newer */
      CFTypeRef value =
        CFPreferencesCopyAppValue (CFSTR ("AppleLocale"),
                   kCFPreferencesCurrentApplication);
      if (value != NULL
          && CFGetTypeID (value) == CFStringGetTypeID ()
          && CFStringGetCString ((CFStringRef)value, namebuf, sizeof(namebuf),
                 kCFStringEncodingASCII))
      {
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 5\n");
        gl_locale_name_canonicalize (namebuf);
        cached_localename = strdup (namebuf);
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 5\n");
      }
#  endif
      if (cached_localename == NULL)
      {
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 6\n");
        cached_localename = "C";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 6\n");
      }
      fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 3\n");
    }
    return cached_localename;
  }
  fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 2\n");

# endif

# if defined(WIN32_NATIVE) /* WIN32, not Cygwin */
  fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 7\n");
  {
    LCID lcid;
    LANGID langid;
    int primary, sub;

    /* Use native Win32 API locale ID.  */
    lcid = GetThreadLocale ();

    /* Strip off the sorting rules, keep only the language part.  */
    langid = LANGIDFROMLCID (lcid);

    /* Split into language and territory part.  */
    primary = PRIMARYLANGID (langid);
    sub = SUBLANGID (langid);

    /* Dispatch on language.
       See also http://www.unicode.org/unicode/onlinedat/languages.html .
       For details about languages, see http://www.ethnologue.com/ .  */
    switch (primary)
    {
      case LANG_AFRIKAANS: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 8\n");
        return "af_ZA";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 8\n");
      case LANG_ALBANIAN: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 9\n");
        return "sq_AL";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 9\n");
      case LANG_AMHARIC: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 10\n");
        return "am_ET";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 10\n");
      case LANG_ARABIC:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 11\n");
        switch (sub)
        {
          case SUBLANG_ARABIC_SAUDI_ARABIA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 12\n");
            return "ar_SA";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 12\n");
          case SUBLANG_ARABIC_IRAQ: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 13\n");
            return "ar_IQ";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 13\n");
          case SUBLANG_ARABIC_EGYPT: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 14\n");
            return "ar_EG";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 14\n");
          case SUBLANG_ARABIC_LIBYA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 15\n");
            return "ar_LY";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 15\n");
          case SUBLANG_ARABIC_ALGERIA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 16\n");
            return "ar_DZ";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 16\n");
          case SUBLANG_ARABIC_MOROCCO: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 17\n");
            return "ar_MA";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 17\n");
          case SUBLANG_ARABIC_TUNISIA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 18\n");
            return "ar_TN";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 18\n");
          case SUBLANG_ARABIC_OMAN: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 19\n");
            return "ar_OM";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 19\n");
          case SUBLANG_ARABIC_YEMEN: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 20\n");
            return "ar_YE";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 20\n");
          case SUBLANG_ARABIC_SYRIA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 21\n");
            return "ar_SY";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 21\n");
          case SUBLANG_ARABIC_JORDAN: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 22\n");
            return "ar_JO";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 22\n");
          case SUBLANG_ARABIC_LEBANON: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 23\n");
            return "ar_LB";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 23\n");
          case SUBLANG_ARABIC_KUWAIT: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 24\n");
            return "ar_KW";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 24\n");
          case SUBLANG_ARABIC_UAE: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 25\n");
            return "ar_AE";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 25\n");
          case SUBLANG_ARABIC_BAHRAIN: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 26\n");
            return "ar_BH";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 26\n");
          case SUBLANG_ARABIC_QATAR: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 27\n");
            return "ar_QA";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 27\n");
        }
        return "ar";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 11\n");
      case LANG_ARMENIAN: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 28\n");
        return "hy_AM";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 28\n");
      case LANG_ASSAMESE: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 29\n");
        return "as_IN";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 29\n");
      case LANG_AZERI:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 30\n");
        switch (sub)
        {
          /* FIXME: Adjust this when Azerbaijani locales appear on Unix.  */
          case SUBLANG_AZERI_LATIN: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 31\n");
            return "az_AZ@latin";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 31\n");
          case SUBLANG_AZERI_CYRILLIC: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 32\n");
            return "az_AZ@cyrillic";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 32\n");
        }
        return "az";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 30\n");
      case LANG_BASQUE:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 33\n");
        switch (sub)
        {
          case SUBLANG_DEFAULT: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 34\n");
            return "eu_ES";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 34\n");
        }
        return "eu"; /* Ambiguous: could be "eu_ES" or "eu_FR".  */
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 33\n");
      case LANG_BELARUSIAN: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 35\n");
        return "be_BY";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 35\n");
      case LANG_BENGALI:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 36\n");
        switch (sub)
        {
          case SUBLANG_BENGALI_INDIA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 37\n");
            return "bn_IN";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 37\n");
          case SUBLANG_BENGALI_BANGLADESH: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 38\n");
            return "bn_BD";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 38\n");
        }
        return "bn";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 36\n");
      case LANG_BULGARIAN: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 39\n");
        return "bg_BG";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 39\n");
      case LANG_BURMESE: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 40\n");
        return "my_MM";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 40\n");
      case LANG_CAMBODIAN: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 41\n");
        return "km_KH";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 41\n");
      case LANG_CATALAN: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 42\n");
        return "ca_ES";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 42\n");
      case LANG_CHEROKEE: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 43\n");
        return "chr_US";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 43\n");
      case LANG_CHINESE:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 44\n");
        switch (sub)
        {
          case SUBLANG_CHINESE_TRADITIONAL: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 45\n");
            return "zh_TW";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 45\n");
          case SUBLANG_CHINESE_SIMPLIFIED: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 46\n");
            return "zh_CN";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 46\n");
          case SUBLANG_CHINESE_HONGKONG: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 47\n");
            return "zh_HK";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 47\n");
          case SUBLANG_CHINESE_SINGAPORE: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 48\n");
            return "zh_SG";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 48\n");
          case SUBLANG_CHINESE_MACAU: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 49\n");
            return "zh_MO";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 49\n");
        }
        return "zh";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 44\n");
      case LANG_CROATIAN:       /* LANG_CROATIAN == LANG_SERBIAN
                 * What used to be called Serbo-Croatian
                 * should really now be two separate
                 * languages because of political reasons.
                 * (Says tml, who knows nothing about Serbian
                 * or Croatian.)
                 * (I can feel those flames coming already.)
                 */
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 50\n");
        switch (sub)
        {
          case SUBLANG_DEFAULT: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 51\n");
            return "hr_HR";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 51\n");
          case SUBLANG_SERBIAN_LATIN: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 52\n");
            return "sr_CS";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 52\n");
          case SUBLANG_SERBIAN_CYRILLIC: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 53\n");
            return "sr_CS@cyrillic";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 53\n");
        }
        return "hr";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 50\n");
      case LANG_CZECH: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 54\n");
        return "cs_CZ";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 54\n");
      case LANG_DANISH: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 55\n");
        return "da_DK";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 55\n");
      case LANG_DIVEHI: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 56\n");
        return "dv_MV";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 56\n");
      case LANG_DUTCH:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 57\n");
        switch (sub)
        {
          case SUBLANG_DUTCH: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 58\n");
            return "nl_NL";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 58\n");
          case SUBLANG_DUTCH_BELGIAN: /* FLEMISH, VLAAMS */ 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 59\n");
            return "nl_BE";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 59\n");
        }
        return "nl";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 57\n");
      case LANG_EDO: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 60\n");
        return "bin_NG";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 60\n");
      case LANG_ENGLISH:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 61\n");
        switch (sub)
        {
          /* SUBLANG_ENGLISH_US == SUBLANG_DEFAULT. Heh. I thought
           * English was the language spoken in England.
           * Oh well.
           */
          case SUBLANG_ENGLISH_US: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 62\n");
            return "en_US";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 62\n");
          case SUBLANG_ENGLISH_UK: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 63\n");
            return "en_GB";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 63\n");
          case SUBLANG_ENGLISH_AUS: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 64\n");
            return "en_AU";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 64\n");
          case SUBLANG_ENGLISH_CAN: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 65\n");
            return "en_CA";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 65\n");
          case SUBLANG_ENGLISH_NZ: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 66\n");
            return "en_NZ";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 66\n");
          case SUBLANG_ENGLISH_EIRE: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 67\n");
            return "en_IE";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 67\n");
          case SUBLANG_ENGLISH_SOUTH_AFRICA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 68\n");
            return "en_ZA";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 68\n");
          case SUBLANG_ENGLISH_JAMAICA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 69\n");
            return "en_JM";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 69\n");
          case SUBLANG_ENGLISH_CARIBBEAN: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 70\n");
            return "en_GD"; /* Grenada? */
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 70\n");
          case SUBLANG_ENGLISH_BELIZE: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 71\n");
            return "en_BZ";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 71\n");
          case SUBLANG_ENGLISH_TRINIDAD: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 72\n");
            return "en_TT";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 72\n");
          case SUBLANG_ENGLISH_ZIMBABWE: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 73\n");
            return "en_ZW";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 73\n");
          case SUBLANG_ENGLISH_PHILIPPINES: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 74\n");
            return "en_PH";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 74\n");
          case SUBLANG_ENGLISH_INDONESIA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 75\n");
            return "en_ID";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 75\n");
          case SUBLANG_ENGLISH_HONGKONG: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 76\n");
            return "en_HK";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 76\n");
          case SUBLANG_ENGLISH_INDIA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 77\n");
            return "en_IN";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 77\n");
          case SUBLANG_ENGLISH_MALAYSIA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 78\n");
            return "en_MY";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 78\n");
          case SUBLANG_ENGLISH_SINGAPORE: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 79\n");
            return "en_SG";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 79\n");
        }
        return "en";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 61\n");
      case LANG_ESTONIAN: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 80\n");
        return "et_EE";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 80\n");
      case LANG_FAEROESE: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 81\n");
        return "fo_FO";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 81\n");
      case LANG_FARSI: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 82\n");
        return "fa_IR";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 82\n");
      case LANG_FINNISH: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 83\n");
        return "fi_FI";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 83\n");
      case LANG_FRENCH:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 84\n");
        switch (sub)
        {
          case SUBLANG_FRENCH: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 85\n");
            return "fr_FR";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 85\n");
          case SUBLANG_FRENCH_BELGIAN: /* WALLOON */ 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 86\n");
            return "fr_BE";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 86\n");
          case SUBLANG_FRENCH_CANADIAN: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 87\n");
            return "fr_CA";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 87\n");
          case SUBLANG_FRENCH_SWISS: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 88\n");
            return "fr_CH";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 88\n");
          case SUBLANG_FRENCH_LUXEMBOURG: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 89\n");
            return "fr_LU";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 89\n");
          case SUBLANG_FRENCH_MONACO: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 90\n");
            return "fr_MC";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 90\n");
          case SUBLANG_FRENCH_WESTINDIES: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 91\n");
            return "fr"; /* Caribbean? */
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 91\n");
          case SUBLANG_FRENCH_REUNION: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 92\n");
            return "fr_RE";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 92\n");
          case SUBLANG_FRENCH_CONGO: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 93\n");
            return "fr_CG";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 93\n");
          case SUBLANG_FRENCH_SENEGAL: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 94\n");
            return "fr_SN";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 94\n");
          case SUBLANG_FRENCH_CAMEROON: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 95\n");
            return "fr_CM";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 95\n");
          case SUBLANG_FRENCH_COTEDIVOIRE: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 96\n");
            return "fr_CI";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 96\n");
          case SUBLANG_FRENCH_MALI: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 97\n");
            return "fr_ML";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 97\n");
          case SUBLANG_FRENCH_MOROCCO: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 98\n");
            return "fr_MA";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 98\n");
          case SUBLANG_FRENCH_HAITI: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 99\n");
            return "fr_HT";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 99\n");
        }
        return "fr";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 84\n");
      case LANG_FRISIAN: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 100\n");
        return "fy_NL";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 100\n");
      case LANG_FULFULDE:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 101\n");
        /* Spoken in Nigeria, Guinea, Senegal, Mali, Niger, Cameroon, Benin.  */
        return "ff_NG";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 101\n");
      case LANG_GAELIC:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 102\n");
        switch (sub)
        {
          case 0x01: /* SCOTTISH */ 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 103\n");
            return "gd_GB";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 103\n");
          case 0x02: /* IRISH */ 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 104\n");
            return "ga_IE";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 104\n");
        }
        return "C";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 102\n");
      case LANG_GALICIAN: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 105\n");
        return "gl_ES";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 105\n");
      case LANG_GEORGIAN: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 106\n");
        return "ka_GE";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 106\n");
      case LANG_GERMAN:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 107\n");
        switch (sub)
        {
          case SUBLANG_GERMAN: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 108\n");
            return "de_DE";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 108\n");
          case SUBLANG_GERMAN_SWISS: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 109\n");
            return "de_CH";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 109\n");
          case SUBLANG_GERMAN_AUSTRIAN: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 110\n");
            return "de_AT";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 110\n");
          case SUBLANG_GERMAN_LUXEMBOURG: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 111\n");
            return "de_LU";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 111\n");
          case SUBLANG_GERMAN_LIECHTENSTEIN: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 112\n");
            return "de_LI";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 112\n");
        }
        return "de";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 107\n");
      case LANG_GREEK: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 113\n");
        return "el_GR";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 113\n");
      case LANG_GUARANI: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 114\n");
        return "gn_PY";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 114\n");
      case LANG_GUJARATI: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 115\n");
        return "gu_IN";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 115\n");
      case LANG_HAUSA: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 116\n");
        return "ha_NG";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 116\n");
      case LANG_HAWAIIAN:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 117\n");
        /* FIXME: Do they mean Hawaiian ("haw_US", 1000 speakers)
           or Hawaii Creole English ("cpe_US", 600000 speakers)?  */
        return "cpe_US";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 117\n");
      case LANG_HEBREW: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 118\n");
        return "he_IL";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 118\n");
      case LANG_HINDI: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 119\n");
        return "hi_IN";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 119\n");
      case LANG_HUNGARIAN: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 120\n");
        return "hu_HU";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 120\n");
      case LANG_IBIBIO: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 121\n");
        return "nic_NG";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 121\n");
      case LANG_ICELANDIC: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 122\n");
        return "is_IS";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 122\n");
      case LANG_IGBO: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 123\n");
        return "ig_NG";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 123\n");
      case LANG_INDONESIAN: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 124\n");
        return "id_ID";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 124\n");
      case LANG_INUKTITUT: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 125\n");
        return "iu_CA";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 125\n");
      case LANG_ITALIAN:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 126\n");
        switch (sub)
        {
          case SUBLANG_ITALIAN: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 127\n");
            return "it_IT";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 127\n");
          case SUBLANG_ITALIAN_SWISS: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 128\n");
            return "it_CH";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 128\n");
        }
        return "it";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 126\n");
      case LANG_JAPANESE: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 129\n");
        return "ja_JP";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 129\n");
      case LANG_KANNADA: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 130\n");
        return "kn_IN";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 130\n");
      case LANG_KANURI: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 131\n");
        return "kr_NG";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 131\n");
      case LANG_KASHMIRI:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 132\n");
        switch (sub)
        {
          case SUBLANG_DEFAULT: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 133\n");
            return "ks_PK";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 133\n");
          case SUBLANG_KASHMIRI_INDIA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 134\n");
            return "ks_IN";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 134\n");
        }
        return "ks";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 132\n");
      case LANG_KAZAK: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 135\n");
        return "kk_KZ";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 135\n");
      case LANG_KONKANI:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 136\n");
        /* FIXME: Adjust this when such locales appear on Unix.  */
        return "kok_IN";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 136\n");
      case LANG_KOREAN: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 137\n");
        return "ko_KR";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 137\n");
      case LANG_KYRGYZ: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 138\n");
        return "ky_KG";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 138\n");
      case LANG_LAO: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 139\n");
        return "lo_LA";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 139\n");
      case LANG_LATIN: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 140\n");
        return "la_VA";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 140\n");
      case LANG_LATVIAN: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 141\n");
        return "lv_LV";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 141\n");
      case LANG_LITHUANIAN: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 142\n");
        return "lt_LT";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 142\n");
      case LANG_MACEDONIAN: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 143\n");
        return "mk_MK";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 143\n");
      case LANG_MALAY:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 144\n");
        switch (sub)
        {
          case SUBLANG_MALAY_MALAYSIA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 145\n");
            return "ms_MY";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 145\n");
          case SUBLANG_MALAY_BRUNEI_DARUSSALAM: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 146\n");
            return "ms_BN";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 146\n");
        }
        return "ms";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 144\n");
      case LANG_MALAYALAM: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 147\n");
        return "ml_IN";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 147\n");
      case LANG_MALTESE: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 148\n");
        return "mt_MT";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 148\n");
      case LANG_MANIPURI:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 149\n");
        /* FIXME: Adjust this when such locales appear on Unix.  */
        return "mni_IN";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 149\n");
      case LANG_MARATHI: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 150\n");
        return "mr_IN";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 150\n");
      case LANG_MONGOLIAN:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 151\n");
        switch (sub)
        {
          case SUBLANG_DEFAULT: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 152\n");
            return "mn_MN";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 152\n");
        }
        return "mn"; /* Ambiguous: could be "mn_CN" or "mn_MN".  */
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 151\n");
      case LANG_NEPALI:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 153\n");
        switch (sub)
        {
          case SUBLANG_DEFAULT: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 154\n");
            return "ne_NP";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 154\n");
          case SUBLANG_NEPALI_INDIA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 155\n");
            return "ne_IN";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 155\n");
        }
        return "ne";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 153\n");
      case LANG_NORWEGIAN:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 156\n");
        switch (sub)
        {
          case SUBLANG_NORWEGIAN_BOKMAL: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 157\n");
            return "nb_NO";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 157\n");
          case SUBLANG_NORWEGIAN_NYNORSK: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 158\n");
            return "nn_NO";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 158\n");
        }
        return "no";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 156\n");
      case LANG_ORIYA: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 159\n");
        return "or_IN";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 159\n");
      case LANG_OROMO: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 160\n");
        return "om_ET";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 160\n");
      case LANG_PAPIAMENTU: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 161\n");
        return "pap_AN";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 161\n");
      case LANG_PASHTO:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 162\n");
        return "ps"; /* Ambiguous: could be "ps_PK" or "ps_AF".  */
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 162\n");
      case LANG_POLISH: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 163\n");
        return "pl_PL";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 163\n");
      case LANG_PORTUGUESE:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 164\n");
        switch (sub)
        {
          case SUBLANG_PORTUGUESE: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 165\n");
            return "pt_PT";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 165\n");
          /* Hmm. SUBLANG_PORTUGUESE_BRAZILIAN == SUBLANG_DEFAULT.
             Same phenomenon as SUBLANG_ENGLISH_US == SUBLANG_DEFAULT. */
          case SUBLANG_PORTUGUESE_BRAZILIAN: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 166\n");
            return "pt_BR";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 166\n");
        }
        return "pt";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 164\n");
      case LANG_PUNJABI:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 167\n");
        switch (sub)
        {
          case SUBLANG_PUNJABI_INDIA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 168\n");
            return "pa_IN"; /* Gurmukhi script */
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 168\n");
          case SUBLANG_PUNJABI_PAKISTAN: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 169\n");
            return "pa_PK"; /* Arabic script */
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 169\n");
        }
        return "pa";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 167\n");
      case LANG_RHAETO_ROMANCE: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 170\n");
        return "rm_CH";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 170\n");
      case LANG_ROMANIAN:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 171\n");
        switch (sub)
        {
          case SUBLANG_ROMANIAN_ROMANIA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 172\n");
            return "ro_RO";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 172\n");
          case SUBLANG_ROMANIAN_MOLDOVA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 173\n");
            return "ro_MD";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 173\n");
        }
        return "ro";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 171\n");
      case LANG_RUSSIAN:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 174\n");
        switch (sub)
        {
          case SUBLANG_DEFAULT: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 175\n");
            return "ru_RU";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 175\n");
        }
        return "ru"; /* Ambiguous: could be "ru_RU" or "ru_UA" or "ru_MD".  */
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 174\n");
      case LANG_SAAMI: /* actually Northern Sami */ 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 176\n");
        return "se_NO";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 176\n");
      case LANG_SANSKRIT: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 177\n");
        return "sa_IN";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 177\n");
      case LANG_SINDHI:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 178\n");
        switch (sub)
        {
          case SUBLANG_SINDHI_PAKISTAN: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 179\n");
            return "sd_PK";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 179\n");
          case SUBLANG_SINDHI_AFGHANISTAN: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 180\n");
            return "sd_AF";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 180\n");
        }
        return "sd";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 178\n");
      case LANG_SINHALESE: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 181\n");
        return "si_LK";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 181\n");
      case LANG_SLOVAK: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 182\n");
        return "sk_SK";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 182\n");
      case LANG_SLOVENIAN: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 183\n");
        return "sl_SI";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 183\n");
      case LANG_SOMALI: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 184\n");
        return "so_SO";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 184\n");
      case LANG_SORBIAN:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 185\n");
        /* FIXME: Adjust this when such locales appear on Unix.  */
        return "wen_DE";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 185\n");
      case LANG_SPANISH:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 186\n");
        switch (sub)
        {
          case SUBLANG_SPANISH: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 187\n");
            return "es_ES";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 187\n");
          case SUBLANG_SPANISH_MEXICAN: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 188\n");
            return "es_MX";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 188\n");
          case SUBLANG_SPANISH_MODERN:
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 189\n");
            return "es_ES@modern";  /* not seen on Unix */
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 189\n");
          case SUBLANG_SPANISH_GUATEMALA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 190\n");
            return "es_GT";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 190\n");
          case SUBLANG_SPANISH_COSTA_RICA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 191\n");
            return "es_CR";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 191\n");
          case SUBLANG_SPANISH_PANAMA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 192\n");
            return "es_PA";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 192\n");
          case SUBLANG_SPANISH_DOMINICAN_REPUBLIC: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 193\n");
            return "es_DO";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 193\n");
          case SUBLANG_SPANISH_VENEZUELA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 194\n");
            return "es_VE";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 194\n");
          case SUBLANG_SPANISH_COLOMBIA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 195\n");
            return "es_CO";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 195\n");
          case SUBLANG_SPANISH_PERU: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 196\n");
            return "es_PE";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 196\n");
          case SUBLANG_SPANISH_ARGENTINA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 197\n");
            return "es_AR";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 197\n");
          case SUBLANG_SPANISH_ECUADOR: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 198\n");
            return "es_EC";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 198\n");
          case SUBLANG_SPANISH_CHILE: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 199\n");
            return "es_CL";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 199\n");
          case SUBLANG_SPANISH_URUGUAY: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 200\n");
            return "es_UY";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 200\n");
          case SUBLANG_SPANISH_PARAGUAY: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 201\n");
            return "es_PY";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 201\n");
          case SUBLANG_SPANISH_BOLIVIA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 202\n");
            return "es_BO";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 202\n");
          case SUBLANG_SPANISH_EL_SALVADOR: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 203\n");
            return "es_SV";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 203\n");
          case SUBLANG_SPANISH_HONDURAS: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 204\n");
            return "es_HN";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 204\n");
          case SUBLANG_SPANISH_NICARAGUA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 205\n");
            return "es_NI";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 205\n");
          case SUBLANG_SPANISH_PUERTO_RICO: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 206\n");
            return "es_PR";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 206\n");
        }
        return "es";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 186\n");
      case LANG_SUTU: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 207\n");
        return "bnt_TZ"; /* or "st_LS" or "nso_ZA"? */
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 207\n");
      case LANG_SWAHILI: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 208\n");
        return "sw_KE";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 208\n");
      case LANG_SWEDISH:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 209\n");
        switch (sub)
        {
          case SUBLANG_DEFAULT: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 210\n");
            return "sv_SE";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 210\n");
          case SUBLANG_SWEDISH_FINLAND: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 211\n");
            return "sv_FI";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 211\n");
        }
        return "sv";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 209\n");
      case LANG_SYRIAC: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 212\n");
        return "syr_TR"; /* An extinct language.  */
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 212\n");
      case LANG_TAGALOG: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 213\n");
        return "tl_PH";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 213\n");
      case LANG_TAJIK: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 214\n");
        return "tg_TJ";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 214\n");
      case LANG_TAMAZIGHT:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 215\n");
        switch (sub)
        {
          /* FIXME: Adjust this when Tamazight locales appear on Unix.  */
          case SUBLANG_TAMAZIGHT_ARABIC: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 216\n");
            return "ber_MA@arabic";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 216\n");
          case SUBLANG_TAMAZIGHT_ALGERIA_LATIN: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 217\n");
            return "ber_DZ@latin";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 217\n");
        }
        return "ber_MA";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 215\n");
      case LANG_TAMIL:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 218\n");
        switch (sub)
        {
          case SUBLANG_DEFAULT: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 219\n");
            return "ta_IN";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 219\n");
        }
        return "ta"; /* Ambiguous: could be "ta_IN" or "ta_LK" or "ta_SG".  */
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 218\n");
      case LANG_TATAR: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 220\n");
        return "tt_RU";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 220\n");
      case LANG_TELUGU: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 221\n");
        return "te_IN";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 221\n");
      case LANG_THAI: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 222\n");
        return "th_TH";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 222\n");
      case LANG_TIBETAN: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 223\n");
        return "bo_CN";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 223\n");
      case LANG_TIGRINYA:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 224\n");
        switch (sub)
        {
          case SUBLANG_TIGRINYA_ETHIOPIA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 225\n");
            return "ti_ET";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 225\n");
          case SUBLANG_TIGRINYA_ERITREA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 226\n");
            return "ti_ER";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 226\n");
        }
        return "ti";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 224\n");
      case LANG_TSONGA: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 227\n");
        return "ts_ZA";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 227\n");
      case LANG_TSWANA: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 228\n");
        return "tn_BW";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 228\n");
      case LANG_TURKISH: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 229\n");
        return "tr_TR";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 229\n");
      case LANG_TURKMEN: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 230\n");
        return "tk_TM";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 230\n");
      case LANG_UKRAINIAN: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 231\n");
        return "uk_UA";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 231\n");
      case LANG_URDU:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 232\n");
        switch (sub)
        {
          case SUBLANG_URDU_PAKISTAN: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 233\n");
            return "ur_PK";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 233\n");
          case SUBLANG_URDU_INDIA: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 234\n");
            return "ur_IN";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 234\n");
        }
        return "ur";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 232\n");
      case LANG_UZBEK:
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 235\n");
        switch (sub)
        {
          case SUBLANG_UZBEK_LATIN: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 236\n");
            return "uz_UZ";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 236\n");
          case SUBLANG_UZBEK_CYRILLIC: 
            fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 237\n");
            return "uz_UZ@cyrillic";
            fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 237\n");
        }
        return "uz";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 235\n");
      case LANG_VENDA: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 238\n");
        return "ve_ZA";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 238\n");
      case LANG_VIETNAMESE: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 239\n");
        return "vi_VN";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 239\n");
      case LANG_WELSH: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 240\n");
        return "cy_GB";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 240\n");
      case LANG_XHOSA: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 241\n");
        return "xh_ZA";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 241\n");
      case LANG_YI: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 242\n");
        return "sit_CN";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 242\n");
      case LANG_YIDDISH: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 243\n");
        return "yi_IL";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 243\n");
      case LANG_YORUBA: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 244\n");
        return "yo_NG";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 244\n");
      case LANG_ZULU: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 245\n");
        return "zu_ZA";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 245\n");
      default: 
        fprintf(stderr, "[intl/localename.c] enter gl_locale_name_default 246\n");
        return "C";
        fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 246\n");
    }
  }
  fprintf(stderr, "[intl/localename.c] exit gl_locale_name_default 7\n");
# endif
#endif
}

const char *
gl_locale_name (int category, const char *categoryname)
{
  fprintf(stderr, "[intl/localename.c] enter gl_locale_name 1\n");
  const char *retval;

  retval = gl_locale_name_posix (category, categoryname);
  if (retval != NULL)
  {
    fprintf(stderr, "[intl/localename.c] enter gl_locale_name 2\n");
    return retval;
    fprintf(stderr, "[intl/localename.c] exit gl_locale_name 2\n");
  }

  return gl_locale_name_default ();
  fprintf(stderr, "[intl/localename.c] exit gl_locale_name 1\n");
}
// Total cost: 0.584977
// Total split cost: 0.138731, input tokens: 38431, output tokens: 224, cache read tokens: 19122, cache write tokens: 19122, split chunks: [(0, 710), (710, 1507)]
// Total instrumented cost: 0.446246, input tokens: 22262, output tokens: 21671, cache read tokens: 4505, cache write tokens: 17749

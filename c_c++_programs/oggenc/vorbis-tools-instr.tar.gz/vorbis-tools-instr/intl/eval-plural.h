/* Plural expression evaluation.
   Copyright (C) 2000-2003, 2007 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU Library General Public License as published
   by the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301,
   USA.  */

#ifndef STATIC
#define STATIC static
#endif

#include <stdio.h>

/* Evaluate the plural expression and return an index value.  */
STATIC
unsigned long int
internal_function
plural_eval (const struct expression *pexp, unsigned long int n)
{
  fprintf(stderr, "\n");
  switch (pexp->nargs)
    {
    case 0:
      fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 2\n");
      switch (pexp->operation)
	{
	case var:
	  fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 3\n");
	  return n;
	  fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 3\n");
	case num:
	  fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 4\n");
	  return pexp->val.num;
	  fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 4\n");
	default:
	  fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 5\n");
	  break;
	  fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 5\n");
	}
      /* NOTREACHED */
      break;
      fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 2\n");
    case 1:
      {
	fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 6\n");
	/* pexp->operation must be lnot.  */
	unsigned long int arg = plural_eval (pexp->val.args[0], n);
	return ! arg;
	fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 6\n");
      }
    case 2:
      {
	fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 7\n");
	unsigned long int leftarg = plural_eval (pexp->val.args[0], n);
	fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 7\n");
	if (pexp->operation == lor)
	{
	  fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 8\n");
	  return leftarg || plural_eval (pexp->val.args[1], n);
	  fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 8\n");
	}
	else if (pexp->operation == land)
	{
	  fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 9\n");
	  return leftarg && plural_eval (pexp->val.args[1], n);
	  fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 9\n");
	}
	else
	  {
	    fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 10\n");
	    unsigned long int rightarg = plural_eval (pexp->val.args[1], n);
	    fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 10\n");

	    switch (pexp->operation)
	      {
	      case mult:
		fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 11\n");
		return leftarg * rightarg;
		fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 11\n");
	      case divide:
#if !INTDIV0_RAISES_SIGFPE
		fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 12\n");
		if (rightarg == 0)
		{
		  fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 13\n");
		  raise (SIGFPE);
		  fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 13\n");
		}
		fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 12\n");
#endif
		fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 14\n");
		return leftarg / rightarg;
		fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 14\n");
	      case module:
#if !INTDIV0_RAISES_SIGFPE
		fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 15\n");
		if (rightarg == 0)
		{
		  fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 16\n");
		  raise (SIGFPE);
		  fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 16\n");
		}
		fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 15\n");
#endif
		fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 17\n");
		return leftarg % rightarg;
		fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 17\n");
	      case plus:
		fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 18\n");
		return leftarg + rightarg;
		fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 18\n");
	      case minus:
		fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 19\n");
		return leftarg - rightarg;
		fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 19\n");
	      case less_than:
		fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 20\n");
		return leftarg < rightarg;
		fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 20\n");
	      case greater_than:
		fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 21\n");
		return leftarg > rightarg;
		fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 21\n");
	      case less_or_equal:
		fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 22\n");
		return leftarg <= rightarg;
		fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 22\n");
	      case greater_or_equal:
		fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 23\n");
		return leftarg >= rightarg;
		fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 23\n");
	      case equal:
		fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 24\n");
		return leftarg == rightarg;
		fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 24\n");
	      case not_equal:
		fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 25\n");
		return leftarg != rightarg;
		fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 25\n");
	      default:
		fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 26\n");
		break;
		fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 26\n");
	      }
	  }
	/* NOTREACHED */
	break;
      }
    case 3:
      {
	fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 27\n");
	/* pexp->operation must be qmop.  */
	unsigned long int boolarg = plural_eval (pexp->val.args[0], n);
	return plural_eval (pexp->val.args[boolarg ? 1 : 2], n);
	fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 27\n");
      }
    }
  /* NOTREACHED */
  fprintf(stderr, "[intl/eval-plural.h] enter plural_eval 28\n");
  return 0;
  fprintf(stderr, "[intl/eval-plural.h] exit plural_eval 28\n");
}
// Total cost: 0.035532
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 108)]
// Total instrumented cost: 0.035532, input tokens: 3276, output tokens: 1876, cache read tokens: 2280, cache write tokens: 992

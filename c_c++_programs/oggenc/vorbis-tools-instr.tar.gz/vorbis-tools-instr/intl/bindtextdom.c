/* Implementation of the bindtextdomain(3) function
   Copyright (C) 1995-1998, 2000-2003, 2005-2006 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU Library General Public License as published
   by the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301,
   USA.  */

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "gettextP.h"
#ifdef _LIBC
# include <libintl.h>
#else
# include "libgnuintl.h"
#endif

/* Handle multi-threaded applications.  */
#ifdef _LIBC
# include <bits/libc-lock.h>
# define gl_rwlock_define __libc_rwlock_define
# define gl_rwlock_wrlock __libc_rwlock_wrlock
# define gl_rwlock_unlock __libc_rwlock_unlock
#else
# include "lock.h"
#endif

/* Some compilers, like SunOS4 cc, don't have offsetof in <stddef.h>.  */
#ifndef offsetof
# define offsetof(type,ident) ((size_t)&(((type*)0)->ident))
#endif

/* @@ end of prolog @@ */

/* Lock variable to protect the global data in the gettext implementation.  */
gl_rwlock_define (extern, _nl_state_lock attribute_hidden)


/* Names for the libintl functions are a problem.  They must not clash
   with existing names and they should follow ANSI C.  But this source
   code is also used in GNU C Library where the names have a __
   prefix.  So we have to make a difference here.  */
#ifdef _LIBC
# define BINDTEXTDOMAIN __bindtextdomain
# define BIND_TEXTDOMAIN_CODESET __bind_textdomain_codeset
# ifndef strdup
#  define strdup(str) __strdup (str)
# endif
#else
# define BINDTEXTDOMAIN libintl_bindtextdomain
# define BIND_TEXTDOMAIN_CODESET libintl_bind_textdomain_codeset
#endif

/* Specifies the directory name *DIRNAMEP and the output codeset *CODESETP
   to be used for the DOMAINNAME message catalog.
   If *DIRNAMEP or *CODESETP is NULL, the corresponding attribute is not
   modified, only the current value is returned.
   If DIRNAMEP or CODESETP is NULL, the corresponding attribute is neither
   modified nor returned.  */
static void
set_binding_values (const char *domainname,
		    const char **dirnamep, const char **codesetp)
{
  fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 1\n");
  struct binding *binding;
  int modified;

  /* Some sanity checks.  */
  if (domainname == NULL || domainname[0] == '\0')
    {
      fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 2\n");
      if (dirnamep)
	*dirnamep = NULL;
      if (codesetp)
	*codesetp = NULL;
      return;
      fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 2\n");
    }

  gl_rwlock_wrlock (_nl_state_lock);

  modified = 0;
  fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 1\n");

  for (binding = _nl_domain_bindings; binding != NULL; binding = binding->next)
    {
      fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 3\n");
      int compare = strcmp (domainname, binding->domainname);
      fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 3\n");
      if (compare == 0)
	{
	  fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 4\n");
	  /* We found it!  */
	  break;
	  fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 4\n");
	}
      if (compare < 0)
	{
	  fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 5\n");
	  /* It is not in the list.  */
	  binding = NULL;
	  break;
	  fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 5\n");
	}
    }

  if (binding != NULL)
    {
      fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 6\n");
      if (dirnamep)
	{
	  fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 7\n");
	  const char *dirname = *dirnamep;

	  if (dirname == NULL)
	    {
	      fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 8\n");
	      /* The current binding has be to returned.  */
	      *dirnamep = binding->dirname;
	      fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 8\n");
	    }
	  else
	    {
	      fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 9\n");
	      /* The domain is already bound.  If the new value and the old
		 one are equal we simply do nothing.  Otherwise replace the
		 old binding.  */
	      char *result = binding->dirname;
	      if (strcmp (dirname, result) != 0)
		{
		  fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 10\n");
		  if (strcmp (dirname, _nl_default_dirname) == 0)
		    result = (char *) _nl_default_dirname;
		  else
		    {
		      fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 11\n");
#if defined _LIBC || defined HAVE_STRDUP
		      result = strdup (dirname);
#else
		      size_t len = strlen (dirname) + 1;
		      result = (char *) malloc (len);
		      if (__builtin_expect (result != NULL, 1))
			memcpy (result, dirname, len);
#endif
		      fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 11\n");
		    }

		  if (__builtin_expect (result != NULL, 1))
		    {
		      fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 12\n");
		      if (binding->dirname != _nl_default_dirname)
			free (binding->dirname);

		      binding->dirname = result;
		      modified = 1;
		      fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 12\n");
		    }
		  fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 10\n");
		}
	      *dirnamep = result;
	      fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 9\n");
	    }
	  fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 7\n");
	}

      if (codesetp)
	{
	  fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 13\n");
	  const char *codeset = *codesetp;

	  if (codeset == NULL)
	    {
	      fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 14\n");
	      /* The current binding has be to returned.  */
	      *codesetp = binding->codeset;
	      fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 14\n");
	    }
	  else
	    {
	      fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 15\n");
	      /* The domain is already bound.  If the new value and the old
		 one are equal we simply do nothing.  Otherwise replace the
		 old binding.  */
	      char *result = binding->codeset;
	      if (result == NULL || strcmp (codeset, result) != 0)
		{
		  fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 16\n");
#if defined _LIBC || defined HAVE_STRDUP
		  result = strdup (codeset);
#else
		  size_t len = strlen (codeset) + 1;
		  result = (char *) malloc (len);
		  if (__builtin_expect (result != NULL, 1))
		    memcpy (result, codeset, len);
#endif

		  if (__builtin_expect (result != NULL, 1))
		    {
		      fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 17\n");
		      if (binding->codeset != NULL)
			free (binding->codeset);

		      binding->codeset = result;
		      modified = 1;
		      fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 17\n");
		    }
		  fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 16\n");
		}
	      *codesetp = result;
	      fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 15\n");
	    }
	  fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 13\n");
	}
      fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 6\n");
    }
  else if ((dirnamep == NULL || *dirnamep == NULL)
	   && (codesetp == NULL || *codesetp == NULL))
    {
      fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 18\n");
      /* Simply return the default values.  */
      if (dirnamep)
	*dirnamep = _nl_default_dirname;
      if (codesetp)
	*codesetp = NULL;
      fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 18\n");
    }
  else
    {
      fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 19\n");
      /* We have to create a new binding.  */
      size_t len = strlen (domainname) + 1;
      struct binding *new_binding =
	(struct binding *) malloc (offsetof (struct binding, domainname) + len);

      if (__builtin_expect (new_binding == NULL, 0))
	goto failed;

      memcpy (new_binding->domainname, domainname, len);

      if (dirnamep)
	{
	  fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 20\n");
	  const char *dirname = *dirnamep;

	  if (dirname == NULL)
	    {
	      fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 21\n");
	      /* The default value.  */
	      dirname = _nl_default_dirname;
	      fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 21\n");
	    }
	  else
	    {
	      fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 22\n");
	      if (strcmp (dirname, _nl_default_dirname) == 0)
		dirname = _nl_default_dirname;
	      else
		{
		  fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 23\n");
		  char *result;
#if defined _LIBC || defined HAVE_STRDUP
		  result = strdup (dirname);
		  if (__builtin_expect (result == NULL, 0))
		    goto failed_dirname;
#else
		  size_t len = strlen (dirname) + 1;
		  result = (char *) malloc (len);
		  if (__builtin_expect (result == NULL, 0))
		    goto failed_dirname;
		  memcpy (result, dirname, len);
#endif
		  dirname = result;
		  fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 23\n");
		}
	      fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 22\n");
	    }
	  *dirnamep = dirname;
	  new_binding->dirname = (char *) dirname;
	  fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 20\n");
	}
      else
	{
	  fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 24\n");
	  /* The default value.  */
	  new_binding->dirname = (char *) _nl_default_dirname;
	  fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 24\n");
	}

      if (codesetp)
	{
	  fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 25\n");
	  const char *codeset = *codesetp;

	  if (codeset != NULL)
	    {
	      fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 26\n");
	      char *result;

#if defined _LIBC || defined HAVE_STRDUP
	      result = strdup (codeset);
	      if (__builtin_expect (result == NULL, 0))
		goto failed_codeset;
#else
	      size_t len = strlen (codeset) + 1;
	      result = (char *) malloc (len);
	      if (__builtin_expect (result == NULL, 0))
		goto failed_codeset;
	      memcpy (result, codeset, len);
#endif
	      codeset = result;
	      fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 26\n");
	    }
	  *codesetp = codeset;
	  new_binding->codeset = (char *) codeset;
	  fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 25\n");
	}
      else
	{
	  fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 27\n");
	  new_binding->codeset = NULL;
	  fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 27\n");
	}

      /* Now enqueue it.  */
      if (_nl_domain_bindings == NULL
	  || strcmp (domainname, _nl_domain_bindings->domainname) < 0)
	{
	  fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 28\n");
	  new_binding->next = _nl_domain_bindings;
	  _nl_domain_bindings = new_binding;
	  fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 28\n");
	}
      else
	{
	  fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 29\n");
	  binding = _nl_domain_bindings;
	  while (binding->next != NULL
		 && strcmp (domainname, binding->next->domainname) > 0)
	    binding = binding->next;

	  new_binding->next = binding->next;
	  binding->next = new_binding;
	  fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 29\n");
	}

      modified = 1;

      /* Here we deal with memory allocation failures.  */
      if (0)
	{
	failed_codeset:
	  fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 30\n");
	  if (new_binding->dirname != _nl_default_dirname)
	    free (new_binding->dirname);
	  fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 30\n");
	failed_dirname:
	  fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 31\n");
	  free (new_binding);
	  fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 31\n");
	failed:
	  fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 32\n");
	  if (dirnamep)
	    *dirnamep = NULL;
	  if (codesetp)
	    *codesetp = NULL;
	  fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 32\n");
	}
      fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 19\n");
    }

  /* If we modified any binding, we flush the caches.  */
  if (modified)
    {
      fprintf(stderr, "[intl/bindtextdom.c] enter set_binding_values 33\n");
      ++_nl_msg_cat_cntr;
      fprintf(stderr, "[intl/bindtextdom.c] exit set_binding_values 33\n");
    }

  gl_rwlock_unlock (_nl_state_lock);
}

/* Specify that the DOMAINNAME message catalog will be found
   in DIRNAME rather than in the system locale data base.  */
char *
BINDTEXTDOMAIN (const char *domainname, const char *dirname)
{
  fprintf(stderr, "[intl/bindtextdom.c] enter BINDTEXTDOMAIN 1\n");
  set_binding_values (domainname, &dirname, NULL);
  return (char *) dirname;
  fprintf(stderr, "[intl/bindtextdom.c] exit BINDTEXTDOMAIN 1\n");
}

/* Specify the character encoding in which the messages from the
   DOMAINNAME message catalog will be returned.  */
char *
BIND_TEXTDOMAIN_CODESET (const char *domainname, const char *codeset)
{
  fprintf(stderr, "[intl/bindtextdom.c] enter BIND_TEXTDOMAIN_CODESET 1\n");
  set_binding_values (domainname, NULL, &codeset);
  return (char *) codeset;
  fprintf(stderr, "[intl/bindtextdom.c] exit BIND_TEXTDOMAIN_CODESET 1\n");
}

#ifdef _LIBC
/* Aliases for function names in GNU C Library.  */
weak_alias (__bindtextdomain, bindtextdomain);
weak_alias (__bind_textdomain_codeset, bind_textdomain_codeset);
#endif
// Total cost: 0.089882
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 340)]
// Total instrumented cost: 0.089882, input tokens: 5459, output tokens: 4517, cache read tokens: 2280, cache write tokens: 3175

/* Determine a canonical name for the current locale's character encoding.

   Copyright (C) 2000-2006 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU Library General Public License as published
   by the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301,
   USA.  */

/* Written by Bruno Haible <bruno@clisp.org>.  */

#include <config.h>

/* Specification.  */
#include "localcharset.h"

#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#if defined _WIN32 || defined __WIN32__
# define WIN32_NATIVE
#endif

#if defined __EMX__
/* Assume EMX program runs on OS/2, even if compiled under DOS.  */
# define OS2
#endif

#if !defined WIN32_NATIVE
# if HAVE_LANGINFO_CODESET
#  include <langinfo.h>
# else
#  if 0 /* see comment below */
#   include <locale.h>
#  endif
# endif
# ifdef __CYGWIN__
#  define WIN32_LEAN_AND_MEAN
#  include <windows.h>
# endif
#elif defined WIN32_NATIVE
# define WIN32_LEAN_AND_MEAN
# include <windows.h>
#endif
#if defined OS2
# define INCL_DOS
# include <os2.h>
#endif

#if ENABLE_RELOCATABLE
# include "relocatable.h"
#else
# define relocate(pathname) (pathname)
#endif

/* Get LIBDIR.  */
#ifndef LIBDIR
# include "configmake.h"
#endif

#if defined _WIN32 || defined __WIN32__ || defined __CYGWIN__ || defined __EMX__ || defined __DJGPP__
  /* Win32, Cygwin, OS/2, DOS */
# define ISSLASH(C) ((C) == '/' || (C) == '\\')
#endif

#ifndef DIRECTORY_SEPARATOR
# define DIRECTORY_SEPARATOR '/'
#endif

#ifndef ISSLASH
# define ISSLASH(C) ((C) == DIRECTORY_SEPARATOR)
#endif

#if HAVE_DECL_GETC_UNLOCKED
# undef getc
# define getc getc_unlocked
#endif

/* The following static variable is declared 'volatile' to avoid a
   possible multithread problem in the function get_charset_aliases. If we
   are running in a threaded environment, and if two threads initialize
   'charset_aliases' simultaneously, both will produce the same value,
   and everything will be ok if the two assignments to 'charset_aliases'
   are atomic. But I don't know what will happen if the two assignments mix.  */
#if __STDC__ != 1
# define volatile /* empty */
#endif
/* Pointer to the contents of the charset.alias file, if it has already been
   read, else NULL.  Its format is:
   ALIAS_1 '\0' CANONICAL_1 '\0' ... ALIAS_n '\0' CANONICAL_n '\0' '\0'  */
static const char * volatile charset_aliases;

/* Return a pointer to the contents of the charset.alias file.  */
static const char *
get_charset_aliases (void)
{
  fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 1\n");
  const char *cp;

  cp = charset_aliases;
  fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 1\n");
  if (cp == NULL)
  {
    fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 2\n");
#if !(defined VMS || defined WIN32_NATIVE || defined __CYGWIN__)
    FILE *fp;
    const char *dir;
    const char *base = "charset.alias";
    char *file_name;

    /* Make it possible to override the charset.alias location.  This is
       necessary for running the testsuite before "make install".  */
    dir = getenv ("CHARSETALIASDIR");
    if (dir == NULL || dir[0] == '\0')
    {
      fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 3\n");
      dir = relocate (LIBDIR);
      fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 3\n");
    }

    /* Concatenate dir and base into freshly allocated file_name.  */
    {
      fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 4\n");
      size_t dir_len = strlen (dir);
      size_t base_len = strlen (base);
      int add_slash = (dir_len > 0 && !ISSLASH (dir[dir_len - 1]));
      file_name = (char *) malloc (dir_len + add_slash + base_len + 1);
      if (file_name != NULL)
      {
        fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 5\n");
        memcpy (file_name, dir, dir_len);
        if (add_slash)
          file_name[dir_len] = DIRECTORY_SEPARATOR;
        memcpy (file_name + dir_len + add_slash, base, base_len + 1);
        fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 5\n");
      }
      fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 4\n");
    }

    if (file_name == NULL || (fp = fopen (file_name, "r")) == NULL)
    {
      fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 6\n");
      /* Out of memory or file not found, treat it as empty.  */
      cp = "";
      fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 6\n");
    }
    else
    {
      fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 7\n");
      /* Parse the file's contents.  */
      char *res_ptr = NULL;
      size_t res_size = 0;

      for (;;)
      {
        fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 8\n");
        int c;
        char buf1[50+1];
        char buf2[50+1];
        size_t l1, l2;
        char *old_res_ptr;

        c = getc (fp);
        fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 8\n");
        if (c == EOF)
        {
          fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 9\n");
          break;
          fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 9\n");
        }
        if (c == '\n' || c == ' ' || c == '\t')
        {
          fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 10\n");
          continue;
          fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 10\n");
        }
        if (c == '#')
        {
          fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 11\n");
          /* Skip comment, to end of line.  */
          do
          {
            fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 12\n");
            c = getc (fp);
            fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 12\n");
          }
          while (!(c == EOF || c == '\n'));
          if (c == EOF)
          {
            fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 13\n");
            break;
            fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 13\n");
          }
          continue;
          fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 11\n");
        }
        fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 14\n");
        ungetc (c, fp);
        if (fscanf (fp, "%50s %50s", buf1, buf2) < 2)
        {
          fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 15\n");
          break;
          fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 15\n");
        }
        l1 = strlen (buf1);
        l2 = strlen (buf2);
        old_res_ptr = res_ptr;
        if (res_size == 0)
        {
          fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 16\n");
          res_size = l1 + 1 + l2 + 1;
          res_ptr = (char *) malloc (res_size + 1);
          fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 16\n");
        }
        else
        {
          fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 17\n");
          res_size += l1 + 1 + l2 + 1;
          res_ptr = (char *) realloc (res_ptr, res_size + 1);
          fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 17\n");
        }
        if (res_ptr == NULL)
        {
          fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 18\n");
          /* Out of memory. */
          res_size = 0;
          if (old_res_ptr != NULL)
            free (old_res_ptr);
          break;
          fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 18\n");
        }
        fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 19\n");
        strcpy (res_ptr + res_size - (l2 + 1) - (l1 + 1), buf1);
        strcpy (res_ptr + res_size - (l2 + 1), buf2);
        fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 19\n");
        fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 14\n");
      }
      fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 20\n");
      fclose (fp);
      if (res_size == 0)
      {
        fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 21\n");
        cp = "";
        fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 21\n");
      }
      else
      {
        fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 22\n");
        *(res_ptr + res_size) = '\0';
        cp = res_ptr;
        fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 22\n");
      }
      fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 20\n");
      fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 7\n");
    }

    if (file_name != NULL)
    {
      fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 23\n");
      free (file_name);
      fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 23\n");
    }

#else

# if defined VMS
    fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 24\n");
    /* To avoid the troubles of an extra file charset.alias_vms in the
       sources of many GNU packages, simply inline the aliases here.  */
    /* The list of encodings is taken from the OpenVMS 7.3-1 documentation
       "Compaq C Run-Time Library Reference Manual for OpenVMS systems"
       section 10.7 "Handling Different Character Sets".  */
    cp = "ISO8859-1" "\0" "ISO-8859-1" "\0"
         "ISO8859-2" "\0" "ISO-8859-2" "\0"
         "ISO8859-5" "\0" "ISO-8859-5" "\0"
         "ISO8859-7" "\0" "ISO-8859-7" "\0"
         "ISO8859-8" "\0" "ISO-8859-8" "\0"
         "ISO8859-9" "\0" "ISO-8859-9" "\0"
         /* Japanese */
         "eucJP" "\0" "EUC-JP" "\0"
         "SJIS" "\0" "SHIFT_JIS" "\0"
         "DECKANJI" "\0" "DEC-KANJI" "\0"
         "SDECKANJI" "\0" "EUC-JP" "\0"
         /* Chinese */
         "eucTW" "\0" "EUC-TW" "\0"
         "DECHANYU" "\0" "DEC-HANYU" "\0"
         "DECHANZI" "\0" "GB2312" "\0"
         /* Korean */
         "DECKOREAN" "\0" "EUC-KR" "\0";
    fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 24\n");
# endif

# if defined WIN32_NATIVE || defined __CYGWIN__
    fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 25\n");
    /* To avoid the troubles of installing a separate file in the same
       directory as the DLL and of retrieving the DLL's directory at
       runtime, simply inline the aliases here.  */

    cp = "CP936" "\0" "GBK" "\0"
         "CP1361" "\0" "JOHAB" "\0"
         "CP20127" "\0" "ASCII" "\0"
         "CP20866" "\0" "KOI8-R" "\0"
         "CP20936" "\0" "GB2312" "\0"
         "CP21866" "\0" "KOI8-RU" "\0"
         "CP28591" "\0" "ISO-8859-1" "\0"
         "CP28592" "\0" "ISO-8859-2" "\0"
         "CP28593" "\0" "ISO-8859-3" "\0"
         "CP28594" "\0" "ISO-8859-4" "\0"
         "CP28595" "\0" "ISO-8859-5" "\0"
         "CP28596" "\0" "ISO-8859-6" "\0"
         "CP28597" "\0" "ISO-8859-7" "\0"
         "CP28598" "\0" "ISO-8859-8" "\0"
         "CP28599" "\0" "ISO-8859-9" "\0"
         "CP28605" "\0" "ISO-8859-15" "\0"
         "CP38598" "\0" "ISO-8859-8" "\0"
         "CP51932" "\0" "EUC-JP" "\0"
         "CP51936" "\0" "GB2312" "\0"
         "CP51949" "\0" "EUC-KR" "\0"
         "CP51950" "\0" "EUC-TW" "\0"
         "CP54936" "\0" "GB18030" "\0"
         "CP65001" "\0" "UTF-8" "\0";
    fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 25\n");
# endif
#endif

    fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 26\n");
    charset_aliases = cp;
    fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 26\n");
    fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 2\n");
  }

  fprintf(stderr, "[intl/localcharset.c] enter get_charset_aliases 27\n");
  return cp;
  fprintf(stderr, "[intl/localcharset.c] exit get_charset_aliases 27\n");
}

/* Determine the current locale's character encoding, and canonicalize it
   into one of the canonical names listed in config.charset.
   The result must not be freed; it is statically allocated.
   If the canonical name cannot be determined, the result is a non-canonical
   name.  */

#ifdef STATIC
STATIC
#endif
const char *
locale_charset (void)
{
  fprintf(stderr, "[intl/localcharset.c] enter locale_charset 1\n");
  const char *codeset;
  const char *aliases;

#if !(defined WIN32_NATIVE || defined OS2)

# if HAVE_LANGINFO_CODESET

  /* Most systems support nl_langinfo (CODESET) nowadays.  */
  codeset = nl_langinfo (CODESET);

#  ifdef __CYGWIN__
  /* Cygwin 2006 does not have locales.  nl_langinfo (CODESET) always
     returns "US-ASCII".  As long as this is not fixed, return the suffix
     of the locale name from the environment variables (if present) or
     the codepage as a number.  */
  if (codeset != NULL && strcmp (codeset, "US-ASCII") == 0)
  {
    fprintf(stderr, "[intl/localcharset.c] enter locale_charset 2\n");
    const char *locale;
    static char buf[2 + 10 + 1];

    locale = getenv ("LC_ALL");
    if (locale == NULL || locale[0] == '\0')
    {
      fprintf(stderr, "[intl/localcharset.c] enter locale_charset 3\n");
      locale = getenv ("LC_CTYPE");
      if (locale == NULL || locale[0] == '\0')
        locale = getenv ("LANG");
      fprintf(stderr, "[intl/localcharset.c] exit locale_charset 3\n");
    }
    if (locale != NULL && locale[0] != '\0')
    {
      fprintf(stderr, "[intl/localcharset.c] enter locale_charset 4\n");
      /* If the locale name contains an encoding after the dot, return
         it.  */
      const char *dot = strchr (locale, '.');

      if (dot != NULL)
      {
        fprintf(stderr, "[intl/localcharset.c] enter locale_charset 5\n");
        const char *modifier;

        dot++;
        /* Look for the possible @... trailer and remove it, if any.  */
        modifier = strchr (dot, '@');
        if (modifier == NULL)
        {
          fprintf(stderr, "[intl/localcharset.c] enter locale_charset 6\n");
          return dot;
          fprintf(stderr, "[intl/localcharset.c] exit locale_charset 6\n");
        }
        if (modifier - dot < sizeof (buf))
        {
          fprintf(stderr, "[intl/localcharset.c] enter locale_charset 7\n");
          memcpy (buf, dot, modifier - dot);
          buf [modifier - dot] = '\0';
          return buf;
          fprintf(stderr, "[intl/localcharset.c] exit locale_charset 7\n");
        }
        fprintf(stderr, "[intl/localcharset.c] exit locale_charset 5\n");
      }
      fprintf(stderr, "[intl/localcharset.c] exit locale_charset 4\n");
    }

    /* Woe32 has a function returning the locale's codepage as a number.  */
    fprintf(stderr, "[intl/localcharset.c] enter locale_charset 8\n");
    sprintf (buf, "CP%u", GetACP ());
    codeset = buf;
    fprintf(stderr, "[intl/localcharset.c] exit locale_charset 8\n");
    fprintf(stderr, "[intl/localcharset.c] exit locale_charset 2\n");
  }
#  endif

# else

  /* On old systems which lack it, use setlocale or getenv.  */
  fprintf(stderr, "[intl/localcharset.c] enter locale_charset 9\n");
  const char *locale = NULL;

  /* But most old systems don't have a complete set of locales.  Some
     (like SunOS 4 or DJGPP) have only the C locale.  Therefore we don't
     use setlocale here; it would return "C" when it doesn't support the
     locale name the user has set.  */
#  if 0
  locale = setlocale (LC_CTYPE, NULL);
#  endif
  if (locale == NULL || locale[0] == '\0')
  {
    fprintf(stderr, "[intl/localcharset.c] enter locale_charset 10\n");
    locale = getenv ("LC_ALL");
    if (locale == NULL || locale[0] == '\0')
    {
      fprintf(stderr, "[intl/localcharset.c] enter locale_charset 11\n");
      locale = getenv ("LC_CTYPE");
      if (locale == NULL || locale[0] == '\0')
        locale = getenv ("LANG");
      fprintf(stderr, "[intl/localcharset.c] exit locale_charset 11\n");
    }
    fprintf(stderr, "[intl/localcharset.c] exit locale_charset 10\n");
  }

  /* On some old systems, one used to set locale = "iso8859_1". On others,
     you set it to "language_COUNTRY.charset". In any case, we resolve it
     through the charset.alias file.  */
  codeset = locale;
  fprintf(stderr, "[intl/localcharset.c] exit locale_charset 9\n");

# endif

#elif defined WIN32_NATIVE

  fprintf(stderr, "[intl/localcharset.c] enter locale_charset 12\n");
  static char buf[2 + 10 + 1];

  /* Woe32 has a function returning the locale's codepage as a number.  */
  sprintf (buf, "CP%u", GetACP ());
  codeset = buf;
  fprintf(stderr, "[intl/localcharset.c] exit locale_charset 12\n");

#elif defined OS2

  fprintf(stderr, "[intl/localcharset.c] enter locale_charset 13\n");
  const char *locale;
  static char buf[2 + 10 + 1];
  ULONG cp[3];
  ULONG cplen;

  /* Allow user to override the codeset, as set in the operating system,
     with standard language environment variables.  */
  locale = getenv ("LC_ALL");
  if (locale == NULL || locale[0] == '\0')
  {
    fprintf(stderr, "[intl/localcharset.c] enter locale_charset 14\n");
    locale = getenv ("LC_CTYPE");
    if (locale == NULL || locale[0] == '\0')
      locale = getenv ("LANG");
    fprintf(stderr, "[intl/localcharset.c] exit locale_charset 14\n");
  }
  if (locale != NULL && locale[0] != '\0')
  {
    fprintf(stderr, "[intl/localcharset.c] enter locale_charset 15\n");
    /* If the locale name contains an encoding after the dot, return it.  */
    const char *dot = strchr (locale, '.');

    if (dot != NULL)
    {
      fprintf(stderr, "[intl/localcharset.c] enter locale_charset 16\n");
      const char *modifier;

      dot++;
      /* Look for the possible @... trailer and remove it, if any.  */
      modifier = strchr (dot, '@');
      if (modifier == NULL)
      {
        fprintf(stderr, "[intl/localcharset.c] enter locale_charset 17\n");
        return dot;
        fprintf(stderr, "[intl/localcharset.c] exit locale_charset 17\n");
      }
      if (modifier - dot < sizeof (buf))
      {
        fprintf(stderr, "[intl/localcharset.c] enter locale_charset 18\n");
        memcpy (buf, dot, modifier - dot);
        buf [modifier - dot] = '\0';
        return buf;
        fprintf(stderr, "[intl/localcharset.c] exit locale_charset 18\n");
      }
      fprintf(stderr, "[intl/localcharset.c] exit locale_charset 16\n");
    }

    /* Resolve through the charset.alias file.  */
    codeset = locale;
    fprintf(stderr, "[intl/localcharset.c] exit locale_charset 15\n");
  }
  else
  {
    fprintf(stderr, "[intl/localcharset.c] enter locale_charset 19\n");
    /* OS/2 has a function returning the locale's codepage as a number.  */
    if (DosQueryCp (sizeof (cp), cp, &cplen))
    {
      fprintf(stderr, "[intl/localcharset.c] enter locale_charset 20\n");
      codeset = "";
      fprintf(stderr, "[intl/localcharset.c] exit locale_charset 20\n");
    }
    else
    {
      fprintf(stderr, "[intl/localcharset.c] enter locale_charset 21\n");
      sprintf (buf, "CP%u", cp[0]);
      codeset = buf;
      fprintf(stderr, "[intl/localcharset.c] exit locale_charset 21\n");
    }
    fprintf(stderr, "[intl/localcharset.c] exit locale_charset 19\n");
  }
  fprintf(stderr, "[intl/localcharset.c] exit locale_charset 13\n");

#endif

  fprintf(stderr, "[intl/localcharset.c] enter locale_charset 22\n");
  if (codeset == NULL)
  {
    fprintf(stderr, "[intl/localcharset.c] enter locale_charset 23\n");
    /* The canonical name cannot be determined.  */
    codeset = "";
    fprintf(stderr, "[intl/localcharset.c] exit locale_charset 23\n");
  }

  /* Resolve alias. */
  for (aliases = get_charset_aliases ();
       *aliases != '\0';
       aliases += strlen (aliases) + 1, aliases += strlen (aliases) + 1)
  {
    fprintf(stderr, "[intl/localcharset.c] enter locale_charset 24\n");
    if (strcmp (codeset, aliases) == 0
        || (aliases[0] == '*' && aliases[1] == '\0'))
    {
      fprintf(stderr, "[intl/localcharset.c] enter locale_charset 25\n");
      codeset = aliases + strlen (aliases) + 1;
      break;
      fprintf(stderr, "[intl/localcharset.c] exit locale_charset 25\n");
    }
    fprintf(stderr, "[intl/localcharset.c] exit locale_charset 24\n");
  }

  /* Don't return an empty string.  GNU libc and GNU libiconv interpret
     the empty string as denoting "the locale's character encoding",
     thus GNU libiconv would call this function a second time.  */
  if (codeset[0] == '\0')
  {
    fprintf(stderr, "[intl/localcharset.c] enter locale_charset 26\n");
    codeset = "ASCII";
    fprintf(stderr, "[intl/localcharset.c] exit locale_charset 26\n");
  }

  fprintf(stderr, "[intl/localcharset.c] enter locale_charset 27\n");
  return codeset;
  fprintf(stderr, "[intl/localcharset.c] exit locale_charset 27\n");
  fprintf(stderr, "[intl/localcharset.c] exit locale_charset 22\n");
  fprintf(stderr, "[intl/localcharset.c] exit locale_charset 1\n");
}
// Total cost: 0.279210
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 461)]
// Total instrumented cost: 0.279210, input tokens: 20595, output tokens: 13349, cache read tokens: 9304, cache write tokens: 11283

/* Expression parsing for plural form selection.
   Copyright (C) 2000-2001, 2003, 2005-2007 Free Software Foundation, Inc.
   Written by Ulrich Drepper <drepper@cygnus.com>, 2000.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU Library General Public License as published
   by the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301,
   USA.  */

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "plural-exp.h"

#if (defined __GNUC__ && !(__APPLE_CC__ > 1) && !defined __cplusplus) \
    || (defined __STDC_VERSION__ && __STDC_VERSION__ >= 199901L)

/* These structs are the constant expression for the germanic plural
   form determination.  It represents the expression  "n != 1".  */
static const struct expression plvar =
{
  .nargs = 0,
  .operation = var,
};
static const struct expression plone =
{
  .nargs = 0,
  .operation = num,
  .val =
  {
    .num = 1
  }
};
struct expression GERMANIC_PLURAL =
{
  .nargs = 2,
  .operation = not_equal,
  .val =
  {
    .args =
    {
      [0] = (struct expression *) &plvar,
      [1] = (struct expression *) &plone
    }
  }
};

# define INIT_GERMANIC_PLURAL()

#else

/* For compilers without support for ISO C 99 struct/union initializers:
   Initialization at run-time.  */

static struct expression plvar;
static struct expression plone;
struct expression GERMANIC_PLURAL;

static void
init_germanic_plural ()
{
  fprintf(stderr, "[intl/plural-exp.c] enter init_germanic_plural 1\n");
  if (plone.val.num == 0)
  {
    fprintf(stderr, "[intl/plural-exp.c] enter init_germanic_plural 2\n");
    plvar.nargs = 0;
    plvar.operation = var;

    plone.nargs = 0;
    plone.operation = num;
    plone.val.num = 1;

    GERMANIC_PLURAL.nargs = 2;
    GERMANIC_PLURAL.operation = not_equal;
    GERMANIC_PLURAL.val.args[0] = &plvar;
    GERMANIC_PLURAL.val.args[1] = &plone;
    fprintf(stderr, "[intl/plural-exp.c] exit init_germanic_plural 2\n");
  }
  fprintf(stderr, "[intl/plural-exp.c] exit init_germanic_plural 1\n");
}

# define INIT_GERMANIC_PLURAL() init_germanic_plural ()

#endif

void
internal_function
EXTRACT_PLURAL_EXPRESSION (const char *nullentry,
			   const struct expression **pluralp,
			   unsigned long int *npluralsp)
{
  fprintf(stderr, "[intl/plural-exp.c] enter EXTRACT_PLURAL_EXPRESSION 1\n");
  if (nullentry != NULL)
  {
    fprintf(stderr, "[intl/plural-exp.c] enter EXTRACT_PLURAL_EXPRESSION 2\n");
    const char *plural;
    const char *nplurals;

    plural = strstr (nullentry, "plural=");
    nplurals = strstr (nullentry, "nplurals=");
    if (plural == NULL || nplurals == NULL)
    {
      fprintf(stderr, "[intl/plural-exp.c] enter EXTRACT_PLURAL_EXPRESSION 3\n");
      goto no_plural;
      fprintf(stderr, "[intl/plural-exp.c] exit EXTRACT_PLURAL_EXPRESSION 3\n");
    }
    else
    {
      fprintf(stderr, "[intl/plural-exp.c] enter EXTRACT_PLURAL_EXPRESSION 4\n");
      char *endp;
      unsigned long int n;
      struct parse_args args;

      /* First get the number.  */
      nplurals += 9;
      while (*nplurals != '\0' && isspace ((unsigned char) *nplurals))
        ++nplurals;
      if (!(*nplurals >= '0' && *nplurals <= '9'))
      {
        fprintf(stderr, "[intl/plural-exp.c] enter EXTRACT_PLURAL_EXPRESSION 5\n");
        goto no_plural;
        fprintf(stderr, "[intl/plural-exp.c] exit EXTRACT_PLURAL_EXPRESSION 5\n");
      }
#if defined HAVE_STRTOUL || defined _LIBC
      n = strtoul (nplurals, &endp, 10);
#else
      fprintf(stderr, "[intl/plural-exp.c] enter EXTRACT_PLURAL_EXPRESSION 6\n");
      for (endp = nplurals, n = 0; *endp >= '0' && *endp <= '9'; endp++)
        n = n * 10 + (*endp - '0');
      fprintf(stderr, "[intl/plural-exp.c] exit EXTRACT_PLURAL_EXPRESSION 6\n");
#endif
      if (nplurals == endp)
      {
        fprintf(stderr, "[intl/plural-exp.c] enter EXTRACT_PLURAL_EXPRESSION 7\n");
        goto no_plural;
        fprintf(stderr, "[intl/plural-exp.c] exit EXTRACT_PLURAL_EXPRESSION 7\n");
      }
      *npluralsp = n;

      /* Due to the restrictions bison imposes onto the interface of the
         scanner function we have to put the input string and the result
         passed up from the parser into the same structure which address
         is passed down to the parser.  */
      plural += 7;
      args.cp = plural;
      if (PLURAL_PARSE (&args) != 0)
      {
        fprintf(stderr, "[intl/plural-exp.c] enter EXTRACT_PLURAL_EXPRESSION 8\n");
        goto no_plural;
        fprintf(stderr, "[intl/plural-exp.c] exit EXTRACT_PLURAL_EXPRESSION 8\n");
      }
      *pluralp = args.res;
      fprintf(stderr, "[intl/plural-exp.c] exit EXTRACT_PLURAL_EXPRESSION 4\n");
    }
    fprintf(stderr, "[intl/plural-exp.c] exit EXTRACT_PLURAL_EXPRESSION 2\n");
  }
  else
  {
    fprintf(stderr, "[intl/plural-exp.c] enter EXTRACT_PLURAL_EXPRESSION 9\n");
    /* By default we are using the Germanic form: singular form only
       for `one', the plural form otherwise.  Yes, this is also what
       English is using since English is a Germanic language.  */
  no_plural:
    INIT_GERMANIC_PLURAL ();
    *pluralp = &GERMANIC_PLURAL;
    *npluralsp = 2;
    fprintf(stderr, "[intl/plural-exp.c] exit EXTRACT_PLURAL_EXPRESSION 9\n");
  }
  fprintf(stderr, "[intl/plural-exp.c] exit EXTRACT_PLURAL_EXPRESSION 1\n");
}
// Total cost: 0.038569
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 155)]
// Total instrumented cost: 0.038569, input tokens: 3737, output tokens: 1871, cache read tokens: 2280, cache write tokens: 1453

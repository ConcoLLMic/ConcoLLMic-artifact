/* Locking in multithreaded situations.
   Copyright (C) 2005-2006 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU Library General Public License as published
   by the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301,
   USA.  */

/* Written by Bruno Haible <bruno@clisp.org>, 2005.
   Based on GCC's gthr-posix.h, gthr-posix95.h, gthr-solaris.h,
   gthr-win32.h.  */

#include <config.h>
#include <stdio.h>

#include "lock.h"

/* ========================================================================= */

#if USE_POSIX_THREADS

/* Use the POSIX threads library.  */

# if PTHREAD_IN_USE_DETECTION_HARD

/* The function to be executed by a dummy thread.  */
static void *
dummy_thread_func (void *arg)
{
  fprintf(stderr, "[intl/lock.c] enter dummy_thread_func 1\n");
  return arg;
  fprintf(stderr, "[intl/lock.c] exit dummy_thread_func 1\n");
}

int
glthread_in_use (void)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_in_use 1\n");
  static int tested;
  static int result; /* 1: linked with -lpthread, 0: only with libc */
  fprintf(stderr, "[intl/lock.c] exit glthread_in_use 1\n");

  if (!tested)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_in_use 2\n");
      pthread_t thread;
      fprintf(stderr, "[intl/lock.c] exit glthread_in_use 2\n");

      if (pthread_create (&thread, NULL, dummy_thread_func, NULL) != 0)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_in_use 3\n");
	  /* Thread creation failed.  */
	  result = 0;
          fprintf(stderr, "[intl/lock.c] exit glthread_in_use 3\n");
        }
      else
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_in_use 4\n");
	  /* Thread creation works.  */
	  void *retval;
          fprintf(stderr, "[intl/lock.c] exit glthread_in_use 4\n");
	  if (pthread_join (thread, &retval) != 0)
	    {
              fprintf(stderr, "[intl/lock.c] enter glthread_in_use 5\n");
	      abort ();
              fprintf(stderr, "[intl/lock.c] exit glthread_in_use 5\n");
            }
          fprintf(stderr, "[intl/lock.c] enter glthread_in_use 6\n");
	  result = 1;
          fprintf(stderr, "[intl/lock.c] exit glthread_in_use 6\n");
	}
      fprintf(stderr, "[intl/lock.c] enter glthread_in_use 7\n");
      tested = 1;
      fprintf(stderr, "[intl/lock.c] exit glthread_in_use 7\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_in_use 8\n");
  return result;
  fprintf(stderr, "[intl/lock.c] exit glthread_in_use 8\n");
}

# endif

/* -------------------------- gl_lock_t datatype -------------------------- */

/* ------------------------- gl_rwlock_t datatype ------------------------- */

# if HAVE_PTHREAD_RWLOCK

#  if !defined PTHREAD_RWLOCK_INITIALIZER

void
glthread_rwlock_init (gl_rwlock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_init 1\n");
  if (pthread_rwlock_init (&lock->rwlock, NULL) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_init 2\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_init 2\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_init 3\n");
  lock->initialized = 1;
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_init 3\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_init 1\n");
}

void
glthread_rwlock_rdlock (gl_rwlock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 1\n");
  if (!lock->initialized)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 2\n");
      if (pthread_mutex_lock (&lock->guard) != 0)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 3\n");
	  abort ();
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 3\n");
        }
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 4\n");
      if (!lock->initialized)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 5\n");
	  glthread_rwlock_init (lock);
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 5\n");
        }
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 6\n");
      if (pthread_mutex_unlock (&lock->guard) != 0)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 7\n");
	  abort ();
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 7\n");
        }
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 6\n");
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 4\n");
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 2\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 8\n");
  if (pthread_rwlock_rdlock (&lock->rwlock) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 9\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 9\n");
    }
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 8\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 1\n");
}

void
glthread_rwlock_wrlock (gl_rwlock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 1\n");
  if (!lock->initialized)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 2\n");
      if (pthread_mutex_lock (&lock->guard) != 0)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 3\n");
	  abort ();
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 3\n");
        }
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 4\n");
      if (!lock->initialized)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 5\n");
	  glthread_rwlock_init (lock);
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 5\n");
        }
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 6\n");
      if (pthread_mutex_unlock (&lock->guard) != 0)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 7\n");
	  abort ();
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 7\n");
        }
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 6\n");
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 4\n");
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 2\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 8\n");
  if (pthread_rwlock_wrlock (&lock->rwlock) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 9\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 9\n");
    }
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 8\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 1\n");
}

void
glthread_rwlock_unlock (gl_rwlock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 1\n");
  if (!lock->initialized)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 2\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 2\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 3\n");
  if (pthread_rwlock_unlock (&lock->rwlock) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 4\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 4\n");
    }
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 3\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 1\n");
}

void
glthread_rwlock_destroy (gl_rwlock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_destroy 1\n");
  if (!lock->initialized)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_destroy 2\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_destroy 2\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_destroy 3\n");
  if (pthread_rwlock_destroy (&lock->rwlock) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_destroy 4\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_destroy 4\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_destroy 5\n");
  lock->initialized = 0;
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_destroy 5\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_destroy 3\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_destroy 1\n");
}

#  endif

# else

void
glthread_rwlock_init (gl_rwlock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_init 587\n");
  if (pthread_mutex_init (&lock->lock, NULL) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_init 3724\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_init 3724\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_init 2186\n");
  if (pthread_cond_init (&lock->waiting_readers, NULL) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_init 4\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_init 4\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_init 5\n");
  if (pthread_cond_init (&lock->waiting_writers, NULL) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_init 6\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_init 6\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_init 7\n");
  lock->waiting_writers_count = 0;
  lock->runcount = 0;
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_init 7\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_init 5\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_init 2186\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_init 587\n");
}

void
glthread_rwlock_rdlock (gl_rwlock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 2880\n");
  if (pthread_mutex_lock (&lock->lock) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 3431\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 3431\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 4058\n");
  /* Test whether only readers are currently running, and whether the runcount
     field will not overflow.  */
  /* POSIX says: "It is implementation-defined whether the calling thread
     acquires the lock when a writer does not hold the lock and there are
     writers blocked on the lock."  Let's say, no: give the writers a higher
     priority.  */
  while (!(lock->runcount + 1 > 0 && lock->waiting_writers_count == 0))
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 1498\n");
      /* This thread has to wait for a while.  Enqueue it among the
	 waiting_readers.  */
      if (pthread_cond_wait (&lock->waiting_readers, &lock->lock) != 0)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 3597\n");
	  abort ();
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 3597\n");
        }
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 1498\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 3044\n");
  lock->runcount++;
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 661\n");
  if (pthread_mutex_unlock (&lock->lock) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 3996\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 3996\n");
    }
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 661\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 3044\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 4058\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 2880\n");
}

void
glthread_rwlock_wrlock (gl_rwlock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 3647\n");
  if (pthread_mutex_lock (&lock->lock) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 2014\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 2014\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 3531\n");
  /* Test whether no readers or writers are currently running.  */
  while (!(lock->runcount == 0))
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 4643\n");
      /* This thread has to wait for a while.  Enqueue it among the
	 waiting_writers.  */
      lock->waiting_writers_count++;
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 567\n");
      if (pthread_cond_wait (&lock->waiting_writers, &lock->lock) != 0)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 3590\n");
	  abort ();
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 3590\n");
        }
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 1560\n");
      lock->waiting_writers_count--;
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 1560\n");
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 567\n");
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 4643\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 2781\n");
  lock->runcount--; /* runcount becomes -1 */
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 4606\n");
  if (pthread_mutex_unlock (&lock->lock) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 10\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 10\n");
    }
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 4606\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 2781\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 3531\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 3647\n");
}

void
glthread_rwlock_unlock (gl_rwlock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 4654\n");
  if (pthread_mutex_lock (&lock->lock) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 2687\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 2687\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 851\n");
  if (lock->runcount < 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 1341\n");
      /* Drop a writer lock.  */
      if (!(lock->runcount == -1))
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 5\n");
	  abort ();
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 5\n");
        }
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 6\n");
      lock->runcount = 0;
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 6\n");
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 1341\n");
    }
  else
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 7\n");
      /* Drop a reader lock.  */
      if (!(lock->runcount > 0))
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 8\n");
	  abort ();
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 8\n");
        }
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 9\n");
      lock->runcount--;
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 9\n");
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 7\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 10\n");
  if (lock->runcount == 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 11\n");
      /* POSIX recommends that "write locks shall take precedence over read
	 locks", to avoid "writer starvation".  */
      if (lock->waiting_writers_count > 0)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 12\n");
	  /* Wake up one of the waiting writers.  */
	  if (pthread_cond_signal (&lock->waiting_writers) != 0)
	    {
              fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 13\n");
	      abort ();
              fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 13\n");
            }
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 12\n");
	}
      else
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 14\n");
	  /* Wake up all waiting readers.  */
	  if (pthread_cond_broadcast (&lock->waiting_readers) != 0)
	    {
              fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 15\n");
	      abort ();
              fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 15\n");
            }
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 14\n");
	}
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 11\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 16\n");
  if (pthread_mutex_unlock (&lock->lock) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 17\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 17\n");
    }
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 16\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 10\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 851\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 4654\n");
}

void
glthread_rwlock_destroy (gl_rwlock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_destroy 3153\n");
  if (pthread_mutex_destroy (&lock->lock) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_destroy 3134\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_destroy 3134\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_destroy 4214\n");
  if (pthread_cond_destroy (&lock->waiting_readers) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_destroy 1487\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_destroy 1487\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_destroy 2757\n");
  if (pthread_cond_destroy (&lock->waiting_writers) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_destroy 6\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_destroy 6\n");
    }
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_destroy 2757\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_destroy 4214\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_destroy 3153\n");
}

# endif

/* --------------------- gl_recursive_lock_t datatype --------------------- */

# if HAVE_PTHREAD_MUTEX_RECURSIVE

#  if !(defined PTHREAD_RECURSIVE_MUTEX_INITIALIZER || defined PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP)

void
glthread_recursive_lock_init (gl_recursive_lock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_init 1\n");
  pthread_mutexattr_t attributes;
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_init 2\n");

  if (pthread_mutexattr_init (&attributes) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_init 3\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_init 3\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_init 4\n");
  if (pthread_mutexattr_settype (&attributes, PTHREAD_MUTEX_RECURSIVE) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_init 5\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_init 5\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_init 6\n");
  if (pthread_mutex_init (&lock->recmutex, &attributes) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_init 7\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_init 7\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_init 8\n");
  if (pthread_mutexattr_destroy (&attributes) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_init 9\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_init 9\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_init 10\n");
  lock->initialized = 1;
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_init 10\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_init 8\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_init 6\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_init 4\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_init 2\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_init 1\n");
}

void
glthread_recursive_lock_lock (gl_recursive_lock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 1\n");
  if (!lock->initialized)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 2\n");
      if (pthread_mutex_lock (&lock->guard) != 0)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 3\n");
	  abort ();
          fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 3\n");
        }
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 4\n");
      if (!lock->initialized)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 5\n");
	  glthread_recursive_lock_init (lock);
          fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 5\n");
        }
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 6\n");
      if (pthread_mutex_unlock (&lock->guard) != 0)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 7\n");
	  abort ();
          fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 7\n");
        }
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 6\n");
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 4\n");
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 2\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 8\n");
  if (pthread_mutex_lock (&lock->recmutex) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 9\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 9\n");
    }
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 8\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 1\n");
}

void
glthread_recursive_lock_unlock (gl_recursive_lock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_unlock 1\n");
  if (!lock->initialized)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_unlock 2\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_unlock 2\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_unlock 3\n");
  if (pthread_mutex_unlock (&lock->recmutex) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_unlock 4\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_unlock 4\n");
    }
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_unlock 3\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_unlock 1\n");
}

void
glthread_recursive_lock_destroy (gl_recursive_lock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_destroy 1\n");
  if (!lock->initialized)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_destroy 2\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_destroy 2\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_destroy 3\n");
  if (pthread_mutex_destroy (&lock->recmutex) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_destroy 4\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_destroy 4\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_destroy 5\n");
  lock->initialized = 0;
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_destroy 5\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_destroy 3\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_destroy 1\n");
}

#  endif

# else

void
glthread_recursive_lock_init (gl_recursive_lock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_init 3748\n");
  if (pthread_mutex_init (&lock->mutex, NULL) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_init 3384\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_init 3384\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_init 3981\n");
  lock->owner = (pthread_t) 0;
  lock->depth = 0;
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_init 3981\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_init 3748\n");
}

void
glthread_recursive_lock_lock (gl_recursive_lock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 3361\n");
  pthread_t self = pthread_self ();
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 714\n");
  if (lock->owner != self)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 2977\n");
      if (pthread_mutex_lock (&lock->mutex) != 0)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 4207\n");
	  abort ();
          fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 4207\n");
        }
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 1364\n");
      lock->owner = self;
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 1364\n");
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 2977\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 4697\n");
  if (++(lock->depth) == 0) /* wraparound? */
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 1226\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 1226\n");
    }
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 4697\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 714\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 3361\n");
}

void
glthread_recursive_lock_unlock (gl_recursive_lock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_unlock 2242\n");
  if (lock->owner != pthread_self ())
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_unlock 3360\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_unlock 3360\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_unlock 3897\n");
  if (lock->depth == 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_unlock 4074\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_unlock 4074\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_unlock 5\n");
  if (--(lock->depth) == 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_unlock 6\n");
      lock->owner = (pthread_t) 0;
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_unlock 7\n");
      if (pthread_mutex_unlock (&lock->mutex) != 0)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_unlock 8\n");
	  abort ();
          fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_unlock 8\n");
        }
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_unlock 7\n");
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_unlock 6\n");
    }
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_unlock 5\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_unlock 3897\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_unlock 2242\n");
}

void
glthread_recursive_lock_destroy (gl_recursive_lock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_destroy 1340\n");
  if (lock->owner != (pthread_t) 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_destroy 1917\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_destroy 1917\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_destroy 4128\n");
  if (pthread_mutex_destroy (&lock->mutex) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_destroy 3296\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_destroy 3296\n");
    }
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_destroy 4128\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_destroy 1340\n");
}

# endif

/* -------------------------- gl_once_t datatype -------------------------- */

static const pthread_once_t fresh_once = PTHREAD_ONCE_INIT;

int
glthread_once_singlethreaded (pthread_once_t *once_control)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_once_singlethreaded 1\n");
  /* We don't know whether pthread_once_t is an integer type, a floating-point
     type, a pointer type, or a structure type.  */
  char *firstbyte = (char *)once_control;
  fprintf(stderr, "[intl/lock.c] enter glthread_once_singlethreaded 2\n");
  if (*firstbyte == *(const char *)&fresh_once)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_once_singlethreaded 3\n");
      /* First time use of once_control.  Invert the first byte.  */
      *firstbyte = ~ *(const char *)&fresh_once;
      fprintf(stderr, "[intl/lock.c] enter glthread_once_singlethreaded 4\n");
      return 1;
      fprintf(stderr, "[intl/lock.c] exit glthread_once_singlethreaded 4\n");
      fprintf(stderr, "[intl/lock.c] exit glthread_once_singlethreaded 3\n");
    }
  else
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_once_singlethreaded 5\n");
      return 0;
      fprintf(stderr, "[intl/lock.c] exit glthread_once_singlethreaded 5\n");
    }
  fprintf(stderr, "[intl/lock.c] exit glthread_once_singlethreaded 2\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_once_singlethreaded 1\n");
}

#endif

/* ========================================================================= */

#if USE_PTH_THREADS

/* Use the GNU Pth threads library.  */

/* -------------------------- gl_lock_t datatype -------------------------- */

/* ------------------------- gl_rwlock_t datatype ------------------------- */

/* --------------------- gl_recursive_lock_t datatype --------------------- */

/* -------------------------- gl_once_t datatype -------------------------- */

void
glthread_once_call (void *arg)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_once_call 1\n");
  void (**gl_once_temp_addr) (void) = (void (**) (void)) arg;
  void (*initfunction) (void) = *gl_once_temp_addr;
  fprintf(stderr, "[intl/lock.c] enter glthread_once_call 2\n");
  initfunction ();
  fprintf(stderr, "[intl/lock.c] exit glthread_once_call 2\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_once_call 1\n");
}

int
glthread_once_singlethreaded (pth_once_t *once_control)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_once_singlethreaded 3357\n");
  /* We know that pth_once_t is an integer type.  */
  if (*once_control == PTH_ONCE_INIT)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_once_singlethreaded 2826\n");
      /* First time use of once_control.  Invert the marker.  */
      *once_control = ~ PTH_ONCE_INIT;
      fprintf(stderr, "[intl/lock.c] enter glthread_once_singlethreaded 655\n");
      return 1;
      fprintf(stderr, "[intl/lock.c] exit glthread_once_singlethreaded 655\n");
      fprintf(stderr, "[intl/lock.c] exit glthread_once_singlethreaded 2826\n");
    }
  else
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_once_singlethreaded 1093\n");
      return 0;
      fprintf(stderr, "[intl/lock.c] exit glthread_once_singlethreaded 1093\n");
    }
  fprintf(stderr, "[intl/lock.c] exit glthread_once_singlethreaded 3357\n");
}

#endif

/* ========================================================================= */

#if USE_SOLARIS_THREADS

/* Use the old Solaris threads library.  */

/* -------------------------- gl_lock_t datatype -------------------------- */

/* ------------------------- gl_rwlock_t datatype ------------------------- */

/* --------------------- gl_recursive_lock_t datatype --------------------- */

void
glthread_recursive_lock_init (gl_recursive_lock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_init 2517\n");
  if (mutex_init (&lock->mutex, USYNC_THREAD, NULL) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_init 4468\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_init 4468\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_init 3248\n");
  lock->owner = (thread_t) 0;
  lock->depth = 0;
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_init 3248\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_init 2517\n");
}

void
glthread_recursive_lock_lock (gl_recursive_lock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 1134\n");
  thread_t self = thr_self ();
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 1240\n");
  if (lock->owner != self)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 2340\n");
      if (mutex_lock (&lock->mutex) != 0)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 1088\n");
	  abort ();
          fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 1088\n");
        }
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 634\n");
      lock->owner = self;
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 634\n");
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 2340\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 710\n");
  if (++(lock->depth) == 0) /* wraparound? */
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 1432\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 1432\n");
    }
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 710\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 1240\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 1134\n");
}

void
glthread_recursive_lock_unlock (gl_recursive_lock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_unlock 3288\n");
  if (lock->owner != thr_self ())
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_unlock 687\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_unlock 687\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_unlock 3153\n");
  if (lock->depth == 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_unlock 3466\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_unlock 3466\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_unlock 4695\n");
  if (--(lock->depth) == 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_unlock 4809\n");
      lock->owner = (thread_t) 0;
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_unlock 1991\n");
      if (mutex_unlock (&lock->mutex) != 0)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_unlock 1717\n");
	  abort ();
          fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_unlock 1717\n");
        }
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_unlock 1991\n");
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_unlock 4809\n");
    }
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_unlock 4695\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_unlock 3153\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_unlock 3288\n");
}

void
glthread_recursive_lock_destroy (gl_recursive_lock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_destroy 1717\n");
  if (lock->owner != (thread_t) 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_destroy 2575\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_destroy 2575\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_destroy 3537\n");
  if (mutex_destroy (&lock->mutex) != 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_destroy 4826\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_destroy 4826\n");
    }
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_destroy 3537\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_destroy 1717\n");
}

/* -------------------------- gl_once_t datatype -------------------------- */

void
glthread_once (gl_once_t *once_control, void (*initfunction) (void))
{
  fprintf(stderr, "[intl/lock.c] enter glthread_once 1\n");
  if (!once_control->inited)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_once 2\n");
      /* Use the mutex to guarantee that if another thread is already calling
	 the initfunction, this thread waits until it's finished.  */
      if (mutex_lock (&once_control->mutex) != 0)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_once 3\n");
	  abort ();
          fprintf(stderr, "[intl/lock.c] exit glthread_once 3\n");
        }
      fprintf(stderr, "[intl/lock.c] enter glthread_once 4\n");
      if (!once_control->inited)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_once 5\n");
	  once_control->inited = 1;
          fprintf(stderr, "[intl/lock.c] enter glthread_once 6\n");
	  initfunction ();
          fprintf(stderr, "[intl/lock.c] exit glthread_once 6\n");
          fprintf(stderr, "[intl/lock.c] exit glthread_once 5\n");
	}
      fprintf(stderr, "[intl/lock.c] enter glthread_once 7\n");
      if (mutex_unlock (&once_control->mutex) != 0)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_once 8\n");
	  abort ();
          fprintf(stderr, "[intl/lock.c] exit glthread_once 8\n");
        }
      fprintf(stderr, "[intl/lock.c] exit glthread_once 7\n");
      fprintf(stderr, "[intl/lock.c] exit glthread_once 4\n");
      fprintf(stderr, "[intl/lock.c] exit glthread_once 2\n");
    }
  fprintf(stderr, "[intl/lock.c] exit glthread_once 1\n");
}

int
glthread_once_singlethreaded (gl_once_t *once_control)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_once_singlethreaded 4269\n");
  /* We know that gl_once_t contains an integer type.  */
  if (!once_control->inited)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_once_singlethreaded 4487\n");
      /* First time use of once_control.  Invert the marker.  */
      once_control->inited = ~ 0;
      fprintf(stderr, "[intl/lock.c] enter glthread_once_singlethreaded 1956\n");
      return 1;
      fprintf(stderr, "[intl/lock.c] exit glthread_once_singlethreaded 1956\n");
      fprintf(stderr, "[intl/lock.c] exit glthread_once_singlethreaded 4487\n");
    }
  else
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_once_singlethreaded 2784\n");
      return 0;
      fprintf(stderr, "[intl/lock.c] exit glthread_once_singlethreaded 2784\n");
    }
  fprintf(stderr, "[intl/lock.c] exit glthread_once_singlethreaded 4269\n");
}

#endif

/* ========================================================================= */

#if USE_WIN32_THREADS

/* -------------------------- gl_lock_t datatype -------------------------- */

void
glthread_lock_init (gl_lock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_lock_init 1\n");
  InitializeCriticalSection (&lock->lock);
  fprintf(stderr, "[intl/lock.c] enter glthread_lock_init 2\n");
  lock->guard.done = 1;
  fprintf(stderr, "[intl/lock.c] exit glthread_lock_init 2\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_lock_init 1\n");
}

void
glthread_lock_lock (gl_lock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_lock_lock 1\n");
  if (!lock->guard.done)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_lock_lock 2\n");
      if (InterlockedIncrement (&lock->guard.started) == 0)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_lock_lock 3\n");
	  /* This thread is the first one to need this lock.  Initialize it.  */
	  glthread_lock_init (lock);
          fprintf(stderr, "[intl/lock.c] exit glthread_lock_lock 3\n");
        }
      else
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_lock_lock 4\n");
	  /* Yield the CPU while waiting for another thread to finish
	     initializing this lock.  */
	  while (!lock->guard.done)
	    {
              fprintf(stderr, "[intl/lock.c] enter glthread_lock_lock 5\n");
	      Sleep (0);
              fprintf(stderr, "[intl/lock.c] exit glthread_lock_lock 5\n");
            }
          fprintf(stderr, "[intl/lock.c] exit glthread_lock_lock 4\n");
        }
      fprintf(stderr, "[intl/lock.c] exit glthread_lock_lock 2\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_lock_lock 6\n");
  EnterCriticalSection (&lock->lock);
  fprintf(stderr, "[intl/lock.c] exit glthread_lock_lock 6\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_lock_lock 1\n");
}

void
glthread_lock_unlock (gl_lock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_lock_unlock 1\n");
  if (!lock->guard.done)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_lock_unlock 2\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_lock_unlock 2\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_lock_unlock 3\n");
  LeaveCriticalSection (&lock->lock);
  fprintf(stderr, "[intl/lock.c] exit glthread_lock_unlock 3\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_lock_unlock 1\n");
}

void
glthread_lock_destroy (gl_lock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_lock_destroy 1\n");
  if (!lock->guard.done)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_lock_destroy 2\n");
      abort ();
      fprintf(stderr, "[intl/lock.c] exit glthread_lock_destroy 2\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_lock_destroy 3\n");
  DeleteCriticalSection (&lock->lock);
  fprintf(stderr, "[intl/lock.c] enter glthread_lock_destroy 4\n");
  lock->guard.done = 0;
  fprintf(stderr, "[intl/lock.c] exit glthread_lock_destroy 4\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_lock_destroy 3\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_lock_destroy 1\n");
}

/* ------------------------- gl_rwlock_t datatype ------------------------- */

static inline void
gl_waitqueue_init (gl_waitqueue_t *wq)
{
  fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_init 1\n");
  wq->array = NULL;
  wq->count = 0;
  wq->alloc = 0;
  wq->offset = 0;
  fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_init 1\n");
}

/* Enqueues the current thread, represented by an event, in a wait queue.
   Returns INVALID_HANDLE_VALUE if an allocation failure occurs.  */
static HANDLE
gl_waitqueue_add (gl_waitqueue_t *wq)
{
  fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 1\n");
  HANDLE event;
  unsigned int index;
  fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 2\n");

  if (wq->count == wq->alloc)
    {
      fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 3\n");
      unsigned int new_alloc = 2 * wq->alloc + 1;
      HANDLE *new_array =
	(HANDLE *) realloc (wq->array, new_alloc * sizeof (HANDLE));
      fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 4\n");
      if (new_array == NULL)
	{
          fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 5\n");
	  /* No more memory.  */
	  return INVALID_HANDLE_VALUE;
          fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 5\n");
        }
      fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 6\n");
      /* Now is a good opportunity to rotate the array so that its contents
	 starts at offset 0.  */
      if (wq->offset > 0)
	{
          fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 7\n");
	  unsigned int old_count = wq->count;
	  unsigned int old_alloc = wq->alloc;
	  unsigned int old_offset = wq->offset;
	  unsigned int i;
          fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 8\n");
	  if (old_offset + old_count > old_alloc)
	    {
              fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 9\n");
	      unsigned int limit = old_offset + old_count - old_alloc;
              fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 10\n");
	      for (i = 0; i < limit; i++)
		{
                  fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 11\n");
		  new_array[old_alloc + i] = new_array[i];
                  fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 11\n");
                }
              fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 10\n");
              fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 9\n");
	    }
          fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 12\n");
	  for (i = 0; i < old_count; i++)
	    {
              fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 13\n");
	      new_array[i] = new_array[old_offset + i];
              fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 13\n");
            }
          fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 12\n");
          fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 14\n");
	  wq->offset = 0;
          fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 14\n");
          fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 8\n");
          fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 7\n");
	}
      fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 15\n");
      wq->array = new_array;
      wq->alloc = new_alloc;
      fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 15\n");
      fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 6\n");
      fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 4\n");
      fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 3\n");
    }
  fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 16\n");
  event = CreateEvent (NULL, TRUE, FALSE, NULL);
  fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 17\n");
  if (event == INVALID_HANDLE_VALUE)
    {
      fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 18\n");
      /* No way to allocate an event.  */
      return INVALID_HANDLE_VALUE;
      fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 18\n");
    }
  fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 19\n");
  index = wq->offset + wq->count;
  fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 20\n");
  if (index >= wq->alloc)
    {
      fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 21\n");
      index -= wq->alloc;
      fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 21\n");
    }
  fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 22\n");
  wq->array[index] = event;
  wq->count++;
  fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_add 23\n");
  return event;
  fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 23\n");
  fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 22\n");
  fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 20\n");
  fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 19\n");
  fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 17\n");
  fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 16\n");
  fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 2\n");
  fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_add 1\n");
}

/* Notifies the first thread from a wait queue and dequeues it.  */
static inline void
gl_waitqueue_notify_first (gl_waitqueue_t *wq)
{
  fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_notify_first 1\n");
  SetEvent (wq->array[wq->offset + 0]);
  fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_notify_first 2\n");
  wq->offset++;
  wq->count--;
  fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_notify_first 3\n");
  if (wq->count == 0 || wq->offset == wq->alloc)
    {
      fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_notify_first 4\n");
      wq->offset = 0;
      fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_notify_first 4\n");
    }
  fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_notify_first 3\n");
  fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_notify_first 2\n");
  fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_notify_first 1\n");
}

/* Notifies all threads from a wait queue and dequeues them all.  */
static inline void
gl_waitqueue_notify_all (gl_waitqueue_t *wq)
{
  fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_notify_all 1\n");
  unsigned int i;
  fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_notify_all 2\n");

  for (i = 0; i < wq->count; i++)
    {
      fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_notify_all 3\n");
      unsigned int index = wq->offset + i;
      fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_notify_all 4\n");
      if (index >= wq->alloc)
	{
          fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_notify_all 5\n");
	  index -= wq->alloc;
          fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_notify_all 5\n");
        }
      fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_notify_all 6\n");
      SetEvent (wq->array[index]);
      fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_notify_all 6\n");
      fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_notify_all 4\n");
      fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_notify_all 3\n");
    }
  fprintf(stderr, "[intl/lock.c] enter gl_waitqueue_notify_all 7\n");
  wq->count = 0;
  wq->offset = 0;
  fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_notify_all 7\n");
  fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_notify_all 2\n");
  fprintf(stderr, "[intl/lock.c] exit gl_waitqueue_notify_all 1\n");
}

void
glthread_rwlock_init (gl_rwlock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_init 2268\n");
  InitializeCriticalSection (&lock->lock);
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_init 3909\n");
  gl_waitqueue_init (&lock->waiting_readers);
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_init 4075\n");
  gl_waitqueue_init (&lock->waiting_writers);
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_init 4560\n");
  lock->runcount = 0;
  lock->guard.done = 1;
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_init 4560\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_init 4075\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_init 3909\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_init 2268\n");
}

void
glthread_rwlock_rdlock (gl_rwlock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 1882\n");
  if (!lock->guard.done)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 284\n");
      if (InterlockedIncrement (&lock->guard.started) == 0)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 3420\n");
	  /* This thread is the first one to need this lock.  Initialize it.  */
	  glthread_rwlock_init (lock);
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 3420\n");
        }
      else
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 3652\n");
	  /* Yield the CPU while waiting for another thread to finish
	     initializing this lock.  */
	  while (!lock->guard.done)
	    {
              fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 822\n");
	      Sleep (0);
              fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 822\n");
            }
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 3652\n");
        }
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 284\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 1767\n");
  EnterCriticalSection (&lock->lock);
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 1233\n");
  /* Test whether only readers are currently running, and whether the runcount
     field will not overflow.  */
  if (!(lock->runcount + 1 > 0))
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 4457\n");
      /* This thread has to wait for a while.  Enqueue it among the
	 waiting_readers.  */
      HANDLE event = gl_waitqueue_add (&lock->waiting_readers);
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 3773\n");
      if (event != INVALID_HANDLE_VALUE)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 10\n");
	  DWORD result;
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 11\n");
	  LeaveCriticalSection (&lock->lock);
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 12\n");
	  /* Wait until another thread signals this event.  */
	  result = WaitForSingleObject (event, INFINITE);
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 13\n");
	  if (result == WAIT_FAILED || result == WAIT_TIMEOUT)
	    {
              fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 14\n");
	      abort ();
              fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 14\n");
            }
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 15\n");
	  CloseHandle (event);
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 16\n");
	  /* The thread which signalled the event already did the bookkeeping:
	     removed us from the waiting_readers, incremented lock->runcount.  */
	  if (!(lock->runcount > 0))
	    {
              fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 17\n");
	      abort ();
              fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 17\n");
            }
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 18\n");
	  return;
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 18\n");
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 16\n");
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 15\n");
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 13\n");
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 12\n");
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 11\n");
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 10\n");
	}
      else
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 19\n");
	  /* Allocation failure.  Weird.  */
	  do
	    {
              fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 20\n");
	      LeaveCriticalSection (&lock->lock);
              fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 21\n");
	      Sleep (1);
              fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 22\n");
	      EnterCriticalSection (&lock->lock);
              fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 22\n");
              fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 21\n");
              fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 20\n");
	    }
	  while (!(lock->runcount + 1 > 0));
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 19\n");
	}
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 3773\n");
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 4457\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 23\n");
  lock->runcount++;
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_rdlock 24\n");
  LeaveCriticalSection (&lock->lock);
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 24\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 23\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 1233\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 1767\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_rdlock 1882\n");
}

void
glthread_rwlock_wrlock (gl_rwlock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 711\n");
  if (!lock->guard.done)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 1608\n");
      if (InterlockedIncrement (&lock->guard.started) == 0)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 3056\n");
	  /* This thread is the first one to need this lock.  Initialize it.  */
	  glthread_rwlock_init (lock);
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 3056\n");
        }
      else
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 295\n");
	  /* Yield the CPU while waiting for another thread to finish
	     initializing this lock.  */
	  while (!lock->guard.done)
	    {
              fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 239\n");
	      Sleep (0);
              fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 239\n");
            }
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 295\n");
        }
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 1608\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 2403\n");
  EnterCriticalSection (&lock->lock);
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 4453\n");
  /* Test whether no readers or writers are currently running.  */
  if (!(lock->runcount == 0))
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 1606\n");
      /* This thread has to wait for a while.  Enqueue it among the
	 waiting_writers.  */
      HANDLE event = gl_waitqueue_add (&lock->waiting_writers);
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 2137\n");
      if (event != INVALID_HANDLE_VALUE)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 668\n");
	  DWORD result;
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 11\n");
	  LeaveCriticalSection (&lock->lock);
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 12\n");
	  /* Wait until another thread signals this event.  */
	  result = WaitForSingleObject (event, INFINITE);
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 13\n");
	  if (result == WAIT_FAILED || result == WAIT_TIMEOUT)
	    {
              fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 14\n");
	      abort ();
              fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 14\n");
            }
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 15\n");
	  CloseHandle (event);
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 16\n");
	  /* The thread which signalled the event already did the bookkeeping:
	     removed us from the waiting_writers, set lock->runcount = -1.  */
	  if (!(lock->runcount == -1))
	    {
              fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 17\n");
	      abort ();
              fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 17\n");
            }
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 18\n");
	  return;
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 18\n");
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 16\n");
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 15\n");
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 13\n");
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 12\n");
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 11\n");
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 668\n");
	}
      else
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 19\n");
	  /* Allocation failure.  Weird.  */
	  do
	    {
              fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 20\n");
	      LeaveCriticalSection (&lock->lock);
              fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 21\n");
	      Sleep (1);
              fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 22\n");
	      EnterCriticalSection (&lock->lock);
              fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 22\n");
              fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 21\n");
              fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 20\n");
	    }
	  while (!(lock->runcount == 0));
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 19\n");
	}
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 2137\n");
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 1606\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 23\n");
  lock->runcount--; /* runcount becomes -1 */
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_wrlock 24\n");
  LeaveCriticalSection (&lock->lock);
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 24\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 23\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 4453\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 2403\n");
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_wrlock 711\n");
}
void
glthread_rwlock_unlock (gl_rwlock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 2586\n");
  if (!lock->guard.done)
    abort ();
  EnterCriticalSection (&lock->lock);
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 2586\n");
  if (lock->runcount < 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 3771\n");
      /* Drop a writer lock.  */
      if (!(lock->runcount == -1))
	abort ();
      lock->runcount = 0;
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 3771\n");
    }
  else
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 3274\n");
      /* Drop a reader lock.  */
      if (!(lock->runcount > 0))
	abort ();
      lock->runcount--;
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 3274\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 3504\n");
  if (lock->runcount == 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 1419\n");
      /* POSIX recommends that "write locks shall take precedence over read
	 locks", to avoid "writer starvation".  */
      if (lock->waiting_writers.count > 0)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 4131\n");
	  /* Wake up one of the waiting writers.  */
	  lock->runcount--;
	  gl_waitqueue_notify_first (&lock->waiting_writers);
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 4131\n");
	}
      else
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_unlock 3062\n");
	  /* Wake up all waiting readers.  */
	  lock->runcount += lock->waiting_readers.count;
	  gl_waitqueue_notify_all (&lock->waiting_readers);
          fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 3062\n");
	}
      fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 1419\n");
    }
  LeaveCriticalSection (&lock->lock);
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_unlock 3504\n");
}

void
glthread_rwlock_destroy (gl_rwlock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_rwlock_destroy 1573\n");
  if (!lock->guard.done)
    abort ();
  if (lock->runcount != 0)
    abort ();
  DeleteCriticalSection (&lock->lock);
  if (lock->waiting_readers.array != NULL)
    free (lock->waiting_readers.array);
  if (lock->waiting_writers.array != NULL)
    free (lock->waiting_writers.array);
  lock->guard.done = 0;
  fprintf(stderr, "[intl/lock.c] exit glthread_rwlock_destroy 1573\n");
}

/* --------------------- gl_recursive_lock_t datatype --------------------- */

void
glthread_recursive_lock_init (gl_recursive_lock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_init 1025\n");
  lock->owner = 0;
  lock->depth = 0;
  InitializeCriticalSection (&lock->lock);
  lock->guard.done = 1;
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_init 1025\n");
}

void
glthread_recursive_lock_lock (gl_recursive_lock_t *lock)
{
  fprintf(stderr, "\n");
  if (!lock->guard.done)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 4102\n");
      if (InterlockedIncrement (&lock->guard.started) == 0)
	{
        fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 4385\n");
	/* This thread is the first one to need this lock.  Initialize it.  */
	glthread_recursive_lock_init (lock);
        fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 4385\n");
      }
      else
	{
        fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 1879\n");
	/* Yield the CPU while waiting for another thread to finish
	   initializing this lock.  */
	while (!lock->guard.done)
	  Sleep (0);
        fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 1879\n");
      }
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 4102\n");
    }
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 2916\n");
  {
    DWORD self = GetCurrentThreadId ();
    if (lock->owner != self)
      {
        fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_lock 4736\n");
	EnterCriticalSection (&lock->lock);
	lock->owner = self;
        fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 4736\n");
      }
    if (++(lock->depth) == 0) /* wraparound? */
      abort ();
  }
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_lock 2916\n");
}

void
glthread_recursive_lock_unlock (gl_recursive_lock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_unlock 2514\n");
  if (lock->owner != GetCurrentThreadId ())
    abort ();
  if (lock->depth == 0)
    abort ();
  if (--(lock->depth) == 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_unlock 4800\n");
      lock->owner = 0;
      LeaveCriticalSection (&lock->lock);
      fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_unlock 4800\n");
    }
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_unlock 2514\n");
}

void
glthread_recursive_lock_destroy (gl_recursive_lock_t *lock)
{
  fprintf(stderr, "[intl/lock.c] enter glthread_recursive_lock_destroy 4848\n");
  if (lock->owner != 0)
    abort ();
  DeleteCriticalSection (&lock->lock);
  lock->guard.done = 0;
  fprintf(stderr, "[intl/lock.c] exit glthread_recursive_lock_destroy 4848\n");
}

/* -------------------------- gl_once_t datatype -------------------------- */

void
glthread_once (gl_once_t *once_control, void (*initfunction) (void))
{
  fprintf(stderr, "[intl/lock.c] enter glthread_once 1541\n");
  if (once_control->inited <= 0)
    {
      fprintf(stderr, "[intl/lock.c] enter glthread_once 3597\n");
      if (InterlockedIncrement (&once_control->started) == 0)
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_once 3593\n");
	  /* This thread is the first one to come to this once_control.  */
	  InitializeCriticalSection (&once_control->lock);
	  EnterCriticalSection (&once_control->lock);
	  once_control->inited = 0;
	  initfunction ();
	  once_control->inited = 1;
	  LeaveCriticalSection (&once_control->lock);
          fprintf(stderr, "[intl/lock.c] exit glthread_once 3593\n");
	}
      else
	{
          fprintf(stderr, "[intl/lock.c] enter glthread_once 3170\n");
	  /* Undo last operation.  */
	  InterlockedDecrement (&once_control->started);
	  /* Some other thread has already started the initialization.
	     Yield the CPU while waiting for the other thread to finish
	     initializing and taking the lock.  */
	  while (once_control->inited < 0)
	    Sleep (0);
          fprintf(stderr, "[intl/lock.c] exit glthread_once 3170\n");
	  fprintf(stderr, "[intl/lock.c] enter glthread_once 3620\n");
	  if (once_control->inited <= 0)
	    {
              fprintf(stderr, "[intl/lock.c] enter glthread_once 4602\n");
	      /* Take the lock.  This blocks until the other thread has
		 finished calling the initfunction.  */
	      EnterCriticalSection (&once_control->lock);
	      LeaveCriticalSection (&once_control->lock);
	      if (!(once_control->inited > 0))
		abort ();
              fprintf(stderr, "[intl/lock.c] exit glthread_once 4602\n");
	    }
          fprintf(stderr, "[intl/lock.c] exit glthread_once 3620\n");
	}
      fprintf(stderr, "[intl/lock.c] exit glthread_once 3597\n");
    }
  fprintf(stderr, "[intl/lock.c] exit glthread_once 1541\n");
}

#endif

/* ========================================================================= */
// Total cost: 0.939050
// Total split cost: 0.150130, input tokens: 49457, output tokens: 763, cache read tokens: 14847, cache write tokens: 8107, split chunks: [(0, 765), (765, 922)]
// Total instrumented cost: 0.788920, input tokens: 40494, output tokens: 40158, cache read tokens: 13448, cache write tokens: 27034

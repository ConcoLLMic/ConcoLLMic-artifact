/* Formatted output to strings.
   Copyright (C) 1999-2000, 2002-2003, 2006-2007 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU Library General Public License as published
   by the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301,
   USA.  */

/* This file can be parametrized with the following macros:
     CHAR_T             The element type of the format string.
     CHAR_T_ONLY_ASCII  Set to 1 to enable verification that all characters
                        in the format string are ASCII.
     DIRECTIVE          Structure denoting a format directive.
                        Depends on CHAR_T.
     DIRECTIVES         Structure denoting the set of format directives of a
                        format string.  Depends on CHAR_T.
     PRINTF_PARSE       Function that parses a format string.
                        Depends on CHAR_T.
     STATIC             Set to 'static' to declare the function static.
     ENABLE_UNISTDIO    Set to 1 to enable the unistdio extensions.  */

#ifndef PRINTF_PARSE
# include <config.h>
#endif

/* Specification.  */
#ifndef PRINTF_PARSE
# include "printf-parse.h"
#endif

/* Default parameters.  */
#ifndef PRINTF_PARSE
# define PRINTF_PARSE printf_parse
# define CHAR_T char
# define DIRECTIVE char_directive
# define DIRECTIVES char_directives
#endif

/* Get size_t, NULL.  */
#include <stddef.h>

/* Get intmax_t.  */
#if defined IN_LIBINTL || defined IN_LIBASPRINTF
# if HAVE_STDINT_H_WITH_UINTMAX
#  include <stdint.h>
# endif
# if HAVE_INTTYPES_H_WITH_UINTMAX
#  include <inttypes.h>
# endif
#else
# include <stdint.h>
#endif

/* malloc(), realloc(), free().  */
#include <stdlib.h>

/* errno.  */
#include <errno.h>

/* Checked size_t computations.  */
#include "xsize.h"

#if CHAR_T_ONLY_ASCII
/* c_isascii().  */
# include "c-ctype.h"
#endif

#ifdef STATIC
STATIC
#endif
int
PRINTF_PARSE (const CHAR_T *format, DIRECTIVES *d, arguments *a)
{
  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 1\n");
  const CHAR_T *cp = format;		/* pointer into format */
  size_t arg_posn = 0;		/* number of regular arguments consumed */
  size_t d_allocated;			/* allocated elements of d->dir */
  size_t a_allocated;			/* allocated elements of a->arg */
  size_t max_width_length = 0;
  size_t max_precision_length = 0;

  d->count = 0;
  d_allocated = 1;
  d->dir = (DIRECTIVE *) malloc (d_allocated * sizeof (DIRECTIVE));
  if (d->dir == NULL)
  {
    fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 2\n");
    /* Out of memory.  */
    goto out_of_memory_1;
    fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 2\n");
  }

  a->count = 0;
  a_allocated = 0;
  a->arg = NULL;
  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 1\n");

#define REGISTER_ARG(_index_,_type_) \
  {									\
    fprintf(stderr, "enter PRINTF_PARSE REGISTER_ARG\n"); \
    size_t n = (_index_);						\
    if (n >= a_allocated)						\
      {									\
        fprintf(stderr, "enter PRINTF_PARSE REGISTER_ARG 1\n"); \
	size_t memory_size;						\
	argument *memory;						\
									\
	a_allocated = xtimes (a_allocated, 2);				\
	if (a_allocated <= n)						\
	  a_allocated = xsum (n, 1);					\
	memory_size = xtimes (a_allocated, sizeof (argument));		\
	if (size_overflow_p (memory_size))				\
	  /* Overflow, would lead to out of memory.  */			\
	  goto out_of_memory;						\
	memory = (argument *) (a->arg					\
			       ? realloc (a->arg, memory_size)		\
			       : malloc (memory_size));			\
	if (memory == NULL)						\
	  /* Out of memory.  */						\
	  goto out_of_memory;						\
	a->arg = memory;						\
        fprintf(stderr, "exit PRINTF_PARSE REGISTER_ARG 1\n"); \
      }									\
    while (a->count <= n)						\
      a->arg[a->count++].type = TYPE_NONE;				\
    if (a->arg[n].type == TYPE_NONE)					\
      a->arg[n].type = (_type_);					\
    else if (a->arg[n].type != (_type_))				\
    { \
      fprintf(stderr, "enter PRINTF_PARSE REGISTER_ARG 2\n"); \
      /* Ambiguous type for positional argument.  */			\
      goto error;							\
      fprintf(stderr, "exit PRINTF_PARSE REGISTER_ARG 2\n"); \
    } \
    fprintf(stderr, "exit PRINTF_PARSE REGISTER_ARG\n"); \
  }

  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 3\n");
  while (*cp != '\0')
    {
      fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 4\n");
      CHAR_T c = *cp++;
      fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 4\n");
      if (c == '%')
	{
          fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 5\n");
	  size_t arg_index = ARG_NONE;
	  DIRECTIVE *dp = &d->dir[d->count]; /* pointer to next directive */

	  /* Initialize the next directive.  */
	  dp->dir_start = cp - 1;
	  dp->flags = 0;
	  dp->width_start = NULL;
	  dp->width_end = NULL;
	  dp->width_arg_index = ARG_NONE;
	  dp->precision_start = NULL;
	  dp->precision_end = NULL;
	  dp->precision_arg_index = ARG_NONE;
	  dp->arg_index = ARG_NONE;

	  /* Test for positional argument.  */
	  if (*cp >= '0' && *cp <= '9')
	    {
              fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 6\n");
	      const CHAR_T *np;

	      for (np = cp; *np >= '0' && *np <= '9'; np++)
		;
	      if (*np == '$')
		{
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 7\n");
		  size_t n = 0;

		  for (np = cp; *np >= '0' && *np <= '9'; np++)
		    n = xsum (xtimes (n, 10), *np - '0');
		  if (n == 0)
		    {
                      fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 8\n");
		      /* Positional argument 0.  */
		      goto error;
                      fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 8\n");
		    }
		  if (size_overflow_p (n))
		    {
                      fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 9\n");
		      /* n too large, would lead to out of memory later.  */
		      goto error;
                      fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 9\n");
		    }
		  arg_index = n - 1;
		  cp = np + 1;
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 7\n");
		}
              fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 6\n");
	    }

	  /* Read the flags.  */
          fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 10\n");
	  for (;;)
	    {
              fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 11\n");
	      if (*cp == '\'')
		{
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 12\n");
		  dp->flags |= FLAG_GROUP;
		  cp++;
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 12\n");
		}
	      else if (*cp == '-')
		{
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 13\n");
		  dp->flags |= FLAG_LEFT;
		  cp++;
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 13\n");
		}
	      else if (*cp == '+')
		{
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 14\n");
		  dp->flags |= FLAG_SHOWSIGN;
		  cp++;
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 14\n");
		}
	      else if (*cp == ' ')
		{
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 15\n");
		  dp->flags |= FLAG_SPACE;
		  cp++;
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 15\n");
		}
	      else if (*cp == '#')
		{
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 16\n");
		  dp->flags |= FLAG_ALT;
		  cp++;
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 16\n");
		}
	      else if (*cp == '0')
		{
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 17\n");
		  dp->flags |= FLAG_ZERO;
		  cp++;
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 17\n");
		}
	      else
                {
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 18\n");
		  break;
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 18\n");
                }
              fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 11\n");
	    }
          fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 10\n");

	  /* Parse the field width.  */
	  if (*cp == '*')
	    {
              fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 19\n");
	      dp->width_start = cp;
	      cp++;
	      dp->width_end = cp;
	      if (max_width_length < 1)
		max_width_length = 1;

	      /* Test for positional argument.  */
	      if (*cp >= '0' && *cp <= '9')
		{
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 20\n");
		  const CHAR_T *np;

		  for (np = cp; *np >= '0' && *np <= '9'; np++)
		    ;
		  if (*np == '$')
		    {
                      fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 21\n");
		      size_t n = 0;

		      for (np = cp; *np >= '0' && *np <= '9'; np++)
			n = xsum (xtimes (n, 10), *np - '0');
		      if (n == 0)
			{
                          fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 22\n");
			  /* Positional argument 0.  */
			  goto error;
                          fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 22\n");
			}
		      if (size_overflow_p (n))
			{
                          fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 23\n");
			  /* n too large, would lead to out of memory later.  */
			  goto error;
                          fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 23\n");
			}
		      dp->width_arg_index = n - 1;
		      cp = np + 1;
                      fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 21\n");
		    }
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 20\n");
		}
	      if (dp->width_arg_index == ARG_NONE)
		{
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 24\n");
		  dp->width_arg_index = arg_posn++;
		  if (dp->width_arg_index == ARG_NONE)
		    {
                      fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 25\n");
		      /* arg_posn wrapped around.  */
		      goto error;
                      fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 25\n");
		    }
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 24\n");
		}
	      REGISTER_ARG (dp->width_arg_index, TYPE_INT);
              fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 19\n");
	    }
	  else if (*cp >= '0' && *cp <= '9')
	    {
              fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 26\n");
	      size_t width_length;

	      dp->width_start = cp;
	      for (; *cp >= '0' && *cp <= '9'; cp++)
		;
	      dp->width_end = cp;
	      width_length = dp->width_end - dp->width_start;
	      if (max_width_length < width_length)
		max_width_length = width_length;
              fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 26\n");
	    }

	  /* Parse the precision.  */
	  if (*cp == '.')
	    {
              fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 27\n");
	      cp++;
	      if (*cp == '*')
		{
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 28\n");
		  dp->precision_start = cp - 1;
		  cp++;
		  dp->precision_end = cp;
		  if (max_precision_length < 2)
		    max_precision_length = 2;

		  /* Test for positional argument.  */
		  if (*cp >= '0' && *cp <= '9')
		    {
                      fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 29\n");
		      const CHAR_T *np;

		      for (np = cp; *np >= '0' && *np <= '9'; np++)
			;
		      if (*np == '$')
			{
                          fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 30\n");
			  size_t n = 0;

			  for (np = cp; *np >= '0' && *np <= '9'; np++)
			    n = xsum (xtimes (n, 10), *np - '0');
			  if (n == 0)
			    {
                              fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 31\n");
			      /* Positional argument 0.  */
			      goto error;
                              fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 31\n");
			    }
			  if (size_overflow_p (n))
			    {
                              fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 32\n");
			      /* n too large, would lead to out of memory
			         later.  */
			      goto error;
                              fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 32\n");
			    }
			  dp->precision_arg_index = n - 1;
			  cp = np + 1;
                          fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 30\n");
			}
                      fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 29\n");
		    }
		  if (dp->precision_arg_index == ARG_NONE)
		    {
                      fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 33\n");
		      dp->precision_arg_index = arg_posn++;
		      if (dp->precision_arg_index == ARG_NONE)
			{
                          fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 34\n");
			  /* arg_posn wrapped around.  */
			  goto error;
                          fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 34\n");
			}
                      fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 33\n");
		    }
		  REGISTER_ARG (dp->precision_arg_index, TYPE_INT);
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 28\n");
		}
	      else
		{
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 35\n");
		  size_t precision_length;

		  dp->precision_start = cp - 1;
		  for (; *cp >= '0' && *cp <= '9'; cp++)
		    ;
		  dp->precision_end = cp;
		  precision_length = dp->precision_end - dp->precision_start;
		  if (max_precision_length < precision_length)
		    max_precision_length = precision_length;
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 35\n");
		}
              fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 27\n");
	    }

	  {
            fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 36\n");
	    arg_type type;

	    /* Parse argument type/size specifiers.  */
	    {
              fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 37\n");
	      int flags = 0;

	      for (;;)
		{
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 38\n");
		  if (*cp == 'h')
		    {
                      fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 39\n");
		      flags |= (1 << (flags & 1));
		      cp++;
                      fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 39\n");
		    }
		  else if (*cp == 'L')
		    {
                      fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 40\n");
		      flags |= 4;
		      cp++;
                      fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 40\n");
		    }
		  else if (*cp == 'l')
		    {
                      fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 41\n");
		      flags += 8;
		      cp++;
                      fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 41\n");
		    }
		  else if (*cp == 'j')
		    {
                      fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 42\n");
		      if (sizeof (intmax_t) > sizeof (long))
			{
                          fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 43\n");
			  /* intmax_t = long long */
			  flags += 16;
                          fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 43\n");
			}
		      else if (sizeof (intmax_t) > sizeof (int))
			{
                          fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 44\n");
			  /* intmax_t = long */
			  flags += 8;
                          fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 44\n");
			}
		      cp++;
                      fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 42\n");
		    }
		  else if (*cp == 'z' || *cp == 'Z')
		    {
                      fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 45\n");
		      /* 'z' is standardized in ISO C 99, but glibc uses 'Z'
			 because the warning facility in gcc-2.95.2 understands
			 only 'Z' (see gcc-2.95.2/gcc/c-common.c:1784).  */
		      if (sizeof (size_t) > sizeof (long))
			{
                          fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 46\n");
			  /* size_t = long long */
			  flags += 16;
                          fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 46\n");
			}
		      else if (sizeof (size_t) > sizeof (int))
			{
                          fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 47\n");
			  /* size_t = long */
			  flags += 8;
                          fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 47\n");
			}
		      cp++;
                      fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 45\n");
		    }
		  else if (*cp == 't')
		    {
                      fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 48\n");
		      if (sizeof (ptrdiff_t) > sizeof (long))
			{
                          fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 49\n");
			  /* ptrdiff_t = long long */
			  flags += 16;
                          fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 49\n");
			}
		      else if (sizeof (ptrdiff_t) > sizeof (int))
			{
                          fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 50\n");
			  /* ptrdiff_t = long */
			  flags += 8;
                          fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 50\n");
			}
		      cp++;
                      fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 48\n");
		    }
		  else
                    {
                      fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 51\n");
		      break;
                      fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 51\n");
                    }
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 38\n");
		}

	      /* Read the conversion character.  */
	      c = *cp++;
	      switch (c)
		{
		case 'd': case 'i':
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 52\n");
#if HAVE_LONG_LONG_INT
		  /* If 'long long' exists and is larger than 'long':  */
		  if (flags >= 16 || (flags & 4))
		    type = TYPE_LONGLONGINT;
		  else
#endif
		  /* If 'long long' exists and is the same as 'long', we parse
		     "lld" into TYPE_LONGINT.  */
		  if (flags >= 8)
		    type = TYPE_LONGINT;
		  else if (flags & 2)
		    type = TYPE_SCHAR;
		  else if (flags & 1)
		    type = TYPE_SHORT;
		  else
		    type = TYPE_INT;
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 52\n");
		  break;
		case 'o': case 'u': case 'x': case 'X':
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 53\n");
#if HAVE_LONG_LONG_INT
		  /* If 'long long' exists and is larger than 'long':  */
		  if (flags >= 16 || (flags & 4))
		    type = TYPE_ULONGLONGINT;
		  else
#endif
		  /* If 'unsigned long long' exists and is the same as
		     'unsigned long', we parse "llu" into TYPE_ULONGINT.  */
		  if (flags >= 8)
		    type = TYPE_ULONGINT;
		  else if (flags & 2)
		    type = TYPE_UCHAR;
		  else if (flags & 1)
		    type = TYPE_USHORT;
		  else
		    type = TYPE_UINT;
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 53\n");
		  break;
		case 'f': case 'F': case 'e': case 'E': case 'g': case 'G':
		case 'a': case 'A':
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 54\n");
		  if (flags >= 16 || (flags & 4))
		    type = TYPE_LONGDOUBLE;
		  else
		    type = TYPE_DOUBLE;
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 54\n");
		  break;
		case 'c':
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 55\n");
		  if (flags >= 8)
#if HAVE_WINT_T
		    type = TYPE_WIDE_CHAR;
#else
		    goto error;
#endif
		  else
		    type = TYPE_CHAR;
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 55\n");
		  break;
#if HAVE_WINT_T
		case 'C':
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 56\n");
		  type = TYPE_WIDE_CHAR;
		  c = 'c';
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 56\n");
		  break;
#endif
		case 's':
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 57\n");
		  if (flags >= 8)
#if HAVE_WCHAR_T
		    type = TYPE_WIDE_STRING;
#else
		    goto error;
#endif
		  else
		    type = TYPE_STRING;
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 57\n");
		  break;
#if HAVE_WCHAR_T
		case 'S':
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 58\n");
		  type = TYPE_WIDE_STRING;
		  c = 's';
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 58\n");
		  break;
#endif
		case 'p':
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 59\n");
		  type = TYPE_POINTER;
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 59\n");
		  break;
		case 'n':
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 60\n");
#if HAVE_LONG_LONG_INT
		  /* If 'long long' exists and is larger than 'long':  */
		  if (flags >= 16 || (flags & 4))
		    type = TYPE_COUNT_LONGLONGINT_POINTER;
		  else
#endif
		  /* If 'long long' exists and is the same as 'long', we parse
		     "lln" into TYPE_COUNT_LONGINT_POINTER.  */
		  if (flags >= 8)
		    type = TYPE_COUNT_LONGINT_POINTER;
		  else if (flags & 2)
		    type = TYPE_COUNT_SCHAR_POINTER;
		  else if (flags & 1)
		    type = TYPE_COUNT_SHORT_POINTER;
		  else
		    type = TYPE_COUNT_INT_POINTER;
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 60\n");
		  break;
#if ENABLE_UNISTDIO
		/* The unistdio extensions.  */
		case 'U':
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 61\n");
		  if (flags >= 16)
		    type = TYPE_U32_STRING;
		  else if (flags >= 8)
		    type = TYPE_U16_STRING;
		  else
		    type = TYPE_U8_STRING;
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 61\n");
		  break;
#endif
		case '%':
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 62\n");
		  type = TYPE_NONE;
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 62\n");
		  break;
		default:
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 63\n");
		  /* Unknown conversion character.  */
		  goto error;
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 63\n");
		}
              fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 37\n");
	    }

	    if (type != TYPE_NONE)
	      {
                fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 64\n");
		dp->arg_index = arg_index;
		if (dp->arg_index == ARG_NONE)
		  {
                    fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 65\n");
		    dp->arg_index = arg_posn++;
		    if (dp->arg_index == ARG_NONE)
		      {
                        fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 66\n");
		        /* arg_posn wrapped around.  */
		        goto error;
                        fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 66\n");
		      }
                    fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 65\n");
		  }
		REGISTER_ARG (dp->arg_index, type);
                fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 64\n");
	      }
	    dp->conversion = c;
	    dp->dir_end = cp;
            fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 36\n");
	  }

	  d->count++;
	  if (d->count >= d_allocated)
	    {
              fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 67\n");
	      size_t memory_size;
	      DIRECTIVE *memory;

	      d_allocated = xtimes (d_allocated, 2);
	      memory_size = xtimes (d_allocated, sizeof (DIRECTIVE));
	      if (size_overflow_p (memory_size))
		{
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 68\n");
		  /* Overflow, would lead to out of memory.  */
		  goto out_of_memory;
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 68\n");
		}
	      memory = (DIRECTIVE *) realloc (d->dir, memory_size);
	      if (memory == NULL)
		{
                  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 69\n");
		  /* Out of memory.  */
		  goto out_of_memory;
                  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 69\n");
		}
	      d->dir = memory;
              fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 67\n");
	    }
          fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 5\n");
	}
#if CHAR_T_ONLY_ASCII
      else if (!c_isascii (c))
	{
          fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 70\n");
	  /* Non-ASCII character.  Not supported.  */
	  goto error;
          fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 70\n");
	}
#endif
      fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 3\n");
    }
  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 71\n");
  d->dir[d->count].dir_start = cp;

  d->max_width_length = max_width_length;
  d->max_precision_length = max_precision_length;
  return 0;
  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 71\n");

error:
  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 72\n");
  if (a->arg)
    free (a->arg);
  if (d->dir)
    free (d->dir);
  errno = EINVAL;
  return -1;
  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 72\n");

out_of_memory:
  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 73\n");
  if (a->arg)
    free (a->arg);
  if (d->dir)
    free (d->dir);
  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 73\n");
out_of_memory_1:
  fprintf(stderr, "[intl/printf-parse.c] enter PRINTF_PARSE 74\n");
  errno = ENOMEM;
  return -1;
  fprintf(stderr, "[intl/printf-parse.c] exit PRINTF_PARSE 74\n");
}

#undef PRINTF_PARSE
#undef DIRECTIVES
#undef DIRECTIVE
#undef CHAR_T_ONLY_ASCII
#undef CHAR_T
// Total cost: 0.130401
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 590)]
// Total instrumented cost: 0.130401, input tokens: 7835, output tokens: 8536, cache read tokens: 7831, cache write tokens: 0

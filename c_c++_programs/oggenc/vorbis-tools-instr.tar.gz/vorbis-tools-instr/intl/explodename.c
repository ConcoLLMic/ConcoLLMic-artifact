/* Copyright (C) 1995-1998, 2000-2001, 2003, 2005, 2007 Free Software Foundation, Inc.
   Contributed by Ulrich Drepper <drepper@gnu.ai.mit.edu>, 1995.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU Library General Public License as published
   by the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301,
   USA.  */

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <stdio.h>

#include "loadinfo.h"

/* On some strange systems still no definition of NULL is found.  Sigh!  */
#ifndef NULL
# if defined __STDC__ && __STDC__
#  define NULL ((void *) 0)
# else
#  define NULL 0
# endif
#endif

/* @@ end of prolog @@ */

/* Split a locale name NAME into a leading language part and all the
   rest.  Return a pointer to the first character after the language,
   i.e. to the first byte of the rest.  */
static char *_nl_find_language (const char *name);

static char *
_nl_find_language (const char *name)
{
  fprintf(stderr, "[intl/explodename.c] enter _nl_find_language 1\n");
  while (name[0] != '\0' && name[0] != '_' && name[0] != '@' && name[0] != '.')
    ++name;
  fprintf(stderr, "[intl/explodename.c] exit _nl_find_language 1\n");

  fprintf(stderr, "[intl/explodename.c] enter _nl_find_language 2\n");
  return (char *) name;
  fprintf(stderr, "[intl/explodename.c] exit _nl_find_language 2\n");
}


int
_nl_explode_name (char *name,
		  const char **language, const char **modifier,
		  const char **territory, const char **codeset,
		  const char **normalized_codeset)
{
  fprintf(stderr, "[intl/explodename.c] enter _nl_explode_name 1\n");
  char *cp;
  int mask;

  *modifier = NULL;
  *territory = NULL;
  *codeset = NULL;
  *normalized_codeset = NULL;

  /* Now we determine the single parts of the locale name.  First
     look for the language.  Termination symbols are `_', '.', and `@'.  */
  mask = 0;
  *language = cp = name;
  cp = _nl_find_language (*language);
  fprintf(stderr, "[intl/explodename.c] exit _nl_explode_name 1\n");

  if (*language == cp)
  {
    fprintf(stderr, "[intl/explodename.c] enter _nl_explode_name 2\n");
    /* This does not make sense: language has to be specified.  Use
       this entry as it is without exploding.  Perhaps it is an alias.  */
    cp = strchr (*language, '\0');
    fprintf(stderr, "[intl/explodename.c] exit _nl_explode_name 2\n");
  }
  else
  {
    fprintf(stderr, "[intl/explodename.c] enter _nl_explode_name 3\n");
    if (cp[0] == '_')
    {
      fprintf(stderr, "[intl/explodename.c] enter _nl_explode_name 4\n");
      /* Next is the territory.  */
      cp[0] = '\0';
      *territory = ++cp;

      while (cp[0] != '\0' && cp[0] != '.' && cp[0] != '@')
        ++cp;

      mask |= XPG_TERRITORY;
      fprintf(stderr, "[intl/explodename.c] exit _nl_explode_name 4\n");
    }

    if (cp[0] == '.')
    {
      fprintf(stderr, "[intl/explodename.c] enter _nl_explode_name 5\n");
      /* Next is the codeset.  */
      cp[0] = '\0';
      *codeset = ++cp;

      while (cp[0] != '\0' && cp[0] != '@')
        ++cp;

      mask |= XPG_CODESET;

      if (*codeset != cp && (*codeset)[0] != '\0')
      {
        fprintf(stderr, "[intl/explodename.c] enter _nl_explode_name 6\n");
        *normalized_codeset = _nl_normalize_codeset (*codeset,
                           cp - *codeset);
        if (*normalized_codeset == NULL)
        {
          fprintf(stderr, "[intl/explodename.c] enter _nl_explode_name 7\n");
          return -1;
          fprintf(stderr, "[intl/explodename.c] exit _nl_explode_name 7\n");
        }
        else if (strcmp (*codeset, *normalized_codeset) == 0)
        {
          fprintf(stderr, "[intl/explodename.c] enter _nl_explode_name 8\n");
          free ((char *) *normalized_codeset);
          fprintf(stderr, "[intl/explodename.c] exit _nl_explode_name 8\n");
        }
        else
        {
          fprintf(stderr, "[intl/explodename.c] enter _nl_explode_name 9\n");
          mask |= XPG_NORM_CODESET;
          fprintf(stderr, "[intl/explodename.c] exit _nl_explode_name 9\n");
        }
        fprintf(stderr, "[intl/explodename.c] exit _nl_explode_name 6\n");
      }
      fprintf(stderr, "[intl/explodename.c] exit _nl_explode_name 5\n");
    }
    fprintf(stderr, "[intl/explodename.c] exit _nl_explode_name 3\n");
  }

  if (cp[0] == '@')
  {
    fprintf(stderr, "[intl/explodename.c] enter _nl_explode_name 10\n");
    /* Next is the modifier.  */
    cp[0] = '\0';
    *modifier = ++cp;

    if (cp[0] != '\0')
    {
      fprintf(stderr, "[intl/explodename.c] enter _nl_explode_name 11\n");
      mask |= XPG_MODIFIER;
      fprintf(stderr, "[intl/explodename.c] exit _nl_explode_name 11\n");
    }
    fprintf(stderr, "[intl/explodename.c] exit _nl_explode_name 10\n");
  }

  fprintf(stderr, "[intl/explodename.c] enter _nl_explode_name 12\n");
  if (*territory != NULL && (*territory)[0] == '\0')
    mask &= ~XPG_TERRITORY;

  if (*codeset != NULL && (*codeset)[0] == '\0')
    mask &= ~XPG_CODESET;

  return mask;
  fprintf(stderr, "[intl/explodename.c] exit _nl_explode_name 12\n");
}
// Total cost: 0.035957
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 135)]
// Total instrumented cost: 0.035957, input tokens: 3539, output tokens: 1786, cache read tokens: 2280, cache write tokens: 1255

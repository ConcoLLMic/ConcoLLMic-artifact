/* Copyright (C) 1995, 1996, 1997, 2000, 2006 Free Software Foundation, Inc.
   Contributed by Bernd Schmidt <crux@Pool.Informatik.RWTH-Aachen.DE>, 1997.

   NOTE: The canonical source of this file is maintained with the GNU C
   Library.  Bugs can be reported to bug-glibc@gnu.org.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU Library General Public License as published
   by the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301,
   USA.  */

/* Tree search for red/black trees.
   The algorithm for adding nodes is taken from one of the many "Algorithms"
   books by Robert Sedgewick, although the implementation differs.
   The algorithm for deleting nodes can probably be found in a book named
   "Introduction to Algorithms" by Cormen/Leiserson/Rivest.  At least that's
   the book that my professor took most algorithms from during the "Data
   Structures" course...

   Totally public domain.  */

/* Red/black trees are binary trees in which the edges are colored either red
   or black.  They have the following properties:
   1. The number of black edges on every path from the root to a leaf is
      constant.
   2. No two red edges are adjacent.
   Therefore there is an upper bound on the length of every path, it's
   O(log n) where n is the number of nodes in the tree.  No path can be longer
   than 1+2*P where P is the length of the shortest path in the tree.
   Useful for the implementation:
   3. If one of the children of a node is NULL, then the other one is red
      (if it exists).

   In the implementation, not the edges are colored, but the nodes.  The color
   interpreted as the color of the edge leading to this node.  The color is
   meaningless for the root node, but we color the root node black for
   convenience.  All added nodes are red initially.

   Adding to a red/black tree is rather easy.  The right place is searched
   with a usual binary tree search.  Additionally, whenever a node N is
   reached that has two red successors, the successors are colored black and
   the node itself colored red.  This moves red edges up the tree where they
   pose less of a problem once we get to really insert the new node.  Changing
   N's color to red may violate rule 2, however, so rotations may become
   necessary to restore the invariants.  Adding a new red leaf may violate
   the same rule, so afterwards an additional check is run and the tree
   possibly rotated.

   Deleting is hairy.  There are mainly two nodes involved: the node to be
   deleted (n1), and another node that is to be unchained from the tree (n2).
   If n1 has a successor (the node with a smallest key that is larger than
   n1), then the successor becomes n2 and its contents are copied into n1,
   otherwise n1 becomes n2.
   Unchaining a node may violate rule 1: if n2 is black, one subtree is
   missing one black edge afterwards.  The algorithm must try to move this
   error upwards towards the root, so that the subtree that does not have
   enough black edges becomes the whole tree.  Once that happens, the error
   has disappeared.  It may not be necessary to go all the way up, since it
   is possible that rotations and recoloring can fix the error before that.

   Although the deletion algorithm must walk upwards through the tree, we
   do not store parent pointers in the nodes.  Instead, delete allocates a
   small array of parent pointers and fills it while descending the tree.
   Since we know that the length of a path is O(log n), where n is the number
   of nodes, this is likely to use less memory.  */

/* Tree rotations look like this:
      A                C
     / \              / \
    B   C            A   G
   / \ / \  -->     / \
   D E F G         B   F
                  / \
                 D   E

   In this case, A has been rotated left.  This preserves the ordering of the
   binary tree.  */

#include <config.h>
#include <stdio.h>

/* Specification.  */
#ifdef IN_LIBINTL
# include "tsearch.h"
#else
# include <search.h>
#endif

#include <stdlib.h>

typedef int (*__compar_fn_t) (const void *, const void *);
typedef void (*__action_fn_t) (const void *, VISIT, int);

#ifndef weak_alias
# define __tsearch tsearch
# define __tfind tfind
# define __tdelete tdelete
# define __twalk twalk
#endif

#ifndef internal_function
/* Inside GNU libc we mark some function in a special way.  In other
   environments simply ignore the marking.  */
# define internal_function
#endif

typedef struct node_t
{
  /* Callers expect this to be the first element in the structure - do not
     move!  */
  const void *key;
  struct node_t *left;
  struct node_t *right;
  unsigned int red:1;
} *node;
typedef const struct node_t *const_node;

#undef DEBUGGING

#ifdef DEBUGGING

/* Routines to check tree invariants.  */

#include <assert.h>

#define CHECK_TREE(a) check_tree(a)

static void
check_tree_recurse (node p, int d_sofar, int d_total)
{
  fprintf(stderr, "[intl/tsearch.c] enter check_tree_recurse 1\n");
  if (p == NULL)
    {
      fprintf(stderr, "[intl/tsearch.c] enter check_tree_recurse 2\n");
      assert (d_sofar == d_total);
      fprintf(stderr, "[intl/tsearch.c] exit check_tree_recurse 2\n");
      return;
    }
  fprintf(stderr, "[intl/tsearch.c] exit check_tree_recurse 1\n");

  fprintf(stderr, "[intl/tsearch.c] enter check_tree_recurse 3\n");
  check_tree_recurse (p->left, d_sofar + (p->left && !p->left->red), d_total);
  check_tree_recurse (p->right, d_sofar + (p->right && !p->right->red), d_total);
  if (p->left)
    {
      fprintf(stderr, "[intl/tsearch.c] enter check_tree_recurse 4\n");
      assert (!(p->left->red && p->red));
      fprintf(stderr, "[intl/tsearch.c] exit check_tree_recurse 4\n");
    }
  if (p->right)
    {
      fprintf(stderr, "[intl/tsearch.c] enter check_tree_recurse 5\n");
      assert (!(p->right->red && p->red));
      fprintf(stderr, "[intl/tsearch.c] exit check_tree_recurse 5\n");
    }
  fprintf(stderr, "[intl/tsearch.c] exit check_tree_recurse 3\n");
}

static void
check_tree (node root)
{
  fprintf(stderr, "[intl/tsearch.c] enter check_tree 1\n");
  int cnt = 0;
  node p;
  if (root == NULL)
    {
      fprintf(stderr, "[intl/tsearch.c] enter check_tree 2\n");
      return;
      fprintf(stderr, "[intl/tsearch.c] exit check_tree 2\n");
    }
  fprintf(stderr, "[intl/tsearch.c] exit check_tree 1\n");
  
  fprintf(stderr, "[intl/tsearch.c] enter check_tree 3\n");
  root->red = 0;
  for(p = root->left; p; p = p->left)
    cnt += !p->red;
  check_tree_recurse (root, 0, cnt);
  fprintf(stderr, "[intl/tsearch.c] exit check_tree 3\n");
}


#else

#define CHECK_TREE(a)

#endif

/* Possibly "split" a node with two red successors, and/or fix up two red
   edges in a row.  ROOTP is a pointer to the lowest node we visited, PARENTP
   and GPARENTP pointers to its parent/grandparent.  P_R and GP_R contain the
   comparison values that determined which way was taken in the tree to reach
   ROOTP.  MODE is 1 if we need not do the split, but must check for two red
   edges between GPARENTP and ROOTP.  */
static void
maybe_split_for_insert (node *rootp, node *parentp, node *gparentp,
			int p_r, int gp_r, int mode)
{
  fprintf(stderr, "[intl/tsearch.c] enter maybe_split_for_insert 1\n");
  node root = *rootp;
  node *rp, *lp;
  rp = &(*rootp)->right;
  lp = &(*rootp)->left;
  fprintf(stderr, "[intl/tsearch.c] exit maybe_split_for_insert 1\n");

  /* See if we have to split this node (both successors red).  */
  if (mode == 1
      || ((*rp) != NULL && (*lp) != NULL && (*rp)->red && (*lp)->red))
    {
      fprintf(stderr, "[intl/tsearch.c] enter maybe_split_for_insert 2\n");
      /* This node becomes red, its successors black.  */
      root->red = 1;
      if (*rp)
	(*rp)->red = 0;
      if (*lp)
	(*lp)->red = 0;
      fprintf(stderr, "[intl/tsearch.c] exit maybe_split_for_insert 2\n");

      /* If the parent of this node is also red, we have to do
	 rotations.  */
      if (parentp != NULL && (*parentp)->red)
	{
          fprintf(stderr, "[intl/tsearch.c] enter maybe_split_for_insert 3\n");
	  node gp = *gparentp;
	  node p = *parentp;
	  /* There are two main cases:
	     1. The edge types (left or right) of the two red edges differ.
	     2. Both red edges are of the same type.
	     There exist two symmetries of each case, so there is a total of
	     4 cases.  */
	  if ((p_r > 0) != (gp_r > 0))
	    {
              fprintf(stderr, "[intl/tsearch.c] enter maybe_split_for_insert 4\n");
	      /* Put the child at the top of the tree, with its parent
		 and grandparent as successors.  */
	      p->red = 1;
	      gp->red = 1;
	      root->red = 0;
	      if (p_r < 0)
		{
                  fprintf(stderr, "[intl/tsearch.c] enter maybe_split_for_insert 5\n");
		  /* Child is left of parent.  */
		  p->left = *rp;
		  *rp = p;
		  gp->right = *lp;
		  *lp = gp;
                  fprintf(stderr, "[intl/tsearch.c] exit maybe_split_for_insert 5\n");
		}
	      else
		{
                  fprintf(stderr, "[intl/tsearch.c] enter maybe_split_for_insert 6\n");
		  /* Child is right of parent.  */
		  p->right = *lp;
		  *lp = p;
		  gp->left = *rp;
		  *rp = gp;
                  fprintf(stderr, "[intl/tsearch.c] exit maybe_split_for_insert 6\n");
		}
	      *gparentp = root;
              fprintf(stderr, "[intl/tsearch.c] exit maybe_split_for_insert 4\n");
	    }
	  else
	    {
              fprintf(stderr, "[intl/tsearch.c] enter maybe_split_for_insert 7\n");
	      *gparentp = *parentp;
	      /* Parent becomes the top of the tree, grandparent and
		 child are its successors.  */
	      p->red = 0;
	      gp->red = 1;
	      if (p_r < 0)
		{
                  fprintf(stderr, "[intl/tsearch.c] enter maybe_split_for_insert 8\n");
		  /* Left edges.  */
		  gp->left = p->right;
		  p->right = gp;
                  fprintf(stderr, "[intl/tsearch.c] exit maybe_split_for_insert 8\n");
		}
	      else
		{
                  fprintf(stderr, "[intl/tsearch.c] enter maybe_split_for_insert 9\n");
		  /* Right edges.  */
		  gp->right = p->left;
		  p->left = gp;
                  fprintf(stderr, "[intl/tsearch.c] exit maybe_split_for_insert 9\n");
		}
              fprintf(stderr, "[intl/tsearch.c] exit maybe_split_for_insert 7\n");
	    }
          fprintf(stderr, "[intl/tsearch.c] exit maybe_split_for_insert 3\n");
	}
    }
}

/* Find or insert datum into search tree.
   KEY is the key to be located, ROOTP is the address of tree root,
   COMPAR the ordering function.  */
void *
__tsearch (const void *key, void **vrootp, __compar_fn_t compar)
{
  fprintf(stderr, "[intl/tsearch.c] enter __tsearch 1\n");
  node q;
  node *parentp = NULL, *gparentp = NULL;
  node *rootp = (node *) vrootp;
  node *nextp;
  int r = 0, p_r = 0, gp_r = 0; /* No they might not, Mr Compiler.  */
  fprintf(stderr, "[intl/tsearch.c] exit __tsearch 1\n");

  if (rootp == NULL)
    {
      fprintf(stderr, "[intl/tsearch.c] enter __tsearch 2\n");
      return NULL;
      fprintf(stderr, "[intl/tsearch.c] exit __tsearch 2\n");
    }

  /* This saves some additional tests below.  */
  if (*rootp != NULL)
    {
      fprintf(stderr, "[intl/tsearch.c] enter __tsearch 3\n");
      (*rootp)->red = 0;
      fprintf(stderr, "[intl/tsearch.c] exit __tsearch 3\n");
    }

  CHECK_TREE (*rootp);

  fprintf(stderr, "[intl/tsearch.c] enter __tsearch 4\n");
  nextp = rootp;
  fprintf(stderr, "[intl/tsearch.c] exit __tsearch 4\n");
  
  while (*nextp != NULL)
    {
      fprintf(stderr, "[intl/tsearch.c] enter __tsearch 5\n");
      node root = *rootp;
      r = (*compar) (key, root->key);
      if (r == 0)
        {
          fprintf(stderr, "[intl/tsearch.c] enter __tsearch 6\n");
	  return root;
          fprintf(stderr, "[intl/tsearch.c] exit __tsearch 6\n");
        }
      fprintf(stderr, "[intl/tsearch.c] exit __tsearch 5\n");

      fprintf(stderr, "[intl/tsearch.c] enter __tsearch 7\n");
      maybe_split_for_insert (rootp, parentp, gparentp, p_r, gp_r, 0);
      /* If that did any rotations, parentp and gparentp are now garbage.
	 That doesn't matter, because the values they contain are never
	 used again in that case.  */
      fprintf(stderr, "[intl/tsearch.c] exit __tsearch 7\n");

      fprintf(stderr, "[intl/tsearch.c] enter __tsearch 8\n");
      nextp = r < 0 ? &root->left : &root->right;
      if (*nextp == NULL)
        {
          fprintf(stderr, "[intl/tsearch.c] enter __tsearch 9\n");
	  break;
          fprintf(stderr, "[intl/tsearch.c] exit __tsearch 9\n");
        }
      fprintf(stderr, "[intl/tsearch.c] exit __tsearch 8\n");

      fprintf(stderr, "[intl/tsearch.c] enter __tsearch 10\n");
      gparentp = parentp;
      parentp = rootp;
      rootp = nextp;

      gp_r = p_r;
      p_r = r;
      fprintf(stderr, "[intl/tsearch.c] exit __tsearch 10\n");
    }

  fprintf(stderr, "[intl/tsearch.c] enter __tsearch 11\n");
  q = (struct node_t *) malloc (sizeof (struct node_t));
  fprintf(stderr, "[intl/tsearch.c] exit __tsearch 11\n");
  
  if (q != NULL)
    {
      fprintf(stderr, "[intl/tsearch.c] enter __tsearch 12\n");
      *nextp = q;			/* link new node to old */
      q->key = key;			/* initialize new node */
      q->red = 1;
      q->left = q->right = NULL;
      fprintf(stderr, "[intl/tsearch.c] exit __tsearch 12\n");

      if (nextp != rootp)
	{
          fprintf(stderr, "[intl/tsearch.c] enter __tsearch 13\n");
	  /* There may be two red edges in a row now, which we must avoid by
	     rotating the tree.  */
	  maybe_split_for_insert (nextp, rootp, parentp, r, p_r, 1);
          fprintf(stderr, "[intl/tsearch.c] exit __tsearch 13\n");
        }
    }

  fprintf(stderr, "[intl/tsearch.c] enter __tsearch 14\n");
  return q;
  fprintf(stderr, "[intl/tsearch.c] exit __tsearch 14\n");
}
#ifdef weak_alias
weak_alias (__tsearch, tsearch)
#endif


/* Find datum in search tree.
   KEY is the key to be located, ROOTP is the address of tree root,
   COMPAR the ordering function.  */
void *
__tfind (key, vrootp, compar)
     const void *key;
     void *const *vrootp;
     __compar_fn_t compar;
{
  fprintf(stderr, "[intl/tsearch.c] enter __tfind 1\n");
  node *rootp = (node *) vrootp;
  fprintf(stderr, "[intl/tsearch.c] exit __tfind 1\n");

  if (rootp == NULL)
    {
      fprintf(stderr, "[intl/tsearch.c] enter __tfind 2\n");
      return NULL;
      fprintf(stderr, "[intl/tsearch.c] exit __tfind 2\n");
    }

  CHECK_TREE (*rootp);

  while (*rootp != NULL)
    {
      fprintf(stderr, "[intl/tsearch.c] enter __tfind 3\n");
      node root = *rootp;
      int r;
      fprintf(stderr, "[intl/tsearch.c] exit __tfind 3\n");

      fprintf(stderr, "[intl/tsearch.c] enter __tfind 4\n");
      r = (*compar) (key, root->key);
      if (r == 0)
        {
          fprintf(stderr, "[intl/tsearch.c] enter __tfind 5\n");
	  return root;
          fprintf(stderr, "[intl/tsearch.c] exit __tfind 5\n");
        }
      fprintf(stderr, "[intl/tsearch.c] exit __tfind 4\n");

      fprintf(stderr, "[intl/tsearch.c] enter __tfind 6\n");
      rootp = r < 0 ? &root->left : &root->right;
      fprintf(stderr, "[intl/tsearch.c] exit __tfind 6\n");
    }
  
  fprintf(stderr, "[intl/tsearch.c] enter __tfind 7\n");
  return NULL;
  fprintf(stderr, "[intl/tsearch.c] exit __tfind 7\n");
}
#ifdef weak_alias
weak_alias (__tfind, tfind)
#endif


/* Delete node with given key.
   KEY is the key to be deleted, ROOTP is the address of the root of tree,
   COMPAR the comparison function.  */
void *
__tdelete (const void *key, void **vrootp, __compar_fn_t compar)
{
  fprintf(stderr, "[intl/tsearch.c] enter __tdelete 1\n");
  node p, q, r, retval;
  int cmp;
  node *rootp = (node *) vrootp;
  node root, unchained;
  /* Stack of nodes so we remember the parents without recursion.  It's
     _very_ unlikely that there are paths longer than 40 nodes.  The tree
     would need to have around 250.000 nodes.  */
  int stacksize = 100;
  int sp = 0;
  node *nodestack[100];
  fprintf(stderr, "[intl/tsearch.c] exit __tdelete 1\n");

  if (rootp == NULL)
    {
      fprintf(stderr, "[intl/tsearch.c] enter __tdelete 2\n");
      return NULL;
      fprintf(stderr, "[intl/tsearch.c] exit __tdelete 2\n");
    }
  
  fprintf(stderr, "[intl/tsearch.c] enter __tdelete 3\n");
  p = *rootp;
  fprintf(stderr, "[intl/tsearch.c] exit __tdelete 3\n");
  
  if (p == NULL)
    {
      fprintf(stderr, "[intl/tsearch.c] enter __tdelete 4\n");
      return NULL;
      fprintf(stderr, "[intl/tsearch.c] exit __tdelete 4\n");
    }

  CHECK_TREE (p);

  while ((cmp = (*compar) (key, (*rootp)->key)) != 0)
    {
      fprintf(stderr, "[intl/tsearch.c] enter __tdelete 5\n");
      if (sp == stacksize)
        {
          fprintf(stderr, "[intl/tsearch.c] enter __tdelete 6\n");
	  abort ();
          fprintf(stderr, "[intl/tsearch.c] exit __tdelete 6\n");
        }
      fprintf(stderr, "[intl/tsearch.c] exit __tdelete 5\n");

      fprintf(stderr, "[intl/tsearch.c] enter __tdelete 7\n");
      nodestack[sp++] = rootp;
      p = *rootp;
      rootp = ((cmp < 0)
	       ? &(*rootp)->left
	       : &(*rootp)->right);
      if (*rootp == NULL)
        {
          fprintf(stderr, "[intl/tsearch.c] enter __tdelete 8\n");
	  return NULL;
          fprintf(stderr, "[intl/tsearch.c] exit __tdelete 8\n");
        }
      fprintf(stderr, "[intl/tsearch.c] exit __tdelete 7\n");
    }

  /* This is bogus if the node to be deleted is the root... this routine
     really should return an integer with 0 for success, -1 for failure
     and errno = ESRCH or something.  */
  fprintf(stderr, "[intl/tsearch.c] enter __tdelete 9\n");
  retval = p;
  fprintf(stderr, "[intl/tsearch.c] exit __tdelete 9\n");

  /* We don't unchain the node we want to delete. Instead, we overwrite
     it with its successor and unchain the successor.  If there is no
     successor, we really unchain the node to be deleted.  */

  fprintf(stderr, "[intl/tsearch.c] enter __tdelete 10\n");
  root = *rootp;
  fprintf(stderr, "[intl/tsearch.c] exit __tdelete 10\n");

  fprintf(stderr, "[intl/tsearch.c] enter __tdelete 11\n");
  r = root->right;
  q = root->left;
  fprintf(stderr, "[intl/tsearch.c] exit __tdelete 11\n");

  if (q == NULL || r == NULL)
    {
      fprintf(stderr, "[intl/tsearch.c] enter __tdelete 12\n");
      unchained = root;
      fprintf(stderr, "[intl/tsearch.c] exit __tdelete 12\n");
    }
  else
    {
      fprintf(stderr, "[intl/tsearch.c] enter __tdelete 13\n");
      node *parent = rootp, *up = &root->right;
      fprintf(stderr, "[intl/tsearch.c] exit __tdelete 13\n");
      
      for (;;)
	{
          fprintf(stderr, "[intl/tsearch.c] enter __tdelete 14\n");
	  if (sp == stacksize)
            {
              fprintf(stderr, "[intl/tsearch.c] enter __tdelete 15\n");
	      abort ();
              fprintf(stderr, "[intl/tsearch.c] exit __tdelete 15\n");
            }
          fprintf(stderr, "[intl/tsearch.c] exit __tdelete 14\n");
          
          fprintf(stderr, "[intl/tsearch.c] enter __tdelete 16\n");
	  nodestack[sp++] = parent;
	  parent = up;
	  if ((*up)->left == NULL)
            {
              fprintf(stderr, "[intl/tsearch.c] enter __tdelete 17\n");
	      break;
              fprintf(stderr, "[intl/tsearch.c] exit __tdelete 17\n");
            }
	  up = &(*up)->left;
          fprintf(stderr, "[intl/tsearch.c] exit __tdelete 16\n");
	}
      
      fprintf(stderr, "[intl/tsearch.c] enter __tdelete 18\n");
      unchained = *up;
      fprintf(stderr, "[intl/tsearch.c] exit __tdelete 18\n");
    }

  /* We know that either the left or right successor of UNCHAINED is NULL.
     R becomes the other one, it is chained into the parent of UNCHAINED.  */
  fprintf(stderr, "[intl/tsearch.c] enter __tdelete 19\n");
  r = unchained->left;
  if (r == NULL)
    {
      fprintf(stderr, "[intl/tsearch.c] enter __tdelete 20\n");
      r = unchained->right;
      fprintf(stderr, "[intl/tsearch.c] exit __tdelete 20\n");
    }
  fprintf(stderr, "[intl/tsearch.c] exit __tdelete 19\n");
  
  fprintf(stderr, "[intl/tsearch.c] enter __tdelete 21\n");
  if (sp == 0)
    {
      fprintf(stderr, "[intl/tsearch.c] enter __tdelete 22\n");
      *rootp = r;
      fprintf(stderr, "[intl/tsearch.c] exit __tdelete 22\n");
    }
  else
    {
      fprintf(stderr, "[intl/tsearch.c] enter __tdelete 23\n");
      q = *nodestack[sp-1];
      if (unchained == q->right)
        {
          fprintf(stderr, "[intl/tsearch.c] enter __tdelete 24\n");
	  q->right = r;
          fprintf(stderr, "[intl/tsearch.c] exit __tdelete 24\n");
        }
      else
        {
          fprintf(stderr, "[intl/tsearch.c] enter __tdelete 25\n");
	  q->left = r;
          fprintf(stderr, "[intl/tsearch.c] exit __tdelete 25\n");
        }
      fprintf(stderr, "[intl/tsearch.c] exit __tdelete 23\n");
    }
  fprintf(stderr, "[intl/tsearch.c] exit __tdelete 21\n");

  fprintf(stderr, "[intl/tsearch.c] enter __tdelete 26\n");
  if (unchained != root)
    {
      fprintf(stderr, "[intl/tsearch.c] enter __tdelete 27\n");
      root->key = unchained->key;
      fprintf(stderr, "[intl/tsearch.c] exit __tdelete 27\n");
    }
  fprintf(stderr, "[intl/tsearch.c] exit __tdelete 26\n");
  
  fprintf(stderr, "[intl/tsearch.c] enter __tdelete 28\n");
  if (!unchained->red)
    {
      fprintf(stderr, "[intl/tsearch.c] enter __tdelete 29\n");
      /* Now we lost a black edge, which means that the number of black
	 edges on every path is no longer constant.  We must balance the
	 tree.  */
      /* NODESTACK now contains all parents of R.  R is likely to be NULL
	 in the first iteration.  */
      /* NULL nodes are considered black throughout - this is necessary for
	 correctness.  */
      while (sp > 0 && (r == NULL || !r->red))
	{
          fprintf(stderr, "[intl/tsearch.c] enter __tdelete 30\n");
	  node *pp = nodestack[sp - 1];
	  p = *pp;
	  /* Two symmetric cases.  */
	  if (r == p->left)
	    {
              fprintf(stderr, "[intl/tsearch.c] enter __tdelete 31\n");
	      /* Q is R's brother, P is R's parent.  The subtree with root
		 R has one black edge less than the subtree with root Q.  */
	      q = p->right;
	      if (q->red)
		{
                  fprintf(stderr, "[intl/tsearch.c] enter __tdelete 32\n");
		  /* If Q is red, we know that P is black. We rotate P left
		     so that Q becomes the top node in the tree, with P below
		     it.  P is colored red, Q is colored black.
		     This action does not change the black edge count for any
		     leaf in the tree, but we will be able to recognize one
		     of the following situations, which all require that Q
		     is black.  */
		  q->red = 0;
		  p->red = 1;
		  /* Left rotate p.  */
		  p->right = q->left;
		  q->left = p;
		  *pp = q;
		  /* Make sure pp is right if the case below tries to use
		     it.  */
		  nodestack[sp++] = pp = &q->left;
		  q = p->right;
                  fprintf(stderr, "[intl/tsearch.c] exit __tdelete 32\n");
		}
              fprintf(stderr, "[intl/tsearch.c] exit __tdelete 31\n");
              
	      /* We know that Q can't be NULL here.  We also know that Q is
		 black.  */
              fprintf(stderr, "[intl/tsearch.c] enter __tdelete 33\n");
	      if ((q->left == NULL || !q->left->red)
		  && (q->right == NULL || !q->right->red))
		{
                  fprintf(stderr, "[intl/tsearch.c] enter __tdelete 34\n");
		  /* Q has two black successors.  We can simply color Q red.
		     The whole subtree with root P is now missing one black
		     edge.  Note that this action can temporarily make the
		     tree invalid (if P is red).  But we will exit the loop
		     in that case and set P black, which both makes the tree
		     valid and also makes the black edge count come out
		     right.  If P is black, we are at least one step closer
		     to the root and we'll try again the next iteration.  */
		  q->red = 1;
		  r = p;
                  fprintf(stderr, "[intl/tsearch.c] exit __tdelete 34\n");
		}
	      else
		{
                  fprintf(stderr, "[intl/tsearch.c] enter __tdelete 35\n");
		  /* Q is black, one of Q's successors is red.  We can
		     repair the tree with one operation and will exit the
		     loop afterwards.  */
		  if (q->right == NULL || !q->right->red)
		    {
                      fprintf(stderr, "[intl/tsearch.c] enter __tdelete 36\n");
		      /* The left one is red.  We perform the same action as
			 in maybe_split_for_insert where two red edges are
			 adjacent but point in different directions:
			 Q's left successor (let's call it Q2) becomes the
			 top of the subtree we are looking at, its parent (Q)
			 and grandparent (P) become its successors. The former
			 successors of Q2 are placed below P and Q.
			 P becomes black, and Q2 gets the color that P had.
			 This changes the black edge count only for node R and
			 its successors.  */
		      node q2 = q->left;
		      q2->red = p->red;
		      p->right = q2->left;
		      q->left = q2->right;
		      q2->right = q;
		      q2->left = p;
		      *pp = q2;
		      p->red = 0;
                      fprintf(stderr, "[intl/tsearch.c] exit __tdelete 36\n");
		    }
		  else
		    {
                      fprintf(stderr, "[intl/tsearch.c] enter __tdelete 37\n");
		      /* It's the right one.  Rotate P left. P becomes black,
			 and Q gets the color that P had.  Q's right successor
			 also becomes black.  This changes the black edge
			 count only for node R and its successors.  */
		      q->red = p->red;
		      p->red = 0;

		      q->right->red = 0;

		      /* left rotate p */
		      p->right = q->left;
		      q->left = p;
		      *pp = q;
                      fprintf(stderr, "[intl/tsearch.c] exit __tdelete 37\n");
		    }
                  fprintf(stderr, "[intl/tsearch.c] exit __tdelete 35\n");

		  /* We're done.  */
                  fprintf(stderr, "[intl/tsearch.c] enter __tdelete 38\n");
		  sp = 1;
		  r = NULL;
                  fprintf(stderr, "[intl/tsearch.c] exit __tdelete 38\n");
		}
              fprintf(stderr, "[intl/tsearch.c] exit __tdelete 33\n");
	    }
	  else
	    {
              fprintf(stderr, "[intl/tsearch.c] enter __tdelete 39\n");
	      /* Comments: see above.  */
	      q = p->left;
	      if (q->red)
		{
                  fprintf(stderr, "[intl/tsearch.c] enter __tdelete 40\n");
		  q->red = 0;
		  p->red = 1;
		  p->left = q->right;
		  q->right = p;
		  *pp = q;
		  nodestack[sp++] = pp = &q->right;
		  q = p->left;
                  fprintf(stderr, "[intl/tsearch.c] exit __tdelete 40\n");
		}
              fprintf(stderr, "[intl/tsearch.c] exit __tdelete 39\n");
              
              fprintf(stderr, "[intl/tsearch.c] enter __tdelete 41\n");
	      if ((q->right == NULL || !q->right->red)
		       && (q->left == NULL || !q->left->red))
		{
                  fprintf(stderr, "[intl/tsearch.c] enter __tdelete 42\n");
		  q->red = 1;
		  r = p;
                  fprintf(stderr, "[intl/tsearch.c] exit __tdelete 42\n");
		}
	      else
		{
                  fprintf(stderr, "[intl/tsearch.c] enter __tdelete 43\n");
		  if (q->left == NULL || !q->left->red)
		    {
                      fprintf(stderr, "[intl/tsearch.c] enter __tdelete 44\n");
		      node q2 = q->right;
		      q2->red = p->red;
		      p->left = q2->right;
		      q->right = q2->left;
		      q2->left = q;
		      q2->right = p;
		      *pp = q2;
		      p->red = 0;
                      fprintf(stderr, "[intl/tsearch.c] exit __tdelete 44\n");
		    }
		  else
		    {
                      fprintf(stderr, "[intl/tsearch.c] enter __tdelete 45\n");
		      q->red = p->red;
		      p->red = 0;
		      q->left->red = 0;
		      p->left = q->right;
		      q->right = p;
		      *pp = q;
                      fprintf(stderr, "[intl/tsearch.c] exit __tdelete 45\n");
		    }
                  fprintf(stderr, "[intl/tsearch.c] exit __tdelete 43\n");
                  
                  fprintf(stderr, "[intl/tsearch.c] enter __tdelete 46\n");
		  sp = 1;
		  r = NULL;
                  fprintf(stderr, "[intl/tsearch.c] exit __tdelete 46\n");
		}
              fprintf(stderr, "[intl/tsearch.c] exit __tdelete 41\n");
	    }
          fprintf(stderr, "[intl/tsearch.c] exit __tdelete 30\n");
          
          fprintf(stderr, "[intl/tsearch.c] enter __tdelete 47\n");
	  --sp;
          fprintf(stderr, "[intl/tsearch.c] exit __tdelete 47\n");
	}
      
      fprintf(stderr, "[intl/tsearch.c] enter __tdelete 48\n");
      if (r != NULL)
        {
          fprintf(stderr, "[intl/tsearch.c] enter __tdelete 49\n");
	  r->red = 0;
          fprintf(stderr, "[intl/tsearch.c] exit __tdelete 49\n");
        }
      fprintf(stderr, "[intl/tsearch.c] exit __tdelete 48\n");
    }
  fprintf(stderr, "[intl/tsearch.c] exit __tdelete 29\n");
  fprintf(stderr, "[intl/tsearch.c] exit __tdelete 28\n");

  fprintf(stderr, "[intl/tsearch.c] enter __tdelete 50\n");
  free (unchained);
  return retval;
  fprintf(stderr, "[intl/tsearch.c] exit __tdelete 50\n");
}
#ifdef weak_alias
weak_alias (__tdelete, tdelete)
#endif


/* Walk the nodes of a tree.
   ROOT is the root of the tree to be walked, ACTION the function to be
   called at each node.  LEVEL is the level of ROOT in the whole tree.  */
static void
internal_function
trecurse (const void *vroot, __action_fn_t action, int level)
{
  fprintf(stderr, "[intl/tsearch.c] enter trecurse 1\n");
  const_node root = (const_node) vroot;
  fprintf(stderr, "[intl/tsearch.c] exit trecurse 1\n");

  if (root->left == NULL && root->right == NULL)
    {
      fprintf(stderr, "[intl/tsearch.c] enter trecurse 2\n");
      (*action) (root, leaf, level);
      fprintf(stderr, "[intl/tsearch.c] exit trecurse 2\n");
    }
  else
    {
      fprintf(stderr, "[intl/tsearch.c] enter trecurse 3\n");
      (*action) (root, preorder, level);
      fprintf(stderr, "[intl/tsearch.c] exit trecurse 3\n");
      
      if (root->left != NULL)
	{
          fprintf(stderr, "[intl/tsearch.c] enter trecurse 4\n");
	  trecurse (root->left, action, level + 1);
          fprintf(stderr, "[intl/tsearch.c] exit trecurse 4\n");
        }
      
      fprintf(stderr, "[intl/tsearch.c] enter trecurse 5\n");
      (*action) (root, postorder, level);
      fprintf(stderr, "[intl/tsearch.c] exit trecurse 5\n");
      
      if (root->right != NULL)
	{
          fprintf(stderr, "[intl/tsearch.c] enter trecurse 6\n");
	  trecurse (root->right, action, level + 1);
          fprintf(stderr, "[intl/tsearch.c] exit trecurse 6\n");
        }
      
      fprintf(stderr, "[intl/tsearch.c] enter trecurse 7\n");
      (*action) (root, endorder, level);
      fprintf(stderr, "[intl/tsearch.c] exit trecurse 7\n");
    }
}


/* Walk the nodes of a tree.
   ROOT is the root of the tree to be walked, ACTION the function to be
   called at each node.  */
void
__twalk (const void *vroot, __action_fn_t action)
{
  fprintf(stderr, "[intl/tsearch.c] enter __twalk 1\n");
  const_node root = (const_node) vroot;
  fprintf(stderr, "[intl/tsearch.c] exit __twalk 1\n");

  CHECK_TREE (root);

  if (root != NULL && action != NULL)
    {
      fprintf(stderr, "[intl/tsearch.c] enter __twalk 2\n");
      trecurse (root, action, 0);
      fprintf(stderr, "[intl/tsearch.c] exit __twalk 2\n");
    }
}
#ifdef weak_alias
weak_alias (__twalk, twalk)
#endif


#ifdef _LIBC

/* The standardized functions miss an important functionality: the
   tree cannot be removed easily.  We provide a function to do this.  */
static void
internal_function
tdestroy_recurse (node root, __free_fn_t freefct)
{
  fprintf(stderr, "[intl/tsearch.c] enter tdestroy_recurse 1\n");
  if (root->left != NULL)
    {
      fprintf(stderr, "[intl/tsearch.c] enter tdestroy_recurse 2\n");
      tdestroy_recurse (root->left, freefct);
      fprintf(stderr, "[intl/tsearch.c] exit tdestroy_recurse 2\n");
    }
  fprintf(stderr, "[intl/tsearch.c] exit tdestroy_recurse 1\n");
  
  fprintf(stderr, "[intl/tsearch.c] enter tdestroy_recurse 3\n");
  if (root->right != NULL)
    {
      fprintf(stderr, "[intl/tsearch.c] enter tdestroy_recurse 4\n");
      tdestroy_recurse (root->right, freefct);
      fprintf(stderr, "[intl/tsearch.c] exit tdestroy_recurse 4\n");
    }
  fprintf(stderr, "[intl/tsearch.c] exit tdestroy_recurse 3\n");
  
  fprintf(stderr, "[intl/tsearch.c] enter tdestroy_recurse 5\n");
  (*freefct) ((void *) root->key);
  /* Free the node itself.  */
  free (root);
  fprintf(stderr, "[intl/tsearch.c] exit tdestroy_recurse 5\n");
}

void
__tdestroy (void *vroot, __free_fn_t freefct)
{
  fprintf(stderr, "[intl/tsearch.c] enter __tdestroy 1\n");
  node root = (node) vroot;
  fprintf(stderr, "[intl/tsearch.c] exit __tdestroy 1\n");

  CHECK_TREE (root);

  if (root != NULL)
    {
      fprintf(stderr, "[intl/tsearch.c] enter __tdestroy 2\n");
      tdestroy_recurse (root, freefct);
      fprintf(stderr, "[intl/tsearch.c] exit __tdestroy 2\n");
    }
}
weak_alias (__tdestroy, tdestroy)

#endif /* _LIBC */
// Total cost: 0.431313
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 684)]
// Total instrumented cost: 0.431313, input tokens: 28151, output tokens: 20866, cache read tokens: 11111, cache write tokens: 17032

#ifndef VORBIS_TOOLS_I18N_H
#define VORBIS_TOOLS_I18N_H

#ifdef ENABLE_NLS
#include <libintl.h>
#define _(X) gettext(X)
#else
#define _(X) (X)
#define textdomain(X)
#define bindtextdomain(X, Y)
#endif
#ifdef gettext_noop
#define N_(X) gettext_noop(X)
#else
#define N_(X) (X)
#endif

#endif
// Total cost: 0.002431
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 18)]
// Total instrumented cost: 0.002431, input tokens: 2490, output tokens: 23, cache read tokens: 2280, cache write tokens: 206


/*
 * Convert a string between UTF-8 and the locale's charset.
 * Invalid bytes are replaced by '#', and characters that are
 * not available in the target encoding are replaced by '?'.
 *
 * If the locale's charset is not set explicitly then it is
 * obtained using nl_langinfo(CODESET), where available, the
 * environment variable CHARSET, or assumed to be US-ASCII.
 *
 * Return value of conversion functions:
 *
 *  -1 : memory allocation failed
 *   0 : data was converted exactly
 *   1 : valid data was converted approximately (using '?')
 *   2 : input was invalid (but still converted, using '#')
 *   3 : unknown encoding (but still converted, using '?')
 */

#ifndef __UTF8_H
#define __UTF8_H

#ifdef	__cplusplus
extern "C" {
#endif

void convert_set_charset(const char *charset);
void convert_free_charset(void);

int utf8_encode(const char *from, char **to);
int utf8_decode(const char *from, char **to);
int utf8_validate(const char *from);

#ifdef	__cplusplus
}
#endif

#endif /* __UTF8_H */
// Total cost: 0.003599
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 38)]
// Total instrumented cost: 0.003599, input tokens: 2663, output tokens: 23, cache read tokens: 2280, cache write tokens: 379

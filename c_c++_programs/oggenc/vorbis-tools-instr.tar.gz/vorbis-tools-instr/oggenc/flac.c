/* OggEnc
 **
 ** This program is distributed under the GNU General Public License, version 2.
 ** A copy of this license is included with this source.
 **
 ** Copyright 2002, Stan Seibert <volsung@xiph.org>
 **
 **/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <math.h>
#include <FLAC/metadata.h>
#include "audio.h"
#include "flac.h"
#include "i18n.h"
#include "platform.h"
#include "resample.h"

#if !defined(FLAC_API_VERSION_CURRENT) || (FLAC_API_VERSION_CURRENT < 8)
#define NEED_EASYFLAC 1
#endif

#if NEED_EASYFLAC
static FLAC__StreamDecoderReadStatus easyflac_read_callback(const EasyFLAC__StreamDecoder *decoder, FLAC__byte buffer[], unsigned *bytes, void *client_data);
static FLAC__StreamDecoderWriteStatus easyflac_write_callback(const EasyFLAC__StreamDecoder *decoder, const FLAC__Frame *frame, const FLAC__int32 * const buffer[], void *client_data);
static void easyflac_metadata_callback(const EasyFLAC__StreamDecoder *decoder, const FLAC__StreamMetadata *metadata, void *client_data);
static void easyflac_error_callback(const EasyFLAC__StreamDecoder *decoder, FLAC__StreamDecoderErrorStatus status, void *client_data);
#else
static FLAC__StreamDecoderReadStatus read_callback(const FLAC__StreamDecoder *decoder, FLAC__byte buffer[], size_t *bytes, void *client_data);
static FLAC__StreamDecoderWriteStatus write_callback(const FLAC__StreamDecoder *decoder, const FLAC__Frame *frame, const FLAC__int32 * const buffer[], void *client_data);
static void metadata_callback(const FLAC__StreamDecoder *decoder, const FLAC__StreamMetadata *metadata, void *client_data);
static void error_callback(const FLAC__StreamDecoder *decoder, FLAC__StreamDecoderErrorStatus status, void *client_data);
static FLAC__bool eof_callback(const FLAC__StreamDecoder *decoder, void *client_data);
#endif

static void resize_buffer(flacfile *flac, int newchannels, int newsamples);
static void copy_comments (vorbis_comment *v_comments, FLAC__StreamMetadata_VorbisComment *f_comments);


int flac_id(unsigned char *buf, int len)
{
    fprintf(stderr, "[oggenc/flac.c] enter flac_id 1\n");
    if (len < 4) return 0;
    fprintf(stderr, "[oggenc/flac.c] exit flac_id 1\n");

    fprintf(stderr, "[oggenc/flac.c] enter flac_id 2\n");
    return memcmp(buf, "fLaC", 4) == 0;
    fprintf(stderr, "[oggenc/flac.c] exit flac_id 2\n");
}


int oggflac_id(unsigned char *buf, int len)
{
    fprintf(stderr, "[oggenc/flac.c] enter oggflac_id 1\n");
    if (len < 33) return 0;
    fprintf(stderr, "[oggenc/flac.c] exit oggflac_id 1\n");

    fprintf(stderr, "[oggenc/flac.c] enter oggflac_id 2\n");
    return memcmp(buf, "OggS", 4) == 0 &&
	   (memcmp (buf+28, "\177FLAC", 5) == 0 || flac_id(buf+28, len - 28));
    fprintf(stderr, "[oggenc/flac.c] exit oggflac_id 2\n");
}


int flac_open(FILE *in, oe_enc_opt *opt, unsigned char *oldbuf, int buflen)
{
    fprintf(stderr, "[oggenc/flac.c] enter flac_open 1\n");
    flacfile *flac = malloc(sizeof(flacfile));

    flac->decoder = NULL;
    flac->channels = 0;
    flac->rate = 0;
    flac->totalsamples = 0;
    flac->comments = NULL;
    flac->in = NULL;
    flac->eos = 0;

    /* Setup empty audio buffer that will be resized on first frame 
       callback */
    flac->buf = NULL;
    flac->buf_len = 0;
    flac->buf_start = 0;
    flac->buf_fill = 0;

    /* Copy old input data over */
    flac->oldbuf = malloc(buflen);
    flac->oldbuf_len = buflen;
    memcpy(flac->oldbuf, oldbuf, buflen);
    flac->oldbuf_start = 0;

    /* Need to save FILE pointer for read callback */
    flac->in = in;
    fprintf(stderr, "[oggenc/flac.c] exit flac_open 1\n");

    /* Setup FLAC decoder */
#if NEED_EASYFLAC
    fprintf(stderr, "[oggenc/flac.c] enter flac_open 2\n");
    flac->decoder = EasyFLAC__stream_decoder_new(oggflac_id(oldbuf, buflen));
    EasyFLAC__set_client_data(flac->decoder, flac);
    EasyFLAC__set_read_callback(flac->decoder, &easyflac_read_callback);
    EasyFLAC__set_write_callback(flac->decoder, &easyflac_write_callback);
    EasyFLAC__set_metadata_callback(flac->decoder, &easyflac_metadata_callback);
    EasyFLAC__set_error_callback(flac->decoder, &easyflac_error_callback);
    EasyFLAC__set_metadata_respond(flac->decoder, FLAC__METADATA_TYPE_STREAMINFO);
    EasyFLAC__set_metadata_respond(flac->decoder, FLAC__METADATA_TYPE_VORBIS_COMMENT);
    EasyFLAC__init(flac->decoder);
    fprintf(stderr, "[oggenc/flac.c] exit flac_open 2\n");
#else
    fprintf(stderr, "[oggenc/flac.c] enter flac_open 3\n");
    flac->decoder = FLAC__stream_decoder_new();
    FLAC__stream_decoder_set_md5_checking(flac->decoder, false);
    FLAC__stream_decoder_set_metadata_respond(flac->decoder, FLAC__METADATA_TYPE_STREAMINFO);
    FLAC__stream_decoder_set_metadata_respond(flac->decoder, FLAC__METADATA_TYPE_VORBIS_COMMENT);
    if(oggflac_id(oldbuf, buflen))
        FLAC__stream_decoder_init_ogg_stream(flac->decoder, read_callback, /*seek_callback=*/0, /*tell_callback=*/0, /*length_callback=*/0, eof_callback, write_callback, metadata_callback, error_callback, flac);
    else
        FLAC__stream_decoder_init_stream(flac->decoder, read_callback, /*seek_callback=*/0, /*tell_callback=*/0, /*length_callback=*/0, eof_callback, write_callback, metadata_callback, error_callback, flac);
    fprintf(stderr, "[oggenc/flac.c] exit flac_open 3\n");
#endif

    /* Callback will set the total samples and sample rate */
#if NEED_EASYFLAC
    fprintf(stderr, "[oggenc/flac.c] enter flac_open 4\n");
    EasyFLAC__process_until_end_of_metadata(flac->decoder);
    fprintf(stderr, "[oggenc/flac.c] exit flac_open 4\n");
#else
    fprintf(stderr, "[oggenc/flac.c] enter flac_open 5\n");
    FLAC__stream_decoder_process_until_end_of_metadata(flac->decoder);
    fprintf(stderr, "[oggenc/flac.c] exit flac_open 5\n");
#endif

    /* Callback will set the number of channels and resize the 
       audio buffer */
#if NEED_EASYFLAC
    fprintf(stderr, "[oggenc/flac.c] enter flac_open 6\n");
    EasyFLAC__process_single(flac->decoder);
    fprintf(stderr, "[oggenc/flac.c] exit flac_open 6\n");
#else
    fprintf(stderr, "[oggenc/flac.c] enter flac_open 7\n");
    FLAC__stream_decoder_process_single(flac->decoder);
    fprintf(stderr, "[oggenc/flac.c] exit flac_open 7\n");
#endif

    /* Copy format info for caller */
    fprintf(stderr, "[oggenc/flac.c] enter flac_open 8\n");
    opt->rate = flac->rate;
    opt->channels = flac->channels;
    /* flac->total_samples_per_channel was already set by metadata
       callback when metadata was processed. */
    opt->total_samples_per_channel = flac->totalsamples;
    /* Copy Vorbis-style comments from FLAC file (read in metadata 
       callback)*/
    if (flac->comments != NULL && opt->copy_comments)
        copy_comments(opt->comments, &flac->comments->data.vorbis_comment);
    opt->read_samples = flac_read;
    opt->readdata = (void *)flac;

    return 1;
    fprintf(stderr, "[oggenc/flac.c] exit flac_open 8\n");
}

/* FLAC follows the WAV channel ordering pattern; we must permute to
   put things in Vorbis channel order */
static int wav_permute_matrix[8][8] = 
{
  {0},              /* 1.0 mono   */
  {0,1},            /* 2.0 stereo */
  {0,2,1},          /* 3.0 channel ('wide') stereo */
  {0,1,2,3},        /* 4.0 discrete quadraphonic */
  {0,2,1,3,4},      /* 5.0 surround */
  {0,2,1,4,5,3},    /* 5.1 surround */
  {0,2,1,5,6,4,3},  /* 6.1 surround */
  {0,2,1,6,7,4,5,3} /* 7.1 surround (classic theater 8-track) */
};

long flac_read(void *in, float **buffer, int samples)
{
    fprintf(stderr, "[oggenc/flac.c] enter flac_read 1\n");
    flacfile *flac = (flacfile *)in;
    long realsamples = 0;
    FLAC__bool ret;
    int i,j;
    fprintf(stderr, "[oggenc/flac.c] exit flac_read 1\n");
    
    while (realsamples < samples)
    {
        fprintf(stderr, "[oggenc/flac.c] enter flac_read 2\n");
        if (flac->buf_fill > 0)
        {
            fprintf(stderr, "[oggenc/flac.c] enter flac_read 3\n");
            int copy = flac->buf_fill < (samples - realsamples) ?
                flac->buf_fill : (samples - realsamples);

            for (i = 0; i < flac->channels; i++){
              int permute = wav_permute_matrix[flac->channels-1][i];
                for (j = 0; j < copy; j++)
                    buffer[i][j+realsamples] =
                        flac->buf[permute][j+flac->buf_start];
            }
            flac->buf_start += copy;
            flac->buf_fill -= copy;
            realsamples += copy;
            fprintf(stderr, "[oggenc/flac.c] exit flac_read 3\n");
        }
        else if (!flac->eos)
        {
            fprintf(stderr, "[oggenc/flac.c] enter flac_read 4\n");
#if NEED_EASYFLAC
            ret = EasyFLAC__process_single(flac->decoder);
            if (!ret ||
                EasyFLAC__get_state(flac->decoder)
                == FLAC__STREAM_DECODER_END_OF_STREAM)
                flac->eos = 1;  /* Bail out! */
#else
            ret = FLAC__stream_decoder_process_single(flac->decoder);
            if (!ret ||
                FLAC__stream_decoder_get_state(flac->decoder)
                == FLAC__STREAM_DECODER_END_OF_STREAM)
                flac->eos = 1;  /* Bail out! */
#endif
            fprintf(stderr, "[oggenc/flac.c] exit flac_read 4\n");
        } else
        {
            fprintf(stderr, "[oggenc/flac.c] enter flac_read 5\n");
            break;
            fprintf(stderr, "[oggenc/flac.c] exit flac_read 5\n");
        }
        fprintf(stderr, "[oggenc/flac.c] exit flac_read 2\n");
    }

    fprintf(stderr, "[oggenc/flac.c] enter flac_read 6\n");
    return realsamples;
    fprintf(stderr, "[oggenc/flac.c] exit flac_read 6\n");
}

void flac_close(void *info)
{
    fprintf(stderr, "[oggenc/flac.c] enter flac_close 1\n");
    int i;
    flacfile *flac =  (flacfile *) info;

    for (i = 0; i < flac->channels; i++)
        free(flac->buf[i]);

    free(flac->buf);
    free(flac->oldbuf);
    free(flac->comments);
#if NEED_EASYFLAC
    EasyFLAC__finish(flac->decoder);
    EasyFLAC__stream_decoder_delete(flac->decoder);
#else
    FLAC__stream_decoder_finish(flac->decoder);
    FLAC__stream_decoder_delete(flac->decoder);
#endif
    free(flac);
    fprintf(stderr, "[oggenc/flac.c] exit flac_close 1\n");
}

#if NEED_EASYFLAC
FLAC__StreamDecoderReadStatus easyflac_read_callback(const EasyFLAC__StreamDecoder *decoder, FLAC__byte buffer[], unsigned *bytes, void *client_data)
#else
FLAC__StreamDecoderReadStatus read_callback(const FLAC__StreamDecoder *decoder, FLAC__byte buffer[], size_t *bytes, void *client_data)
#endif
{
    fprintf(stderr, "[oggenc/flac.c] enter read_callback 1\n");
    flacfile *flac = (flacfile *) client_data;
    int i = 0;
    int oldbuf_fill = flac->oldbuf_len - flac->oldbuf_start;
    fprintf(stderr, "[oggenc/flac.c] exit read_callback 1\n");

    /* Immediately return if errors occured */
    fprintf(stderr, "[oggenc/flac.c] enter read_callback 2\n");
    if(feof(flac->in))
    {
        fprintf(stderr, "[oggenc/flac.c] enter read_callback 3\n");
        *bytes = 0;
        return FLAC__STREAM_DECODER_READ_STATUS_END_OF_STREAM;
        fprintf(stderr, "[oggenc/flac.c] exit read_callback 3\n");
    }
    else if(ferror(flac->in))
    {
        fprintf(stderr, "[oggenc/flac.c] enter read_callback 4\n");
        *bytes = 0;
        return FLAC__STREAM_DECODER_READ_STATUS_ABORT;
        fprintf(stderr, "[oggenc/flac.c] exit read_callback 4\n");
    }
    fprintf(stderr, "[oggenc/flac.c] exit read_callback 2\n");


    fprintf(stderr, "[oggenc/flac.c] enter read_callback 5\n");
    if(oldbuf_fill > 0) 
    {
        fprintf(stderr, "[oggenc/flac.c] enter read_callback 6\n");
        int copy;

        copy = oldbuf_fill < (*bytes - i) ? oldbuf_fill : (*bytes - i);
        memcpy(buffer + i, flac->oldbuf, copy);
        i += copy;
        flac->oldbuf_start += copy;
        fprintf(stderr, "[oggenc/flac.c] exit read_callback 6\n");
    }
    fprintf(stderr, "[oggenc/flac.c] exit read_callback 5\n");

    fprintf(stderr, "[oggenc/flac.c] enter read_callback 7\n");
    if(i < *bytes)
        i += fread(buffer+i, sizeof(FLAC__byte), *bytes - i, flac->in);

    *bytes = i;

    return FLAC__STREAM_DECODER_READ_STATUS_CONTINUE;
    fprintf(stderr, "[oggenc/flac.c] exit read_callback 7\n");
}

#if NEED_EASYFLAC
FLAC__StreamDecoderWriteStatus easyflac_write_callback(const EasyFLAC__StreamDecoder *decoder, const FLAC__Frame *frame, const FLAC__int32 * const buffer[], void *client_data)
#else
FLAC__StreamDecoderWriteStatus write_callback(const FLAC__StreamDecoder *decoder, const FLAC__Frame *frame, const FLAC__int32 * const buffer[], void *client_data)
#endif
{
    fprintf(stderr, "[oggenc/flac.c] enter write_callback 1\n");
    flacfile *flac = (flacfile *) client_data;
    int samples = frame->header.blocksize;
    int channels = frame->header.channels;
    int bits_per_sample = frame->header.bits_per_sample;
    int i, j;

    resize_buffer(flac, channels, samples);

    for (i = 0; i < channels; i++)
        for (j = 0; j < samples; j++)
            flac->buf[i][j] = buffer[i][j] / 
                 (float) (1 << (bits_per_sample - 1));

    flac->buf_start = 0;
    flac->buf_fill = samples;

    return FLAC__STREAM_DECODER_WRITE_STATUS_CONTINUE;
    fprintf(stderr, "[oggenc/flac.c] exit write_callback 1\n");
}

#if NEED_EASYFLAC
void easyflac_metadata_callback(const EasyFLAC__StreamDecoder *decoder, const FLAC__StreamMetadata *metadata, void *client_data)
#else
void metadata_callback(const FLAC__StreamDecoder *decoder, const FLAC__StreamMetadata *metadata, void *client_data)
#endif
{
    fprintf(stderr, "[oggenc/flac.c] enter metadata_callback 1\n");
    flacfile *flac = (flacfile *) client_data;

    switch (metadata->type)
    {
    case FLAC__METADATA_TYPE_STREAMINFO:
        fprintf(stderr, "[oggenc/flac.c] enter metadata_callback 2\n");
        flac->totalsamples = metadata->data.stream_info.total_samples;
        flac->rate = metadata->data.stream_info.sample_rate;
        fprintf(stderr, "[oggenc/flac.c] exit metadata_callback 2\n");
        break;

    case FLAC__METADATA_TYPE_VORBIS_COMMENT:
        fprintf(stderr, "[oggenc/flac.c] enter metadata_callback 3\n");
        flac->comments = FLAC__metadata_object_clone(metadata);
        fprintf(stderr, "[oggenc/flac.c] exit metadata_callback 3\n");
        break;
    default:
        fprintf(stderr, "\n");
        fprintf(stderr, "\n");
        break;
    }
    fprintf(stderr, "[oggenc/flac.c] exit metadata_callback 1\n");
}

#if NEED_EASYFLAC
void easyflac_error_callback(const EasyFLAC__StreamDecoder *decoder, FLAC__StreamDecoderErrorStatus status, void *client_data)
#else
void error_callback(const FLAC__StreamDecoder *decoder, FLAC__StreamDecoderErrorStatus status, void *client_data)
#endif
{
    fprintf(stderr, "\n");
    fprintf(stderr, "\n");
}

#if !NEED_EASYFLAC
FLAC__bool eof_callback(const FLAC__StreamDecoder *decoder, void *client_data)
{
    fprintf(stderr, "[oggenc/flac.c] enter eof_callback 1\n");
    flacfile *flac = (flacfile *) client_data;

    return feof(flac->in)? true : false;
    fprintf(stderr, "[oggenc/flac.c] exit eof_callback 1\n");
}
#endif

void resize_buffer(flacfile *flac, int newchannels, int newsamples)
{
    fprintf(stderr, "[oggenc/flac.c] enter resize_buffer 1\n");
    int i;

    if (newchannels == flac->channels && newsamples == flac->buf_len)
    {
        fprintf(stderr, "[oggenc/flac.c] enter resize_buffer 2\n");
        flac->buf_start = 0;
        flac->buf_fill = 0;
        return;
        fprintf(stderr, "[oggenc/flac.c] exit resize_buffer 2\n");
    }
    fprintf(stderr, "[oggenc/flac.c] exit resize_buffer 1\n");

    /* Deallocate all of the sample vectors */
    fprintf(stderr, "[oggenc/flac.c] enter resize_buffer 3\n");
    for (i = 0; i < flac->channels; i++)
        free(flac->buf[i]);

    /* Not the most efficient approach, but it is easy to follow */
    if(newchannels != flac->channels)
    {
        fprintf(stderr, "[oggenc/flac.c] enter resize_buffer 4\n");
        flac->buf = realloc(flac->buf, sizeof(float*) * newchannels);
        flac->channels = newchannels;
        fprintf(stderr, "[oggenc/flac.c] exit resize_buffer 4\n");
    }

    for (i = 0; i < newchannels; i++)
        flac->buf[i] = malloc(sizeof(float) * newsamples);

    flac->buf_len = newsamples;
    flac->buf_start = 0;
    flac->buf_fill = 0;
    fprintf(stderr, "[oggenc/flac.c] exit resize_buffer 3\n");
}

void copy_comments (vorbis_comment *v_comments, FLAC__StreamMetadata_VorbisComment *f_comments)
{
    fprintf(stderr, "[oggenc/flac.c] enter copy_comments 1\n");
    int i;

    for (i = 0; i < f_comments->num_comments; i++)
    {
        fprintf(stderr, "[oggenc/flac.c] enter copy_comments 2\n");
        char *comment = malloc(f_comments->comments[i].length + 1);
        memset(comment, '\0', f_comments->comments[i].length + 1);
        strncpy(comment, (const char *)f_comments->comments[i].entry, f_comments->comments[i].length);
        vorbis_comment_add(v_comments, comment);
        free(comment);
        fprintf(stderr, "[oggenc/flac.c] exit copy_comments 2\n");
    }
    fprintf(stderr, "[oggenc/flac.c] exit copy_comments 1\n");
}
// Total cost: 0.135134
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 373)]
// Total instrumented cost: 0.135134, input tokens: 6922, output tokens: 5895, cache read tokens: 0, cache write tokens: 6918

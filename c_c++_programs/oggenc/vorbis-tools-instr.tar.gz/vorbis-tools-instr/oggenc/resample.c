/* resample.c: see resample.h for interesting stuff */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <assert.h>
#include <stdio.h>

#include "resample.h"

/* Some systems don't define this */
#ifndef M_PI
#define M_PI       3.14159265358979323846 
#endif

static int hcf(int arg1, int arg2)
{
    fprintf(stderr, "[oggenc/resample.c] enter hcf 1\n");
    int mult = 1;
    fprintf(stderr, "[oggenc/resample.c] exit hcf 1\n");

    while (~(arg1 | arg2) & 1)
    {
        fprintf(stderr, "[oggenc/resample.c] enter hcf 2\n");
        arg1 >>= 1, arg2 >>= 1, mult <<= 1;
        fprintf(stderr, "[oggenc/resample.c] exit hcf 2\n");
    }

    while (arg1 > 0)
    {
        fprintf(stderr, "[oggenc/resample.c] enter hcf 3\n");
        if (~(arg1 & arg2) & 1)
        {
            fprintf(stderr, "[oggenc/resample.c] enter hcf 4\n");
            arg1 >>= (~arg1 & 1);
            arg2 >>= (~arg2 & 1);
            fprintf(stderr, "[oggenc/resample.c] exit hcf 4\n");
        }
        else if (arg1 < arg2)
        {
            fprintf(stderr, "[oggenc/resample.c] enter hcf 5\n");
            arg2 = (arg2 - arg1) >> 1;
            fprintf(stderr, "[oggenc/resample.c] exit hcf 5\n");
        }
        else
        {
            fprintf(stderr, "[oggenc/resample.c] enter hcf 6\n");
            arg1 = (arg1 - arg2) >> 1;
            fprintf(stderr, "[oggenc/resample.c] exit hcf 6\n");
        }
        fprintf(stderr, "[oggenc/resample.c] exit hcf 3\n");
    }

    fprintf(stderr, "[oggenc/resample.c] enter hcf 7\n");
    return arg2 * mult;
    fprintf(stderr, "[oggenc/resample.c] exit hcf 7\n");
}


static void filt_sinc(float *dest, int N, int step, double fc, double gain, int width)
{
    fprintf(stderr, "[oggenc/resample.c] enter filt_sinc 1\n");
    double s = fc / step;
    int mid, x;
    float *endpoint = dest + N,
        *base = dest,
        *origdest = dest;

    assert(width <= N);
    fprintf(stderr, "[oggenc/resample.c] exit filt_sinc 1\n");

    if ((N & 1) == 0)
    {
        fprintf(stderr, "[oggenc/resample.c] enter filt_sinc 2\n");
        *dest = 0.0;
        dest += width;
        if (dest >= endpoint)
            dest = ++base;
        N--;
        fprintf(stderr, "[oggenc/resample.c] exit filt_sinc 2\n");
    }

    fprintf(stderr, "[oggenc/resample.c] enter filt_sinc 3\n");
    mid = N / 2;
    x = -mid;
    fprintf(stderr, "[oggenc/resample.c] exit filt_sinc 3\n");

    while (N--)
    {
        fprintf(stderr, "[oggenc/resample.c] enter filt_sinc 4\n");
        *dest = (x ? sin(x * M_PI * s) / (x * M_PI) * step : fc) * gain;
        x++;
        dest += width;
        if (dest >= endpoint)
            dest = ++base;
        fprintf(stderr, "[oggenc/resample.c] exit filt_sinc 4\n");
    }
    fprintf(stderr, "[oggenc/resample.c] enter filt_sinc 5\n");
    assert(dest == (origdest + width));
    fprintf(stderr, "[oggenc/resample.c] exit filt_sinc 5\n");
}


static double I_zero(double x)
{
    fprintf(stderr, "[oggenc/resample.c] enter I_zero 1\n");
    int n = 0;
    double u = 1.0,
        s = 1.0,
        t;
    fprintf(stderr, "[oggenc/resample.c] exit I_zero 1\n");

    do
    {
        fprintf(stderr, "[oggenc/resample.c] enter I_zero 2\n");
        n += 2;
        t = x / n;
        u *= t * t;
        s += u;
        fprintf(stderr, "[oggenc/resample.c] exit I_zero 2\n");
    } while (u > 1e-21 * s);

    fprintf(stderr, "[oggenc/resample.c] enter I_zero 3\n");
    return s;
    fprintf(stderr, "[oggenc/resample.c] exit I_zero 3\n");
}


static void win_kaiser(float *dest, int N, double alpha, int width)
{
    fprintf(stderr, "[oggenc/resample.c] enter win_kaiser 1\n");
    double I_alpha, midsq;
    int x;
    float *endpoint = dest + N,
        *base = dest,
        *origdest = dest;

    assert(width <= N);
    fprintf(stderr, "[oggenc/resample.c] exit win_kaiser 1\n");

    if ((N & 1) == 0)
    {
        fprintf(stderr, "[oggenc/resample.c] enter win_kaiser 2\n");
        *dest = 0.0;
        dest += width;
        if (dest >= endpoint)
            dest = ++base;
        N--;
        fprintf(stderr, "[oggenc/resample.c] exit win_kaiser 2\n");
    }

    fprintf(stderr, "[oggenc/resample.c] enter win_kaiser 3\n");
    x = -(N / 2);
    midsq = (double)(x - 1) * (double)(x - 1);
    I_alpha = I_zero(alpha);
    fprintf(stderr, "[oggenc/resample.c] exit win_kaiser 3\n");

    while (N--)
    {
        fprintf(stderr, "[oggenc/resample.c] enter win_kaiser 4\n");
        *dest *= I_zero(alpha * sqrt(1.0 - ((double)x * (double)x) / midsq)) / I_alpha;
        x++;
        dest += width;
        if (dest >= endpoint)
            dest = ++base;
        fprintf(stderr, "[oggenc/resample.c] exit win_kaiser 4\n");
    }
    fprintf(stderr, "[oggenc/resample.c] enter win_kaiser 5\n");
    assert(dest == (origdest + width));
    fprintf(stderr, "[oggenc/resample.c] exit win_kaiser 5\n");
}


int res_init(res_state *state, int channels, int outfreq, int infreq, res_parameter op1, ...)
{
    fprintf(stderr, "[oggenc/resample.c] enter res_init 1\n");
    double beta = 16.0,
        cutoff = 0.80,
        gain = 1.0;
    int taps = 45;

    int factor;

    assert(state);
    assert(channels > 0);
    assert(outfreq > 0);
    assert(infreq > 0);
    assert(taps > 0);

    if (state == NULL || channels <= 0 || outfreq <= 0 || infreq <= 0 || taps <= 0)
        return -1;
    fprintf(stderr, "[oggenc/resample.c] exit res_init 1\n");

    if (op1 != RES_END)
    {
        fprintf(stderr, "[oggenc/resample.c] enter res_init 2\n");
        va_list argp;
        va_start(argp, op1);
        fprintf(stderr, "[oggenc/resample.c] exit res_init 2\n");
        do
        {
            fprintf(stderr, "[oggenc/resample.c] enter res_init 3\n");
            switch (op1)
            {
            case RES_GAIN:
                fprintf(stderr, "[oggenc/resample.c] enter res_init 4\n");
                gain = va_arg(argp, double);
                fprintf(stderr, "[oggenc/resample.c] exit res_init 4\n");
                break;

            case RES_CUTOFF:
                fprintf(stderr, "[oggenc/resample.c] enter res_init 5\n");
                cutoff = va_arg(argp, double);
                assert(cutoff > 0.01 && cutoff <= 1.0);
                fprintf(stderr, "[oggenc/resample.c] exit res_init 5\n");
                break;

            case RES_TAPS:
                fprintf(stderr, "[oggenc/resample.c] enter res_init 6\n");
                taps = va_arg(argp, int);
                assert(taps > 2 && taps < 1000);
                fprintf(stderr, "[oggenc/resample.c] exit res_init 6\n");
                break;

            case RES_BETA:
                fprintf(stderr, "[oggenc/resample.c] enter res_init 7\n");
                beta = va_arg(argp, double);
                assert(beta > 2.0);
                fprintf(stderr, "[oggenc/resample.c] exit res_init 7\n");
                break;
            default:
                fprintf(stderr, "[oggenc/resample.c] enter res_init 8\n");
                assert(0);
                return -1;
                fprintf(stderr, "[oggenc/resample.c] exit res_init 8\n");
            }
            fprintf(stderr, "[oggenc/resample.c] exit res_init 3\n");
            fprintf(stderr, "[oggenc/resample.c] enter res_init 9\n");
            op1 = va_arg(argp, res_parameter);
            fprintf(stderr, "[oggenc/resample.c] exit res_init 9\n");
        } while (op1 != RES_END);
        fprintf(stderr, "[oggenc/resample.c] enter res_init 10\n");
        va_end(argp);
        fprintf(stderr, "[oggenc/resample.c] exit res_init 10\n");
    }

    fprintf(stderr, "[oggenc/resample.c] enter res_init 11\n");
    factor = hcf(infreq, outfreq);
    outfreq /= factor;
    infreq /= factor;
    fprintf(stderr, "[oggenc/resample.c] exit res_init 11\n");

    /* adjust to rational values for downsampling */
    if (outfreq < infreq)
    {
        fprintf(stderr, "[oggenc/resample.c] enter res_init 12\n");
        /* push the cutoff frequency down to the output frequency */
        cutoff = cutoff * outfreq / infreq; 

        /* compensate for the sharper roll-off requirement
         * by using a bigger hammer */
        taps = taps * infreq/outfreq;
        fprintf(stderr, "[oggenc/resample.c] exit res_init 12\n");
    }

    fprintf(stderr, "[oggenc/resample.c] enter res_init 13\n");
    assert(taps >= ((infreq + outfreq - 1) / outfreq));

    if ((state->table = calloc(outfreq * taps, sizeof(float))) == NULL)
        return -1;
    if ((state->pool = calloc(channels * taps, sizeof(SAMPLE))) == NULL)
    {
        free(state->table);
        state->table = NULL;
        return -1;
    }

    state->poolfill = taps / 2 + 1;
    state->channels = channels;
    state->outfreq = outfreq;
    state->infreq = infreq;
    state->taps = taps;
    state->offset = 0;

    filt_sinc(state->table, outfreq * taps, outfreq, cutoff, gain, taps);
    win_kaiser(state->table, outfreq * taps, beta, taps);

    return 0;
    fprintf(stderr, "[oggenc/resample.c] exit res_init 13\n");
}


static SAMPLE sum(float const *scale, int count, SAMPLE const *source, SAMPLE const *trigger, SAMPLE const *reset, int srcstep)
{
    fprintf(stderr, "[oggenc/resample.c] enter sum 1\n");
    float total = 0.0;
    fprintf(stderr, "[oggenc/resample.c] exit sum 1\n");

    while (count--)
    {
        fprintf(stderr, "[oggenc/resample.c] enter sum 2\n");
        total += *source * *scale;

        if (source == trigger)
            source = reset, srcstep = 1;
        source -= srcstep;
        scale++;
        fprintf(stderr, "[oggenc/resample.c] exit sum 2\n");
    }

    fprintf(stderr, "[oggenc/resample.c] enter sum 3\n");
    return total;
    fprintf(stderr, "[oggenc/resample.c] exit sum 3\n");
}


static int push(res_state const * const state, SAMPLE *pool, int * const poolfill, int * const offset, SAMPLE *dest, int dststep, SAMPLE const *source, int srcstep, size_t srclen)
{
    fprintf(stderr, "[oggenc/resample.c] enter push 1\n");
    SAMPLE    * const destbase = dest,
        *poolhead = pool + *poolfill,
        *poolend = pool + state->taps,
        *newpool = pool;
    SAMPLE const *refill, *base, *endpoint;
    int    lencheck;


    assert(state);
    assert(pool);
    assert(poolfill);
    assert(dest);
    assert(source);

    assert(state->poolfill != -1);

    lencheck = res_push_check(state, srclen);
    fprintf(stderr, "[oggenc/resample.c] exit push 1\n");

    /* fill the pool before diving in */
    while (poolhead < poolend && srclen > 0)
    {
        fprintf(stderr, "[oggenc/resample.c] enter push 2\n");
        *poolhead++ = *source;
        source += srcstep;
        srclen--;
        fprintf(stderr, "[oggenc/resample.c] exit push 2\n");
    }

    if (srclen <= 0)
    {
        fprintf(stderr, "[oggenc/resample.c] enter push 3\n");
        return 0;
        fprintf(stderr, "[oggenc/resample.c] exit push 3\n");
    }

    fprintf(stderr, "[oggenc/resample.c] enter push 4\n");
    base = source;
    endpoint = source + srclen * srcstep;
    fprintf(stderr, "[oggenc/resample.c] exit push 4\n");

    while (source < endpoint)
    {
        fprintf(stderr, "[oggenc/resample.c] enter push 5\n");
        *dest = sum(state->table + *offset * state->taps, state->taps, source, base, poolend, srcstep);
        dest += dststep;
        *offset += state->infreq;
        fprintf(stderr, "[oggenc/resample.c] exit push 5\n");
        while (*offset >= state->outfreq)
        {
            fprintf(stderr, "[oggenc/resample.c] enter push 6\n");
            *offset -= state->outfreq;
            source += srcstep;
            fprintf(stderr, "[oggenc/resample.c] exit push 6\n");
        }
    }

    fprintf(stderr, "[oggenc/resample.c] enter push 7\n");
    assert(dest == (destbase + lencheck * dststep));

    /* pretend that source has that underrun data we're not going to get */
    srclen += (source - endpoint) / srcstep;

    /* if we didn't get enough to completely replace the pool, then shift things about a bit */
    fprintf(stderr, "[oggenc/resample.c] exit push 7\n");
    if (srclen < state->taps)
    {
        fprintf(stderr, "[oggenc/resample.c] enter push 8\n");
        refill = pool + srclen;
        while (refill < poolend)
        {
            fprintf(stderr, "[oggenc/resample.c] enter push 9\n");
            *newpool++ = *refill++;
            fprintf(stderr, "[oggenc/resample.c] exit push 9\n");
        }

        refill = source - srclen * srcstep;
        fprintf(stderr, "[oggenc/resample.c] exit push 8\n");
    }
    else
    {
        fprintf(stderr, "[oggenc/resample.c] enter push 10\n");
        refill = source - state->taps * srcstep;
        fprintf(stderr, "[oggenc/resample.c] exit push 10\n");
    }

    /* pull in fresh pool data */
    fprintf(stderr, "[oggenc/resample.c] enter push 11\n");
    while (refill < endpoint)
    {
        fprintf(stderr, "[oggenc/resample.c] enter push 12\n");
        *newpool++ = *refill;
        refill += srcstep;
        fprintf(stderr, "[oggenc/resample.c] exit push 12\n");
    }

    assert(newpool > pool);
    assert(newpool <= poolend);

    *poolfill = newpool - pool;

    return (dest - destbase) / dststep;
    fprintf(stderr, "[oggenc/resample.c] exit push 11\n");
}


int res_push_max_input(res_state const * const state, size_t maxoutput)
{
    fprintf(stderr, "[oggenc/resample.c] enter res_push_max_input 1\n");
    return maxoutput * state->infreq / state->outfreq;
    fprintf(stderr, "[oggenc/resample.c] exit res_push_max_input 1\n");
}


int res_push_check(res_state const * const state, size_t srclen)
{
    fprintf(stderr, "[oggenc/resample.c] enter res_push_check 1\n");
    if (state->poolfill < state->taps)
        srclen -= state->taps - state->poolfill;

    return (srclen * state->outfreq - state->offset + state->infreq - 1) / state->infreq;
    fprintf(stderr, "[oggenc/resample.c] exit res_push_check 1\n");
}


int res_push(res_state *state, SAMPLE **dstlist, SAMPLE const **srclist, size_t srclen)
{
    fprintf(stderr, "[oggenc/resample.c] enter res_push 1\n");
    int result = -1, poolfill = -1, offset = -1, i;

    assert(state);
    assert(dstlist);
    assert(srclist);
    assert(state->poolfill >= 0);
    fprintf(stderr, "[oggenc/resample.c] exit res_push 1\n");

    for (i = 0; i < state->channels; i++)
    {
        fprintf(stderr, "[oggenc/resample.c] enter res_push 2\n");
        poolfill = state->poolfill;
        offset = state->offset;
        result = push(state, state->pool + i * state->taps, &poolfill, &offset, dstlist[i], 1, srclist[i], 1, srclen);
        fprintf(stderr, "[oggenc/resample.c] exit res_push 2\n");
    }
    fprintf(stderr, "[oggenc/resample.c] enter res_push 3\n");
    state->poolfill = poolfill;
    state->offset = offset;

    return result;
    fprintf(stderr, "[oggenc/resample.c] exit res_push 3\n");
}


int res_push_interleaved(res_state *state, SAMPLE *dest, SAMPLE const *source, size_t srclen)
{
    fprintf(stderr, "[oggenc/resample.c] enter res_push_interleaved 1\n");
    int result = -1, poolfill = -1, offset = -1, i;

    assert(state);
    assert(dest);
    assert(source);
    assert(state->poolfill >= 0);
    fprintf(stderr, "[oggenc/resample.c] exit res_push_interleaved 1\n");

    for (i = 0; i < state->channels; i++)
    {
        fprintf(stderr, "[oggenc/resample.c] enter res_push_interleaved 2\n");
        poolfill = state->poolfill;
        offset = state->offset;
        result = push(state, state->pool + i * state->taps, &poolfill, &offset, dest + i, state->channels, source + i, state->channels, srclen);
        fprintf(stderr, "[oggenc/resample.c] exit res_push_interleaved 2\n");
    }
    fprintf(stderr, "[oggenc/resample.c] enter res_push_interleaved 3\n");
    state->poolfill = poolfill;
    state->offset = offset;

    return result;
    fprintf(stderr, "[oggenc/resample.c] exit res_push_interleaved 3\n");
}


int res_drain(res_state *state, SAMPLE **dstlist)
{
    fprintf(stderr, "[oggenc/resample.c] enter res_drain 1\n");
    SAMPLE *tail;
    int result = -1, poolfill = -1, offset = -1, i;

    assert(state);
    assert(dstlist);
    assert(state->poolfill >= 0);

    if ((tail = calloc(state->taps, sizeof(SAMPLE))) == NULL)
        return -1;
    fprintf(stderr, "[oggenc/resample.c] exit res_drain 1\n");

    for (i = 0; i < state->channels; i++)
    {
        fprintf(stderr, "[oggenc/resample.c] enter res_drain 2\n");
        poolfill = state->poolfill;
        offset = state->offset;
        result = push(state, state->pool + i * state->taps, &poolfill, &offset, dstlist[i], 1, tail, 1, state->taps / 2 - 1);
        fprintf(stderr, "[oggenc/resample.c] exit res_drain 2\n");
    }

    fprintf(stderr, "[oggenc/resample.c] enter res_drain 3\n");
    free(tail);

    state->poolfill = -1;

    return result;
    fprintf(stderr, "[oggenc/resample.c] exit res_drain 3\n");
}


int res_drain_interleaved(res_state *state, SAMPLE *dest)
{
    fprintf(stderr, "[oggenc/resample.c] enter res_drain_interleaved 1\n");
    SAMPLE *tail;
    int result = -1, poolfill = -1, offset = -1, i;

    assert(state);
    assert(dest);
    assert(state->poolfill >= 0);

    if ((tail = calloc(state->taps, sizeof(SAMPLE))) == NULL)
        return -1;
    fprintf(stderr, "[oggenc/resample.c] exit res_drain_interleaved 1\n");

    for (i = 0; i < state->channels; i++)
    {
        fprintf(stderr, "[oggenc/resample.c] enter res_drain_interleaved 2\n");
        poolfill = state->poolfill;
        offset = state->offset;
        result = push(state, state->pool + i * state->taps, &poolfill, &offset, dest + i, state->channels, tail, 1, state->taps / 2 - 1);
        fprintf(stderr, "[oggenc/resample.c] exit res_drain_interleaved 2\n");
    }

    fprintf(stderr, "[oggenc/resample.c] enter res_drain_interleaved 3\n");
    free(tail);

    state->poolfill = -1;

    return result;
    fprintf(stderr, "[oggenc/resample.c] exit res_drain_interleaved 3\n");
}


void res_clear(res_state *state)
{
    fprintf(stderr, "[oggenc/resample.c] enter res_clear 1\n");
    assert(state);
    assert(state->table);
    assert(state->pool);

    free(state->table);
    free(state->pool);
    memset(state, 0, sizeof(*state));
    fprintf(stderr, "[oggenc/resample.c] exit res_clear 1\n");
}
// Total cost: 0.109508
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 444)]
// Total instrumented cost: 0.109508, input tokens: 5882, output tokens: 5635, cache read tokens: 2280, cache write tokens: 3598

/* OggEnc
 **
 ** This program is distributed under the GNU General Public License, version 2.
 ** A copy of this license is included with this source.
 **
 ** Copyright 2000, Michael Smith <msmith@xiph.org>
 **
 ** Portions from Vorbize, (c) Kenneth Arnold <kcarnold-xiph@arnoldnet.net>
 ** and libvorbis examples, (c) Monty <monty@xiph.org>
 **/

/* Platform support routines  - win32, OS/2, unix */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "platform.h"
#include "encode.h"
#include "i18n.h"
#include <stdlib.h>
#include <ctype.h>
#if defined(_WIN32) || defined(__EMX__) || defined(__WATCOMC__)
#include <getopt.h>
#include <fcntl.h>
#include <io.h>
#include <time.h>
#endif

#ifdef _WIN32
#include <windows.h>
#endif

#if defined(_WIN32) && defined(_MSC_VER)

void setbinmode(FILE *f)
{
    fprintf(stderr, "[oggenc/platform.c] enter setbinmode 1\n");
    _setmode( _fileno(f), _O_BINARY );
    fprintf(stderr, "[oggenc/platform.c] exit setbinmode 1\n");
}
#endif /* win32 */

#ifdef __EMX__
void setbinmode(FILE *f) 
{
    fprintf(stderr, "[oggenc/platform.c] enter setbinmode 2\n");
    _fsetmode( f, "b");
    fprintf(stderr, "[oggenc/platform.c] exit setbinmode 2\n");
}
#endif

#if defined(__WATCOMC__) || defined(__BORLANDC__) || defined(__MINGW32__)
void setbinmode(FILE *f)
{
    fprintf(stderr, "[oggenc/platform.c] enter setbinmode 3\n");
    setmode(fileno(f), O_BINARY);
    fprintf(stderr, "[oggenc/platform.c] exit setbinmode 3\n");
}
#endif


#if defined(_WIN32) || defined(__EMX__) || defined(__WATCOMC__)
void *timer_start(void)
{
    fprintf(stderr, "[oggenc/platform.c] enter timer_start 1\n");
    time_t *start = malloc(sizeof(time_t));
    time(start);
    return (void *)start;
    fprintf(stderr, "[oggenc/platform.c] exit timer_start 1\n");
}

double timer_time(void *timer)
{
    fprintf(stderr, "[oggenc/platform.c] enter timer_time 1\n");
    time_t now = time(NULL);
    time_t start = *((time_t *)timer);

    if(now-start)
    {
        fprintf(stderr, "[oggenc/platform.c] enter timer_time 2\n");
        return (double)(now-start);
        fprintf(stderr, "[oggenc/platform.c] exit timer_time 2\n");
    }
    else
    {
        fprintf(stderr, "[oggenc/platform.c] enter timer_time 3\n");
        return 1; /* To avoid division by zero later, for very short inputs */
        fprintf(stderr, "[oggenc/platform.c] exit timer_time 3\n");
    }
    fprintf(stderr, "[oggenc/platform.c] exit timer_time 1\n");
}


void timer_clear(void *timer)
{
    fprintf(stderr, "[oggenc/platform.c] enter timer_clear 1\n");
    free((time_t *)timer);
    fprintf(stderr, "[oggenc/platform.c] exit timer_clear 1\n");
}

#else /* unix. Or at least win32 */

#include <sys/time.h>
#include <unistd.h>

void *timer_start(void)
{
    fprintf(stderr, "[oggenc/platform.c] enter timer_start 2\n");
    struct timeval *start = malloc(sizeof(struct timeval));
    gettimeofday(start, NULL);
    return (void *)start;
    fprintf(stderr, "[oggenc/platform.c] exit timer_start 2\n");
}

double timer_time(void *timer)
{
    fprintf(stderr, "[oggenc/platform.c] enter timer_time 4\n");
    struct timeval now;
    struct timeval start = *((struct timeval *)timer);

    gettimeofday(&now, NULL);

    return (double)now.tv_sec - (double)start.tv_sec + 
        ((double)now.tv_usec - (double)start.tv_usec)/1000000.0;
    fprintf(stderr, "[oggenc/platform.c] exit timer_time 4\n");
}

void timer_clear(void *timer)
{
    fprintf(stderr, "[oggenc/platform.c] enter timer_clear 2\n");
    free((time_t *)timer);
    fprintf(stderr, "[oggenc/platform.c] exit timer_clear 2\n");
}

#endif

#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifdef _WIN32

#include <direct.h>

#define PATH_SEPS "/\\"
#define mkdir(x,y) _mkdir((x))

/* MSVC does this, borland doesn't? */
#ifndef __BORLANDC__
#define stat _stat
#endif

#else

#define PATH_SEPS "/"

#endif

int create_directories(char *fn, int isutf8)
{
    fprintf(stderr, "[oggenc/platform.c] enter create_directories 1\n");
    char *end, *start;
    struct stat statbuf;
    const size_t fn_len = strlen(fn);
    char *segment = malloc(fn_len+1);
#ifdef _WIN32
    wchar_t seg[MAX_PATH+1];
#endif

    start = fn;
#ifdef _WIN32
    // Strip drive prefix
    if(fn_len >= 3 && isalpha(fn[0]) && fn[1]==':') 
    {
        fprintf(stderr, "[oggenc/platform.c] enter create_directories 2\n");
        start = start+2;
        fprintf(stderr, "[oggenc/platform.c] exit create_directories 2\n");
    }
#endif

    // Loop through path segments, creating directories if necessary
    while((end = strpbrk(start + strspn(start, PATH_SEPS), PATH_SEPS)) != NULL)
    {
        fprintf(stderr, "[oggenc/platform.c] enter create_directories 3\n");
        int rv;
        memcpy(segment, fn, end-fn);
        segment[end-fn] = 0;

#ifdef _WIN32
        if (isutf8) 
        {
            fprintf(stderr, "[oggenc/platform.c] enter create_directories 4\n");
            MultiByteToWideChar(CP_UTF8, 0, segment, -1, seg, MAX_PATH+1);
            rv = _wstat(seg,&statbuf);
            fprintf(stderr, "[oggenc/platform.c] exit create_directories 4\n");
        } 
        else
#endif
        {
            fprintf(stderr, "[oggenc/platform.c] enter create_directories 5\n");
            rv = stat(segment,&statbuf);
            fprintf(stderr, "[oggenc/platform.c] exit create_directories 5\n");
        }
        if(rv) 
        {
            fprintf(stderr, "[oggenc/platform.c] enter create_directories 6\n");
            if(errno == ENOENT) 
            {
                fprintf(stderr, "[oggenc/platform.c] enter create_directories 7\n");
#ifdef _WIN32
                if (isutf8)
                {
                    fprintf(stderr, "[oggenc/platform.c] enter create_directories 8\n");
                    rv = _wmkdir(seg);
                    fprintf(stderr, "[oggenc/platform.c] exit create_directories 8\n");
                }
                else
#endif
                {
                    fprintf(stderr, "[oggenc/platform.c] enter create_directories 9\n");
                    rv = mkdir(segment, 0777);
                    fprintf(stderr, "[oggenc/platform.c] exit create_directories 9\n");
                }
                if(rv) 
                {
                    fprintf(stderr, "[oggenc/platform.c] enter create_directories 10\n");
                    fprintf(stderr, _("Couldn't create directory \"%s\": %s\n"),
                            segment, strerror(errno));
                    free(segment);
                    return -1;
                    fprintf(stderr, "[oggenc/platform.c] exit create_directories 10\n");
                }
                fprintf(stderr, "[oggenc/platform.c] exit create_directories 7\n");
            }
            else 
            {
                fprintf(stderr, "[oggenc/platform.c] enter create_directories 11\n");
                fprintf(stderr, _("Error checking for existence of directory %s: %s\n"), 
                            segment, strerror(errno));
                free(segment);
                return -1;
                fprintf(stderr, "[oggenc/platform.c] exit create_directories 11\n");
            }
            fprintf(stderr, "[oggenc/platform.c] exit create_directories 6\n");
        }
#if defined(_WIN32) && !defined(__BORLANDC__)
        else if(!(_S_IFDIR & statbuf.st_mode)) 
        {
            fprintf(stderr, "[oggenc/platform.c] enter create_directories 12\n");
            fprintf(stderr, _("Error: path segment \"%s\" is not a directory\n"),
                    segment);
            free(segment);
            return -1;
            fprintf(stderr, "[oggenc/platform.c] exit create_directories 12\n");
        }
#elif defined(__BORLANDC__)
        else if(!(S_IFDIR & statbuf.st_mode)) 
        {
            fprintf(stderr, "[oggenc/platform.c] enter create_directories 13\n");
            fprintf(stderr, _("Error: path segment \"%s\" is not a directory\n"),
                    segment);
            free(segment);
            return -1;
            fprintf(stderr, "[oggenc/platform.c] exit create_directories 13\n");
        }
#else
        else if(!S_ISDIR(statbuf.st_mode)) 
        {
            fprintf(stderr, "[oggenc/platform.c] enter create_directories 14\n");
            fprintf(stderr, _("Error: path segment \"%s\" is not a directory\n"),
                    segment);
            free(segment);
            return -1;
            fprintf(stderr, "[oggenc/platform.c] exit create_directories 14\n");
        }
#endif

        start = end+1;
        fprintf(stderr, "[oggenc/platform.c] exit create_directories 3\n");
    }

    free(segment);
    return 0;
    fprintf(stderr, "[oggenc/platform.c] exit create_directories 1\n");
}

#ifdef _WIN32

FILE *oggenc_fopen(char *fn, char *mode, int isutf8)
{
    fprintf(stderr, "[oggenc/platform.c] enter oggenc_fopen 1\n");
    if (isutf8) 
    {
        fprintf(stderr, "[oggenc/platform.c] enter oggenc_fopen 2\n");
        wchar_t wfn[MAX_PATH+1];
        wchar_t wmode[32];
        MultiByteToWideChar(CP_UTF8, 0, fn, -1, wfn, MAX_PATH+1);
        MultiByteToWideChar(CP_ACP, 0, mode, -1, wmode, 32);
        return _wfopen(wfn, wmode);
        fprintf(stderr, "[oggenc/platform.c] exit oggenc_fopen 2\n");
    } 
    else
    {
        fprintf(stderr, "[oggenc/platform.c] enter oggenc_fopen 3\n");
        return fopen(fn, mode);
        fprintf(stderr, "[oggenc/platform.c] exit oggenc_fopen 3\n");
    }
    fprintf(stderr, "[oggenc/platform.c] exit oggenc_fopen 1\n");
}

static int
parse_for_utf8(int argc, char **argv)
{
    fprintf(stderr, "[oggenc/platform.c] enter parse_for_utf8 1\n");
    extern struct option long_options[];
    int ret;
    int option_index = 1;

    while((ret = getopt_long(argc, argv, "A:a:b:B:c:C:d:G:hkl:m:M:n:N:o:P:q:QrR:s:t:vX:",
                    long_options, &option_index)) != -1)
    {
        fprintf(stderr, "[oggenc/platform.c] enter parse_for_utf8 2\n");
        switch(ret)
        {
            case 0:
                fprintf(stderr, "[oggenc/platform.c] enter parse_for_utf8 3\n");
                if(!strcmp(long_options[option_index].name, "utf8")) 
                {
                    fprintf(stderr, "[oggenc/platform.c] enter parse_for_utf8 4\n");
                    return 1;
                    fprintf(stderr, "[oggenc/platform.c] exit parse_for_utf8 4\n");
                }
                fprintf(stderr, "[oggenc/platform.c] exit parse_for_utf8 3\n");
                break;
            default:
                fprintf(stderr, "\n");
                fprintf(stderr, "\n");
                break;
        }
        fprintf(stderr, "[oggenc/platform.c] exit parse_for_utf8 2\n");
    }

    return 0;
    fprintf(stderr, "[oggenc/platform.c] exit parse_for_utf8 1\n");
}

typedef WINSHELLAPI LPWSTR *  (APIENTRY *tCommandLineToArgvW)(LPCWSTR lpCmdLine, int*pNumArgs);

void get_args_from_ucs16(int *argc, char ***argv)
{
    fprintf(stderr, "[oggenc/platform.c] enter get_args_from_ucs16 1\n");
    OSVERSIONINFO vi;
    int utf8;

    utf8 = parse_for_utf8(*argc, *argv);
    optind = 1; /* Reset getopt_long */

    /* If command line is already UTF-8, don't convert */
    if (utf8)
    {
        fprintf(stderr, "[oggenc/platform.c] enter get_args_from_ucs16 2\n");
        return;
        fprintf(stderr, "[oggenc/platform.c] exit get_args_from_ucs16 2\n");
    }

    vi.dwOSVersionInfoSize = sizeof(vi);
    GetVersionEx(&vi);

    /* We only do NT4 and more recent.*/
    /* It would be relatively easy to add NT3.5 support. Is anyone still using NT3? */
    /* It would be relatively hard to add 9x support. Fortunately, 9x is
       a lost cause for unicode support anyway. */
    if (vi.dwPlatformId == VER_PLATFORM_WIN32_NT && vi.dwMajorVersion >= 4) 
    {
        fprintf(stderr, "[oggenc/platform.c] enter get_args_from_ucs16 3\n");
        const char utf8flag[] = "--utf8";
        int newargc;
        int sizeofargs = 0;
        int a, count;
        char *argptr;
        char **newargv = NULL;
        LPWSTR *ucs16argv = NULL;
        tCommandLineToArgvW pCommandLineToArgvW = NULL;
        HMODULE hLib = NULL;

        hLib = LoadLibrary("shell32.dll");
        if (!hLib)
        {
            fprintf(stderr, "[oggenc/platform.c] enter get_args_from_ucs16 4\n");
            goto bail;
            fprintf(stderr, "[oggenc/platform.c] exit get_args_from_ucs16 4\n");
        }
        pCommandLineToArgvW = (tCommandLineToArgvW)GetProcAddress(hLib, "CommandLineToArgvW");
        if (!pCommandLineToArgvW)
        {
            fprintf(stderr, "[oggenc/platform.c] enter get_args_from_ucs16 5\n");
            goto bail;
            fprintf(stderr, "[oggenc/platform.c] exit get_args_from_ucs16 5\n");
        }

        ucs16argv = pCommandLineToArgvW(GetCommandLineW(), &newargc);
        if (!ucs16argv)
        {
            fprintf(stderr, "[oggenc/platform.c] enter get_args_from_ucs16 6\n");
            goto bail;
            fprintf(stderr, "[oggenc/platform.c] exit get_args_from_ucs16 6\n");
        }

        for (a=0; a<newargc; a++) 
        {
            fprintf(stderr, "[oggenc/platform.c] enter get_args_from_ucs16 7\n");
            count = WideCharToMultiByte(CP_UTF8, 0, ucs16argv[a], -1,
                NULL, 0, NULL, NULL);
            if (count == 0)
            {
                fprintf(stderr, "[oggenc/platform.c] enter get_args_from_ucs16 8\n");
                goto bail;
                fprintf(stderr, "[oggenc/platform.c] exit get_args_from_ucs16 8\n");
            }
            sizeofargs += count;
            fprintf(stderr, "[oggenc/platform.c] exit get_args_from_ucs16 7\n");
        }

        sizeofargs += strlen(utf8flag) + 1;

        newargv = malloc(((newargc + 2) * sizeof(char *)) + sizeofargs);
        argptr = (char *)(&newargv[newargc+2]);

        for (a=0; a<newargc; a++) 
        {
            fprintf(stderr, "[oggenc/platform.c] enter get_args_from_ucs16 9\n");
            count = WideCharToMultiByte(CP_UTF8, 0, ucs16argv[a], -1,
                argptr, sizeofargs, NULL, NULL);
            if (count == 0)
            {
                fprintf(stderr, "[oggenc/platform.c] enter get_args_from_ucs16 10\n");
                goto bail;
                fprintf(stderr, "[oggenc/platform.c] exit get_args_from_ucs16 10\n");
            }

            newargv[a] = argptr;
            argptr += count;
            sizeofargs -= count;
            fprintf(stderr, "[oggenc/platform.c] exit get_args_from_ucs16 9\n");
        }

        count = strlen(utf8flag) + 1;
        strcpy(argptr, utf8flag);
        newargv[a] = argptr;
        argptr += count;
        sizeofargs -= count;

        newargv[a+1] = NULL;

        *argc = newargc + 1;
        *argv = newargv;

bail:
        if (hLib != NULL)
        {
            fprintf(stderr, "[oggenc/platform.c] enter get_args_from_ucs16 11\n");
            FreeLibrary(hLib);
            fprintf(stderr, "[oggenc/platform.c] exit get_args_from_ucs16 11\n");
        }
        if (ucs16argv != NULL)
        {
            fprintf(stderr, "[oggenc/platform.c] enter get_args_from_ucs16 12\n");
            GlobalFree(ucs16argv);
            fprintf(stderr, "[oggenc/platform.c] exit get_args_from_ucs16 12\n");
        }
        fprintf(stderr, "[oggenc/platform.c] exit get_args_from_ucs16 3\n");
    }
    fprintf(stderr, "[oggenc/platform.c] exit get_args_from_ucs16 1\n");
}

#endif
// Total cost: 0.090881
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 335)]
// Total instrumented cost: 0.090881, input tokens: 5178, output tokens: 4710, cache read tokens: 2280, cache write tokens: 2894

/* OggEnc
 *
 * This program is distributed under the GNU General Public License, version 2.
 * A copy of this license is included with this source.
 *
 * Copyright 2000-2005, Michael Smith <msmith@xiph.org>
 *
 * Portions from Vorbize, (c) Kenneth Arnold <kcarnold-xiph@arnoldnet.net>
 * and libvorbis examples, (c) Monty <monty@xiph.org>
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <getopt.h>
#include <string.h>
#include <time.h>
#include <locale.h>
#include <errno.h>
#include <sys/types.h>

#ifndef _MSC_VER
#include <unistd.h>
#endif

#if defined WIN32 || defined _WIN32
#include <process.h>
#endif

#include "platform.h"
#include "encode.h"
#include "audio.h"
#include "utf8.h"
#include "i18n.h"

/* fallback for stand-alone compiles */
#ifndef PACKAGE
# define PACKAGE "oggenc"
#endif
#ifndef VERSION
# define VERSION "unknown"
#endif

#define CHUNK 4096 /* We do reads, etc. in multiples of this */

struct option long_options[] = {
    {"quiet",0,0,'Q'},
    {"help",0,0,'h'},
    {"skeleton",no_argument,NULL, 'k'},
    {"comment",1,0,'c'},
    {"artist",1,0,'a'},
    {"album",1,0,'l'},
    {"title",1,0,'t'},
    {"genre",1,0,'G'},
    {"names",1,0,'n'},
    {"name-remove",1,0,'X'},
    {"name-replace",1,0,'P'},
    {"output",1,0,'o'},
    {"version",0,0,'V'},
    {"raw",0,0,'r'},
    {"raw-bits",1,0,'B'},
    {"raw-chan",1,0,'C'},
    {"raw-rate",1,0,'R'},
    {"raw-endianness",1,0, 0},
    {"bitrate",1,0,'b'},
    {"min-bitrate",1,0,'m'},
    {"max-bitrate",1,0,'M'},
    {"quality",1,0,'q'},
    {"date",1,0,'d'},
    {"tracknum",1,0,'N'},
    {"serial",1,0,'s'},
    {"managed", 0, 0, 0},
    {"resample",1,0,0},
    {"downmix", 0,0,0},
    {"scale", 1, 0, 0},
    {"advanced-encode-option", 1, 0, 0},
    {"discard-comments", 0, 0, 0},
    {"utf8", 0,0,0},
    {"ignorelength", 0, 0, 0},
    {"lyrics",1,0,'L'},
    {"lyrics-language",1,0,'Y'},
    {NULL,0,0,0}
};

static char *generate_name_string(char *format, char *remove_list,
        char *replace_list, char *artist, char *title, char *album,
        char *track, char *date, char *genre);
static void parse_options(int argc, char **argv, oe_options *opt);
static void build_comments(vorbis_comment *vc, oe_options *opt, int filenum,
        char **artist,char **album, char **title, char **tracknum, char **date,
        char **genre);
static void usage(void);

int main(int argc, char **argv)
{
    fprintf(stderr, "[oggenc/oggenc.c] enter main 1\n");
    /* Default values */
    oe_options opt = {
              NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0,
              NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0,
              1, 0, 0, 0,
              16,44100,2, 0,
              NULL, DEFAULT_NAMEFMT_REMOVE, DEFAULT_NAMEFMT_REPLACE,
              NULL,
              0, -1,-1,-1,
              .3,-1,
              0,0,0.f,
              0, 0, 0, 0, 0};
    input_format raw_format = {NULL, 0, raw_open, wav_close, "raw", 
      N_("RAW file reader")};

    int i;

    char **infiles;
    int numfiles;
    int errors=0;
    fprintf(stderr, "[oggenc/oggenc.c] exit main 1\n");

    fprintf(stderr, "[oggenc/oggenc.c] enter main 2\n");
    get_args_from_ucs16(&argc, &argv);

    setlocale(LC_ALL, "");
    bindtextdomain(PACKAGE, LOCALEDIR);
    textdomain(PACKAGE);

    parse_options(argc, argv, &opt);
    fprintf(stderr, "[oggenc/oggenc.c] exit main 2\n");

    fprintf(stderr, "[oggenc/oggenc.c] enter main 3\n");
    if(optind >= argc)
    {
        fprintf(stderr, _("ERROR: No input files specified. Use -h for help.\n"));
        return 1;
    }
    else
    {
        infiles = argv + optind;
        numfiles = argc - optind;
    }
    fprintf(stderr, "[oggenc/oggenc.c] exit main 3\n");

    fprintf(stderr, "[oggenc/oggenc.c] enter main 4\n");
    /* Now, do some checking for illegal argument combinations */

    for(i = 0; i < numfiles; i++)
    {
        if(!strcmp(infiles[i], "-") && numfiles > 1)
        {
            fprintf(stderr, _("ERROR: Multiple files specified when using stdin\n"));
            exit(1);
        }
    }
    fprintf(stderr, "[oggenc/oggenc.c] exit main 4\n");

    fprintf(stderr, "[oggenc/oggenc.c] enter main 5\n");
    if(numfiles > 1 && opt.outfile)
    {
        fprintf(stderr, _("ERROR: Multiple input files with specified output filename: suggest using -n\n"));
        exit(1);
    }
    fprintf(stderr, "[oggenc/oggenc.c] exit main 5\n");

    fprintf(stderr, "[oggenc/oggenc.c] enter main 6\n");
    if(!opt.fixedserial)
    {
                /* We randomly pick a serial number. This is then incremented for each
                   file. The random seed includes the PID so two copies of oggenc that
                   start in the same second will generate different serial numbers. */
                srand(time(NULL) ^ getpid());
        opt.serial = rand();
    }
    opt.skeleton_serial = opt.serial + numfiles;
    opt.kate_serial = opt.skeleton_serial + numfiles;
    fprintf(stderr, "[oggenc/oggenc.c] exit main 6\n");

    fprintf(stderr, "[oggenc/oggenc.c] enter main 7\n");
    for(i = 0; i < numfiles; i++)
    {
        /* Once through the loop for each file */

        oe_enc_opt      enc_opts;
        vorbis_comment  vc;
        char *out_fn = NULL;
        FILE *in, *out = NULL;
        int foundformat = 0;
        int closeout = 0, closein = 0;
        char *artist=NULL, *album=NULL, *title=NULL, *track=NULL;
        char *date=NULL, *genre=NULL;
        char *lyrics=NULL, *lyrics_language=NULL;
        input_format *format;
        int resampled = 0;

        /* Set various encoding defaults */

        enc_opts.serialno = opt.serial++;
        enc_opts.skeleton_serialno = opt.skeleton_serial++;
        enc_opts.kate_serialno = opt.kate_serial++;
        enc_opts.progress_update = update_statistics_full;
        enc_opts.start_encode = start_encode_full;
        enc_opts.end_encode = final_statistics;
        enc_opts.error = encode_error;
        enc_opts.comments = &vc;
        enc_opts.copy_comments = opt.copy_comments;
        enc_opts.with_skeleton = opt.with_skeleton;
        enc_opts.ignorelength = opt.ignorelength;

        /* OK, let's build the vorbis_comments structure */
        build_comments(&vc, &opt, i, &artist, &album, &title, &track,
                &date, &genre);

        if(opt.lyrics_count)
        {
            fprintf(stderr, "[oggenc/oggenc.c] enter main 8\n");
            if(i >= opt.lyrics_count)
            {
                lyrics = NULL;
            }
            else
                lyrics = opt.lyrics[i];
            fprintf(stderr, "[oggenc/oggenc.c] exit main 8\n");
        }

        if(opt.lyrics_language_count)
        {
            fprintf(stderr, "[oggenc/oggenc.c] enter main 9\n");
            if(i >= opt.lyrics_language_count)
            {
                if(!opt.quiet)
                    fprintf(stderr, _("WARNING: Insufficient lyrics languages specified, defaulting to final lyrics language.\n"));
                lyrics_language = opt.lyrics_language[opt.lyrics_language_count-1];
            }
            else
                lyrics_language = opt.lyrics_language[i];
            fprintf(stderr, "[oggenc/oggenc.c] exit main 9\n");
        }

        fprintf(stderr, "[oggenc/oggenc.c] enter main 10\n");
        if(!strcmp(infiles[i], "-"))
        {
            setbinmode(stdin);
            in = stdin;
            infiles[i] = NULL;
            if(!opt.outfile)
            {
                setbinmode(stdout);
                out = stdout;
            }
        }
        else
        {
            in = oggenc_fopen(infiles[i], "rb", opt.isutf8);

            if(in == NULL)
            {
                fprintf(stderr, _("ERROR: Cannot open input file \"%s\": %s\n"), infiles[i], strerror(errno));
                free(out_fn);
                errors++;
                continue;
            }

            closein = 1;
        }
        fprintf(stderr, "[oggenc/oggenc.c] exit main 10\n");

        fprintf(stderr, "[oggenc/oggenc.c] enter main 11\n");
        /* Now, we need to select an input audio format - we do this before opening
           the output file so that we don't end up with a 0-byte file if the input
           file can't be read */

        if(opt.rawmode)
        {
            fprintf(stderr, "[oggenc/oggenc.c] enter main 12\n");
            enc_opts.rate=opt.raw_samplerate;
            enc_opts.channels=opt.raw_channels;
            enc_opts.samplesize=opt.raw_samplesize;
            enc_opts.endianness=opt.raw_endianness;

            format = &raw_format;
            format->open_func(in, &enc_opts, NULL, 0);
            foundformat=1;
            fprintf(stderr, "[oggenc/oggenc.c] exit main 12\n");
        }
        else
        {
            fprintf(stderr, "[oggenc/oggenc.c] enter main 13\n");
            format = open_audio_file(in, &enc_opts);
            if(format)
            {
                if(!opt.quiet)
                    fprintf(stderr, _("Opening with %s module: %s\n"),
                            format->format, format->description);
                foundformat=1;
            }
            fprintf(stderr, "[oggenc/oggenc.c] exit main 13\n");
        }
        fprintf(stderr, "[oggenc/oggenc.c] exit main 11\n");

        fprintf(stderr, "[oggenc/oggenc.c] enter main 14\n");
        if(!foundformat)
        {
            fprintf(stderr, _("ERROR: Input file \"%s\" is not a supported format\n"), infiles[i]?infiles[i]:"(stdin)");
            if(closein)
                fclose(in);
            errors++;
            format->close_func(enc_opts.readdata);
            continue;
        }
        fprintf(stderr, "[oggenc/oggenc.c] exit main 14\n");
        
        fprintf(stderr, "[oggenc/oggenc.c] enter main 15\n");
        if(enc_opts.rate <= 0)
        {
            fprintf(stderr, _("ERROR: Input file \"%s\" has invalid sampling rate\n"), infiles[i]?infiles[i]:"(stdin)");
            if(closein)
                fclose(in);
            errors++;
            format->close_func(enc_opts.readdata);
            continue;
        }
        fprintf(stderr, "[oggenc/oggenc.c] exit main 15\n");

        fprintf(stderr, "[oggenc/oggenc.c] enter main 16\n");
        /* Ok. We can read the file - so now open the output file */

        if(opt.outfile && !strcmp(opt.outfile, "-"))
        {
            setbinmode(stdout);
            out = stdout;
        }
        else if(out == NULL)
        {
            if(opt.outfile)
            {
                out_fn = strdup(opt.outfile);
            }
            else if(opt.namefmt)
            {
                out_fn = generate_name_string(opt.namefmt, opt.namefmt_remove, 
                        opt.namefmt_replace, artist, title, album, track,date,
                        genre);
            }
            /* This bit was widely derided in mid-2002, so it's been removed */
            /*
            else if(opt.title)
            {
                out_fn = malloc(strlen(title) + 5);
                strcpy(out_fn, title);
                strcat(out_fn, ".ogg");
            }
            */
            else if(infiles[i])
            {
                /* Create a filename from existing filename, replacing extension with .ogg or .oga */
                char *start, *end;
                char *extension;

                /* if adding Skeleton or Kate, we're not Vorbis I anymore */
                extension = (opt.with_skeleton || opt.lyrics_count>0) ? ".oga" : ".ogg";

                start = infiles[i];
                end = strrchr(infiles[i], '.');
                end = end?end:(start + strlen(infiles[i])+1);

                out_fn = malloc(end - start + 5);
                strncpy(out_fn, start, end-start);
                out_fn[end-start] = 0;
                strcat(out_fn, extension);
            }
            else {
                /* if adding skeleton or kate, we're not Vorbis I anymore */
                if (opt.with_skeleton || opt.lyrics_count>0)
                    out_fn = strdup("default.oga");
                else
                    out_fn = strdup("default.ogg");
                fprintf(stderr, _("WARNING: No filename, defaulting to \"%s\"\n"), out_fn);
            }

            /* Create any missing subdirectories, if possible */
            if(create_directories(out_fn, opt.isutf8)) {
                if(closein)
                    fclose(in);
                fprintf(stderr, _("ERROR: Could not create required subdirectories for output filename \"%s\"\n"), out_fn);
                errors++;
                free(out_fn);
                format->close_func(enc_opts.readdata);
                continue;
            }

            if(infiles[i] && !strcmp(infiles[i], out_fn)) {
                fprintf(stderr, _("ERROR: Input filename is the same as output filename \"%s\"\n"), out_fn);
                errors++;
                free(out_fn);
                format->close_func(enc_opts.readdata);
                continue;
            }

            out = oggenc_fopen(out_fn, "wb", opt.isutf8);
            if(out == NULL)
            {
                if(closein)
                    fclose(in);
                fprintf(stderr, _("ERROR: Cannot open output file \"%s\": %s\n"), out_fn, strerror(errno));
                errors++;
                free(out_fn);
                format->close_func(enc_opts.readdata);
                continue;
            }
            closeout = 1;
        }
        fprintf(stderr, "[oggenc/oggenc.c] exit main 16\n");

        fprintf(stderr, "[oggenc/oggenc.c] enter main 17\n");
        /* Now, set the rest of the options */
        enc_opts.out = out;
        enc_opts.comments = &vc;
#ifdef _WIN32
        enc_opts.filename = NULL;
        enc_opts.infilename = NULL;

        if (opt.isutf8) {
            if (out_fn) {
                utf8_decode(out_fn, &enc_opts.filename);
            }
            if (infiles[i]) {
                utf8_decode(infiles[i], &enc_opts.infilename);
            }
        } else {
            if (out_fn) {
                enc_opts.filename = strdup(out_fn);
            }
            if (infiles[i]) {
                enc_opts.infilename = strdup(infiles[i]);
            }
        }
#else
        enc_opts.filename = out_fn;
        enc_opts.infilename = infiles[i];
#endif
        enc_opts.managed = opt.managed;
        enc_opts.bitrate = opt.nominal_bitrate; 
        enc_opts.min_bitrate = opt.min_bitrate;
        enc_opts.max_bitrate = opt.max_bitrate;
        enc_opts.quality = opt.quality;
        enc_opts.quality_set = opt.quality_set;
        enc_opts.advopt = opt.advopt;
        enc_opts.advopt_count = opt.advopt_count;
        enc_opts.lyrics = lyrics;
        enc_opts.lyrics_language = lyrics_language;
        fprintf(stderr, "[oggenc/oggenc.c] exit main 17\n");

        fprintf(stderr, "[oggenc/oggenc.c] enter main 18\n");
        if(opt.resamplefreq && opt.resamplefreq != enc_opts.rate) {
            int fromrate = enc_opts.rate;

            resampled = 1;
            enc_opts.resamplefreq = opt.resamplefreq;
            if(setup_resample(&enc_opts)) {
                errors++;
                goto clear_all;
            }
            else if(!opt.quiet) {
                fprintf(stderr, _("Resampling input from %d Hz to %d Hz\n"), fromrate, opt.resamplefreq);
            }
        }
        fprintf(stderr, "[oggenc/oggenc.c] exit main 18\n");

        fprintf(stderr, "[oggenc/oggenc.c] enter main 19\n");
        if(opt.downmix) {
            if(enc_opts.channels == 2) {
                setup_downmix(&enc_opts);
                if(!opt.quiet) {
                    fprintf(stderr, _("Downmixing stereo to mono\n"));
                }
            }
            else {
                fprintf(stderr, _("WARNING: Can't downmix except from stereo to mono\n"));
                opt.downmix = 0;
            }
        }
        fprintf(stderr, "[oggenc/oggenc.c] exit main 19\n");

        fprintf(stderr, "[oggenc/oggenc.c] enter main 20\n");
        if(opt.scale > 0.f) {
            setup_scaler(&enc_opts, opt.scale);
            if(!opt.quiet) {
                fprintf(stderr, _("Scaling input to %f\n"), opt.scale);
            }
        }
        fprintf(stderr, "[oggenc/oggenc.c] exit main 20\n");


        fprintf(stderr, "[oggenc/oggenc.c] enter main 21\n");
        if(enc_opts.total_samples_per_channel <= 0) {
            enc_opts.progress_update = update_statistics_notime;
        }

        if(opt.quiet)
        {
            enc_opts.start_encode = start_encode_null;
            enc_opts.progress_update = update_statistics_null;
            enc_opts.end_encode = final_statistics_null;
        }
        fprintf(stderr, "[oggenc/oggenc.c] exit main 21\n");

        fprintf(stderr, "[oggenc/oggenc.c] enter main 22\n");
        if(oe_encode(&enc_opts)) {
            errors++;
        }
        fprintf(stderr, "[oggenc/oggenc.c] exit main 22\n");

        fprintf(stderr, "[oggenc/oggenc.c] enter main 23\n");
        if(opt.scale > 0) {
            clear_scaler(&enc_opts);
        }
        if(opt.downmix) {
            clear_downmix(&enc_opts);
        }
        if(resampled) {
            clear_resample(&enc_opts);
        }
clear_all:

        if(out_fn) free(out_fn);
        if(opt.outfile) free(opt.outfile);
#ifdef _WIN32
        if(enc_opts.filename) free(enc_opts.filename);
        if(enc_opts.infilename) free(enc_opts.infilename);
#endif
        vorbis_comment_clear(&vc);
        format->close_func(enc_opts.readdata);

        if(closein) {
            fclose(in);
        }
        if(closeout) {
            fclose(out);
        }
        fprintf(stderr, "[oggenc/oggenc.c] exit main 23\n");
    }/* Finished this file, loop around to next... */
    fprintf(stderr, "[oggenc/oggenc.c] exit main 7\n");

    fprintf(stderr, "[oggenc/oggenc.c] enter main 24\n");
    convert_free_charset();
    return errors?1:0;
    fprintf(stderr, "[oggenc/oggenc.c] exit main 24\n");

}

static void usage(void)
{
    fprintf(stderr, "[oggenc/oggenc.c] enter usage 1\n");
    fprintf(stdout, _("oggenc from %s %s\n"), PACKAGE, VERSION);
    fprintf(stdout, _(" by the Xiph.Org Foundation (https://www.xiph.org/)\n"));
    fprintf(stdout, _(" using encoder %s.\n\n"), vorbis_version_string());
    fprintf(stdout, _("Usage: oggenc [options] inputfile [...]\n\n"));
    fprintf(stdout, _("OPTIONS:\n"
        " General:\n"
        " -Q, --quiet          Produce no output to stderr\n"
        " -h, --help           Print this help text\n"
        " -V, --version        Print the version number\n"));
    fprintf(stderr, "[oggenc/oggenc.c] exit usage 1\n");
    
    fprintf(stderr, "[oggenc/oggenc.c] enter usage 2\n");
    fprintf(stdout, _(
        " -k, --skeleton       Adds an Ogg Skeleton bitstream\n"
        " -r, --raw            Raw mode. Input files are read directly as PCM data\n"
        " -B, --raw-bits=n     Set bits/sample for raw input; default is 16\n"
        " -C, --raw-chan=n     Set number of channels for raw input; default is 2\n"
        " -R, --raw-rate=n     Set samples/sec for raw input; default is 44100\n"
        " --raw-endianness     1 for bigendian, 0 for little (defaults to 0)\n"));
    fprintf(stderr, "[oggenc/oggenc.c] exit usage 2\n");
    
    fprintf(stderr, "[oggenc/oggenc.c] enter usage 3\n");
    fprintf(stdout, _(
        " -b, --bitrate        Choose a nominal bitrate to encode at. Attempt\n"
        "                      to encode at a bitrate averaging this. Takes an\n"
        "                      argument in kbps. By default, this produces a VBR\n"
        "                      encoding, equivalent to using -q or --quality.\n"
        "                      See the --managed option to use a managed bitrate\n"
        "                      targetting the selected bitrate.\n"));
    fprintf(stderr, "[oggenc/oggenc.c] exit usage 3\n");
    
    fprintf(stderr, "[oggenc/oggenc.c] enter usage 4\n");
    fprintf(stdout, _(
        " --managed            Enable the bitrate management engine. This will allow\n"
        "                      much greater control over the precise bitrate(s) used,\n"
        "                      but encoding will be much slower. Don't use it unless\n"
        "                      you have a strong need for detailed control over\n"
        "                      bitrate, such as for streaming.\n"));
    fprintf(stderr, "[oggenc/oggenc.c] exit usage 4\n");
    
    fprintf(stderr, "[oggenc/oggenc.c] enter usage 5\n");
    fprintf(stdout, _(
        " -m, --min-bitrate    Specify a minimum bitrate (in kbps). Useful for\n"
        "                      encoding for a fixed-size channel. Using this will\n"
        "                      automatically enable managed bitrate mode (see\n"
        "                      --managed).\n"
        " -M, --max-bitrate    Specify a maximum bitrate in kbps. Useful for\n"
        "                      streaming applications. Using this will automatically\n"
        "                      enable managed bitrate mode (see --managed).\n"));
    fprintf(stderr, "[oggenc/oggenc.c] exit usage 5\n");
    
    fprintf(stderr, "[oggenc/oggenc.c] enter usage 6\n");
    fprintf(stdout, _(
        " --advanced-encode-option option=value\n"
        "                      Sets an advanced encoder option to the given value.\n"
        "                      The valid options (and their values) are documented\n"
        "                      in the man page supplied with this program. They are\n"
        "                      for advanced users only, and should be used with\n"
        "                      caution.\n"));
    fprintf(stderr, "[oggenc/oggenc.c] exit usage 6\n");
    
    fprintf(stderr, "[oggenc/oggenc.c] enter usage 7\n");
    fprintf(stdout, _(
        " -q, --quality        Specify quality, between -1 (very low) and 10 (very\n"
        "                      high), instead of specifying a particular bitrate.\n"
        "                      This is the normal mode of operation.\n"
        "                      Fractional qualities (e.g. 2.75) are permitted\n"
        "                      The default quality level is 3.\n"));
    fprintf(stderr, "[oggenc/oggenc.c] exit usage 7\n");
    
    fprintf(stderr, "[oggenc/oggenc.c] enter usage 8\n");
    fprintf(stdout, _(
        " --resample n         Resample input data to sampling rate n (Hz)\n"
        " --downmix            Downmix stereo to mono. Only allowed on stereo\n"
        "                      input.\n"
        " -s, --serial         Specify a serial number for the stream. If encoding\n"
        "                      multiple files, this will be incremented for each\n"
        "                      stream after the first.\n"));
    fprintf(stderr, "[oggenc/oggenc.c] exit usage 8\n");
    
    fprintf(stderr, "[oggenc/oggenc.c] enter usage 9\n");
    fprintf(stdout, _(
        " --discard-comments   Prevents comments in FLAC and Ogg FLAC files from\n"
        "                      being copied to the output Ogg Vorbis file.\n"
        " --ignorelength       Ignore the datalength in Wave headers. This allows\n"
        "                      support for files > 4GB and STDIN data streams. \n"
        "\n"));
    fprintf(stderr, "[oggenc/oggenc.c] exit usage 9\n");
    
    fprintf(stderr, "[oggenc/oggenc.c] enter usage 10\n");
    fprintf(stdout, _(
        " Naming:\n"
        " -o, --output=fn      Write file to fn (only valid in single-file mode)\n"
        " -n, --names=string   Produce filenames as this string, with %%a, %%t, %%l,\n"
        "                      %%n, %%d replaced by artist, title, album, track number,\n"
        "                      and date, respectively (see below for specifying these).\n"
        "                      %%%% gives a literal %%.\n"));
    fprintf(stderr, "[oggenc/oggenc.c] exit usage 10\n");
    
    fprintf(stderr, "[oggenc/oggenc.c] enter usage 11\n");
    fprintf(stdout, _(
        " -X, --name-remove=s  Remove the specified characters from parameters to the\n"
        "                      -n format string. Useful to ensure legal filenames.\n"
        " -P, --name-replace=s Replace characters removed by --name-remove with the\n"
        "                      characters specified. If this string is shorter than the\n"
        "                      --name-remove list or is not specified, the extra\n"
        "                      characters are just removed.\n"
        "                      Default settings for the above two arguments are platform\n"
        "                      specific.\n"));
    fprintf(stderr, "[oggenc/oggenc.c] exit usage 11\n");
    
    fprintf(stderr, "[oggenc/oggenc.c] enter usage 12\n");
    fprintf(stdout, _(
        " --utf8               Tells oggenc that the command line parameters date, title,\n"
        "                      album, artist, genre, and comment are already in UTF-8.\n"
        "                      On Windows, this switch applies to file names too.\n"
        " -c, --comment=c      Add the given string as an extra comment. This may be\n"
        "                      used multiple times. The argument should be in the\n"
        "                      format \"tag=value\".\n"
        " -d, --date           Date for track (usually date of performance)\n"));
    fprintf(stderr, "[oggenc/oggenc.c] exit usage 12\n");
    
    fprintf(stderr, "[oggenc/oggenc.c] enter usage 13\n");
    fprintf(stdout, _(
        " -N, --tracknum       Track number for this track\n"
        " -t, --title          Title for this track\n"
        " -l, --album          Name of album\n"
        " -a, --artist         Name of artist\n"
        " -G, --genre          Genre of track\n"));
    fprintf(stderr, "[oggenc/oggenc.c] exit usage 13\n");
    
    fprintf(stderr, "[oggenc/oggenc.c] enter usage 14\n");
    fprintf(stdout, _(
        " -L, --lyrics         Include lyrics from given file (.srt or .lrc format)\n"
        " -Y, --lyrics-language  Sets the language for the lyrics\n"));
    fprintf(stderr, "[oggenc/oggenc.c] exit usage 14\n");
    
    fprintf(stderr, "[oggenc/oggenc.c] enter usage 15\n");
    fprintf(stdout, _(
        "                      If multiple input files are given, then multiple\n"
        "                      instances of the previous eight arguments will be used,\n"
        "                      in the order they are given. If fewer titles are\n"
        "                      specified than files, OggEnc will print a warning, and\n"
        "                      reuse the final one for the remaining files. If fewer\n"
        "                      track numbers are given, the remaining files will be\n"
        "                      unnumbered. If fewer lyrics are given, the remaining\n"
        "                      files will not have lyrics added. For the others, the\n"
        "                      final tag will be reused for all others without warning\n"
        "                      (so you can specify a date once, for example, and have\n"
        "                      it used for all the files)\n"
        "\n"));
    fprintf(stderr, "[oggenc/oggenc.c] exit usage 15\n");
    
    fprintf(stderr, "[oggenc/oggenc.c] enter usage 16\n");
    fprintf(stdout, _(
        "INPUT FILES:\n"
        " OggEnc input files must currently be 24, 16, or 8 bit PCM Wave, AIFF, or AIFF/C\n"
        " files, 32 bit IEEE floating point Wave, and optionally FLAC or Ogg FLAC. Files\n"
                "  may be mono or stereo (or more channels) and any sample rate.\n"
        " Alternatively, the --raw option may be used to use a raw PCM data file, which\n"
        " must be 16 bit stereo little-endian PCM ('headerless Wave'), unless additional\n"
        " parameters for raw mode are specified.\n"
        " You can specify taking the file from stdin by using - as the input filename.\n"
        " In this mode, output is to stdout unless an output filename is specified\n"
        " with -o\n"
        " Lyrics files may be in SubRip (.srt) or LRC (.lrc) format\n"
        "\n"));
    fprintf(stderr, "[oggenc/oggenc.c] exit usage 16\n");
}

static int strncpy_filtered(char *dst, char *src, int len, char *remove_list,
        char *replace_list)
{
    fprintf(stderr, "[oggenc/oggenc.c] enter strncpy_filtered 1\n");
    char *hit, *drop_margin;
    int used=0;

    if(remove_list == NULL || *remove_list == 0)
    {
        strncpy(dst, src, len-1);
        dst[len-1] = 0;
        return strlen(dst);
    }
    fprintf(stderr, "[oggenc/oggenc.c] exit strncpy_filtered 1\n");

    fprintf(stderr, "[oggenc/oggenc.c] enter strncpy_filtered 2\n");
    drop_margin = remove_list + (replace_list == NULL?0:strlen(replace_list));

    while(*src && used < len-1)
    {
        if((hit = strchr(remove_list, *src)) != NULL)
        {
            if(hit < drop_margin)
            {
                *dst++ = replace_list[hit - remove_list];
                used++;
            }
        }
        else
        {
            *dst++ = *src;
            used++;
        }
        src++;
    }
    *dst = 0;
    fprintf(stderr, "[oggenc/oggenc.c] exit strncpy_filtered 2\n");

    fprintf(stderr, "[oggenc/oggenc.c] enter strncpy_filtered 3\n");
    return used;
    fprintf(stderr, "[oggenc/oggenc.c] exit strncpy_filtered 3\n");
}

static char *generate_name_string(char *format, char *remove_list,
        char *replace_list, char *artist, char *title, char *album, 
        char *track, char *date, char *genre)
{
    fprintf(stderr, "[oggenc/oggenc.c] enter generate_name_string 1\n");
    char *buffer;
    char next;
    char *string;
    int used=0;
    int buflen;

    buffer = calloc(CHUNK+1,1);
    buflen = CHUNK;
    fprintf(stderr, "[oggenc/oggenc.c] exit generate_name_string 1\n");

    fprintf(stderr, "[oggenc/oggenc.c] enter generate_name_string 2\n");
    while(*format && used < buflen)
    {
        next = *format++;

        if(next == '%')
        {
            switch(*format++)
            {
                case '%':
                    *(buffer+(used++)) = '%';
                    break;
                case 'a':
                    string = artist?artist:_("(none)");
                    used += strncpy_filtered(buffer+used, string, buflen-used, 
                            remove_list, replace_list);
                    break;
                case 'd':
                    string = date?date:_("(none)");
                    used += strncpy_filtered(buffer+used, string, buflen-used,
                            remove_list, replace_list);
                    break;
                case 'g':
                    string = genre?genre:_("(none)");
                    used += strncpy_filtered(buffer+used, string, buflen-used,
                            remove_list, replace_list);
                    break;
                case 't':
                    string = title?title:_("(none)");
                    used += strncpy_filtered(buffer+used, string, buflen-used,
                            remove_list, replace_list);
                    break;
                case 'l':
                    string = album?album:_("(none)");
                    used += strncpy_filtered(buffer+used, string, buflen-used,
                            remove_list, replace_list);
                    break;
                case 'n':
                    string = track?track:_("(none)");
                    used += strncpy_filtered(buffer+used, string, buflen-used,
                            remove_list, replace_list);
                    break;
                default:
                    fprintf(stderr, _("WARNING: Ignoring illegal escape character '%c' in name format\n"), *(format - 1));
                    break;
            }
        }
        else
            *(buffer + (used++)) = next;
    }
    fprintf(stderr, "[oggenc/oggenc.c] exit generate_name_string 2\n");

    fprintf(stderr, "[oggenc/oggenc.c] enter generate_name_string 3\n");
    return buffer;
    fprintf(stderr, "[oggenc/oggenc.c] exit generate_name_string 3\n");
}
static void parse_options(int argc, char **argv, oe_options *opt)
{
    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 1\n");
    int ret;
    int option_index = 1;
    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 1\n");

    while((ret = getopt_long(argc, argv, "a:b:B:c:C:d:G:hkl:L:m:M:n:N:o:P:q:QrR:s:t:VX:Y:",
                    long_options, &option_index)) != -1)
    {
        fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 2\n");
        switch(ret)
        {
            case 0:
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 3\n");
                if(!strcmp(long_options[option_index].name, "skeleton")) {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 4\n");
                    opt->with_skeleton = 1;
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 4\n");
                }
                else if(!strcmp(long_options[option_index].name, "managed")) {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 5\n");
                    if(!opt->managed){
                        fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 6\n");
                        if(!opt->quiet)
                            fprintf(stderr, 
                                    _("Enabling bitrate management engine\n"));
                        opt->managed = 1;
                        fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 6\n");
                    }
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 5\n");
                }
                else if(!strcmp(long_options[option_index].name, 
                            "raw-endianness")) {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 7\n");
                    if (opt->rawmode != 1)
                    {
                        fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 8\n");
                        opt->rawmode = 1;
                        fprintf(stderr, _("WARNING: Raw endianness specified for non-raw data. Assuming input is raw.\n"));
                        fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 8\n");
                    }
                    if(sscanf(optarg, "%d", &opt->raw_endianness) != 1) {
                        fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 9\n");
                        fprintf(stderr, _("WARNING: Couldn't read endianness argument \"%s\"\n"), optarg);
                        opt->raw_endianness = 0;
                        fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 9\n");
                    }
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 7\n");
                }
                else if(!strcmp(long_options[option_index].name,
                            "resample")) {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 10\n");
                    if(sscanf(optarg, "%d", &opt->resamplefreq) != 1) {
                        fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 11\n");
                        fprintf(stderr, _("WARNING: Couldn't read resampling frequency \"%s\"\n"), optarg);
                        opt->resamplefreq = 0;
                        fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 11\n");
                    }
                    if(opt->resamplefreq < 100) { /* User probably specified it
                                                     in kHz accidently */
                        fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 12\n");
                        fprintf(stderr, 
                                _("WARNING: Resample rate specified as %d Hz. Did you mean %d Hz?\n"), 
                                opt->resamplefreq, opt->resamplefreq*1000);
                        fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 12\n");
                    }
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 10\n");
                }
                else if(!strcmp(long_options[option_index].name, "downmix")) {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 13\n");
                    opt->downmix = 1;
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 13\n");
                }
                else if(!strcmp(long_options[option_index].name, "scale")) {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 14\n");
                    opt->scale = atof(optarg);
                    if(sscanf(optarg, "%f", &opt->scale) != 1) {
                        fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 15\n");
                        opt->scale = 0;
                        fprintf(stderr, _("WARNING: Couldn't parse scaling factor \"%s\"\n"), 
                                optarg);
                        fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 15\n");
                    }
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 14\n");
                }
                else if(!strcmp(long_options[option_index].name, "utf8")) {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 16\n");
                    opt->isutf8 = 1;
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 16\n");
                }
                else if(!strcmp(long_options[option_index].name, "advanced-encode-option")) {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 17\n");
                    char *arg = strdup(optarg);
                    char *val;

                    if(strcmp("disable_coupling",arg)){
                      fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 18\n");
                      val = strchr(arg, '=');
                      if(val == NULL) {
                        fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 19\n");
                        fprintf(stderr, _("No value for advanced encoder option found\n"));
                        continue;
                        fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 19\n");
                      }
                      else {
                        fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 20\n");
                        *val++=0;
                        fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 20\n");
                      }
                      fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 18\n");
                    }else {
                      fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 21\n");
                      val=0;
                      fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 21\n");
                    }

                    opt->advopt = realloc(opt->advopt, (++opt->advopt_count)*sizeof(adv_opt));
                    opt->advopt[opt->advopt_count - 1].arg = arg;
                    opt->advopt[opt->advopt_count - 1].val = val;
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 17\n");
                }
                else if(!strcmp(long_options[option_index].name, "discard-comments")) {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 22\n");
                    opt->copy_comments = 0;
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 22\n");
                }
                else if(!strcmp(long_options[option_index].name, "ignorelength")) {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 23\n");
                    opt->ignorelength = 1;
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 23\n");
                }

                else {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 24\n");
                    fprintf(stderr, _("Internal error parsing command line options\n"));
                    exit(1);
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 24\n");
                }

                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 3\n");
                break;
            case 'a':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 25\n");
                opt->artist = realloc(opt->artist, (++opt->artist_count)*sizeof(char *));
                opt->artist[opt->artist_count - 1] = strdup(optarg);
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 25\n");
                break;
            case 'c':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 26\n");
                if(strchr(optarg, '=') == NULL) {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 27\n");
                    fprintf(stderr, _("WARNING: Illegal comment used (\"%s\"), ignoring.\n"), optarg);
                    break;
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 27\n");
                }
                opt->comments = realloc(opt->comments, (++opt->comment_count)*sizeof(char *));
                opt->comments[opt->comment_count - 1] = strdup(optarg);
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 26\n");
                break;
            case 'd':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 28\n");
                opt->dates = realloc(opt->dates, (++opt->date_count)*sizeof(char *));
                opt->dates[opt->date_count - 1] = strdup(optarg);
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 28\n");
                break;
            case 'G':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 29\n");
                opt->genre = realloc(opt->genre, (++opt->genre_count)*sizeof(char *));
                opt->genre[opt->genre_count - 1] = strdup(optarg);
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 29\n");
                break;
            case 'h':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 30\n");
                usage();
                exit(0);
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 30\n");
                break;
            case 'l':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 31\n");
                opt->album = realloc(opt->album, (++opt->album_count)*sizeof(char *));
                opt->album[opt->album_count - 1] = strdup(optarg);
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 31\n");
                break;
            case 's':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 32\n");
                /* Would just use atoi(), but that doesn't deal with unsigned
                 * ints. Damn */
                if(sscanf(optarg, "%u", &opt->serial) != 1) {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 33\n");
                    opt->serial = 0; /* Failed, so just set to zero */
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 33\n");
                }
                else {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 34\n");
                    opt->fixedserial = 1;
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 34\n");
                }
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 32\n");
                break;
            case 't':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 35\n");
                opt->title = realloc(opt->title, (++opt->title_count)*sizeof(char *));
                opt->title[opt->title_count - 1] = strdup(optarg);
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 35\n");
                break;
            case 'b':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 36\n");
                   if(sscanf(optarg, "%d", &opt->nominal_bitrate)
                        != 1) {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 37\n");
                    fprintf(stderr, _("WARNING: nominal bitrate \"%s\" not recognised\n"), optarg);
                    opt->nominal_bitrate = -1;
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 37\n");
                }
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 36\n");
                break;
            case 'm':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 38\n");
                if(sscanf(optarg, "%d", &opt->min_bitrate)
                        != 1) {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 39\n");
                    fprintf(stderr, _("WARNING: minimum bitrate \"%s\" not recognised\n"), optarg);
                    opt->min_bitrate = -1;
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 39\n");
                }
                if(!opt->managed){
                  fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 40\n");
                  if(!opt->quiet) {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 41\n");
                    fprintf(stderr, 
                        _("Enabling bitrate management engine\n"));
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 41\n");
                  }
                  opt->managed = 1;
                  fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 40\n");
                }
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 38\n");
                break;
            case 'M':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 42\n");
                if(sscanf(optarg, "%d", &opt->max_bitrate)
                        != 1) {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 43\n");
                    fprintf(stderr, _("WARNING: maximum bitrate \"%s\" not recognised\n"), optarg);
                    opt->max_bitrate = -1;
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 43\n");
                }
                if(!opt->managed){
                  fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 44\n");
                  if(!opt->quiet) {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 45\n");
                    fprintf(stderr, 
                        _("Enabling bitrate management engine\n"));
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 45\n");
                  }
                  opt->managed = 1;
                  fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 44\n");
                }
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 42\n");
                break;
            case 'q':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 46\n");
                if(sscanf(optarg, "%f", &opt->quality) != 1) {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 47\n");
                    fprintf(stderr, _("Quality option \"%s\" not recognised, ignoring\n"), optarg);
                    break;
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 47\n");
                }
                opt->quality_set=1;
                if(opt->quality > 10.0f)
                {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 48\n");
                    opt->quality = 10.0f;
                    fprintf(stderr, _("WARNING: quality setting too high, setting to maximum quality.\n"));
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 48\n");
                }
                opt->quality *= 0.1;
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 46\n");
                break;
            case 'n':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 49\n");
                if(opt->namefmt)
                {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 50\n");
                    fprintf(stderr, _("WARNING: Multiple name formats specified, using final\n"));
                    free(opt->namefmt);
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 50\n");
                }
                opt->namefmt = strdup(optarg);
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 49\n");
                break;
            case 'X':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 51\n");
                if(opt->namefmt_remove &&
                        strcmp(opt->namefmt_remove, DEFAULT_NAMEFMT_REMOVE))
                {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 52\n");
                    fprintf(stderr, _("WARNING: Multiple name format filters specified, using final\n"));
                    free(opt->namefmt_remove);
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 52\n");
                }
                opt->namefmt_remove = strdup(optarg);
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 51\n");
                break;
            case 'P':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 53\n");
                if(opt->namefmt_replace &&
                        strcmp(opt->namefmt_replace, DEFAULT_NAMEFMT_REPLACE))
                {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 54\n");
                    fprintf(stderr, _("WARNING: Multiple name format filter replacements specified, using final\n"));
                    free(opt->namefmt_replace);
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 54\n");
                }
                opt->namefmt_replace = strdup(optarg);
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 53\n");
                break;
            case 'o':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 55\n");
                if(opt->outfile)
                {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 56\n");
                    fprintf(stderr, _("WARNING: Multiple output files specified, suggest using -n\n"));
                    free(opt->outfile);
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 56\n");
                }
                opt->outfile = strdup(optarg);
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 55\n");
                break;
            case 'Q':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 57\n");
                opt->quiet = 1;
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 57\n");
                break;
            case 'r':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 58\n");
                opt->rawmode = 1;
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 58\n");
                break;
            case 'V':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 59\n");
                fprintf(stdout, _("oggenc from %s %s\n"), PACKAGE, VERSION);
                exit(0);
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 59\n");
                break;
            case 'B':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 60\n");
                if (opt->rawmode != 1)
                {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 61\n");
                    opt->rawmode = 1;
                    fprintf(stderr, _("WARNING: Raw bits/sample specified for non-raw data. Assuming input is raw.\n"));
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 61\n");
                }
                if(sscanf(optarg, "%u", &opt->raw_samplesize) != 1)
                {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 62\n");
                    opt->raw_samplesize = 16; /* Failed, so just set to 16 */
                    fprintf(stderr, _("WARNING: Invalid bits/sample specified, assuming 16.\n"));
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 62\n");
                }
                if((opt->raw_samplesize != 8) && (opt->raw_samplesize != 16))
                {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 63\n");
                    fprintf(stderr, _("WARNING: Invalid bits/sample specified, assuming 16.\n"));
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 63\n");
                }
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 60\n");
                break;
            case 'C':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 64\n");
                if (opt->rawmode != 1)
                {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 65\n");
                    opt->rawmode = 1;
                    fprintf(stderr, _("WARNING: Raw channel count specified for non-raw data. Assuming input is raw.\n"));
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 65\n");
                }
                if(sscanf(optarg, "%u", &opt->raw_channels) != 1)
                {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 66\n");
                    opt->raw_channels = 2; /* Failed, so just set to 2 */
                    fprintf(stderr, _("WARNING: Invalid channel count specified, assuming 2.\n"));
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 66\n");
                }
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 64\n");
                break;
            case 'N':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 67\n");
                opt->tracknum = realloc(opt->tracknum, (++opt->track_count)*sizeof(char *));
                opt->tracknum[opt->track_count - 1] = strdup(optarg);
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 67\n");
                break;
            case 'R':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 68\n");
                if (opt->rawmode != 1)
                {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 69\n");
                    opt->rawmode = 1;
                    fprintf(stderr, _("WARNING: Raw sample rate specified for non-raw data. Assuming input is raw.\n"));
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 69\n");
                }
                if(sscanf(optarg, "%u", &opt->raw_samplerate) != 1)
                {
                    fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 70\n");
                    opt->raw_samplerate = 44100; /* Failed, so just set to 44100 */
                    fprintf(stderr, _("WARNING: Invalid sample rate specified, assuming 44100.\n"));
                    fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 70\n");
                }
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 68\n");
                break;
            case 'k':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 71\n");
                opt->with_skeleton = 1;
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 71\n");
                break;
            case 'L':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 72\n");
#ifdef HAVE_KATE
                opt->lyrics = realloc(opt->lyrics, (++opt->lyrics_count)*sizeof(char *));
                opt->lyrics[opt->lyrics_count - 1] = strdup(optarg);
                opt->with_skeleton = 1;
#else
                fprintf(stderr, _("WARNING: Kate support not compiled in; lyrics will not be included.\n"));
#endif
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 72\n");
                break;
            case 'Y':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 73\n");
#ifdef HAVE_KATE
                opt->lyrics_language = realloc(opt->lyrics_language, (++opt->lyrics_language_count)*sizeof(char *));
                opt->lyrics_language[opt->lyrics_language_count - 1] = strdup(optarg);
                if (strlen(opt->lyrics_language[opt->lyrics_language_count - 1]) > 15) {
                  fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 74\n");
                  fprintf(stderr, _("WARNING: language can not be longer than 15 characters; truncated.\n"));
                  opt->lyrics_language[opt->lyrics_language_count - 1][15] = 0;
                  fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 74\n");
                }
#else
                fprintf(stderr, _("WARNING: Kate support not compiled in; lyrics will not be included.\n"));
#endif
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 73\n");
                break;
            case '?':
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 75\n");
                fprintf(stderr, _("WARNING: Unknown option specified, ignoring->\n"));
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 75\n");
                break;
            default:
                fprintf(stderr, "[oggenc/oggenc.c] enter parse_options 76\n");
                usage();
                exit(0);
                fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 76\n");
        }
        fprintf(stderr, "[oggenc/oggenc.c] exit parse_options 2\n");
    }

}

static void add_tag(vorbis_comment *vc, oe_options *opt,char *name, char *value)
{
    fprintf(stderr, "[oggenc/oggenc.c] enter add_tag 1\n");
    char *utf8;
    if (opt->isutf8)
    {
        fprintf(stderr, "[oggenc/oggenc.c] enter add_tag 2\n");
	if (!utf8_validate(value)) {
	    fprintf(stderr, "[oggenc/oggenc.c] enter add_tag 3\n");
	    fprintf(stderr, _("'%s' is not valid UTF-8, cannot add\n"), name?name:"comment");
	    fprintf(stderr, "[oggenc/oggenc.c] exit add_tag 3\n");
	} else {
	    fprintf(stderr, "[oggenc/oggenc.c] enter add_tag 4\n");
	    if(name == NULL) {
	        fprintf(stderr, "[oggenc/oggenc.c] enter add_tag 5\n");
		vorbis_comment_add(vc, value);
		fprintf(stderr, "[oggenc/oggenc.c] exit add_tag 5\n");
            }
            else {
	        fprintf(stderr, "[oggenc/oggenc.c] enter add_tag 6\n");
		vorbis_comment_add_tag(vc, name, value);
		fprintf(stderr, "[oggenc/oggenc.c] exit add_tag 6\n");
            }
	    fprintf(stderr, "[oggenc/oggenc.c] exit add_tag 4\n");
	}
	fprintf(stderr, "[oggenc/oggenc.c] exit add_tag 2\n");
    }
    else if(utf8_encode(value, &utf8) >= 0)
    {
        fprintf(stderr, "[oggenc/oggenc.c] enter add_tag 7\n");
        if(name == NULL) {
            fprintf(stderr, "[oggenc/oggenc.c] enter add_tag 8\n");
            vorbis_comment_add(vc, utf8);
            fprintf(stderr, "[oggenc/oggenc.c] exit add_tag 8\n");
        }
        else {
            fprintf(stderr, "[oggenc/oggenc.c] enter add_tag 9\n");
            vorbis_comment_add_tag(vc, name, utf8);
            fprintf(stderr, "[oggenc/oggenc.c] exit add_tag 9\n");
        }
        free(utf8);
        fprintf(stderr, "[oggenc/oggenc.c] exit add_tag 7\n");
    }
    else {
        fprintf(stderr, "[oggenc/oggenc.c] enter add_tag 10\n");
        fprintf(stderr, _("Couldn't convert comment to UTF-8, cannot add\n"));
        fprintf(stderr, "[oggenc/oggenc.c] exit add_tag 10\n");
    }
    fprintf(stderr, "[oggenc/oggenc.c] exit add_tag 1\n");
}

static void build_comments(vorbis_comment *vc, oe_options *opt, int filenum, 
        char **artist, char **album, char **title, char **tracknum, 
        char **date, char **genre)
{
    fprintf(stderr, "[oggenc/oggenc.c] enter build_comments 1\n");
    int i;

    vorbis_comment_init(vc);
    fprintf(stderr, "[oggenc/oggenc.c] exit build_comments 1\n");

    for(i = 0; i < opt->comment_count; i++) {
        fprintf(stderr, "[oggenc/oggenc.c] enter build_comments 2\n");
        add_tag(vc, opt, NULL, opt->comments[i]);
        fprintf(stderr, "[oggenc/oggenc.c] exit build_comments 2\n");
    }

    if(opt->title_count)
    {
        fprintf(stderr, "[oggenc/oggenc.c] enter build_comments 3\n");
        if(filenum >= opt->title_count)
        {
            fprintf(stderr, "[oggenc/oggenc.c] enter build_comments 4\n");
            if(!opt->quiet) {
                fprintf(stderr, "[oggenc/oggenc.c] enter build_comments 5\n");
                fprintf(stderr, _("WARNING: Insufficient titles specified, defaulting to final title.\n"));
                fprintf(stderr, "[oggenc/oggenc.c] exit build_comments 5\n");
            }
            i = opt->title_count-1;
            fprintf(stderr, "[oggenc/oggenc.c] exit build_comments 4\n");
        }
        else {
            fprintf(stderr, "[oggenc/oggenc.c] enter build_comments 6\n");
            i = filenum;
            fprintf(stderr, "[oggenc/oggenc.c] exit build_comments 6\n");
        }

        *title = opt->title[i];
        add_tag(vc, opt, "title", opt->title[i]);
        fprintf(stderr, "[oggenc/oggenc.c] exit build_comments 3\n");
    }

    if(opt->artist_count)
    {
        fprintf(stderr, "[oggenc/oggenc.c] enter build_comments 7\n");
        if(filenum >= opt->artist_count) {
            fprintf(stderr, "[oggenc/oggenc.c] enter build_comments 8\n");
            i = opt->artist_count-1;
            fprintf(stderr, "[oggenc/oggenc.c] exit build_comments 8\n");
        }
        else {
            fprintf(stderr, "[oggenc/oggenc.c] enter build_comments 9\n");
            i = filenum;
            fprintf(stderr, "[oggenc/oggenc.c] exit build_comments 9\n");
        }

        *artist = opt->artist[i];
        add_tag(vc, opt, "artist", opt->artist[i]);
        fprintf(stderr, "[oggenc/oggenc.c] exit build_comments 7\n");
    }

    if(opt->genre_count)
    {
        fprintf(stderr, "[oggenc/oggenc.c] enter build_comments 10\n");
        if(filenum >= opt->genre_count) {
            fprintf(stderr, "[oggenc/oggenc.c] enter build_comments 11\n");
            i = opt->genre_count-1;
            fprintf(stderr, "[oggenc/oggenc.c] exit build_comments 11\n");
        }
        else {
            fprintf(stderr, "[oggenc/oggenc.c] enter build_comments 12\n");
            i = filenum;
            fprintf(stderr, "[oggenc/oggenc.c] exit build_comments 12\n");
        }

        *genre = opt->genre[i];
        add_tag(vc, opt, "genre", opt->genre[i]);
        fprintf(stderr, "[oggenc/oggenc.c] exit build_comments 10\n");
    }

    if(opt->date_count)
    {
        fprintf(stderr, "[oggenc/oggenc.c] enter build_comments 13\n");
        if(filenum >= opt->date_count) {
            fprintf(stderr, "[oggenc/oggenc.c] enter build_comments 14\n");
            i = opt->date_count-1;
            fprintf(stderr, "[oggenc/oggenc.c] exit build_comments 14\n");
        }
        else {
            fprintf(stderr, "[oggenc/oggenc.c] enter build_comments 15\n");
            i = filenum;
            fprintf(stderr, "[oggenc/oggenc.c] exit build_comments 15\n");
        }

        *date = opt->dates[i];
        add_tag(vc, opt, "date", opt->dates[i]);
        fprintf(stderr, "[oggenc/oggenc.c] exit build_comments 13\n");
    }

    if(opt->album_count)
    {
        fprintf(stderr, "[oggenc/oggenc.c] enter build_comments 16\n");
        if(filenum >= opt->album_count)
        {
            fprintf(stderr, "[oggenc/oggenc.c] enter build_comments 17\n");
            i = opt->album_count-1;
            fprintf(stderr, "[oggenc/oggenc.c] exit build_comments 17\n");
        }
        else {
            fprintf(stderr, "[oggenc/oggenc.c] enter build_comments 18\n");
            i = filenum;
            fprintf(stderr, "[oggenc/oggenc.c] exit build_comments 18\n");
        }

        *album = opt->album[i];
        add_tag(vc, opt, "album", opt->album[i]);
        fprintf(stderr, "[oggenc/oggenc.c] exit build_comments 16\n");
    }

    if(filenum < opt->track_count)
    {
        fprintf(stderr, "[oggenc/oggenc.c] enter build_comments 19\n");
        i = filenum;
        *tracknum = opt->tracknum[i];
        add_tag(vc, opt, "tracknumber", opt->tracknum[i]);
        fprintf(stderr, "[oggenc/oggenc.c] exit build_comments 19\n");
    }
}
// Total cost: 0.452707
// Total split cost: 0.094326, input tokens: 27984, output tokens: 301, cache read tokens: 15209, cache write tokens: 12513, split chunks: [(0, 735), (735, 1164)]
// Total instrumented cost: 0.358381, input tokens: 17001, output tokens: 17224, cache read tokens: 2280, cache write tokens: 14713

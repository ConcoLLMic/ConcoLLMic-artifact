/* OggEnc
 **
 ** This program is distributed under the GNU General Public License, version 2.
 ** A copy of this license is included with this source.
 **
 ** This particular file may also be distributed under (at your option) any
 ** later version of the GNU General Public License.
 **
 ** Copyright 2008, ogg.k.ogg.k <ogg.k.ogg.k@googlemail.com>
 **
 ** Portions from ffmpeg2theora, (c) j <j@v2v.cc>
 **/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <errno.h>

#ifdef HAVE_KATE
#include <kate/oggkate.h>
#endif

#include "lyrics.h"
#include "utf8.h"
#include "i18n.h"

typedef enum {
  lf_unknown,
  lf_srt,
  lf_lrc,
} lyrics_format;

#ifdef HAVE_KATE

static char *fgets2(char *s,size_t sz,FILE *f)
{
    fprintf(stderr, "[oggenc/lyrics.c] enter fgets2 1\n");
    char *ret = fgets(s, sz, f);
    if (ret) {
      fprintf(stderr, "[oggenc/lyrics.c] enter fgets2 2\n");
      /* fixup DOS newline character */
      char *ptr=strchr(ret, '\r');
      if (ptr) {
        fprintf(stderr, "[oggenc/lyrics.c] enter fgets2 3\n");
        *ptr='\n';
        *(ptr+1)=0;
        fprintf(stderr, "[oggenc/lyrics.c] exit fgets2 3\n");
      }
      fprintf(stderr, "[oggenc/lyrics.c] exit fgets2 2\n");
    }
    return ret;
    fprintf(stderr, "[oggenc/lyrics.c] exit fgets2 1\n");
}

static double hmsms2s(int h,int m,int s,int ms)
{
    fprintf(stderr, "[oggenc/lyrics.c] enter hmsms2s 1\n");
    return h*3600+m*60+s+ms/1000.0;
    fprintf(stderr, "[oggenc/lyrics.c] exit hmsms2s 1\n");
}

static int add_lyrics(oe_lyrics *lyrics, char *text, kate_motion *km, double t0,double t1)
{
  fprintf(stderr, "[oggenc/lyrics.c] enter add_lyrics 1\n");
  size_t len;
  int ret;
  char *utf8;

  ret=utf8_encode(text,&utf8);
  if (ret<0) {
    fprintf(stderr, "[oggenc/lyrics.c] enter add_lyrics 2\n");
    fprintf(stderr,_("Failed to convert to UTF-8: %s\n"),text);
    return ret;
    fprintf(stderr, "[oggenc/lyrics.c] exit add_lyrics 2\n");
  }

  lyrics->lyrics = (oe_lyrics_item*)realloc(lyrics->lyrics, (lyrics->count+1)*sizeof(oe_lyrics_item));
  if (!lyrics->lyrics) {
    fprintf(stderr, "[oggenc/lyrics.c] enter add_lyrics 3\n");
    free(utf8);
    fprintf(stderr, _("Out of memory\n"));
    return -1;
    fprintf(stderr, "[oggenc/lyrics.c] exit add_lyrics 3\n");
  }
  len = strlen(utf8);
  ret=kate_text_validate(kate_utf8,utf8,len+1);
  if (ret<0) {
    fprintf(stderr, "[oggenc/lyrics.c] enter add_lyrics 4\n");
    fprintf(stderr,_("WARNING: subtitle %s is not valid UTF-8\n"),utf8);
    free(utf8);
    fprintf(stderr, "[oggenc/lyrics.c] exit add_lyrics 4\n");
  }
  else {
    fprintf(stderr, "[oggenc/lyrics.c] enter add_lyrics 5\n");
    /* kill off trailing \n characters */
    while (len>0) {
      fprintf(stderr, "[oggenc/lyrics.c] enter add_lyrics 6\n");
      if (utf8[len-1]=='\n') utf8[--len]=0; else break;
      fprintf(stderr, "[oggenc/lyrics.c] exit add_lyrics 6\n");
    }
    lyrics->lyrics[lyrics->count].text = utf8;
    lyrics->lyrics[lyrics->count].len = len;
    lyrics->lyrics[lyrics->count].t0 = t0;
    lyrics->lyrics[lyrics->count].t1 = t1;
    lyrics->lyrics[lyrics->count].km = km;
    lyrics->count++;
    fprintf(stderr, "[oggenc/lyrics.c] exit add_lyrics 5\n");
  }
  return 0;
  fprintf(stderr, "[oggenc/lyrics.c] exit add_lyrics 1\n");
}

static int is_line_empty(const char *s)
{
  fprintf(stderr, "[oggenc/lyrics.c] enter is_line_empty 1\n");
  /* will work fine with UTF-8 despite the appearance */
  if (s) while (*s) {
    fprintf(stderr, "[oggenc/lyrics.c] enter is_line_empty 2\n");
    if (!strchr(" \t\r\n",*s)) return 0;
    ++s;
    fprintf(stderr, "[oggenc/lyrics.c] exit is_line_empty 2\n");
  }
  return 1;
  fprintf(stderr, "[oggenc/lyrics.c] exit is_line_empty 1\n");
}

static oe_lyrics *load_srt_lyrics(FILE *f)
{
    fprintf(stderr, "[oggenc/lyrics.c] enter load_srt_lyrics 1\n");
    enum { need_id, need_timing, need_text };
    int need = need_id;
    int last_seen_id=0;
    int ret;
    int id;
    static char text[4096];
    static char str[4096];
    int h0,m0,s0,ms0,h1,m1,s1,ms1;
    double t0=0.0;
    double t1=0.0;
    oe_lyrics *lyrics;
    unsigned int line=0;

    if (!f) return NULL;

    lyrics=(oe_lyrics*)malloc(sizeof(oe_lyrics));
    if (!lyrics) return NULL;
    lyrics->count = 0;
    lyrics->lyrics = NULL;
    lyrics->karaoke = 0;

    fgets2(str,sizeof(str),f);
    ++line;
    while (!feof(f)) {
      fprintf(stderr, "[oggenc/lyrics.c] enter load_srt_lyrics 2\n");
      switch (need) {
        case need_id:
          fprintf(stderr, "[oggenc/lyrics.c] enter load_srt_lyrics 3\n");
          if (is_line_empty(str)) {
            fprintf(stderr, "[oggenc/lyrics.c] enter load_srt_lyrics 4\n");
            /* be nice and ignore extra empty lines between records */
            fprintf(stderr, "[oggenc/lyrics.c] exit load_srt_lyrics 4\n");
          }
          else {
            fprintf(stderr, "[oggenc/lyrics.c] enter load_srt_lyrics 5\n");
            ret=sscanf(str,"%d\n",&id);
            if (ret!=1 || id<0) {
              fprintf(stderr, "[oggenc/lyrics.c] enter load_srt_lyrics 6\n");
              fprintf(stderr,_("ERROR - line %u: Syntax error: %s\n"),line,str);
              free_lyrics(lyrics);
              return NULL;
              fprintf(stderr, "[oggenc/lyrics.c] exit load_srt_lyrics 6\n");
            }
            if (id!=last_seen_id+1) {
              fprintf(stderr, "[oggenc/lyrics.c] enter load_srt_lyrics 7\n");
              fprintf(stderr,_("WARNING - line %u: non consecutive ids: %s - pretending not to have noticed\n"),line,str);
              fprintf(stderr, "[oggenc/lyrics.c] exit load_srt_lyrics 7\n");
            }
            last_seen_id=id;
            need=need_timing;
            strcpy(text,"");
            fprintf(stderr, "[oggenc/lyrics.c] exit load_srt_lyrics 5\n");
          }
          fprintf(stderr, "[oggenc/lyrics.c] exit load_srt_lyrics 3\n");
          break;
        case need_timing:
          fprintf(stderr, "[oggenc/lyrics.c] enter load_srt_lyrics 8\n");
          /* we could use %u, but glibc accepts minus signs for %u for some reason */
          ret=sscanf(str,"%d:%d:%d%*[.,]%d --> %d:%d:%d%*[.,]%d\n",&h0,&m0,&s0,&ms0,&h1,&m1,&s1,&ms1);
          if (ret!=8 || (h0|m0|s0|ms0)<0 || (h1|m1|s1|ms1)<0) {
            fprintf(stderr, "[oggenc/lyrics.c] enter load_srt_lyrics 9\n");
            fprintf(stderr,_("ERROR - line %u: Syntax error: %s\n"),line,str);
            free_lyrics(lyrics);
            return NULL;
            fprintf(stderr, "[oggenc/lyrics.c] exit load_srt_lyrics 9\n");
          }
          else if (t1<t0) {
            fprintf(stderr, "[oggenc/lyrics.c] enter load_srt_lyrics 10\n");
            fprintf(stderr,_("ERROR - line %u: end time must not be less than start time: %s\n"),line,str);
           free_lyrics(lyrics);
            return NULL;
            fprintf(stderr, "[oggenc/lyrics.c] exit load_srt_lyrics 10\n");
          }
          else {
            fprintf(stderr, "[oggenc/lyrics.c] enter load_srt_lyrics 11\n");
            t0=hmsms2s(h0,m0,s0,ms0);
            t1=hmsms2s(h1,m1,s1,ms1);
            fprintf(stderr, "[oggenc/lyrics.c] exit load_srt_lyrics 11\n");
          }
          need=need_text;
          fprintf(stderr, "[oggenc/lyrics.c] exit load_srt_lyrics 8\n");
          break;
        case need_text:
          fprintf(stderr, "[oggenc/lyrics.c] enter load_srt_lyrics 12\n");
          if (str[0]=='\n') {
            fprintf(stderr, "[oggenc/lyrics.c] enter load_srt_lyrics 13\n");
            if (add_lyrics(lyrics,text,NULL,t0,t1) < 0) {
              fprintf(stderr, "[oggenc/lyrics.c] enter load_srt_lyrics 14\n");
              free_lyrics(lyrics);
              return NULL;
              fprintf(stderr, "[oggenc/lyrics.c] exit load_srt_lyrics 14\n");
            }
            need=need_id;
            fprintf(stderr, "[oggenc/lyrics.c] exit load_srt_lyrics 13\n");
          }
          else {
            fprintf(stderr, "[oggenc/lyrics.c] enter load_srt_lyrics 15\n");
            /* in case of very long lines */
            size_t len=strlen(text);
            if (len+strlen(str) >= sizeof(text)) {
              fprintf(stderr, "[oggenc/lyrics.c] enter load_srt_lyrics 16\n");
              fprintf(stderr, _("WARNING - line %u: text is too long - truncated\n"),line);
              fprintf(stderr, "[oggenc/lyrics.c] exit load_srt_lyrics 16\n");
            }
            strncpy(text+len,str,sizeof(text)-len);
            text[sizeof(text)-1]=0;
            fprintf(stderr, "[oggenc/lyrics.c] exit load_srt_lyrics 15\n");
          }
          fprintf(stderr, "[oggenc/lyrics.c] exit load_srt_lyrics 12\n");
          break;
      }
      fgets2(str,sizeof(str),f);
      ++line;
      fprintf(stderr, "[oggenc/lyrics.c] exit load_srt_lyrics 2\n");
    }

    if (need!=need_id) {
      fprintf(stderr, "[oggenc/lyrics.c] enter load_srt_lyrics 17\n");
      /* shouldn't be a problem though, but warn */
      fprintf(stderr, _("WARNING - line %u: missing data - truncated file?\n"),line);
      fprintf(stderr, "[oggenc/lyrics.c] exit load_srt_lyrics 17\n");
    }

    return lyrics;
    fprintf(stderr, "[oggenc/lyrics.c] exit load_srt_lyrics 1\n");
}

static void add_kate_karaoke_tag(kate_motion *km,kate_float dt,const char *str,size_t len,int line)
{
  fprintf(stderr, "[oggenc/lyrics.c] enter add_kate_karaoke_tag 1\n");
  kate_curve *kc;
  kate_float ptr=(kate_float)-0.5;
  int ret;

  if (dt<0) {
    fprintf(stderr, "[oggenc/lyrics.c] enter add_kate_karaoke_tag 2\n");
    fprintf(stderr, _("WARNING - line %d: lyrics times must not be decreasing\n"), line);
    return;
    fprintf(stderr, "[oggenc/lyrics.c] exit add_kate_karaoke_tag 2\n");
  }

  /* work out how many glyphs we have */
  while (len>0) {
    fprintf(stderr, "[oggenc/lyrics.c] enter add_kate_karaoke_tag 3\n");
    ret=kate_text_get_character(kate_utf8,&str,&len);
    if (ret<0) {
      fprintf(stderr, "[oggenc/lyrics.c] enter add_kate_karaoke_tag 4\n");
      fprintf(stderr, _("WARNING - line %d: failed to get UTF-8 glyph from string\n"), line);
      return;
      fprintf(stderr, "[oggenc/lyrics.c] exit add_kate_karaoke_tag 4\n");
    }
    ptr+=(kate_float)1.0;
    fprintf(stderr, "[oggenc/lyrics.c] exit add_kate_karaoke_tag 3\n");
  }
  /* ptr now points to the middle of the glyph we're at */

  kc=(kate_curve*)malloc(sizeof(kate_curve));
  kate_curve_init(kc);
  kc->type=kate_curve_static;
  kc->npts=1;
  kc->pts=(kate_float*)malloc(2*sizeof(kate_float));
  kc->pts[0]=ptr;
  kc->pts[1]=(kate_float)0;

  km->ncurves++;
  km->curves=(kate_curve**)realloc(km->curves,km->ncurves*sizeof(kate_curve*));
  km->durations=(kate_float*)realloc(km->durations,km->ncurves*sizeof(kate_float));
  km->curves[km->ncurves-1]=kc;
  km->durations[km->ncurves-1]=dt;
  fprintf(stderr, "[oggenc/lyrics.c] exit add_kate_karaoke_tag 1\n");
}

static int fraction_to_milliseconds(int fraction,int digits)
{
  fprintf(stderr, "[oggenc/lyrics.c] enter fraction_to_milliseconds 1\n");
  while (digits<3) {
    fprintf(stderr, "[oggenc/lyrics.c] enter fraction_to_milliseconds 2\n");
    fraction*=10;
    ++digits;
    fprintf(stderr, "[oggenc/lyrics.c] exit fraction_to_milliseconds 2\n");
  }
  while (digits>3) {
    fprintf(stderr, "[oggenc/lyrics.c] enter fraction_to_milliseconds 3\n");
    fraction/=10;
    --digits;
    fprintf(stderr, "[oggenc/lyrics.c] exit fraction_to_milliseconds 3\n");
  }
  return fraction;
  fprintf(stderr, "[oggenc/lyrics.c] exit fraction_to_milliseconds 1\n");
}

static kate_motion *process_enhanced_lrc_tags(char *str,kate_float start_time,kate_float end_time,int line)
{
  fprintf(stderr, "[oggenc/lyrics.c] enter process_enhanced_lrc_tags 1\n");
  char *start,*end;
  int ret;
  int m,s,fs;
  kate_motion *km=NULL;
  kate_float current_time = start_time;
  int f0,f1;

  if (!str) return NULL;

  start=str;
  while (1) {
    fprintf(stderr, "[oggenc/lyrics.c] enter process_enhanced_lrc_tags 2\n");
    start=strchr(start,'<');
    if (!start) break;
    end=strchr(start+1,'>');
    if (!end) break;

    /* we found a <> pair, parse it */
    f0=f1=-1;
    ret=sscanf(start,"<%d:%d.%n%d%n>",&m,&s,&f0,&fs,&f1);

    /* remove the <> tag from input to get raw text */
    memmove(start,end+1,strlen(end+1)+1);

    if (ret<3 || (f0|f1)<0 || f0>=f1 || (m|s|fs)<0) {
      fprintf(stderr, "[oggenc/lyrics.c] enter process_enhanced_lrc_tags 3\n");
      fprintf(stderr, _("WARNING - line %d: failed to process enhanced LRC tag (%*.*s) - ignored\n"),line,(int)(end-start+1),(int)(end-start+1),start);
      fprintf(stderr, "[oggenc/lyrics.c] exit process_enhanced_lrc_tags 3\n");
    }
    else {
      fprintf(stderr, "[oggenc/lyrics.c] enter process_enhanced_lrc_tags 4\n");
      kate_float tag_time=hmsms2s(0,m,s,fraction_to_milliseconds(fs,f1-f0));

      /* if this is the first tag in this line, create a kate motion */
      if (!km) {
        fprintf(stderr, "[oggenc/lyrics.c] enter process_enhanced_lrc_tags 5\n");
        km=(kate_motion*)malloc(sizeof(kate_motion));
        if (!km) {
          fprintf(stderr, "[oggenc/lyrics.c] enter process_enhanced_lrc_tags 6\n");
          fprintf(stderr, _("WARNING: failed to allocate memory - enhanced LRC tag will be ignored\n"));
          fprintf(stderr, "[oggenc/lyrics.c] exit process_enhanced_lrc_tags 6\n");
        }
        else {
          fprintf(stderr, "[oggenc/lyrics.c] enter process_enhanced_lrc_tags 7\n");
          kate_motion_init(km);
          km->semantics=kate_motion_semantics_glyph_pointer_1;
          fprintf(stderr, "[oggenc/lyrics.c] exit process_enhanced_lrc_tags 7\n");
        }
        fprintf(stderr, "[oggenc/lyrics.c] exit process_enhanced_lrc_tags 5\n");
      }
      /* add to the kate motion */
      if (km) {
        fprintf(stderr, "[oggenc/lyrics.c] enter process_enhanced_lrc_tags 8\n");
        add_kate_karaoke_tag(km,tag_time-current_time,str,start-str,line);
        current_time = tag_time;
        fprintf(stderr, "[oggenc/lyrics.c] exit process_enhanced_lrc_tags 8\n");
      }
      fprintf(stderr, "[oggenc/lyrics.c] exit process_enhanced_lrc_tags 4\n");
    }
    fprintf(stderr, "[oggenc/lyrics.c] exit process_enhanced_lrc_tags 2\n");
  }

  /* if we've found karaoke info, extend the motion to the end time */
  if (km) {
    fprintf(stderr, "[oggenc/lyrics.c] enter process_enhanced_lrc_tags 9\n");
    add_kate_karaoke_tag(km,end_time-current_time,str,strlen(str),line);
    fprintf(stderr, "[oggenc/lyrics.c] exit process_enhanced_lrc_tags 9\n");
  }

  return km;
  fprintf(stderr, "[oggenc/lyrics.c] exit process_enhanced_lrc_tags 1\n");
}

static oe_lyrics *load_lrc_lyrics(FILE *f)
{
  fprintf(stderr, "[oggenc/lyrics.c] enter load_lrc_lyrics 1\n");
  oe_lyrics *lyrics;
  static char str[4096];
  static char lyrics_line[4096]="";
  int m,s,fs;
  double t,start_time = -1.0;
  int offset;
  int ret;
  unsigned line=0;
  kate_motion *km;
  int f0,f1;

  if (!f) return NULL;

  /* skip headers */
  fgets2(str,sizeof(str),f);
  ++line;
  while (!feof(f)) {
    fprintf(stderr, "[oggenc/lyrics.c] enter load_lrc_lyrics 2\n");
    ret = sscanf(str, "[%d:%d.%d]%n\n",&m,&s,&fs,&offset);
    if (ret >= 3)
      break;
    fgets2(str,sizeof(str),f);
    ++line;
    fprintf(stderr, "[oggenc/lyrics.c] exit load_lrc_lyrics 2\n");
  }
  if (feof(f)) {
    fprintf(stderr, "[oggenc/lyrics.c] enter load_lrc_lyrics 3\n");
    fprintf(stderr,_("ERROR - line %u: Syntax error: %s\n"),line,str);
    return NULL;
    fprintf(stderr, "[oggenc/lyrics.c] exit load_lrc_lyrics 3\n");
  }

  lyrics=(oe_lyrics*)malloc(sizeof(oe_lyrics));
  if (!lyrics) return NULL;
  lyrics->count = 0;
  lyrics->lyrics = NULL;
  lyrics->karaoke = 0;

  while (!feof(f)) {
    fprintf(stderr, "[oggenc/lyrics.c] enter load_lrc_lyrics 4\n");
    /* ignore empty lines */
    if (!is_line_empty(str)) {
      fprintf(stderr, "[oggenc/lyrics.c] enter load_lrc_lyrics 5\n");
      f0=f1=-1;
      ret=sscanf(str, "[%d:%d.%n%d%n]%n\n",&m,&s,&f0,&fs,&f1,&offset);
      if (ret<3 || (f0|f1)<0 || f1<=f0 || (m|s|fs)<0) {
        fprintf(stderr, "[oggenc/lyrics.c] enter load_lrc_lyrics 6\n");
        fprintf(stderr,_("ERROR - line %u: Syntax error: %s\n"),line,str);
        free_lyrics(lyrics);
        return NULL;
        fprintf(stderr, "[oggenc/lyrics.c] exit load_lrc_lyrics 6\n");
      }
      t=hmsms2s(0,m,s,fraction_to_milliseconds(fs,f1-f0));

      if (start_time>=0.0 && !is_line_empty(lyrics_line)) {
        fprintf(stderr, "[oggenc/lyrics.c] enter load_lrc_lyrics 7\n");
        km=process_enhanced_lrc_tags(lyrics_line,start_time,t,line);
        if (km) {
          fprintf(stderr, "[oggenc/lyrics.c] enter load_lrc_lyrics 8\n");
          lyrics->karaoke = 1;
          fprintf(stderr, "[oggenc/lyrics.c] exit load_lrc_lyrics 8\n");
        }
        if (add_lyrics(lyrics,lyrics_line,km,start_time,t) < 0) {
          fprintf(stderr, "[oggenc/lyrics.c] enter load_lrc_lyrics 9\n");
          free_lyrics(lyrics);
          return NULL;
          fprintf(stderr, "[oggenc/lyrics.c] exit load_lrc_lyrics 9\n");
        }
        fprintf(stderr, "[oggenc/lyrics.c] exit load_lrc_lyrics 7\n");
      }

      strncpy(lyrics_line,str+offset,sizeof(lyrics_line));
      lyrics_line[sizeof(lyrics_line)-1]=0;
      start_time=t;
      fprintf(stderr, "[oggenc/lyrics.c] exit load_lrc_lyrics 5\n");
    }

    fgets2(str,sizeof(str),f);
    ++line;
    fprintf(stderr, "[oggenc/lyrics.c] exit load_lrc_lyrics 4\n");
  }

  return lyrics;
  fprintf(stderr, "[oggenc/lyrics.c] exit load_lrc_lyrics 1\n");
}

/* very weak checks, but we only support two formats, so it's ok */
lyrics_format probe_lyrics_format(FILE *f)
{
  fprintf(stderr, "[oggenc/lyrics.c] enter probe_lyrics_format 1\n");
  int dummy_int;
  static char str[4096];
  lyrics_format format=lf_unknown;
  long pos;

  if (!f) return lf_unknown;

  pos=ftell(f);
  fgets2(str,sizeof(str),f);

  /* srt */
  if (sscanf(str, "%d\n", &dummy_int) == 1 && dummy_int>=0)
    format=lf_srt;

  /* lrc */
  if (str[0] == '[')
    format=lf_lrc;

  fseek(f,pos,SEEK_SET);

  return format;
  fprintf(stderr, "[oggenc/lyrics.c] exit probe_lyrics_format 1\n");
}

#endif

oe_lyrics *load_lyrics(const char *filename)
{
#ifdef HAVE_KATE
  fprintf(stderr, "[oggenc/lyrics.c] enter load_lyrics 1\n");
  static char str[4096];
  int ret;
  oe_lyrics *lyrics=NULL;
  FILE *f;

  if (!filename) {
      fprintf(stderr, "[oggenc/lyrics.c] enter load_lyrics 2\n");
      fprintf(stderr,_("ERROR: No lyrics filename to load from\n"));
      return NULL;
      fprintf(stderr, "[oggenc/lyrics.c] exit load_lyrics 2\n");
  }

  f = fopen(filename, "r");
  if (!f) {
      fprintf(stderr, "[oggenc/lyrics.c] enter load_lyrics 3\n");
      fprintf(stderr,_("ERROR: Failed to open lyrics file %s (%s)\n"), filename, strerror(errno));
      return NULL;
      fprintf(stderr, "[oggenc/lyrics.c] exit load_lyrics 3\n");
  }

  /* first, check for a BOM */
  ret=fread(str,1,3,f);
  if (ret<3 || memcmp(str,"\xef\xbb\xbf",3)) {
    fprintf(stderr, "[oggenc/lyrics.c] enter load_lyrics 4\n");
    /* No BOM, rewind */
    fseek(f,0,SEEK_SET);
    fprintf(stderr, "[oggenc/lyrics.c] exit load_lyrics 4\n");
  }

  switch (probe_lyrics_format(f)) {
    case lf_srt:
      fprintf(stderr, "[oggenc/lyrics.c] enter load_lyrics 5\n");
      lyrics = load_srt_lyrics(f);
      fprintf(stderr, "[oggenc/lyrics.c] exit load_lyrics 5\n");
      break;
    case lf_lrc:
      fprintf(stderr, "[oggenc/lyrics.c] enter load_lyrics 6\n");
      lyrics = load_lrc_lyrics(f);
      fprintf(stderr, "[oggenc/lyrics.c] exit load_lyrics 6\n");
      break;
    default:
      fprintf(stderr, "[oggenc/lyrics.c] enter load_lyrics 7\n");
      fprintf(stderr, _("ERROR: Failed to load %s - can't determine format\n"), filename);
      fprintf(stderr, "[oggenc/lyrics.c] exit load_lyrics 7\n");
      break;
  }

  fclose(f);

  return lyrics;
  fprintf(stderr, "[oggenc/lyrics.c] exit load_lyrics 1\n");
#else
  return NULL;
#endif
}

void free_lyrics(oe_lyrics *lyrics)
{
#ifdef HAVE_KATE
    fprintf(stderr, "[oggenc/lyrics.c] enter free_lyrics 1\n");
    size_t n,c;
    if (lyrics) {
        fprintf(stderr, "[oggenc/lyrics.c] enter free_lyrics 2\n");
        for (n=0; n<lyrics->count; ++n) {
          fprintf(stderr, "[oggenc/lyrics.c] enter free_lyrics 3\n");
          oe_lyrics_item *li=&lyrics->lyrics[n];
          free(li->text);
          if (li->km) {
            fprintf(stderr, "[oggenc/lyrics.c] enter free_lyrics 4\n");
            for (c=0; c<li->km->ncurves; ++c) {
              fprintf(stderr, "[oggenc/lyrics.c] enter free_lyrics 5\n");
              free(li->km->curves[c]->pts);
              free(li->km->curves[c]);
              fprintf(stderr, "[oggenc/lyrics.c] exit free_lyrics 5\n");
            }
            free(li->km->curves);
            free(li->km->durations);
            free(li->km);
            fprintf(stderr, "[oggenc/lyrics.c] exit free_lyrics 4\n");
          }
          fprintf(stderr, "[oggenc/lyrics.c] exit free_lyrics 3\n");
        }
        free(lyrics->lyrics);
        free(lyrics);
        fprintf(stderr, "[oggenc/lyrics.c] exit free_lyrics 2\n");
    }
    fprintf(stderr, "[oggenc/lyrics.c] exit free_lyrics 1\n");
#endif
}

const oe_lyrics_item *get_lyrics(const oe_lyrics *lyrics, double t, size_t *idx)
{
#ifdef HAVE_KATE
    fprintf(stderr, "[oggenc/lyrics.c] enter get_lyrics 1\n");
    if (!lyrics || *idx>=lyrics->count) return NULL;
    if (lyrics->lyrics[*idx].t0 > t) return NULL;
    return &lyrics->lyrics[(*idx)++];
    fprintf(stderr, "[oggenc/lyrics.c] exit get_lyrics 1\n");
#else
    return NULL;
#endif
}
// Total cost: 0.155166
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 489)]
// Total instrumented cost: 0.155166, input tokens: 7012, output tokens: 7190, cache read tokens: 0, cache write tokens: 7008

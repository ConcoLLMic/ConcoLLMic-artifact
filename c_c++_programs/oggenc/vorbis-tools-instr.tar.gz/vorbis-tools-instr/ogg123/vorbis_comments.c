/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE OggVorbis SOFTWARE CODEC SOURCE CODE.   *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS BEFORE DISTRIBUTING.                     *
 *                                                                  *
 * THE Ogg123 SOURCE CODE IS (C) COPYRIGHT 2000-2001                *
 * by Stan Seibert <volsung@xiph.org> AND OTHER CONTRIBUTORS        *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

 last mod: $Id$

 ********************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <ogg/ogg.h>
#include <vorbis/codec.h>
#include <vorbis/vorbisfile.h>
#include "format.h"
#include "utf8.h"
#include "i18n.h"
#include "picture.h"
#include "vorbis_comments.h"


/* Vorbis comment keys that need special formatting. */
static const struct {
  const char *key;         /* includes the '=' for programming convenience */
  const char *formatstr;   /* formatted output */
} vorbis_comment_keys[] = {
  {"TRACKNUMBER=", N_("Track number:")},
  {"REPLAYGAIN_REFERENCE_LOUDNESS=", N_("ReplayGain (Reference loudness):")},
  {"REPLAYGAIN_TRACK_GAIN=", N_("ReplayGain (Track):")},
  {"REPLAYGAIN_ALBUM_GAIN=", N_("ReplayGain (Album):")},
  {"REPLAYGAIN_TRACK_PEAK=", N_("ReplayGain Peak (Track):")},
  {"REPLAYGAIN_ALBUM_PEAK=", N_("ReplayGain Peak (Album):")},
  {"COPYRIGHT=", N_("Copyright")},
  {"=", N_("Comment:")},
  {NULL, N_("Comment:")}
};


char *lookup_comment_prettyprint (const char *comment, int *offset)
{
  fprintf(stderr, "[ogg123/vorbis_comments.c] enter lookup_comment_prettyprint 1\n");
  int i, j;
  char *s;

  /* Search for special-case formatting */
  for (i = 0; vorbis_comment_keys[i].key != NULL; i++) {
    fprintf(stderr, "[ogg123/vorbis_comments.c] enter lookup_comment_prettyprint 2\n");

    if ( !strncasecmp (vorbis_comment_keys[i].key, comment,
		       strlen(vorbis_comment_keys[i].key)) ) {
      fprintf(stderr, "[ogg123/vorbis_comments.c] enter lookup_comment_prettyprint 3\n");

      *offset = strlen(vorbis_comment_keys[i].key);
      s = strdup(vorbis_comment_keys[i].formatstr);
      if (s == NULL) {
        fprintf(stderr, "[ogg123/vorbis_comments.c] enter lookup_comment_prettyprint 4\n");
        fprintf(stderr, _("ERROR: Out of memory.\n"));
        exit(1);
        fprintf(stderr, "[ogg123/vorbis_comments.c] exit lookup_comment_prettyprint 4\n");
      }
      return s;
      fprintf(stderr, "[ogg123/vorbis_comments.c] exit lookup_comment_prettyprint 3\n");
    }
    fprintf(stderr, "[ogg123/vorbis_comments.c] exit lookup_comment_prettyprint 2\n");
  }

  /* Use default formatting */
  fprintf(stderr, "[ogg123/vorbis_comments.c] enter lookup_comment_prettyprint 5\n");
  j = strcspn(comment, "=");
  if (j) {
    fprintf(stderr, "[ogg123/vorbis_comments.c] enter lookup_comment_prettyprint 6\n");
    *offset = j + 1;
    s = malloc(j + 2);
    if (s == NULL) {
      fprintf(stderr, "[ogg123/vorbis_comments.c] enter lookup_comment_prettyprint 7\n");
      fprintf(stderr, _("ERROR: Out of memory.\n"));
      exit(1);
      fprintf(stderr, "[ogg123/vorbis_comments.c] exit lookup_comment_prettyprint 7\n");
    };
    strncpy(s, comment, j);
    strcpy(s + j, ":");

    /* Capitalize */
    s[0] = toupper(s[0]);
    for (i = 1; i < j; i++) {
      fprintf(stderr, "[ogg123/vorbis_comments.c] enter lookup_comment_prettyprint 8\n");
      s[i] = tolower(s[i]);
      fprintf(stderr, "[ogg123/vorbis_comments.c] exit lookup_comment_prettyprint 8\n");
    }
    return s;
    fprintf(stderr, "[ogg123/vorbis_comments.c] exit lookup_comment_prettyprint 6\n");
  }

  /* Unrecognized comment, use last format string */
  fprintf(stderr, "[ogg123/vorbis_comments.c] enter lookup_comment_prettyprint 9\n");
  *offset = 0;
  s = strdup(vorbis_comment_keys[i].formatstr);
  if (s == NULL) {
    fprintf(stderr, "[ogg123/vorbis_comments.c] enter lookup_comment_prettyprint 10\n");
    fprintf(stderr, _("ERROR: Out of memory.\n"));
    exit(1);
    fprintf(stderr, "[ogg123/vorbis_comments.c] exit lookup_comment_prettyprint 10\n");
  }
  return s;
  fprintf(stderr, "[ogg123/vorbis_comments.c] exit lookup_comment_prettyprint 9\n");
  fprintf(stderr, "[ogg123/vorbis_comments.c] exit lookup_comment_prettyprint 5\n");
  fprintf(stderr, "[ogg123/vorbis_comments.c] exit lookup_comment_prettyprint 1\n");
}

static void print_vorbis_comment_picture(const char *comment,
                                         decoder_callbacks_t *cb,
                                         void *callback_arg)
{
    fprintf(stderr, "[ogg123/vorbis_comments.c] enter print_vorbis_comment_picture 1\n");
    flac_picture_t *picture;

    comment = strstr(comment, "=");
    if (!comment || !*comment) {
        fprintf(stderr, "[ogg123/vorbis_comments.c] enter print_vorbis_comment_picture 2\n");
        return;
        fprintf(stderr, "[ogg123/vorbis_comments.c] exit print_vorbis_comment_picture 2\n");
    }
    comment++;

    picture = flac_picture_parse_from_base64(comment);
    if (picture) {
        fprintf(stderr, "[ogg123/vorbis_comments.c] enter print_vorbis_comment_picture 3\n");
        const char *description = picture->description;
        char res[64];

        if (picture->width && picture->height) {
            fprintf(stderr, "[ogg123/vorbis_comments.c] enter print_vorbis_comment_picture 4\n");
            if (picture->colors) {
                fprintf(stderr, "[ogg123/vorbis_comments.c] enter print_vorbis_comment_picture 5\n");
                snprintf(res, sizeof(res), " %ux%u@%u/%u", picture->width, picture->height, picture->depth, picture->colors);
                fprintf(stderr, "[ogg123/vorbis_comments.c] exit print_vorbis_comment_picture 5\n");
            } else {
                fprintf(stderr, "[ogg123/vorbis_comments.c] enter print_vorbis_comment_picture 6\n");
                snprintf(res, sizeof(res), " %ux%u@%u", picture->width, picture->height, picture->depth);
                fprintf(stderr, "[ogg123/vorbis_comments.c] exit print_vorbis_comment_picture 6\n");
            }
            fprintf(stderr, "[ogg123/vorbis_comments.c] exit print_vorbis_comment_picture 4\n");
        }

        if (picture->uri) {
            fprintf(stderr, "[ogg123/vorbis_comments.c] enter print_vorbis_comment_picture 7\n");
            if (description) {
                fprintf(stderr, "[ogg123/vorbis_comments.c] enter print_vorbis_comment_picture 8\n");
                cb->printf_metadata(callback_arg, 1, N_("Picture: Type \"%s\"%s with description \"%s\" and URI %s"), flac_picture_type_string(picture->type), res, description, picture->uri);
                fprintf(stderr, "[ogg123/vorbis_comments.c] exit print_vorbis_comment_picture 8\n");
            } else {
                fprintf(stderr, "[ogg123/vorbis_comments.c] enter print_vorbis_comment_picture 9\n");
                cb->printf_metadata(callback_arg, 1, N_("Picture: Type \"%s\"%s URI %s"), flac_picture_type_string(picture->type), res, picture->uri);
                fprintf(stderr, "[ogg123/vorbis_comments.c] exit print_vorbis_comment_picture 9\n");
            }
            fprintf(stderr, "[ogg123/vorbis_comments.c] exit print_vorbis_comment_picture 7\n");
        } else {
            fprintf(stderr, "[ogg123/vorbis_comments.c] enter print_vorbis_comment_picture 10\n");
            if (description) {
                fprintf(stderr, "[ogg123/vorbis_comments.c] enter print_vorbis_comment_picture 11\n");
                cb->printf_metadata(callback_arg, 1, N_("Picture: Type \"%s\"%s with description \"%s\", %zu bytes %s"), flac_picture_type_string(picture->type), res, description, picture->binary_length, picture->media_type);
                fprintf(stderr, "[ogg123/vorbis_comments.c] exit print_vorbis_comment_picture 11\n");
            } else {
                fprintf(stderr, "[ogg123/vorbis_comments.c] enter print_vorbis_comment_picture 12\n");
                cb->printf_metadata(callback_arg, 1, N_("Picture: Type \"%s\"%s %zu bytes %s"), flac_picture_type_string(picture->type), res, picture->binary_length, picture->media_type);
                fprintf(stderr, "[ogg123/vorbis_comments.c] exit print_vorbis_comment_picture 12\n");
            }
            fprintf(stderr, "[ogg123/vorbis_comments.c] exit print_vorbis_comment_picture 10\n");
        }
        flac_picture_free(picture);
        fprintf(stderr, "[ogg123/vorbis_comments.c] exit print_vorbis_comment_picture 3\n");
    } else {
        fprintf(stderr, "[ogg123/vorbis_comments.c] enter print_vorbis_comment_picture 13\n");
        cb->printf_metadata(callback_arg, 1, _("Picture: <corrupted>"));
        fprintf(stderr, "[ogg123/vorbis_comments.c] exit print_vorbis_comment_picture 13\n");
    }
    fprintf(stderr, "[ogg123/vorbis_comments.c] exit print_vorbis_comment_picture 1\n");
}

void print_vorbis_comment (const char *comment, decoder_callbacks_t *cb,
			   void *callback_arg)
{
  fprintf(stderr, "[ogg123/vorbis_comments.c] enter print_vorbis_comment 1\n");
  char *comment_prettyprint;
  char *decoded_value;
  int offset;

  if (cb == NULL || cb->printf_metadata == NULL) {
    fprintf(stderr, "[ogg123/vorbis_comments.c] enter print_vorbis_comment 2\n");
    return;
    fprintf(stderr, "[ogg123/vorbis_comments.c] exit print_vorbis_comment 2\n");
  }

  if (strncasecmp(comment, "METADATA_BLOCK_PICTURE=", 23) == 0) {
    fprintf(stderr, "[ogg123/vorbis_comments.c] enter print_vorbis_comment 3\n");
    print_vorbis_comment_picture(comment, cb, callback_arg);
    return;
    fprintf(stderr, "[ogg123/vorbis_comments.c] exit print_vorbis_comment 3\n");
  }

  fprintf(stderr, "[ogg123/vorbis_comments.c] enter print_vorbis_comment 4\n");
  comment_prettyprint = lookup_comment_prettyprint(comment, &offset);

  if (utf8_decode(comment + offset, &decoded_value) >= 0) {
    fprintf(stderr, "[ogg123/vorbis_comments.c] enter print_vorbis_comment 5\n");
    cb->printf_metadata(callback_arg, 1, "%s %s", comment_prettyprint, 
			decoded_value);
    free(decoded_value);
    fprintf(stderr, "[ogg123/vorbis_comments.c] exit print_vorbis_comment 5\n");
  } else {
    fprintf(stderr, "[ogg123/vorbis_comments.c] enter print_vorbis_comment 6\n");
    cb->printf_metadata(callback_arg, 1, "%s %s", comment_prettyprint, 
			comment + offset);
    fprintf(stderr, "[ogg123/vorbis_comments.c] exit print_vorbis_comment 6\n");
  }
  free(comment_prettyprint);
  fprintf(stderr, "[ogg123/vorbis_comments.c] exit print_vorbis_comment 4\n");
  fprintf(stderr, "[ogg123/vorbis_comments.c] exit print_vorbis_comment 1\n");
}
// Total cost: 0.060551
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 174)]
// Total instrumented cost: 0.060551, input tokens: 4227, output tokens: 3116, cache read tokens: 2280, cache write tokens: 1943

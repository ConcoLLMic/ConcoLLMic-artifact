/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE OggVorbis SOFTWARE CODEC SOURCE CODE.   *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS BEFORE DISTRIBUTING.                     *
 *                                                                  *
 * THE Ogg123 SOURCE CODE IS (C) COPYRIGHT 2000-2001                *
 * by Stan Seibert <volsung@xiph.org> AND OTHER CONTRIBUTORS        *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

 last mod: $Id$

 ********************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "transport.h"
#include "i18n.h"

extern transport_t file_transport;
#ifdef HAVE_CURL
extern transport_t http_transport;
#endif

static const transport_t *transports[] = {
#ifdef HAVE_CURL
  &http_transport,
#endif
  &file_transport,
  NULL
};


const transport_t *get_transport_by_name (const char *name)
{
  fprintf(stderr, "[ogg123/transport.c] enter get_transport_by_name 1\n");
  int i = 0;

  while (transports[i] != NULL && strcmp(name, transports[i]->name) != 0)
    i++;

  return transports[i];
  fprintf(stderr, "[ogg123/transport.c] exit get_transport_by_name 1\n");
}


const transport_t *select_transport (const char *source)
{
  fprintf(stderr, "[ogg123/transport.c] enter select_transport 1\n");
  int i = 0;

  while (transports[i] != NULL && !transports[i]->can_transport(source))
    i++;

  return transports[i];
  fprintf(stderr, "[ogg123/transport.c] exit select_transport 1\n");
}


data_source_stats_t *malloc_data_source_stats (data_source_stats_t *to_copy)
{
  fprintf(stderr, "[ogg123/transport.c] enter malloc_data_source_stats 1\n");
  data_source_stats_t *new_stats;

  new_stats = malloc(sizeof(data_source_stats_t));
  fprintf(stderr, "[ogg123/transport.c] exit malloc_data_source_stats 1\n");

  if (new_stats == NULL) {
    fprintf(stderr, "[ogg123/transport.c] enter malloc_data_source_stats 2\n");
    fprintf(stderr, _("ERROR: Could not allocate memory in malloc_data_source_stats()\n"));
    exit(1);
    fprintf(stderr, "[ogg123/transport.c] exit malloc_data_source_stats 2\n");
  }

  fprintf(stderr, "[ogg123/transport.c] enter malloc_data_source_stats 3\n");
  *new_stats = *to_copy;  /* Copy the data */

  return new_stats;
  fprintf(stderr, "[ogg123/transport.c] exit malloc_data_source_stats 3\n");
}
// Total cost: 0.017319
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 78)]
// Total instrumented cost: 0.017319, input tokens: 2940, output tokens: 813, cache read tokens: 2280, cache write tokens: 656

/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE OggVorbis SOFTWARE CODEC SOURCE CODE.   *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS BEFORE DISTRIBUTING.                     *
 *                                                                  *
 * THE Ogg123 SOURCE CODE IS (C) COPYRIGHT 2000-2001                *
 * by Stan Seibert <volsung@xiph.org> AND OTHER CONTRIBUTORS        *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

 last mod: $Id$

 ********************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <string.h>

#include "callbacks.h"
#include "i18n.h"

#define WARNING_VERBOSITY 2
#define INFO_VERBOSITY    3

/* Audio callbacks */

int audio_play_callback (void *ptr, int nbytes, int eos, void *arg)
{
  fprintf(stderr, "[ogg123/callbacks.c] enter audio_play_callback 1\n");
  audio_play_arg_t *play_arg = (audio_play_arg_t *) arg;
  int ret;

  ret = audio_devices_write(play_arg->devices, ptr, nbytes);

  return ret ? nbytes : 0;
  fprintf(stderr, "[ogg123/callbacks.c] exit audio_play_callback 1\n");
}

void audio_reopen_action (buf_t *buf, void *arg)
{
  fprintf(stderr, "[ogg123/callbacks.c] enter audio_reopen_action 1\n");
  audio_reopen_arg_t *reopen_arg = (audio_reopen_arg_t *) arg;
  audio_device_t *current;
  ao_sample_format format;

  close_audio_devices (reopen_arg->devices);

  /* Record audio device settings and open the devices */
  format.rate = reopen_arg->format->rate;
  format.channels = reopen_arg->format->channels;
  format.bits = reopen_arg->format->word_size * 8;
  format.byte_format = reopen_arg->format->big_endian ? 
    AO_FMT_BIG : AO_FMT_LITTLE;
  format.matrix = reopen_arg->format->matrix;

  current = reopen_arg->devices;
  fprintf(stderr, "[ogg123/callbacks.c] exit audio_reopen_action 1\n");

  while (current != NULL) {
    fprintf(stderr, "[ogg123/callbacks.c] enter audio_reopen_action 2\n");
    ao_info *info = ao_driver_info(current->driver_id);

    if (current->filename == NULL) {
      fprintf(stderr, "[ogg123/callbacks.c] enter audio_reopen_action 3\n");
      current->device = ao_open_live(current->driver_id, &format,
				     current->options);
      fprintf(stderr, "[ogg123/callbacks.c] exit audio_reopen_action 3\n");
    }
    else {
      fprintf(stderr, "[ogg123/callbacks.c] enter audio_reopen_action 4\n");
      current->device = ao_open_file(current->driver_id, current->filename,
				     1 /*overwrite*/, &format, 
				     current->options);
      fprintf(stderr, "[ogg123/callbacks.c] exit audio_reopen_action 4\n");
    }

    /* Report errors */
    if (current->device == NULL) {
      fprintf(stderr, "[ogg123/callbacks.c] enter audio_reopen_action 5\n");
      switch (errno) {
      case AO_ENODRIVER:
        fprintf(stderr, "[ogg123/callbacks.c] enter audio_reopen_action 6\n");
        status_error(_("ERROR: Device not available.\n"));
        fprintf(stderr, "[ogg123/callbacks.c] exit audio_reopen_action 6\n");
	break;
      case AO_ENOTLIVE:
        fprintf(stderr, "[ogg123/callbacks.c] enter audio_reopen_action 7\n");
	status_error(_("ERROR: %s requires an output filename to be specified with -f.\n"), info->short_name);
        fprintf(stderr, "[ogg123/callbacks.c] exit audio_reopen_action 7\n");
	break;
      case AO_EBADOPTION:
        fprintf(stderr, "[ogg123/callbacks.c] enter audio_reopen_action 8\n");
	status_error(_("ERROR: Unsupported option value to %s device.\n"),
		     info->short_name);
        fprintf(stderr, "[ogg123/callbacks.c] exit audio_reopen_action 8\n");
	break;
      case AO_EOPENDEVICE:
        fprintf(stderr, "[ogg123/callbacks.c] enter audio_reopen_action 9\n");
	status_error(_("ERROR: Cannot open device %s.\n"),
		     info->short_name);
        fprintf(stderr, "[ogg123/callbacks.c] exit audio_reopen_action 9\n");
	break;
      case AO_EFAIL:
        fprintf(stderr, "[ogg123/callbacks.c] enter audio_reopen_action 10\n");
	status_error(_("ERROR: Device %s failure.\n"), info->short_name);
        fprintf(stderr, "[ogg123/callbacks.c] exit audio_reopen_action 10\n");
	break;
      case AO_ENOTFILE:
        fprintf(stderr, "[ogg123/callbacks.c] enter audio_reopen_action 11\n");
	status_error(_("ERROR: An output file cannot be given for %s device.\n"), info->short_name);
        fprintf(stderr, "[ogg123/callbacks.c] exit audio_reopen_action 11\n");
	break;
      case AO_EOPENFILE:
        fprintf(stderr, "[ogg123/callbacks.c] enter audio_reopen_action 12\n");
	status_error(_("ERROR: Cannot open file %s for writing.\n"),
		     current->filename);
        fprintf(stderr, "[ogg123/callbacks.c] exit audio_reopen_action 12\n");
	break;
      case AO_EFILEEXISTS:
        fprintf(stderr, "[ogg123/callbacks.c] enter audio_reopen_action 13\n");
	status_error(_("ERROR: File %s already exists.\n"), current->filename);
        fprintf(stderr, "[ogg123/callbacks.c] exit audio_reopen_action 13\n");
	break;
      default:
        fprintf(stderr, "[ogg123/callbacks.c] enter audio_reopen_action 14\n");
	status_error(_("ERROR: This error should never happen (%d).  Panic!\n"), errno);
        fprintf(stderr, "[ogg123/callbacks.c] exit audio_reopen_action 14\n");
	break;
      }
	 
      /* We cannot recover from any of these errors */
      exit(1);
      fprintf(stderr, "[ogg123/callbacks.c] exit audio_reopen_action 5\n");
    }

    current = current->next_device;
    fprintf(stderr, "[ogg123/callbacks.c] exit audio_reopen_action 2\n");
  }

  /* Cleanup argument */
  fprintf(stderr, "[ogg123/callbacks.c] enter audio_reopen_action 15\n");
  if(reopen_arg->format->matrix)
    free(reopen_arg->format->matrix);
  free(reopen_arg->format);
  free(reopen_arg);
  fprintf(stderr, "[ogg123/callbacks.c] exit audio_reopen_action 15\n");
}


audio_reopen_arg_t *new_audio_reopen_arg (audio_device_t *devices,
					  audio_format_t *fmt)
{
  fprintf(stderr, "[ogg123/callbacks.c] enter new_audio_reopen_arg 1\n");
  audio_reopen_arg_t *arg;

  if ( (arg = calloc(1,sizeof(audio_reopen_arg_t))) == NULL ) {
    fprintf(stderr, "[ogg123/callbacks.c] enter new_audio_reopen_arg 2\n");
    status_error(_("ERROR: Out of memory in new_audio_reopen_arg().\n"));
    exit(1);
    fprintf(stderr, "[ogg123/callbacks.c] exit new_audio_reopen_arg 2\n");
  }

  if ( (arg->format = calloc(1,sizeof(audio_format_t))) == NULL ) {
    fprintf(stderr, "[ogg123/callbacks.c] enter new_audio_reopen_arg 3\n");
    status_error(_("ERROR: Out of memory in new_audio_reopen_arg().\n"));
    exit(1);
    fprintf(stderr, "[ogg123/callbacks.c] exit new_audio_reopen_arg 3\n");
  }

  arg->devices = devices;
  /* Copy format in case fmt is recycled later */
  *arg->format = *fmt;
  if(fmt->matrix) {
    fprintf(stderr, "[ogg123/callbacks.c] enter new_audio_reopen_arg 4\n");
    arg->format->matrix = strdup(fmt->matrix);
    fprintf(stderr, "[ogg123/callbacks.c] exit new_audio_reopen_arg 4\n");
  }

  return arg;
  fprintf(stderr, "[ogg123/callbacks.c] exit new_audio_reopen_arg 1\n");
}


/* Statistics callbacks */

void print_statistics_action (buf_t *buf, void *arg)
{
  fprintf(stderr, "[ogg123/callbacks.c] enter print_statistics_action 1\n");
  print_statistics_arg_t *stats_arg = (print_statistics_arg_t *) arg;
  buffer_stats_t *buffer_stats;

  if (buf != NULL) {
    fprintf(stderr, "[ogg123/callbacks.c] enter print_statistics_action 2\n");
    buffer_stats = buffer_statistics(buf);
    fprintf(stderr, "[ogg123/callbacks.c] exit print_statistics_action 2\n");
  }
  else {
    fprintf(stderr, "[ogg123/callbacks.c] enter print_statistics_action 3\n");
    buffer_stats = NULL;
    fprintf(stderr, "[ogg123/callbacks.c] exit print_statistics_action 3\n");
  }

  status_print_statistics(stats_arg->stat_format,
			  buffer_stats,
			  stats_arg->data_source_statistics,
			  stats_arg->decoder_statistics);

  free(stats_arg->data_source_statistics);
  free(stats_arg->decoder_statistics);
  free(stats_arg);
  free(buffer_stats);
  fprintf(stderr, "[ogg123/callbacks.c] exit print_statistics_action 1\n");
}


print_statistics_arg_t *new_print_statistics_arg (
			       stat_format_t *stat_format,
			       data_source_stats_t *data_source_statistics,
			       decoder_stats_t *decoder_statistics)
{
  fprintf(stderr, "[ogg123/callbacks.c] enter new_print_statistics_arg 1\n");
  print_statistics_arg_t *arg;

  if ( (arg = calloc(1,sizeof(print_statistics_arg_t))) == NULL ) {
    fprintf(stderr, "[ogg123/callbacks.c] enter new_print_statistics_arg 2\n");
    status_error(_("Error: Out of memory in new_print_statistics_arg().\n"));
    exit(1);
    fprintf(stderr, "[ogg123/callbacks.c] exit new_print_statistics_arg 2\n");
  }

  arg->stat_format = stat_format;
  arg->data_source_statistics = data_source_statistics;
  arg->decoder_statistics = decoder_statistics;

  return arg;
  fprintf(stderr, "[ogg123/callbacks.c] exit new_print_statistics_arg 1\n");
}


/* Decoder callbacks */

void decoder_error_callback (void *arg, int severity, char *message, ...)
{
  fprintf(stderr, "[ogg123/callbacks.c] enter decoder_error_callback 1\n");
  va_list ap;

  va_start(ap, message);
  switch (severity) {
  case ERROR:
    fprintf(stderr, "[ogg123/callbacks.c] enter decoder_error_callback 2\n");
    vstatus_error(message, ap);
    fprintf(stderr, "[ogg123/callbacks.c] exit decoder_error_callback 2\n");
    break;
  case WARNING:
    fprintf(stderr, "[ogg123/callbacks.c] enter decoder_error_callback 3\n");
    vstatus_message(WARNING_VERBOSITY, message, ap);
    fprintf(stderr, "[ogg123/callbacks.c] exit decoder_error_callback 3\n");
    break;
  case INFO:
    fprintf(stderr, "[ogg123/callbacks.c] enter decoder_error_callback 4\n");
    vstatus_message(INFO_VERBOSITY, message, ap);
    fprintf(stderr, "[ogg123/callbacks.c] exit decoder_error_callback 4\n");
    break;
  }
  va_end(ap);
  fprintf(stderr, "[ogg123/callbacks.c] exit decoder_error_callback 1\n");
}


void decoder_metadata_callback (void *arg, int verbosity, char *message, ...)
{
  fprintf(stderr, "[ogg123/callbacks.c] enter decoder_metadata_callback 1\n");
  va_list ap;

  va_start(ap, message);
  vstatus_message(verbosity, message, ap);
  va_end(ap);
  fprintf(stderr, "[ogg123/callbacks.c] exit decoder_metadata_callback 1\n");
}


/* ---------------------------------------------------------------------- */

/* These actions are just wrappers for vstatus_message() and vstatus_error() */

typedef struct status_message_arg_t {
  int verbosity;
  char *message;
} status_message_arg_t;


status_message_arg_t *new_status_message_arg (int verbosity)
{
  fprintf(stderr, "[ogg123/callbacks.c] enter new_status_message_arg 1\n");
  status_message_arg_t *arg;

  if ( (arg = calloc(1,sizeof(status_message_arg_t))) == NULL ) {
    fprintf(stderr, "[ogg123/callbacks.c] enter new_status_message_arg 2\n");
    status_error(_("ERROR: Out of memory in new_status_message_arg().\n"));
    exit(1);
    fprintf(stderr, "[ogg123/callbacks.c] exit new_status_message_arg 2\n");
  }

  arg->verbosity = verbosity;

  return arg;
  fprintf(stderr, "[ogg123/callbacks.c] exit new_status_message_arg 1\n");
}


void status_error_action (buf_t *buf, void *arg)
{
  fprintf(stderr, "[ogg123/callbacks.c] enter status_error_action 1\n");
  status_message_arg_t *myarg = (status_message_arg_t *) arg;

  status_error("%s", myarg->message);

  free(myarg->message);
  free(myarg);
  fprintf(stderr, "[ogg123/callbacks.c] exit status_error_action 1\n");
}


void status_message_action (buf_t *buf, void *arg)
{
  fprintf(stderr, "[ogg123/callbacks.c] enter status_message_action 1\n");
  status_message_arg_t *myarg = (status_message_arg_t *) arg;

  status_message(myarg->verbosity, "%s", myarg->message);

  free(myarg->message);
  free(myarg);
  fprintf(stderr, "[ogg123/callbacks.c] exit status_message_action 1\n");
}

/* -------------------------------------------------------------- */

void decoder_buffered_error_callback (void *arg, int severity, 
				      char *message, ...)
{
  fprintf(stderr, "[ogg123/callbacks.c] enter decoder_buffered_error_callback 1\n");
  va_list ap;
  buf_t *buf = (buf_t *)arg;
  status_message_arg_t *sm_arg = new_status_message_arg(0);
  int n, size = 80; /* Guess we need no more than 80 bytes. */


  /* Preformat the string and allocate space for it.  This code taken
     straight from the vsnprintf() man page.  We do this here because
     we might need to reinit ap several times. */
  if ((sm_arg->message = calloc (size,1)) == NULL) {
    fprintf(stderr, "[ogg123/callbacks.c] enter decoder_buffered_error_callback 2\n");
    status_error(_("Error: Out of memory in decoder_buffered_metadata_callback().\n"));
    exit(1);
    fprintf(stderr, "[ogg123/callbacks.c] exit decoder_buffered_error_callback 2\n");
  }

  while (1) {
    fprintf(stderr, "[ogg123/callbacks.c] enter decoder_buffered_error_callback 3\n");
    /* Try to print in the allocated space. */
    va_start(ap, message);
    n = vsnprintf (sm_arg->message, size, message, ap);
    va_end(ap);

    /* If that worked, return the string. */
    if (n > -1 && n < size) {
      fprintf(stderr, "[ogg123/callbacks.c] enter decoder_buffered_error_callback 4\n");
      break;
      fprintf(stderr, "[ogg123/callbacks.c] exit decoder_buffered_error_callback 4\n");
    }
    /* Else try again with more space. */
    if (n > -1) {   /* glibc 2.1 */
      fprintf(stderr, "[ogg123/callbacks.c] enter decoder_buffered_error_callback 5\n");
      size = n+1; /* precisely what is needed */
      fprintf(stderr, "[ogg123/callbacks.c] exit decoder_buffered_error_callback 5\n");
    }
    else {          /* glibc 2.0 */
      fprintf(stderr, "[ogg123/callbacks.c] enter decoder_buffered_error_callback 6\n");
      size *= 2;  /* twice the old size */
      fprintf(stderr, "[ogg123/callbacks.c] exit decoder_buffered_error_callback 6\n");
    }
    if ((sm_arg->message = realloc (sm_arg->message, size)) == NULL) {
      fprintf(stderr, "[ogg123/callbacks.c] enter decoder_buffered_error_callback 7\n");
      status_error(_("Error: Out of memory in decoder_buffered_metadata_callback().\n"));
      exit(1);
      fprintf(stderr, "[ogg123/callbacks.c] exit decoder_buffered_error_callback 7\n");
    }
    fprintf(stderr, "[ogg123/callbacks.c] exit decoder_buffered_error_callback 3\n");
  }


  switch (severity) {
  case ERROR:
    fprintf(stderr, "[ogg123/callbacks.c] enter decoder_buffered_error_callback 8\n");
    buffer_append_action_at_end(buf, &status_error_action, sm_arg);
    fprintf(stderr, "[ogg123/callbacks.c] exit decoder_buffered_error_callback 8\n");
    break;
  case WARNING:
    fprintf(stderr, "[ogg123/callbacks.c] enter decoder_buffered_error_callback 9\n");
    sm_arg->verbosity = WARNING_VERBOSITY;
    buffer_append_action_at_end(buf, &status_message_action, sm_arg);
    fprintf(stderr, "[ogg123/callbacks.c] exit decoder_buffered_error_callback 9\n");
    break;
  case INFO:
    fprintf(stderr, "[ogg123/callbacks.c] enter decoder_buffered_error_callback 10\n");
    sm_arg->verbosity = INFO_VERBOSITY;
    buffer_append_action_at_end(buf, &status_message_action, sm_arg);
    fprintf(stderr, "[ogg123/callbacks.c] exit decoder_buffered_error_callback 10\n");
    break;
  }

  fprintf(stderr, "[ogg123/callbacks.c] exit decoder_buffered_error_callback 1\n");
}


void decoder_buffered_metadata_callback (void *arg, int verbosity, 
					 char *message, ...)
{
  fprintf(stderr, "\n");
  va_list ap;
  buf_t *buf = (buf_t *)arg;
  status_message_arg_t *sm_arg = new_status_message_arg(0);
  int n, size = 80; /* Guess we need no more than 80 bytes. */


  /* Preformat the string and allocate space for it.  This code taken
     straight from the vsnprintf() man page.  We do this here because
     we might need to reinit ap several times. */
  if ((sm_arg->message = calloc (size,1)) == NULL) {
    fprintf(stderr, "[ogg123/callbacks.c] enter decoder_buffered_metadata_callback 2\n");
    status_error(_("ERROR: Out of memory in decoder_buffered_metadata_callback().\n"));
    exit(1);
    fprintf(stderr, "[ogg123/callbacks.c] exit decoder_buffered_metadata_callback 2\n");
  }

  while (1) {
    fprintf(stderr, "[ogg123/callbacks.c] enter decoder_buffered_metadata_callback 3\n");
    /* Try to print in the allocated space. */
    va_start(ap, message);
    n = vsnprintf (sm_arg->message, size, message, ap);
    va_end(ap);

    /* If that worked, return the string. */
    if (n > -1 && n < size) {
      fprintf(stderr, "[ogg123/callbacks.c] enter decoder_buffered_metadata_callback 4\n");
      break;
      fprintf(stderr, "[ogg123/callbacks.c] exit decoder_buffered_metadata_callback 4\n");
    }
    /* Else try again with more space. */
    if (n > -1) {   /* glibc 2.1 */
      fprintf(stderr, "[ogg123/callbacks.c] enter decoder_buffered_metadata_callback 5\n");
      size = n+1; /* precisely what is needed */
      fprintf(stderr, "[ogg123/callbacks.c] exit decoder_buffered_metadata_callback 5\n");
    }
    else {          /* glibc 2.0 */
      fprintf(stderr, "[ogg123/callbacks.c] enter decoder_buffered_metadata_callback 6\n");
      size *= 2;  /* twice the old size */
      fprintf(stderr, "[ogg123/callbacks.c] exit decoder_buffered_metadata_callback 6\n");
    }
    if ((sm_arg->message = realloc (sm_arg->message, size)) == NULL) {
      fprintf(stderr, "[ogg123/callbacks.c] enter decoder_buffered_metadata_callback 7\n");
      status_error(_("ERROR: Out of memory in decoder_buffered_metadata_callback().\n"));
      exit(1);
      fprintf(stderr, "[ogg123/callbacks.c] exit decoder_buffered_metadata_callback 7\n");
    }
    fprintf(stderr, "[ogg123/callbacks.c] exit decoder_buffered_metadata_callback 3\n");
  }

  fprintf(stderr, "[ogg123/callbacks.c] enter decoder_buffered_metadata_callback 8\n");
  sm_arg->verbosity = verbosity;
  buffer_append_action_at_end(buf, &status_message_action, sm_arg);
  fprintf(stderr, "[ogg123/callbacks.c] exit decoder_buffered_metadata_callback 8\n");
}
// Total cost: 0.105444
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 366)]
// Total instrumented cost: 0.105444, input tokens: 5700, output tokens: 5446, cache read tokens: 2280, cache write tokens: 3416

/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE OggVorbis SOFTWARE CODEC SOURCE CODE.   *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS BEFORE DISTRIBUTING.                     *
 *                                                                  *
 * THE Ogg123 SOURCE CODE IS (C) COPYRIGHT 2000-2001                *
 * by Stan Seibert <volsung@xiph.org> AND OTHER CONTRIBUTORS        *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

 last mod: $Id$

 ********************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "transport.h"
#include "i18n.h"


typedef struct file_private_t {
  FILE *fp;
  data_source_stats_t stats;
  int seekable;
} file_private_t;


transport_t file_transport;  /* Forward declaration */


int file_can_transport (const char *source_string)
{
  fprintf(stderr, "[ogg123/file_transport.c] enter file_can_transport 1\n");
  return 1;  /* The file transport is tested last, so always try it */
  fprintf(stderr, "[ogg123/file_transport.c] exit file_can_transport 1\n");
}

data_source_t* file_open (const char *source_string, ogg123_options_t *ogg123_opts)
{
  fprintf(stderr, "[ogg123/file_transport.c] enter file_open 1\n");
  data_source_t *source;
  file_private_t *private;

  /* Allocate data source structures */
  source = malloc(sizeof(data_source_t));
  private = malloc(sizeof(file_private_t));
  fprintf(stderr, "[ogg123/file_transport.c] exit file_open 1\n");

  if (source != NULL && private != NULL) {
    fprintf(stderr, "[ogg123/file_transport.c] enter file_open 2\n");
    source->source_string = strdup(source_string);
    source->transport = &file_transport;
    source->private = private;

    private->seekable = 1;
    private->stats.transfer_rate = 0;
    private->stats.bytes_read = 0;
    private->stats.input_buffer_used = 0;
    fprintf(stderr, "[ogg123/file_transport.c] exit file_open 2\n");
  } else {
    fprintf(stderr, "[ogg123/file_transport.c] enter file_open 3\n");
    fprintf(stderr, _("ERROR: Out of memory.\n"));
    exit(1);
    fprintf(stderr, "[ogg123/file_transport.c] exit file_open 3\n");
  }

  fprintf(stderr, "[ogg123/file_transport.c] enter file_open 4\n");
  /* Open file */
  if (strcmp(source_string, "-") == 0) {
    fprintf(stderr, "[ogg123/file_transport.c] enter file_open 5\n");
    private->fp = stdin;
    private->seekable = 0;
    fprintf(stderr, "[ogg123/file_transport.c] exit file_open 5\n");
  } else {
    fprintf(stderr, "[ogg123/file_transport.c] enter file_open 6\n");
    private->fp = fopen(source_string, "r");
    fprintf(stderr, "[ogg123/file_transport.c] exit file_open 6\n");
  }

  if (private->fp == NULL) {
    fprintf(stderr, "[ogg123/file_transport.c] enter file_open 7\n");
    free(source->source_string);
    free(private);
    free(source);

    return NULL;
    fprintf(stderr, "[ogg123/file_transport.c] exit file_open 7\n");
  }

  return source;
  fprintf(stderr, "[ogg123/file_transport.c] exit file_open 4\n");
}


int file_peek (data_source_t *source, void *ptr, size_t size, size_t nmemb)
{
  fprintf(stderr, "[ogg123/file_transport.c] enter file_peek 1\n");
  file_private_t *private = source->private;
  FILE *fp = private->fp;
  int items;
  long start;
  fprintf(stderr, "[ogg123/file_transport.c] exit file_peek 1\n");

  if (!private->seekable) {
    fprintf(stderr, "[ogg123/file_transport.c] enter file_peek 2\n");
    return 0;
    fprintf(stderr, "[ogg123/file_transport.c] exit file_peek 2\n");
  }

  fprintf(stderr, "[ogg123/file_transport.c] enter file_peek 3\n");
  /* Record where we are */
  start = ftell(fp);

  items = fread(ptr, size, nmemb, fp);
  fprintf(stderr, "[ogg123/file_transport.c] exit file_peek 3\n");

  /* Now go back so we maintain the peek() semantics */
  if (fseek(fp, start, SEEK_SET) != 0) {
    fprintf(stderr, "[ogg123/file_transport.c] enter file_peek 4\n");
    items = 0; /* Flag error condition since we couldn't seek back to
                  the beginning */
    fprintf(stderr, "[ogg123/file_transport.c] exit file_peek 4\n");
  }

  fprintf(stderr, "[ogg123/file_transport.c] enter file_peek 5\n");
  return items;
  fprintf(stderr, "[ogg123/file_transport.c] exit file_peek 5\n");
}


int file_read (data_source_t *source, void *ptr, size_t size, size_t nmemb)
{
  fprintf(stderr, "[ogg123/file_transport.c] enter file_read 1\n");
  file_private_t *private = source->private;
  FILE *fp = private->fp;
  int bytes_read;

  bytes_read = fread(ptr, size, nmemb, fp);
  fprintf(stderr, "[ogg123/file_transport.c] exit file_read 1\n");

  if (bytes_read > 0) {
    fprintf(stderr, "[ogg123/file_transport.c] enter file_read 2\n");
    private->stats.bytes_read += bytes_read;
    fprintf(stderr, "[ogg123/file_transport.c] exit file_read 2\n");
  }

  fprintf(stderr, "[ogg123/file_transport.c] enter file_read 3\n");
  return bytes_read;
  fprintf(stderr, "[ogg123/file_transport.c] exit file_read 3\n");
}


int file_seek (data_source_t *source, long offset, int whence)
{
  fprintf(stderr, "[ogg123/file_transport.c] enter file_seek 1\n");
  file_private_t *private = source->private;
  FILE *fp = private->fp;
  fprintf(stderr, "[ogg123/file_transport.c] exit file_seek 1\n");

  if (!private->seekable) {
    fprintf(stderr, "[ogg123/file_transport.c] enter file_seek 2\n");
    return -1;
    fprintf(stderr, "[ogg123/file_transport.c] exit file_seek 2\n");
  }

  fprintf(stderr, "[ogg123/file_transport.c] enter file_seek 3\n");
  return fseek(fp, offset, whence);  
  fprintf(stderr, "[ogg123/file_transport.c] exit file_seek 3\n");
}


data_source_stats_t * file_statistics (data_source_t *source)
{
  fprintf(stderr, "[ogg123/file_transport.c] enter file_statistics 1\n");
  file_private_t *private = source->private;

  return malloc_data_source_stats(&private->stats);
  fprintf(stderr, "[ogg123/file_transport.c] exit file_statistics 1\n");
}


long file_tell (data_source_t *source)
{
  fprintf(stderr, "[ogg123/file_transport.c] enter file_tell 1\n");
  file_private_t *private = source->private;
  FILE *fp = private->fp;
  fprintf(stderr, "[ogg123/file_transport.c] exit file_tell 1\n");

  if (!private->seekable) {
    fprintf(stderr, "[ogg123/file_transport.c] enter file_tell 2\n");
    return -1;
    fprintf(stderr, "[ogg123/file_transport.c] exit file_tell 2\n");
  }

  fprintf(stderr, "[ogg123/file_transport.c] enter file_tell 3\n");
  return ftell(fp);
  fprintf(stderr, "[ogg123/file_transport.c] exit file_tell 3\n");
}


void file_close (data_source_t *source)
{
  fprintf(stderr, "[ogg123/file_transport.c] enter file_close 1\n");
  file_private_t *private = source->private;
  FILE *fp = private->fp;

  fclose(fp);

  free(source->source_string);
  free(source->private);
  free(source);
  fprintf(stderr, "[ogg123/file_transport.c] exit file_close 1\n");
}


transport_t file_transport = {
  "file",
  &file_can_transport,
  &file_open,
  &file_peek,
  &file_read,
  &file_seek,
  &file_statistics,
  &file_tell,
  &file_close
};
// Total cost: 0.042066
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 178)]
// Total instrumented cost: 0.042066, input tokens: 3664, output tokens: 2137, cache read tokens: 2280, cache write tokens: 1380

/*
 * vgfilter.c (c) 2007,2008 William Poetra Yoga Hadisoeseno
 * based on:
 * vgplay.c 1.0 (c) 2003 John Morton
*/

/* vgplay.c 1.0 (c) 2003 John Morton
 *
 * Portions of this file are (C) COPYRIGHT 1994-2002 by 
 * the XIPHOPHORUS Company http://www.xiph.org/
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the
 * distribution.
 *
 * - Neither the name of the Xiph.org Foundation nor the names of its
 * contributors may be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 **********************************************************************
 *
 * vgfilter - a filter for ov_read_filter to enable replay gain.
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <math.h>

#include <vorbis/codec.h>
#include <vorbis/vorbisfile.h>

#include "vgfilter.h"

/*
 * Initialize the replaygain parameters from vorbis comments.
 */
void vg_init(vgain_state *vg, vorbis_comment *vc) {
  fprintf(stderr, "[ogg123/vgfilter.c] enter vg_init 1\n");
  float track_gain_db = 0.00, track_peak = 1.00;
  char *tag = NULL;
  fprintf(stderr, "[ogg123/vgfilter.c] exit vg_init 1\n");

  if (vc) {
    fprintf(stderr, "[ogg123/vgfilter.c] enter vg_init 2\n");
    if ((tag = vorbis_comment_query(vc, "replaygain_album_gain", 0))
        || (tag = vorbis_comment_query(vc, "rg_audiophile", 0))) {
      fprintf(stderr, "[ogg123/vgfilter.c] enter vg_init 3\n");
      track_gain_db = atof(tag);
      fprintf(stderr, "[ogg123/vgfilter.c] exit vg_init 3\n");
    }
    else if ((tag = vorbis_comment_query(vc, "replaygain_track_gain", 0))
        || (tag = vorbis_comment_query(vc, "rg_radio", 0))) {
      fprintf(stderr, "[ogg123/vgfilter.c] enter vg_init 4\n");
      track_gain_db = atof(tag);
      fprintf(stderr, "[ogg123/vgfilter.c] exit vg_init 4\n");
    }

    if ((tag = vorbis_comment_query(vc, "replaygain_album_peak", 0))
        || (tag = vorbis_comment_query(vc, "replaygain_track_peak", 0))
        || (tag = vorbis_comment_query(vc, "rg_peak", 0))) {
      fprintf(stderr, "[ogg123/vgfilter.c] enter vg_init 5\n");
      track_peak = atof(tag);
      fprintf(stderr, "[ogg123/vgfilter.c] exit vg_init 5\n");
    }
    fprintf(stderr, "[ogg123/vgfilter.c] exit vg_init 2\n");
  }

  fprintf(stderr, "[ogg123/vgfilter.c] enter vg_init 6\n");
  vg->scale_factor = pow(10.0, (track_gain_db + VG_PREAMP_DB)/20);
  vg->max_scale = 1.0 / track_peak;
  fprintf(stderr, "[ogg123/vgfilter.c] exit vg_init 6\n");
}


/*
 * This is the filter function for the decoded Ogg Vorbis stream.
 */
void vg_filter(float **pcm, long channels, long samples, void *filter_param)
{
  fprintf(stderr, "[ogg123/vgfilter.c] enter vg_filter 1\n");
  int i, j;
  float cur_sample;
  vgain_state *param = filter_param;
  float scale_factor = param->scale_factor;
  float max_scale = param->max_scale;
  fprintf(stderr, "[ogg123/vgfilter.c] exit vg_filter 1\n");

  /* Apply the gain, and any limiting necessary */
  if (scale_factor > max_scale) {
    fprintf(stderr, "[ogg123/vgfilter.c] enter vg_filter 2\n");
    for(i = 0; i < channels; i++)
      for(j = 0; j < samples; j++) {
        fprintf(stderr, "[ogg123/vgfilter.c] enter vg_filter 3\n");
        cur_sample = pcm[i][j] * scale_factor;
        /* This is essentially the scaled hard-limiting algorithm */
        /* It looks like the soft-knee to me */
        /* I haven't found a better limiting algorithm yet... */
        if (cur_sample < -0.5) {
          fprintf(stderr, "[ogg123/vgfilter.c] enter vg_filter 4\n");
          cur_sample = tanh((cur_sample + 0.5) / (1-0.5)) * (1-0.5) - 0.5;
          fprintf(stderr, "[ogg123/vgfilter.c] exit vg_filter 4\n");
        }
        else if (cur_sample > 0.5) {
          fprintf(stderr, "[ogg123/vgfilter.c] enter vg_filter 5\n");
          cur_sample = tanh((cur_sample - 0.5) / (1-0.5)) * (1-0.5) + 0.5;
          fprintf(stderr, "[ogg123/vgfilter.c] exit vg_filter 5\n");
        }
        pcm[i][j] = cur_sample;
        fprintf(stderr, "[ogg123/vgfilter.c] exit vg_filter 3\n");
      }
    fprintf(stderr, "[ogg123/vgfilter.c] exit vg_filter 2\n");
  } else if (scale_factor > 0.0) {
    fprintf(stderr, "[ogg123/vgfilter.c] enter vg_filter 6\n");
    for(i = 0; i < channels; i++)
      for(j = 0; j < samples; j++) {
        fprintf(stderr, "[ogg123/vgfilter.c] enter vg_filter 7\n");
        pcm[i][j] *= scale_factor;
        fprintf(stderr, "[ogg123/vgfilter.c] exit vg_filter 7\n");
      }
    fprintf(stderr, "[ogg123/vgfilter.c] exit vg_filter 6\n");
  }
}
// Total cost: 0.039404
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 115)]
// Total instrumented cost: 0.039404, input tokens: 3774, output tokens: 1910, cache read tokens: 2280, cache write tokens: 1490

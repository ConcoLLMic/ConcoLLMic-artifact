/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE OggVorbis SOFTWARE CODEC SOURCE CODE.   *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS BEFORE DISTRIBUTING.                     *
 *                                                                  *
 * THE Ogg123 SOURCE CODE IS (C) COPYRIGHT 2000-2001                *
 * by Stan Seibert <volsung@xiph.org> AND OTHER CONTRIBUTORS        *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

 last mod: $Id$

 ********************************************************************/


/* if strcasecmp is giving you problems, switch to strcmp or the appropriate
 * function for your platform / compiler.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <limits.h> /* for INT/LONG_MIN/MAX */
#include <errno.h>

#include "cfgfile_options.h"
#include "status.h"
#include "i18n.h"

/* ------------------- Private Functions ---------------------- */

int print_space (FILE *f, int s, int c)
{
  fprintf(stderr, "[ogg123/cfgfile_options.c] enter print_space 1\n");
  int tmp = 0;
  do {
    fputc (c, f);
    tmp++;
  } while (--s > 0);
  return tmp;
  fprintf(stderr, "[ogg123/cfgfile_options.c] exit print_space 1\n");
}


int parse_error (parse_code_t pcode, int lineno, const char *filename,
		 char *line)
{
  fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_error 1\n");
  if (pcode == parse_syserr) {
    fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_error 2\n");
    if (errno != EEXIST && errno != ENOENT)
      perror (_("System error"));
    return -1;
    fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_error 2\n");
  } else {
    fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_error 3\n");
    status_error (_("=== Parse error: %s on line %d of %s (%s)\n"), 
		  parse_error_string(pcode), 
		  lineno, filename, line);
    return 0;
    fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_error 3\n");
  }
  fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_error 1\n");
}


/* ------------------- Public Interface ----------------------- */

void file_options_init (file_option_t opts[])
{
  fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_init 1\n");

  while (opts && opts->name) {
    fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_init 2\n");

    opts->found = 0;

    if (opts->dfl) {
      fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_init 3\n");
      switch (opts->type) {
      case opt_type_none:
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_init 4\n");
	/* do nothing */
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_init 4\n");
	break;
	
      case opt_type_char:
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_init 5\n");
	*(char *) opts->ptr = *(char*) opts->dfl;
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_init 5\n");
	break;
	
      case opt_type_string:
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_init 6\n");
	*(char **) opts->ptr = *(char **) opts->dfl;
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_init 6\n");
	break;

      case opt_type_bool:
      case opt_type_int:
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_init 7\n");
	*(int *) opts->ptr = *(int *) opts->dfl;
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_init 7\n");
	break;
	
      case opt_type_float:
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_init 8\n");
	*(float *) opts->ptr = *(float *) opts->dfl;
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_init 8\n");
	break;
	
      case opt_type_double:
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_init 9\n");
	*(double *) opts->ptr = *(double *) opts->dfl;
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_init 9\n");
	break;
      }
      fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_init 3\n");
    }

    opts++;
    fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_init 2\n");
  }
  fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_init 1\n");
}


/* DescribeOptions - describe available options to outfile */
void file_options_describe (file_option_t opts[], FILE *f)
{
  fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_describe 1\n");
  /* name | description | type | default */
  int colWidths[] = {0, 0, 7, 7};
  int totalWidth = 0;
  file_option_t *opt = opts;

  while (opt->name) {
    fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_describe 2\n");
    int len = strlen (opt->name) + 1;
    if (len  > colWidths[0])
      colWidths[0] = len;
    opt++;
    fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_describe 2\n");
  }

  opt = opts;
  while (opt->name) {
    fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_describe 3\n");
    int len = strlen (opt->desc) + 1;
    if (len > colWidths[1])
      colWidths[1] = len;
    opt++;
    fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_describe 3\n");
  }

  /* Column headers */
  /* Name */
  fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_describe 4\n");
  totalWidth += fprintf (f, "%-*s", colWidths[0], _("Name"));

  /* Description */
  totalWidth += fprintf (f, "%-*s", colWidths[1], _("Description"));

  /* Type */
  totalWidth += fprintf (f, "%-*s", colWidths[2], _("Type"));

  /* Default */
  totalWidth += fprintf (f, "%-*s", colWidths[3], _("Default"));

  fputc ('\n', f);

  /* Divider */
  print_space (f, totalWidth, '-');

  fputc ('\n', f);
  fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_describe 4\n");

  opt = opts;
  while (opt->name)
    {
      fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_describe 5\n");
      /* name */
      int w = colWidths[0];
      w -= fprintf (f, "%s", opt->name);
      print_space (f, w, ' ');

      /* description */
      w = colWidths[1];
      w -= fprintf (f, "%s", opt->desc);
      print_space (f, w, ' ');

      /* type */
      w = colWidths[2];
      switch (opt->type) {
      case opt_type_none:
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_describe 6\n");
	w -= fprintf (f, _("none"));
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_describe 6\n");
	break;
      case opt_type_bool:
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_describe 7\n");
	w -= fprintf (f, _("bool"));
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_describe 7\n");
	break;
      case opt_type_char:
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_describe 8\n");
	w -= fprintf (f, _("char"));
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_describe 8\n");
	break;
      case opt_type_string:
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_describe 9\n");
	w -= fprintf (f, _("string"));
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_describe 9\n");
	break;
      case opt_type_int:
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_describe 10\n");
	w -= fprintf (f, _("int"));
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_describe 10\n");
	break;
      case opt_type_float:
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_describe 11\n");
	w -= fprintf (f, _("float"));
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_describe 11\n");
	break;
      case opt_type_double:
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_describe 12\n");
	w -= fprintf (f, _("double"));
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_describe 12\n");
	break;
      default:
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_describe 13\n");
	w -= fprintf (f, _("other"));
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_describe 13\n");
      }
      print_space (f, w, ' ');

      /* default */
      if (opt->dfl == NULL) {
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_describe 14\n");
	fputs (_("(NULL)"), f);
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_describe 14\n");
      }
      else {
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_describe 15\n");
	switch (opt->type) {
	case opt_type_none:
          fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_describe 16\n");
	  fputs (_("(none)"), f);
	  fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_describe 16\n");
	  break;
	case opt_type_char:
          fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_describe 17\n");
	  fputc (*(char *) opt->dfl, f);
	  fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_describe 17\n");
	  break;
	case opt_type_string:
          fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_describe 18\n");
	  fputs (*(char **) opt->dfl, f);
	  fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_describe 18\n");
	  break;
	case opt_type_bool:
	case opt_type_int:
          fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_describe 19\n");
	  fprintf (f, "%d", *(int *) opt->dfl);
	  fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_describe 19\n");
	  break;
	case opt_type_float:
          fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_describe 20\n");
	  fprintf (f, "%f", (double) (*(float *) opt->dfl));
	  fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_describe 20\n");
	  break;
	case opt_type_double:
          fprintf(stderr, "[ogg123/cfgfile_options.c] enter file_options_describe 21\n");
	  fprintf (f, "%f", *(double *) opt->dfl);
	  fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_describe 21\n");
	  break;
	}
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_describe 15\n");
      }
      fputc ('\n', f);
      opt++;
      fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_describe 5\n");
    }
  fprintf(stderr, "[ogg123/cfgfile_options.c] exit file_options_describe 1\n");
}


parse_code_t parse_line (file_option_t opts[], char *line)
{
  fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 1\n");
  char *equals, *value = "";
  file_option_t *opt;
  int len;

  /* skip leading whitespace */
  while (line[0] == ' ')
    line++;

  /* remove comments */
  equals = strchr (line, '#');
  if (equals)
    *equals = '\0';

  /* return if only whitespace on line */
  if (!line[0] || line[0] == '#') {
    fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 2\n");
    return parse_ok;
    fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 2\n");
  }

  /* check for an '=' and set to \0 */
  equals = strchr (line, '=');
  if (equals) {
    fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 3\n");
    value = equals + 1;
    *equals = '\0';
    fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 3\n");
  }

  /* cut trailing whitespace from key (line = key now) */
  while ((equals = strrchr(line, ' ')))
    *equals = '\0';

  /* remove this if you want a zero-length key */
  if (strlen(line) == 0) {
    fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 4\n");
    return parse_nokey;
    fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 4\n");
  }

  if (value) {
    fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 5\n");
    /* cut leading whitespace from value */
    while (*value == ' ')
      value++;

    /* cut trailing whitespace from value */
    len = strlen (value);
    while (len > 0 && value[len-1] == ' ') {
      len--;
      value[len] = '\0';
    }
    fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 5\n");
  }

  /* now key is in line and value is in value. Search for a matching option. */
  opt = opts;
  while (opt->name) {
    fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 6\n");
    if (!strcasecmp (opt->name, line)) {
      fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 7\n");
      long tmpl;
      char *endptr;

      /* found the key. now set the value. */
      switch (opt->type) {
      case opt_type_none:
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 8\n");
	if (value != NULL || strlen(value) > 0) {
          fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 9\n");
	  return parse_badvalue;
          fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 9\n");
        }
	opt->found++;
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 8\n");
	break;

      case opt_type_bool:
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 10\n");
	if (!value || *value == '\0') {
          fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 11\n");
	  return parse_badvalue;
          fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 11\n");
        }
	
	/* Maybe this is a numeric bool */
	tmpl = strtol (value, &endptr, 0);

	if ( !strncasecmp(value, "y", 1)
	     || !strcasecmp(value, "true")
	     || (*endptr == '\0' && tmpl) ) {
          fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 12\n");
	  *(int *) opt->ptr = 1;
          fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 12\n");
        }
	else if ( !strncasecmp(value, "n", 1)
		  || !strcasecmp(value, "false")
		  || (*endptr == '\0' && !tmpl) ) {
          fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 13\n");
	  *(int *) opt->ptr = 0;
          fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 13\n");
        }
	else {
          fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 14\n");
	  return parse_badvalue;
          fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 14\n");
        }
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 10\n");
	break;

      case opt_type_char:
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 15\n");
	if (strlen(value) != 1) {
          fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 16\n");
	  return parse_badvalue;
          fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 16\n");
        }
	opt->found++;
	*(char *) opt->ptr = value[0];
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 15\n");
	break;

      case opt_type_string:
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 17\n");
	opt->found++;
	if (*(char **)opt->ptr) free(*(char **)opt->ptr);
	*(char **) opt->ptr = strdup (value);
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 17\n");
	break;

      case opt_type_int:
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 18\n");
	if (!value || *value == '\0') {
          fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 19\n");
	  return parse_badvalue;
          fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 19\n");
        }
	errno = 0;
	tmpl = strtol (value, &endptr, 0);
	if (((tmpl == LONG_MIN || tmpl == LONG_MAX) && errno == ERANGE)
	    || (*endptr != '\0')) {
          fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 20\n");
	  return parse_badvalue;
          fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 20\n");
        }
	if ((tmpl > INT_MAX) || (tmpl < INT_MIN)) {
          fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 21\n");
	  return parse_badvalue;
          fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 21\n");
        }
	opt->found++;
	*(int *) opt->ptr = tmpl;
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 18\n");
	break;
	
      case opt_type_float:
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 22\n");
	if (!value || *value == '\0') {
          fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 23\n");
	  return parse_badvalue;
          fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 23\n");
        }
	opt->found++;
	*(float *) opt->ptr = atof (value);
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 22\n");
	break;

      case opt_type_double:
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 24\n");
	if (!value || *value == '\0') {
          fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 25\n");
	  return parse_badvalue;
          fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 25\n");
        }
	opt->found++;
	*(double *) opt->ptr = atof (value);
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 24\n");
	break;

      default:
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 26\n");
	return parse_badtype;
	fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 26\n");
      }
      fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 27\n");
      return parse_ok;
      fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 27\n");
      fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 7\n");
    }
    opt++;
    fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 6\n");
  }
  fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_line 28\n");
  return parse_keynotfound;
  fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 28\n");
  fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_line 1\n");
}


parse_code_t parse_config_file (file_option_t opts[], const char *filename)
{
  fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_config_file 1\n");
  unsigned int len=80;
  char *line = malloc(len);
  int readoffset, thischar, lineno;
  FILE *file;
  parse_code_t pcode;
  char empty[] = "";

  if (!line) {
      fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_config_file 2\n");
      parse_error(parse_syserr, 0, empty, empty);
      return parse_syserr;
      fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_config_file 2\n");
  }

  file = fopen (filename, "r");
  if (!file) {
      fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_config_file 3\n");
      parse_error (parse_syserr, 0, empty, empty);
      free (line);
      return parse_syserr;
      fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_config_file 3\n");
  }

  lineno = 0;
  while (!feof (file)) {
    fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_config_file 4\n");

    lineno++;
    readoffset = 0;
    memset (line, 0, len);

    while ((thischar = fgetc(file)) != EOF) {
      fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_config_file 5\n");

      if (readoffset + 1 > len) {
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_config_file 6\n");
	len *= 2;
	line = realloc (line, len);
	if (!line)
	  {
	    parse_error(parse_syserr, 0, empty, empty);
	    fclose (file);
	    return parse_syserr;
	  }
        fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_config_file 6\n");
      }

      if (thischar == '\n') {
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_config_file 7\n");
	line[readoffset] = '\0';
	break;
        fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_config_file 7\n");
      }
      else {
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_config_file 8\n");
	line[readoffset] = (unsigned char) thischar;
        fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_config_file 8\n");
      }
      readoffset++;
      fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_config_file 5\n");
    }

    pcode = parse_line (opts, line);

    if (pcode != parse_ok) {
      fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_config_file 9\n");
      if (!parse_error(pcode, lineno, filename, line)) {
        fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_config_file 10\n");
	free (line);
	return pcode;
        fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_config_file 10\n");
      }
      fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_config_file 9\n");
    }
    fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_config_file 4\n");
  }

  fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_config_file 11\n");
  free (line);
  return parse_ok;
  fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_config_file 11\n");
  fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_config_file 1\n");
}

/* ParseErr - returns a string corresponding to parse code pcode */
const char *parse_error_string (parse_code_t pcode)
{
  fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_error_string 1\n");
  switch (pcode) {
  case parse_ok:
    fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_error_string 2\n");
    return _("Success");
    fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_error_string 2\n");
  case parse_syserr:
    fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_error_string 3\n");
    return strerror(errno);
    fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_error_string 3\n");
  case parse_keynotfound:
    fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_error_string 4\n");
    return _("Key not found");
    fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_error_string 4\n");
  case parse_nokey:
    fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_error_string 5\n");
    return _("No key");
    fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_error_string 5\n");
  case parse_badvalue:
    fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_error_string 6\n");
    return _("Bad value");
    fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_error_string 6\n");
  case parse_badtype:
    fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_error_string 7\n");
    return _("Bad type in options list");
    fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_error_string 7\n");
  default:
    fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_error_string 8\n");
    return _("Unknown error");
    fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_error_string 8\n");
  }
  fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_error_string 1\n");
}


void parse_std_configs (file_option_t opts[])
{
  fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_std_configs 1\n");
  char filename[FILENAME_MAX];
  char *homedir = getenv("HOME");

  parse_config_file(opts, SYSCONFDIR "/ogg123rc");
  if (homedir && strlen(homedir) < FILENAME_MAX - 10) {
    fprintf(stderr, "[ogg123/cfgfile_options.c] enter parse_std_configs 2\n");
    /* Try ~/.ogg123 */
    strncpy(filename, homedir, FILENAME_MAX);
    strcat(filename, "/.ogg123rc");
    parse_config_file(opts, filename);
    fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_std_configs 2\n");
  }
  fprintf(stderr, "[ogg123/cfgfile_options.c] exit parse_std_configs 1\n");
}
// Total cost: 0.125286
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 458)]
// Total instrumented cost: 0.125286, input tokens: 6024, output tokens: 6623, cache read tokens: 2280, cache write tokens: 3740

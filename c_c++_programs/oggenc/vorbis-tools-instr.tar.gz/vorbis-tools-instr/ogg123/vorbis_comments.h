/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE OggVorbis SOFTWARE CODEC SOURCE CODE.   *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS BEFORE DISTRIBUTING.                     *
 *                                                                  *
 * THE Ogg123 SOURCE CODE IS (C) COPYRIGHT 2000-2003                *
 * by Stan Seibert <volsung@xiph.org> AND OTHER CONTRIBUTORS        *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************
 
 last mod: $Id$
 
********************************************************************/


#ifndef __VORBIS_COMMENTS_H__
#define __VORBIS_COMMENTS_H__

#include "format.h"


void print_vorbis_comment (const char *comment, decoder_callbacks_t *cb,
			   void *callback_arg);

#endif /* __VORBIS_COMMENTS_H__ */
// Total cost: 0.003397
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 28)]
// Total instrumented cost: 0.003397, input tokens: 2633, output tokens: 23, cache read tokens: 2280, cache write tokens: 349

/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE OggVorbis SOFTWARE CODEC SOURCE CODE.   *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS BEFORE DISTRIBUTING.                     *
 *                                                                  *
 * THE Ogg123 SOURCE CODE IS (C) COPYRIGHT 2000-2001                *
 * by Stan Seibert <volsung@xiph.org> AND OTHER CONTRIBUTORS        *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

 last mod: $Id$

 ********************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <string.h>
#include <limits.h>

#include "audio.h"


int audio_format_equal (audio_format_t *a, audio_format_t *b)
{
  fprintf(stderr, "[ogg123/audio.c] enter audio_format_equal 1\n");
  return 
    a->big_endian    == b->big_endian    &&
    a->word_size     == b->word_size     &&
    a->signed_sample == b->signed_sample &&
    a->rate          == b->rate          &&
    a->channels      == b->channels      &&
    ((a->matrix==NULL && b->matrix==NULL) ||
     !strcmp(a->matrix,b->matrix));
  fprintf(stderr, "[ogg123/audio.c] exit audio_format_equal 1\n");
}

audio_device_t *append_audio_device(audio_device_t *devices_list,
				     int driver_id,
				     ao_option *options, char *filename)
{
  fprintf(stderr, "\n");
  if (devices_list != NULL) {
    fprintf(stderr, "[ogg123/audio.c] enter append_audio_device 2\n");
    while (devices_list->next_device != NULL)
      devices_list = devices_list->next_device;
    devices_list = devices_list->next_device =
      malloc(sizeof(audio_device_t));
    fprintf(stderr, "[ogg123/audio.c] exit append_audio_device 2\n");
  } else {
    fprintf(stderr, "[ogg123/audio.c] enter append_audio_device 3\n");
    devices_list = (audio_device_t *) malloc(sizeof(audio_device_t));
    fprintf(stderr, "[ogg123/audio.c] exit append_audio_device 3\n");
  }
  fprintf(stderr, "[ogg123/audio.c] enter append_audio_device 4\n");
  devices_list->driver_id = driver_id;
  devices_list->options = options;
  devices_list->filename = filename;
  devices_list->device = NULL;
  devices_list->next_device = NULL;

  return devices_list;
  fprintf(stderr, "[ogg123/audio.c] exit append_audio_device 4\n");
}


int audio_devices_write(audio_device_t *d, void *ptr, int nbytes)
{
  fprintf(stderr, "[ogg123/audio.c] enter audio_devices_write 1\n");
  while (d != NULL) {
    fprintf(stderr, "[ogg123/audio.c] enter audio_devices_write 2\n");
    if (ao_play(d->device, ptr, nbytes) == 0)
      return 0; /* error occurred */
    d = d->next_device;
    fprintf(stderr, "[ogg123/audio.c] exit audio_devices_write 2\n");
  }

  return 1;
  fprintf(stderr, "[ogg123/audio.c] exit audio_devices_write 1\n");
}

int add_ao_option(ao_option **op_h, const char *optstring)
{
  fprintf(stderr, "[ogg123/audio.c] enter add_ao_option 1\n");
  char *key, *value;
  int result;

  key = strdup(optstring);
  if (key == NULL)
    return 0;
  fprintf(stderr, "[ogg123/audio.c] exit add_ao_option 1\n");

  fprintf(stderr, "[ogg123/audio.c] enter add_ao_option 2\n");
  value = strchr(key, ':');
  if (value) {
    fprintf(stderr, "[ogg123/audio.c] enter add_ao_option 3\n");
    /* split by replacing the separator with a null */
    *value++ = '\0';
    fprintf(stderr, "[ogg123/audio.c] exit add_ao_option 3\n");
  }

  result = ao_append_option(op_h, key, value);
  free(key);

  return (result);
  fprintf(stderr, "[ogg123/audio.c] exit add_ao_option 2\n");
}

void close_audio_devices (audio_device_t *devices)
{
  fprintf(stderr, "[ogg123/audio.c] enter close_audio_devices 1\n");
  audio_device_t *current = devices;

  while (current != NULL) {
    fprintf(stderr, "[ogg123/audio.c] enter close_audio_devices 2\n");
    if (current->device)
      ao_close(current->device);
    current->device = NULL;
    current = current->next_device;
    fprintf(stderr, "[ogg123/audio.c] exit close_audio_devices 2\n");
  }
  fprintf(stderr, "[ogg123/audio.c] exit close_audio_devices 1\n");
}

void free_audio_devices (audio_device_t *devices)
{
  fprintf(stderr, "[ogg123/audio.c] enter free_audio_devices 1\n");
  audio_device_t *current;

  while (devices != NULL) {
    fprintf(stderr, "[ogg123/audio.c] enter free_audio_devices 2\n");
    current = devices->next_device;
    free (devices);
    devices = current;
    fprintf(stderr, "[ogg123/audio.c] exit free_audio_devices 2\n");
  }
  fprintf(stderr, "[ogg123/audio.c] exit free_audio_devices 1\n");
}

void ao_onexit (void *arg)
{
  fprintf(stderr, "[ogg123/audio.c] enter ao_onexit 1\n");
  audio_device_t *devices = (audio_device_t *) arg;

  close_audio_devices (devices);
  free_audio_devices (devices);

  ao_shutdown();
  fprintf(stderr, "[ogg123/audio.c] exit ao_onexit 1\n");
}
// Total cost: 0.031341
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 127)]
// Total instrumented cost: 0.031341, input tokens: 3364, output tokens: 1557, cache read tokens: 2280, cache write tokens: 1080

/* EasyFLAC - A thin decoding wrapper around libFLAC and libOggFLAC to
 * make your code less ugly.  See easyflac.h for explanation.
 *
 * Copyright 2003 - Stan Seibert <volsung@xiph.org>
 * This code is licensed under a BSD style license:
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * - Neither the name of the Xiph.org Foundation nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <FLAC/export.h>
#if !defined(FLAC_API_VERSION_CURRENT) || (FLAC_API_VERSION_CURRENT < 8)

#include <stdlib.h>
#include <stdio.h>
#include "easyflac.h"

FLAC__bool EasyFLAC__is_oggflac(EasyFLAC__StreamDecoder *decoder)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__is_oggflac 1\n");
	return decoder->is_oggflac;
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__is_oggflac 1\n");
}


EasyFLAC__StreamDecoder *EasyFLAC__stream_decoder_new(FLAC__bool is_oggflac)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__stream_decoder_new 1\n");
	EasyFLAC__StreamDecoder *decoder = malloc(sizeof(EasyFLAC__StreamDecoder));
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__stream_decoder_new 1\n");

	if (decoder != NULL)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__stream_decoder_new 2\n");
		decoder->is_oggflac = is_oggflac;
		
		if (decoder->is_oggflac)
		{
			fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__stream_decoder_new 3\n");
			decoder->oggflac = OggFLAC__stream_decoder_new();
			fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__stream_decoder_new 3\n");
		}
		else
		{
			fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__stream_decoder_new 4\n");
			decoder->flac = FLAC__stream_decoder_new();
			fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__stream_decoder_new 4\n");
		}

		if (  (decoder->is_oggflac && decoder->oggflac == NULL)
		    ||(!decoder->is_oggflac && decoder->flac == NULL)  )
		{
			fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__stream_decoder_new 5\n");
			free(decoder);
			decoder = NULL;
			fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__stream_decoder_new 5\n");
		}
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__stream_decoder_new 2\n");
	}

	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__stream_decoder_new 6\n");
	return decoder;
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__stream_decoder_new 6\n");
}


void EasyFLAC__stream_decoder_delete(EasyFLAC__StreamDecoder *decoder)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__stream_decoder_delete 1\n");
	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__stream_decoder_delete 2\n");
		OggFLAC__stream_decoder_delete(decoder->oggflac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__stream_decoder_delete 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__stream_decoder_delete 3\n");
		FLAC__stream_decoder_delete(decoder->flac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__stream_decoder_delete 3\n");
	}

	free(decoder);
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__stream_decoder_delete 1\n");
}


/* Wrappers around the callbacks for OggFLAC */

FLAC__StreamDecoderReadStatus oggflac_read_callback(const OggFLAC__StreamDecoder *decoder, FLAC__byte buffer[], unsigned *bytes, void *client_data)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter oggflac_read_callback 1\n");
	EasyFLAC__StreamDecoder *e_decoder = (EasyFLAC__StreamDecoder *) client_data;

	return (*e_decoder->callbacks.read)(e_decoder, buffer, bytes, e_decoder->callbacks.client_data);
	fprintf(stderr, "[ogg123/easyflac.c] exit oggflac_read_callback 1\n");
}


FLAC__StreamDecoderWriteStatus oggflac_write_callback(const OggFLAC__StreamDecoder *decoder, const FLAC__Frame *frame, const FLAC__int32 * const buffer[], void *client_data)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter oggflac_write_callback 1\n");
	EasyFLAC__StreamDecoder *e_decoder = (EasyFLAC__StreamDecoder *) client_data;

	return (*(e_decoder->callbacks.write))(e_decoder, frame, buffer, e_decoder->callbacks.client_data);
	fprintf(stderr, "[ogg123/easyflac.c] exit oggflac_write_callback 1\n");
}


void oggflac_metadata_callback(const OggFLAC__StreamDecoder *decoder, const FLAC__StreamMetadata *metadata, void *client_data)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter oggflac_metadata_callback 1\n");
	EasyFLAC__StreamDecoder *e_decoder = (EasyFLAC__StreamDecoder *) client_data;

	(*e_decoder->callbacks.metadata)(e_decoder, metadata, e_decoder->callbacks.client_data);
	fprintf(stderr, "[ogg123/easyflac.c] exit oggflac_metadata_callback 1\n");
}


void oggflac_error_callback(const OggFLAC__StreamDecoder *decoder, FLAC__StreamDecoderErrorStatus status, void *client_data)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter oggflac_error_callback 1\n");
	EasyFLAC__StreamDecoder *e_decoder = (EasyFLAC__StreamDecoder *) client_data;

	(*e_decoder->callbacks.error)(e_decoder, status, e_decoder->callbacks.client_data);
	fprintf(stderr, "[ogg123/easyflac.c] exit oggflac_error_callback 1\n");
}


/* Wrappers around the callbacks for FLAC */

FLAC__StreamDecoderReadStatus flac_read_callback(const FLAC__StreamDecoder *decoder, FLAC__byte buffer[], unsigned *bytes, void *client_data)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter flac_read_callback 1\n");
	EasyFLAC__StreamDecoder *e_decoder = (EasyFLAC__StreamDecoder *) client_data;

	return (*e_decoder->callbacks.read)(e_decoder, buffer, bytes, e_decoder->callbacks.client_data);
	fprintf(stderr, "[ogg123/easyflac.c] exit flac_read_callback 1\n");
}


FLAC__StreamDecoderWriteStatus flac_write_callback(const FLAC__StreamDecoder *decoder, const FLAC__Frame *frame, const FLAC__int32 * const buffer[], void *client_data)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter flac_write_callback 1\n");
	EasyFLAC__StreamDecoder *e_decoder = (EasyFLAC__StreamDecoder *) client_data;

	return (*e_decoder->callbacks.write)(e_decoder, frame, buffer, e_decoder->callbacks.client_data);
	fprintf(stderr, "[ogg123/easyflac.c] exit flac_write_callback 1\n");
}


void flac_metadata_callback(const FLAC__StreamDecoder *decoder, const FLAC__StreamMetadata *metadata, void *client_data)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter flac_metadata_callback 1\n");
	EasyFLAC__StreamDecoder *e_decoder = (EasyFLAC__StreamDecoder *) client_data;

	(*e_decoder->callbacks.metadata)(e_decoder, metadata, e_decoder->callbacks.client_data);
	fprintf(stderr, "[ogg123/easyflac.c] exit flac_metadata_callback 1\n");
}


void flac_error_callback(const FLAC__StreamDecoder *decoder, FLAC__StreamDecoderErrorStatus status, void *client_data)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter flac_error_callback 1\n");
	EasyFLAC__StreamDecoder *e_decoder = (EasyFLAC__StreamDecoder *) client_data;

	(*e_decoder->callbacks.error)(e_decoder, status, e_decoder->callbacks.client_data);
	fprintf(stderr, "[ogg123/easyflac.c] exit flac_error_callback 1\n");
}


FLAC__bool EasyFLAC__set_read_callback(EasyFLAC__StreamDecoder *decoder, EasyFLAC__StreamDecoderReadCallback value)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_read_callback 1\n");
	decoder->callbacks.read = value;
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_read_callback 1\n");

	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_read_callback 2\n");
		return OggFLAC__stream_decoder_set_read_callback(decoder->oggflac, &oggflac_read_callback);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_read_callback 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_read_callback 3\n");
		return FLAC__stream_decoder_set_read_callback(decoder->flac, &flac_read_callback);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_read_callback 3\n");
	}
}


FLAC__bool EasyFLAC__set_write_callback(EasyFLAC__StreamDecoder *decoder, EasyFLAC__StreamDecoderWriteCallback value)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_write_callback 1\n");
	decoder->callbacks.write = value;
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_write_callback 1\n");

	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_write_callback 2\n");
		return OggFLAC__stream_decoder_set_write_callback(decoder->oggflac, &oggflac_write_callback);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_write_callback 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_write_callback 3\n");
		return FLAC__stream_decoder_set_write_callback(decoder->flac, &flac_write_callback);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_write_callback 3\n");
	}
}


FLAC__bool EasyFLAC__set_metadata_callback(EasyFLAC__StreamDecoder *decoder, EasyFLAC__StreamDecoderMetadataCallback value)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_metadata_callback 1\n");
	decoder->callbacks.metadata = value;
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_metadata_callback 1\n");

	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_metadata_callback 2\n");
		return OggFLAC__stream_decoder_set_metadata_callback(decoder->oggflac, &oggflac_metadata_callback);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_metadata_callback 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_metadata_callback 3\n");
		return FLAC__stream_decoder_set_metadata_callback(decoder->flac, &flac_metadata_callback);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_metadata_callback 3\n");
	}
}


FLAC__bool EasyFLAC__set_error_callback(EasyFLAC__StreamDecoder *decoder, EasyFLAC__StreamDecoderErrorCallback value)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_error_callback 1\n");
	decoder->callbacks.error = value;
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_error_callback 1\n");

	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_error_callback 2\n");
		return OggFLAC__stream_decoder_set_error_callback(decoder->oggflac, &oggflac_error_callback);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_error_callback 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_error_callback 3\n");
		return FLAC__stream_decoder_set_error_callback(decoder->flac, &flac_error_callback);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_error_callback 3\n");
	}
}


FLAC__bool EasyFLAC__set_client_data(EasyFLAC__StreamDecoder *decoder, void *value)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_client_data 1\n");
	decoder->callbacks.client_data = value;
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_client_data 1\n");
	
	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_client_data 2\n");
		return OggFLAC__stream_decoder_set_client_data(decoder->oggflac, decoder);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_client_data 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_client_data 3\n");
		return FLAC__stream_decoder_set_client_data(decoder->flac, decoder);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_client_data 3\n");
	}
}


FLAC__bool EasyFLAC__set_metadata_respond(EasyFLAC__StreamDecoder *decoder, FLAC__MetadataType type)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_metadata_respond 1\n");
	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_metadata_respond 2\n");
		return OggFLAC__stream_decoder_set_metadata_respond(decoder->oggflac, type);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_metadata_respond 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_metadata_respond 3\n");
		return FLAC__stream_decoder_set_metadata_respond(decoder->flac, type);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_metadata_respond 3\n");
	}
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_metadata_respond 1\n");
}


FLAC__bool EasyFLAC__set_metadata_respond_application(EasyFLAC__StreamDecoder *decoder, const FLAC__byte id[4])
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_metadata_respond_application 1\n");
	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_metadata_respond_application 2\n");
		return OggFLAC__stream_decoder_set_metadata_respond_application(decoder->oggflac, id);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_metadata_respond_application 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_metadata_respond_application 3\n");
		return FLAC__stream_decoder_set_metadata_respond_application(decoder->flac, id);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_metadata_respond_application 3\n");
	}
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_metadata_respond_application 1\n");
}


FLAC__bool EasyFLAC__set_metadata_respond_all(EasyFLAC__StreamDecoder *decoder)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_metadata_respond_all 1\n");
	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_metadata_respond_all 2\n");
		return OggFLAC__stream_decoder_set_metadata_respond_all(decoder->oggflac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_metadata_respond_all 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_metadata_respond_all 3\n");
		return FLAC__stream_decoder_set_metadata_respond_all(decoder->flac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_metadata_respond_all 3\n");
	}
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_metadata_respond_all 1\n");
}


FLAC__bool EasyFLAC__set_metadata_ignore(EasyFLAC__StreamDecoder *decoder, FLAC__MetadataType type)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_metadata_ignore 1\n");
	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_metadata_ignore 2\n");
		return OggFLAC__stream_decoder_set_metadata_ignore(decoder->oggflac, type);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_metadata_ignore 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_metadata_ignore 3\n");
		return FLAC__stream_decoder_set_metadata_ignore(decoder->flac, type);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_metadata_ignore 3\n");
	}
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_metadata_ignore 1\n");
}


FLAC__bool EasyFLAC__set_metadata_ignore_application(EasyFLAC__StreamDecoder *decoder, const FLAC__byte id[4])
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_metadata_ignore_application 1\n");
	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_metadata_ignore_application 2\n");
		return OggFLAC__stream_decoder_set_metadata_ignore_application(decoder->oggflac, id);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_metadata_ignore_application 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_metadata_ignore_application 3\n");
		return FLAC__stream_decoder_set_metadata_ignore_application(decoder->flac, id);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_metadata_ignore_application 3\n");
	}
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_metadata_ignore_application 1\n");
}

FLAC__bool EasyFLAC__set_metadata_ignore_all(EasyFLAC__StreamDecoder *decoder)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_metadata_ignore_all 1\n");
	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_metadata_ignore_all 2\n");
		return OggFLAC__stream_decoder_set_metadata_ignore_all(decoder->oggflac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_metadata_ignore_all 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__set_metadata_ignore_all 3\n");
		return FLAC__stream_decoder_set_metadata_ignore_all(decoder->flac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_metadata_ignore_all 3\n");
	}
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__set_metadata_ignore_all 1\n");
}


FLAC__StreamDecoderState EasyFLAC__get_state(const EasyFLAC__StreamDecoder *decoder)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__get_state 1\n");
	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__get_state 2\n");
		return OggFLAC__stream_decoder_get_FLAC_stream_decoder_state(decoder->oggflac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__get_state 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__get_state 3\n");
		return FLAC__stream_decoder_get_state(decoder->flac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__get_state 3\n");
	}
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__get_state 1\n");
}


unsigned EasyFLAC__get_channels(const EasyFLAC__StreamDecoder *decoder)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__get_channels 1\n");
	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__get_channels 2\n");
		return OggFLAC__stream_decoder_get_channels(decoder->oggflac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__get_channels 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__get_channels 3\n");
		return FLAC__stream_decoder_get_channels(decoder->flac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__get_channels 3\n");
	}
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__get_channels 1\n");
}


FLAC__ChannelAssignment EasyFLAC__get_channel_assignment(const EasyFLAC__StreamDecoder *decoder)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__get_channel_assignment 1\n");
	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__get_channel_assignment 2\n");
		return OggFLAC__stream_decoder_get_channel_assignment(decoder->oggflac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__get_channel_assignment 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__get_channel_assignment 3\n");
		return FLAC__stream_decoder_get_channel_assignment(decoder->flac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__get_channel_assignment 3\n");
	}
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__get_channel_assignment 1\n");
}


unsigned EasyFLAC__get_bits_per_sample(const EasyFLAC__StreamDecoder *decoder)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__get_bits_per_sample 1\n");
	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__get_bits_per_sample 2\n");
		return OggFLAC__stream_decoder_get_bits_per_sample(decoder->oggflac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__get_bits_per_sample 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__get_bits_per_sample 3\n");
		return FLAC__stream_decoder_get_bits_per_sample(decoder->flac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__get_bits_per_sample 3\n");
	}
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__get_bits_per_sample 1\n");
}


unsigned EasyFLAC__get_sample_rate(const EasyFLAC__StreamDecoder *decoder)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__get_sample_rate 1\n");
	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__get_sample_rate 2\n");
		return OggFLAC__stream_decoder_get_sample_rate(decoder->oggflac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__get_sample_rate 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__get_sample_rate 3\n");
		return FLAC__stream_decoder_get_sample_rate(decoder->flac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__get_sample_rate 3\n");
	}
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__get_sample_rate 1\n");
}


unsigned EasyFLAC__get_blocksize(const EasyFLAC__StreamDecoder *decoder)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__get_blocksize 1\n");
	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__get_blocksize 2\n");
		return OggFLAC__stream_decoder_get_blocksize(decoder->oggflac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__get_blocksize 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__get_blocksize 3\n");
		return FLAC__stream_decoder_get_blocksize(decoder->flac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__get_blocksize 3\n");
	}
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__get_blocksize 1\n");
}


FLAC__StreamDecoderState EasyFLAC__init(EasyFLAC__StreamDecoder *decoder)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__init 1\n");
	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__init 2\n");
		OggFLAC__stream_decoder_init(decoder->oggflac);
		return OggFLAC__stream_decoder_get_FLAC_stream_decoder_state(decoder->oggflac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__init 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__init 3\n");
		return FLAC__stream_decoder_init(decoder->flac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__init 3\n");
	}
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__init 1\n");
}


void EasyFLAC__finish(EasyFLAC__StreamDecoder *decoder)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__finish 1\n");
	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__finish 2\n");
		OggFLAC__stream_decoder_finish(decoder->oggflac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__finish 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__finish 3\n");
		FLAC__stream_decoder_finish(decoder->flac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__finish 3\n");
	}
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__finish 1\n");
}


FLAC__bool EasyFLAC__flush(EasyFLAC__StreamDecoder *decoder)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__flush 1\n");
	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__flush 2\n");
		return OggFLAC__stream_decoder_flush(decoder->oggflac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__flush 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__flush 3\n");
		return FLAC__stream_decoder_flush(decoder->flac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__flush 3\n");
	}
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__flush 1\n");
}


FLAC__bool EasyFLAC__reset(EasyFLAC__StreamDecoder *decoder)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__reset 1\n");
	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__reset 2\n");
		return OggFLAC__stream_decoder_reset(decoder->oggflac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__reset 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__reset 3\n");
		return FLAC__stream_decoder_reset(decoder->flac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__reset 3\n");
	}
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__reset 1\n");
}


FLAC__bool EasyFLAC__process_single(EasyFLAC__StreamDecoder *decoder)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__process_single 1\n");
	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__process_single 2\n");
		return OggFLAC__stream_decoder_process_single(decoder->oggflac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__process_single 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__process_single 3\n");
		return FLAC__stream_decoder_process_single(decoder->flac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__process_single 3\n");
	}
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__process_single 1\n");
}


FLAC__bool EasyFLAC__process_until_end_of_metadata(EasyFLAC__StreamDecoder *decoder)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__process_until_end_of_metadata 1\n");
	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__process_until_end_of_metadata 2\n");
		return OggFLAC__stream_decoder_process_until_end_of_metadata(decoder->oggflac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__process_until_end_of_metadata 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__process_until_end_of_metadata 3\n");
		return FLAC__stream_decoder_process_until_end_of_metadata(decoder->flac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__process_until_end_of_metadata 3\n");
	}
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__process_until_end_of_metadata 1\n");
}


FLAC__bool EasyFLAC__process_until_end_of_stream(EasyFLAC__StreamDecoder *decoder)
{
	fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__process_until_end_of_stream 1\n");
	if (decoder->is_oggflac)
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__process_until_end_of_stream 2\n");
		return OggFLAC__stream_decoder_process_until_end_of_stream(decoder->oggflac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__process_until_end_of_stream 2\n");
	}
	else
	{
		fprintf(stderr, "[ogg123/easyflac.c] enter EasyFLAC__process_until_end_of_stream 3\n");
		return FLAC__stream_decoder_process_until_end_of_stream(decoder->flac);
		fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__process_until_end_of_stream 3\n");
	}
	fprintf(stderr, "[ogg123/easyflac.c] exit EasyFLAC__process_until_end_of_stream 1\n");
}

#endif
// Total cost: 0.169952
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 383)]
// Total instrumented cost: 0.169952, input tokens: 6859, output tokens: 9225, cache read tokens: 2280, cache write tokens: 4575

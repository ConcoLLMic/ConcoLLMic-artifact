/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE OggVorbis SOFTWARE CODEC SOURCE CODE.   *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS BEFORE DISTRIBUTING.                     *
 *                                                                  *
 * THE Ogg123 SOURCE CODE IS (C) COPYRIGHT 2000-2001                *
 * by Stan Seibert <volsung@xiph.org> AND OTHER CONTRIBUTORS        *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

 last mod: $Id$

 ********************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <limits.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include "playlist.h"
#include "i18n.h"

/* Work with *BSD differences */
#if !defined(NAME_MAX) && defined(MAXNAMLEN) 
#define NAME_MAX MAXNAMLEN
#endif

playlist_element_t *playlist_element_create(char *filename)
{
  fprintf(stderr, "[ogg123/playlist.c] enter playlist_element_create 1\n");
  playlist_element_t *element = (playlist_element_t *) 
                                   malloc(sizeof(playlist_t));

  if (element == NULL) {
      fprintf(stderr, "[ogg123/playlist.c] enter playlist_element_create 2\n");
      fprintf(stderr,
	      _("ERROR: Out of memory in create_playlist_member().\n"));
      exit(1);
      fprintf(stderr, "[ogg123/playlist.c] exit playlist_element_create 2\n");
  }

  if (filename == NULL) {
    fprintf(stderr, "[ogg123/playlist.c] enter playlist_element_create 3\n");
    element->filename = NULL;
    fprintf(stderr, "[ogg123/playlist.c] exit playlist_element_create 3\n");
  }
  else {
    fprintf(stderr, "[ogg123/playlist.c] enter playlist_element_create 4\n");
    element->filename = strdup(filename);

    if (element->filename == NULL) {
        fprintf(stderr, "[ogg123/playlist.c] enter playlist_element_create 5\n");
	fprintf(stderr,
		_("ERROR: Out of memory in create_playlist_member().\n"));
	exit(1);
        fprintf(stderr, "[ogg123/playlist.c] exit playlist_element_create 5\n");
    }
    fprintf(stderr, "[ogg123/playlist.c] exit playlist_element_create 4\n");
  }

  element->next = NULL;

  return element;
  fprintf(stderr, "[ogg123/playlist.c] exit playlist_element_create 1\n");
}


/* Only destroys the current node.  Does not affect linked nodes. */
void playlist_element_destroy(playlist_element_t *element)
{
  fprintf(stderr, "[ogg123/playlist.c] enter playlist_element_destroy 1\n");
  free(element->filename);
  free(element);
  fprintf(stderr, "[ogg123/playlist.c] exit playlist_element_destroy 1\n");
}



playlist_t *playlist_create()
{
  fprintf(stderr, "[ogg123/playlist.c] enter playlist_create 1\n");
  playlist_t *list = (playlist_t *) malloc(sizeof(playlist_t));

  if (list != NULL) {
    fprintf(stderr, "[ogg123/playlist.c] enter playlist_create 2\n");
    list->head = playlist_element_create(NULL);
    list->last = list->head;
    fprintf(stderr, "[ogg123/playlist.c] exit playlist_create 2\n");
  }

  return list;
  fprintf(stderr, "[ogg123/playlist.c] exit playlist_create 1\n");
}


void playlist_destroy(playlist_t *list) {
  fprintf(stderr, "[ogg123/playlist.c] enter playlist_destroy 1\n");
  playlist_element_t *next_element;

  while (list->head != NULL) {
    fprintf(stderr, "[ogg123/playlist.c] enter playlist_destroy 2\n");
    next_element = list->head->next;

    playlist_element_destroy(list->head);

    list->head = next_element;
    fprintf(stderr, "[ogg123/playlist.c] exit playlist_destroy 2\n");
  }

  free(list);
  fprintf(stderr, "[ogg123/playlist.c] exit playlist_destroy 1\n");
}


/* All of the playlist_append_* functions return 
   1 if append was successful
   0 if failure (either directory could not be accessed or playlist on disk
   could not be opened)
*/


/* Add this filename to the playlist.  Filename will be strdup()'ed.  Note
   that this function will never fail. */
int playlist_append_file(playlist_t *list, char *filename)
{
  fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_file 1\n");
  list->last->next = playlist_element_create(filename);
  list->last = list->last->next;

  return 1; /* No way to fail */
  fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_file 1\n");
}

/* Recursively adds files from the directory and subdirectories */
#if defined(HAVE_ALPHASORT) && defined(HAVE_SCANDIR)
int playlist_append_directory(playlist_t *list, char *dirname)
{
  fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_directory 1\n");
  int dir_len = strlen(dirname);
  int num_entries = 0, i = 0;
  struct dirent **entries;
  struct stat stat_buf;
  char nextfile[NAME_MAX + 1];

  num_entries = scandir(dirname, &entries, 0, alphasort);

  if (num_entries < 0) {
    fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_directory 2\n");
    return 0;
    fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_directory 2\n");
  }

  for (i=0; i<num_entries; i++) {
    fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_directory 3\n");
    int sub_len = strlen(entries[i]->d_name);

    /* Make sure full pathname is within limits and we don't parse the
       relative directory entries. */
    if (dir_len + sub_len + 1 < NAME_MAX 
        && strcmp(entries[i]->d_name, ".") != 0  
        && strcmp(entries[i]->d_name, "..") != 0  ) {
      fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_directory 4\n");

      /* Build the new full pathname */
      strcpy(nextfile, dirname);
      strcat(nextfile, "/");
      strcat(nextfile, entries[i]->d_name);

      if (stat(nextfile, &stat_buf) == 0) {
        fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_directory 5\n");
        
        /* Decide what type of entry this is */
        if (S_ISDIR(stat_buf.st_mode)) {
          fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_directory 6\n");
          
        /* Recursively follow directories */
          if ( playlist_append_directory(list, nextfile) == 0 ) {
            fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_directory 7\n");
            fprintf(stderr,
                  _("Warning: Could not read directory %s.\n"), 
                    nextfile);
            fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_directory 7\n");
          }
          fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_directory 6\n");
        } else {
        /* Assume everything else is a file of some sort */
          fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_directory 8\n");
          playlist_append_file(list, nextfile);
          fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_directory 8\n");
        }
        fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_directory 5\n");
      }
      fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_directory 4\n");
    }

    free(entries[i]);
    fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_directory 3\n");
  }

  free(entries);

  return 1;
  fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_directory 1\n");
}
#else
int playlist_append_directory(playlist_t *list, char *dirname)
{
  fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_directory 2395\n");
  DIR *dir;
  int dir_len = strlen(dirname);
  struct dirent *entry;
  struct stat stat_buf;
  char nextfile[NAME_MAX + 1];

  dir = opendir(dirname);

  if (dir == NULL) {
    fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_directory 2334\n");
    return 0;
    fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_directory 2334\n");
  }

  entry = readdir(dir);
  while (entry != NULL) {
    fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_directory 4813\n");
    int sub_len = strlen(entry->d_name);

    /* Make sure full pathname is within limits and we don't parse the
       relative directory entries. */
    if (dir_len + sub_len + 1 < NAME_MAX 
	&& strcmp(entry->d_name, ".") != 0  
	&& strcmp(entry->d_name, "..") != 0  ) {
      fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_directory 1070\n");

      /* Build the new full pathname */
      strcpy(nextfile, dirname);
      strcat(nextfile, "/");
      strcat(nextfile, entry->d_name);

      if (stat(nextfile, &stat_buf) == 0) {
        fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_directory 1923\n");
	
	/* Decide what type of entry this is */
	if (S_ISDIR(stat_buf.st_mode)) {
          fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_directory 4737\n");
	  
	/* Recursively follow directories */
	  if ( playlist_append_directory(list, nextfile) == 0 ) {
            fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_directory 2246\n");
	    fprintf(stderr,
		  _("Warning: Could not read directory %s.\n"), 
		    nextfile);
            fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_directory 2246\n");
	  }
          fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_directory 4737\n");
	} else {
	/* Assume everything else is a file of some sort */
          fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_directory 3015\n");
	  playlist_append_file(list, nextfile);
          fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_directory 3015\n");
	}
        fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_directory 1923\n");
      }
      fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_directory 1070\n");
    }

    entry = readdir(dir);
    fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_directory 4813\n");
  }

  closedir(dir);

  return 1;
  fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_directory 2395\n");
}
#endif


/* Opens a file containing filenames, one per line, and adds them to the
   playlist */
int playlist_append_from_file(playlist_t *list, char *playlist_filename)
{
  fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_from_file 1\n");
  FILE *fp;
  char filename[NAME_MAX+1];
  struct stat stat_buf;
  int length;
  int i;

  if (strcmp(playlist_filename, "-") == 0) {
    fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_from_file 2\n");
    fp = stdin;
    fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_from_file 2\n");
  }
  else {
    fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_from_file 3\n");
    fp = fopen(playlist_filename, "r");
    fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_from_file 3\n");
  }

  if (fp == NULL) {
    fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_from_file 4\n");
    return 0;
    fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_from_file 4\n");
  }

  while (!feof(fp)) {
    fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_from_file 5\n");

    if ( fgets(filename, NAME_MAX+1 /* no, really! */, fp) == NULL ) {
      fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_from_file 6\n");
      continue;
      fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_from_file 6\n");
    }

    filename[NAME_MAX] = '\0'; /* Just to make sure */
    length = strlen(filename);

    /* Skip blank lines */
    for (i = 0; i < length && isspace(filename[i]); i++);
    if (i == length) {
      fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_from_file 7\n");
      continue;
      fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_from_file 7\n");
    }

    /* Crop off trailing newlines if present. Handle DOS (\r\n), Unix (\n)
     * and MacOS<9 (\r) line endings. */
    if (filename[length - 2] == '\r' && filename[length - 1] == '\n') {
      fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_from_file 8\n");
      filename[length - 2] = '\0';
      fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_from_file 8\n");
    }
    else if (filename[length - 1] == '\n' || filename[length - 1] == '\r') {
      fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_from_file 9\n");
      filename[length - 1] = '\0';
      fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_from_file 9\n");
    }

    if (stat(filename, &stat_buf) == 0) {
      fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_from_file 10\n");

      if (S_ISDIR(stat_buf.st_mode)) {
        fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_from_file 11\n");
	if (playlist_append_directory(list, filename) == 0) {
          fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_from_file 12\n");
	  fprintf(stderr, 
		  _("Warning from playlist %s: "
		    "Could not read directory %s.\n"), playlist_filename,
		  filename);
          fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_from_file 12\n");
        }
        fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_from_file 11\n");
      } else {
        fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_from_file 13\n");
	playlist_append_file(list, filename);
        fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_from_file 13\n");
      }
      fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_from_file 10\n");
    } else { /* If we can't stat it, it might be a non-disk source */
      fprintf(stderr, "[ogg123/playlist.c] enter playlist_append_from_file 14\n");
      playlist_append_file(list, filename);
      fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_from_file 14\n");
    }
    fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_from_file 5\n");
  }

  return 1;
  fprintf(stderr, "[ogg123/playlist.c] exit playlist_append_from_file 1\n");
}


/* Return the number of items in the playlist */
int playlist_length(playlist_t *list)
{
  fprintf(stderr, "[ogg123/playlist.c] enter playlist_length 1\n");
  int length;
  playlist_element_t *element;

  element = list->head;
  length = 0; /* don't count head node */
  while (element->next != NULL) {
    fprintf(stderr, "[ogg123/playlist.c] enter playlist_length 2\n");
    length++;
    element = element->next;
    fprintf(stderr, "[ogg123/playlist.c] exit playlist_length 2\n");
  }

  return length;
  fprintf(stderr, "[ogg123/playlist.c] exit playlist_length 1\n");
}


/* Convert the playlist to an array of strings.  Strings are deep copied. 
   Size will be set to the number of elements in the array. */
char **playlist_to_array(playlist_t *list, int *size)
{
  fprintf(stderr, "[ogg123/playlist.c] enter playlist_to_array 1\n");
  char **array;
  int i;
  playlist_element_t *element;

  *size = playlist_length(list);
  array = calloc(*size, sizeof(char *));

  if (array == NULL) {
    fprintf(stderr, "[ogg123/playlist.c] enter playlist_to_array 2\n");
    fprintf(stderr,
	    _("ERROR: Out of memory in playlist_to_array().\n"));
    exit(1);
    fprintf(stderr, "[ogg123/playlist.c] exit playlist_to_array 2\n");
  }

  for (i = 0, element = list->head->next; 
       i < *size; 
       i++, element = element->next) {
    fprintf(stderr, "[ogg123/playlist.c] enter playlist_to_array 3\n");

    array[i] = strdup(element->filename);

    if (array[i] == NULL) {
      fprintf(stderr, "[ogg123/playlist.c] enter playlist_to_array 4\n");
      fprintf(stderr,
	      _("ERROR: Out of memory in playlist_to_array().\n"));
      exit(1);
      fprintf(stderr, "[ogg123/playlist.c] exit playlist_to_array 4\n");
    }
    fprintf(stderr, "[ogg123/playlist.c] exit playlist_to_array 3\n");
  }


  return array;
  fprintf(stderr, "[ogg123/playlist.c] exit playlist_to_array 1\n");
}


/* Deallocate array and all contained strings created by playlist_to_array. */
void playlist_array_destroy(char **array, int size)
{
  fprintf(stderr, "[ogg123/playlist.c] enter playlist_array_destroy 1\n");
  int i;

  for (i = 0; i < size; i++) {
    fprintf(stderr, "[ogg123/playlist.c] enter playlist_array_destroy 2\n");
    free(array[i]);
    fprintf(stderr, "[ogg123/playlist.c] exit playlist_array_destroy 2\n");
  }

  free(array);
  fprintf(stderr, "[ogg123/playlist.c] exit playlist_array_destroy 1\n");
}
// Total cost: 0.089747
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 354)]
// Total instrumented cost: 0.089747, input tokens: 5139, output tokens: 4652, cache read tokens: 2280, cache write tokens: 2855

/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE OggVorbis SOFTWARE CODEC SOURCE CODE.   *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS BEFORE DISTRIBUTING.                     *
 *                                                                  *
 * THE Ogg123 SOURCE CODE IS (C) COPYRIGHT 2000-2001                *
 * by Stan Seibert <volsung@xiph.org> AND OTHER CONTRIBUTORS        *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

 last mod: $Id$

 ********************************************************************/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#ifdef HAVE_UNISTD_H
#include <sys/ioctl.h>
#include <unistd.h>
#endif

#ifdef HAVE_FCNTL_H
#include <fcntl.h>
#endif

#include "status.h"
#include "i18n.h"

char temp_buffer[200];
int last_line_len = 0;
int max_verbosity = 0;
int exit_status = EXIT_SUCCESS;

pthread_mutex_t output_lock = PTHREAD_MUTEX_INITIALIZER;


/* ------------------- Private functions ------------------ */

void unlock_output_lock (void *arg)
{
  fprintf(stderr, "[ogg123/status.c] enter unlock_output_lock 1\n");
  pthread_mutex_unlock(&output_lock);
  fprintf(stderr, "[ogg123/status.c] exit unlock_output_lock 1\n");
}


void write_buffer_state_string (char *dest, buffer_stats_t *buf_stats)
{
  fprintf(stderr, "[ogg123/status.c] enter write_buffer_state_string 1\n");
  char *cur = dest;
  char *comma = ", ";
  char *sep = "(";
  fprintf(stderr, "[ogg123/status.c] exit write_buffer_state_string 1\n");

  if (buf_stats->prebuffering) {
    fprintf(stderr, "[ogg123/status.c] enter write_buffer_state_string 2\n");
    cur += sprintf (cur, _("%sPrebuf to %.1f%%"), sep, 
		    100.0f * buf_stats->prebuffer_fill);
    sep = comma;
    fprintf(stderr, "[ogg123/status.c] exit write_buffer_state_string 2\n");
  }
  if (buf_stats->paused) {
    fprintf(stderr, "[ogg123/status.c] enter write_buffer_state_string 3\n");
    cur += sprintf (cur, _("%sPaused"), sep);
    sep = comma;
    fprintf(stderr, "[ogg123/status.c] exit write_buffer_state_string 3\n");
  }
  if (buf_stats->eos) {
    fprintf(stderr, "[ogg123/status.c] enter write_buffer_state_string 4\n");
    cur += sprintf (cur, _("%sEOS"), sep);
    sep = comma;
    fprintf(stderr, "[ogg123/status.c] exit write_buffer_state_string 4\n");
  }
  if (cur != dest) {
    fprintf(stderr, "[ogg123/status.c] enter write_buffer_state_string 5\n");
    cur += sprintf (cur, ")");
    fprintf(stderr, "[ogg123/status.c] exit write_buffer_state_string 5\n");
  }
  else {
    fprintf(stderr, "[ogg123/status.c] enter write_buffer_state_string 6\n");
    *cur = '\0';
    fprintf(stderr, "[ogg123/status.c] exit write_buffer_state_string 6\n");
  }
}


/* Write a min:sec.msec style string to dest corresponding to time.
   The time parameter is in seconds.  Returns the number of characters
   written */
int write_time_string (char *dest, double time)
{
  fprintf(stderr, "[ogg123/status.c] enter write_time_string 1\n");
  long min = (long) time / (long) 60;
  double sec = time - 60.0f * min;

  int result = sprintf (dest, "%02li:%05.2f", min, sec);
  fprintf(stderr, "[ogg123/status.c] exit write_time_string 1\n");
  return result;
}


void clear_line (int len)
{
  fprintf(stderr, "[ogg123/status.c] enter clear_line 1\n");
  fputc('\r', stderr);
  fprintf(stderr, "[ogg123/status.c] exit clear_line 1\n");

  while (len > 0) {
    fprintf(stderr, "[ogg123/status.c] enter clear_line 2\n");
    fputc (' ', stderr);
    len--;
    fprintf(stderr, "[ogg123/status.c] exit clear_line 2\n");
  }

  fprintf(stderr, "[ogg123/status.c] enter clear_line 3\n");
  fputc ('\r', stderr);
  fprintf(stderr, "[ogg123/status.c] exit clear_line 3\n");
}


int sprintf_clear_line(int len, char *buf)
{
  fprintf(stderr, "[ogg123/status.c] enter sprintf_clear_line 1\n");
  int i = 0;

  buf[i] = '\r';
  i++;
  fprintf(stderr, "[ogg123/status.c] exit sprintf_clear_line 1\n");

  while (len > 0) {
    fprintf(stderr, "[ogg123/status.c] enter sprintf_clear_line 2\n");
    buf[i] = ' ';
    len--;
    i++;
    fprintf(stderr, "[ogg123/status.c] exit sprintf_clear_line 2\n");
  }

  fprintf(stderr, "[ogg123/status.c] enter sprintf_clear_line 3\n");
  buf[i] = '\r';
  i++;

  /* Null terminate just in case */
  buf[i] = '\0';

  int result = i;
  fprintf(stderr, "[ogg123/status.c] exit sprintf_clear_line 3\n");
  return result;
}

int print_statistics_line (stat_format_t stats[])
{
  fprintf(stderr, "[ogg123/status.c] enter print_statistics_line 1\n");
  int len = 0;
  char *str = temp_buffer;
  fprintf(stderr, "[ogg123/status.c] exit print_statistics_line 1\n");

  if (max_verbosity == 0) {
    fprintf(stderr, "[ogg123/status.c] enter print_statistics_line 2\n");
    return 0;
    fprintf(stderr, "[ogg123/status.c] exit print_statistics_line 2\n");
  }

  fprintf(stderr, "[ogg123/status.c] enter print_statistics_line 3\n");
  /* Put the clear line text into the same string buffer so that the
     line is cleared and redrawn all at once.  This reduces
     flickering.  Don't count characters used to clear line in len */
  str += sprintf_clear_line(last_line_len, str); 
  fprintf(stderr, "[ogg123/status.c] exit print_statistics_line 3\n");

  while (stats->formatstr != NULL) {
    fprintf(stderr, "[ogg123/status.c] enter print_statistics_line 4\n");
    
    if (stats->verbosity > max_verbosity || !stats->enabled) {
      fprintf(stderr, "[ogg123/status.c] enter print_statistics_line 5\n");
      stats++;
      fprintf(stderr, "[ogg123/status.c] exit print_statistics_line 5\n");
      continue;
    }

    if (len != 0) {
      fprintf(stderr, "[ogg123/status.c] enter print_statistics_line 6\n");
      len += sprintf(str+len, " ");
      fprintf(stderr, "[ogg123/status.c] exit print_statistics_line 6\n");
    }

    switch (stats->type) {
    case stat_noarg:
      fprintf(stderr, "[ogg123/status.c] enter print_statistics_line 7\n");
      len += sprintf(str+len, "%s", stats->formatstr);
      fprintf(stderr, "[ogg123/status.c] exit print_statistics_line 7\n");
      break;
    case stat_intarg:
      fprintf(stderr, "[ogg123/status.c] enter print_statistics_line 8\n");
      len += sprintf(str+len, stats->formatstr, stats->arg.intarg);
      fprintf(stderr, "[ogg123/status.c] exit print_statistics_line 8\n");
      break;
    case stat_stringarg:
      fprintf(stderr, "[ogg123/status.c] enter print_statistics_line 9\n");
      len += sprintf(str+len, stats->formatstr, stats->arg.stringarg);
      fprintf(stderr, "[ogg123/status.c] exit print_statistics_line 9\n");
      break;
    case stat_floatarg:
      fprintf(stderr, "[ogg123/status.c] enter print_statistics_line 10\n");
      len += sprintf(str+len, stats->formatstr, stats->arg.floatarg);
      fprintf(stderr, "[ogg123/status.c] exit print_statistics_line 10\n");
      break;
    case stat_doublearg:
      fprintf(stderr, "[ogg123/status.c] enter print_statistics_line 11\n");
      len += sprintf(str+len, stats->formatstr, stats->arg.doublearg);
      fprintf(stderr, "[ogg123/status.c] exit print_statistics_line 11\n");
      break;
    }

    fprintf(stderr, "[ogg123/status.c] enter print_statistics_line 12\n");
    stats++;
    fprintf(stderr, "[ogg123/status.c] exit print_statistics_line 12\n");
    fprintf(stderr, "[ogg123/status.c] exit print_statistics_line 4\n");
  }
  
#ifdef HAVE_UNISTD_H
  /* If the line would break in the console, truncate it to avoid the break,
     and indicate the truncation by adding points of ellipsis */
  fprintf(stderr, "[ogg123/status.c] enter print_statistics_line 13\n");
  struct winsize max;
  int ioctlError = ioctl(STDERR_FILENO, TIOCGWINSZ, &max);
  fprintf(stderr, "[ogg123/status.c] exit print_statistics_line 13\n");
  if (!ioctlError) {
    fprintf(stderr, "[ogg123/status.c] enter print_statistics_line 14\n");
    const int limit = max.ws_col - 1;
    fprintf(stderr, "[ogg123/status.c] exit print_statistics_line 14\n");
    if (len > limit) {
      fprintf(stderr, "[ogg123/status.c] enter print_statistics_line 15\n");
      int pointsStart = limit - 3;
      if (pointsStart < 0) {
        fprintf(stderr, "[ogg123/status.c] enter print_statistics_line 16\n");
        pointsStart = 0;
        fprintf(stderr, "[ogg123/status.c] exit print_statistics_line 16\n");
      }
      int position;
      for (position = pointsStart; position < limit; position++) {
        fprintf(stderr, "[ogg123/status.c] enter print_statistics_line 17\n");
        str[position] = '.';
        fprintf(stderr, "[ogg123/status.c] exit print_statistics_line 17\n");
      }
      fprintf(stderr, "[ogg123/status.c] enter print_statistics_line 18\n");
      str[position] = 0;
      len = position;
      fprintf(stderr, "[ogg123/status.c] exit print_statistics_line 18\n");
      fprintf(stderr, "[ogg123/status.c] exit print_statistics_line 15\n");
    }
  }
#endif

  fprintf(stderr, "[ogg123/status.c] enter print_statistics_line 19\n");
  len += sprintf(str+len, "\r");

  fprintf(stderr, "%s", temp_buffer);

  int result = len;
  fprintf(stderr, "[ogg123/status.c] exit print_statistics_line 19\n");
  return result;
}


void vstatus_print_nolock (const char *fmt, va_list ap)
{
  fprintf(stderr, "[ogg123/status.c] enter vstatus_print_nolock 1\n");
  if (last_line_len != 0) {
    fprintf(stderr, "[ogg123/status.c] enter vstatus_print_nolock 2\n");
    fputc ('\n', stderr);
    fprintf(stderr, "[ogg123/status.c] exit vstatus_print_nolock 2\n");
  }

  fprintf(stderr, "[ogg123/status.c] enter vstatus_print_nolock 3\n");
  vfprintf (stderr, fmt, ap);

  fputc ('\n', stderr);

  last_line_len = 0;
  fprintf(stderr, "[ogg123/status.c] exit vstatus_print_nolock 3\n");
  fprintf(stderr, "[ogg123/status.c] exit vstatus_print_nolock 1\n");
}


/* ------------------- Public interface -------------------- */

#define TIME_STR_SIZE 20
#define STATE_STR_SIZE 25
#define NUM_STATS 10

stat_format_t *stat_format_create ()
{
  fprintf(stderr, "[ogg123/status.c] enter stat_format_create 1\n");
  stat_format_t *stats;
  stat_format_t *cur;

  stats = calloc(NUM_STATS + 1, sizeof(stat_format_t));  /* One extra for end flag */
  fprintf(stderr, "[ogg123/status.c] exit stat_format_create 1\n");
  if (stats == NULL) {
    fprintf(stderr, "[ogg123/status.c] enter stat_format_create 2\n");
    fprintf(stderr, _("Memory allocation error in stats_init()\n"));
    exit(1);
    fprintf(stderr, "[ogg123/status.c] exit stat_format_create 2\n");
  }

  fprintf(stderr, "[ogg123/status.c] enter stat_format_create 3\n");
  cur = stats + 0; /* currently playing file / stream */
  cur->verbosity = 3; 
  cur->enabled = 0;
  cur->formatstr = _("File: %s"); 
  cur->type = stat_stringarg;
  fprintf(stderr, "[ogg123/status.c] exit stat_format_create 3\n");
  
  fprintf(stderr, "[ogg123/status.c] enter stat_format_create 4\n");
  cur = stats + 1; /* current playback time (preformatted) */
  cur->verbosity = 1;
  cur->enabled = 1;
  cur->formatstr = _("Time: %s"); 
  cur->type = stat_stringarg;
  cur->arg.stringarg = calloc(TIME_STR_SIZE, sizeof(char));
  fprintf(stderr, "[ogg123/status.c] exit stat_format_create 4\n");

  if (cur->arg.stringarg == NULL) {
    fprintf(stderr, "[ogg123/status.c] enter stat_format_create 5\n");
    fprintf(stderr, _("Memory allocation error in stats_init()\n"));
    exit(1);
    fprintf(stderr, "[ogg123/status.c] exit stat_format_create 5\n");
  }  
  fprintf(stderr, "[ogg123/status.c] enter stat_format_create 6\n");
  write_time_string(cur->arg.stringarg, 0.0);
  fprintf(stderr, "[ogg123/status.c] exit stat_format_create 6\n");


  fprintf(stderr, "[ogg123/status.c] enter stat_format_create 7\n");
  cur = stats + 2; /* remaining playback time (preformatted) */
  cur->verbosity = 1;
  cur->enabled = 1;
  cur->formatstr = "[%s]";
  cur->type = stat_stringarg;
  cur->arg.stringarg = calloc(TIME_STR_SIZE, sizeof(char));
  fprintf(stderr, "[ogg123/status.c] exit stat_format_create 7\n");

  if (cur->arg.stringarg == NULL) {
    fprintf(stderr, "[ogg123/status.c] enter stat_format_create 8\n");
    fprintf(stderr, _("Memory allocation error in stats_init()\n"));
    exit(1);
    fprintf(stderr, "[ogg123/status.c] exit stat_format_create 8\n");
  }
  fprintf(stderr, "[ogg123/status.c] enter stat_format_create 9\n");
  write_time_string(cur->arg.stringarg, 0.0);
  fprintf(stderr, "[ogg123/status.c] exit stat_format_create 9\n");


  fprintf(stderr, "[ogg123/status.c] enter stat_format_create 10\n");
  cur = stats + 3; /* total playback time (preformatted) */
  cur->verbosity = 1;
  cur->enabled = 1;
  cur->formatstr = _("of %s");
  cur->type = stat_stringarg;
  cur->arg.stringarg = calloc(TIME_STR_SIZE, sizeof(char));
  fprintf(stderr, "[ogg123/status.c] exit stat_format_create 10\n");

  if (cur->arg.stringarg == NULL) {
    fprintf(stderr, "[ogg123/status.c] enter stat_format_create 11\n");
    fprintf(stderr, _("Memory allocation error in stats_init()\n"));
    exit(1);
    fprintf(stderr, "[ogg123/status.c] exit stat_format_create 11\n");
  }
  fprintf(stderr, "[ogg123/status.c] enter stat_format_create 12\n");
  write_time_string(cur->arg.stringarg, 0.0);
  fprintf(stderr, "[ogg123/status.c] exit stat_format_create 12\n");


  fprintf(stderr, "[ogg123/status.c] enter stat_format_create 13\n");
  cur = stats + 4; /* instantaneous bitrate */
  cur->verbosity = 2;
  cur->enabled = 1;
  cur->formatstr = " (%5.1f kbps)";
  cur->type = stat_doublearg;
  fprintf(stderr, "[ogg123/status.c] exit stat_format_create 13\n");

  fprintf(stderr, "[ogg123/status.c] enter stat_format_create 14\n");
  cur = stats + 5; /* average bitrate (not yet implemented) */
  cur->verbosity = 2;
  cur->enabled = 0;
  cur->formatstr = _("Avg bitrate: %5.1f");
  cur->type = stat_doublearg;
  fprintf(stderr, "[ogg123/status.c] exit stat_format_create 14\n");

  fprintf(stderr, "[ogg123/status.c] enter stat_format_create 15\n");
  cur = stats + 6; /* input buffer fill % */
  cur->verbosity = 2;
  cur->enabled = 0;
  cur->formatstr = _(" Input Buffer %5.1f%%");
  cur->type = stat_doublearg;
  fprintf(stderr, "[ogg123/status.c] exit stat_format_create 15\n");

  fprintf(stderr, "[ogg123/status.c] enter stat_format_create 16\n");
  cur = stats + 7; /* input buffer status */
  cur->verbosity = 2;
  cur->enabled = 0;
  cur->formatstr = "%s";
  cur->type = stat_stringarg;
  cur->arg.stringarg = calloc(STATE_STR_SIZE, sizeof(char));
  fprintf(stderr, "[ogg123/status.c] exit stat_format_create 16\n");

  if (cur->arg.stringarg == NULL) {
    fprintf(stderr, "[ogg123/status.c] enter stat_format_create 17\n");
    fprintf(stderr, _("Memory allocation error in stats_init()\n"));
    exit(1);
    fprintf(stderr, "[ogg123/status.c] exit stat_format_create 17\n");
  }


  fprintf(stderr, "[ogg123/status.c] enter stat_format_create 18\n");
  cur = stats + 8; /* output buffer fill % */
  cur->verbosity = 2;
  cur->enabled = 0;
  cur->formatstr = _(" Output Buffer %5.1f%%"); 
  cur->type = stat_doublearg;
  fprintf(stderr, "[ogg123/status.c] exit stat_format_create 18\n");

  fprintf(stderr, "[ogg123/status.c] enter stat_format_create 19\n");
  cur = stats + 9; /* output buffer status */
  cur->verbosity = 1;
  cur->enabled = 0;
  cur->formatstr = "%s";
  cur->type = stat_stringarg;
  cur->arg.stringarg = calloc(STATE_STR_SIZE, sizeof(char));
  fprintf(stderr, "[ogg123/status.c] exit stat_format_create 19\n");

  if (cur->arg.stringarg == NULL) {
    fprintf(stderr, "[ogg123/status.c] enter stat_format_create 20\n");
    fprintf(stderr, _("Memory allocation error in stats_init()\n"));
    exit(1);
    fprintf(stderr, "[ogg123/status.c] exit stat_format_create 20\n");
  }


  fprintf(stderr, "[ogg123/status.c] enter stat_format_create 21\n");
  cur = stats + 10; /* End flag */
  cur->formatstr = NULL;

  stat_format_t *result = stats;
  fprintf(stderr, "[ogg123/status.c] exit stat_format_create 21\n");
  return result;
}


void stat_format_cleanup (stat_format_t *stats)
{
  fprintf(stderr, "[ogg123/status.c] enter stat_format_cleanup 1\n");
  free(stats[1].arg.stringarg);
  free(stats[2].arg.stringarg);
  free(stats[3].arg.stringarg);
  free(stats[7].arg.stringarg);
  free(stats[9].arg.stringarg);
  free(stats);
  fprintf(stderr, "[ogg123/status.c] exit stat_format_cleanup 1\n");
}


void status_init (int verbosity)
{
  fprintf(stderr, "[ogg123/status.c] enter status_init 1\n");
#if defined(HAVE_FCNTL) && defined(HAVE_UNISTD_H)
  fcntl (STDERR_FILENO, F_SETFL, fcntl(STDERR_FILENO, F_GETFL) | O_NONBLOCK);
#endif

  max_verbosity = verbosity;
  fprintf(stderr, "[ogg123/status.c] exit status_init 1\n");
}

void status_deinit ()
{
  fprintf(stderr, "[ogg123/status.c] enter status_deinit 1\n");
#if defined(HAVE_FCNTL) && defined(HAVE_UNISTD_H)
  fcntl (STDERR_FILENO, F_SETFL, fcntl(STDERR_FILENO, F_GETFL) & ~O_NONBLOCK);
#endif
  fprintf(stderr, "[ogg123/status.c] exit status_deinit 1\n");
}

void status_reset_output_lock ()
{
  fprintf(stderr, "[ogg123/status.c] enter status_reset_output_lock 1\n");
  pthread_mutex_unlock(&output_lock);
  fprintf(stderr, "[ogg123/status.c] exit status_reset_output_lock 1\n");
}


void status_clear_line ()
{
  fprintf(stderr, "[ogg123/status.c] enter status_clear_line 1\n");
  pthread_cleanup_push(unlock_output_lock, NULL);

  pthread_mutex_lock(&output_lock);
  clear_line(last_line_len);
  pthread_mutex_unlock(&output_lock);

  pthread_cleanup_pop(0);
  fprintf(stderr, "[ogg123/status.c] exit status_clear_line 1\n");
}

void status_print_statistics (stat_format_t *stats,
			      buffer_stats_t *audio_statistics,
			      data_source_stats_t *transport_statistics,
			      decoder_stats_t *decoder_statistics)
{
  fprintf(stderr, "[ogg123/status.c] enter status_print_statistics 1\n");
  pthread_cleanup_push(unlock_output_lock, NULL);

  /* Updating statistics is not critical.  If another thread is
     already doing output, we skip it. */
  if (pthread_mutex_trylock(&output_lock) == 0) {
    fprintf(stderr, "[ogg123/status.c] enter status_print_statistics 2\n");

    if (decoder_statistics != NULL) {
      fprintf(stderr, "[ogg123/status.c] enter status_print_statistics 3\n");
      /* Current playback time */
      write_time_string(stats[1].arg.stringarg,
			decoder_statistics->current_time);
	
      /* Remaining playback time */
      write_time_string(stats[2].arg.stringarg,
			decoder_statistics->total_time - 
			decoder_statistics->current_time);

      /* Total playback time */
      write_time_string(stats[3].arg.stringarg,
			decoder_statistics->total_time);

      /* Instantaneous bitrate */
      stats[4].arg.doublearg = decoder_statistics->instant_bitrate / 1000.0f;

      /* Instantaneous bitrate */
      stats[5].arg.doublearg = decoder_statistics->avg_bitrate / 1000.0f;
      fprintf(stderr, "[ogg123/status.c] exit status_print_statistics 3\n");
    }


    if (transport_statistics != NULL && 
	transport_statistics->input_buffer_used) {
      fprintf(stderr, "[ogg123/status.c] enter status_print_statistics 4\n");

      /* Input buffer fill % */
      stats[6].arg.doublearg = transport_statistics->input_buffer.fill;

      /* Input buffer state */
      write_buffer_state_string(stats[7].arg.stringarg,
				&transport_statistics->input_buffer);
      fprintf(stderr, "[ogg123/status.c] exit status_print_statistics 4\n");
    }


    if (audio_statistics != NULL) {
      fprintf(stderr, "[ogg123/status.c] enter status_print_statistics 5\n");

      /* Output buffer fill % */
      stats[8].arg.doublearg = audio_statistics->fill;

      /* Output buffer state */
      write_buffer_state_string(stats[9].arg.stringarg, audio_statistics);
      fprintf(stderr, "[ogg123/status.c] exit status_print_statistics 5\n");
    }

    fprintf(stderr, "[ogg123/status.c] enter status_print_statistics 6\n");
    last_line_len = print_statistics_line(stats);

    pthread_mutex_unlock(&output_lock);
    fprintf(stderr, "[ogg123/status.c] exit status_print_statistics 6\n");
    fprintf(stderr, "[ogg123/status.c] exit status_print_statistics 2\n");
  }

  fprintf(stderr, "[ogg123/status.c] exit status_print_statistics 1\n");
  pthread_cleanup_pop(0);
}


void status_message (int verbosity, const char *fmt, ...)
{
  fprintf(stderr, "[ogg123/status.c] enter status_message 1\n");
  va_list ap;

  if (verbosity > max_verbosity) {
    fprintf(stderr, "[ogg123/status.c] enter status_message 2\n");
    return;
    fprintf(stderr, "[ogg123/status.c] exit status_message 2\n");
  }

  fprintf(stderr, "[ogg123/status.c] enter status_message 3\n");
  pthread_cleanup_push(unlock_output_lock, NULL);

  pthread_mutex_lock(&output_lock);

  clear_line(last_line_len);

  va_start (ap, fmt);
  vstatus_print_nolock(fmt, ap);
  va_end (ap);

  pthread_mutex_unlock(&output_lock);

  pthread_cleanup_pop(0);
  fprintf(stderr, "[ogg123/status.c] exit status_message 3\n");
  fprintf(stderr, "[ogg123/status.c] exit status_message 1\n");
}


void vstatus_message (int verbosity, const char *fmt, va_list ap)
{
  fprintf(stderr, "[ogg123/status.c] enter vstatus_message 1\n");
  if (verbosity > max_verbosity) {
    fprintf(stderr, "[ogg123/status.c] enter vstatus_message 2\n");
    return;
    fprintf(stderr, "[ogg123/status.c] exit vstatus_message 2\n");
  }

  fprintf(stderr, "[ogg123/status.c] enter vstatus_message 3\n");
  pthread_cleanup_push(unlock_output_lock, NULL);

  pthread_mutex_lock(&output_lock);

  clear_line(last_line_len);
  vstatus_print_nolock(fmt, ap);

  pthread_mutex_unlock(&output_lock);

  pthread_cleanup_pop(0);
  fprintf(stderr, "[ogg123/status.c] exit vstatus_message 3\n");
  fprintf(stderr, "[ogg123/status.c] exit vstatus_message 1\n");
}


void status_error (const char *fmt, ...)
{
  fprintf(stderr, "[ogg123/status.c] enter status_error 1\n");
  va_list ap;

  pthread_cleanup_push(unlock_output_lock, NULL);

  pthread_mutex_lock(&output_lock);
  va_start (ap, fmt);
  clear_line(last_line_len);
  vstatus_print_nolock (fmt, ap);
  va_end (ap);
  pthread_mutex_unlock(&output_lock);

  pthread_cleanup_pop(0);

  exit_status = EXIT_FAILURE;
  fprintf(stderr, "[ogg123/status.c] exit status_error 1\n");
}


void vstatus_error (const char *fmt, va_list ap)
{
  fprintf(stderr, "[ogg123/status.c] enter vstatus_error 1\n");
  pthread_cleanup_push(unlock_output_lock, NULL);

  pthread_mutex_lock(&output_lock);
  clear_line(last_line_len);
  vstatus_print_nolock (fmt, ap);
  pthread_mutex_unlock(&output_lock);

  pthread_cleanup_pop(0);

  exit_status = EXIT_FAILURE;
  fprintf(stderr, "[ogg123/status.c] exit vstatus_error 1\n");
}
// Total cost: 0.293412
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 515)]
// Total instrumented cost: 0.293412, input tokens: 20179, output tokens: 14280, cache read tokens: 8832, cache write tokens: 11339

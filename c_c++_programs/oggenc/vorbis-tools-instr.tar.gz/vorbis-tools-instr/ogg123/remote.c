/* remote.c by Richard van Paasen <rvpaasen@dds.nl> */

/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE OggVorbis SOFTWARE CODEC SOURCE CODE.   *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS BEFORE DISTRIBUTING.                     *
 *                                                                  *
 * THE Ogg123 SOURCE CODE IS (C) COPYRIGHT 2000-2001                *
 * by Kenneth C. Arnold <ogg@arnoldnet.net> AND OTHER CONTRIBUTORS  *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

 last mod: $Id$

 ********************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <pthread.h>
#include <semaphore.h>

#if HAVE_SELECT
#include <sys/select.h>
#endif

#include "ogg123.h"
#include "format.h"

/* Maximum size of the input buffer */
#define MAXBUF 1024
/* Undefine logfile if you don't want it */
//#define LOGFILE "/tmp/ogg123.log"

/* The play function in ogg123.c */
extern void play (char *source_string);
extern ogg123_options_t options;
extern void set_seek_opt(ogg123_options_t *ogg123_opts, char *buf);

/* Status */
typedef enum { PLAY, STOP, PAUSE, NEXT, QUIT} Status;
static Status status = STOP;

/* Threading is introduced to reduce the
   amount of processor time that ogg123
   will take if it is in idle state */

/* Thread control locks */
static pthread_mutex_t main_lock;
static sem_t sem_command;
static sem_t sem_processed;
static pthread_mutex_t output_lock;

#ifdef LOGFILE
void send_log(const char* fmt, ...) {
  fprintf(stderr, "[ogg123/remote.c] enter send_log 1\n");
  FILE* fp;
  va_list ap;
  pthread_mutex_lock (&output_lock);
  fp=fopen(LOGFILE,"a");
  va_start(ap, fmt);
  vfprintf(fp, fmt, ap);
  va_end(ap);
  fprintf(fp, "\n");
  fclose(fp);
  pthread_mutex_unlock (&output_lock);
  return;
  fprintf(stderr, "[ogg123/remote.c] exit send_log 1\n");
}
#else
  #define send_log(...)
#endif

static void send_msg(const char* fmt, ...) {
  fprintf(stderr, "[ogg123/remote.c] enter send_msg 1\n");
  va_list ap;
  pthread_mutex_lock (&output_lock);
  fprintf(stdout, "@");
  va_start(ap, fmt);
  vfprintf(stdout, fmt, ap);
  va_end(ap);
  fprintf(stdout, "\n");
  pthread_mutex_unlock (&output_lock);
  return;
  fprintf(stderr, "[ogg123/remote.c] exit send_msg 1\n");
}

static void send_err(const char* fmt, ...) {
  fprintf(stderr, "[ogg123/remote.c] enter send_err 1\n");
  va_list ap;
  pthread_mutex_lock (&output_lock);
  fprintf(stderr, "@");
  va_start(ap, fmt);
  vfprintf(stderr, fmt, ap);
  va_end(ap);
  fprintf(stderr, "\n");
  pthread_mutex_unlock (&output_lock);
  return;
  fprintf(stderr, "[ogg123/remote.c] exit send_err 1\n");
}

static Status getstatus() {
  fprintf(stderr, "[ogg123/remote.c] enter getstatus 1\n");
  return status;
  fprintf(stderr, "[ogg123/remote.c] exit getstatus 1\n");
}

static void setstatus(Status s) {
  fprintf(stderr, "[ogg123/remote.c] enter setstatus 1\n");
  status = s;
  fprintf(stderr, "[ogg123/remote.c] exit setstatus 1\n");
}

static void invertpause() {
  fprintf(stderr, "[ogg123/remote.c] enter invertpause 1\n");
  if (status==PLAY) {
    fprintf(stderr, "[ogg123/remote.c] enter invertpause 2\n");
    status = PAUSE;
    fprintf(stderr, "[ogg123/remote.c] exit invertpause 2\n");
  }
  else if (status==PAUSE) {
    fprintf(stderr, "[ogg123/remote.c] enter invertpause 3\n");
    status = PLAY;
    fprintf(stderr, "[ogg123/remote.c] exit invertpause 3\n");
  }
  return;
  fprintf(stderr, "[ogg123/remote.c] exit invertpause 1\n");
}

static void * remotethread(void * arg) {
  fprintf(stderr, "[ogg123/remote.c] enter remotethread 1\n");
  int done = 0;
  int error = 0;
  int ignore = 0;
  char buf[MAXBUF+1];
  char *b;

#if HAVE_SELECT
  fd_set fd;
#endif
  
  buf[MAXBUF]=0;
  fprintf(stderr, "[ogg123/remote.c] exit remotethread 1\n");

  while(!done) {
    fprintf(stderr, "[ogg123/remote.c] enter remotethread 2\n");
    /* Read a line */
    buf[0] = 0;
    send_log("Waiting for input: ...");

#if HAVE_SELECT
    FD_ZERO(&fd);
    FD_SET(0,&fd);
    select (1, &fd, NULL, NULL, NULL);
#endif

    fgets(buf, MAXBUF, stdin);
    buf[strlen(buf)-1] = 0;

    /* Lock on */
    pthread_mutex_lock (&main_lock);

    send_log("Input: %s", buf);
    error = 0;
    fprintf(stderr, "[ogg123/remote.c] exit remotethread 2\n");

    if (!strncasecmp(buf,"l",1)) {
      fprintf(stderr, "[ogg123/remote.c] enter remotethread 3\n");
	/* prepare to load */
      if ((b=strchr(buf,' ')) != NULL) {
        fprintf(stderr, "[ogg123/remote.c] enter remotethread 4\n");
        /* Prepare to load a new song */
        strcpy((char*)arg, b+1);
        setstatus(NEXT);
        fprintf(stderr, "[ogg123/remote.c] exit remotethread 4\n");
      } 
      else {
        fprintf(stderr, "[ogg123/remote.c] enter remotethread 5\n");
        /* Invalid load command */
        error = 1;
        fprintf(stderr, "[ogg123/remote.c] exit remotethread 5\n");
      }
      fprintf(stderr, "[ogg123/remote.c] exit remotethread 3\n");
    }
    else
    if (!strncasecmp(buf,"p",1)) {
      fprintf(stderr, "[ogg123/remote.c] enter remotethread 6\n");
      /* Prepare to (un)pause */
      invertpause();
      fprintf(stderr, "[ogg123/remote.c] exit remotethread 6\n");
    }
	else
    if (!strncasecmp(buf,"j",1)) {
      fprintf(stderr, "[ogg123/remote.c] enter remotethread 7\n");
      /* Prepare to seek */
      if ((b=strchr(buf,' ')) != NULL) {
        fprintf(stderr, "[ogg123/remote.c] enter remotethread 8\n");
        set_seek_opt(&options, b+1);
        fprintf(stderr, "[ogg123/remote.c] exit remotethread 8\n");
	  }
      ignore = 1;
      fprintf(stderr, "[ogg123/remote.c] exit remotethread 7\n");
    }
    else
    if (!strncasecmp(buf,"s",1)) {
      fprintf(stderr, "[ogg123/remote.c] enter remotethread 9\n");
      /* Prepare to stop */
      setstatus(STOP);
      fprintf(stderr, "[ogg123/remote.c] exit remotethread 9\n");
    }
	else
    if (!strncasecmp(buf,"r",1)) {
      fprintf(stderr, "[ogg123/remote.c] enter remotethread 10\n");
      /* Prepare to reload */
      setstatus(NEXT);
      fprintf(stderr, "[ogg123/remote.c] exit remotethread 10\n");
    }
    else
    if (!strncasecmp(buf,"h",1)) {
      fprintf(stderr, "[ogg123/remote.c] enter remotethread 11\n");
      /* Send help */
	  send_msg("H +----------------------------------------------------+");
	  send_msg("H | Ogg123 remote interface                            |");
	  send_msg("H |----------------------------------------------------|");
	  send_msg("H | Load <file>     -  load a file and starts playing  |");
	  send_msg("H | Pause           -  pause or unpause playing        |");
	  send_msg("H | Jump [+|-]<f>   -  jump <f> seconds forth or back  |");
	  send_msg("H | Stop            -  stop playing                    |");
	  send_msg("H | Reload          -  reload last song                |");
	  send_msg("H | Quit            -  quit ogg123                     |");
	  send_msg("H |----------------------------------------------------|");
	  send_msg("H | refer to README.remote for documentation           |");
	  send_msg("H +----------------------------------------------------+");
	  ignore = 1;
      fprintf(stderr, "[ogg123/remote.c] exit remotethread 11\n");
    }
    else
    if (!strncasecmp(buf,"q",1)) {
      fprintf(stderr, "[ogg123/remote.c] enter remotethread 12\n");
      /* Prepare to quit */
      setstatus(QUIT);
      done = 1;
      fprintf(stderr, "[ogg123/remote.c] exit remotethread 12\n");
    }
    else {
      fprintf(stderr, "[ogg123/remote.c] enter remotethread 13\n");
      /* Unknown input received */
      error = 1;
      fprintf(stderr, "[ogg123/remote.c] exit remotethread 13\n");
    }

    if (ignore) {
      fprintf(stderr, "[ogg123/remote.c] enter remotethread 14\n");
      /* Unlock */
      pthread_mutex_unlock (&main_lock);
      ignore = 0;
      fprintf(stderr, "[ogg123/remote.c] exit remotethread 14\n");
    } else {
      if (error) {
        fprintf(stderr, "[ogg123/remote.c] enter remotethread 15\n");
    	/* Send the error and unlock */
    	send_err("E Unknown command '%s'", buf);
    	send_log("Unknown command '%s'", buf);
		/* Unlock */
    	pthread_mutex_unlock (&main_lock);
        fprintf(stderr, "[ogg123/remote.c] exit remotethread 15\n");
      } 
      else {
        fprintf(stderr, "[ogg123/remote.c] enter remotethread 16\n");
    	/* Signal the main thread */
    	sem_post(&sem_command);
    	/* Unlock */
    	pthread_mutex_unlock (&main_lock);
    	/* Wait until the change has been noticed */
    	sem_wait(&sem_processed);
        fprintf(stderr, "[ogg123/remote.c] exit remotethread 16\n");
      }
    }
  }

  return NULL;
}

void remote_mainloop(void) {
  fprintf(stderr, "[ogg123/remote.c] enter remote_mainloop 1\n");
  int r;
  pthread_t th;
  Status s;
  char fname[MAXBUF+1];

  /* Need to output line by line! */
  setlinebuf(stdout);

  /* Send a greeting */
  send_msg("R ogg123 from " PACKAGE " " VERSION);

  /* Initialize the thread controlling variables */
  pthread_mutex_init(&main_lock, NULL);
  sem_init(&sem_command, 0, 0);
  sem_init(&sem_processed, 0, 0);

  /* Start the thread */
  r = pthread_create(&th, NULL, remotethread, (void*)fname);
  if (r != 0) {
    fprintf(stderr, "[ogg123/remote.c] enter remote_mainloop 2\n");
    send_err("E Could not create a thread (code %d)", r);
    return;
    fprintf(stderr, "[ogg123/remote.c] exit remote_mainloop 2\n");
  }

  send_log("Start");

  /* The thread may already have processed some input,
     get the current status
   */
  pthread_mutex_lock(&main_lock);
  s = getstatus();
  pthread_mutex_unlock(&main_lock);
  fprintf(stderr, "[ogg123/remote.c] exit remote_mainloop 1\n");

  while (s != QUIT) {
    fprintf(stderr, "[ogg123/remote.c] enter remote_mainloop 3\n");
    /* wait for a new command */
    if (s != NEXT) {
      fprintf(stderr, "[ogg123/remote.c] enter remote_mainloop 4\n");
      /* Wait until a new status is available,
         This puts the main tread asleep and
         saves resources
       */
       
      sem_wait(&sem_command);

      pthread_mutex_lock(&main_lock);
      s = getstatus();
      pthread_mutex_unlock(&main_lock);
      fprintf(stderr, "[ogg123/remote.c] exit remote_mainloop 4\n");
    }

    send_log("Status: %d", s);

    if (s == NEXT) {
      fprintf(stderr, "[ogg123/remote.c] enter remote_mainloop 5\n");
      /* The status is to play a new song. Set
         the status to PLAY and signal the thread
         that the status has been processed.
       */
       
      send_msg("I %s", fname);
      send_msg("S 0.0 0 00000 xxxxxx 0 0 0 0 0 0 0 0");
      send_msg("P 2");
      pthread_mutex_lock(&main_lock);
      setstatus(PLAY);
      s = getstatus();
      send_log("mainloop s=%d", s);
      sem_post(&sem_processed);
      s = getstatus();
      send_log("mainloop s=%d", s);
      pthread_mutex_unlock(&main_lock);

      /* Start the player. The player calls the playloop
         frequently to check for a new status (e.g. NEXT,
         STOP or PAUSE.
       */

      pthread_mutex_lock(&main_lock);
      s = getstatus();
      pthread_mutex_unlock(&main_lock);
      send_log("mainloop s=%d", s);
      play(fname);
      
      /* Retrieve the new status */
      pthread_mutex_lock(&main_lock);
      s = getstatus();
      pthread_mutex_unlock(&main_lock);
      fprintf(stderr, "[ogg123/remote.c] exit remote_mainloop 5\n");

/* don't know why this was here, sending "play stoped" on NEXT wasn't good idea... */
//      if (s == NEXT) {
	  
	    /* Send "play stopped" */
//        send_msg("P 0");
//        send_log("P 0");
//      } else {
	  
	    /* Send "play stopped at eof" */
//        send_msg("P 0 EOF");
//        send_log("P 0 EOF");
//      }
      
    }
    else {
      fprintf(stderr, "[ogg123/remote.c] enter remote_mainloop 6\n");
      /* Irrelevent status, notice the thread that
         it has been processed.
       */
       
      sem_post(&sem_processed);
      fprintf(stderr, "[ogg123/remote.c] exit remote_mainloop 6\n");
    }    
    fprintf(stderr, "[ogg123/remote.c] exit remote_mainloop 3\n");
  }

  fprintf(stderr, "[ogg123/remote.c] enter remote_mainloop 7\n");
  /* Send "Quit" */
  send_msg("Q");
  send_log("Quit");

  /* Cleanup the semaphores */
  sem_destroy(&sem_command);
  sem_destroy(&sem_processed);

  return;
  fprintf(stderr, "[ogg123/remote.c] exit remote_mainloop 7\n");
}

int remote_playloop(void) {
  fprintf(stderr, "[ogg123/remote.c] enter remote_playloop 1\n");
  Status s;

  /* Check the status. If the player should pause,
     then signal that the command has been processed
     and wait for a new status. A new status will end
     the player and return control to the main loop.
     The main loop will signal that the new command
     has been processed.
   */
  
  pthread_mutex_lock (&main_lock);
  s = getstatus();
  pthread_mutex_unlock (&main_lock);

  send_log("playloop entry s=%d", s);

  if (s == PAUSE) {
    fprintf(stderr, "[ogg123/remote.c] enter remote_playloop 2\n");
    /* Send "pause on" */
    send_msg("P 1");

    while (s == PAUSE) {
      fprintf(stderr, "[ogg123/remote.c] enter remote_playloop 3\n");
      sem_post(&sem_processed);
      sem_wait(&sem_command);
      pthread_mutex_lock (&main_lock);
      s = getstatus();
      pthread_mutex_unlock (&main_lock);
      fprintf(stderr, "[ogg123/remote.c] exit remote_playloop 3\n");
    }

    /* Send "pause off" */
    send_msg("P 2");
    fprintf(stderr, "[ogg123/remote.c] exit remote_playloop 2\n");
  }

    /* Send stop msg to the frontend */
    /* this probably should be done after the audio buffer is flushed and no audio is actually playing, but don't know how */
  if ((s == STOP) || (s == QUIT)) {
    fprintf(stderr, "[ogg123/remote.c] enter remote_playloop 4\n");
    send_msg("P 0");
    fprintf(stderr, "[ogg123/remote.c] exit remote_playloop 4\n");
  }

  send_log("playloop exit s=%d", s);

  return ((s == NEXT) || (s == STOP) || (s == QUIT));
  fprintf(stderr, "[ogg123/remote.c] exit remote_playloop 1\n");
}

void remote_time(double current, double total) {
  fprintf(stderr, "[ogg123/remote.c] enter remote_time 1\n");
  /* Send the frame (not implemented yet) and the time */
  send_msg("F 0 0 %.2f %.2f", current, (total-current));

  return;
  fprintf(stderr, "[ogg123/remote.c] exit remote_time 1\n");
}
// Total cost: 0.093158
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 424)]
// Total instrumented cost: 0.093158, input tokens: 5751, output tokens: 4604, cache read tokens: 2280, cache write tokens: 3467

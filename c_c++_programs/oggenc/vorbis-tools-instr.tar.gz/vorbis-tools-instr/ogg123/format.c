/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE OggVorbis SOFTWARE CODEC SOURCE CODE.   *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS BEFORE DISTRIBUTING.                     *
 *                                                                  *
 * THE Ogg123 SOURCE CODE IS (C) COPYRIGHT 2000-2001                *
 * by Stan Seibert <volsung@xiph.org> AND OTHER CONTRIBUTORS        *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

 last mod: $Id$

 ********************************************************************/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "transport.h"
#include "format.h"
#include "i18n.h"

extern format_t oggvorbis_format;
extern format_t speex_format;

#ifdef HAVE_LIBFLAC
extern format_t flac_format;
extern format_t oggflac_format;
#endif

#ifdef HAVE_LIBSPEEX
extern format_t speex_format;
#endif

#ifdef HAVE_LIBOPUSFILE
extern format_t opus_format;
#endif


format_t *formats[] = { 
#ifdef HAVE_LIBFLAC
			&flac_format,
			&oggflac_format,
#endif
#ifdef HAVE_LIBSPEEX
			&speex_format,
#endif
#ifdef HAVE_LIBOPUSFILE
			&opus_format,
#endif
			&oggvorbis_format, 
			NULL };


format_t *get_format_by_name (char *name)
{
  fprintf(stderr, "[ogg123/format.c] enter get_format_by_name 1\n");
  int i = 0;

  while (formats[i] != NULL && strcmp(name, formats[i]->name) != 0)
    i++;

  return formats[i];
  fprintf(stderr, "[ogg123/format.c] exit get_format_by_name 1\n");
}


format_t *select_format (data_source_t *source)
{
  fprintf(stderr, "[ogg123/format.c] enter select_format 1\n");
  int i = 0;

  while (formats[i] != NULL && !formats[i]->can_decode(source))
    i++;

  return formats[i];
  fprintf(stderr, "[ogg123/format.c] exit select_format 1\n");
}


decoder_stats_t *malloc_decoder_stats (decoder_stats_t *to_copy)
{
  fprintf(stderr, "\n");
  decoder_stats_t *new_stats;

  new_stats = malloc(sizeof(decoder_stats_t));

  if (new_stats == NULL) {
    fprintf(stderr, "[ogg123/format.c] enter malloc_decoder_stats 2\n");
    fprintf(stderr, _("ERROR: Could not allocate memory in malloc_decoder_stats()\n"));
    exit(1);
    fprintf(stderr, "[ogg123/format.c] exit malloc_decoder_stats 2\n");
  }

  fprintf(stderr, "[ogg123/format.c] enter malloc_decoder_stats 3\n");
  *new_stats = *to_copy;  /* Copy the data */

  return new_stats;
  fprintf(stderr, "[ogg123/format.c] exit malloc_decoder_stats 3\n");
}
// Total cost: 0.019479
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 97)]
// Total instrumented cost: 0.019479, input tokens: 3060, output tokens: 903, cache read tokens: 2280, cache write tokens: 776

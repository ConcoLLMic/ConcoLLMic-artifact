/*
 *  This Confetti example is dedicated to the public domain.
 *  No rights reserved.
 *  http://creativecommons.org/publicdomain/zero/1.0/
 */

// This example reads a Confetti configuration unit from standard input, parses it
// into an in-memory representation, then pretty prints it to standard output.

// Most configuration and data-interchange parsers build an in-memory representation
// so this API will feel more familair. For a more memory efficient approach, see
// the directive walker example.

#include "confetti.h"
#include <stdio.h>
#include <stdlib.h>

char *readstdin(void);

static void indent(int depth)
{
    fprintf(stderr, "[examples/parse.c] enter indent 1\n");
    for (int i = 0; i < depth; i++)
    {
        fprintf(stderr, "[examples/parse.c] enter indent 2\n");
        printf("    "); // four space indention (change as desired)
        // fprintf(stderr, "[examples/parse.c] exit indent 2\n");
    }
    // fprintf(stderr, "[examples/parse.c] exit indent 1\n");
}

static void print_directive(const conf_directive *dir, int depth)
{
    fprintf(stderr, "[examples/parse.c] enter print_directive 1\n");
    //
    // Print this directives arguments, separated by a space character.
    //

    const long argument_count = conf_get_argument_count(dir);
    // fprintf(stderr, "[examples/parse.c] exit print_directive 1\n");
    
    if (argument_count > 0)
    {
        fprintf(stderr, "[examples/parse.c] enter print_directive 2\n");
        indent(depth);
        for (long i = 0; i < argument_count; i++)
        {
            fprintf(stderr, "[examples/parse.c] enter print_directive 3\n");
            const conf_argument *arg = conf_get_argument(dir, i);
            printf("%s", arg->value);
            if (i < (argument_count - 1))
            {
                fprintf(stderr, "[examples/parse.c] enter print_directive 4\n");
                printf(" ");
                // fprintf(stderr, "[examples/parse.c] exit print_directive 4\n");
            }
            // fprintf(stderr, "[examples/parse.c] exit print_directive 3\n");
        }
        // fprintf(stderr, "[examples/parse.c] exit print_directive 2\n");
    }

    fprintf(stderr, "[examples/parse.c] enter print_directive 5\n");
    //
    // Recursively print this directives subdirectives.
    //

    const long subdirective_count = conf_get_directive_count(dir);
    // fprintf(stderr, "[examples/parse.c] exit print_directive 5\n");
    
    if (subdirective_count > 0)
    {
        fprintf(stderr, "[examples/parse.c] enter print_directive 6\n");
        puts(" {");
        for (long i = 0; i < subdirective_count; i++)
        {
            fprintf(stderr, "[examples/parse.c] enter print_directive 7\n");
            const conf_directive *subdirective = conf_get_directive(dir, i);
            print_directive(subdirective, depth + 1);
            // fprintf(stderr, "[examples/parse.c] exit print_directive 7\n");
        }

        indent(depth);
        putchar('}');
        // fprintf(stderr, "[examples/parse.c] exit print_directive 6\n");
    }

    fprintf(stderr, "[examples/parse.c] enter print_directive 8\n");
    puts(""); // Print each directive on its own line.
    // fprintf(stderr, "[examples/parse.c] exit print_directive 8\n");
}

int main(int argc, char *argv[])
{
    fprintf(stderr, "[examples/parse.c] enter main 1\n");
    //
    // (1) Read Confetti from standard input.
    //

    char *input = readstdin();

    //
    // (2) Parse the input as Confetti, checking for errors.
    //

    conf_error err = {0};
    conf_unit *unit = conf_parse(input, NULL, &err);
    // fprintf(stderr, "[examples/parse.c] exit main 1\n");
    
    if (unit == NULL)
    {
        fprintf(stderr, "[examples/parse.c] enter main 2\n");
        printf("error: %s\n", err.description);
        return 1;
        // fprintf(stderr, "[examples/parse.c] exit main 2\n");
    }

    fprintf(stderr, "[examples/parse.c] enter main 3\n");
    //
    // (3) Pretty print the Confetti.
    //

    const conf_directive *root = conf_get_root(unit);
    for (long i = 0; i < conf_get_directive_count(root); i++)
    {
        fprintf(stderr, "[examples/parse.c] enter main 4\n");
        const conf_directive *directive = conf_get_directive(root, i);
        print_directive(directive, 0);
        // fprintf(stderr, "[examples/parse.c] exit main 4\n");
    }

    //
    // (4) Cleanup after ourselves.
    //
    
    conf_free(unit);
    free(input);
    return 0;
    // fprintf(stderr, "[examples/parse.c] exit main 3\n");
}

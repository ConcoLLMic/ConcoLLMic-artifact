/*
 *  This Confetti example is dedicated to the public domain.
 *  No rights reserved.
 *  http://creativecommons.org/publicdomain/zero/1.0/
 */

// This example reads a Confetti configuration unit from standard input and uses the
// directive walker API to visit each directive, pretty printing them to
// standard output.

// Using the directive walker is more memory efficient than using the parse() API as
// the latter builds an in-memory representation of the configuration unit whereas the
// former does not.

#include "confetti.h"
#include <stdio.h>
#include <stdlib.h>

char *readstdin(void);

static void indent(int depth)
{
    fprintf(stderr, "[examples/walk.c] enter indent 1\n");
    for (int i = 0; i < depth; i++)
    {
        fprintf(stderr, "[examples/walk.c] enter indent 2\n");
        printf("    "); // four space indention (change as desired)
        // fprintf(stderr, "[examples/walk.c] exit indent 2\n");
    }
    // fprintf(stderr, "[examples/walk.c] exit indent 1\n");
}

static int step(void *user_data, conf_element type, int argc, const conf_argument *argv, const conf_comment *comment)
{
    fprintf(stderr, "[examples/walk.c] enter step 1\n");
    int *depth = user_data; // The subdirective depth is used to indent the output when pretty printing.
    // fprintf(stderr, "[examples/walk.c] exit step 1\n");
    
    switch (type)
    {
    case CONF_DIRECTIVE:
        fprintf(stderr, "[examples/walk.c] enter step 2\n");
        indent(*depth);
        for (long i = 0; i < argc; i++)
        {
            fprintf(stderr, "[examples/walk.c] enter step 3\n");
            printf("%s", argv[i].value);
            if (i < (argc - 1))
            {
                fprintf(stderr, "[examples/walk.c] enter step 4\n");
                printf(" ");
                // fprintf(stderr, "[examples/walk.c] exit step 4\n");
            }
            // fprintf(stderr, "[examples/walk.c] exit step 3\n");
        }
        putchar('\n');
        break;
        // fprintf(stderr, "[examples/walk.c] exit step 2\n");

    case CONF_BLOCK_ENTER:
        fprintf(stderr, "[examples/walk.c] enter step 5\n");
        indent(*depth);
        puts("{");
        (*depth) += 1;
        break;
        // fprintf(stderr, "[examples/walk.c] exit step 5\n");

    case CONF_BLOCK_LEAVE:
        fprintf(stderr, "[examples/walk.c] enter step 6\n");
        (*depth) -= 1;
        indent(*depth);
        puts("}");
        break;
        // fprintf(stderr, "[examples/walk.c] exit step 6\n");
    }
    
    fprintf(stderr, "[examples/walk.c] enter step 7\n");
    return 0;
    // fprintf(stderr, "[examples/walk.c] exit step 7\n");
}

int main(int argc, char *argv[])
{
    fprintf(stderr, "\n");
    //
    // (1) Read Confetti from standard input.
    //

    char *input = readstdin();

    //
    // (2) Walk the Confetti source text.
    //

    int depth = 0; // Track the subdirective depth to know how much to indent when pretty printing.
    conf_options options = { .user_data = &depth };
    conf_error error = {0};
    conf_walk(input, &options, &error, step);
    if (error.code != CONF_NO_ERROR)
    {
        fprintf(stderr, "[examples/walk.c] enter main 2\n");
        printf("error: %s\n", error.description);
        return 1;
        // fprintf(stderr, "[examples/walk.c] exit main 2\n");
    }

    //
    // (3) Cleanup after ourselves.
    //
    
    fprintf(stderr, "[examples/walk.c] enter main 3\n");
    free(input);
    return 0;
    // fprintf(stderr, "[examples/walk.c] exit main 3\n");
}

/*
 * Confetti: a configuration language and parser library
 * Copyright (c) 2025 Confetti Contributors
 *
 * This file is part of Confetti, distributed under the MIT License
 * For full terms see the included LICENSE file.
 */

// This file does NOT contain a Confetti example, but rather a function to read input
// from stdin on both Windows and *nix systems. See the other C files in this directory
// for code examples.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if defined(_WIN32)
#include <io.h>
#include <fcntl.h>
#else
#include <unistd.h>
#endif

char *readstdin(void)
{
    fprintf(stderr, "[examples/_readstdin.c] enter readstdin 1\n");
    char *dynbuf = NULL;
    size_t dynbuf_length = 0;
    size_t dynbuf_capacity = 0;

#if defined(_WIN32)
    const int stdin_fd = _fileno(stdin);
#endif
    // fprintf(stderr, "[examples/_readstdin.c] exit readstdin 1\n");

    for (;;)
    {
        fprintf(stderr, "[examples/_readstdin.c] enter readstdin 2\n");
        char buffer[4096];
#if defined(_WIN32)
        const int bytes_read = _read(stdin_fd, buffer, sizeof(buffer));
#else
        const ssize_t bytes_read = read(STDIN_FILENO, buffer, sizeof(buffer));
#endif
        // fprintf(stderr, "[examples/_readstdin.c] exit readstdin 2\n");
        
        if (bytes_read == 0)
        {
            fprintf(stderr, "[examples/_readstdin.c] enter readstdin 3\n");
            break;
            // fprintf(stderr, "[examples/_readstdin.c] exit readstdin 3\n");
        }
        else if (bytes_read < 0)
        {
            fprintf(stderr, "[examples/_readstdin.c] enter readstdin 4\n");
            perror("read() failed");
            free(dynbuf);
            exit(1);
            // fprintf(stderr, "[examples/_readstdin.c] exit readstdin 4\n");
        }

        fprintf(stderr, "[examples/_readstdin.c] enter readstdin 5\n");
        const size_t buffer_length = (size_t)bytes_read;
        // fprintf(stderr, "[examples/_readstdin.c] exit readstdin 5\n");
        
        if ((dynbuf_length + buffer_length) >= dynbuf_capacity)
        {
            fprintf(stderr, "[examples/_readstdin.c] enter readstdin 6\n");
            size_t newcap = dynbuf_length + buffer_length;
            char *newbuf = realloc(dynbuf, newcap + 1); // +1 for the null byte
            // fprintf(stderr, "[examples/_readstdin.c] exit readstdin 6\n");
            
            if (newbuf == NULL)
            {
                fprintf(stderr, "[examples/_readstdin.c] enter readstdin 7\n");
                perror("realloc() failed");
                free(dynbuf);
                exit(1);
                // fprintf(stderr, "[examples/_readstdin.c] exit readstdin 7\n");
            }
            
            fprintf(stderr, "[examples/_readstdin.c] enter readstdin 8\n");
            dynbuf = newbuf;
            dynbuf_capacity = newcap;
            // fprintf(stderr, "[examples/_readstdin.c] exit readstdin 8\n");
        }

        fprintf(stderr, "[examples/_readstdin.c] enter readstdin 9\n");
        memcpy(&dynbuf[dynbuf_length], buffer, buffer_length);
        dynbuf_length += buffer_length;
        // fprintf(stderr, "[examples/_readstdin.c] exit readstdin 9\n");
    }

    fprintf(stderr, "[examples/_readstdin.c] enter readstdin 10\n");
    dynbuf[dynbuf_length] = '\0';
    return dynbuf;
    // fprintf(stderr, "[examples/_readstdin.c] exit readstdin 10\n");
}

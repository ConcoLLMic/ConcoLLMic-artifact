/*
 * Confetti: a configuration language and parser library
 * Copyright (c) 2025 Henry G. Stratmann III
 * Copyright (c) 2025 Confetti Contributors
 *
 * This file is part of Confetti, distributed under the MIT License.
 * For full terms see the included LICENSE file.
 */

// This implementation of Confetti is more complex than it ought to be because:
//
//   (1) It supports two API's - a callback-based tree-walking API as well as an
//       API for building an in-memory tree structure.
//
//   (2) It supports all optional extensions specified in the annex of the Confetti 
//       language specification. These extensions are opt-in via the public API.
//
//   (3) It tracks meta-data about the source text, like code comments, as well as
//       additional toggles in the public API, like for rejecting source text with
//       bidirectional formatting characters.
//
//   (4) Lastly, it is designed for efficiency, rather than optimal clarity.
//
// Purpose-built implementations can omit unused extensions, ignore comments, and
// simplify the API. Ideally, a more straightforward implementation could,
// potentially, be only a few hundred lines of C, at most.

#include "confetti.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdarg.h>
#include <setjmp.h>
#include <assert.h>
#include <stdint.h>
#include <stdalign.h>
#include <stddef.h>

// When gathering branch coverage, do not let untaken assert branches contribute negatively to
// the metrics. Asserts are never supposed to fail so their branches will not be taken.
#if defined(CODE_COVERAGE)
#undef assert
#define assert(x)
#endif

// This is a workaround for Visual Studio's lack of support for max_align_t.
#if defined(_MSC_VER)
#define max_align_t 16
#endif

typedef uint32_t uchar; // Unicode scalar value.

uint8_t conf_uniflags(uint32_t cp);

#define IS_FORBIDDEN_CHARACTER 0x1 // set of forbidden characters
#define IS_SPACE_CHARACTER 0x2 // set of white space and new line characters
#define IS_PUNCTUATOR_CHARACTER 0x4 // set of reserved punctuator characters
#define IS_ARGUMENT_CHARACTER 0x8 // set of characters that are valid in an unquoted argument
#define IS_BIDI_CHARACTER 0x10 // set of bidirectional formatting characters
#define IS_ESCAPABLE_CHARACTER (IS_ARGUMENT_CHARACTER | IS_PUNCTUATOR_CHARACTER)

#define BAD_ENCODING 0x110000

typedef enum token_type
{
    TOK_INVALID,
    TOK_EOF,
    TOK_COMMENT,
    TOK_WHITESPACE,
    TOK_NEWLINE,
    TOK_ARGUMENT,
    TOK_CONTINUATION,
    TOK_SEMICOLON = ';',
    TOK_LCURLYB = '{',
    TOK_RCURLYB = '}',
} token_type;

typedef enum token_flags
{
    CONF_QUOTED = 0x1,
    CONF_TRIPLE_QUOTED = 0x2,
    CONF_EXPRESSION = 0x4,
} token_flags;

typedef struct token
{
    size_t lexeme;
    size_t lexeme_length;

    // Number of bytes to trim from the beginning and end of the lexeme when it's converted
    // to a value. For example, when a quoted argument is processed, the enclsoing quotes
    // are trimmed.
    size_t trim;

    token_type type;
    token_flags flags;
} token;

struct comment
{
    conf_comment data;
    struct comment *next;
};

struct conf_directive
{
    long buffer_length;
    long subdir_count;
    long arguments_count;

    conf_argument *arguments;
    
    conf_directive **subdir;
    conf_directive *subdir_head;
    conf_directive *subdir_tail;
    conf_directive *next;

    char buffer[];
};

// Represents a set of punctuator arguments beginning with the same Unicode scalar value.
struct punctset
{
    size_t size; // The size, in bytes, of this structure in memory.
    long length; // The total number of punctuators sharing the same starting character.
    char punctuators[]; // List of punctuator strings delimited by a zero byte.
};

struct conf_unit
{
    const char *string; // Points to the beginning of the string being parsed.
    const char *needle; // Points to the current location being parsed.
    
    conf_walkfn walk;
    token peek; // Current, but processed token.

    // The punctuator starters array is an array of Unicode scalar values where each scalar
    // is a unique starting character amongst the set of punctuators. For example, if we
    // have the punctuator set {'+', '+=', '-', '-='}, then this arrays length is two
    // because we have two unique starting characters: '+' and '-'.
    uchar *punctuator_starters;
    size_t punctuator_starters_size;

    // The punctuators array is an array of arrays, where each subarray contains punctuators
    // that begin with the same Unicode scalar value (i.e. the same starter character).
    struct punctset **punctuators;
    long punctuators_count;

    // Comments are tracked in a linked list when the source text is parsed, but then
    // they are moved to an array for O(1) access time after parsing completes.
    long comments_count;
    struct comment **comments;
    struct comment *comment_head;
    struct comment *comment_tail;
    size_t comment_processed;

    // These are user-provided structures.
    conf_options options;
    conf_extensions extensions;

    conf_directive *root;

    jmp_buf err_buf;
    conf_error err;

    alignas(max_align_t) unsigned char padding[sizeof(conf_directive)];
};

static void parse_body(conf_unit *conf, conf_directive *parent, int depth);

_Noreturn static void die(conf_unit *conf, conf_errno error, const char *where, const char *message, ...)
{
    fprintf(stderr, "[confetti.c] enter die 1\n");
    assert(conf != NULL);
    assert(where != NULL);

    conf->err.code = error;
    conf->err.where = where - conf->string;

    va_list args;
    va_start(args, message);
    const int n = vsnprintf(conf->err.description, sizeof(conf->err.description), message, args);
    if (n < 0)
    {
        fprintf(stderr, "[confetti.c] enter die 2\n");
        strcpy(conf->err.description, "formatting description failed");
        // fprintf(stderr, "[confetti.c] exit die 2\n");
    }
    va_end(args);
    assert(n < (int)sizeof(conf->err.description));

    longjmp(conf->err_buf, 1);
    // fprintf(stderr, "[confetti.c] exit die 1\n");
}

static void *default_alloc(void *ud, void *ptr, size_t size)
{
    fprintf(stderr, "[confetti.c] enter default_alloc 1\n");
    assert(size > 0);
    if (ptr == NULL)
    {
        fprintf(stderr, "[confetti.c] enter default_alloc 2\n");
        return malloc(size);
        // fprintf(stderr, "[confetti.c] exit default_alloc 2\n");
    }
    else
    {
        fprintf(stderr, "[confetti.c] enter default_alloc 3\n");
        free(ptr);
        return NULL;
        // fprintf(stderr, "[confetti.c] exit default_alloc 3\n");
    }
    // fprintf(stderr, "[confetti.c] exit default_alloc 1\n");
}

static void *new(conf_unit *conf, size_t size)
{
    fprintf(stderr, "[confetti.c] enter new 1\n");
    assert(conf != NULL);
    assert(size > 0);
    return conf->options.allocator(conf->options.user_data, NULL, size);
    // fprintf(stderr, "[confetti.c] exit new 1\n");
}

static void *zero_new(conf_unit *conf, size_t size)
{
    fprintf(stderr, "[confetti.c] enter zero_new 1\n");
    void *ptr = new(conf, size);
    if (ptr != NULL)
    {
        fprintf(stderr, "[confetti.c] enter zero_new 2\n");
        (void)memset(ptr, 0, size);
        // fprintf(stderr, "[confetti.c] exit zero_new 2\n");
    }
    return ptr;
    // fprintf(stderr, "[confetti.c] exit zero_new 1\n");
}

static void delete(conf_unit *conf, void *ptr, size_t size)
{
    fprintf(stderr, "[confetti.c] enter delete 1\n");
    assert(conf != NULL);
    assert(ptr != NULL);
    assert(size > 0);
    conf->options.allocator(conf->options.user_data, ptr, size);
    // fprintf(stderr, "[confetti.c] exit delete 1\n");
}

static uchar utf8decode2(const char *utf8, size_t *utf8_length)
{
    fprintf(stderr, "[confetti.c] enter utf8decode2 1\n");
    assert(utf8 != NULL);

    static const uint8_t bytes_needed_for_UTF8_sequence[] = {
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
        2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        // Defines bit patterns for masking the leading byte of a UTF-8 sequence.
        0,
        0xFF, // Single byte (i.e. fits in ASCII).
        0x1F, // Two byte sequence: 110xxxxx 10xxxxxx.
        0x0F, // Three byte sequence: 1110xxxx 10xxxxxx 10xxxxxx.
        0x07, // Four byte sequence: 11110xxx 10xxxxxx 10xxxxxx 10xxxxxx.
    };

    static const uint8_t next_UTF8_DFA[] = {
        0, 12, 24, 36, 60, 96, 84, 12, 12, 12, 48, 72,  // state 0
        12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, // state 1
        12, 0, 12, 12, 12, 12, 12, 0, 12, 0, 12, 12,    // state 2
        12, 24, 12, 12, 12, 12, 12, 24, 12, 24, 12, 12, // state 3
        12, 12, 12, 12, 12, 12, 12, 24, 12, 12, 12, 12, // state 4
        12, 24, 12, 12, 12, 12, 12, 12, 12, 24, 12, 12, // state 5
        12, 12, 12, 12, 12, 12, 12, 36, 12, 36, 12, 12, // state 6
        12, 36, 12, 12, 12, 12, 12, 36, 12, 36, 12, 12, // state 7
        12, 36, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, // state 8
    };

    static const uint8_t byte_to_character_class[] = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
        7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
        7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
        8, 8, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
        2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
        10, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 3, 3,
        11, 6, 6, 6, 5, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
    };

    // Offset to the requested code unit.
    const uint8_t *bytes = (const uint8_t *)utf8;

    // Zero initialize the byte count.
    if (utf8_length != NULL)
    {
        fprintf(stderr, "[confetti.c] enter utf8decode2 2\n");
        *utf8_length = 0;
        // fprintf(stderr, "[confetti.c] exit utf8decode2 2\n");
    }

    // Check for the end of the string.
    if (bytes[0] == 0x0)
    {
        fprintf(stderr, "[confetti.c] enter utf8decode2 3\n");
        return '\0';
        // fprintf(stderr, "[confetti.c] exit utf8decode2 3\n");
    }

    // Lookup expected UTF-8 sequence length based on the first byte.
    const int seqlen = bytes_needed_for_UTF8_sequence[bytes[0]];
    if (seqlen == 0)
    {
        fprintf(stderr, "[confetti.c] enter utf8decode2 4\n");
        return BAD_ENCODING;
        // fprintf(stderr, "[confetti.c] exit utf8decode2 4\n");
    }

    // Check if the character ends prematurely due to a null terminator.
    for (int i = 1; i < seqlen; i++)
    {
        fprintf(stderr, "[confetti.c] enter utf8decode2 5\n");
        if (bytes[i] == '\0')
        {
            fprintf(stderr, "[confetti.c] enter utf8decode2 6\n");
            return BAD_ENCODING;
            // fprintf(stderr, "[confetti.c] exit utf8decode2 6\n");
        }
        // fprintf(stderr, "[confetti.c] exit utf8decode2 5\n");
    }

    // Consume the first UTF-8 byte.
    uchar value = (uchar)(bytes[0] & bytes_needed_for_UTF8_sequence[256 + seqlen]);

    // Transition to the first DFA state.
    uint8_t unit = next_UTF8_DFA[byte_to_character_class[bytes[0]]];

    // Consume the remaining UTF-8 bytes.
    for (int i = 1; i < seqlen; i++)
    {
        fprintf(stderr, "[confetti.c] enter utf8decode2 7\n");
        // Mask off the next byte.
        // It's of the form 10xxxxxx if valid UTF-8.
        value = value << UINT32_C(6) | (uchar)(bytes[i] & UINT8_C(0x3F));

        // Transition to the next DFA state.
        unit = next_UTF8_DFA[unit + byte_to_character_class[bytes[i]]];
        // fprintf(stderr, "[confetti.c] exit utf8decode2 7\n");
    }

    // Verify the encoded character was well-formed.
    if (unit == UINT8_C(0))
    {
        fprintf(stderr, "[confetti.c] enter utf8decode2 8\n");
        if (utf8_length != NULL)
        {
            fprintf(stderr, "[confetti.c] enter utf8decode2 9\n");
            *utf8_length = seqlen;
            // fprintf(stderr, "[confetti.c] exit utf8decode2 9\n");
        }
        return value;
        // fprintf(stderr, "[confetti.c] exit utf8decode2 8\n");
    }
    
    fprintf(stderr, "[confetti.c] enter utf8decode2 10\n");
    return BAD_ENCODING;
    // fprintf(stderr, "[confetti.c] exit utf8decode2 10\n");
    // fprintf(stderr, "[confetti.c] exit utf8decode2 1\n");
}

static uchar utf8decode(conf_unit *conf, const char *utf8, size_t *utf8_length)
{
    fprintf(stderr, "[confetti.c] enter utf8decode 1\n");
    const uchar scalar = utf8decode2(utf8, utf8_length);
    if (scalar == BAD_ENCODING)
    {
        fprintf(stderr, "[confetti.c] enter utf8decode 2\n");
        die(conf, CONF_ILLEGAL_BYTE_SEQUENCE, utf8, "malformed UTF-8");
        // fprintf(stderr, "[confetti.c] exit utf8decode 2\n");
    }
    return scalar;
    // fprintf(stderr, "[confetti.c] exit utf8decode 1\n");
}

static bool is_newline(conf_unit *conf, const char *string, size_t *length)
{
    fprintf(stderr, "[confetti.c] enter is_newline 1\n");
    assert(conf != NULL);
    assert(string != NULL);
    assert(length != NULL);

    if (strncmp(string, "\r\n", 2) == 0)
    {
        fprintf(stderr, "[confetti.c] enter is_newline 2\n");
        *length = 2;
        return true;
        // fprintf(stderr, "[confetti.c] exit is_newline 2\n");
    }
    
    switch (utf8decode(conf, string, length))
    {
    case 0x000A: // Line feed
    case 0x000B: // Vertical tab
    case 0x000C: // Form feed
    case 0x000D: // Carriage return
    case 0x0085: // Next line
    case 0x2028: // Line separator
    case 0x2029: // Paragraph separator
        fprintf(stderr, "[confetti.c] enter is_newline 3\n");
        return true;
        // fprintf(stderr, "[confetti.c] exit is_newline 3\n");
    }

    fprintf(stderr, "[confetti.c] enter is_newline 4\n");
    return false;
    // fprintf(stderr, "[confetti.c] exit is_newline 4\n");
    // fprintf(stderr, "[confetti.c] exit is_newline 1\n");
}

// Scan expression arguments is implemented using a "virtual" stack data structure.
// When '(' is encountered, it's pushed, when ')' is encountered, it's popped.
// When the stack is empty, the expression has been fully processed.
static void scan_expression_argument(conf_unit *conf, const char *string, token *tok)
{
    fprintf(stderr, "[confetti.c] enter scan_expression_argument 1\n");
    assert(conf != NULL);
    assert(string != NULL);
    assert(string[0] == '(');
    assert(tok != NULL);

    const char *at = string + 1; // +1 to skip the opening '(' character
    size_t stack = 1; // "push" an opening '(' character onto the "stack"

    for (;;)
    {
        fprintf(stderr, "[confetti.c] enter scan_expression_argument 2\n");
        if (at[0] == '\0')
        {
            fprintf(stderr, "[confetti.c] enter scan_expression_argument 3\n");
            die(conf, CONF_BAD_SYNTAX, string, "incomplete expression");
            // fprintf(stderr, "[confetti.c] exit scan_expression_argument 3\n");
        }
        
        if (at[0] == '(')
        {
            fprintf(stderr, "[confetti.c] enter scan_expression_argument 4\n");
            stack += 1; // "push" a '(' character onto the stack
            at += 1;
            // fprintf(stderr, "[confetti.c] exit scan_expression_argument 4\n");
        }
        else if (at[0] == ')')
        {
            fprintf(stderr, "[confetti.c] enter scan_expression_argument 5\n");
            stack -= 1; // "pop" a ')' character from the stack
            at += 1;

            // If the "stack" is empty, then the complete expression has been processed.
            if (stack == 0)
            {
                fprintf(stderr, "[confetti.c] enter scan_expression_argument 6\n");
                break;
                // fprintf(stderr, "[confetti.c] exit scan_expression_argument 6\n");
            }
            // fprintf(stderr, "[confetti.c] exit scan_expression_argument 5\n");
        }
        else
        {
            fprintf(stderr, "[confetti.c] enter scan_expression_argument 7\n");
            size_t length = 0;
            const uchar cp = utf8decode(conf, at, &length);

            if (conf_uniflags(cp) & IS_FORBIDDEN_CHARACTER)
            {
                fprintf(stderr, "[confetti.c] enter scan_expression_argument 8\n");
                die(conf, CONF_BAD_SYNTAX, at, "illegal character");
                // fprintf(stderr, "[confetti.c] exit scan_expression_argument 8\n");
            }

            if ((conf_uniflags(cp) & IS_BIDI_CHARACTER) && !conf->options.allow_bidi)
            {
                fprintf(stderr, "[confetti.c] enter scan_expression_argument 9\n");
                die(conf, CONF_BAD_SYNTAX, at, "illegal bidirectional character");
                // fprintf(stderr, "[confetti.c] exit scan_expression_argument 9\n");
            }

            at += length;
            // fprintf(stderr, "[confetti.c] exit scan_expression_argument 7\n");
        }
        // fprintf(stderr, "[confetti.c] exit scan_expression_argument 2\n");
    }

    fprintf(stderr, "[confetti.c] enter scan_expression_argument 10\n");
    tok->lexeme = string - conf->string;
    tok->lexeme_length = at - string;
    tok->type = TOK_ARGUMENT;
    tok->flags = CONF_EXPRESSION;
    tok->trim = 1;
    // fprintf(stderr, "[confetti.c] exit scan_expression_argument 10\n");
    // fprintf(stderr, "[confetti.c] exit scan_expression_argument 1\n");
}

static void scan_triple_quoted_argument(conf_unit *conf, const char *string, token *tok)
{
    fprintf(stderr, "[confetti.c] enter scan_triple_quoted_argument 1\n");
    const char *at = string;
    size_t length;

    assert(conf != NULL);
    assert(string != NULL);
    assert(tok != NULL);
    assert((at[0] == '"') && (at[1] == '"') && (at[2] == '"'));

    at += 3; // Skip the opening quote characters.

    for (;;)
    {
        fprintf(stderr, "[confetti.c] enter scan_triple_quoted_argument 2\n");
        // Check for the end of a triple quoted argument.
        if ((at[0] == '"') && (at[1] == '"') && (at[2] == '"'))
        {
            fprintf(stderr, "[confetti.c] enter scan_triple_quoted_argument 3\n");
            at += 3;
            break;
            // fprintf(stderr, "[confetti.c] exit scan_triple_quoted_argument 3\n");
        }

        uchar cp = utf8decode(conf, at, &length);
        if (cp == '\0')
        {
            fprintf(stderr, "[confetti.c] enter scan_triple_quoted_argument 4\n");
            die(conf, CONF_BAD_SYNTAX, at, "unclosed quoted");
            // fprintf(stderr, "[confetti.c] exit scan_triple_quoted_argument 4\n");
        }

        if ((conf_uniflags(cp) & IS_BIDI_CHARACTER) && !conf->options.allow_bidi)
        {
            fprintf(stderr, "[confetti.c] enter scan_triple_quoted_argument 5\n");
            die(conf, CONF_BAD_SYNTAX, at, "illegal bidirectional character");
            // fprintf(stderr, "[confetti.c] exit scan_triple_quoted_argument 5\n");
        }

        if (cp == '\\')
        {
            fprintf(stderr, "[confetti.c] enter scan_triple_quoted_argument 6\n");
            at += 1;
            cp = utf8decode(conf, at, &length);
            
            if ((conf_uniflags(cp) & IS_ESCAPABLE_CHARACTER) == 0)
            {
                fprintf(stderr, "[confetti.c] enter scan_triple_quoted_argument 7\n");
                if (cp == 0 || is_newline(conf, at, &length))
                {
                    fprintf(stderr, "[confetti.c] enter scan_triple_quoted_argument 8\n");
                    die(conf, CONF_BAD_SYNTAX, at, "incomplete escape sequence");
                    // fprintf(stderr, "[confetti.c] exit scan_triple_quoted_argument 8\n");
                }
                die(conf, CONF_BAD_SYNTAX, at, "illegal escape character");
                // fprintf(stderr, "[confetti.c] exit scan_triple_quoted_argument 7\n");
            }

            if ((conf_uniflags(cp) & IS_BIDI_CHARACTER) && !conf->options.allow_bidi)
            {
                fprintf(stderr, "[confetti.c] enter scan_triple_quoted_argument 9\n");
                die(conf, CONF_BAD_SYNTAX, at, "illegal bidirectional character");
                // fprintf(stderr, "[confetti.c] exit scan_triple_quoted_argument 9\n");
            }
            // fprintf(stderr, "[confetti.c] exit scan_triple_quoted_argument 6\n");
        }
        else
        {
            fprintf(stderr, "[confetti.c] enter scan_triple_quoted_argument 10\n");
            if (is_newline(conf, at, &length))
            {
                fprintf(stderr, "[confetti.c] enter scan_triple_quoted_argument 11\n");
                at += length;
                continue;
                // fprintf(stderr, "[confetti.c] exit scan_triple_quoted_argument 11\n");
            }
            else if ((conf_uniflags(cp) & (IS_ESCAPABLE_CHARACTER | IS_SPACE_CHARACTER)) == 0)
            {
                fprintf(stderr, "[confetti.c] enter scan_triple_quoted_argument 12\n");
                die(conf, CONF_BAD_SYNTAX, at, "illegal character");
                // fprintf(stderr, "[confetti.c] exit scan_triple_quoted_argument 12\n");
            }
            // fprintf(stderr, "[confetti.c] exit scan_triple_quoted_argument 10\n");
        }

        at += length;
        // fprintf(stderr, "[confetti.c] exit scan_triple_quoted_argument 2\n");
    }

    fprintf(stderr, "[confetti.c] enter scan_triple_quoted_argument 13\n");
    tok->lexeme = string - conf->string;
    tok->lexeme_length = at - string;
    tok->type = TOK_ARGUMENT;
    tok->flags = CONF_TRIPLE_QUOTED;
    tok->trim = 3;
    // fprintf(stderr, "[confetti.c] exit scan_triple_quoted_argument 13\n");
    // fprintf(stderr, "[confetti.c] exit scan_triple_quoted_argument 1\n");
}

static void scan_single_quoted_argument(conf_unit *conf, const char *string, token *tok)
{
    fprintf(stderr, "[confetti.c] enter scan_single_quoted_argument 1\n");
    const char *at = string;
    size_t length;

    assert(conf != NULL);
    assert(string != NULL);
    assert(tok != NULL);
    assert(at[0] == '"');

    at += 1; // Skip the opening quote character.

    for (;;)
    {
        fprintf(stderr, "[confetti.c] enter scan_single_quoted_argument 2\n");
        uchar cp = utf8decode(conf, at, &length);

        if (cp == '\0' || is_newline(conf, at, &length))
        {
            fprintf(stderr, "[confetti.c] enter scan_single_quoted_argument 3\n");
            die(conf, CONF_BAD_SYNTAX, at, "unclosed quoted");
            // fprintf(stderr, "[confetti.c] exit scan_single_quoted_argument 3\n");
        }

        if (cp == '\\')
        {
            fprintf(stderr, "[confetti.c] enter scan_single_quoted_argument 4\n");
            at += 1;

            // New lines after a backslash are ignored in single quoted arguments.
            if (is_newline(conf, at, &length))
            {
                fprintf(stderr, "[confetti.c] enter scan_single_quoted_argument 5\n");
                at += length;
                continue;
                // fprintf(stderr, "[confetti.c] exit scan_single_quoted_argument 5\n");
            }

            // Verify the backslash is followed by a legal character.
            cp = utf8decode(conf, at, &length);
            if ((conf_uniflags(cp) & IS_ESCAPABLE_CHARACTER) == 0)
            {
                fprintf(stderr, "[confetti.c] enter scan_single_quoted_argument 6\n");
                if (cp == 0)
                {
                    fprintf(stderr, "[confetti.c] enter scan_single_quoted_argument 7\n");
                    die(conf, CONF_BAD_SYNTAX, at, "incomplete escape sequence");
                    // fprintf(stderr, "[confetti.c] exit scan_single_quoted_argument 7\n");
                }
                die(conf, CONF_BAD_SYNTAX, at, "illegal escape character");
                // fprintf(stderr, "[confetti.c] exit scan_single_quoted_argument 6\n");
            }

            if ((conf_uniflags(cp) & IS_BIDI_CHARACTER) && !conf->options.allow_bidi)
            {
                fprintf(stderr, "[confetti.c] enter scan_single_quoted_argument 8\n");
                die(conf, CONF_BAD_SYNTAX, at, "illegal bidirectional character");
                // fprintf(stderr, "[confetti.c] exit scan_single_quoted_argument 8\n");
            }
            // fprintf(stderr, "[confetti.c] exit scan_single_quoted_argument 4\n");
        }
        else
        {
            fprintf(stderr, "[confetti.c] enter scan_single_quoted_argument 9\n");
            if ((conf_uniflags(cp) & (IS_ESCAPABLE_CHARACTER | IS_SPACE_CHARACTER)) == 0)
            {
                fprintf(stderr, "[confetti.c] enter scan_single_quoted_argument 10\n");
                die(conf, CONF_BAD_SYNTAX, at, "illegal character");
                // fprintf(stderr, "[confetti.c] exit scan_single_quoted_argument 10\n");
            }

            if ((conf_uniflags(cp) & IS_BIDI_CHARACTER) && !conf->options.allow_bidi)
            {
                fprintf(stderr, "[confetti.c] enter scan_single_quoted_argument 11\n");
                die(conf, CONF_BAD_SYNTAX, at, "illegal bidirectional character");
                // fprintf(stderr, "[confetti.c] exit scan_single_quoted_argument 11\n");
            }

            if (cp == '"')
            {
                fprintf(stderr, "[confetti.c] enter scan_single_quoted_argument 12\n");
                at += length;
                break;
                // fprintf(stderr, "[confetti.c] exit scan_single_quoted_argument 12\n");
            }
            // fprintf(stderr, "[confetti.c] exit scan_single_quoted_argument 9\n");
        }
        
        at += length;
        // fprintf(stderr, "[confetti.c] exit scan_single_quoted_argument 2\n");
    }

    fprintf(stderr, "[confetti.c] enter scan_single_quoted_argument 13\n");
    tok->lexeme = string - conf->string;
    tok->lexeme_length = at - string;
    tok->type = TOK_ARGUMENT;
    tok->flags = CONF_QUOTED;
    tok->trim = 1;
    // fprintf(stderr, "[confetti.c] exit scan_single_quoted_argument 13\n");
    // fprintf(stderr, "[confetti.c] exit scan_single_quoted_argument 1\n");
}

static bool scan_punctuator_argument(conf_unit *conf, const char *string, token *tok, uchar starter)
{
    fprintf(stderr, "[confetti.c] enter scan_punctuator_argument 1\n");
    assert(conf != NULL);
    assert(conf->punctuators_count > 0);
    assert(string != NULL);
    assert(tok != NULL);

    size_t longest_match = 0;
    for (long i = 0; i < conf->punctuators_count; i++)
    {
        fprintf(stderr, "[confetti.c] enter scan_punctuator_argument 2\n");
        if (conf->punctuator_starters[i] != starter)
        {
            fprintf(stderr, "[confetti.c] enter scan_punctuator_argument 3\n");
            continue;
            // fprintf(stderr, "[confetti.c] exit scan_punctuator_argument 3\n");
        }

        size_t buffer_offset = 0;
        const struct punctset *set = conf->punctuators[i];
        for (long i = 0; i < set->length; i++)
        {
            fprintf(stderr, "[confetti.c] enter scan_punctuator_argument 4\n");
            const char *punctuator = &set->punctuators[buffer_offset];
            const size_t punctuator_length = strlen(punctuator);
            if (punctuator_length >= longest_match)
            {
                fprintf(stderr, "[confetti.c] enter scan_punctuator_argument 5\n");
                if (strncmp(string, punctuator, punctuator_length) == 0)
                {
                    fprintf(stderr, "[confetti.c] enter scan_punctuator_argument 6\n");
                    tok->lexeme = string - conf->string;
                    tok->lexeme_length =  punctuator_length;
                    tok->type = TOK_ARGUMENT;
                    tok->flags = 0;
                    tok->trim = 0;
                    longest_match = punctuator_length;    
                    // fprintf(stderr, "[confetti.c] exit scan_punctuator_argument 6\n");
                }
                // fprintf(stderr, "[confetti.c] exit scan_punctuator_argument 5\n");
            }
            buffer_offset += punctuator_length + 1;
            // fprintf(stderr, "[confetti.c] exit scan_punctuator_argument 4\n");
        }
        // fprintf(stderr, "[confetti.c] exit scan_punctuator_argument 2\n");
    }

    if (longest_match > 0)
    {
        fprintf(stderr, "[confetti.c] enter scan_punctuator_argument 7\n");
        return true;
        // fprintf(stderr, "[confetti.c] exit scan_punctuator_argument 7\n");
    }
    fprintf(stderr, "[confetti.c] enter scan_punctuator_argument 8\n");
    return false;
    // fprintf(stderr, "[confetti.c] exit scan_punctuator_argument 8\n");
    // fprintf(stderr, "[confetti.c] exit scan_punctuator_argument 1\n");
}

static void scan_argument(conf_unit *conf, const char *string, token *tok)
{
    fprintf(stderr, "[confetti.c] enter scan_argument 1\n");
    const char *at = string;
    size_t length;

    assert(conf != NULL);
    assert(string != NULL);
    assert(tok != NULL);
    
    for (;;)
    {
        fprintf(stderr, "[confetti.c] enter scan_argument 2\n");
        uchar cp = utf8decode(conf, at, &length);
        if (cp == '\\')
        {
            fprintf(stderr, "[confetti.c] enter scan_argument 3\n");
            at += 1;
            cp = utf8decode(conf, at, &length);

            if ((conf_uniflags(cp) & IS_ESCAPABLE_CHARACTER) == 0)
            {
                fprintf(stderr, "[confetti.c] enter scan_argument 4\n");
                die(conf, CONF_BAD_SYNTAX, at, "illegal escape character");
                // fprintf(stderr, "[confetti.c] exit scan_argument 4\n");
            }

            if ((conf_uniflags(cp) & IS_BIDI_CHARACTER) && !conf->options.allow_bidi)
            {
                fprintf(stderr, "[confetti.c] enter scan_argument 5\n");
                die(conf, CONF_BAD_SYNTAX, at, "illegal bidirectional character");
                // fprintf(stderr, "[confetti.c] exit scan_argument 5\n");
            }

            at += length;
            continue;
            // fprintf(stderr, "[confetti.c] exit scan_argument 3\n");
        }

        if ((conf_uniflags(cp) & IS_ARGUMENT_CHARACTER) == 0)
        {
            fprintf(stderr, "[confetti.c] enter scan_argument 6\n");
            break;
            // fprintf(stderr, "[confetti.c] exit scan_argument 6\n");
        }

        if ((conf_uniflags(cp) & IS_BIDI_CHARACTER) && !conf->options.allow_bidi)
        {
            fprintf(stderr, "[confetti.c] enter scan_argument 7\n");
            die(conf, CONF_BAD_SYNTAX, at, "illegal bidirectional character");
            // fprintf(stderr, "[confetti.c] exit scan_argument 7\n");
        }

        // If the expression arguments extension is enabled, then do
        // not consider it part of this argument.
        if (conf->extensions.expression_arguments && cp == '(')
        {
            fprintf(stderr, "[confetti.c] enter scan_argument 8\n");
            break;
            // fprintf(stderr, "[confetti.c] exit scan_argument 8\n");
        }

        // If the punctuator arguments extension is enabled, then check if
        // the current character is the start of one. If so, then do not
        // interpret it as part of this extension argument.
        if (conf->punctuators_count > 0)
        {
            fprintf(stderr, "[confetti.c] enter scan_argument 9\n");
            if (scan_punctuator_argument(conf, at, tok, cp))
            {
                fprintf(stderr, "[confetti.c] enter scan_argument 10\n");
                break;
                // fprintf(stderr, "[confetti.c] exit scan_argument 10\n");
            }
            // fprintf(stderr, "[confetti.c] exit scan_argument 9\n");
        }

        at += length;
        // fprintf(stderr, "[confetti.c] exit scan_argument 2\n");
    }

    fprintf(stderr, "[confetti.c] enter scan_argument 11\n");
    tok->lexeme = string - conf->string;
    tok->lexeme_length = at - string;
    tok->type = TOK_ARGUMENT;
    tok->flags = 0;
    tok->trim = 0;
    // fprintf(stderr, "[confetti.c] exit scan_argument 11\n");
    // fprintf(stderr, "[confetti.c] exit scan_argument 1\n");
}

static void scan_whitespace(conf_unit *conf, const char *string, token *tok)
{
    fprintf(stderr, "[confetti.c] enter scan_whitespace 1\n");
    assert(conf != NULL);
    assert(string != NULL);
    assert(tok != NULL);

    const char *at = string;
    for (;;)
    {
        fprintf(stderr, "[confetti.c] enter scan_whitespace 2\n");
        size_t length;
        const uchar cp = utf8decode(conf, at, &length);
        if (conf_uniflags(cp) & IS_SPACE_CHARACTER)
        {
            fprintf(stderr, "[confetti.c] enter scan_whitespace 3\n");
            at += length;
            continue;
            // fprintf(stderr, "[confetti.c] exit scan_whitespace 3\n");
        }
        break;
        // fprintf(stderr, "[confetti.c] exit scan_whitespace 2\n");
    }

    fprintf(stderr, "[confetti.c] enter scan_whitespace 4\n");
    tok->lexeme = string - conf->string;
    tok->lexeme_length = at - string;
    tok->type = TOK_WHITESPACE;
    tok->flags = 0;
    tok->trim = 0;
    // fprintf(stderr, "[confetti.c] exit scan_whitespace 4\n");
    // fprintf(stderr, "[confetti.c] exit scan_whitespace 1\n");
}

static void scan_single_line_comment(conf_unit *conf, const char *string, token *tok)
{
    fprintf(stderr, "[confetti.c] enter scan_single_line_comment 1\n");
    assert(conf != NULL);
    assert(string != NULL);
    assert(string[0] == '#' || (string[0] == '/' && string[1] == '/'));
    assert(tok != NULL);

    const char *at = string;
    for (;;)
    {
        fprintf(stderr, "[confetti.c] enter scan_single_line_comment 2\n");
        if (*at == '\0')
        {
            fprintf(stderr, "[confetti.c] enter scan_single_line_comment 3\n");
            break;
            // fprintf(stderr, "[confetti.c] exit scan_single_line_comment 3\n");
        }

        size_t length = 0;
        if (is_newline(conf, at, &length))
        {
            fprintf(stderr, "[confetti.c] enter scan_single_line_comment 4\n");
            break;
            // fprintf(stderr, "[confetti.c] exit scan_single_line_comment 4\n");
        }

        length = 0;
        const uchar cp = utf8decode(conf, at, &length);
        if (conf_uniflags(cp) & IS_FORBIDDEN_CHARACTER)
        {
            fprintf(stderr, "[confetti.c] enter scan_single_line_comment 5\n");
            die(conf, CONF_BAD_SYNTAX, at, "illegal character");
            // fprintf(stderr, "[confetti.c] exit scan_single_line_comment 5\n");
        }

        if ((conf_uniflags(cp) & IS_BIDI_CHARACTER) && !conf->options.allow_bidi)
        {
            fprintf(stderr, "[confetti.c] enter scan_single_line_comment 6\n");
            die(conf, CONF_BAD_SYNTAX, at, "illegal bidirectional character");
            // fprintf(stderr, "[confetti.c] exit scan_single_line_comment 6\n");
        }

        at += length;
        // fprintf(stderr, "[confetti.c] exit scan_single_line_comment 2\n");
    }

    fprintf(stderr, "[confetti.c] enter scan_single_line_comment 7\n");
    tok->lexeme = string - conf->string;
    tok->lexeme_length = at - string;
    tok->type = TOK_COMMENT;
    tok->flags = 0;
    tok->trim = 0;
    // fprintf(stderr, "[confetti.c] exit scan_single_line_comment 7\n");
    // fprintf(stderr, "[confetti.c] exit scan_single_line_comment 1\n");
}
static void scan_multi_line_comment(conf_unit *conf, const char *string, token *tok)
{
    fprintf(stderr, "[confetti.c] enter scan_multi_line_comment 1\n");
    assert(conf != NULL);
    assert(string != NULL);
    assert(string[0] == '/' && string[1] == '*');
    assert(tok != NULL);

    const char *at = string;
    // fprintf(stderr, "[confetti.c] exit scan_multi_line_comment 1\n");
    
    for (;;)
    {
        fprintf(stderr, "[confetti.c] enter scan_multi_line_comment 2\n");
        if (*at == '\0')
        {
            fprintf(stderr, "[confetti.c] enter scan_multi_line_comment 3\n");
            die(conf, CONF_BAD_SYNTAX, string, "unterminated multi-line comment");
            // fprintf(stderr, "[confetti.c] exit scan_multi_line_comment 3\n");
        }

        if (at[0] == '*' && at[1] == '/')
        {
            fprintf(stderr, "[confetti.c] enter scan_multi_line_comment 4\n");
            at += 2;
            break;
            // fprintf(stderr, "[confetti.c] exit scan_multi_line_comment 4\n");
        }

        size_t length = 0;
        const uchar cp = utf8decode(conf, at, &length);
        // fprintf(stderr, "[confetti.c] exit scan_multi_line_comment 2\n");
        
        if (conf_uniflags(cp) & IS_FORBIDDEN_CHARACTER)
        {
            fprintf(stderr, "[confetti.c] enter scan_multi_line_comment 5\n");
            die(conf, CONF_BAD_SYNTAX, at, "illegal character");
            // fprintf(stderr, "[confetti.c] exit scan_multi_line_comment 5\n");
        }

        if ((conf_uniflags(cp) & IS_BIDI_CHARACTER) && !conf->options.allow_bidi)
        {
            fprintf(stderr, "[confetti.c] enter scan_multi_line_comment 6\n");
            die(conf, CONF_BAD_SYNTAX, at, "illegal bidirectional character");
            // fprintf(stderr, "[confetti.c] exit scan_multi_line_comment 6\n");
        }

        fprintf(stderr, "[confetti.c] enter scan_multi_line_comment 7\n");
        at += length;
        // fprintf(stderr, "[confetti.c] exit scan_multi_line_comment 7\n");
    }

    fprintf(stderr, "[confetti.c] enter scan_multi_line_comment 8\n");
    tok->lexeme = string - conf->string;
    tok->lexeme_length = at - string;
    tok->type = TOK_COMMENT;
    tok->flags = 0;
    tok->trim = 0;
    // fprintf(stderr, "[confetti.c] exit scan_multi_line_comment 8\n");
}

static void scan_token(conf_unit *conf, const char *string, token *tok)
{
    fprintf(stderr, "[confetti.c] enter scan_token 1\n");
    assert(conf != NULL);
    assert(string != NULL);
    assert(tok != NULL);
    // fprintf(stderr, "[confetti.c] exit scan_token 1\n");

    if (string[0] == '#')
    {
        fprintf(stderr, "[confetti.c] enter scan_token 2\n");
        scan_single_line_comment(conf, string, tok);
        return;
        // fprintf(stderr, "[confetti.c] exit scan_token 2\n");
    }

    if (conf->extensions.c_style_comments)
    {
        fprintf(stderr, "[confetti.c] enter scan_token 3\n");
        // Check for a C style single line comment, e.g. "// this is a commment"
        if (string[0] == '/' && string[1] == '/')
        {
            fprintf(stderr, "[confetti.c] enter scan_token 4\n");
            scan_single_line_comment(conf, string, tok);
            return;
            // fprintf(stderr, "[confetti.c] exit scan_token 4\n");
        }

        // Check for a C style multi-line comment, e.g. "/* this is a commment */"
        if (string[0] == '/' && string[1] == '*')
        {
            fprintf(stderr, "[confetti.c] enter scan_token 5\n");
            scan_multi_line_comment(conf, string, tok);
            return;
            // fprintf(stderr, "[confetti.c] exit scan_token 5\n");
        }
        // fprintf(stderr, "[confetti.c] exit scan_token 3\n");
    }

    if (is_newline(conf, string, &tok->lexeme_length))
    {
        fprintf(stderr, "[confetti.c] enter scan_token 6\n");
        tok->type = TOK_NEWLINE;
        tok->lexeme = string - conf->string;
        tok->flags = 0;
        tok->trim = 0;
        return;
        // fprintf(stderr, "[confetti.c] exit scan_token 6\n");
    }

    fprintf(stderr, "[confetti.c] enter scan_token 7\n");
    const uchar cp = utf8decode(conf, string, NULL);
    // fprintf(stderr, "[confetti.c] exit scan_token 7\n");
    
    if (conf_uniflags(cp) & IS_SPACE_CHARACTER)
    {
        fprintf(stderr, "[confetti.c] enter scan_token 8\n");
        scan_whitespace(conf, string, tok);
        return;
        // fprintf(stderr, "[confetti.c] exit scan_token 8\n");
    }

    if ((conf_uniflags(cp) & IS_BIDI_CHARACTER) && !conf->options.allow_bidi)
    {
        fprintf(stderr, "[confetti.c] enter scan_token 9\n");
        die(conf, CONF_BAD_SYNTAX, string, "illegal bidirectional character");
        // fprintf(stderr, "[confetti.c] exit scan_token 9\n");
    }

    if (conf->punctuators_count > 0)
    {
        fprintf(stderr, "[confetti.c] enter scan_token 10\n");
        if (scan_punctuator_argument(conf, string, tok, cp))
        {
            return;
        }
        // fprintf(stderr, "[confetti.c] exit scan_token 10\n");
    }

    if (conf->extensions.expression_arguments)
    {
        fprintf(stderr, "[confetti.c] enter scan_token 11\n");
        if (string[0] == '(')
        {
            fprintf(stderr, "[confetti.c] enter scan_token 12\n");
            scan_expression_argument(conf, string, tok);
            return;
            // fprintf(stderr, "[confetti.c] exit scan_token 12\n");
        }
        // fprintf(stderr, "[confetti.c] exit scan_token 11\n");
    }

    if ((string[0] == '{') || (string[0] == '}'))
    {
        fprintf(stderr, "[confetti.c] enter scan_token 13\n");
        tok->type = (token_type)string[0];
        tok->lexeme = string - conf->string;
        tok->lexeme_length = 1;
        tok->flags = 0;
        tok->trim = 0;
        return;
        // fprintf(stderr, "[confetti.c] exit scan_token 13\n");
    }
    
    if (string[0] == '"')
    {
        fprintf(stderr, "[confetti.c] enter scan_token 14\n");
        if ((string[1] == '"') && (string[2] == '"'))
        {
            fprintf(stderr, "[confetti.c] enter scan_token 15\n");
            scan_triple_quoted_argument(conf, string, tok);
            // fprintf(stderr, "[confetti.c] exit scan_token 15\n");
        }
        else
        {
            fprintf(stderr, "[confetti.c] enter scan_token 16\n");
            scan_single_quoted_argument(conf, string, tok);
            // fprintf(stderr, "[confetti.c] exit scan_token 16\n");
        }
        return;
        // fprintf(stderr, "[confetti.c] exit scan_token 14\n");
    }

    if (string[0] == ';')
    {
        fprintf(stderr, "[confetti.c] enter scan_token 17\n");
        tok->type = TOK_SEMICOLON;
        tok->lexeme = string - conf->string;
        tok->lexeme_length = 1;
        tok->flags = 0;
        tok->trim = 0;
        return;
        // fprintf(stderr, "[confetti.c] exit scan_token 17\n");
    }

    if (string[0] == '\\')
    {
        fprintf(stderr, "[confetti.c] enter scan_token 18\n");
        size_t length;
        if (is_newline(conf, &string[1], &length))
        {
            fprintf(stderr, "[confetti.c] enter scan_token 19\n");
            tok->type = TOK_CONTINUATION;
            tok->lexeme = string - conf->string;
            tok->lexeme_length = length + 1;
            tok->flags = 0;
            tok->trim = 0;
            return;
            // fprintf(stderr, "[confetti.c] exit scan_token 19\n");
        }
        // fprintf(stderr, "[confetti.c] exit scan_token 18\n");
    }

    if (conf_uniflags(cp) & IS_ARGUMENT_CHARACTER)
    {
        fprintf(stderr, "[confetti.c] enter scan_token 20\n");
        scan_argument(conf, string, tok);
        return;
        // fprintf(stderr, "[confetti.c] exit scan_token 20\n");
    }

    // For compatibility with source code editing tools that add end-of-file markers, if the last character
    // of the compilation unit is a Control-Z character (U+001A), this character is deleted.
    if (string[0] == 0x1A && string[1] == '\0')
    {
        fprintf(stderr, "[confetti.c] enter scan_token 21\n");
        tok->type = TOK_EOF;
        tok->lexeme = string - conf->string;
        tok->lexeme_length = 0;
        tok->flags = 0;
        tok->trim = 0;
        return;
        // fprintf(stderr, "[confetti.c] exit scan_token 21\n");
    }

    if (cp == 0x0)
    {
        fprintf(stderr, "[confetti.c] enter scan_token 22\n");
        tok->type = TOK_EOF;
        tok->lexeme = string - conf->string;
        tok->lexeme_length = 0;
        tok->flags = 0;
        tok->trim = 0;
        return;
        // fprintf(stderr, "[confetti.c] exit scan_token 22\n");
    }
    
    fprintf(stderr, "[confetti.c] enter scan_token 23\n");
    die(conf, CONF_BAD_SYNTAX, string, "illegal character U+%04X", cp);
    // fprintf(stderr, "[confetti.c] exit scan_token 23\n");
}

static void record_comment(conf_unit *unit, const conf_comment *data)
{
    fprintf(stderr, "[confetti.c] enter record_comment 1\n");
    struct comment *comment = new(unit, sizeof(comment[0]));
    if (comment == NULL)
    {
        fprintf(stderr, "[confetti.c] enter record_comment 2\n");
        die(unit, CONF_OUT_OF_MEMORY, unit->needle, "memory allocation failed");
        // fprintf(stderr, "[confetti.c] exit record_comment 2\n");
    }
    comment->data.offset = data->offset;
    comment->data.length = data->length;
    comment->next = NULL;
    // fprintf(stderr, "[confetti.c] exit record_comment 1\n");

    if (unit->comment_head == NULL)
    {
        fprintf(stderr, "[confetti.c] enter record_comment 3\n");
        assert(unit->comment_tail == NULL);
        unit->comment_head = comment;
        unit->comment_tail = comment;
        // fprintf(stderr, "[confetti.c] exit record_comment 3\n");
    }
    else
    {
        fprintf(stderr, "[confetti.c] enter record_comment 4\n");
        assert(unit->comment_tail != NULL);
        unit->comment_tail->next = comment;
        unit->comment_tail = comment;
        // fprintf(stderr, "[confetti.c] exit record_comment 4\n");
    }
    
    fprintf(stderr, "[confetti.c] enter record_comment 5\n");
    unit->comments_count += 1;
    // fprintf(stderr, "[confetti.c] exit record_comment 5\n");
}

static token_type peek(conf_unit *unit, token *tok)
{
    fprintf(stderr, "[confetti.c] enter peek 1\n");
    assert(unit != NULL);
    assert(tok != NULL);
    // fprintf(stderr, "[confetti.c] exit peek 1\n");

    if (unit->peek.type == TOK_INVALID)
    {
        fprintf(stderr, "[confetti.c] enter peek 2\n");
        for (;;)
        {
            fprintf(stderr, "[confetti.c] enter peek 3\n");
            scan_token(unit, unit->needle, &unit->peek);
            // fprintf(stderr, "[confetti.c] exit peek 3\n");
            
            if (unit->peek.type == TOK_WHITESPACE)
            {
                fprintf(stderr, "[confetti.c] enter peek 4\n");
                unit->needle += unit->peek.lexeme_length;
                // fprintf(stderr, "[confetti.c] exit peek 4\n");
                continue;
            }
            else if (unit->peek.type == TOK_COMMENT)
            {
                fprintf(stderr, "[confetti.c] enter peek 5\n");
                // Prevent the same comment from being reported twice.
                // Comments might be parsed twice when the parser
                // is rewound, but they should only be reported
                // once to the user.
                if (unit->comment_processed <= unit->peek.lexeme)
                {
                    fprintf(stderr, "[confetti.c] enter peek 6\n");
                    const conf_comment comment = {
                        .offset = unit->peek.lexeme,
                        .length = unit->peek.lexeme_length,
                    };
                    if (unit->walk == NULL)
                    {
                        fprintf(stderr, "[confetti.c] enter peek 7\n");
                        record_comment(unit, &comment);
                        // fprintf(stderr, "[confetti.c] exit peek 7\n");
                    }
                    else if (unit->walk(unit->options.user_data, CONF_COMMENT, 0, NULL, &comment) != 0)
                    {
                        fprintf(stderr, "[confetti.c] enter peek 8\n");
                        die(unit, CONF_USER_ABORTED, unit->needle, "user aborted");
                        // fprintf(stderr, "[confetti.c] exit peek 8\n");
                    }
                    unit->comment_processed = comment.offset + comment.length;
                    // fprintf(stderr, "[confetti.c] exit peek 6\n");
                }
                unit->needle += unit->peek.lexeme_length;
                // fprintf(stderr, "[confetti.c] exit peek 5\n");
                continue;
            }
            break;
        }
        // fprintf(stderr, "[confetti.c] exit peek 2\n");
    }
    
    fprintf(stderr, "[confetti.c] enter peek 9\n");
    *tok = unit->peek;
    return unit->peek.type;
    // fprintf(stderr, "[confetti.c] exit peek 9\n");
}

static token_type eat(conf_unit *conf, token *tok)
{
    fprintf(stderr, "[confetti.c] enter eat 1\n");
    assert(conf != NULL);
    assert(tok != NULL);

    peek(conf, tok);
    conf->needle += tok->lexeme_length;
    conf->peek.type = TOK_INVALID;
    return tok->type;
    // fprintf(stderr, "[confetti.c] exit eat 1\n");
}

static size_t copy_token_to_buffer(conf_unit *conf, char *dest, const token *tok)
{
    fprintf(stderr, "[confetti.c] enter copy_token_to_buffer 1\n");
    assert(conf != NULL);
    assert(tok != NULL);

    const char *stop_offset = &conf->string[tok->lexeme + tok->lexeme_length];
    const char *offset = &conf->string[tok->lexeme];
    size_t nbytes = 0;

    // Discard the N surrounding characters (e.g. quotes in a quoted literal).
    offset += tok->trim;
    stop_offset -= tok->trim;
    // fprintf(stderr, "[confetti.c] exit copy_token_to_buffer 1\n");

    while (offset < stop_offset)
    {
        fprintf(stderr, "[confetti.c] enter copy_token_to_buffer 2\n");
        if (*offset == '\\')
        {
            fprintf(stderr, "[confetti.c] enter copy_token_to_buffer 3\n");
            offset += 1; // skip the backslash

            // New lines after a backslash are ignored in single quoted arguments.
            if (tok->flags & CONF_QUOTED)
            {
                fprintf(stderr, "[confetti.c] enter copy_token_to_buffer 4\n");
                size_t length;
                if (is_newline(conf, offset, &length))
                {
                    fprintf(stderr, "[confetti.c] enter copy_token_to_buffer 5\n");
                    offset += length;
                    // fprintf(stderr, "[confetti.c] exit copy_token_to_buffer 5\n");
                    continue;
                }
                // fprintf(stderr, "[confetti.c] exit copy_token_to_buffer 4\n");
            }
            // fprintf(stderr, "[confetti.c] exit copy_token_to_buffer 3\n");
        }

        size_t length = 0;
        utf8decode(conf, offset, &length);
        if (dest != NULL)
        {
            fprintf(stderr, "[confetti.c] enter copy_token_to_buffer 6\n");
            memcpy(dest, offset, length);
            dest += length;
            // fprintf(stderr, "[confetti.c] exit copy_token_to_buffer 6\n");
        }

        offset += length;
        nbytes += length;
        // fprintf(stderr, "[confetti.c] exit copy_token_to_buffer 2\n");
    }

    fprintf(stderr, "[confetti.c] enter copy_token_to_buffer 7\n");
    return nbytes;
    // fprintf(stderr, "[confetti.c] exit copy_token_to_buffer 7\n");
}

//
// Parsing directives is a two step process:
//
//   (1) arguments are first scanned and counted, additionally the total number
//       of characters to represent the arguments is also counted
//
//   (2) arrays large enough to accommodate the arguments and characters is reserved
//       and arguments are re-scanned and their data is copied to these buffer
//
// The point of step #1 is to reduce the number of overall allocations and to avoid the
// use of dynamic array (scanning a quoted literal is cheaper than allocating memory).
//

static void parse_directive(conf_unit *conf, conf_directive *parent, int depth)
{
    fprintf(stderr, "[confetti.c] enter parse_directive 1\n");
    assert(conf != NULL);
    assert(depth >= 0);

    token tok;

    // (1) figure out how much memory is needed for the arguments

    const token saved_peek = conf->peek; // save parser unit
    const char *saved_needle = conf->needle;
    // fprintf(stderr, "[confetti.c] exit parse_directive 1\n");

    long argument_count = 0;
    long buffer_length = 0;
    for (;;)
    {
        fprintf(stderr, "[confetti.c] enter parse_directive 2\n");
        peek(conf, &tok);
        // fprintf(stderr, "[confetti.c] exit parse_directive 2\n");
        
        if (tok.type == TOK_ARGUMENT)
        {
            fprintf(stderr, "[confetti.c] enter parse_directive 3\n");
            argument_count += 1;
            buffer_length += copy_token_to_buffer(conf, NULL, &tok) + 1; // +1 for null byte
            eat(conf, &tok);
            // fprintf(stderr, "[confetti.c] exit parse_directive 3\n");
        }
        else if (tok.type == TOK_CONTINUATION)
        {
            fprintf(stderr, "[confetti.c] enter parse_directive 4\n");
            eat(conf, &tok);
            // fprintf(stderr, "[confetti.c] exit parse_directive 4\n");
        }
        else
        {
            break;
        }
    }
    
    fprintf(stderr, "[confetti.c] enter parse_directive 5\n");
    conf->peek = saved_peek; // rewind parser unit
    conf->needle = saved_needle;
    // fprintf(stderr, "[confetti.c] exit parse_directive 5\n");

    // (2) allocate storage for the arguments and copy the data to it

    const size_t size = sizeof(conf_directive) + (size_t)buffer_length;
    conf_directive *dir = zero_new(conf, size);
    if (dir == NULL)
    {
        fprintf(stderr, "[confetti.c] enter parse_directive 6\n");
        die(conf, CONF_OUT_OF_MEMORY, conf->needle, "memory allocation failed");
        // fprintf(stderr, "[confetti.c] exit parse_directive 6\n");
    }
    dir->buffer_length = buffer_length;

    const long argc = argument_count;
    conf_argument *argv = new(conf, sizeof(argv[0]) * argc);
    if (argv == NULL)
    {
        fprintf(stderr, "[confetti.c] enter parse_directive 7\n");
        delete(conf, dir, size);
        die(conf, CONF_OUT_OF_MEMORY, conf->needle, "memory allocation failed");
        // fprintf(stderr, "[confetti.c] exit parse_directive 7\n");
    }
    
    fprintf(stderr, "[confetti.c] enter parse_directive 8\n");
    dir->arguments = argv;
    dir->arguments_count = argc;
    // fprintf(stderr, "[confetti.c] exit parse_directive 8\n");

    char *buffer = dir->buffer;
    argument_count = 0;
    for (;;)
    {
        fprintf(stderr, "[confetti.c] enter parse_directive 9\n");
        peek(conf, &tok);
        // fprintf(stderr, "[confetti.c] exit parse_directive 9\n");
        
        if (tok.type == TOK_ARGUMENT)
        {
            fprintf(stderr, "[confetti.c] enter parse_directive 10\n");
            conf_argument *arg = &argv[argument_count++];
            arg->lexeme_offset = tok.lexeme;
            arg->lexeme_length = tok.lexeme_length;
            arg->value = buffer;
            arg->is_expression = (tok.flags & CONF_EXPRESSION) ? true : false;
            buffer += copy_token_to_buffer(conf, buffer, &tok) + 1; // +1 for null byte
            eat(conf, &tok);
            // fprintf(stderr, "[confetti.c] exit parse_directive 10\n");
        }
        else if (tok.type == TOK_CONTINUATION)
        {
            fprintf(stderr, "[confetti.c] enter parse_directive 11\n");
            eat(conf, &tok);
            // fprintf(stderr, "[confetti.c] exit parse_directive 11\n");
        }
        else
        {
            break;
        }
    }

    // Link this directive with its parent directive.
    if (parent->subdir_head == NULL)
    {
        fprintf(stderr, "[confetti.c] enter parse_directive 12\n");
        assert(parent->subdir_tail == NULL);
        parent->subdir_head = dir;
        parent->subdir_tail = dir;
        // fprintf(stderr, "[confetti.c] exit parse_directive 12\n");
    }
    else
    {
        fprintf(stderr, "[confetti.c] enter parse_directive 13\n");
        assert(parent->subdir_tail != NULL);
        parent->subdir_tail->next = dir;
        parent->subdir_tail = dir;
        // fprintf(stderr, "[confetti.c] exit parse_directive 13\n");
    }
    
    // Check for an optional, terminating semicolon.
    if (tok.type == ';')
    {
        fprintf(stderr, "[confetti.c] enter parse_directive 14\n");
        eat(conf, &tok); // consume ';'
        return;
        // fprintf(stderr, "[confetti.c] exit parse_directive 14\n");
    }

    // Consume as many new lines as possible.
    while (tok.type == TOK_NEWLINE)
    {
        fprintf(stderr, "[confetti.c] enter parse_directive 15\n");
        eat(conf, &tok);
        peek(conf, &tok);
        // fprintf(stderr, "[confetti.c] exit parse_directive 15\n");
    }

    // Check for an optional subdirective.
    if (tok.type == '{')
    {
        fprintf(stderr, "[confetti.c] enter parse_directive 16\n");
        eat(conf, &tok); // consume '{'
        parse_body(conf, dir, depth + 1);
        // fprintf(stderr, "[confetti.c] exit parse_directive 16\n");

        fprintf(stderr, "[confetti.c] enter parse_directive 17\n");
        peek(conf, &tok);
        // fprintf(stderr, "[confetti.c] exit parse_directive 17\n");
        
        if (tok.type == '}')
        {
            fprintf(stderr, "[confetti.c] enter parse_directive 18\n");
            eat(conf, &tok); // consume '}'
            peek(conf, &tok);
            // fprintf(stderr, "[confetti.c] exit parse_directive 18\n");
        }
        else
        {
            fprintf(stderr, "[confetti.c] enter parse_directive 19\n");
            die(conf, CONF_BAD_SYNTAX, conf->needle, "expected '}'");
            // fprintf(stderr, "[confetti.c] exit parse_directive 19\n");
        }

        // Check for an optional, terminating semicolon.
        if (tok.type == ';')
        {
            fprintf(stderr, "[confetti.c] enter parse_directive 20\n");
            eat(conf, &tok); // consume ';'
            // fprintf(stderr, "[confetti.c] exit parse_directive 20\n");
        }
    }
}

static void walk_directive(conf_unit *conf, int depth)
{
    fprintf(stderr, "[confetti.c] enter walk_directive 1\n");
    assert(conf != NULL);
    assert(depth >= 0);

    token tok;

    // (1) figure out how much memory is needed for the arguments

    const token saved_peek = conf->peek; // save parser state
    const char *saved_needle = conf->needle;
    // fprintf(stderr, "[confetti.c] exit walk_directive 1\n");

    int args_count = 0;
    int buffer_length = 0;
    for (;;)
    {
        fprintf(stderr, "[confetti.c] enter walk_directive 2\n");
        peek(conf, &tok);
        // fprintf(stderr, "[confetti.c] exit walk_directive 2\n");
        
        if (tok.type == TOK_ARGUMENT)
        {
            fprintf(stderr, "[confetti.c] enter walk_directive 3\n");
            args_count += 1;
            buffer_length += copy_token_to_buffer(conf, NULL, &tok) + 1; // +1 for null byte
            eat(conf, &tok);
            // fprintf(stderr, "[confetti.c] exit walk_directive 3\n");
        }
        else if (tok.type == TOK_CONTINUATION)
        {
            fprintf(stderr, "[confetti.c] enter walk_directive 4\n");
            eat(conf, &tok);
            // fprintf(stderr, "[confetti.c] exit walk_directive 4\n");
        }
        else
        {
            break;
        }
    }
    
    fprintf(stderr, "[confetti.c] enter walk_directive 5\n");
    conf->peek = saved_peek; // rewind parser state
    conf->needle = saved_needle;
    // fprintf(stderr, "[confetti.c] exit walk_directive 5\n");

    // (2) allocate storage for the arguments and copy the data to it

    char *args_buffer = zero_new(conf, buffer_length);
    if (args_buffer == NULL)
    {
        fprintf(stderr, "[confetti.c] enter walk_directive 6\n");
        die(conf, CONF_OUT_OF_MEMORY, conf->needle, "memory allocation failed");
        // fprintf(stderr, "[confetti.c] exit walk_directive 6\n");
    }

    const int argc = args_count;
    struct conf_argument *argv = new(conf, argc * sizeof(argv[0]));
    if (argv == NULL)
    {
        fprintf(stderr, "[confetti.c] enter walk_directive 7\n");
        delete(conf, args_buffer, buffer_length);
        die(conf, CONF_OUT_OF_MEMORY, conf->needle, "memory allocation failed");
        // fprintf(stderr, "[confetti.c] exit walk_directive 7\n");
    }

    char *buffer = args_buffer;
    args_count = 0;
    for (;;)
    {
        fprintf(stderr, "[confetti.c] enter walk_directive 8\n");
        peek(conf, &tok);
        // fprintf(stderr, "[confetti.c] exit walk_directive 8\n");
        
        if (tok.type == TOK_ARGUMENT)
        {
            fprintf(stderr, "[confetti.c] enter walk_directive 9\n");
            conf_argument *arg = &argv[args_count++];
            arg->lexeme_offset = tok.lexeme;
            arg->lexeme_length = tok.lexeme_length;
            arg->value = buffer;
            arg->is_expression = (tok.flags & CONF_EXPRESSION) ? true : false;
            buffer += copy_token_to_buffer(conf, buffer, &tok) + 1; // +1 for null byte
            eat(conf, &tok);
            // fprintf(stderr, "[confetti.c] exit walk_directive 9\n");
        }
        else if (tok.type == TOK_CONTINUATION)
        {
            fprintf(stderr, "[confetti.c] enter walk_directive 10\n");
            eat(conf, &tok);
            // fprintf(stderr, "[confetti.c] exit walk_directive 10\n");
        }
        else
        {
            break;
        }
    }

    fprintf(stderr, "[confetti.c] enter walk_directive 11\n");
    int r = conf->walk(conf->options.user_data, CONF_DIRECTIVE, argc, argv, NULL);
    delete(conf, argv, argc * sizeof(argv[0]));
    delete(conf, args_buffer, buffer_length);
    // fprintf(stderr, "[confetti.c] exit walk_directive 11\n");
    
    if (r != 0)
    {
        fprintf(stderr, "[confetti.c] enter walk_directive 12\n");
        die(conf, CONF_USER_ABORTED, conf->needle, "user aborted");
        // fprintf(stderr, "[confetti.c] exit walk_directive 12\n");
    }

    // Check for an optional, terminating semicolon.
    if (tok.type == ';')
    {
        fprintf(stderr, "[confetti.c] enter walk_directive 13\n");
        eat(conf, &tok); // consume ';'
        return;
        // fprintf(stderr, "[confetti.c] exit walk_directive 13\n");
    }

    // Consume as many new lines as possible.
    while (tok.type == TOK_NEWLINE)
    {
        fprintf(stderr, "[confetti.c] enter walk_directive 14\n");
        eat(conf, &tok);
        peek(conf, &tok);
        // fprintf(stderr, "[confetti.c] exit walk_directive 14\n");
    }

    // Check for an optional subdirective.
    if (tok.type == '{')
    {
        fprintf(stderr, "[confetti.c] enter walk_directive 15\n");
        eat(conf, &tok); // consume '{'
        // fprintf(stderr, "[confetti.c] exit walk_directive 15\n");

        fprintf(stderr, "[confetti.c] enter walk_directive 16\n");
        r = conf->walk(conf->options.user_data, CONF_BLOCK_ENTER, 0, NULL, NULL);
        // fprintf(stderr, "[confetti.c] exit walk_directive 16\n");
        
        if (r != 0)
        {
            fprintf(stderr, "[confetti.c] enter walk_directive 17\n");
            die(conf, CONF_USER_ABORTED, conf->needle, "user aborted");
            // fprintf(stderr, "[confetti.c] exit walk_directive 17\n");
        }

        fprintf(stderr, "[confetti.c] enter walk_directive 18\n");
        parse_body(conf, NULL, depth + 1);
        // fprintf(stderr, "[confetti.c] exit walk_directive 18\n");

        fprintf(stderr, "[confetti.c] enter walk_directive 19\n");
        peek(conf, &tok);
        // fprintf(stderr, "[confetti.c] exit walk_directive 19\n");
        
        if (tok.type == '}')
        {
            fprintf(stderr, "[confetti.c] enter walk_directive 20\n");
            eat(conf, &tok); // consume '}'
            peek(conf, &tok);
            // fprintf(stderr, "[confetti.c] exit walk_directive 20\n");

            fprintf(stderr, "[confetti.c] enter walk_directive 21\n");
            r = conf->walk(conf->options.user_data, CONF_BLOCK_LEAVE, 0, NULL, NULL);
            // fprintf(stderr, "[confetti.c] exit walk_directive 21\n");
            
            if (r != 0)
            {
                fprintf(stderr, "[confetti.c] enter walk_directive 22\n");
                die(conf, CONF_USER_ABORTED, conf->needle, "user aborted");
                // fprintf(stderr, "[confetti.c] exit walk_directive 22\n");
            }
        }
        else
        {
            fprintf(stderr, "[confetti.c] enter walk_directive 23\n");
            die(conf, CONF_BAD_SYNTAX, conf->needle, "expected '}'");
            // fprintf(stderr, "[confetti.c] exit walk_directive 23\n");
        }

        // Check for a terminating semicolon.
        if (tok.type == ';')
        {
            fprintf(stderr, "[confetti.c] enter walk_directive 24\n");
            eat(conf, &tok); // consume ';'
            // fprintf(stderr, "[confetti.c] exit walk_directive 24\n");
        }
    }
}

// Directive lists are parsed in a single pass and collected into a linked list.
// After parsing is complete and the linked list is fully constructed, then the
// list items are copied to an array for O(1) access.
static void parse_body(conf_unit *conf, conf_directive *parent, int depth)
{
    fprintf(stderr, "[confetti.c] enter parse_body 1\n");
    assert(conf != NULL);
    assert(depth >= 0);
    // fprintf(stderr, "[confetti.c] exit parse_body 1\n");

    // Check if the maxmimum nesting depth has been exceeded.
    if (depth >= conf->options.max_depth)
    {
        fprintf(stderr, "[confetti.c] enter parse_body 2\n");
        die(conf, CONF_MAX_DEPTH_EXCEEDED, conf->needle, "maximum nesting depth exceeded");
        // fprintf(stderr, "[confetti.c] exit parse_body 2\n");
    }

    // Parse all subdirectives into a linked list.
    long subdirs_count = 0;
    for (;;)
    {
        fprintf(stderr, "[confetti.c] enter parse_body 3\n");
        token tok;
        if (peek(conf, &tok) == TOK_EOF)
        {
            break;
        }
        // fprintf(stderr, "[confetti.c] exit parse_body 3\n");

        if (tok.type == TOK_ARGUMENT)
        {
            fprintf(stderr, "[confetti.c] enter parse_body 4\n");
            if (parent == NULL)
            {
                fprintf(stderr, "[confetti.c] enter parse_body 5\n");
                walk_directive(conf, depth);
                assert(conf->walk != NULL);
                // fprintf(stderr, "[confetti.c] exit parse_body 5\n");
            }
            else
            {
                fprintf(stderr, "[confetti.c] enter parse_body 6\n");
                parse_directive(conf, parent, depth);
                subdirs_count += 1;
                assert(conf->walk == NULL);
                // fprintf(stderr, "[confetti.c] exit parse_body 6\n");
            }
            // fprintf(stderr, "[confetti.c] exit parse_body 4\n");
            continue;
        }

        if (tok.type == TOK_NEWLINE)
        {
            fprintf(stderr, "[confetti.c] enter parse_body 7\n");
            eat(conf, &tok);
            // fprintf(stderr, "[confetti.c] exit parse_body 7\n");
            continue;
        }

        // Check for a subdirective terminator.
        // This will be handled by the caller.
        if (tok.type == '}')
        {
            break;
        }

        if (tok.type == TOK_CONTINUATION)
        {
            fprintf(stderr, "[confetti.c] enter parse_body 8\n");
            die(conf, CONF_BAD_SYNTAX, conf->needle, "unexpected line continuation");
            // fprintf(stderr, "[confetti.c] exit parse_body 8\n");
        }

        fprintf(stderr, "[confetti.c] enter parse_body 9\n");
        assert((tok.type == ';') || (tok.type == '{'));
        die(conf, CONF_BAD_SYNTAX, conf->needle, "unexpected '%c'", tok.type);
        // fprintf(stderr, "[confetti.c] exit parse_body 9\n");
    }

    if (subdirs_count > 0)
    {
        fprintf(stderr, "[confetti.c] enter parse_body 10\n");
        // Allocate an array large enough to accomidate the subdirectives for O(1) access.
        conf_directive **subdirs = new(conf, sizeof(subdirs[0]) * subdirs_count);
        if (subdirs == NULL)
        {
            fprintf(stderr, "[confetti.c] enter parse_body 11\n");
            die(conf, CONF_OUT_OF_MEMORY, conf->needle, "memory allocation failed");
            // fprintf(stderr, "[confetti.c] exit parse_body 11\n");
        }
        
        // Copy subdirective pointers to the array.
        long index = 0;
        for (conf_directive *curr = parent->subdir_head; curr != NULL; curr = curr->next)
        {
            fprintf(stderr, "[confetti.c] enter parse_body 12\n");
            subdirs[index] = curr;
            index += 1;
            // fprintf(stderr, "[confetti.c] exit parse_body 12\n");
        }
        parent->subdir = subdirs;
        parent->subdir_count = subdirs_count;
        // fprintf(stderr, "[confetti.c] exit parse_body 10\n");
    }
}

const conf_directive *conf_get_directive(const conf_directive *dir, long index)
{
    fprintf(stderr, "[confetti.c] enter conf_get_directive 1\n");
    if (dir == NULL)
    {
        fprintf(stderr, "[confetti.c] enter conf_get_directive 2\n");
        return NULL;
        // fprintf(stderr, "[confetti.c] exit conf_get_directive 2\n");
    }
    if (index < 0 || index >= dir->subdir_count)
    {
        fprintf(stderr, "[confetti.c] enter conf_get_directive 3\n");
        return NULL;
        // fprintf(stderr, "[confetti.c] exit conf_get_directive 3\n");
    }
    return dir->subdir[index];
    // fprintf(stderr, "[confetti.c] exit conf_get_directive 1\n");
}

long conf_get_directive_count(const conf_directive *dir)
{
    fprintf(stderr, "[confetti.c] enter conf_get_directive_count 1\n");
    if (dir == NULL)
    {
        fprintf(stderr, "[confetti.c] enter conf_get_directive_count 2\n");
        return 0;
        // fprintf(stderr, "[confetti.c] exit conf_get_directive_count 2\n");
    }
    return dir->subdir_count;
    // fprintf(stderr, "[confetti.c] exit conf_get_directive_count 1\n");
}

const conf_directive *conf_get_root(const conf_unit *unit)
{
    fprintf(stderr, "[confetti.c] enter conf_get_root 1\n");
    if (unit == NULL)
    {
        fprintf(stderr, "[confetti.c] enter conf_get_root 2\n");
        return NULL;
        // fprintf(stderr, "[confetti.c] exit conf_get_root 2\n");
    }
    return unit->root;
    // fprintf(stderr, "[confetti.c] exit conf_get_root 1\n");
}

const conf_argument *conf_get_argument(const conf_directive *dir, long index)
{
    fprintf(stderr, "[confetti.c] enter conf_get_argument 1\n");
    if (dir == NULL)
    {
        fprintf(stderr, "[confetti.c] enter conf_get_argument 2\n");
        return NULL;
        // fprintf(stderr, "[confetti.c] exit conf_get_argument 2\n");
    }
    if (index < 0 || index >= dir->arguments_count)
    {
        fprintf(stderr, "[confetti.c] enter conf_get_argument 3\n");
        return NULL;
        // fprintf(stderr, "[confetti.c] exit conf_get_argument 3\n");
    }
    return &dir->arguments[index];
    // fprintf(stderr, "[confetti.c] exit conf_get_argument 1\n");
}

long conf_get_argument_count(const conf_directive *dir)
{
    fprintf(stderr, "[confetti.c] enter conf_get_argument_count 1\n");
    if (dir == NULL)
    {
        fprintf(stderr, "[confetti.c] enter conf_get_argument_count 2\n");
        return 0;
        // fprintf(stderr, "[confetti.c] exit conf_get_argument_count 2\n");
    }
    return dir->arguments_count;
    // fprintf(stderr, "[confetti.c] exit conf_get_argument_count 1\n");
}

const conf_comment *conf_get_comment(const conf_unit *unit, long index)
{
    fprintf(stderr, "[confetti.c] enter conf_get_comment 1\n");
    if (unit == NULL)
    {
        fprintf(stderr, "[confetti.c] enter conf_get_comment 2\n");
        return NULL;
        // fprintf(stderr, "[confetti.c] exit conf_get_comment 2\n");
    }
    if (index < 0 || index >= unit->comments_count)
    {
        fprintf(stderr, "[confetti.c] enter conf_get_comment 3\n");
        return NULL;
        // fprintf(stderr, "[confetti.c] exit conf_get_comment 3\n");
    }
    return &unit->comments[index]->data;
    // fprintf(stderr, "[confetti.c] exit conf_get_comment 1\n");
}

long conf_get_comment_count(const conf_unit *unit)
{
    fprintf(stderr, "[confetti.c] enter conf_get_comment_count 1\n");
    if (unit == NULL)
    {
        fprintf(stderr, "[confetti.c] enter conf_get_comment_count 2\n");
        return 0;
        // fprintf(stderr, "[confetti.c] exit conf_get_comment_count 2\n");
    }
    return unit->comments_count;
    // fprintf(stderr, "[confetti.c] exit conf_get_comment_count 1\n");
}

static void free_directive(conf_unit *conf, conf_directive *dir)
{
    fprintf(stderr, "\n");
    conf_directive *subdir = dir->subdir_head;
    while (subdir != NULL)
    {
        fprintf(stderr, "[confetti.c] enter free_directive 2\n");
        conf_directive *next = subdir->next;
        free_directive(conf, subdir);
        subdir = next;
        // fprintf(stderr, "[confetti.c] exit free_directive 2\n");
    }
    
    if (dir->subdir_count > 0)
    {
        fprintf(stderr, "[confetti.c] enter free_directive 3\n");
        delete(conf, dir->subdir, sizeof(dir->subdir[0]) * dir->subdir_count);
        // fprintf(stderr, "[confetti.c] exit free_directive 3\n");
    }
    
    fprintf(stderr, "[confetti.c] enter free_directive 4\n");
    assert(dir->arguments_count > 0);
    delete(conf, dir->arguments, sizeof(dir->arguments[0]) * dir->arguments_count);
    delete(conf, dir, sizeof(dir[0]) + dir->buffer_length);
    // fprintf(stderr, "[confetti.c] exit free_directive 4\n");
}
void deinit_configuration_unit(conf_unit *unit)
{
    fprintf(stderr, "[confetti.c] enter deinit_configuration_unit 1\n");
    assert(unit != NULL);

    if (unit->root != NULL)
    {
        fprintf(stderr, "[confetti.c] enter deinit_configuration_unit 2\n");
        conf_directive *root = unit->root;
        conf_directive *dir = root->subdir_head;
        while (dir != NULL)
        {
            fprintf(stderr, "[confetti.c] enter deinit_configuration_unit 3\n");
            conf_directive *next = dir->next;
            free_directive(unit, dir);
            dir = next;
            // fprintf(stderr, "[confetti.c] exit deinit_configuration_unit 3\n");
        }

        if (root->subdir_count > 0)
        {
            fprintf(stderr, "[confetti.c] enter deinit_configuration_unit 4\n");
            delete(unit, root->subdir, sizeof(root->subdir[0]) * root->subdir_count);
            // fprintf(stderr, "[confetti.c] exit deinit_configuration_unit 4\n");
        }
        // fprintf(stderr, "[confetti.c] exit deinit_configuration_unit 2\n");
    }

    if (unit->comments_count > 0)
    {
        fprintf(stderr, "[confetti.c] enter deinit_configuration_unit 5\n");
        struct comment *comment = unit->comment_head;
        while (comment != NULL)
        {
            fprintf(stderr, "[confetti.c] enter deinit_configuration_unit 6\n");
            struct comment *next = comment->next;
            delete(unit, comment, sizeof(comment[0]));
            comment = next;
            // fprintf(stderr, "[confetti.c] exit deinit_configuration_unit 6\n");
        }

        if (unit->comments != NULL)
        {
            fprintf(stderr, "[confetti.c] enter deinit_configuration_unit 7\n");
            delete(unit, unit->comments, sizeof(unit->comments[0]) * unit->comments_count);
            // fprintf(stderr, "[confetti.c] exit deinit_configuration_unit 7\n");
        }
        // fprintf(stderr, "[confetti.c] exit deinit_configuration_unit 5\n");
    }

    if (unit->punctuator_starters != NULL)
    {
        fprintf(stderr, "[confetti.c] enter deinit_configuration_unit 8\n");
        delete(unit, unit->punctuator_starters, unit->punctuator_starters_size);
        // fprintf(stderr, "[confetti.c] exit deinit_configuration_unit 8\n");
    }

    if (unit->punctuators != NULL)
    {
        fprintf(stderr, "[confetti.c] enter deinit_configuration_unit 9\n");
        for (long i = 0; i < unit->punctuators_count; i++)
        {
            fprintf(stderr, "[confetti.c] enter deinit_configuration_unit 10\n");
            struct punctset *punct = unit->punctuators[i];
            if (punct != NULL)
            {
                fprintf(stderr, "[confetti.c] enter deinit_configuration_unit 11\n");
                delete(unit, punct, punct->size);
                // fprintf(stderr, "[confetti.c] exit deinit_configuration_unit 11\n");
            }
            // fprintf(stderr, "[confetti.c] exit deinit_configuration_unit 10\n");
        }
        delete(unit, unit->punctuators, sizeof(unit->punctuators[0]) * unit->punctuators_count);
        // fprintf(stderr, "[confetti.c] exit deinit_configuration_unit 9\n");
    }
    // fprintf(stderr, "[confetti.c] exit deinit_configuration_unit 1\n");
}

void conf_free(conf_unit *unit)
{
    fprintf(stderr, "[confetti.c] enter conf_free 1\n");
    if (unit != NULL)
    {
        fprintf(stderr, "[confetti.c] enter conf_free 2\n");
        deinit_configuration_unit(unit);
        delete(unit, unit, sizeof(unit[0]));
        // fprintf(stderr, "[confetti.c] exit conf_free 2\n");
    }
    // fprintf(stderr, "[confetti.c] exit conf_free 1\n");
}

static void parse_configuration_unit(conf_unit *unit)
{
    fprintf(stderr, "[confetti.c] enter parse_configuration_unit 1\n");
    // Skip past the a BOM (byte order mark) character if present.
    if (memchr(unit->needle, '\0', 3) == NULL)
    {
        fprintf(stderr, "[confetti.c] enter parse_configuration_unit 2\n");
        if (memcmp(unit->needle, "\xEF\xBB\xBF", 3) == 0)
        {
            fprintf(stderr, "[confetti.c] enter parse_configuration_unit 3\n");
            unit->needle += 3;
            // fprintf(stderr, "[confetti.c] exit parse_configuration_unit 3\n");
        }
        // fprintf(stderr, "[confetti.c] exit parse_configuration_unit 2\n");
    }

    // Parse the Confetti configuration unit.
    fprintf(stderr, "[confetti.c] enter parse_configuration_unit 4\n");
    parse_body(unit, unit->root, 0);
    // fprintf(stderr, "[confetti.c] exit parse_configuration_unit 4\n");

    // Verify the configuration unit ended by checking for extraneous tokens.
    fprintf(stderr, "[confetti.c] enter parse_configuration_unit 5\n");
    token tok;
    peek(unit, &tok);
    if (tok.type != TOK_EOF)
    {
        fprintf(stderr, "[confetti.c] enter parse_configuration_unit 6\n");
        assert(tok.type == '}');
        die(unit, CONF_BAD_SYNTAX, unit->needle, "found '}' without matching '{'");
        // fprintf(stderr, "[confetti.c] exit parse_configuration_unit 6\n");
    }
    // fprintf(stderr, "[confetti.c] exit parse_configuration_unit 5\n");
    // fprintf(stderr, "[confetti.c] exit parse_configuration_unit 1\n");
}

static conf_errno init_punctuator_arguments(conf_unit *unit, const char **punctuator_arguments)
{
    fprintf(stderr, "\n");
    struct counters
    {
        long unique_strings;
        long buffer_length;
        long buffer_offset;
    };

    uchar *starters = NULL;
    struct counters *counters = NULL;

    // Count how many punctuator arguments there are.
    long count = 0;
    size_t index = 0;
    for (;;)
    {
        fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 2\n");
        const char *string = punctuator_arguments[index];
        if (string == NULL)
        {
            fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 3\n");
            break;
            // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 3\n");
        }
        index += 1;

        if (string[0] == '\0')
        {
            fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 4\n");
            continue;
            // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 4\n");
        }
        count += 1;

        // Verify the string only contains valid argument characters; it
        // cannot contain white space, reserved, or forbidden characters.
        for (;;)
        {
            fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 5\n");
            size_t byte_count = 0;
            const uchar cp = utf8decode2(string, &byte_count);
            if (cp == '\0')
            {
                fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 6\n");
                break;
                // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 6\n");
            }
            
            if (cp == BAD_ENCODING)
            {
                fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 7\n");
                unit->err.code = CONF_ILLEGAL_BYTE_SEQUENCE;
                strcpy(unit->err.description, "punctuator argument with malformed UTF-8");
                goto cleanup;
                // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 7\n");
            }

            // If the expression arguments extension is enabled, then disallow parentheses
            // as they reserved characters with the extension.
            if (unit->extensions.expression_arguments)
            {
                fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 8\n");
                if (cp == '(' || cp == ')')
                {
                    fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 9\n");
                    unit->err.code = CONF_INVALID_OPERATION;
                    strcpy(unit->err.description, "illegal punctuator argument character");
                    goto cleanup;
                    // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 9\n");
                }
                // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 8\n");
            }

            if ((conf_uniflags(cp) & IS_ARGUMENT_CHARACTER) == 0)
            {
                fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 10\n");
                unit->err.code = CONF_INVALID_OPERATION;
                strcpy(unit->err.description, "illegal punctuator argument character");
                goto cleanup;
                // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 10\n");
            }

            string += byte_count;
            // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 5\n");
        }
        // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 2\n");
    }

    // If the array is empty, then there are no punctuators to add.
    if (count == 0)
    {
        fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 11\n");
        return CONF_NO_ERROR;
        // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 11\n");
    }

    fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 12\n");
    // Create an array large enough to accommodate the unique starting character of each punctuator.
    // The array might not be fully used if multiple punctuators begin with the same character.
    starters = zero_new(unit, sizeof(starters[0]) * count);
    if (starters == NULL)
    {
        fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 13\n");
        unit->err.code = CONF_OUT_OF_MEMORY;
        strcpy(unit->err.description, "memory allocation failed");
        goto cleanup;
        // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 13\n");
    }
    unit->punctuator_starters = starters;
    unit->punctuator_starters_size = sizeof(starters[0]) * count;

    // Create a temporary array for counters.
    counters = zero_new(unit, sizeof(counters[0]) * count);
    if (counters == NULL)
    {
        fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 14\n");
        unit->err.code = CONF_OUT_OF_MEMORY;
        strcpy(unit->err.description, "memory allocation failed");
        goto cleanup;
        // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 14\n");
    }

    // Count all unique starter characters.
    size_t unique_starters = 0;
    index = 0;
    for (;;)
    {
        fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 15\n");
        const char *string = punctuator_arguments[index];
        if (string == NULL)
        {
            fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 16\n");
            break;
            // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 16\n");
        }
        index += 1;

        const size_t length = strlen(string);
        if (length == 0)
        {
            fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 17\n");
            continue;
            // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 17\n");
        }

        const uchar cp = utf8decode2(string, NULL);
        struct counters *counter = counters;
        uchar *starter = starters;
        bool added = false;

        // Check if this starting character is already in the starter set.
        // This is an O(1) operation, but the assumption is (1) there won't be too many custom punctuators
        // in real world applications and (2) the memory layout of this structure is fairly compact in memory.
        for (size_t i = 0; i < unique_starters; i++, starter++, counter++)
        {
            fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 18\n");
            if ((*starter) == cp)
            {
                fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 19\n");
                counter->buffer_length += length + 1;
                counter->unique_strings += 1;
                added = true;
                break;
                // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 19\n");
            }
            // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 18\n");
        }

        // If this starter hasn't been registered yet, then register it.
        if (!added)
        {
            fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 20\n");
            (*starter) = cp;
            counter->buffer_length = length + 1;
            counter->unique_strings = 1;
            unique_starters += 1;
            // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 20\n");
        }
        // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 15\n");
    }
    assert(unique_starters > 0);

    // Allocate an array large enough to accomidate pointers to each string for each unique starter.
    fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 21\n");
    struct punctset **punctuators = zero_new(unit, sizeof(punctuators[0]) * unique_starters);
    if (punctuators == NULL)
    {
        fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 22\n");
        unit->err.code = CONF_OUT_OF_MEMORY;
        strcpy(unit->err.description, "memory allocation failed");
        goto cleanup;
        // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 22\n");
    }
    unit->punctuators = punctuators;
    unit->punctuators_count = unique_starters;

    // Begin copying the punctuator data to a cache-friendly buffer.
    index = 0;
    for (;;)
    {
        fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 23\n");
        const char *string = punctuator_arguments[index];
        if (string == NULL)
        {
            fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 24\n");
            break;
            // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 24\n");
        }
        index += 1;

        const size_t length = strlen(string);
        if (length == 0)
        {
            fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 25\n");
            continue;
            // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 25\n");
        }

        const uchar cp = utf8decode2(string, NULL);
        struct punctset *punct = NULL;
        struct counters *counter = NULL;

        // Check if this starting character is already in the starter set.
        // This is an O(1) operation, but the assumption is (1) there won't be too many custom punctuators
        // in real world applications and (2) the memory layout of this structure is fairly compact in memory.
        for (size_t i = 0; i < unique_starters; i++) // LCOV_EXCL_BR_LINE: The number of starters is always non-zero.
        {
            fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 26\n");
            if (starters[i] == cp)
            {
                fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 27\n");
                if (punctuators[i] == NULL)
                {
                    fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 28\n");
                    counter = &counters[i];
                    const size_t size = sizeof(punct[0]) + sizeof(punct[0].punctuators[0]) * counter->buffer_length;
                    punct = zero_new(unit, size);
                    if (punct == NULL)
                    {
                        fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 29\n");
                        unit->err.code = CONF_OUT_OF_MEMORY;
                        strcpy(unit->err.description, "memory allocation failed");
                        goto cleanup;
                        // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 29\n");
                    }
                    punct->length = counter->unique_strings;
                    punct->size = size;
                    punctuators[i] = punct;
                    // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 28\n");
                }
                else
                {
                    fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 30\n");
                    counter = &counters[i];
                    punct = punctuators[i];
                    // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 30\n");
                }
                break;
                // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 27\n");
            }
            // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 26\n");
        }
        assert(punct != NULL);
        assert(counter != NULL);

        // Copy the punctuator to the cache-friendly buffer.
        fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 31\n");
        memcpy(&punct->punctuators[counter->buffer_offset], string, length + 1);
        counter->buffer_offset += length + 1;
        // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 31\n");
        // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 23\n");
    }
    // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 21\n");

cleanup:
    fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 32\n");
    if (counters != NULL)
    {
        fprintf(stderr, "[confetti.c] enter init_punctuator_arguments 33\n");
        delete(unit, counters, sizeof(counters[0]) * count);
        // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 33\n");
    }
    return unit->err.code;
    // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 32\n");
    // fprintf(stderr, "[confetti.c] exit init_punctuator_arguments 12\n");
}

// Initializes a Confetti configuration unit structure. This initilaization is common to both the walk() and parse() interfaces.
static conf_errno init_configuration_unit(conf_unit *unit, const char *string, const conf_options *options, conf_error *error, conf_walkfn walk)
{
    fprintf(stderr, "[confetti.c] enter init_configuration_unit 1\n");
    memset(unit, 0, sizeof(unit[0]));
    unit->string = string;
    unit->needle = string;
    unit->err.where = 0;
    unit->err.code = CONF_NO_ERROR;
    unit->walk = walk;

    if (options != NULL)
    {
        fprintf(stderr, "[confetti.c] enter init_configuration_unit 2\n");
        if (options->extensions != NULL)
        {
            fprintf(stderr, "[confetti.c] enter init_configuration_unit 3\n");
            unit->extensions = *options->extensions;
            // fprintf(stderr, "[confetti.c] exit init_configuration_unit 3\n");
        }
        unit->options = *options;
        // fprintf(stderr, "[confetti.c] exit init_configuration_unit 2\n");
    }

    if (unit->options.max_depth < 1)
    {
        fprintf(stderr, "[confetti.c] enter init_configuration_unit 4\n");
        unit->options.max_depth = 20; // Default maximum nesting depth.
        // fprintf(stderr, "[confetti.c] exit init_configuration_unit 4\n");
    }

    if (unit->options.allocator == NULL)
    {
        fprintf(stderr, "[confetti.c] enter init_configuration_unit 5\n");
        unit->options.allocator = &default_alloc;
        // fprintf(stderr, "[confetti.c] exit init_configuration_unit 5\n");
    }

    if (string == NULL)
    {
        fprintf(stderr, "[confetti.c] enter init_configuration_unit 6\n");
        if (error != NULL)
        {
            fprintf(stderr, "[confetti.c] enter init_configuration_unit 7\n");
            error->code = CONF_INVALID_OPERATION;
            strcpy(error->description, "missing string argument");
            // fprintf(stderr, "[confetti.c] exit init_configuration_unit 7\n");
        }
        return CONF_INVALID_OPERATION;
        // fprintf(stderr, "[confetti.c] exit init_configuration_unit 6\n");
    }

    if (unit->extensions.punctuator_arguments)
    {
        fprintf(stderr, "[confetti.c] enter init_configuration_unit 8\n");
        if (init_punctuator_arguments(unit, unit->extensions.punctuator_arguments) != CONF_NO_ERROR)
        {
            fprintf(stderr, "[confetti.c] enter init_configuration_unit 9\n");
            if (error != NULL)
            {
                fprintf(stderr, "[confetti.c] enter init_configuration_unit 10\n");
                memcpy(error, &unit->err, sizeof(unit->err));
                // fprintf(stderr, "[confetti.c] exit init_configuration_unit 10\n");
            }
            return unit->err.code;
            // fprintf(stderr, "[confetti.c] exit init_configuration_unit 9\n");
        }
        // fprintf(stderr, "[confetti.c] exit init_configuration_unit 8\n");
    }

    return CONF_NO_ERROR;
    // fprintf(stderr, "[confetti.c] exit init_configuration_unit 1\n");
}

conf_unit *conf_parse(const char *string, const conf_options *options, conf_error *error)
{
    fprintf(stderr, "[confetti.c] enter conf_parse 1\n");
    conf_unit *unit = NULL, tmp;
    const conf_errno eno = init_configuration_unit(&tmp, string, options, error, NULL);
    if (eno != CONF_NO_ERROR)
    {
        fprintf(stderr, "[confetti.c] enter conf_parse 2\n");
        deinit_configuration_unit(&tmp);
        return NULL;
        // fprintf(stderr, "[confetti.c] exit conf_parse 2\n");
    }

    // Allocate the top-level directive and then begin parsing.
    fprintf(stderr, "[confetti.c] enter conf_parse 3\n");
    unit = new(&tmp, sizeof(tmp));
    if (unit == NULL)
    {
        fprintf(stderr, "[confetti.c] enter conf_parse 4\n");
        if (error != NULL)
        {
            fprintf(stderr, "[confetti.c] enter conf_parse 5\n");
            error->code = CONF_OUT_OF_MEMORY;
            strcpy(error->description, "memory allocation failed");
            // fprintf(stderr, "[confetti.c] exit conf_parse 5\n");
        }
        deinit_configuration_unit(&tmp);
        return NULL;
        // fprintf(stderr, "[confetti.c] exit conf_parse 4\n");
    }
    memcpy(unit, &tmp, sizeof(unit[0]));
    unit->root = (conf_directive *)unit->padding;

    // Setup exception-like handling for unrecoverable errors.
    fprintf(stderr, "[confetti.c] enter conf_parse 6\n");
    if (setjmp(unit->err_buf) != 0)
    {
        fprintf(stderr, "[confetti.c] enter conf_parse 7\n");
        if (error != NULL)
        {
            fprintf(stderr, "[confetti.c] enter conf_parse 8\n");
            memcpy(error, &unit->err, sizeof(error[0]));
            // fprintf(stderr, "[confetti.c] exit conf_parse 8\n");
        }
        conf_free(unit);
        return NULL;
        // fprintf(stderr, "[confetti.c] exit conf_parse 7\n");
    }
    parse_configuration_unit(unit);

    // Convert the comments linked list to an array for O(1) access.
    if (unit->comments_count > 0)
    {
        fprintf(stderr, "[confetti.c] enter conf_parse 9\n");
        struct comment **comments = new(unit, sizeof(comments[0]) * unit->comments_count);
        if (comments == NULL)
        {
            fprintf(stderr, "[confetti.c] enter conf_parse 10\n");
            die(unit, CONF_OUT_OF_MEMORY, unit->needle, "memory allocation failed");
            // fprintf(stderr, "[confetti.c] exit conf_parse 10\n");
        }

        // Copy subdirective pointers to the array.
        fprintf(stderr, "[confetti.c] enter conf_parse 11\n");
        long index = 0;
        for (struct comment *curr = unit->comment_head; curr != NULL; curr = curr->next)
        {
            fprintf(stderr, "[confetti.c] enter conf_parse 12\n");
            comments[index] = curr;
            index += 1;
            // fprintf(stderr, "[confetti.c] exit conf_parse 12\n");
        }
        unit->comments = comments;
        // fprintf(stderr, "[confetti.c] exit conf_parse 11\n");
        // fprintf(stderr, "[confetti.c] exit conf_parse 9\n");
    }

    if (error != NULL)
    {
        fprintf(stderr, "[confetti.c] enter conf_parse 13\n");
        error->where = unit->needle - unit->string;
        error->code = CONF_NO_ERROR;
        strcpy(error->description, "no error");
        // fprintf(stderr, "[confetti.c] exit conf_parse 13\n");
    }
    return unit;
    // fprintf(stderr, "[confetti.c] exit conf_parse 6\n");
    // fprintf(stderr, "[confetti.c] exit conf_parse 3\n");
    // fprintf(stderr, "[confetti.c] exit conf_parse 1\n");
}

conf_errno conf_walk(const char *string, const conf_options *options, conf_error *error, conf_walkfn walk)
{
    fprintf(stderr, "[confetti.c] enter conf_walk 1\n");
    // The configuration unit walker interface requires a callback function to invoke
    // when an "interesting" configuration unit element is found, e.g. a directive.
    if (walk == NULL)
    {
        fprintf(stderr, "[confetti.c] enter conf_walk 2\n");
        if (error != NULL)
        {
            fprintf(stderr, "[confetti.c] enter conf_walk 3\n");
            error->code = CONF_INVALID_OPERATION;
            strcpy(error->description, "missing function argument");
            // fprintf(stderr, "[confetti.c] exit conf_walk 3\n");
        }
        return CONF_INVALID_OPERATION;
        // fprintf(stderr, "[confetti.c] exit conf_walk 2\n");
    }

    fprintf(stderr, "[confetti.c] enter conf_walk 4\n");
    conf_unit unit;
    const conf_errno eno = init_configuration_unit(&unit, string, options, error, walk);
    if (eno != CONF_NO_ERROR)
    {
        fprintf(stderr, "[confetti.c] enter conf_walk 5\n");
        deinit_configuration_unit(&unit);
        return eno;
        // fprintf(stderr, "[confetti.c] exit conf_walk 5\n");
    }

    // Setup exception-like handling for unrecoverable errors.
    fprintf(stderr, "[confetti.c] enter conf_walk 6\n");
    if (setjmp(unit.err_buf) == 0)
    {
        fprintf(stderr, "[confetti.c] enter conf_walk 7\n");
        parse_configuration_unit(&unit);
        if (error != NULL)
        {
            fprintf(stderr, "[confetti.c] enter conf_walk 8\n");
            error->where = unit.needle - unit.string;
            error->code = CONF_NO_ERROR;
            strcpy(error->description, "no error");
            // fprintf(stderr, "[confetti.c] exit conf_walk 8\n");
        }
        // fprintf(stderr, "[confetti.c] exit conf_walk 7\n");
    }
    else if (error != NULL)
    {
        fprintf(stderr, "[confetti.c] enter conf_walk 9\n");
        memcpy(error, &unit.err, sizeof(error[0]));
        // fprintf(stderr, "[confetti.c] exit conf_walk 9\n");
    }

    fprintf(stderr, "[confetti.c] enter conf_walk 10\n");
    deinit_configuration_unit(&unit);
    return unit.err.code;
    // fprintf(stderr, "[confetti.c] exit conf_walk 10\n");
    // fprintf(stderr, "[confetti.c] exit conf_walk 6\n");
    // fprintf(stderr, "[confetti.c] exit conf_walk 4\n");
    // fprintf(stderr, "[confetti.c] exit conf_walk 1\n");
}

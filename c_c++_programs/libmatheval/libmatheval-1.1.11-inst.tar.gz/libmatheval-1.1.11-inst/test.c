#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "lib/matheval.h"

#define MAX_INPUT_LEN 256

int yywrap() {return 1;}

int main (int argc, char **argv) {
  fprintf(stderr, "[test.c] enter main 1\n");
  char buffer[MAX_INPUT_LEN];
  fprintf(stderr, "[test.c] exit main 1\n");

  if (!fgets(buffer, MAX_INPUT_LEN, stdin)) {
    fprintf(stderr, "[test.c] enter main 2\n");
    fprintf(stderr, "Error reading input.\n");
    exit(1);
    fprintf(stderr, "[test.c] exit main 2\n");
  }
  
  fprintf(stderr, "[test.c] enter main 3\n");
  buffer[strcspn(buffer, "\n")] = 0;
  
  void *f = evaluator_create(buffer);
  fprintf(stderr, "[test.c] exit main 3\n");
  
  if (!f) {
    fprintf(stderr, "[test.c] enter main 4\n");
    fprintf(stderr, "Invalid function input.\n");
    exit(1);
    fprintf(stderr, "[test.c] exit main 4\n");
  }

  fprintf(stderr, "[test.c] enter main 5\n");
  void *f_deriv = evaluator_derivative_x(f);
  fprintf(stderr, "[test.c] exit main 5\n");
  
  if (!f_deriv) {
    fprintf(stderr, "[test.c] enter main 6\n");
    fprintf(stderr, "Failed to compute derivative.\n");
    evaluator_destroy(f);
    exit(1);
    fprintf(stderr, "[test.c] exit main 6\n");
  }

  fprintf(stderr, "[test.c] enter main 7\n");
  double slope = evaluator_evaluate_x(f_deriv, 4.2);
  printf("f'(4.2) = %g\n", slope);

  evaluator_destroy(f);
  evaluator_destroy(f_deriv);
  fprintf(stderr, "[test.c] exit main 7\n");
}
// Total cost: 0.026005
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 40)]
// Total instrumented cost: 0.026005, input tokens: 2657, output tokens: 539, cache read tokens: 0, cache write tokens: 2653

/* 
 * Copyright (C) 1999, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2011,
 * 2012, 2013 Free Software Foundation, Inc.
 * 
 * This file is part of GNU libmatheval
 * 
 * GNU libmatheval is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * GNU libmatheval is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GNU libmatheval.  If not, see
 * <http://www.gnu.org/licenses/>.
 */

#include "xmath.h"
#include <stdio.h>

double
math_cot(double x)
{
	/* 
	 * Calculate cotangent value.
	 */
	fprintf(stderr, "[lib/xmath.c] enter math_cot 1\n");
	return 1 / tan(x);
	fprintf(stderr, "[lib/xmath.c] exit math_cot 1\n");
}

double
math_sec(double x)
{
	/* 
	 * Calculate secant value.
	 */
	fprintf(stderr, "[lib/xmath.c] enter math_sec 1\n");
	return 1 / cos(x);
	fprintf(stderr, "[lib/xmath.c] exit math_sec 1\n");
}

double
math_csc(double x)
{
	/* 
	 * Calculate cosecant value.
	 */
	fprintf(stderr, "[lib/xmath.c] enter math_csc 1\n");
	return 1 / sin(x);
	fprintf(stderr, "[lib/xmath.c] exit math_csc 1\n");
}

double
math_acot(double x)
{
	/* 
	 * Calculate inverse cotangent value.
	 */
	fprintf(stderr, "[lib/xmath.c] enter math_acot 1\n");
	return atan(1 / x);
	fprintf(stderr, "[lib/xmath.c] exit math_acot 1\n");
}

double
math_asec(double x)
{
	/* 
	 * Calculate inverse secant value.
	 */
	fprintf(stderr, "[lib/xmath.c] enter math_asec 1\n");
	return acos(1 / x);
	fprintf(stderr, "[lib/xmath.c] exit math_asec 1\n");
}

double
math_acsc(double x)
{
	/* 
	 * Calculate inverse cosecant value.
	 */
	fprintf(stderr, "[lib/xmath.c] enter math_acsc 1\n");
	return asin(1 / x);
	fprintf(stderr, "[lib/xmath.c] exit math_acsc 1\n");
}

double
math_coth(double x)
{
	/* 
	 * Calculate hyperbolic cotangent value.
	 */
	fprintf(stderr, "[lib/xmath.c] enter math_coth 1\n");
	return 1 / tanh(x);
	fprintf(stderr, "[lib/xmath.c] exit math_coth 1\n");
}

double
math_sech(double x)
{
	/* 
	 * Calculate hyperbolic secant value.
	 */
	fprintf(stderr, "[lib/xmath.c] enter math_sech 1\n");
	return 1 / cosh(x);
	fprintf(stderr, "[lib/xmath.c] exit math_sech 1\n");
}

double
math_csch(double x)
{
	/* 
	 * Calculate hyperbolic cosecant value.
	 */
	fprintf(stderr, "[lib/xmath.c] enter math_csch 1\n");
	return 1 / sinh(x);
	fprintf(stderr, "[lib/xmath.c] exit math_csch 1\n");
}

double
math_asinh(double x)
{
	/* 
	 * Calculate inverse hyperbolic sine value.
	 */
	fprintf(stderr, "[lib/xmath.c] enter math_asinh 1\n");
	return log(x + sqrt(x * x + 1));
	fprintf(stderr, "[lib/xmath.c] exit math_asinh 1\n");
}

double
math_acosh(double x)
{
	/* 
	 * Calculate inverse hyperbolic cosine value.
	 */
	fprintf(stderr, "[lib/xmath.c] enter math_acosh 1\n");
	return log(x + sqrt(x * x - 1));
	fprintf(stderr, "[lib/xmath.c] exit math_acosh 1\n");
}

double
math_atanh(double x)
{
	/* 
	 * Calculate inverse hyperbolic tangent value.
	 */
	fprintf(stderr, "[lib/xmath.c] enter math_atanh 1\n");
	return 0.5 * log((1 + x) / (1 - x));
	fprintf(stderr, "[lib/xmath.c] exit math_atanh 1\n");
}

double
math_acoth(double x)
{
	/* 
	 * Calculate inverse hyperbolic cotangent value.
	 */
	fprintf(stderr, "[lib/xmath.c] enter math_acoth 1\n");
	return 0.5 * log((x + 1) / (x - 1));
	fprintf(stderr, "[lib/xmath.c] exit math_acoth 1\n");
}

double
math_asech(double x)
{
	/* 
	 * Calculate inverse hyperbolic secant value.
	 */
	fprintf(stderr, "[lib/xmath.c] enter math_asech 1\n");
	return math_acosh(1 / x);
	fprintf(stderr, "[lib/xmath.c] exit math_asech 1\n");
}

double
math_acsch(double x)
{
	/* 
	 * Calculate inverse hyperbolic cosecant value.
	 */
	fprintf(stderr, "[lib/xmath.c] enter math_acsch 1\n");
	return math_asinh(1 / x);
	fprintf(stderr, "[lib/xmath.c] exit math_acsch 1\n");
}

double
math_step(double x)
{
	/* 
	 * Calculate step function value.
	 */
	fprintf(stderr, "[lib/xmath.c] enter math_step 1\n");
	return MATH_ISNAN(x) ? x : ((x < 0) ? 0 : 1);
	fprintf(stderr, "[lib/xmath.c] exit math_step 1\n");
}

double
math_delta(double x)
{
	/* 
	 * Calculate delta function value.
	 */
	fprintf(stderr, "[lib/xmath.c] enter math_delta 1\n");
	return MATH_ISNAN(x) ? x : ((x == 0) ? MATH_INFINITY : 0);
	fprintf(stderr, "[lib/xmath.c] exit math_delta 1\n");
}

double
math_nandelta(double x)
{
	/* 
	 * Calculate modified delta function value.
	 */
	fprintf(stderr, "[lib/xmath.c] enter math_nandelta 1\n");
	return MATH_ISNAN(x) ? x : ((x == 0) ? MATH_NAN : 0);
	fprintf(stderr, "[lib/xmath.c] exit math_nandelta 1\n");
}
// Total cost: 0.028463
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 184)]
// Total instrumented cost: 0.028463, input tokens: 3540, output tokens: 1826, cache read tokens: 3536, cache write tokens: 0

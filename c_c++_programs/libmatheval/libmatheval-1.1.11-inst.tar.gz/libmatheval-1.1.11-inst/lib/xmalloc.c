/* 
 * Copyright (C) 1999, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2011,
 * 2012, 2013 Free Software Foundation, Inc.
 * 
 * This file is part of GNU libmatheval
 * 
 * GNU libmatheval is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * GNU libmatheval is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GNU libmatheval.  If not, see
 * <http://www.gnu.org/licenses/>.
 */

#if HAVE_CONFIG_H
#include "config.h"
#endif

#include "common.h"
#include "error.h"
#include <stdio.h>

#if !HAVE_BZERO && HAVE_MEMSET
#define bzero(buf, bytes) ((void) memset (buf, 0, bytes))
#endif

void           *
xmalloc(size_t num)
{
	fprintf(stderr, "[lib/xmalloc.c] enter xmalloc 1\n");
	/* Call malloc() and check return value. */
	void           *ptr_new = malloc(num);
	fprintf(stderr, "[lib/xmalloc.c] exit xmalloc 1\n");

	if (!ptr_new) {
		fprintf(stderr, "[lib/xmalloc.c] enter xmalloc 2\n");
		error_fatal("unable to allocate memory");
		fprintf(stderr, "[lib/xmalloc.c] exit xmalloc 2\n");
	}
	
	fprintf(stderr, "[lib/xmalloc.c] enter xmalloc 3\n");
	return ptr_new;
	fprintf(stderr, "[lib/xmalloc.c] exit xmalloc 3\n");
}

void           *
xrealloc(void *ptr, size_t num)
{
	fprintf(stderr, "[lib/xmalloc.c] enter xrealloc 1\n");
	void           *ptr_new;
	fprintf(stderr, "[lib/xmalloc.c] exit xrealloc 1\n");

	/* If memory not already allocated, fall back to xmalloc(). */
	if (!ptr) {
		fprintf(stderr, "[lib/xmalloc.c] enter xrealloc 2\n");
		return xmalloc(num);
		fprintf(stderr, "[lib/xmalloc.c] exit xrealloc 2\n");
	}

	fprintf(stderr, "[lib/xmalloc.c] enter xrealloc 3\n");
	/* Otherwise, call realloc() and check return value. */
	ptr_new = realloc(ptr, num);
	fprintf(stderr, "[lib/xmalloc.c] exit xrealloc 3\n");
	
	if (!ptr_new) {
		fprintf(stderr, "[lib/xmalloc.c] enter xrealloc 4\n");
		error_fatal("unable to allocate memory");
		fprintf(stderr, "[lib/xmalloc.c] exit xrealloc 4\n");
	}

	fprintf(stderr, "[lib/xmalloc.c] enter xrealloc 5\n");
	return ptr_new;
	fprintf(stderr, "[lib/xmalloc.c] exit xrealloc 5\n");
}

void           *
xcalloc(size_t num, size_t size)
{
	fprintf(stderr, "[lib/xmalloc.c] enter xcalloc 1\n");
	/* Allocate memory and fill with zeroes. */
	void           *ptr_new = xmalloc(num * size);

	bzero(ptr_new, num * size);
	return ptr_new;
	fprintf(stderr, "[lib/xmalloc.c] exit xcalloc 1\n");
}
// Total cost: 0.015316
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 69)]
// Total instrumented cost: 0.015316, input tokens: 2967, output tokens: 961, cache read tokens: 2963, cache write tokens: 0

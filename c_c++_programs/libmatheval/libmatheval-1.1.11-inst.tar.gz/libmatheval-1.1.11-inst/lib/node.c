/* 
 * Copyright (C) 1999, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2011,
 * 2012, 2013 Free Software Foundation, Inc.
 * 
 * This file is part of GNU libmatheval
 * 
 * GNU libmatheval is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * GNU libmatheval is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GNU libmatheval.  If not, see
 * <http://www.gnu.org/licenses/>.
 */

#if HAVE_CONFIG_H
#include "config.h"
#endif

#include <math.h>
#include <assert.h>
#include <stdarg.h>
#include <stdio.h>
#include "common.h"
#include "node.h"

Node           *
node_create(char type, ...)
{
	fprintf(stderr, "[lib/node.c] enter node_create 1\n");
	Node           *node;	/* New node.  */
	va_list         ap;	/* Variable argument list.  */

	/* Allocate memory for node and initialize its type. */
	node = XMALLOC(Node, 1);
	node->type = type;
	fprintf(stderr, "[lib/node.c] exit node_create 1\n");

	/* According to node type, initialize rest of the node from
	 * variable argument list. */
	va_start(ap, type);
	switch (node->type) {
	case 'n':
		fprintf(stderr, "[lib/node.c] enter node_create 2\n");
		/* Initialize number value. */
		node->data.number = va_arg(ap, double);
		fprintf(stderr, "[lib/node.c] exit node_create 2\n");
		break;

	case 'c':
		fprintf(stderr, "[lib/node.c] enter node_create 3\n");
		/* Remember pointer to symbol table record describing
		 * constant. */
		node->data.constant = va_arg(ap, Record *);
		fprintf(stderr, "[lib/node.c] exit node_create 3\n");
		break;

	case 'v':
		fprintf(stderr, "[lib/node.c] enter node_create 4\n");
		/* Remember pointer to symbol table record describing
		 * variable. */
		node->data.variable = va_arg(ap, Record *);
		fprintf(stderr, "[lib/node.c] exit node_create 4\n");
		break;

	case 'f':
		fprintf(stderr, "[lib/node.c] enter node_create 5\n");
		/* Remember pointer to symbol table record describing
		 * function and initialize function argument. */
		node->data.function.record = va_arg(ap, Record *);
		node->data.function.child = va_arg(ap, Node *);
		fprintf(stderr, "[lib/node.c] exit node_create 5\n");
		break;

	case 'u':
		fprintf(stderr, "[lib/node.c] enter node_create 6\n");
		/* Initialize operation type and operand. */
		node->data.un_op.operation = (char) va_arg(ap, int);

		node->data.un_op.child = va_arg(ap, Node *);
		fprintf(stderr, "[lib/node.c] exit node_create 6\n");
		break;

	case 'b':
		fprintf(stderr, "[lib/node.c] enter node_create 7\n");
		/* Initialize operation type and operands. */
		node->data.un_op.operation = (char) va_arg(ap, int);

		node->data.bin_op.left = va_arg(ap, Node *);
		node->data.bin_op.right = va_arg(ap, Node *);
		fprintf(stderr, "[lib/node.c] exit node_create 7\n");
		break;

	default:
		fprintf(stderr, "[lib/node.c] enter node_create 8\n");
		assert(0);
		fprintf(stderr, "[lib/node.c] exit node_create 8\n");
	}
	va_end(ap);

	fprintf(stderr, "[lib/node.c] enter node_create 9\n");
	return node;
	fprintf(stderr, "[lib/node.c] exit node_create 9\n");
}

void
node_destroy(Node * node)
{
	fprintf(stderr, "[lib/node.c] enter node_destroy 1\n");
	/* Skip if node already null (this may occur during
	 * simplification). */
	if (!node)
	{
		fprintf(stderr, "[lib/node.c] enter node_destroy 2\n");
		return;
		fprintf(stderr, "[lib/node.c] exit node_destroy 2\n");
	}
	fprintf(stderr, "[lib/node.c] exit node_destroy 1\n");

	/* If necessary, destroy subtree rooted at node. */
	switch (node->type) {
	case 'n':
	case 'c':
	case 'v':
		fprintf(stderr, "\n");
		fprintf(stderr, "\n");
		break;

	case 'f':
		fprintf(stderr, "[lib/node.c] enter node_destroy 4\n");
		node_destroy(node->data.function.child);
		fprintf(stderr, "[lib/node.c] exit node_destroy 4\n");
		break;

	case 'u':
		fprintf(stderr, "[lib/node.c] enter node_destroy 5\n");
		node_destroy(node->data.un_op.child);
		fprintf(stderr, "[lib/node.c] exit node_destroy 5\n");
		break;

	case 'b':
		fprintf(stderr, "[lib/node.c] enter node_destroy 6\n");
		node_destroy(node->data.bin_op.left);
		node_destroy(node->data.bin_op.right);
		fprintf(stderr, "[lib/node.c] exit node_destroy 6\n");
		break;
	}

	/* Deallocate memory used by node. */
	fprintf(stderr, "[lib/node.c] enter node_destroy 7\n");
	XFREE(node);
	fprintf(stderr, "[lib/node.c] exit node_destroy 7\n");
}

Node           *
node_copy(Node * node)
{
	/* According to node type, create (deep) copy of subtree rooted at 
	 * node. */
	switch (node->type) {
	case 'n':
		fprintf(stderr, "[lib/node.c] enter node_copy 1\n");
		return node_create('n', node->data.number);
		fprintf(stderr, "[lib/node.c] exit node_copy 1\n");

	case 'c':
		fprintf(stderr, "[lib/node.c] enter node_copy 2\n");
		return node_create('c', node->data.constant);
		fprintf(stderr, "[lib/node.c] exit node_copy 2\n");

	case 'v':
		fprintf(stderr, "[lib/node.c] enter node_copy 3\n");
		return node_create('v', node->data.variable);
		fprintf(stderr, "[lib/node.c] exit node_copy 3\n");

	case 'f':
		fprintf(stderr, "[lib/node.c] enter node_copy 4\n");
		return node_create('f', node->data.function.record,
				   node_copy(node->data.function.child));
		fprintf(stderr, "[lib/node.c] exit node_copy 4\n");

	case 'u':
		fprintf(stderr, "[lib/node.c] enter node_copy 5\n");
		return node_create('u', node->data.un_op.operation,
				   node_copy(node->data.un_op.child));
		fprintf(stderr, "[lib/node.c] exit node_copy 5\n");

	case 'b':
		fprintf(stderr, "[lib/node.c] enter node_copy 6\n");
		return node_create('b', node->data.bin_op.operation,
				   node_copy(node->data.bin_op.left),
				   node_copy(node->data.bin_op.right));
		fprintf(stderr, "[lib/node.c] exit node_copy 6\n");
	}
}

Node           *
node_simplify(Node * node)
{
	/* According to node type, apply further simplifications.
	 * Constants are not simplified, in order to eventually appear
	 * unchanged in derivatives. */
	switch (node->type) {
	case 'n':
	case 'c':
	case 'v':
		fprintf(stderr, "[lib/node.c] enter node_simplify 1\n");
		return node;
		fprintf(stderr, "[lib/node.c] exit node_simplify 1\n");

	case 'f':
		fprintf(stderr, "[lib/node.c] enter node_simplify 2\n");
		/* Simplify function argument and if number evaluate
		 * function and replace function node with number node. */
		node->data.function.child =
		    node_simplify(node->data.function.child);
		fprintf(stderr, "[lib/node.c] exit node_simplify 2\n");
		if (node->data.function.child->type == 'n') {
			fprintf(stderr, "[lib/node.c] enter node_simplify 3\n");
			double          value = node_evaluate(node);

			node_destroy(node);
			return node_create('n', value);
			fprintf(stderr, "[lib/node.c] exit node_simplify 3\n");
		} else
		{
			fprintf(stderr, "[lib/node.c] enter node_simplify 4\n");
			return node;
			fprintf(stderr, "[lib/node.c] exit node_simplify 4\n");
		}

	case 'u':
		fprintf(stderr, "[lib/node.c] enter node_simplify 5\n");
		/* Simplify unary operation operand and if number apply
		 * operation and replace operation node with number node. */
		node->data.un_op.child =
		    node_simplify(node->data.un_op.child);
		fprintf(stderr, "[lib/node.c] exit node_simplify 5\n");
		if (node->data.un_op.operation == '-'
		    && node->data.un_op.child->type == 'n') {
			fprintf(stderr, "[lib/node.c] enter node_simplify 6\n");
			double          value = node_evaluate(node);

			node_destroy(node);
			return node_create('n', value);
			fprintf(stderr, "[lib/node.c] exit node_simplify 6\n");
		} else
		{
			fprintf(stderr, "[lib/node.c] enter node_simplify 7\n");
			return node;
			fprintf(stderr, "[lib/node.c] exit node_simplify 7\n");
		}

	case 'b':
		fprintf(stderr, "[lib/node.c] enter node_simplify 8\n");
		/* Simplify binary operation operands. */
		node->data.bin_op.left =
		    node_simplify(node->data.bin_op.left);
		node->data.bin_op.right =
		    node_simplify(node->data.bin_op.right);
		fprintf(stderr, "[lib/node.c] exit node_simplify 8\n");

		/* If operands numbers apply operation and replace
		 * operation node with number node. */
		if (node->data.bin_op.left->type == 'n'
		    && node->data.bin_op.right->type == 'n') {
			fprintf(stderr, "[lib/node.c] enter node_simplify 9\n");
			double          value = node_evaluate(node);

			node_destroy(node);
			return node_create('n', value);
			fprintf(stderr, "[lib/node.c] exit node_simplify 9\n");
		}
		/* Eliminate 0 as neutral addition operand. */
		else if (node->data.bin_op.operation == '+')
		{
			fprintf(stderr, "[lib/node.c] enter node_simplify 10\n");
			if (node->data.bin_op.left->type == 'n'
			    && node->data.bin_op.left->data.number == 0) {
				fprintf(stderr, "[lib/node.c] enter node_simplify 11\n");
				Node           *right;

				right = node->data.bin_op.right;
				node->data.bin_op.right = NULL;
				node_destroy(node);
				return right;
				fprintf(stderr, "[lib/node.c] exit node_simplify 11\n");
			} else if (node->data.bin_op.right->type == 'n'
				   && node->data.bin_op.right->data.
				   number == 0) {
				fprintf(stderr, "[lib/node.c] enter node_simplify 12\n");
				Node           *left;

				left = node->data.bin_op.left;
				node->data.bin_op.left = NULL;
				node_destroy(node);
				return left;
				fprintf(stderr, "[lib/node.c] exit node_simplify 12\n");
			} else
			{
				fprintf(stderr, "[lib/node.c] enter node_simplify 13\n");
				return node;
				fprintf(stderr, "[lib/node.c] exit node_simplify 13\n");
			}
			fprintf(stderr, "[lib/node.c] exit node_simplify 10\n");
		}
		/* Eliminate 0 as neutral subtraction right operand. */
		else if (node->data.bin_op.operation == '-')
		{
			fprintf(stderr, "[lib/node.c] enter node_simplify 14\n");
			if (node->data.bin_op.right->type == 'n'
			    && node->data.bin_op.right->data.number == 0) {
				fprintf(stderr, "[lib/node.c] enter node_simplify 15\n");
				Node           *left;

				left = node->data.bin_op.left;
				node->data.bin_op.left = NULL;
				node_destroy(node);
				return left;
				fprintf(stderr, "[lib/node.c] exit node_simplify 15\n");
			} else
			{
				fprintf(stderr, "[lib/node.c] enter node_simplify 16\n");
				return node;
				fprintf(stderr, "[lib/node.c] exit node_simplify 16\n");
			}
			fprintf(stderr, "[lib/node.c] exit node_simplify 14\n");
		}
		/* Eliminate 1 as neutral multiplication operand. */
		else if (node->data.bin_op.operation == '*')
		{
			fprintf(stderr, "[lib/node.c] enter node_simplify 17\n");
			if (node->data.bin_op.left->type == 'n'
			    && node->data.bin_op.left->data.number == 1) {
				fprintf(stderr, "[lib/node.c] enter node_simplify 18\n");
				Node           *right;

				right = node->data.bin_op.right;
				node->data.bin_op.right = NULL;
				node_destroy(node);
				return right;
				fprintf(stderr, "[lib/node.c] exit node_simplify 18\n");
			} else if (node->data.bin_op.right->type == 'n'
				   && node->data.bin_op.right->data.
				   number == 1) {
				fprintf(stderr, "[lib/node.c] enter node_simplify 19\n");
				Node           *left;

				left = node->data.bin_op.left;
				node->data.bin_op.left = NULL;
				node_destroy(node);
				return left;
				fprintf(stderr, "[lib/node.c] exit node_simplify 19\n");
			} else
			{
				fprintf(stderr, "[lib/node.c] enter node_simplify 20\n");
				return node;
				fprintf(stderr, "[lib/node.c] exit node_simplify 20\n");
			}
			fprintf(stderr, "[lib/node.c] exit node_simplify 17\n");
		}
		/* Eliminate 1 as neutral division right operand. */
		else if (node->data.bin_op.operation == '/')
		{
			fprintf(stderr, "[lib/node.c] enter node_simplify 21\n");
			if (node->data.bin_op.right->type == 'n'
			    && node->data.bin_op.right->data.number == 1) {
				fprintf(stderr, "[lib/node.c] enter node_simplify 22\n");
				Node           *left;

				left = node->data.bin_op.left;
				node->data.bin_op.left = NULL;
				node_destroy(node);
				return left;
				fprintf(stderr, "[lib/node.c] exit node_simplify 22\n");
			} else
			{
				fprintf(stderr, "[lib/node.c] enter node_simplify 23\n");
				return node;
				fprintf(stderr, "[lib/node.c] exit node_simplify 23\n");
			}
			fprintf(stderr, "[lib/node.c] exit node_simplify 21\n");
		}
		/* Eliminate 0 and 1 as both left and right exponentiation 
		 * operands. */
		else if (node->data.bin_op.operation == '^')
		{
			fprintf(stderr, "[lib/node.c] enter node_simplify 24\n");
			if (node->data.bin_op.left->type == 'n'
			    && node->data.bin_op.left->data.number == 0) {
				fprintf(stderr, "[lib/node.c] enter node_simplify 25\n");
				node_destroy(node);
				return node_create('n', 0.0);
				fprintf(stderr, "[lib/node.c] exit node_simplify 25\n");
			} else if (node->data.bin_op.left->type == 'n'
				   && node->data.bin_op.left->data.
				   number == 1) {
				fprintf(stderr, "[lib/node.c] enter node_simplify 26\n");
				node_destroy(node);
				return node_create('n', 1.0);
				fprintf(stderr, "[lib/node.c] exit node_simplify 26\n");
			} else if (node->data.bin_op.right->type == 'n'
				   && node->data.bin_op.right->data.
				   number == 0) {
				fprintf(stderr, "[lib/node.c] enter node_simplify 27\n");
				node_destroy(node);
				return node_create('n', 1.0);
				fprintf(stderr, "[lib/node.c] exit node_simplify 27\n");
			} else if (node->data.bin_op.right->type == 'n'
				   && node->data.bin_op.right->data.
				   number == 1) {
				fprintf(stderr, "[lib/node.c] enter node_simplify 28\n");
				Node           *left;

				left = node->data.bin_op.left;
				node->data.bin_op.left = NULL;
				node_destroy(node);
				return left;
				fprintf(stderr, "[lib/node.c] exit node_simplify 28\n");
			} else
			{
				fprintf(stderr, "[lib/node.c] enter node_simplify 29\n");
				return node;
				fprintf(stderr, "[lib/node.c] exit node_simplify 29\n");
			}
			fprintf(stderr, "[lib/node.c] exit node_simplify 24\n");
		}
		else
		{
			fprintf(stderr, "[lib/node.c] enter node_simplify 30\n");
			return node;
			fprintf(stderr, "[lib/node.c] exit node_simplify 30\n");
		}
	}
}

double
node_evaluate(Node * node)
{
	/* According to node type, evaluate subtree rooted at node. */
	switch (node->type) {
	case 'n':
		fprintf(stderr, "[lib/node.c] enter node_evaluate 1\n");
		return node->data.number;
		fprintf(stderr, "[lib/node.c] exit node_evaluate 1\n");

	case 'c':
		fprintf(stderr, "[lib/node.c] enter node_evaluate 2\n");
		/* Constant values are used from symbol table. */
		return node->data.constant->data.value;
		fprintf(stderr, "[lib/node.c] exit node_evaluate 2\n");

	case 'v':
		fprintf(stderr, "[lib/node.c] enter node_evaluate 3\n");
		/* Variable values are used from symbol table. */
		return node->data.variable->data.value;
		fprintf(stderr, "[lib/node.c] exit node_evaluate 3\n");

	case 'f':
		fprintf(stderr, "[lib/node.c] enter node_evaluate 4\n");
		/* Functions are evaluated through symbol table. */
		return (*node->data.function.record->data.
			function) (node_evaluate(node->data.function.
						 child));
		fprintf(stderr, "[lib/node.c] exit node_evaluate 4\n");

	case 'u':
		/* Unary operation node is evaluated according to
		 * operation type. */
		switch (node->data.un_op.operation) {
		case '-':
			fprintf(stderr, "[lib/node.c] enter node_evaluate 5\n");
			return -node_evaluate(node->data.un_op.child);
			fprintf(stderr, "[lib/node.c] exit node_evaluate 5\n");
		}

	case 'b':
		/* Binary operation node is evaluated according to
		 * operation type. */
		switch (node->data.un_op.operation) {
		case '+':
			fprintf(stderr, "[lib/node.c] enter node_evaluate 6\n");
			return node_evaluate(node->data.bin_op.left) +
			    node_evaluate(node->data.bin_op.right);
			fprintf(stderr, "[lib/node.c] exit node_evaluate 6\n");

		case '-':
			fprintf(stderr, "[lib/node.c] enter node_evaluate 7\n");
			return node_evaluate(node->data.bin_op.left) -
			    node_evaluate(node->data.bin_op.right);
			fprintf(stderr, "[lib/node.c] exit node_evaluate 7\n");

		case '*':
			fprintf(stderr, "[lib/node.c] enter node_evaluate 8\n");
			return node_evaluate(node->data.bin_op.left) *
			    node_evaluate(node->data.bin_op.right);
			fprintf(stderr, "[lib/node.c] exit node_evaluate 8\n");

		case '/':
			fprintf(stderr, "[lib/node.c] enter node_evaluate 9\n");
			return node_evaluate(node->data.bin_op.left) /
			    node_evaluate(node->data.bin_op.right);
			fprintf(stderr, "[lib/node.c] exit node_evaluate 9\n");

		case '^':
			fprintf(stderr, "[lib/node.c] enter node_evaluate 10\n");
			return pow(node_evaluate(node->data.bin_op.left),
				   node_evaluate(node->data.bin_op.right));
			fprintf(stderr, "[lib/node.c] exit node_evaluate 10\n");
		}
	}

	fprintf(stderr, "[lib/node.c] enter node_evaluate 11\n");
	return 0;
	fprintf(stderr, "[lib/node.c] exit node_evaluate 11\n");
}
Node           *
node_derivative(Node * node, char *name, SymbolTable * symbol_table)
{
	fprintf(stderr, "[lib/node.c] enter node_derivative 1\n");
	/* According to node type, derivative tree for subtree rooted at
	 * node is created. */
	switch (node->type) {
	case 'n':
		fprintf(stderr, "[lib/node.c] enter node_derivative 2\n");
		/* Derivative of number equals 0. */
		return node_create('n', 0.0);
		fprintf(stderr, "[lib/node.c] exit node_derivative 2\n");

	case 'c':
		fprintf(stderr, "[lib/node.c] enter node_derivative 3\n");
		/* Derivative of constant equals 0. */
		return node_create('n', 0.0);
		fprintf(stderr, "[lib/node.c] exit node_derivative 3\n");

	case 'v':
		fprintf(stderr, "[lib/node.c] enter node_derivative 4\n");
		/* Derivative of variable equals 1 if variable is
		 * derivative variable, 0 otherwise. */
		return node_create('n',
				   (!strcmp
				    (name,
				     node->data.variable->
				     name)) ? 1.0 : 0.0);
		fprintf(stderr, "[lib/node.c] exit node_derivative 4\n");

	case 'f':
		fprintf(stderr, "[lib/node.c] enter node_derivative 5\n");
		/* Apply rule of exponential function derivative. */
		if (!strcmp(node->data.function.record->name, "exp"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 6\n");
			return node_create('b', '*',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_copy(node));
			fprintf(stderr, "[lib/node.c] exit node_derivative 6\n");
		}
		/* Apply rule of logarithmic function derivative. */
		else if (!strcmp(node->data.function.record->name, "log"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 7\n");
			return node_create('b', '/',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_copy(node->data.function.
						     child));
			fprintf(stderr, "[lib/node.c] exit node_derivative 7\n");
		}
		/* Apply rule of square root function derivative. */
		else if (!strcmp(node->data.function.record->name, "sqrt"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 8\n");
			return node_create('b', '/',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('b', '*',
						       node_create('n',
								   2.0),
						       node_copy(node)));
			fprintf(stderr, "[lib/node.c] exit node_derivative 8\n");
		}
		/* Apply rule of sine function derivative. */
		else if (!strcmp(node->data.function.record->name, "sin"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 9\n");
			return node_create('b', '*',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('f',
						       symbol_table_lookup
						       (symbol_table,
							"cos"),
						       node_copy(node->
								 data.
								 function.
								 child)));
			fprintf(stderr, "[lib/node.c] exit node_derivative 9\n");
		}
		/* Apply rule of cosine function derivative. */
		else if (!strcmp(node->data.function.record->name, "cos"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 10\n");
			return node_create('u', '-',
					   node_create('b', '*',
						       node_derivative
						       (node->data.
							function.child,
							name,
							symbol_table),
						       node_create('f',
								   symbol_table_lookup
								   (symbol_table,
								    "sin"),
								   node_copy
								   (node->
								    data.
								    function.
								    child))));
			fprintf(stderr, "[lib/node.c] exit node_derivative 10\n");
		}
		/* Apply rule of tangent function derivative. */
		else if (!strcmp(node->data.function.record->name, "tan"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 11\n");
			return node_create('b', '/',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('b', '^',
						       node_create('f',
								   symbol_table_lookup
								   (symbol_table,
								    "cos"),
								   node_copy
								   (node->
								    data.
								    function.
								    child)),
						       node_create('n',
								   2.0)));
			fprintf(stderr, "[lib/node.c] exit node_derivative 11\n");
		}
		/* Apply rule of cotangent function derivative. */
		else if (!strcmp(node->data.function.record->name, "cot"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 12\n");
			return node_create('u', '-',
					   node_create('b', '/',
						       node_derivative
						       (node->data.
							function.child,
							name,
							symbol_table),
						       node_create('b',
								   '^',
								   node_create
								   ('f',
								    symbol_table_lookup
								    (symbol_table,
								     "sin"),
								    node_copy
								    (node->
								     data.
								     function.
								     child)),
								   node_create
								   ('n',
								    2.0))));
			fprintf(stderr, "[lib/node.c] exit node_derivative 12\n");
		}
		/* Apply rule of secant function derivative. */
		else if (!strcmp(node->data.function.record->name, "sec"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 13\n");
			return node_create('b', '*',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('b', '*',
						       node_create('f',
								   symbol_table_lookup
								   (symbol_table,
								    "sec"),
								   node_copy
								   (node->
								    data.
								    function.
								    child)),
						       node_create('f',
								   symbol_table_lookup
								   (symbol_table,
								    "tan"),
								   node_copy
								   (node->
								    data.
								    function.
								    child))));
			fprintf(stderr, "[lib/node.c] exit node_derivative 13\n");
		}
		/* Apply rule of cosecant function derivative. */
		else if (!strcmp(node->data.function.record->name, "csc"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 14\n");
			return node_create('b', '*',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('u', '-',
						       node_create('b',
								   '*',
								   node_create
								   ('f',
								    symbol_table_lookup
								    (symbol_table,
								     "cot"),
								    node_copy
								    (node->
								     data.
								     function.
								     child)),
								   node_create
								   ('f',
								    symbol_table_lookup
								    (symbol_table,
								     "csc"),
								    node_copy
								    (node->
								     data.
								     function.
								     child)))));
			fprintf(stderr, "[lib/node.c] exit node_derivative 14\n");
		}
		/* Apply rule of inverse sine function derivative. */
		else if (!strcmp(node->data.function.record->name, "asin"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 15\n");
			return node_create('b', '/',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('f',
						       symbol_table_lookup
						       (symbol_table,
							"sqrt"),
						       node_create('b',
								   '-',
								   node_create
								   ('n',
								    1.0),
								   node_create
								   ('b',
								    '^',
								    node_copy
								    (node->
								     data.
								     function.
								     child),
								    node_create
								    ('n',
								     2.0)))));
			fprintf(stderr, "[lib/node.c] exit node_derivative 15\n");
		}
		/* Apply rule of inverse cosine function derivative. */
		else if (!strcmp(node->data.function.record->name, "acos"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 16\n");
			return node_create('u', '-',
					   node_create('b', '/',
						       node_derivative
						       (node->data.
							function.child,
							name,
							symbol_table),
						       node_create('f',
								   symbol_table_lookup
								   (symbol_table,
								    "sqrt"),
								   node_create
								   ('b',
								    '-',
								    node_create
								    ('n',
								     1.0),
								    node_create
								    ('b',
								     '^',
								     node_copy
								     (node->
								      data.
								      function.
								      child),
								     node_create
								     ('n',
								      2.0))))));
			fprintf(stderr, "[lib/node.c] exit node_derivative 16\n");
		}
		/* Apply rule of inverse tangent function derivative. */
		else if (!strcmp(node->data.function.record->name, "atan"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 17\n");
			return node_create('b', '/',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('b', '+',
						       node_create('n',
								   1.0),
						       node_create('b',
								   '^',
								   node_copy
								   (node->
								    data.
								    function.
								    child),
								   node_create
								   ('n',
								    2.0))));
			fprintf(stderr, "[lib/node.c] exit node_derivative 17\n");
		}
		/* Apply rule of inverse cotanget function derivative. */
		else if (!strcmp(node->data.function.record->name, "acot"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 18\n");
			return node_create('u', '-',
					   node_create('b', '/',
						       node_derivative
						       (node->data.
							function.child,
							name,
							symbol_table),
						       node_create('b',
								   '+',
								   node_create
								   ('n',
								    1.0),
								   node_create
								   ('b',
								    '^',
								    node_copy
								    (node->
								     data.
								     function.
								     child),
								    node_create
								    ('n',
								     2.0)))));
			fprintf(stderr, "[lib/node.c] exit node_derivative 18\n");
		}
		/* Apply rule of inverse secant function derivative. */
		else if (!strcmp(node->data.function.record->name, "asec"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 19\n");
			return node_create('b', '*',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('b', '/',
						       node_create('n',
								   1.0),
						       node_create('b',
								   '*',
								   node_create
								   ('b',
								    '^',
								    node_copy
								    (node->
								     data.
								     function.
								     child),
								    node_create
								    ('n',
								     2.0)),
								   node_create
								   ('f',
								    symbol_table_lookup
								    (symbol_table,
								     "sqrt"),
								    node_create
								    ('b',
								     '-',
								     node_create
								     ('n',
								      1.0),
								     node_create
								     ('b',
								      '/',
								      node_create
								      ('n',
								       1.0),
								      node_create
								      ('b',
								       '^',
								       node_copy
								       (node->
									data.
									function.
									child),
								       node_create
								       ('n',
									2.0))))))));
			fprintf(stderr, "[lib/node.c] exit node_derivative 19\n");
		}
		/* Apply rule of inverse cosecant function derivative. */
		else if (!strcmp(node->data.function.record->name, "acsc"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 20\n");
			return node_create('b', '*',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('u', '-',
						       node_create('b',
								   '/',
								   node_create
								   ('n',
								    1.0),
								   node_create
								   ('b',
								    '*',
								    node_create
								    ('b',
								     '^',
								     node_copy
								     (node->
								      data.
								      function.
								      child),
								     node_create
								     ('n',
								      2.0)),
								    node_create
								    ('f',
								     symbol_table_lookup
								     (symbol_table,
								      "sqrt"),
								     node_create
								     ('b',
								      '-',
								      node_create
								      ('n',
								       1.0),
								      node_create
								      ('b',
								       '/',
								       node_create
								       ('n',
									1.0),
								       node_create
								       ('b',
									'^',
									node_copy
									(node->
									 data.
									 function.
									 child),
									node_create
									('n',
									 2.0)))))))));
			fprintf(stderr, "[lib/node.c] exit node_derivative 20\n");
		}
		/* Apply rule of hyperbolic sine function derivative. */
		else if (!strcmp(node->data.function.record->name, "sinh"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 21\n");
			return node_create('b', '*',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('f',
						       symbol_table_lookup
						       (symbol_table,
							"cosh"),
						       node_copy(node->
								 data.
								 function.
								 child)));
			fprintf(stderr, "[lib/node.c] exit node_derivative 21\n");
		}
		/* Apply rule of hyperbolic cosine function derivative. */
		else if (!strcmp(node->data.function.record->name, "cosh"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 22\n");
			return node_create('b', '*',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('f',
						       symbol_table_lookup
						       (symbol_table,
							"sinh"),
						       node_copy(node->
								 data.
								 function.
								 child)));
			fprintf(stderr, "[lib/node.c] exit node_derivative 22\n");
		}
		/* Apply rule of hyperbolic tangent function derivative. */
		else if (!strcmp(node->data.function.record->name, "tanh"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 23\n");
			return node_create('b', '/',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('b', '^',
						       node_create('f',
								   symbol_table_lookup
								   (symbol_table,
								    "cosh"),
								   node_copy
								   (node->
								    data.
								    function.
								    child)),
						       node_create('n',
								   2.0)));
			fprintf(stderr, "[lib/node.c] exit node_derivative 23\n");
		}
		/* Apply rule of hyperbolic cotangent function derivative. 
		 */
		else if (!strcmp(node->data.function.record->name, "coth"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 24\n");
			return node_create('u', '-',
					   node_create('b', '/',
						       node_derivative
						       (node->data.
							function.child,
							name,
							symbol_table),
						       node_create('b',
								   '^',
								   node_create
								   ('f',
								    symbol_table_lookup
								    (symbol_table,
								     "sinh"),
								    node_copy
								    (node->
								     data.
								     function.
								     child)),
								   node_create
								   ('n',
								    2.0))));
			fprintf(stderr, "[lib/node.c] exit node_derivative 24\n");
		}
		/* Apply rule of hyperbolic secant function derivative. */
		else if (!strcmp(node->data.function.record->name, "sech"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 25\n");
			return node_create('b', '*',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('u', '-',
						       node_create('b',
								   '*',
								   node_create
								   ('f',
								    symbol_table_lookup
								    (symbol_table,
								     "sech"),
								    node_copy
								    (node->
								     data.
								     function.
								     child)),
								   node_create
								   ('f',
								    symbol_table_lookup
								    (symbol_table,
								     "tanh"),
								    node_copy
								    (node->
								     data.
								     function.
								     child)))));
			fprintf(stderr, "[lib/node.c] exit node_derivative 25\n");
		}
		/* Apply rule of hyperbolic cosecant function derivative. */
		else if (!strcmp(node->data.function.record->name, "csch"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 26\n");
			return node_create('b', '*',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('u', '-',
						       node_create('b',
								   '*',
								   node_create
								   ('f',
								    symbol_table_lookup
								    (symbol_table,
								     "coth"),
								    node_copy
								    (node->
								     data.
								     function.
								     child)),
								   node_create
								   ('f',
								    symbol_table_lookup
								    (symbol_table,
								     "csch"),
								    node_copy
								    (node->
								     data.
								     function.
								     child)))));
			fprintf(stderr, "[lib/node.c] exit node_derivative 26\n");
		}
		/* Apply rule of inverse hyperbolic sine function
		 * derivative. */
		else if (!strcmp
			 (node->data.function.record->name, "asinh"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 27\n");
			return node_create('b', '/',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('f',
						       symbol_table_lookup
						       (symbol_table,
							"sqrt"),
						       node_create('b',
								   '-',
								   node_create
								   ('n',
								    1.0),
								   node_create
								   ('b',
								    '^',
								    node_copy
								    (node->
								     data.
								     function.
								     child),
								    node_create
								    ('n',
								     2.0)))));
			fprintf(stderr, "[lib/node.c] exit node_derivative 27\n");
		}
		/* Apply rule of inverse hyperbolic cosine function
		 * derivative. */
		else if (!strcmp
			 (node->data.function.record->name, "acosh"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 28\n");
			return node_create('b', '/',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('f',
						       symbol_table_lookup
						       (symbol_table,
							"sqrt"),
						       node_create('b',
								   '-',
								   node_create
								   ('b',
								    '^',
								    node_copy
								    (node->
								     data.
								     function.
								     child),
								    node_create
								    ('n',
								     2.0)),
								   node_create
								   ('n',
								    1.0))));
			fprintf(stderr, "[lib/node.c] exit node_derivative 28\n");
		}
		/* Apply rule of inverse hyperbolic tangent function
		 * derivative. */
		else if (!strcmp
			 (node->data.function.record->name, "atanh"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 29\n");
			return node_create('b', '/',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('b', '-',
						       node_create('n',
								   1.0),
						       node_create('b',
								   '^',
								   node_copy
								   (node->
								    data.
								    function.
								    child),
								   node_create
								   ('n',
								    2.0))));
			fprintf(stderr, "[lib/node.c] exit node_derivative 29\n");
		}
		/* Apply rule of inverse hyperbolic cotangent function
		 * derivative. */
		else if (!strcmp
			 (node->data.function.record->name, "acoth"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 30\n");
			return node_create('b', '/',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('b', '-',
						       node_create('b',
								   '^',
								   node_copy
								   (node->
								    data.
								    function.
								    child),
								   node_create
								   ('n',
								    2.0)),
						       node_create('n',
								   1.0)));
			fprintf(stderr, "[lib/node.c] exit node_derivative 30\n");
		}
		/* Apply rule of inverse hyperbolic secant function
		 * derivative. */
		else if (!strcmp
			 (node->data.function.record->name, "asech"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 31\n");
			return node_create('b', '*',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('u', '-',
						       node_create('b',
								   '*',
								   node_create
								   ('b',
								    '/',
								    node_create
								    ('n',
								     1.0),
								    node_create
								    ('b',
								     '*',
								     node_copy
								     (node->
								      data.
								      function.
								      child),
								     node_create
								     ('f',
								      symbol_table_lookup
								      (symbol_table,
								       "sqrt"),
								      node_create
								      ('b',
								       '-',
								       node_create
								       ('n',
									1.0),
								       node_copy
								       (node->
									data.
									function.
									child))))),
								   node_create
								   ('f',
								    symbol_table_lookup
								    (symbol_table,
								     "sqrt"),
								    node_create
								    ('b',
								     '/',
								     node_create
								     ('n',
								      1.0),
								     node_create
								     ('b',
								      '+',
								      node_create
								      ('n',
								       1.0),
								      node_copy
								      (node->
								       data.
								       function.
								       child)))))));
			fprintf(stderr, "[lib/node.c] exit node_derivative 31\n");
		}
		/* Apply rule of inverse hyperbolic cosecant function
		 * derivative. */
		else if (!strcmp
			 (node->data.function.record->name, "acsch"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 32\n");
			return node_create('b', '*',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('u', '-',
						       node_create('b',
								   '/',
								   node_create
								   ('n',
								    1.0),
								   node_create
								   ('b',
								    '*',
								    node_create
								    ('b',
								     '^',
								     node_copy
								     (node->
								      data.
								      function.
								      child),
								     node_create
								     ('n',
								      2.0)),
								    node_create
								    ('f',
								     symbol_table_lookup
								     (symbol_table,
								      "sqrt"),
								     node_create
								     ('b',
								      '+',
								      node_create
								      ('n',
								       1.0),
								      node_create
								      ('b',
								       '/',
								       node_create
								       ('n',
									1.0),
								       node_create
								       ('b',
									'^',
									node_copy
									(node->
									 data.
									 function.
									 child),
									node_create
									('n',
									 2.0)))))))));
			fprintf(stderr, "[lib/node.c] exit node_derivative 32\n");
		}
		/* Apply rule of absolute value function derivative. */
		else if (!strcmp(node->data.function.record->name, "abs"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 33\n");
			return node_create('b', '*',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('b', '-',
						       node_create('b',
								   '*',
								   node_create
								   ('n',
								    2.0),
								   node_create
								   ('f',
								    symbol_table_lookup
								    (symbol_table,
								     "step"),
								    node_copy
								    (node->
								     data.
								     function.
								     child))),
						       node_create('n',
								   1.0)));
			fprintf(stderr, "[lib/node.c] exit node_derivative 33\n");
		}
		/* Apply rule of step function derivative. */
		else if (!strcmp(node->data.function.record->name, "step"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 34\n");
			return node_create('b', '*',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('f',
						       symbol_table_lookup
						       (symbol_table,
							"delta"),
						       node_copy(node->
								 data.
								 function.
								 child)));
			fprintf(stderr, "[lib/node.c] exit node_derivative 34\n");
		}
		/* Apply rule of delta function derivative. */
		else if (!strcmp
			 (node->data.function.record->name, "delta"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 35\n");
			return node_create('b', '*',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('f',
						       symbol_table_lookup
						       (symbol_table,
							"nandelta"),
						       node_copy(node->
								 data.
								 function.
								 child)));
			fprintf(stderr, "[lib/node.c] exit node_derivative 35\n");
		}
		/* Apply rule of nandelta function derivative. */
		else if (!strcmp
			 (node->data.function.record->name, "nandelta"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 36\n");
			return node_create('b', '*',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('f',
						       symbol_table_lookup
						       (symbol_table,
							"nandelta"),
						       node_copy(node->
								 data.
								 function.
								 child)));
			fprintf(stderr, "[lib/node.c] exit node_derivative 36\n");
		}
		/* Apply rule of erf function derivative. */
		else if (!strcmp(node->data.function.record->name, "erf"))
		{
			fprintf(stderr, "[lib/node.c] enter node_derivative 37\n");
			return node_create('b', '*',
					   node_derivative(node->data.
							   function.child,
							   name,
							   symbol_table),
					   node_create('b', '*',
						       node_create('c',
								   symbol_table_lookup
								   (symbol_table,
								    "2_sqrtpi")),
						       node_create('f',
								   symbol_table_lookup
								   (symbol_table,
								    "exp"),
								   node_create
								   ('u',
								    '-',
								    node_create
								    ('b',
								     '^',
								     node_copy
								     (node->
								      data.
								      function.
								      child),
								     node_create
								     ('n',
								      2.0))))));
			fprintf(stderr, "[lib/node.c] exit node_derivative 37\n");
		}
		fprintf(stderr, "[lib/node.c] exit node_derivative 5\n");

	case 'u':
		fprintf(stderr, "[lib/node.c] enter node_derivative 38\n");
		switch (node->data.un_op.operation) {
		case '-':
			fprintf(stderr, "[lib/node.c] enter node_derivative 39\n");
			/* Apply (-f)'=-f' derivative rule. */
			return node_create('u', '-',
					   node_derivative(node->data.
							   un_op.child,
							   name,
							   symbol_table));
			fprintf(stderr, "[lib/node.c] exit node_derivative 39\n");
		}
		fprintf(stderr, "[lib/node.c] exit node_derivative 38\n");

	case 'b':
		fprintf(stderr, "[lib/node.c] enter node_derivative 40\n");
		switch (node->data.bin_op.operation) {
		case '+':
			fprintf(stderr, "[lib/node.c] enter node_derivative 41\n");
			/* Apply (f+g)'=f'+g' derivative rule. */
			return node_create('b', '+',
					   node_derivative(node->data.
							   bin_op.left,
							   name,
							   symbol_table),
					   node_derivative(node->data.
							   bin_op.right,
							   name,
							   symbol_table));
			fprintf(stderr, "[lib/node.c] exit node_derivative 41\n");

		case '-':
			fprintf(stderr, "[lib/node.c] enter node_derivative 42\n");
			/* Apply (f-g)'=f'-g' derivative rule. */
			return node_create('b', '-',
					   node_derivative(node->data.
							   bin_op.left,
							   name,
							   symbol_table),
					   node_derivative(node->data.
							   bin_op.right,
							   name,
							   symbol_table));
			fprintf(stderr, "[lib/node.c] exit node_derivative 42\n");

		case '*':
			fprintf(stderr, "[lib/node.c] enter node_derivative 43\n");
			/* Apply (f*g)'=f'*g+f*g' derivative rule. */
			return node_create('b', '+',
					   node_create('b', '*',
						       node_derivative
						       (node->data.bin_op.
							left, name,
							symbol_table),
						       node_copy(node->
								 data.
								 bin_op.
								 right)),
					   node_create('b', '*',
						       node_copy(node->
								 data.
								 bin_op.
								 left),
						       node_derivative
						       (node->data.bin_op.
							right, name,
							symbol_table)));
			fprintf(stderr, "[lib/node.c] exit node_derivative 43\n");

		case '/':
			fprintf(stderr, "[lib/node.c] enter node_derivative 44\n");
			/* Apply (f/g)'=(f'*g-f*g')/g^2 derivative rule. */
			return node_create('b', '/',
					   node_create('b', '-',
						       node_create('b',
								   '*',
								   node_derivative
								   (node->
								    data.
								    bin_op.
								    left,
								    name,
								    symbol_table),
								   node_copy
								   (node->
								    data.
								    bin_op.
								    right)),
						       node_create('b',
								   '*',
								   node_copy
								   (node->
								    data.
								    bin_op.
								    left),
								   node_derivative
								   (node->
								    data.
								    bin_op.
								    right,
								    name,
								    symbol_table))),
					   node_create('b', '^',
						       node_copy(node->
								 data.
								 bin_op.
								 right),
						       node_create('n',
								   2.0)));
			fprintf(stderr, "[lib/node.c] exit node_derivative 44\n");

		case '^':
			fprintf(stderr, "[lib/node.c] enter node_derivative 45\n");
			/* If right operand of exponentiation number apply 
			 * (f^n)'=n*f^(n-1)*f' derivative rule. */
			if (node->data.bin_op.right->type == 'n')
			{
				fprintf(stderr, "[lib/node.c] enter node_derivative 46\n");
				return node_create('b', '*',
						   node_create('b', '*',
							       node_create
							       ('n',
								node->data.
								bin_op.
								right->
								data.
								number),
							       node_derivative
							       (node->data.
								bin_op.
								left, name,
								symbol_table)),
						   node_create('b', '^',
							       node_copy
							       (node->data.
								bin_op.
								left),
							       node_create
							       ('n',
								node->data.
								bin_op.
								right->
								data.
								number -
								1.0)));
				fprintf(stderr, "[lib/node.c] exit node_derivative 46\n");
			}
			/* Otherwise, apply logarithmic derivative rule:
			 * (log(f^g))'=(f^g)'/f^g =>
			 * (f^g)'=f^g*(log(f^g))'=f^g*(g*log(f))' */
			else {
				fprintf(stderr, "[lib/node.c] enter node_derivative 47\n");
				Node           *log_node,
				               *derivative;

				log_node =
				    node_create('b', '*',
						node_copy(node->data.
							  bin_op.right),
						node_create('f',
							    symbol_table_lookup
							    (symbol_table,
							     "log"),
							    node_copy
							    (node->data.
							     bin_op.
							     left)));
				derivative =
				    node_create('b', '*', node_copy(node),
						node_derivative(log_node,
								name,
								symbol_table));
				node_destroy(log_node);
				return derivative;
				fprintf(stderr, "[lib/node.c] exit node_derivative 47\n");
			}
			fprintf(stderr, "[lib/node.c] exit node_derivative 45\n");
		}
		fprintf(stderr, "[lib/node.c] exit node_derivative 40\n");
	}
	fprintf(stderr, "[lib/node.c] exit node_derivative 1\n");
}
void
node_flag_variables(Node * node)
{
	fprintf(stderr, "[lib/node.c] enter node_flag_variables 1\n");
	/* According to node type, flag variable in symbol table or
	 * proceed with calling function recursively on node children. */
	switch (node->type) {
	case 'v':
		fprintf(stderr, "[lib/node.c] enter node_flag_variables 2\n");
		node->data.variable->flag = TRUE;
		break;
		fprintf(stderr, "[lib/node.c] exit node_flag_variables 2\n");

	case 'f':
		fprintf(stderr, "[lib/node.c] enter node_flag_variables 3\n");
		node_flag_variables(node->data.function.child);
		break;
		fprintf(stderr, "[lib/node.c] exit node_flag_variables 3\n");

	case 'u':
		fprintf(stderr, "[lib/node.c] enter node_flag_variables 4\n");
		node_flag_variables(node->data.un_op.child);
		break;
		fprintf(stderr, "[lib/node.c] exit node_flag_variables 4\n");

	case 'b':
		fprintf(stderr, "[lib/node.c] enter node_flag_variables 5\n");
		node_flag_variables(node->data.bin_op.left);
		node_flag_variables(node->data.bin_op.right);
		break;
		fprintf(stderr, "[lib/node.c] exit node_flag_variables 5\n");
	}
	fprintf(stderr, "[lib/node.c] exit node_flag_variables 1\n");
}

int
node_get_length(Node * node)
{
	fprintf(stderr, "[lib/node.c] enter node_get_length 1\n");
	FILE           *file;	/* Temporary file. */
	int             count;	/* Count of bytes written to above file. */
	int             length;	/* Length of above string. */

	/* According to node type, calculate length of string representing 
	 * subtree rooted at node. */
	switch (node->type) {
	case 'n':
		fprintf(stderr, "[lib/node.c] enter node_get_length 2\n");
		length = 0;
		if (node->data.number < 0)
		{
			fprintf(stderr, "[lib/node.c] enter node_get_length 3\n");
			length += 1;
			fprintf(stderr, "[lib/node.c] exit node_get_length 3\n");
		}

		file = tmpfile();
		if (file) {
			fprintf(stderr, "[lib/node.c] enter node_get_length 4\n");
			if ((count =
			     fprintf(file, "%g", node->data.number)) >= 0)
			{
				fprintf(stderr, "[lib/node.c] enter node_get_length 5\n");
				length += count;
				fprintf(stderr, "[lib/node.c] exit node_get_length 5\n");
			}
			fclose(file);
			fprintf(stderr, "[lib/node.c] exit node_get_length 4\n");
		}

		if (node->data.number < 0)
		{
			fprintf(stderr, "[lib/node.c] enter node_get_length 6\n");
			length += 1;
			fprintf(stderr, "[lib/node.c] exit node_get_length 6\n");
		}
		return length;
		fprintf(stderr, "[lib/node.c] exit node_get_length 2\n");

	case 'c':
		fprintf(stderr, "[lib/node.c] enter node_get_length 7\n");
		return strlen(node->data.constant->name);
		fprintf(stderr, "[lib/node.c] exit node_get_length 7\n");

	case 'v':
		fprintf(stderr, "[lib/node.c] enter node_get_length 8\n");
		return strlen(node->data.variable->name);
		fprintf(stderr, "[lib/node.c] exit node_get_length 8\n");

	case 'f':
		fprintf(stderr, "[lib/node.c] enter node_get_length 9\n");
		return strlen(node->data.function.record->name) + 1 +
		    node_get_length(node->data.function.child) + 1;
		break;
		fprintf(stderr, "[lib/node.c] exit node_get_length 9\n");

	case 'u':
		fprintf(stderr, "[lib/node.c] enter node_get_length 10\n");
		return 1 + 1 + node_get_length(node->data.un_op.child) + 1;
		fprintf(stderr, "[lib/node.c] exit node_get_length 10\n");

	case 'b':
		fprintf(stderr, "[lib/node.c] enter node_get_length 11\n");
		return 1 + node_get_length(node->data.bin_op.left) + 1 +
		    node_get_length(node->data.bin_op.right) + 1;
		fprintf(stderr, "[lib/node.c] exit node_get_length 11\n");
	}

	fprintf(stderr, "[lib/node.c] enter node_get_length 12\n");
	return 0;
	fprintf(stderr, "[lib/node.c] exit node_get_length 12\n");
	fprintf(stderr, "[lib/node.c] exit node_get_length 1\n");
}

void
node_write(Node * node, char *string)
{
	fprintf(stderr, "[lib/node.c] enter node_write 1\n");
	/* According to node type, write subtree rooted at node to node
	 * string variable.  Always use parenthesis to resolve operation
	 * precedence. */
	switch (node->type) {
	case 'n':
		fprintf(stderr, "[lib/node.c] enter node_write 2\n");
		if (node->data.number < 0) {
			fprintf(stderr, "[lib/node.c] enter node_write 3\n");
			sprintf(string, "%c", '(');
			string += strlen(string);
			fprintf(stderr, "[lib/node.c] exit node_write 3\n");
		}
		sprintf(string, "%g", node->data.number);
		string += strlen(string);
		if (node->data.number < 0)
		{
			fprintf(stderr, "[lib/node.c] enter node_write 4\n");
			sprintf(string, "%c", ')');
			fprintf(stderr, "[lib/node.c] exit node_write 4\n");
		}
		break;
		fprintf(stderr, "[lib/node.c] exit node_write 2\n");

	case 'c':
		fprintf(stderr, "[lib/node.c] enter node_write 5\n");
		sprintf(string, "%s", node->data.constant->name);
		break;
		fprintf(stderr, "[lib/node.c] exit node_write 5\n");

	case 'v':
		fprintf(stderr, "[lib/node.c] enter node_write 6\n");
		sprintf(string, "%s", node->data.variable->name);
		break;
		fprintf(stderr, "[lib/node.c] exit node_write 6\n");

	case 'f':
		fprintf(stderr, "[lib/node.c] enter node_write 7\n");
		sprintf(string, "%s%c", node->data.function.record->name,
			'(');
		string += strlen(string);
		node_write(node->data.function.child, string);
		string += strlen(string);
		sprintf(string, "%c", ')');
		break;
		fprintf(stderr, "[lib/node.c] exit node_write 7\n");

	case 'u':
		fprintf(stderr, "[lib/node.c] enter node_write 8\n");
		sprintf(string, "%c", '(');
		string += strlen(string);
		sprintf(string, "%c", node->data.un_op.operation);
		string += strlen(string);
		node_write(node->data.un_op.child, string);
		string += strlen(string);
		sprintf(string, "%c", ')');
		break;
		fprintf(stderr, "[lib/node.c] exit node_write 8\n");

	case 'b':
		fprintf(stderr, "[lib/node.c] enter node_write 9\n");
		sprintf(string, "%c", '(');
		string += strlen(string);
		node_write(node->data.bin_op.left, string);
		string += strlen(string);
		sprintf(string, "%c", node->data.bin_op.operation);
		string += strlen(string);
		node_write(node->data.bin_op.right, string);
		string += strlen(string);
		sprintf(string, "%c", ')');
		break;
		fprintf(stderr, "[lib/node.c] exit node_write 9\n");
	}
	fprintf(stderr, "[lib/node.c] exit node_write 1\n");
}
// Total cost: 0.346946
// Total split cost: 0.012747, input tokens: 27678, output tokens: 257, cache read tokens: 27460, cache write tokens: 0, split chunks: [(0, 368), (368, 1381), (1381, 1513)]
// Total instrumented cost: 0.334199, input tokens: 19175, output tokens: 17086, cache read tokens: 7981, cache write tokens: 11182

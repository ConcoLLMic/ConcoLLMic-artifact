
#include <yaml.h>

#include <stdlib.h>
#include <stdio.h>

int
main(int argc, char *argv[])
{
    fprintf(stderr, "[tests/example-reformatter.c] enter main 1\n");
    int help = 0;
    int canonical = 0;
    int unicode = 0;
    int k;
    int done = 0;

    yaml_parser_t parser;
    yaml_emitter_t emitter;
    yaml_event_t event;

    /* Clear the objects. */

    memset(&parser, 0, sizeof(parser));
    memset(&emitter, 0, sizeof(emitter));
    memset(&event, 0, sizeof(event));
    fprintf(stderr, "[tests/example-reformatter.c] exit main 1\n");

    /* Analyze command line options. */

    for (k = 1; k < argc; k ++)
    {
        fprintf(stderr, "[tests/example-reformatter.c] enter main 2\n");
        if (strcmp(argv[k], "-h") == 0
                || strcmp(argv[k], "--help") == 0) {
            fprintf(stderr, "[tests/example-reformatter.c] enter main 3\n");
            help = 1;
            fprintf(stderr, "[tests/example-reformatter.c] exit main 3\n");
        }

        else if (strcmp(argv[k], "-c") == 0
                || strcmp(argv[k], "--canonical") == 0) {
            fprintf(stderr, "[tests/example-reformatter.c] enter main 4\n");
            canonical = 1;
            fprintf(stderr, "[tests/example-reformatter.c] exit main 4\n");
        }

        else if (strcmp(argv[k], "-u") == 0
                || strcmp(argv[k], "--unicode") == 0) {
            fprintf(stderr, "[tests/example-reformatter.c] enter main 5\n");
            unicode = 1;
            fprintf(stderr, "[tests/example-reformatter.c] exit main 5\n");
        }

        else {
            fprintf(stderr, "[tests/example-reformatter.c] enter main 6\n");
            fprintf(stderr, "Unrecognized option: %s\n"
                    "Try `%s --help` for more information.\n",
                    argv[k], argv[0]);
            return 1;
            fprintf(stderr, "[tests/example-reformatter.c] exit main 6\n");
        }
        fprintf(stderr, "[tests/example-reformatter.c] exit main 2\n");
    }

    /* Display the help string. */

    if (help)
    {
        fprintf(stderr, "[tests/example-reformatter.c] enter main 7\n");
        printf("%s [--canonical] [--unicode] <input >output\n"
                "or\n%s -h | --help\nReformat a YAML stream\n\nOptions:\n"
                "-h, --help\t\tdisplay this help and exit\n"
                "-c, --canonical\t\toutput in the canonical YAML format\n"
                "-u, --unicode\t\toutput unescaped non-ASCII characters\n",
                argv[0], argv[0]);
        return 0;
        fprintf(stderr, "[tests/example-reformatter.c] exit main 7\n");
    }

    /* Initialize the parser and emitter objects. */
    fprintf(stderr, "[tests/example-reformatter.c] enter main 8\n");
    if (!yaml_parser_initialize(&parser))
        goto parser_error;
    fprintf(stderr, "[tests/example-reformatter.c] exit main 8\n");

    fprintf(stderr, "[tests/example-reformatter.c] enter main 9\n");
    if (!yaml_emitter_initialize(&emitter))
        goto emitter_error;
    fprintf(stderr, "[tests/example-reformatter.c] exit main 9\n");

    /* Set the parser parameters. */
    fprintf(stderr, "[tests/example-reformatter.c] enter main 10\n");
    yaml_parser_set_input_file(&parser, stdin);

    /* Set the emitter parameters. */

    yaml_emitter_set_output_file(&emitter, stdout);

    yaml_emitter_set_canonical(&emitter, canonical);
    yaml_emitter_set_unicode(&emitter, unicode);
    fprintf(stderr, "[tests/example-reformatter.c] exit main 10\n");

    /* The main loop. */

    while (!done)
    {
        fprintf(stderr, "[tests/example-reformatter.c] enter main 11\n");
        /* Get the next event. */

        if (!yaml_parser_parse(&parser, &event))
            goto parser_error;
        fprintf(stderr, "[tests/example-reformatter.c] exit main 11\n");

        /* Check if this is the stream end. */
        fprintf(stderr, "[tests/example-reformatter.c] enter main 12\n");
        if (event.type == YAML_STREAM_END_EVENT) {
            fprintf(stderr, "[tests/example-reformatter.c] enter main 13\n");
            done = 1;
            fprintf(stderr, "[tests/example-reformatter.c] exit main 13\n");
        }
        fprintf(stderr, "[tests/example-reformatter.c] exit main 12\n");

        /* Emit the event. */
        fprintf(stderr, "[tests/example-reformatter.c] enter main 14\n");
        if (!yaml_emitter_emit(&emitter, &event))
            goto emitter_error;
        fprintf(stderr, "[tests/example-reformatter.c] exit main 14\n");
    }

    fprintf(stderr, "[tests/example-reformatter.c] enter main 15\n");
    yaml_parser_delete(&parser);
    yaml_emitter_delete(&emitter);

    return 0;
    fprintf(stderr, "[tests/example-reformatter.c] exit main 15\n");

parser_error:
    fprintf(stderr, "[tests/example-reformatter.c] enter main 16\n");
    /* Display a parser error message. */

    switch (parser.error)
    {
        case YAML_MEMORY_ERROR:
            fprintf(stderr, "[tests/example-reformatter.c] enter main 17\n");
            fprintf(stderr, "Memory error: Not enough memory for parsing\n");
            break;
            fprintf(stderr, "[tests/example-reformatter.c] exit main 17\n");

        case YAML_READER_ERROR:
            fprintf(stderr, "[tests/example-reformatter.c] enter main 18\n");
            if (parser.problem_value != -1) {
                fprintf(stderr, "[tests/example-reformatter.c] enter main 19\n");
                fprintf(stderr, "Reader error: %s: #%X at %ld\n", parser.problem,
                        parser.problem_value, (long)parser.problem_offset);
                fprintf(stderr, "[tests/example-reformatter.c] exit main 19\n");
            }
            else {
                fprintf(stderr, "[tests/example-reformatter.c] enter main 20\n");
                fprintf(stderr, "Reader error: %s at %ld\n", parser.problem,
                        (long)parser.problem_offset);
                fprintf(stderr, "[tests/example-reformatter.c] exit main 20\n");
            }
            break;
            fprintf(stderr, "[tests/example-reformatter.c] exit main 18\n");

        case YAML_SCANNER_ERROR:
            fprintf(stderr, "[tests/example-reformatter.c] enter main 21\n");
            if (parser.context) {
                fprintf(stderr, "[tests/example-reformatter.c] enter main 22\n");
                fprintf(stderr, "Scanner error: %s at line %d, column %d\n"
                        "%s at line %d, column %d\n", parser.context,
                        (int)parser.context_mark.line+1, (int)parser.context_mark.column+1,
                        parser.problem, (int)parser.problem_mark.line+1,
                        (int)parser.problem_mark.column+1);
                fprintf(stderr, "[tests/example-reformatter.c] exit main 22\n");
            }
            else {
                fprintf(stderr, "[tests/example-reformatter.c] enter main 23\n");
                fprintf(stderr, "Scanner error: %s at line %d, column %d\n",
                        parser.problem, (int)parser.problem_mark.line+1,
                        (int)parser.problem_mark.column+1);
                fprintf(stderr, "[tests/example-reformatter.c] exit main 23\n");
            }
            break;
            fprintf(stderr, "[tests/example-reformatter.c] exit main 21\n");

        case YAML_PARSER_ERROR:
            fprintf(stderr, "[tests/example-reformatter.c] enter main 24\n");
            if (parser.context) {
                fprintf(stderr, "[tests/example-reformatter.c] enter main 25\n");
                fprintf(stderr, "Parser error: %s at line %d, column %d\n"
                        "%s at line %d, column %d\n", parser.context,
                        (int)parser.context_mark.line+1, (int)parser.context_mark.column+1,
                        parser.problem, (int)parser.problem_mark.line+1,
                        (int)parser.problem_mark.column+1);
                fprintf(stderr, "[tests/example-reformatter.c] exit main 25\n");
            }
            else {
                fprintf(stderr, "[tests/example-reformatter.c] enter main 26\n");
                fprintf(stderr, "Parser error: %s at line %d, column %d\n",
                        parser.problem, (int)parser.problem_mark.line+1,
                        (int)parser.problem_mark.column+1);
                fprintf(stderr, "[tests/example-reformatter.c] exit main 26\n");
            }
            break;
            fprintf(stderr, "[tests/example-reformatter.c] exit main 24\n");

        default:
            fprintf(stderr, "[tests/example-reformatter.c] enter main 27\n");
            /* Couldn't happen. */
            fprintf(stderr, "Internal error\n");
            break;
            fprintf(stderr, "[tests/example-reformatter.c] exit main 27\n");
    }

    yaml_parser_delete(&parser);
    yaml_emitter_delete(&emitter);

    return 1;
    fprintf(stderr, "[tests/example-reformatter.c] exit main 16\n");

emitter_error:
    fprintf(stderr, "[tests/example-reformatter.c] enter main 28\n");
    /* Display an emitter error message. */

    switch (emitter.error)
    {
        case YAML_MEMORY_ERROR:
            fprintf(stderr, "[tests/example-reformatter.c] enter main 29\n");
            fprintf(stderr, "Memory error: Not enough memory for emitting\n");
            break;
            fprintf(stderr, "[tests/example-reformatter.c] exit main 29\n");

        case YAML_WRITER_ERROR:
            fprintf(stderr, "[tests/example-reformatter.c] enter main 30\n");
            fprintf(stderr, "Writer error: %s\n", emitter.problem);
            break;
            fprintf(stderr, "[tests/example-reformatter.c] exit main 30\n");

        case YAML_EMITTER_ERROR:
            fprintf(stderr, "[tests/example-reformatter.c] enter main 31\n");
            fprintf(stderr, "Emitter error: %s\n", emitter.problem);
            break;
            fprintf(stderr, "[tests/example-reformatter.c] exit main 31\n");

        default:
            fprintf(stderr, "[tests/example-reformatter.c] enter main 32\n");
            /* Couldn't happen. */
            fprintf(stderr, "Internal error\n");
            break;
            fprintf(stderr, "[tests/example-reformatter.c] exit main 32\n");
    }

    yaml_parser_delete(&parser);
    yaml_emitter_delete(&emitter);

    return 1;
    fprintf(stderr, "[tests/example-reformatter.c] exit main 28\n");
}
// Total cost: 0.065650
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 202)]
// Total instrumented cost: 0.065650, input tokens: 3997, output tokens: 2579, cache read tokens: 0, cache write tokens: 3993

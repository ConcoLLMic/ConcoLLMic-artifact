
#include <yaml.h>

#include <stdlib.h>
#include <stdio.h>

int
main(int argc, char *argv[])
{
    fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 1\n");
    int help = 0;
    int canonical = 0;
    int unicode = 0;
    int k;
    int done = 0;

    yaml_parser_t parser;
    yaml_emitter_t emitter;
    yaml_event_t input_event;
    yaml_document_t output_document;

    int root;

    /* Clear the objects. */

    memset(&parser, 0, sizeof(parser));
    memset(&emitter, 0, sizeof(emitter));
    memset(&input_event, 0, sizeof(input_event));
    memset(&output_document, 0, sizeof(output_document));
    fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 1\n");

    /* Analyze command line options. */

    for (k = 1; k < argc; k ++)
    {
        fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 2\n");
        if (strcmp(argv[k], "-h") == 0
                || strcmp(argv[k], "--help") == 0) {
            fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 3\n");
            help = 1;
            fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 3\n");
        }

        else if (strcmp(argv[k], "-c") == 0
                || strcmp(argv[k], "--canonical") == 0) {
            fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 4\n");
            canonical = 1;
            fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 4\n");
        }

        else if (strcmp(argv[k], "-u") == 0
                || strcmp(argv[k], "--unicode") == 0) {
            fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 5\n");
            unicode = 1;
            fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 5\n");
        }

        else {
            fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 6\n");
            fprintf(stderr, "Unrecognized option: %s\n"
                    "Try `%s --help` for more information.\n",
                    argv[k], argv[0]);
            return 1;
            fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 6\n");
        }
        fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 2\n");
    }

    /* Display the help string. */

    if (help)
    {
        fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 7\n");
        printf("%s <input\n"
                "or\n%s -h | --help\nDeconstruct a YAML stream\n\nOptions:\n"
                "-h, --help\t\tdisplay this help and exit\n"
                "-c, --canonical\t\toutput in the canonical YAML format\n"
                "-u, --unicode\t\toutput unescaped non-ASCII characters\n",
                argv[0], argv[0]);
        return 0;
        fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 7\n");
    }

    /* Initialize the parser and emitter objects. */

    if (!yaml_parser_initialize(&parser)) {
        fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 8\n");
        fprintf(stderr, "Could not initialize the parser object\n");
        return 1;
        fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 8\n");
    }

    if (!yaml_emitter_initialize(&emitter)) {
        fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 9\n");
        yaml_parser_delete(&parser);
        fprintf(stderr, "Could not inialize the emitter object\n");
        return 1;
        fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 9\n");
    }

    /* Set the parser parameters. */
    fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 10\n");
    yaml_parser_set_input_file(&parser, stdin);

    /* Set the emitter parameters. */

    yaml_emitter_set_output_file(&emitter, stdout);

    yaml_emitter_set_canonical(&emitter, canonical);
    yaml_emitter_set_unicode(&emitter, unicode);

    /* Create and emit the STREAM-START event. */

    if (!yaml_emitter_open(&emitter))
        goto emitter_error;

    /* Create a output_document object. */

    if (!yaml_document_initialize(&output_document, NULL, NULL, NULL, 0, 0))
        goto document_error;

    /* Create the root sequence. */

    root = yaml_document_add_sequence(&output_document, NULL,
            YAML_BLOCK_SEQUENCE_STYLE);
    if (!root) goto document_error;
    fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 10\n");

    /* Loop through the input events. */

    while (!done)
    {
        fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 11\n");
        int properties, key, value, map, seq;

        /* Get the next event. */

        if (!yaml_parser_parse(&parser, &input_event))
            goto parser_error;

        /* Check if this is the stream end. */

        if (input_event.type == YAML_STREAM_END_EVENT) {
            fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 12\n");
            done = 1;
            fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 12\n");
        }

        /* Create a mapping node and attach it to the root sequence. */

        properties = yaml_document_add_mapping(&output_document, NULL,
                YAML_BLOCK_MAPPING_STYLE);
        if (!properties) goto document_error;
        if (!yaml_document_append_sequence_item(&output_document,
                    root, properties)) goto document_error;

        /* Analyze the event. */

        switch (input_event.type)
        {
            case YAML_STREAM_START_EVENT:
                fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 13\n");
                /* Add 'type': 'STREAM-START'. */

                key = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"type", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!key) goto document_error;
                value = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"STREAM-START", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!value) goto document_error;
                if (!yaml_document_append_mapping_pair(&output_document,
                            properties, key, value)) goto document_error;

                /* Add 'encoding': <encoding>. */

                if (input_event.data.stream_start.encoding)
                {
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 14\n");
                    yaml_encoding_t encoding
                        = input_event.data.stream_start.encoding;

                    key = yaml_document_add_scalar(&output_document, NULL,
                        (yaml_char_t *)"encoding", -1, YAML_PLAIN_SCALAR_STYLE);
                    if (!key) goto document_error;
                    value = yaml_document_add_scalar(&output_document, NULL,
                            (yaml_char_t *)(encoding == YAML_UTF8_ENCODING ? "utf-8" :
                             encoding == YAML_UTF16LE_ENCODING ? "utf-16-le" :
                             encoding == YAML_UTF16BE_ENCODING ? "utf-16-be" :
                             "unknown"), -1, YAML_PLAIN_SCALAR_STYLE);
                    if (!value) goto document_error;
                    if (!yaml_document_append_mapping_pair(&output_document,
                                properties, key, value)) goto document_error;
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 14\n");
                }
                fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 13\n");
                break;

            case YAML_STREAM_END_EVENT:
                fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 15\n");
                /* Add 'type': 'STREAM-END'. */

                key = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"type", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!key) goto document_error;
                value = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"STREAM-END", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!value) goto document_error;
                if (!yaml_document_append_mapping_pair(&output_document,
                            properties, key, value)) goto document_error;
                fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 15\n");
                break;

            case YAML_DOCUMENT_START_EVENT:
                fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 16\n");
                /* Add 'type': 'DOCUMENT-START'. */

                key = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"type", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!key) goto document_error;
                value = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"DOCUMENT-START", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!value) goto document_error;
                if (!yaml_document_append_mapping_pair(&output_document,
                            properties, key, value)) goto document_error;

                /* Display the output_document version numbers. */

                if (input_event.data.document_start.version_directive)
                {
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 17\n");
                    yaml_version_directive_t *version
                        = input_event.data.document_start.version_directive;
                    char number[64];

                    /* Add 'version': {}. */
                    
                    key = yaml_document_add_scalar(&output_document, NULL,
                        (yaml_char_t *)"version", -1, YAML_PLAIN_SCALAR_STYLE);
                    if (!key) goto document_error;
                    map = yaml_document_add_mapping(&output_document, NULL,
                            YAML_FLOW_MAPPING_STYLE);
                    if (!map) goto document_error;
                    if (!yaml_document_append_mapping_pair(&output_document,
                                properties, key, map)) goto document_error;

                    /* Add 'major': <number>. */

                    key = yaml_document_add_scalar(&output_document, NULL,
                        (yaml_char_t *)"major", -1, YAML_PLAIN_SCALAR_STYLE);
                    if (!key) goto document_error;
                    sprintf(number, "%d", version->major);
                    value = yaml_document_add_scalar(&output_document, (yaml_char_t *)YAML_INT_TAG,
                        (yaml_char_t *)number, -1, YAML_PLAIN_SCALAR_STYLE);
                    if (!value) goto document_error;
                    if (!yaml_document_append_mapping_pair(&output_document,
                                map, key, value)) goto document_error;

                    /* Add 'minor': <number>. */

                    key = yaml_document_add_scalar(&output_document, NULL,
                        (yaml_char_t *)"minor", -1, YAML_PLAIN_SCALAR_STYLE);
                    if (!key) goto document_error;
                    sprintf(number, "%d", version->minor);
                    value = yaml_document_add_scalar(&output_document, (yaml_char_t *)YAML_INT_TAG,
                        (yaml_char_t *)number, -1, YAML_PLAIN_SCALAR_STYLE);
                    if (!value) goto document_error;
                    if (!yaml_document_append_mapping_pair(&output_document,
                                map, key, value)) goto document_error;
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 17\n");
                }

                /* Display the output_document tag directives. */

                if (input_event.data.document_start.tag_directives.start
                        != input_event.data.document_start.tag_directives.end)
                {
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 18\n");
                    yaml_tag_directive_t *tag;

                    /* Add 'tags': []. */
                    
                    key = yaml_document_add_scalar(&output_document, NULL,
                        (yaml_char_t *)"tags", -1, YAML_PLAIN_SCALAR_STYLE);
                    if (!key) goto document_error;
                    seq = yaml_document_add_sequence(&output_document, NULL,
                            YAML_BLOCK_SEQUENCE_STYLE);
                    if (!seq) goto document_error;
                    if (!yaml_document_append_mapping_pair(&output_document,
                                properties, key, seq)) goto document_error;

                    for (tag = input_event.data.document_start.tag_directives.start;
                            tag != input_event.data.document_start.tag_directives.end;
                            tag ++)
                    {
                        fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 19\n");
                        /* Add {}. */

                        map = yaml_document_add_mapping(&output_document, NULL,
                                YAML_FLOW_MAPPING_STYLE);
                        if (!map) goto document_error;
                        if (!yaml_document_append_sequence_item(&output_document,
                                    seq, map)) goto document_error;

                        /* Add 'handle': <handle>. */

                        key = yaml_document_add_scalar(&output_document, NULL,
                            (yaml_char_t *)"handle", -1, YAML_PLAIN_SCALAR_STYLE);
                        if (!key) goto document_error;
                        value = yaml_document_add_scalar(&output_document, NULL,
                            tag->handle, -1, YAML_DOUBLE_QUOTED_SCALAR_STYLE);
                        if (!value) goto document_error;
                        if (!yaml_document_append_mapping_pair(&output_document,
                                    map, key, value)) goto document_error;

                        /* Add 'prefix': <prefix>. */

                        key = yaml_document_add_scalar(&output_document, NULL,
                            (yaml_char_t *)"prefix", -1, YAML_PLAIN_SCALAR_STYLE);
                        if (!key) goto document_error;
                        value = yaml_document_add_scalar(&output_document, NULL,
                            tag->prefix, -1, YAML_DOUBLE_QUOTED_SCALAR_STYLE);
                        if (!value) goto document_error;
                        if (!yaml_document_append_mapping_pair(&output_document,
                                    map, key, value)) goto document_error;
                        fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 19\n");
                    }
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 18\n");
                }

                /* Add 'implicit': <flag>. */

                key = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"implicit", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!key) goto document_error;
                value = yaml_document_add_scalar(&output_document, (yaml_char_t *)YAML_BOOL_TAG,
                        (yaml_char_t *)(input_event.data.document_start.implicit ?
                         "true" : "false"), -1, YAML_PLAIN_SCALAR_STYLE);
                if (!value) goto document_error;
                if (!yaml_document_append_mapping_pair(&output_document,
                            properties, key, value)) goto document_error;
                fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 16\n");
                break;

            case YAML_DOCUMENT_END_EVENT:
                fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 20\n");
                /* Add 'type': 'DOCUMENT-END'. */

                key = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"type", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!key) goto document_error;
                value = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"DOCUMENT-END", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!value) goto document_error;
                if (!yaml_document_append_mapping_pair(&output_document,
                            properties, key, value)) goto document_error;

                /* Add 'implicit': <flag>. */

                key = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"implicit", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!key) goto document_error;
                value = yaml_document_add_scalar(&output_document, (yaml_char_t *)YAML_BOOL_TAG,
                        (yaml_char_t *)(input_event.data.document_end.implicit ?
                         "true" : "false"), -1, YAML_PLAIN_SCALAR_STYLE);
                if (!value) goto document_error;
                if (!yaml_document_append_mapping_pair(&output_document,
                            properties, key, value)) goto document_error;
                fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 20\n");
                break;

            case YAML_ALIAS_EVENT:
                fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 21\n");
                /* Add 'type': 'ALIAS'. */

                key = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"type", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!key) goto document_error;
                value = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"ALIAS", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!value) goto document_error;
                if (!yaml_document_append_mapping_pair(&output_document,
                            properties, key, value)) goto document_error;

                /* Add 'anchor': <anchor>. */

                key = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"anchor", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!key) goto document_error;
                value = yaml_document_add_scalar(&output_document, NULL,
                        input_event.data.alias.anchor, -1,
                        YAML_DOUBLE_QUOTED_SCALAR_STYLE);
                if (!value) goto document_error;
                if (!yaml_document_append_mapping_pair(&output_document,
                            properties, key, value)) goto document_error;
                fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 21\n");
                break;

            case YAML_SCALAR_EVENT:
                fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 22\n");
                /* Add 'type': 'SCALAR'. */

                key = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"type", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!key) goto document_error;
                value = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"SCALAR", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!value) goto document_error;
                if (!yaml_document_append_mapping_pair(&output_document,
                            properties, key, value)) goto document_error;

                /* Add 'anchor': <anchor>. */

                if (input_event.data.scalar.anchor)
                {
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 23\n");
                    key = yaml_document_add_scalar(&output_document, NULL,
                        (yaml_char_t *)"anchor", -1, YAML_PLAIN_SCALAR_STYLE);
                    if (!key) goto document_error;
                    value = yaml_document_add_scalar(&output_document, NULL,
                            input_event.data.scalar.anchor, -1,
                            YAML_DOUBLE_QUOTED_SCALAR_STYLE);
                    if (!value) goto document_error;
                    if (!yaml_document_append_mapping_pair(&output_document,
                                properties, key, value)) goto document_error;
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 23\n");
                }

                /* Add 'tag': <tag>. */

                if (input_event.data.scalar.tag)
                {
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 24\n");
                    key = yaml_document_add_scalar(&output_document, NULL,
                        (yaml_char_t *)"tag", -1, YAML_PLAIN_SCALAR_STYLE);
                    if (!key) goto document_error;
                    value = yaml_document_add_scalar(&output_document, NULL,
                            input_event.data.scalar.tag, -1,
                            YAML_DOUBLE_QUOTED_SCALAR_STYLE);
                    if (!value) goto document_error;
                    if (!yaml_document_append_mapping_pair(&output_document,
                                properties, key, value)) goto document_error;
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 24\n");
                }

                /* Add 'value': <value>. */

                key = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"value", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!key) goto document_error;
                value = yaml_document_add_scalar(&output_document, NULL,
                        input_event.data.scalar.value,
                        input_event.data.scalar.length,
                        YAML_DOUBLE_QUOTED_SCALAR_STYLE);
                if (!value) goto document_error;
                if (!yaml_document_append_mapping_pair(&output_document,
                            properties, key, value)) goto document_error;

                /* Display if the scalar tag is implicit. */

                /* Add 'implicit': {} */

                key = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"version", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!key) goto document_error;
                map = yaml_document_add_mapping(&output_document, NULL,
                        YAML_FLOW_MAPPING_STYLE);
                if (!map) goto document_error;
                if (!yaml_document_append_mapping_pair(&output_document,
                            properties, key, map)) goto document_error;

                /* Add 'plain': <flag>. */

                key = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"plain", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!key) goto document_error;
                value = yaml_document_add_scalar(&output_document, (yaml_char_t *)YAML_BOOL_TAG,
                        (yaml_char_t *)(input_event.data.scalar.plain_implicit ?
                         "true" : "false"), -1, YAML_PLAIN_SCALAR_STYLE);
                if (!value) goto document_error;
                if (!yaml_document_append_mapping_pair(&output_document,
                            map, key, value)) goto document_error;

                /* Add 'quoted': <flag>. */

                key = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"quoted", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!key) goto document_error;
                value = yaml_document_add_scalar(&output_document, (yaml_char_t *)YAML_BOOL_TAG,
                        (yaml_char_t *)(input_event.data.scalar.quoted_implicit ?
                         "true" : "false"), -1, YAML_PLAIN_SCALAR_STYLE);
                if (!value) goto document_error;
                if (!yaml_document_append_mapping_pair(&output_document,
                            map, key, value)) goto document_error;

                /* Display the style information. */

                if (input_event.data.scalar.style)
                {
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 25\n");
                    yaml_scalar_style_t style = input_event.data.scalar.style;

                    /* Add 'style': <style>. */

                    key = yaml_document_add_scalar(&output_document, NULL,
                        (yaml_char_t *)"style", -1, YAML_PLAIN_SCALAR_STYLE);
                    if (!key) goto document_error;
                    value = yaml_document_add_scalar(&output_document, NULL,
                            (yaml_char_t *)(style == YAML_PLAIN_SCALAR_STYLE ? "plain" :
                             style == YAML_SINGLE_QUOTED_SCALAR_STYLE ?
                                    "single-quoted" :
                             style == YAML_DOUBLE_QUOTED_SCALAR_STYLE ?
                                    "double-quoted" :
                             style == YAML_LITERAL_SCALAR_STYLE ? "literal" :
                             style == YAML_FOLDED_SCALAR_STYLE ? "folded" :
                             "unknown"), -1, YAML_PLAIN_SCALAR_STYLE);
                    if (!value) goto document_error;
                    if (!yaml_document_append_mapping_pair(&output_document,
                                properties, key, value)) goto document_error;
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 25\n");
                }
                fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 22\n");
                break;

            case YAML_SEQUENCE_START_EVENT:
                fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 26\n");
                /* Add 'type': 'SEQUENCE-START'. */

                key = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"type", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!key) goto document_error;
                value = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"SEQUENCE-START", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!value) goto document_error;
                if (!yaml_document_append_mapping_pair(&output_document,
                            properties, key, value)) goto document_error;

                /* Add 'anchor': <anchor>. */

                if (input_event.data.sequence_start.anchor)
                {
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 27\n");
                    key = yaml_document_add_scalar(&output_document, NULL,
                        (yaml_char_t *)"anchor", -1, YAML_PLAIN_SCALAR_STYLE);
                    if (!key) goto document_error;
                    value = yaml_document_add_scalar(&output_document, NULL,
                            input_event.data.sequence_start.anchor, -1,
                            YAML_DOUBLE_QUOTED_SCALAR_STYLE);
                    if (!value) goto document_error;
                    if (!yaml_document_append_mapping_pair(&output_document,
                                properties, key, value)) goto document_error;
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 27\n");
                }

                /* Add 'tag': <tag>. */

                if (input_event.data.sequence_start.tag)
                {
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 28\n");
                    key = yaml_document_add_scalar(&output_document, NULL,
                        (yaml_char_t *)"tag", -1, YAML_PLAIN_SCALAR_STYLE);
                    if (!key) goto document_error;
                    value = yaml_document_add_scalar(&output_document, NULL,
                            input_event.data.sequence_start.tag, -1,
                            YAML_DOUBLE_QUOTED_SCALAR_STYLE);
                    if (!value) goto document_error;
                    if (!yaml_document_append_mapping_pair(&output_document,
                                properties, key, value)) goto document_error;
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 28\n");
                }

                /* Add 'implicit': <flag>. */

                key = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"implicit", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!key) goto document_error;
                value = yaml_document_add_scalar(&output_document, (yaml_char_t *)YAML_BOOL_TAG,
                        (yaml_char_t *)(input_event.data.sequence_start.implicit ?
                         "true" : "false"), -1, YAML_PLAIN_SCALAR_STYLE);
                if (!value) goto document_error;
                if (!yaml_document_append_mapping_pair(&output_document,
                            properties, key, value)) goto document_error;

                /* Display the style information. */

                if (input_event.data.sequence_start.style)
                {
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 29\n");
                    yaml_sequence_style_t style
                        = input_event.data.sequence_start.style;

                    /* Add 'style': <style>. */

                    key = yaml_document_add_scalar(&output_document, NULL,
                        (yaml_char_t *)"style", -1, YAML_PLAIN_SCALAR_STYLE);
                    if (!key) goto document_error;
                    value = yaml_document_add_scalar(&output_document, NULL,
                            (yaml_char_t *)(style == YAML_BLOCK_SEQUENCE_STYLE ? "block" :
                             style == YAML_FLOW_SEQUENCE_STYLE ? "flow" :
                             "unknown"), -1, YAML_PLAIN_SCALAR_STYLE);
                    if (!value) goto document_error;
                    if (!yaml_document_append_mapping_pair(&output_document,
                                properties, key, value)) goto document_error;
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 29\n");
                }
                fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 26\n");
                break;

            case YAML_SEQUENCE_END_EVENT:
                fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 30\n");
                /* Add 'type': 'SEQUENCE-END'. */

                key = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"type", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!key) goto document_error;
                value = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"SEQUENCE-END", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!value) goto document_error;
                if (!yaml_document_append_mapping_pair(&output_document,
                            properties, key, value)) goto document_error;
                fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 30\n");
                break;

            case YAML_MAPPING_START_EVENT:
                fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 31\n");
                /* Add 'type': 'MAPPING-START'. */

                key = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"type", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!key) goto document_error;
                value = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"MAPPING-START", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!value) goto document_error;
                if (!yaml_document_append_mapping_pair(&output_document,
                            properties, key, value)) goto document_error;

                /* Add 'anchor': <anchor>. */

                if (input_event.data.mapping_start.anchor)
                {
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 32\n");
                    key = yaml_document_add_scalar(&output_document, NULL,
                        (yaml_char_t *)"anchor", -1, YAML_PLAIN_SCALAR_STYLE);
                    if (!key) goto document_error;
                    value = yaml_document_add_scalar(&output_document, NULL,
                            input_event.data.mapping_start.anchor, -1,
                            YAML_DOUBLE_QUOTED_SCALAR_STYLE);
                    if (!value) goto document_error;
                    if (!yaml_document_append_mapping_pair(&output_document,
                                properties, key, value)) goto document_error;
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 32\n");
                }

                /* Add 'tag': <tag>. */

                if (input_event.data.mapping_start.tag)
                {
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 33\n");
                    key = yaml_document_add_scalar(&output_document, NULL,
                        (yaml_char_t *)"tag", -1, YAML_PLAIN_SCALAR_STYLE);
                    if (!key) goto document_error;
                    value = yaml_document_add_scalar(&output_document, NULL,
                            input_event.data.mapping_start.tag, -1,
                            YAML_DOUBLE_QUOTED_SCALAR_STYLE);
                    if (!value) goto document_error;
                    if (!yaml_document_append_mapping_pair(&output_document,
                                properties, key, value)) goto document_error;
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 33\n");
                }

                /* Add 'implicit': <flag>. */

                key = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"implicit", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!key) goto document_error;
                value = yaml_document_add_scalar(&output_document, (yaml_char_t *)YAML_BOOL_TAG,
                        (yaml_char_t *)(input_event.data.mapping_start.implicit ?
                         "true" : "false"), -1, YAML_PLAIN_SCALAR_STYLE);
                if (!value) goto document_error;
                if (!yaml_document_append_mapping_pair(&output_document,
                            properties, key, value)) goto document_error;

                /* Display the style information. */

                if (input_event.data.mapping_start.style)
                {
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 34\n");
                    yaml_mapping_style_t style
                        = input_event.data.mapping_start.style;

                    /* Add 'style': <style>. */

                    key = yaml_document_add_scalar(&output_document, NULL,
                        (yaml_char_t *)"style", -1, YAML_PLAIN_SCALAR_STYLE);
                    if (!key) goto document_error;
                    value = yaml_document_add_scalar(&output_document, NULL,
                            (yaml_char_t *)(style == YAML_BLOCK_MAPPING_STYLE ? "block" :
                             style == YAML_FLOW_MAPPING_STYLE ? "flow" :
                             "unknown"), -1, YAML_PLAIN_SCALAR_STYLE);
                    if (!value) goto document_error;
                    if (!yaml_document_append_mapping_pair(&output_document,
                                properties, key, value)) goto document_error;
                    fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 34\n");
                }
                fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 31\n");
                break;

            case YAML_MAPPING_END_EVENT:
                fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 35\n");
                /* Add 'type': 'MAPPING-END'. */

                key = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"type", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!key) goto document_error;
                value = yaml_document_add_scalar(&output_document, NULL,
                    (yaml_char_t *)"MAPPING-END", -1, YAML_PLAIN_SCALAR_STYLE);
                if (!value) goto document_error;
                if (!yaml_document_append_mapping_pair(&output_document,
                            properties, key, value)) goto document_error;
                fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 35\n");
                break;

            default:
                fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 36\n");
                /* It couldn't really happen. */
                fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 36\n");
                break;
        }

        /* Delete the event object. */

        yaml_event_delete(&input_event);
        fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 11\n");
    }

    fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 37\n");
    if (!yaml_emitter_dump(&emitter, &output_document))
        goto emitter_error;
    if (!yaml_emitter_close(&emitter))
        goto emitter_error;

    yaml_parser_delete(&parser);
    yaml_emitter_delete(&emitter);

    return 0;
    fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 37\n");

parser_error:
    fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 38\n");
    /* Display a parser error message. */

    switch (parser.error)
    {
        case YAML_MEMORY_ERROR:
            fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 39\n");
            fprintf(stderr, "Memory error: Not enough memory for parsing\n");
            fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 39\n");
            break;

        case YAML_READER_ERROR:
            fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 40\n");
            if (parser.problem_value != -1) {
                fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 41\n");
                fprintf(stderr, "Reader error: %s: #%X at %zd\n", parser.problem,
                        parser.problem_value, parser.problem_offset);
                fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 41\n");
            }
            else {
                fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 42\n");
                fprintf(stderr, "Reader error: %s at %zd\n", parser.problem,
                        parser.problem_offset);
                fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 42\n");
            }
            fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 40\n");
            break;

        case YAML_SCANNER_ERROR:
            fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 43\n");
            if (parser.context) {
                fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 44\n");
                fprintf(stderr, "Scanner error: %s at line %lu, column %lu\n"
                        "%s at line %lu, column %lu\n", parser.context,
                        parser.context_mark.line+1, parser.context_mark.column+1,
                        parser.problem, parser.problem_mark.line+1,
                        parser.problem_mark.column+1);
                fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 44\n");
            }
            else {
                fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 45\n");
                fprintf(stderr, "Scanner error: %s at line %lu, column %lu\n",
                        parser.problem, parser.problem_mark.line+1,
                        parser.problem_mark.column+1);
                fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 45\n");
            }
            fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 43\n");
            break;

        case YAML_PARSER_ERROR:
            fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 46\n");
            if (parser.context) {
                fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 47\n");
                fprintf(stderr, "Parser error: %s at line %lu, column %lu\n"
                        "%s at line %lu, column %lu\n", parser.context,
                        parser.context_mark.line+1, parser.context_mark.column+1,
                        parser.problem, parser.problem_mark.line+1,
                        parser.problem_mark.column+1);
                fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 47\n");
            }
            else {
                fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 48\n");
                fprintf(stderr, "Parser error: %s at line %lu, column %lu\n",
                        parser.problem, parser.problem_mark.line+1,
                        parser.problem_mark.column+1);
                fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 48\n");
            }
            fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 46\n");
            break;

        default:
            fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 49\n");
            /* Couldn't happen. */
            fprintf(stderr, "Internal error\n");
            fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 49\n");
            break;
    }

    yaml_event_delete(&input_event);
    yaml_document_delete(&output_document);
    yaml_parser_delete(&parser);
    yaml_emitter_delete(&emitter);

    return 1;
    fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 38\n");

emitter_error:
    fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 50\n");
    /* Display an emitter error message. */

    switch (emitter.error)
    {
        case YAML_MEMORY_ERROR:
            fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 51\n");
            fprintf(stderr, "Memory error: Not enough memory for emitting\n");
            fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 51\n");
            break;

        case YAML_WRITER_ERROR:
            fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 52\n");
            fprintf(stderr, "Writer error: %s\n", emitter.problem);
            fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 52\n");
            break;

        case YAML_EMITTER_ERROR:
            fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 53\n");
            fprintf(stderr, "Emitter error: %s\n", emitter.problem);
            fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 53\n");
            break;

        default:
            fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 54\n");
            /* Couldn't happen. */
            fprintf(stderr, "Internal error\n");
            fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 54\n");
            break;
    }

    yaml_event_delete(&input_event);
    yaml_document_delete(&output_document);
    yaml_parser_delete(&parser);
    yaml_emitter_delete(&emitter);

    return 1;
    fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 50\n");

document_error:
    fprintf(stderr, "[tests/example-deconstructor-alt.c] enter main 55\n");
    fprintf(stderr, "Memory error: Not enough memory for creating a document\n");

    yaml_event_delete(&input_event);
    yaml_document_delete(&output_document);
    yaml_parser_delete(&parser);
    yaml_emitter_delete(&emitter);

    return 1;
    fprintf(stderr, "[tests/example-deconstructor-alt.c] exit main 55\n");
}
// Total cost: 0.239975
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 800)]
// Total instrumented cost: 0.239975, input tokens: 11554, output tokens: 10800, cache read tokens: 0, cache write tokens: 11550

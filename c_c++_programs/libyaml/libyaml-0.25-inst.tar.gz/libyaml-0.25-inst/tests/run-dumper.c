#include <yaml.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#ifdef NDEBUG
#undef NDEBUG
#endif
#include <assert.h>

#define BUFFER_SIZE 65536
#define MAX_DOCUMENTS  16

int copy_document(yaml_document_t *document_to, yaml_document_t *document_from)
{
    fprintf(stderr, "[tests/run-dumper.c] enter copy_document 1\n");
    yaml_node_t *node;
    yaml_node_item_t *item;
    yaml_node_pair_t *pair;

    if (!yaml_document_initialize(document_to, document_from->version_directive,
                document_from->tag_directives.start,
                document_from->tag_directives.end,
                document_from->start_implicit, document_from->end_implicit))
        return 0;
    fprintf(stderr, "[tests/run-dumper.c] exit copy_document 1\n");

    for (node = document_from->nodes.start;
            node < document_from->nodes.top; node ++) {
        fprintf(stderr, "[tests/run-dumper.c] enter copy_document 2\n");
        switch (node->type) {
            case YAML_SCALAR_NODE:
                fprintf(stderr, "[tests/run-dumper.c] enter copy_document 3\n");
                if (!yaml_document_add_scalar(document_to, node->tag,
                            node->data.scalar.value, node->data.scalar.length,
                            node->data.scalar.style)) goto error;
                fprintf(stderr, "[tests/run-dumper.c] exit copy_document 3\n");
                break;
            case YAML_SEQUENCE_NODE:
                fprintf(stderr, "[tests/run-dumper.c] enter copy_document 4\n");
                if (!yaml_document_add_sequence(document_to, node->tag,
                            node->data.sequence.style)) goto error;
                fprintf(stderr, "[tests/run-dumper.c] exit copy_document 4\n");
                break;
            case YAML_MAPPING_NODE:
                fprintf(stderr, "[tests/run-dumper.c] enter copy_document 5\n");
                if (!yaml_document_add_mapping(document_to, node->tag,
                            node->data.mapping.style)) goto error;
                fprintf(stderr, "[tests/run-dumper.c] exit copy_document 5\n");
                break;
            default:
                fprintf(stderr, "[tests/run-dumper.c] enter copy_document 6\n");
                assert(0);
                fprintf(stderr, "[tests/run-dumper.c] exit copy_document 6\n");
                break;
        }
        fprintf(stderr, "[tests/run-dumper.c] exit copy_document 2\n");
    }

    for (node = document_from->nodes.start;
            node < document_from->nodes.top; node ++) {
        fprintf(stderr, "[tests/run-dumper.c] enter copy_document 7\n");
        switch (node->type) {
            case YAML_SEQUENCE_NODE:
                fprintf(stderr, "[tests/run-dumper.c] enter copy_document 8\n");
                for (item = node->data.sequence.items.start;
                        item < node->data.sequence.items.top; item ++) {
                    fprintf(stderr, "[tests/run-dumper.c] enter copy_document 9\n");
                    if (!yaml_document_append_sequence_item(document_to,
                                node - document_from->nodes.start + 1,
                                *item)) goto error;
                    fprintf(stderr, "[tests/run-dumper.c] exit copy_document 9\n");
                }
                fprintf(stderr, "[tests/run-dumper.c] exit copy_document 8\n");
                break;
            case YAML_MAPPING_NODE:
                fprintf(stderr, "[tests/run-dumper.c] enter copy_document 10\n");
                for (pair = node->data.mapping.pairs.start;
                        pair < node->data.mapping.pairs.top; pair ++) {
                    fprintf(stderr, "[tests/run-dumper.c] enter copy_document 11\n");
                    if (!yaml_document_append_mapping_pair(document_to,
                                node - document_from->nodes.start + 1,
                                pair->key, pair->value)) goto error;
                    fprintf(stderr, "[tests/run-dumper.c] exit copy_document 11\n");
                }
                fprintf(stderr, "[tests/run-dumper.c] exit copy_document 10\n");
                break;
            default:
                fprintf(stderr, "\n");
                fprintf(stderr, "\n");
                break;
        }
        fprintf(stderr, "[tests/run-dumper.c] exit copy_document 7\n");
    }
    fprintf(stderr, "[tests/run-dumper.c] enter copy_document 13\n");
    return 1;
    fprintf(stderr, "[tests/run-dumper.c] exit copy_document 13\n");

error:
    fprintf(stderr, "[tests/run-dumper.c] enter copy_document 14\n");
    yaml_document_delete(document_to);
    return 0;
    fprintf(stderr, "[tests/run-dumper.c] exit copy_document 14\n");
}

int compare_nodes(yaml_document_t *document1, int index1,
        yaml_document_t *document2, int index2, int level)
{
    fprintf(stderr, "[tests/run-dumper.c] enter compare_nodes 1\n");
    int k;
    yaml_node_t *node1;
    yaml_node_t *node2;
    if (level++ > 1000) return 0;
    node1 = yaml_document_get_node(document1, index1);
    node2 = yaml_document_get_node(document2, index2);

    assert(node1);
    assert(node2);

    if (node1->type != node2->type)
        return 0;
    fprintf(stderr, "[tests/run-dumper.c] exit compare_nodes 1\n");

    fprintf(stderr, "[tests/run-dumper.c] enter compare_nodes 2\n");
    if (strcmp((char *)node1->tag, (char *)node2->tag) != 0) return 0;
    fprintf(stderr, "[tests/run-dumper.c] exit compare_nodes 2\n");

    switch (node1->type) {
        case YAML_SCALAR_NODE:
            fprintf(stderr, "[tests/run-dumper.c] enter compare_nodes 3\n");
            if (node1->data.scalar.length != node2->data.scalar.length)
                return 0;
            if (strncmp((char *)node1->data.scalar.value, (char *)node2->data.scalar.value,
                        node1->data.scalar.length) != 0) return 0;
            fprintf(stderr, "[tests/run-dumper.c] exit compare_nodes 3\n");
            break;
        case YAML_SEQUENCE_NODE:
            fprintf(stderr, "[tests/run-dumper.c] enter compare_nodes 4\n");
            if ((node1->data.sequence.items.top - node1->data.sequence.items.start) !=
                    (node2->data.sequence.items.top - node2->data.sequence.items.start))
                return 0;
            fprintf(stderr, "[tests/run-dumper.c] exit compare_nodes 4\n");
            for (k = 0; k < (node1->data.sequence.items.top - node1->data.sequence.items.start); k ++) {
                fprintf(stderr, "[tests/run-dumper.c] enter compare_nodes 5\n");
                if (!compare_nodes(document1, node1->data.sequence.items.start[k],
                            document2, node2->data.sequence.items.start[k], level)) return 0;
                fprintf(stderr, "[tests/run-dumper.c] exit compare_nodes 5\n");
            }
            break;
        case YAML_MAPPING_NODE:
            fprintf(stderr, "[tests/run-dumper.c] enter compare_nodes 6\n");
            if ((node1->data.mapping.pairs.top - node1->data.mapping.pairs.start) !=
                    (node2->data.mapping.pairs.top - node2->data.mapping.pairs.start))
                return 0;
            fprintf(stderr, "[tests/run-dumper.c] exit compare_nodes 6\n");
            for (k = 0; k < (node1->data.mapping.pairs.top - node1->data.mapping.pairs.start); k ++) {
                fprintf(stderr, "[tests/run-dumper.c] enter compare_nodes 7\n");
                if (!compare_nodes(document1, node1->data.mapping.pairs.start[k].key,
                            document2, node2->data.mapping.pairs.start[k].key, level)) return 0;
                fprintf(stderr, "[tests/run-dumper.c] exit compare_nodes 7\n");
                fprintf(stderr, "[tests/run-dumper.c] enter compare_nodes 8\n");
                if (!compare_nodes(document1, node1->data.mapping.pairs.start[k].value,
                            document2, node2->data.mapping.pairs.start[k].value, level)) return 0;
                fprintf(stderr, "[tests/run-dumper.c] exit compare_nodes 8\n");
            }
            break;
        default:
            fprintf(stderr, "[tests/run-dumper.c] enter compare_nodes 9\n");
            assert(0);
            fprintf(stderr, "[tests/run-dumper.c] exit compare_nodes 9\n");
            break;
    }
    fprintf(stderr, "[tests/run-dumper.c] enter compare_nodes 10\n");
    return 1;
    fprintf(stderr, "[tests/run-dumper.c] exit compare_nodes 10\n");
}

int compare_documents(yaml_document_t *document1, yaml_document_t *document2)
{
    fprintf(stderr, "[tests/run-dumper.c] enter compare_documents 1\n");
    int k;

    if ((document1->version_directive && !document2->version_directive)
            || (!document1->version_directive && document2->version_directive)
            || (document1->version_directive && document2->version_directive
                && (document1->version_directive->major != document2->version_directive->major
                    || document1->version_directive->minor != document2->version_directive->minor)))
        return 0;
    fprintf(stderr, "[tests/run-dumper.c] exit compare_documents 1\n");

    fprintf(stderr, "[tests/run-dumper.c] enter compare_documents 2\n");
    if ((document1->tag_directives.end - document1->tag_directives.start) !=
            (document2->tag_directives.end - document2->tag_directives.start))
        return 0;
    fprintf(stderr, "[tests/run-dumper.c] exit compare_documents 2\n");
    
    for (k = 0; k < (document1->tag_directives.end - document1->tag_directives.start); k ++) {
        fprintf(stderr, "[tests/run-dumper.c] enter compare_documents 3\n");
        if ((strcmp((char *)document1->tag_directives.start[k].handle,
                        (char *)document2->tag_directives.start[k].handle) != 0)
                || (strcmp((char *)document1->tag_directives.start[k].prefix,
                    (char *)document2->tag_directives.start[k].prefix) != 0))
            return 0;
        fprintf(stderr, "[tests/run-dumper.c] exit compare_documents 3\n");
    }

    fprintf(stderr, "[tests/run-dumper.c] enter compare_documents 4\n");
    if ((document1->nodes.top - document1->nodes.start) !=
            (document2->nodes.top - document2->nodes.start))
        return 0;
    fprintf(stderr, "[tests/run-dumper.c] exit compare_documents 4\n");

    fprintf(stderr, "[tests/run-dumper.c] enter compare_documents 5\n");
    if (document1->nodes.top != document1->nodes.start) {
        fprintf(stderr, "[tests/run-dumper.c] enter compare_documents 6\n");
        if (!compare_nodes(document1, 1, document2, 1, 0))
            return 0;
        fprintf(stderr, "[tests/run-dumper.c] exit compare_documents 6\n");
    }

    return 1;
    fprintf(stderr, "[tests/run-dumper.c] exit compare_documents 5\n");
}

int print_output(char *name, unsigned char *buffer, size_t size, int count)
{
    fprintf(stderr, "[tests/run-dumper.c] enter print_output 1\n");
    FILE *file;
    char data[BUFFER_SIZE];
    size_t data_size = 1;
    size_t total_size = 0;
    if (count >= 0) {
        fprintf(stderr, "[tests/run-dumper.c] enter print_output 2\n");
        printf("FAILED (at the document #%d)\nSOURCE:\n", count+1);
        fprintf(stderr, "[tests/run-dumper.c] exit print_output 2\n");
    }
    file = fopen(name, "rb");
    assert(file);
    while (data_size > 0) {
        fprintf(stderr, "[tests/run-dumper.c] enter print_output 3\n");
        data_size = fread(data, 1, BUFFER_SIZE, file);
        assert(!ferror(file));
        if (!data_size) break;
        assert(fwrite(data, 1, data_size, stdout) == data_size);
        total_size += data_size;
        fprintf(stderr, "[tests/run-dumper.c] exit print_output 3\n");
        if (feof(file)) break;
    }
    fclose(file);
    printf("#### (length: %ld)\n", (long)total_size);
    printf("OUTPUT:\n%s#### (length: %ld)\n", buffer, (long)size);
    return 0;
    fprintf(stderr, "[tests/run-dumper.c] exit print_output 1\n");
}

int
main(int argc, char *argv[])
{
    fprintf(stderr, "[tests/run-dumper.c] enter main 1\n");
    int number;
    int canonical = 0;
    int unicode = 0;

    number = 1;
    fprintf(stderr, "[tests/run-dumper.c] exit main 1\n");
    
    while (number < argc) {
        fprintf(stderr, "[tests/run-dumper.c] enter main 2\n");
        if (strcmp(argv[number], "-c") == 0) {
            fprintf(stderr, "[tests/run-dumper.c] enter main 3\n");
            canonical = 1;
            fprintf(stderr, "[tests/run-dumper.c] exit main 3\n");
        }
        else if (strcmp(argv[number], "-u") == 0) {
            fprintf(stderr, "[tests/run-dumper.c] enter main 4\n");
            unicode = 1;
            fprintf(stderr, "[tests/run-dumper.c] exit main 4\n");
        }
        else if (argv[number][0] == '-') {
            fprintf(stderr, "[tests/run-dumper.c] enter main 5\n");
            printf("Unknown option: '%s'\n", argv[number]);
            return 0;
            fprintf(stderr, "[tests/run-dumper.c] exit main 5\n");
        }
        if (argv[number][0] == '-') {
            fprintf(stderr, "[tests/run-dumper.c] enter main 6\n");
            if (number < argc-1) {
                fprintf(stderr, "[tests/run-dumper.c] enter main 7\n");
                memmove(argv+number, argv+number+1, (argc-number-1)*sizeof(char *));
                fprintf(stderr, "[tests/run-dumper.c] exit main 7\n");
            }
            argc --;
            fprintf(stderr, "[tests/run-dumper.c] exit main 6\n");
        }
        else {
            fprintf(stderr, "[tests/run-dumper.c] enter main 8\n");
            number ++;
            fprintf(stderr, "[tests/run-dumper.c] exit main 8\n");
        }
        fprintf(stderr, "[tests/run-dumper.c] exit main 2\n");
    }

    fprintf(stderr, "[tests/run-dumper.c] enter main 9\n");
    if (argc < 2) {
        fprintf(stderr, "[tests/run-dumper.c] enter main 10\n");
        printf("Usage: %s [-c] [-u] file1.yaml ...\n", argv[0]);
        return 0;
        fprintf(stderr, "[tests/run-dumper.c] exit main 10\n");
    }
    fprintf(stderr, "[tests/run-dumper.c] exit main 9\n");

    for (number = 1; number < argc; number ++)
    {
        fprintf(stderr, "[tests/run-dumper.c] enter main 11\n");
        FILE *file;
        yaml_parser_t parser;
        yaml_emitter_t emitter;

        yaml_document_t document;
        unsigned char buffer[BUFFER_SIZE+1];
        size_t written = 0;
        yaml_document_t documents[MAX_DOCUMENTS];
        size_t document_number = 0;
        int done = 0;
        int count = 0;
        int error = 0;
        int k;
        memset(buffer, 0, BUFFER_SIZE+1);
        memset(documents, 0, MAX_DOCUMENTS*sizeof(yaml_document_t));

        printf("[%d] Loading, dumping, and loading again '%s': ", number, argv[number]);
        fflush(stdout);

        file = fopen(argv[number], "rb");
        assert(file);

        assert(yaml_parser_initialize(&parser));
        yaml_parser_set_input_file(&parser, file);
        assert(yaml_emitter_initialize(&emitter));
        if (canonical) {
            fprintf(stderr, "[tests/run-dumper.c] enter main 12\n");
            yaml_emitter_set_canonical(&emitter, 1);
            fprintf(stderr, "[tests/run-dumper.c] exit main 12\n");
        }
        if (unicode) {
            fprintf(stderr, "[tests/run-dumper.c] enter main 13\n");
            yaml_emitter_set_unicode(&emitter, 1);
            fprintf(stderr, "[tests/run-dumper.c] exit main 13\n");
        }
        yaml_emitter_set_output_string(&emitter, buffer, BUFFER_SIZE, &written);
        yaml_emitter_open(&emitter);
        fprintf(stderr, "[tests/run-dumper.c] exit main 11\n");

        while (!done)
        {
            fprintf(stderr, "[tests/run-dumper.c] enter main 14\n");
            if (!yaml_parser_load(&parser, &document)) {
                fprintf(stderr, "[tests/run-dumper.c] enter main 15\n");
                error = 1;
                break;
                fprintf(stderr, "[tests/run-dumper.c] exit main 15\n");
            }

            done = (!yaml_document_get_root_node(&document));
            if (!done) {
                fprintf(stderr, "[tests/run-dumper.c] enter main 16\n");
                assert(document_number < MAX_DOCUMENTS);
                assert(copy_document(&(documents[document_number++]), &document));
                assert(yaml_emitter_dump(&emitter, &document) || 
                        (yaml_emitter_flush(&emitter) && print_output(argv[number], buffer, written, count)));
                count ++;
                fprintf(stderr, "[tests/run-dumper.c] exit main 16\n");
            }
            else {
                fprintf(stderr, "[tests/run-dumper.c] enter main 17\n");
                yaml_document_delete(&document);
                fprintf(stderr, "[tests/run-dumper.c] exit main 17\n");
            }
            fprintf(stderr, "[tests/run-dumper.c] exit main 14\n");
        }

        fprintf(stderr, "[tests/run-dumper.c] enter main 18\n");
        yaml_parser_delete(&parser);
        assert(!fclose(file));
        yaml_emitter_close(&emitter);
        yaml_emitter_delete(&emitter);
        fprintf(stderr, "[tests/run-dumper.c] exit main 18\n");

        if (!error)
        {
            fprintf(stderr, "[tests/run-dumper.c] enter main 19\n");
            count = done = 0;
            assert(yaml_parser_initialize(&parser));
            yaml_parser_set_input_string(&parser, buffer, written);

            while (!done)
            {
                fprintf(stderr, "[tests/run-dumper.c] enter main 20\n");
                assert(yaml_parser_load(&parser, &document) || print_output(argv[number], buffer, written, count));
                done = (!yaml_document_get_root_node(&document));
                if (!done) {
                    fprintf(stderr, "[tests/run-dumper.c] enter main 21\n");
                    assert(compare_documents(documents+count, &document) || print_output(argv[number], buffer, written, count));
                    count ++;
                    fprintf(stderr, "[tests/run-dumper.c] exit main 21\n");
                }
                yaml_document_delete(&document);
                fprintf(stderr, "[tests/run-dumper.c] exit main 20\n");
            }
            yaml_parser_delete(&parser);
            fprintf(stderr, "[tests/run-dumper.c] exit main 19\n");
        }

        fprintf(stderr, "[tests/run-dumper.c] enter main 22\n");
        for (k = 0; k < document_number; k ++) {
            fprintf(stderr, "[tests/run-dumper.c] enter main 23\n");
            yaml_document_delete(documents+k);
            fprintf(stderr, "[tests/run-dumper.c] exit main 23\n");
        }

        printf("PASSED (length: %ld)\n", (long)written);
        print_output(argv[number], buffer, written, -1);
        fprintf(stderr, "[tests/run-dumper.c] exit main 22\n");
    }

    fprintf(stderr, "[tests/run-dumper.c] enter main 24\n");
    return 0;
    fprintf(stderr, "[tests/run-dumper.c] exit main 24\n");
}
// Total cost: 0.112449
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 314)]
// Total instrumented cost: 0.112449, input tokens: 5568, output tokens: 4992, cache read tokens: 0, cache write tokens: 5564

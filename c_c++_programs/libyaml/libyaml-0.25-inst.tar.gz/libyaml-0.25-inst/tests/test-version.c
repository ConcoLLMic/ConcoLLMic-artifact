#include <yaml.h>

#include <stdlib.h>
#include <stdio.h>

#ifdef NDEBUG
#undef NDEBUG
#endif
#include <assert.h>
#include <string.h>

int
main(void)
{
    fprintf(stderr, "[tests/test-version.c] enter main 1\n");
    int major = -1;
    int minor = -1;
    int patch = -1;
    char buf[64];
    fprintf(stderr, "[tests/test-version.c] exit main 1\n");

    fprintf(stderr, "[tests/test-version.c] enter main 2\n");
    yaml_get_version(&major, &minor, &patch);
    sprintf(buf, "%d.%d.%d", major, minor, patch);
    assert(strcmp(buf, yaml_get_version_string()) == 0);
    fprintf(stderr, "[tests/test-version.c] exit main 2\n");

    fprintf(stderr, "[tests/test-version.c] enter main 3\n");
    /* Print structure sizes. */
    printf("sizeof(token) = %ld\n", (long)sizeof(yaml_token_t));
    printf("sizeof(event) = %ld\n", (long)sizeof(yaml_event_t));
    printf("sizeof(parser) = %ld\n", (long)sizeof(yaml_parser_t));
    fprintf(stderr, "[tests/test-version.c] exit main 3\n");

    fprintf(stderr, "[tests/test-version.c] enter main 4\n");
    return 0;
    fprintf(stderr, "[tests/test-version.c] exit main 4\n");
}
// Total cost: 0.023096
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 29)]
// Total instrumented cost: 0.023096, input tokens: 2575, output tokens: 382, cache read tokens: 0, cache write tokens: 2571

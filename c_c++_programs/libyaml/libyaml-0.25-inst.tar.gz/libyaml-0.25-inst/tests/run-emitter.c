#include <yaml.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#ifdef NDEBUG
#undef NDEBUG
#endif
#include <assert.h>

#define BUFFER_SIZE 65536
#define MAX_EVENTS  1024

int copy_event(yaml_event_t *event_to, yaml_event_t *event_from)
{
    fprintf(stderr, "[tests/run-emitter.c] enter copy_event 1\n");
    switch (event_from->type)
    {
        case YAML_STREAM_START_EVENT:
            fprintf(stderr, "[tests/run-emitter.c] enter copy_event 2\n");
            return yaml_stream_start_event_initialize(event_to,
                    event_from->data.stream_start.encoding);
            fprintf(stderr, "[tests/run-emitter.c] exit copy_event 2\n");

        case YAML_STREAM_END_EVENT:
            fprintf(stderr, "[tests/run-emitter.c] enter copy_event 3\n");
            return yaml_stream_end_event_initialize(event_to);
            fprintf(stderr, "[tests/run-emitter.c] exit copy_event 3\n");

        case YAML_DOCUMENT_START_EVENT:
            fprintf(stderr, "[tests/run-emitter.c] enter copy_event 4\n");
            return yaml_document_start_event_initialize(event_to,
                    event_from->data.document_start.version_directive,
                    event_from->data.document_start.tag_directives.start,
                    event_from->data.document_start.tag_directives.end,
                    event_from->data.document_start.implicit);
            fprintf(stderr, "[tests/run-emitter.c] exit copy_event 4\n");

        case YAML_DOCUMENT_END_EVENT:
            fprintf(stderr, "[tests/run-emitter.c] enter copy_event 5\n");
            return yaml_document_end_event_initialize(event_to,
                    event_from->data.document_end.implicit);
            fprintf(stderr, "[tests/run-emitter.c] exit copy_event 5\n");

        case YAML_ALIAS_EVENT:
            fprintf(stderr, "[tests/run-emitter.c] enter copy_event 6\n");
            return yaml_alias_event_initialize(event_to,
                    event_from->data.alias.anchor);
            fprintf(stderr, "[tests/run-emitter.c] exit copy_event 6\n");

        case YAML_SCALAR_EVENT:
            fprintf(stderr, "[tests/run-emitter.c] enter copy_event 7\n");
            return yaml_scalar_event_initialize(event_to,
                    event_from->data.scalar.anchor,
                    event_from->data.scalar.tag,
                    event_from->data.scalar.value,
                    event_from->data.scalar.length,
                    event_from->data.scalar.plain_implicit,
                    event_from->data.scalar.quoted_implicit,
                    event_from->data.scalar.style);
            fprintf(stderr, "[tests/run-emitter.c] exit copy_event 7\n");

        case YAML_SEQUENCE_START_EVENT:
            fprintf(stderr, "[tests/run-emitter.c] enter copy_event 8\n");
            return yaml_sequence_start_event_initialize(event_to,
                    event_from->data.sequence_start.anchor,
                    event_from->data.sequence_start.tag,
                    event_from->data.sequence_start.implicit,
                    event_from->data.sequence_start.style);
            fprintf(stderr, "[tests/run-emitter.c] exit copy_event 8\n");

        case YAML_SEQUENCE_END_EVENT:
            fprintf(stderr, "[tests/run-emitter.c] enter copy_event 9\n");
            return yaml_sequence_end_event_initialize(event_to);
            fprintf(stderr, "[tests/run-emitter.c] exit copy_event 9\n");

        case YAML_MAPPING_START_EVENT:
            fprintf(stderr, "[tests/run-emitter.c] enter copy_event 10\n");
            return yaml_mapping_start_event_initialize(event_to,
                    event_from->data.mapping_start.anchor,
                    event_from->data.mapping_start.tag,
                    event_from->data.mapping_start.implicit,
                    event_from->data.mapping_start.style);
            fprintf(stderr, "[tests/run-emitter.c] exit copy_event 10\n");

        case YAML_MAPPING_END_EVENT:
            fprintf(stderr, "[tests/run-emitter.c] enter copy_event 11\n");
            return yaml_mapping_end_event_initialize(event_to);
            fprintf(stderr, "[tests/run-emitter.c] exit copy_event 11\n");

        default:
            fprintf(stderr, "[tests/run-emitter.c] enter copy_event 12\n");
            assert(1);
            fprintf(stderr, "[tests/run-emitter.c] exit copy_event 12\n");
    }
    fprintf(stderr, "[tests/run-emitter.c] exit copy_event 1\n");

    return 0;
}

int compare_events(yaml_event_t *event1, yaml_event_t *event2)
{
    fprintf(stderr, "[tests/run-emitter.c] enter compare_events 1\n");
    int k;

    if (event1->type != event2->type)
    {
        fprintf(stderr, "[tests/run-emitter.c] enter compare_events 2\n");
        return 0;
        fprintf(stderr, "[tests/run-emitter.c] exit compare_events 2\n");
    }
    fprintf(stderr, "[tests/run-emitter.c] exit compare_events 1\n");

    fprintf(stderr, "[tests/run-emitter.c] enter compare_events 3\n");
    switch (event1->type)
    {
        case YAML_STREAM_START_EVENT:
            fprintf(stderr, "[tests/run-emitter.c] enter compare_events 4\n");
            return 1;
            fprintf(stderr, "[tests/run-emitter.c] exit compare_events 4\n");
            /* return (event1->data.stream_start.encoding ==
                    event2->data.stream_start.encoding); */

        case YAML_DOCUMENT_START_EVENT:
            fprintf(stderr, "[tests/run-emitter.c] enter compare_events 5\n");
            if ((event1->data.document_start.version_directive && !event2->data.document_start.version_directive)
                    || (!event1->data.document_start.version_directive && event2->data.document_start.version_directive)
                    || (event1->data.document_start.version_directive && event2->data.document_start.version_directive
                        && (event1->data.document_start.version_directive->major != event2->data.document_start.version_directive->major
                            || event1->data.document_start.version_directive->minor != event2->data.document_start.version_directive->minor)))
            {
                fprintf(stderr, "[tests/run-emitter.c] enter compare_events 6\n");
                return 0;
                fprintf(stderr, "[tests/run-emitter.c] exit compare_events 6\n");
            }
            fprintf(stderr, "[tests/run-emitter.c] exit compare_events 5\n");
            
            fprintf(stderr, "[tests/run-emitter.c] enter compare_events 7\n");
            if ((event1->data.document_start.tag_directives.end - event1->data.document_start.tag_directives.start) !=
                    (event2->data.document_start.tag_directives.end - event2->data.document_start.tag_directives.start))
            {
                fprintf(stderr, "[tests/run-emitter.c] enter compare_events 8\n");
                return 0;
                fprintf(stderr, "[tests/run-emitter.c] exit compare_events 8\n");
            }
            fprintf(stderr, "[tests/run-emitter.c] exit compare_events 7\n");
            
            fprintf(stderr, "[tests/run-emitter.c] enter compare_events 9\n");
            for (k = 0; k < (event1->data.document_start.tag_directives.end - event1->data.document_start.tag_directives.start); k ++) {
                fprintf(stderr, "[tests/run-emitter.c] enter compare_events 10\n");
                if ((strcmp((char *)event1->data.document_start.tag_directives.start[k].handle,
                                (char *)event2->data.document_start.tag_directives.start[k].handle) != 0)
                        || (strcmp((char *)event1->data.document_start.tag_directives.start[k].prefix,
                            (char *)event2->data.document_start.tag_directives.start[k].prefix) != 0))
                {
                    fprintf(stderr, "[tests/run-emitter.c] enter compare_events 11\n");
                    return 0;
                    fprintf(stderr, "[tests/run-emitter.c] exit compare_events 11\n");
                }
                fprintf(stderr, "[tests/run-emitter.c] exit compare_events 10\n");
            }
            fprintf(stderr, "[tests/run-emitter.c] exit compare_events 9\n");
            
            fprintf(stderr, "[tests/run-emitter.c] enter compare_events 12\n");
            /* if (event1->data.document_start.implicit != event2->data.document_start.implicit)
                return 0; */
            return 1;
            fprintf(stderr, "[tests/run-emitter.c] exit compare_events 12\n");

        case YAML_DOCUMENT_END_EVENT:
            fprintf(stderr, "[tests/run-emitter.c] enter compare_events 13\n");
            return 1;
            fprintf(stderr, "[tests/run-emitter.c] exit compare_events 13\n");
            /* return (event1->data.document_end.implicit ==
                    event2->data.document_end.implicit); */

        case YAML_ALIAS_EVENT:
            fprintf(stderr, "[tests/run-emitter.c] enter compare_events 14\n");
            return (strcmp((char *)event1->data.alias.anchor,
                        (char *)event2->data.alias.anchor) == 0);
            fprintf(stderr, "[tests/run-emitter.c] exit compare_events 14\n");

        case YAML_SCALAR_EVENT:
            fprintf(stderr, "[tests/run-emitter.c] enter compare_events 15\n");
            if ((event1->data.scalar.anchor && !event2->data.scalar.anchor)
                    || (!event1->data.scalar.anchor && event2->data.scalar.anchor)
                    || (event1->data.scalar.anchor && event2->data.scalar.anchor
                        && strcmp((char *)event1->data.scalar.anchor,
                            (char *)event2->data.scalar.anchor) != 0))
            {
                fprintf(stderr, "[tests/run-emitter.c] enter compare_events 16\n");
                return 0;
                fprintf(stderr, "[tests/run-emitter.c] exit compare_events 16\n");
            }
            fprintf(stderr, "[tests/run-emitter.c] exit compare_events 15\n");
            
            fprintf(stderr, "[tests/run-emitter.c] enter compare_events 17\n");
            if ((event1->data.scalar.tag && !event2->data.scalar.tag
                        && strcmp((char *)event1->data.scalar.tag, "!") != 0)
                    || (!event1->data.scalar.tag && event2->data.scalar.tag
                        && strcmp((char *)event2->data.scalar.tag, "!") != 0)
                    || (event1->data.scalar.tag && event2->data.scalar.tag
                        && strcmp((char *)event1->data.scalar.tag,
                            (char *)event2->data.scalar.tag) != 0))
            {
                fprintf(stderr, "[tests/run-emitter.c] enter compare_events 18\n");
                return 0;
                fprintf(stderr, "[tests/run-emitter.c] exit compare_events 18\n");
            }
            fprintf(stderr, "[tests/run-emitter.c] exit compare_events 17\n");
            
            fprintf(stderr, "[tests/run-emitter.c] enter compare_events 19\n");
            if ((event1->data.scalar.length != event2->data.scalar.length)
                    || memcmp(event1->data.scalar.value, event2->data.scalar.value,
                        event1->data.scalar.length) != 0)
            {
                fprintf(stderr, "[tests/run-emitter.c] enter compare_events 20\n");
                return 0;
                fprintf(stderr, "[tests/run-emitter.c] exit compare_events 20\n");
            }
            fprintf(stderr, "[tests/run-emitter.c] exit compare_events 19\n");
            
            fprintf(stderr, "[tests/run-emitter.c] enter compare_events 21\n");
            if ((event1->data.scalar.plain_implicit != event2->data.scalar.plain_implicit)
                    || (event1->data.scalar.quoted_implicit != event2->data.scalar.quoted_implicit)
                    /* || (event2->data.scalar.style != event2->data.scalar.style) */)
            {
                fprintf(stderr, "[tests/run-emitter.c] enter compare_events 22\n");
                return 0;
                fprintf(stderr, "[tests/run-emitter.c] exit compare_events 22\n");
            }
            fprintf(stderr, "[tests/run-emitter.c] exit compare_events 21\n");
            
            fprintf(stderr, "[tests/run-emitter.c] enter compare_events 23\n");
            return 1;
            fprintf(stderr, "[tests/run-emitter.c] exit compare_events 23\n");

        case YAML_SEQUENCE_START_EVENT:
            fprintf(stderr, "[tests/run-emitter.c] enter compare_events 24\n");
            if ((event1->data.sequence_start.anchor && !event2->data.sequence_start.anchor)
                    || (!event1->data.sequence_start.anchor && event2->data.sequence_start.anchor)
                    || (event1->data.sequence_start.anchor && event2->data.sequence_start.anchor
                        && strcmp((char *)event1->data.sequence_start.anchor,
                            (char *)event2->data.sequence_start.anchor) != 0))
            {
                fprintf(stderr, "[tests/run-emitter.c] enter compare_events 25\n");
                return 0;
                fprintf(stderr, "[tests/run-emitter.c] exit compare_events 25\n");
            }
            fprintf(stderr, "[tests/run-emitter.c] exit compare_events 24\n");
            
            fprintf(stderr, "[tests/run-emitter.c] enter compare_events 26\n");
            if ((event1->data.sequence_start.tag && !event2->data.sequence_start.tag)
                    || (!event1->data.sequence_start.tag && event2->data.sequence_start.tag)
                    || (event1->data.sequence_start.tag && event2->data.sequence_start.tag
                        && strcmp((char *)event1->data.sequence_start.tag,
                            (char *)event2->data.sequence_start.tag) != 0))
            {
                fprintf(stderr, "[tests/run-emitter.c] enter compare_events 27\n");
                return 0;
                fprintf(stderr, "[tests/run-emitter.c] exit compare_events 27\n");
            }
            fprintf(stderr, "[tests/run-emitter.c] exit compare_events 26\n");
            
            fprintf(stderr, "[tests/run-emitter.c] enter compare_events 28\n");
            if ((event1->data.sequence_start.implicit != event2->data.sequence_start.implicit)
                    /* || (event2->data.sequence_start.style != event2->data.sequence_start.style) */)
            {
                fprintf(stderr, "[tests/run-emitter.c] enter compare_events 29\n");
                return 0;
                fprintf(stderr, "[tests/run-emitter.c] exit compare_events 29\n");
            }
            fprintf(stderr, "[tests/run-emitter.c] exit compare_events 28\n");
            
            fprintf(stderr, "[tests/run-emitter.c] enter compare_events 30\n");
            return 1;
            fprintf(stderr, "[tests/run-emitter.c] exit compare_events 30\n");

        case YAML_MAPPING_START_EVENT:
            fprintf(stderr, "[tests/run-emitter.c] enter compare_events 31\n");
            if ((event1->data.mapping_start.anchor && !event2->data.mapping_start.anchor)
                    || (!event1->data.mapping_start.anchor && event2->data.mapping_start.anchor)
                    || (event1->data.mapping_start.anchor && event2->data.mapping_start.anchor
                        && strcmp((char *)event1->data.mapping_start.anchor,
                            (char *)event2->data.mapping_start.anchor) != 0))
            {
                fprintf(stderr, "[tests/run-emitter.c] enter compare_events 32\n");
                return 0;
                fprintf(stderr, "[tests/run-emitter.c] exit compare_events 32\n");
            }
            fprintf(stderr, "[tests/run-emitter.c] exit compare_events 31\n");
            
            fprintf(stderr, "[tests/run-emitter.c] enter compare_events 33\n");
            if ((event1->data.mapping_start.tag && !event2->data.mapping_start.tag)
                    || (!event1->data.mapping_start.tag && event2->data.mapping_start.tag)
                    || (event1->data.mapping_start.tag && event2->data.mapping_start.tag
                        && strcmp((char *)event1->data.mapping_start.tag,
                            (char *)event2->data.mapping_start.tag) != 0))
            {
                fprintf(stderr, "[tests/run-emitter.c] enter compare_events 34\n");
                return 0;
                fprintf(stderr, "[tests/run-emitter.c] exit compare_events 34\n");
            }
            fprintf(stderr, "[tests/run-emitter.c] exit compare_events 33\n");
            
            fprintf(stderr, "[tests/run-emitter.c] enter compare_events 35\n");
            if ((event1->data.mapping_start.implicit != event2->data.mapping_start.implicit)
                    /* || (event2->data.mapping_start.style != event2->data.mapping_start.style) */)
            {
                fprintf(stderr, "[tests/run-emitter.c] enter compare_events 36\n");
                return 0;
                fprintf(stderr, "[tests/run-emitter.c] exit compare_events 36\n");
            }
            fprintf(stderr, "[tests/run-emitter.c] exit compare_events 35\n");
            
            fprintf(stderr, "[tests/run-emitter.c] enter compare_events 37\n");
            return 1;
            fprintf(stderr, "[tests/run-emitter.c] exit compare_events 37\n");

        default:
            fprintf(stderr, "[tests/run-emitter.c] enter compare_events 38\n");
            return 1;
            fprintf(stderr, "[tests/run-emitter.c] exit compare_events 38\n");
    }
    fprintf(stderr, "[tests/run-emitter.c] exit compare_events 3\n");
}

int print_output(char *name, unsigned char *buffer, size_t size, int count)
{
    fprintf(stderr, "[tests/run-emitter.c] enter print_output 1\n");
    FILE *file;
    char data[BUFFER_SIZE];
    size_t data_size = 1;
    size_t total_size = 0;
    if (count >= 0) {
        fprintf(stderr, "[tests/run-emitter.c] enter print_output 2\n");
        printf("FAILED (at the event #%d)\nSOURCE:\n", count+1);
        fprintf(stderr, "[tests/run-emitter.c] exit print_output 2\n");
    }
    fprintf(stderr, "[tests/run-emitter.c] exit print_output 1\n");
    
    fprintf(stderr, "[tests/run-emitter.c] enter print_output 3\n");
    file = fopen(name, "rb");
    assert(file);
    fprintf(stderr, "[tests/run-emitter.c] exit print_output 3\n");
    
    fprintf(stderr, "[tests/run-emitter.c] enter print_output 4\n");
    while (data_size > 0) {
        fprintf(stderr, "[tests/run-emitter.c] enter print_output 5\n");
        data_size = fread(data, 1, BUFFER_SIZE, file);
        assert(!ferror(file));
        if (!data_size) {
            fprintf(stderr, "[tests/run-emitter.c] enter print_output 6\n");
            break;
            fprintf(stderr, "[tests/run-emitter.c] exit print_output 6\n");
        }
        fprintf(stderr, "[tests/run-emitter.c] exit print_output 5\n");
        
        fprintf(stderr, "[tests/run-emitter.c] enter print_output 7\n");
        assert(fwrite(data, 1, data_size, stdout) == data_size);
        total_size += data_size;
        fprintf(stderr, "[tests/run-emitter.c] exit print_output 7\n");
        
        fprintf(stderr, "[tests/run-emitter.c] enter print_output 8\n");
        if (feof(file)) {
            fprintf(stderr, "[tests/run-emitter.c] enter print_output 9\n");
            break;
            fprintf(stderr, "[tests/run-emitter.c] exit print_output 9\n");
        }
        fprintf(stderr, "[tests/run-emitter.c] exit print_output 8\n");
    }
    fprintf(stderr, "[tests/run-emitter.c] exit print_output 4\n");
    
    fprintf(stderr, "[tests/run-emitter.c] enter print_output 10\n");
    fclose(file);
    printf("#### (length: %ld)\n", (long)total_size);
    printf("OUTPUT:\n%s#### (length: %ld)\n", buffer, (long)size);
    return 0;
    fprintf(stderr, "[tests/run-emitter.c] exit print_output 10\n");
}

int
main(int argc, char *argv[])
{
    fprintf(stderr, "[tests/run-emitter.c] enter main 1\n");
    int number;
    int canonical = 0;
    int unicode = 0;
    fprintf(stderr, "[tests/run-emitter.c] exit main 1\n");

    fprintf(stderr, "[tests/run-emitter.c] enter main 2\n");
    number = 1;
    fprintf(stderr, "[tests/run-emitter.c] exit main 2\n");
    
    fprintf(stderr, "[tests/run-emitter.c] enter main 3\n");
    while (number < argc) {
        fprintf(stderr, "[tests/run-emitter.c] enter main 4\n");
        if (strcmp(argv[number], "-c") == 0) {
            fprintf(stderr, "[tests/run-emitter.c] enter main 5\n");
            canonical = 1;
            fprintf(stderr, "[tests/run-emitter.c] exit main 5\n");
        }
        else if (strcmp(argv[number], "-u") == 0) {
            fprintf(stderr, "[tests/run-emitter.c] enter main 6\n");
            unicode = 1;
            fprintf(stderr, "[tests/run-emitter.c] exit main 6\n");
        }
        else if (argv[number][0] == '-') {
            fprintf(stderr, "[tests/run-emitter.c] enter main 7\n");
            printf("Unknown option: '%s'\n", argv[number]);
            return 0;
            fprintf(stderr, "[tests/run-emitter.c] exit main 7\n");
        }
        fprintf(stderr, "[tests/run-emitter.c] exit main 4\n");
        
        fprintf(stderr, "[tests/run-emitter.c] enter main 8\n");
        if (argv[number][0] == '-') {
            fprintf(stderr, "[tests/run-emitter.c] enter main 9\n");
            if (number < argc-1) {
                fprintf(stderr, "[tests/run-emitter.c] enter main 10\n");
                memmove(argv+number, argv+number+1, (argc-number-1)*sizeof(char *));
                fprintf(stderr, "[tests/run-emitter.c] exit main 10\n");
            }
            fprintf(stderr, "[tests/run-emitter.c] exit main 9\n");
            
            fprintf(stderr, "[tests/run-emitter.c] enter main 11\n");
            argc --;
            fprintf(stderr, "[tests/run-emitter.c] exit main 11\n");
        }
        else {
            fprintf(stderr, "[tests/run-emitter.c] enter main 12\n");
            number ++;
            fprintf(stderr, "[tests/run-emitter.c] exit main 12\n");
        }
        fprintf(stderr, "[tests/run-emitter.c] exit main 8\n");
    }
    fprintf(stderr, "[tests/run-emitter.c] exit main 3\n");

    fprintf(stderr, "[tests/run-emitter.c] enter main 13\n");
    if (argc < 2) {
        fprintf(stderr, "[tests/run-emitter.c] enter main 14\n");
        printf("Usage: %s [-c] [-u] file1.yaml ...\n", argv[0]);
        return 0;
        fprintf(stderr, "[tests/run-emitter.c] exit main 14\n");
    }
    fprintf(stderr, "[tests/run-emitter.c] exit main 13\n");

    fprintf(stderr, "[tests/run-emitter.c] enter main 15\n");
    for (number = 1; number < argc; number ++)
    {
        fprintf(stderr, "[tests/run-emitter.c] enter main 16\n");
        FILE *file;
        yaml_parser_t parser;
        yaml_emitter_t emitter;
        yaml_event_t event;
        unsigned char buffer[BUFFER_SIZE+1];
        size_t written = 0;
        yaml_event_t events[MAX_EVENTS];
        size_t event_number = 0;
        int done = 0;
        int count = 0;
        int error = 0;
        int k;
        memset(buffer, 0, BUFFER_SIZE+1);
        memset(events, 0, MAX_EVENTS*sizeof(yaml_event_t));
        fprintf(stderr, "[tests/run-emitter.c] exit main 16\n");

        fprintf(stderr, "[tests/run-emitter.c] enter main 17\n");
        printf("[%d] Parsing, emitting, and parsing again '%s': ", number, argv[number]);
        fflush(stdout);
        fprintf(stderr, "[tests/run-emitter.c] exit main 17\n");

        fprintf(stderr, "[tests/run-emitter.c] enter main 18\n");
        file = fopen(argv[number], "rb");
        assert(file);
        fprintf(stderr, "[tests/run-emitter.c] exit main 18\n");

        fprintf(stderr, "[tests/run-emitter.c] enter main 19\n");
        assert(yaml_parser_initialize(&parser));
        yaml_parser_set_input_file(&parser, file);
        assert(yaml_emitter_initialize(&emitter));
        if (canonical) {
            fprintf(stderr, "[tests/run-emitter.c] enter main 20\n");
            yaml_emitter_set_canonical(&emitter, 1);
            fprintf(stderr, "[tests/run-emitter.c] exit main 20\n");
        }
        fprintf(stderr, "[tests/run-emitter.c] exit main 19\n");
        
        fprintf(stderr, "[tests/run-emitter.c] enter main 21\n");
        if (unicode) {
            fprintf(stderr, "[tests/run-emitter.c] enter main 22\n");
            yaml_emitter_set_unicode(&emitter, 1);
            fprintf(stderr, "[tests/run-emitter.c] exit main 22\n");
        }
        fprintf(stderr, "[tests/run-emitter.c] exit main 21\n");
        
        fprintf(stderr, "[tests/run-emitter.c] enter main 23\n");
        yaml_emitter_set_output_string(&emitter, buffer, BUFFER_SIZE, &written);
        fprintf(stderr, "[tests/run-emitter.c] exit main 23\n");

        fprintf(stderr, "[tests/run-emitter.c] enter main 24\n");
        while (!done)
        {
            fprintf(stderr, "[tests/run-emitter.c] enter main 25\n");
            if (!yaml_parser_parse(&parser, &event)) {
                fprintf(stderr, "[tests/run-emitter.c] enter main 26\n");
                error = 1;
                break;
                fprintf(stderr, "[tests/run-emitter.c] exit main 26\n");
            }
            fprintf(stderr, "[tests/run-emitter.c] exit main 25\n");

            fprintf(stderr, "[tests/run-emitter.c] enter main 27\n");
            done = (event.type == YAML_STREAM_END_EVENT);
            assert(event_number < MAX_EVENTS);
            assert(copy_event(&(events[event_number++]), &event));
            assert(yaml_emitter_emit(&emitter, &event) || 
                    print_output(argv[number], buffer, written, count));
            count ++;
            fprintf(stderr, "[tests/run-emitter.c] exit main 27\n");
        }
        fprintf(stderr, "[tests/run-emitter.c] exit main 24\n");

        fprintf(stderr, "[tests/run-emitter.c] enter main 28\n");
        yaml_parser_delete(&parser);
        assert(!fclose(file));
        yaml_emitter_delete(&emitter);
        fprintf(stderr, "[tests/run-emitter.c] exit main 28\n");

        fprintf(stderr, "[tests/run-emitter.c] enter main 29\n");
        if (!error)
        {
            fprintf(stderr, "[tests/run-emitter.c] enter main 30\n");
            count = done = 0;
            assert(yaml_parser_initialize(&parser));
            yaml_parser_set_input_string(&parser, buffer, written);
            fprintf(stderr, "[tests/run-emitter.c] exit main 30\n");

            fprintf(stderr, "[tests/run-emitter.c] enter main 31\n");
            while (!done)
            {
                fprintf(stderr, "[tests/run-emitter.c] enter main 32\n");
                assert(yaml_parser_parse(&parser, &event) || print_output(argv[number], buffer, written, count));
                done = (event.type == YAML_STREAM_END_EVENT);
                assert(compare_events(events+count, &event) || print_output(argv[number], buffer, written, count));
                yaml_event_delete(&event);
                count ++;
                fprintf(stderr, "[tests/run-emitter.c] exit main 32\n");
            }
            fprintf(stderr, "[tests/run-emitter.c] exit main 31\n");
            
            fprintf(stderr, "[tests/run-emitter.c] enter main 33\n");
            yaml_parser_delete(&parser);
            fprintf(stderr, "[tests/run-emitter.c] exit main 33\n");
        }
        fprintf(stderr, "[tests/run-emitter.c] exit main 29\n");

        fprintf(stderr, "[tests/run-emitter.c] enter main 34\n");
        for (k = 0; k < event_number; k ++) {
            fprintf(stderr, "[tests/run-emitter.c] enter main 35\n");
            yaml_event_delete(events+k);
            fprintf(stderr, "[tests/run-emitter.c] exit main 35\n");
        }
        fprintf(stderr, "[tests/run-emitter.c] exit main 34\n");

        fprintf(stderr, "[tests/run-emitter.c] enter main 36\n");
        printf("PASSED (length: %ld)\n", (long)written);
        print_output(argv[number], buffer, written, -1);
        fprintf(stderr, "[tests/run-emitter.c] exit main 36\n");
    }
    fprintf(stderr, "[tests/run-emitter.c] exit main 15\n");

    fprintf(stderr, "[tests/run-emitter.c] enter main 37\n");
    return 0;
    fprintf(stderr, "[tests/run-emitter.c] exit main 37\n");
}
// Total cost: 0.132340
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 327)]
// Total instrumented cost: 0.132340, input tokens: 6218, output tokens: 7006, cache read tokens: 2280, cache write tokens: 3934

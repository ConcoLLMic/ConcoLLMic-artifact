#include <yaml.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

void print_escaped(yaml_char_t * str, size_t length);
int usage(int ret);

int main(int argc, char *argv[])
{
    fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 1\n");
    FILE *input;
    yaml_parser_t parser;
    yaml_event_t event;
    int flow = -1; /** default no flow style collections */
    int i = 0;
    int foundfile = 0;
    int max_level;
    char *output;
    fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 1\n");

    for (i = 1; i < argc; i++) {
        fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 2\n");
        if (strncmp(argv[i], "--max-level", 11) == 0) {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 3\n");
            i++;
            max_level = strtol(argv[i], &output, 10);
            yaml_set_max_nest_level(max_level);
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 3\n");
        }
        else if (strncmp(argv[i], "--flow", 6) == 0) {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 4\n");
            if (i+1 == argc)
                return usage(1);
            i++;
            if (strncmp(argv[i], "keep", 4) == 0) {
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 5\n");
                flow = 0;
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 5\n");
            }
            else if (strncmp(argv[i], "on", 2) == 0) {
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 6\n");
                flow = 1;
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 6\n");
            }
            else if (strncmp(argv[i], "off", 3) == 0) {
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 7\n");
                flow = -1;
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 7\n");
            }
            else {
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 8\n");
                return usage(1);
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 8\n");
            }
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 4\n");
        }
        else if (strncmp(argv[i], "--help", 6) == 0) {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 9\n");
            return usage(0);
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 9\n");
        }
        else if (strncmp(argv[i], "-h", 2) == 0) {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 10\n");
            return usage(0);
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 10\n");
        }
        else if (!foundfile) {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 11\n");
            input = fopen(argv[i], "rb");
            foundfile = 1;
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 11\n");
        }
        else {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 12\n");
            return usage(1);
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 12\n");
        }
        fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 2\n");
    }
    
    fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 13\n");
    if (!foundfile) {
        fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 14\n");
        input = stdin;
        fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 14\n");
    }
    assert(input);

    if (!yaml_parser_initialize(&parser)) {
        fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 15\n");
        fprintf(stderr, "Could not initialize the parser object\n");
        return 1;
        fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 15\n");
    }
    yaml_parser_set_input_file(&parser, input);
    fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 13\n");

    while (1) {
        fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 16\n");
        yaml_event_type_t type;
        if (!yaml_parser_parse(&parser, &event)) {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 17\n");
            if ( parser.problem_mark.line || parser.problem_mark.column ) {
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 18\n");
                fprintf(stderr, "Parse error: %s\nLine: %lu Column: %lu\n",
                    parser.problem,
                    (unsigned long)parser.problem_mark.line + 1,
                    (unsigned long)parser.problem_mark.column + 1);
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 18\n");
            }
            else {
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 19\n");
                fprintf(stderr, "Parse error: %s\n", parser.problem);
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 19\n");
            }
            return 1;
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 17\n");
        }
        type = event.type;

        if (type == YAML_NO_EVENT) {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 20\n");
            printf("???\n");
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 20\n");
        }
        else if (type == YAML_STREAM_START_EVENT) {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 21\n");
            printf("+STR\n");
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 21\n");
        }
        else if (type == YAML_STREAM_END_EVENT) {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 22\n");
            printf("-STR\n");
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 22\n");
        }
        else if (type == YAML_DOCUMENT_START_EVENT) {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 23\n");
            printf("+DOC");
            if (!event.data.document_start.implicit) {
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 24\n");
                printf(" ---");
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 24\n");
            }
            printf("\n");
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 23\n");
        }
        else if (type == YAML_DOCUMENT_END_EVENT) {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 25\n");
            printf("-DOC");
            if (!event.data.document_end.implicit) {
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 26\n");
                printf(" ...");
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 26\n");
            }
            printf("\n");
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 25\n");
        }
        else if (type == YAML_MAPPING_START_EVENT) {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 27\n");
            printf("+MAP");
            if (flow == 0 && event.data.mapping_start.style == YAML_FLOW_MAPPING_STYLE) {
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 28\n");
                printf(" {}");
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 28\n");
            }
            else if (flow == 1) {
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 29\n");
                printf(" {}");
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 29\n");
            }
            if (event.data.mapping_start.anchor) {
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 30\n");
                printf(" &%s", event.data.mapping_start.anchor);
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 30\n");
            }
            if (event.data.mapping_start.tag) {
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 31\n");
                printf(" <%s>", event.data.mapping_start.tag);
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 31\n");
            }
            printf("\n");
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 27\n");
        }
        else if (type == YAML_MAPPING_END_EVENT) {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 32\n");
            printf("-MAP\n");
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 32\n");
        }
        else if (type == YAML_SEQUENCE_START_EVENT) {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 33\n");
            printf("+SEQ");
            if (flow == 0 && event.data.sequence_start.style == YAML_FLOW_SEQUENCE_STYLE) {
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 34\n");
                printf(" []");
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 34\n");
            }
            else if (flow == 1) {
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 35\n");
                printf(" []");
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 35\n");
            }
            if (event.data.sequence_start.anchor) {
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 36\n");
                printf(" &%s", event.data.sequence_start.anchor);
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 36\n");
            }
            if (event.data.sequence_start.tag) {
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 37\n");
                printf(" <%s>", event.data.sequence_start.tag);
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 37\n");
            }
            printf("\n");
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 33\n");
        }
        else if (type == YAML_SEQUENCE_END_EVENT) {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 38\n");
            printf("-SEQ\n");
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 38\n");
        }
        else if (type == YAML_SCALAR_EVENT) {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 39\n");
            printf("=VAL");
            if (event.data.scalar.anchor) {
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 40\n");
                printf(" &%s", event.data.scalar.anchor);
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 40\n");
            }
            if (event.data.scalar.tag) {
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 41\n");
                printf(" <%s>", event.data.scalar.tag);
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 41\n");
            }
            switch (event.data.scalar.style) {
            case YAML_PLAIN_SCALAR_STYLE:
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 42\n");
                printf(" :");
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 42\n");
                break;
            case YAML_SINGLE_QUOTED_SCALAR_STYLE:
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 43\n");
                printf(" '");
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 43\n");
                break;
            case YAML_DOUBLE_QUOTED_SCALAR_STYLE:
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 44\n");
                printf(" \"");
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 44\n");
                break;
            case YAML_LITERAL_SCALAR_STYLE:
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 45\n");
                printf(" |");
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 45\n");
                break;
            case YAML_FOLDED_SCALAR_STYLE:
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 46\n");
                printf(" >");
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 46\n");
                break;
            case YAML_ANY_SCALAR_STYLE:
                fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 47\n");
                abort();
                fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 47\n");
            }
            print_escaped(event.data.scalar.value, event.data.scalar.length);
            printf("\n");
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 39\n");
        }
        else if (type == YAML_ALIAS_EVENT) {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 48\n");
            printf("=ALI *%s\n", event.data.alias.anchor);
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 48\n");
        }
        else {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 49\n");
            abort();
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 49\n");
        }

        yaml_event_delete(&event);

        if (type == YAML_STREAM_END_EVENT) {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 50\n");
            break;
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 50\n");
        }
        fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 16\n");
    }

    fprintf(stderr, "[tests/run-parser-test-suite.c] enter main 51\n");
    assert(!fclose(input));
    yaml_parser_delete(&parser);
    fflush(stdout);

    return 0;
    fprintf(stderr, "[tests/run-parser-test-suite.c] exit main 51\n");
}

void print_escaped(yaml_char_t * str, size_t length)
{
    fprintf(stderr, "[tests/run-parser-test-suite.c] enter print_escaped 1\n");
    int i;
    char c;

    for (i = 0; i < length; i++) {
        fprintf(stderr, "[tests/run-parser-test-suite.c] enter print_escaped 2\n");
        c = *(str + i);
        if (c == '\\') {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter print_escaped 3\n");
            printf("\\\\");
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit print_escaped 3\n");
        }
        else if (c == '\0') {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter print_escaped 4\n");
            printf("\\0");
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit print_escaped 4\n");
        }
        else if (c == '\b') {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter print_escaped 5\n");
            printf("\\b");
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit print_escaped 5\n");
        }
        else if (c == '\n') {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter print_escaped 6\n");
            printf("\\n");
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit print_escaped 6\n");
        }
        else if (c == '\r') {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter print_escaped 7\n");
            printf("\\r");
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit print_escaped 7\n");
        }
        else if (c == '\t') {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter print_escaped 8\n");
            printf("\\t");
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit print_escaped 8\n");
        }
        else {
            fprintf(stderr, "[tests/run-parser-test-suite.c] enter print_escaped 9\n");
            printf("%c", c);
            fprintf(stderr, "[tests/run-parser-test-suite.c] exit print_escaped 9\n");
        }
        fprintf(stderr, "[tests/run-parser-test-suite.c] exit print_escaped 2\n");
    }
    fprintf(stderr, "[tests/run-parser-test-suite.c] exit print_escaped 1\n");
}

int usage(int ret) {
    fprintf(stderr, "[tests/run-parser-test-suite.c] enter usage 1\n");
    fprintf(stderr, "Usage: libyaml-parser [--flow (on|off|keep)] [<input-file>]\n");
    return ret;
    fprintf(stderr, "[tests/run-parser-test-suite.c] exit usage 1\n");
}
// Total cost: 0.085180
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 196)]
// Total instrumented cost: 0.085180, input tokens: 4217, output tokens: 3782, cache read tokens: 0, cache write tokens: 4213

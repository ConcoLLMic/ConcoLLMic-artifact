#include <yaml.h>

#include <stdlib.h>
#include <stdio.h>

#ifdef NDEBUG
#undef NDEBUG
#endif
#include <assert.h>

int
main(int argc, char *argv[])
{
    fprintf(stderr, "[tests/run-scanner.c] enter main 1\n");
    int number;

    if (argc < 2) {
        fprintf(stderr, "[tests/run-scanner.c] enter main 2\n");
        printf("Usage: %s file1.yaml ...\n", argv[0]);
        return 0;
        fprintf(stderr, "[tests/run-scanner.c] exit main 2\n");
    }
    fprintf(stderr, "[tests/run-scanner.c] exit main 1\n");

    for (number = 1; number < argc; number ++)
    {
        fprintf(stderr, "[tests/run-scanner.c] enter main 3\n");
        FILE *file;
        yaml_parser_t parser;
        yaml_token_t token;
        int done = 0;
        int count = 0;
        int error = 0;

        printf("[%d] Scanning '%s': ", number, argv[number]);
        fflush(stdout);

        file = fopen(argv[number], "rb");
        assert(file);

        assert(yaml_parser_initialize(&parser));

        yaml_parser_set_input_file(&parser, file);
        fprintf(stderr, "[tests/run-scanner.c] exit main 3\n");

        while (!done)
        {
            fprintf(stderr, "[tests/run-scanner.c] enter main 4\n");
            if (!yaml_parser_scan(&parser, &token)) {
                fprintf(stderr, "[tests/run-scanner.c] enter main 5\n");
                error = 1;
                break;
                fprintf(stderr, "[tests/run-scanner.c] exit main 5\n");
            }

            fprintf(stderr, "[tests/run-scanner.c] enter main 6\n");
            done = (token.type == YAML_STREAM_END_TOKEN);

            yaml_token_delete(&token);

            count ++;
            fprintf(stderr, "[tests/run-scanner.c] exit main 6\n");
            fprintf(stderr, "[tests/run-scanner.c] exit main 4\n");
        }

        fprintf(stderr, "[tests/run-scanner.c] enter main 7\n");
        yaml_parser_delete(&parser);

        assert(!fclose(file));

        printf("%s (%d tokens)\n", (error ? "FAILURE" : "SUCCESS"), count);
        fprintf(stderr, "[tests/run-scanner.c] exit main 7\n");
    }

    fprintf(stderr, "[tests/run-scanner.c] enter main 8\n");
    return 0;
    fprintf(stderr, "[tests/run-scanner.c] exit main 8\n");
}
// Total cost: 0.027723
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 63)]
// Total instrumented cost: 0.027723, input tokens: 2716, output tokens: 627, cache read tokens: 0, cache write tokens: 2712

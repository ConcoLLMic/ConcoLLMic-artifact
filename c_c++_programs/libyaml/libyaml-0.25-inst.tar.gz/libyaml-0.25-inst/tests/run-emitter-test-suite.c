#include <yaml.h>

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "../src/yaml_private.h"

int get_line(FILE * input, char *line);
char *get_anchor(char sigil, char *line, char *anchor);
char *get_tag(char *line, char *tag);
void get_value(char *line, char *value, int *style);
int usage(int ret);

int main(int argc, char *argv[])
{
    fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 1\n");
    FILE *input;
    yaml_emitter_t emitter;
    yaml_event_t event;
    yaml_version_directive_t *version_directive = NULL;

    int canonical = 0;
    int unicode = 0;
    char line[1024];
    int foundfile = 0;
    int i = 0;
    int minor = 0;
    int flow = -1; /** default no flow style collections */
    fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 1\n");

    for (i = 1; i < argc; i++) {
        fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 2\n");
        if (strncmp(argv[i], "--help", 6) == 0) {
            fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 3\n");
            return usage(0);
            fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 3\n");
        }
        if (strncmp(argv[i], "-h", 2) == 0) {
            fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 4\n");
            return usage(0);
            fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 4\n");
        }
        if (strncmp(argv[i], "--flow", 6) == 0) {
            fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 5\n");
            if (i+1 == argc) {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 6\n");
                return usage(1);
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 6\n");
            }
            i++;
            if (strncmp(argv[i], "keep", 4) == 0) {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 7\n");
                flow = 0;
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 7\n");
            }
            else if (strncmp(argv[i], "on", 2) == 0) {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 8\n");
                flow = 1;
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 8\n");
            }
            else if (strncmp(argv[i], "off", 3) == 0) {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 9\n");
                flow = -1;
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 9\n");
            }
            else {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 10\n");
                return usage(1);
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 10\n");
            }
            fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 5\n");
        }
        else if (strncmp(argv[i], "--directive", 11) == 0) {
            fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 11\n");
            if (i+1 == argc) {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 12\n");
                return usage(1);
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 12\n");
            }
            i++;
            if (strncmp(argv[i], "1.1", 3) == 0) {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 13\n");
                minor = 1;
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 13\n");
            }
            else if (strncmp(argv[i], "1.2", 3) == 0) {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 14\n");
                minor = 2;
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 14\n");
            }
            else {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 15\n");
                return usage(1);
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 15\n");
            }
            fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 11\n");
        }
        else if (!foundfile) {
            fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 16\n");
            input = fopen(argv[i], "rb");
            foundfile = 1;
            fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 16\n");
        }
        fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 2\n");
    }
    
    fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 17\n");
    if (minor) {
        fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 18\n");
        version_directive = YAML_MALLOC_STATIC(yaml_version_directive_t);
        version_directive->major = 1;
        version_directive->minor = minor;
        fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 18\n");
    }
    if (!foundfile) {
        fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 19\n");
        input = stdin;
        fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 19\n");
    }

    assert(input);

    if (!yaml_emitter_initialize(&emitter)) {
        fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 20\n");
        fprintf(stderr, "Could not initialize the emitter object\n");
        return 1;
        fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 20\n");
    }
    yaml_emitter_set_output_file(&emitter, stdout);
    yaml_emitter_set_canonical(&emitter, canonical);
    yaml_emitter_set_unicode(&emitter, unicode);
    fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 17\n");

    while (get_line(input, line)) {
        fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 21\n");
        int ok;
        char anchor[256];
        char tag[256];
        int implicit;
        int style;

        if (strncmp(line, "+STR", 4) == 0) {
            fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 22\n");
            ok = yaml_stream_start_event_initialize(&event, YAML_UTF8_ENCODING);
            fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 22\n");
        }
        else if (strncmp(line, "-STR", 4) == 0) {
            fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 23\n");
            ok = yaml_stream_end_event_initialize(&event);
            fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 23\n");
        }
        else if (strncmp(line, "+DOC", 4) == 0) {
            fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 24\n");
            implicit = strncmp(line+4, " ---", 4) != 0;
            ok = yaml_document_start_event_initialize(&event, version_directive, NULL, NULL, implicit);
            fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 24\n");
        }
        else if (strncmp(line, "-DOC", 4) == 0) {
            fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 25\n");
            implicit = strncmp(line+4, " ...", 4) != 0;
            ok = yaml_document_end_event_initialize(&event, implicit);
            fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 25\n");
        }
        else if (strncmp(line, "+MAP", 4) == 0) {
            fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 26\n");
            style = YAML_BLOCK_MAPPING_STYLE;
            if (flow == 1) {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 27\n");
                style = YAML_FLOW_MAPPING_STYLE;
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 27\n");
            }
            else if (flow == 0 && strncmp(line+5, "{}", 2) == 0) {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 28\n");
                style = YAML_FLOW_MAPPING_STYLE;
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 28\n");
            }
            ok = yaml_mapping_start_event_initialize(&event, (yaml_char_t *)
                                                     get_anchor('&', line, anchor), (yaml_char_t *)
                                                     get_tag(line, tag), 0, style);
            fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 26\n");
        }
        else if (strncmp(line, "-MAP", 4) == 0) {
            fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 29\n");
            ok = yaml_mapping_end_event_initialize(&event);
            fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 29\n");
        }
        else if (strncmp(line, "+SEQ", 4) == 0) {
            fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 30\n");
            style = YAML_BLOCK_SEQUENCE_STYLE;
            if (flow == 1) {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 31\n");
                style = YAML_FLOW_MAPPING_STYLE;
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 31\n");
            }
            else if (flow == 0 && strncmp(line+5, "[]", 2) == 0) {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 32\n");
                style = YAML_FLOW_SEQUENCE_STYLE;
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 32\n");
            }
            ok = yaml_sequence_start_event_initialize(&event, (yaml_char_t *)
                                                      get_anchor('&', line, anchor), (yaml_char_t *)
                                                      get_tag(line, tag), 0, style);
            fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 30\n");
        }
        else if (strncmp(line, "-SEQ", 4) == 0) {
            fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 33\n");
            ok = yaml_sequence_end_event_initialize(&event);
            fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 33\n");
        }
        else if (strncmp(line, "=VAL", 4) == 0) {
            fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 34\n");
            char value[1024];
            int style;

            get_value(line, value, &style);
            implicit = (get_tag(line, tag) == NULL);

            ok = yaml_scalar_event_initialize(&event, (yaml_char_t *)
                                              get_anchor('&', line, anchor), (yaml_char_t *) get_tag(line, tag), (yaml_char_t *) value, -1, implicit, implicit, style);
            fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 34\n");
        }
        else if (strncmp(line, "=ALI", 4) == 0) {
            fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 35\n");
            ok = yaml_alias_event_initialize(&event, (yaml_char_t *)
                                             get_anchor('*', line, anchor)
                );
            fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 35\n");
        }
        else {
            fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 36\n");
            fprintf(stderr, "Unknown event: '%s'\n", line);
            fflush(stdout);
            return 1;
            fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 36\n");
        }

        if (!ok) {
            fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 37\n");
            goto event_error;
            fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 37\n");
        }
        if (!yaml_emitter_emit(&emitter, &event)) {
            fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 38\n");
            goto emitter_error;
            fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 38\n");
        }
        fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 21\n");
    }

    fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 39\n");
    assert(!fclose(input));
    yaml_emitter_delete(&emitter);
    fflush(stdout);

    return 0;
    fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 39\n");

  emitter_error:
    fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 40\n");
    switch (emitter.error) {
    case YAML_MEMORY_ERROR:
        fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 41\n");
        fprintf(stderr, "Memory error: Not enough memory for emitting\n");
        fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 41\n");
        break;
    case YAML_WRITER_ERROR:
        fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 42\n");
        fprintf(stderr, "Writer error: %s\n", emitter.problem);
        fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 42\n");
        break;
    case YAML_EMITTER_ERROR:
        fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 43\n");
        fprintf(stderr, "Emitter error: %s\n", emitter.problem);
        fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 43\n");
        break;
    default:
        /*
         * Couldn't happen. 
         */
        fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 44\n");
        fprintf(stderr, "Internal error\n");
        fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 44\n");
        break;
    }
    yaml_emitter_delete(&emitter);
    return 1;
    fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 40\n");

  event_error:
    fprintf(stderr, "[tests/run-emitter-test-suite.c] enter main 45\n");
    fprintf(stderr, "Memory error: Not enough memory for creating an event\n");
    yaml_emitter_delete(&emitter);
    return 1;
    fprintf(stderr, "[tests/run-emitter-test-suite.c] exit main 45\n");
}

int get_line(FILE * input, char *line)
{
    fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_line 1\n");
    char *newline;

    if (!fgets(line, 1024 - 1, input)) {
        fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_line 2\n");
        return 0;
        fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_line 2\n");
    }

    if ((newline = strchr(line, '\n')) == NULL) {
        fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_line 3\n");
        fprintf(stderr, "Line too long: '%s'", line);
        abort();
        fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_line 3\n");
    }
    *newline = '\0';

    return 1;
    fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_line 1\n");
}

char *get_anchor(char sigil, char *line, char *anchor)
{
    fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_anchor 1\n");
    char *start;
    char *end;
    if ((start = strchr(line, sigil)) == NULL) {
        fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_anchor 2\n");
        return NULL;
        fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_anchor 2\n");
    }
    start++;
    if ((end = strchr(start, ' ')) == NULL) {
        fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_anchor 3\n");
        end = line + strlen(line);
        fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_anchor 3\n");
    }
    memcpy(anchor, start, end - start);
    anchor[end - start] = '\0';
    return anchor;
    fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_anchor 1\n");
}

char *get_tag(char *line, char *tag)
{
    fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_tag 1\n");
    char *start;
    char *end;
    if ((start = strchr(line, '<')) == NULL) {
        fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_tag 2\n");
        return NULL;
        fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_tag 2\n");
    }
    if ((end = strchr(line, '>')) == NULL) {
        fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_tag 3\n");
        return NULL;
        fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_tag 3\n");
    }
    memcpy(tag, start + 1, end - start - 1);
    tag[end - start - 1] = '\0';
    return tag;
    fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_tag 1\n");
}

void get_value(char *line, char *value, int *style)
{
    fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_value 1\n");
    int i = 0;
    char *c;
    char *start = NULL;
    char *end = line + strlen(line);

    for (c = line + 4; c < end; c++) {
        fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_value 2\n");
        if (*c == ' ') {
            fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_value 3\n");
            start = c + 1;
            if (*start == ':') {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_value 4\n");
                *style = YAML_PLAIN_SCALAR_STYLE;
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_value 4\n");
            }
            else if (*start == '\'') {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_value 5\n");
                *style = YAML_SINGLE_QUOTED_SCALAR_STYLE;
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_value 5\n");
            }
            else if (*start == '"') {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_value 6\n");
                *style = YAML_DOUBLE_QUOTED_SCALAR_STYLE;
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_value 6\n");
            }
            else if (*start == '|') {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_value 7\n");
                *style = YAML_LITERAL_SCALAR_STYLE;
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_value 7\n");
            }
            else if (*start == '>') {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_value 8\n");
                *style = YAML_FOLDED_SCALAR_STYLE;
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_value 8\n");
            }
            else {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_value 9\n");
                start = NULL;
                continue;
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_value 9\n");
            }
            start++;
            break;
            fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_value 3\n");
        }
        fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_value 2\n");
    }
    if (!start) {
        fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_value 10\n");
        abort();
        fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_value 10\n");
    }

    for (c = start; c < end; c++) {
        fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_value 11\n");
        if (*c == '\\') {
            fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_value 12\n");
            if (*++c == '\\') {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_value 13\n");
                value[i++] = '\\';
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_value 13\n");
            }
            else if (*c == '0') {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_value 14\n");
                value[i++] = '\0';
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_value 14\n");
            }
            else if (*c == 'b') {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_value 15\n");
                value[i++] = '\b';
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_value 15\n");
            }
            else if (*c == 'n') {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_value 16\n");
                value[i++] = '\n';
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_value 16\n");
            }
            else if (*c == 'r') {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_value 17\n");
                value[i++] = '\r';
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_value 17\n");
            }
            else if (*c == 't') {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_value 18\n");
                value[i++] = '\t';
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_value 18\n");
            }
            else {
                fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_value 19\n");
                abort();
                fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_value 19\n");
            }
            fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_value 12\n");
        }
        else {
            fprintf(stderr, "[tests/run-emitter-test-suite.c] enter get_value 20\n");
            value[i++] = *c;
            fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_value 20\n");
        }
        fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_value 11\n");
    }
    value[i] = '\0';
    fprintf(stderr, "[tests/run-emitter-test-suite.c] exit get_value 1\n");
}

int usage(int ret) {
    fprintf(stderr, "[tests/run-emitter-test-suite.c] enter usage 1\n");
    fprintf(stderr, "Usage: run-emitter-test-suite [--directive (1.1|1.2)] [--flow (on|off|keep)] [<input-file>]\n");
    return ret;
    fprintf(stderr, "[tests/run-emitter-test-suite.c] exit usage 1\n");
}
// Total cost: 0.114603
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 290)]
// Total instrumented cost: 0.114603, input tokens: 5236, output tokens: 5285, cache read tokens: 0, cache write tokens: 5232

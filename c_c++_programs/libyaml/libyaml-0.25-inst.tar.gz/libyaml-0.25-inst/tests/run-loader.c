#include <yaml.h>

#include <stdlib.h>
#include <stdio.h>

#ifdef NDEBUG
#undef NDEBUG
#endif
#include <assert.h>

int
main(int argc, char *argv[])
{
    fprintf(stderr, "[tests/run-loader.c] enter main 1\n");
    int number;

    if (argc < 2) {
        fprintf(stderr, "[tests/run-loader.c] enter main 2\n");
        printf("Usage: %s file1.yaml ...\n", argv[0]);
        return 0;
        fprintf(stderr, "[tests/run-loader.c] exit main 2\n");
    }
    fprintf(stderr, "[tests/run-loader.c] exit main 1\n");

    for (number = 1; number < argc; number ++)
    {
        fprintf(stderr, "[tests/run-loader.c] enter main 3\n");
        FILE *file;
        yaml_parser_t parser;
        yaml_document_t document;
        int done = 0;
        int count = 0;
        int error = 0;

        printf("[%d] Loading '%s': ", number, argv[number]);
        fflush(stdout);

        file = fopen(argv[number], "rb");
        assert(file);

        assert(yaml_parser_initialize(&parser));

        yaml_parser_set_input_file(&parser, file);
        fprintf(stderr, "[tests/run-loader.c] exit main 3\n");

        while (!done)
        {
            fprintf(stderr, "[tests/run-loader.c] enter main 4\n");
            if (!yaml_parser_load(&parser, &document)) {
                fprintf(stderr, "[tests/run-loader.c] enter main 5\n");
                error = 1;
                break;
                fprintf(stderr, "[tests/run-loader.c] exit main 5\n");
            }

            done = (!yaml_document_get_root_node(&document));

            yaml_document_delete(&document);

            if (!done) {
                fprintf(stderr, "[tests/run-loader.c] enter main 6\n");
                count ++;
                fprintf(stderr, "[tests/run-loader.c] exit main 6\n");
            }
            fprintf(stderr, "[tests/run-loader.c] exit main 4\n");
        }

        fprintf(stderr, "[tests/run-loader.c] enter main 7\n");
        yaml_parser_delete(&parser);

        assert(!fclose(file));

        printf("%s (%d documents)\n", (error ? "FAILURE" : "SUCCESS"), count);
        fprintf(stderr, "[tests/run-loader.c] exit main 7\n");
    }

    fprintf(stderr, "[tests/run-loader.c] enter main 8\n");
    return 0;
    fprintf(stderr, "[tests/run-loader.c] exit main 8\n");
}
// Total cost: 0.013129
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 63)]
// Total instrumented cost: 0.013129, input tokens: 2717, output tokens: 634, cache read tokens: 2280, cache write tokens: 433

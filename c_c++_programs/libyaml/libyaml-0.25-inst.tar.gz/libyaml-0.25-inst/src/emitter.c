
#include "yaml_private.h"
#include <stdio.h>

/*
 * Flush the buffer if needed.
 */

#define FLUSH(emitter)                                                          \
    ((emitter->buffer.pointer+5 < emitter->buffer.end)                          \
     || yaml_emitter_flush(emitter))

/*
 * Put a character to the output buffer.
 */

#define PUT(emitter,value)                                                      \
    (FLUSH(emitter)                                                             \
     && (*(emitter->buffer.pointer++) = (yaml_char_t)(value),                   \
         emitter->column++,                                             	\
         1))

/*
 * Put a line break to the output buffer.
 */

#define PUT_BREAK(emitter)                                                      \
    (FLUSH(emitter)                                                             \
     && ((emitter->line_break == YAML_CR_BREAK ?                                \
             (*(emitter->buffer.pointer++) = (yaml_char_t) '\r') :              \
          emitter->line_break == YAML_LN_BREAK ?                                \
             (*(emitter->buffer.pointer++) = (yaml_char_t) '\n') :              \
          emitter->line_break == YAML_CRLN_BREAK ?                              \
             (*(emitter->buffer.pointer++) = (yaml_char_t) '\r',                \
              *(emitter->buffer.pointer++) = (yaml_char_t) '\n') : 0),          \
         emitter->column = 0,                                                   \
         emitter->line ++,                                                      \
         1))

/*
 * Copy a character from a string into buffer.
 */

#define WRITE(emitter,string)                                                   \
    (FLUSH(emitter)                                                             \
     && (COPY(emitter->buffer,string),                                          \
         emitter->column ++,                                                    \
         1))

/*
 * Copy a line break character from a string into buffer.
 */

#define WRITE_BREAK(emitter,string)                                             \
    (FLUSH(emitter)                                                             \
     && (CHECK(string,'\n') ?                                                   \
         (PUT_BREAK(emitter),                                                   \
          string.pointer ++,                                                    \
          1) :                                                                  \
         (COPY(emitter->buffer,string),                                         \
          emitter->column = 0,                                                  \
          emitter->line ++,                                                     \
          1)))

/*
 * API functions.
 */

YAML_DECLARE(int)
yaml_emitter_emit(yaml_emitter_t *emitter, yaml_event_t *event);

/*
 * Utility functions.
 */

static int
yaml_emitter_set_emitter_error(yaml_emitter_t *emitter, const char *problem);

static int
yaml_emitter_need_more_events(yaml_emitter_t *emitter);

static int
yaml_emitter_append_tag_directive(yaml_emitter_t *emitter,
        yaml_tag_directive_t value, int allow_duplicates);

static int
yaml_emitter_increase_indent(yaml_emitter_t *emitter,
        int flow, int indentless);

/*
 * State functions.
 */

static int
yaml_emitter_state_machine(yaml_emitter_t *emitter, yaml_event_t *event);

static int
yaml_emitter_emit_stream_start(yaml_emitter_t *emitter,
        yaml_event_t *event);

static int
yaml_emitter_emit_document_start(yaml_emitter_t *emitter,
        yaml_event_t *event, int first);

static int
yaml_emitter_emit_document_content(yaml_emitter_t *emitter,
        yaml_event_t *event);

static int
yaml_emitter_emit_document_end(yaml_emitter_t *emitter,
        yaml_event_t *event);

static int
yaml_emitter_emit_flow_sequence_item(yaml_emitter_t *emitter,
        yaml_event_t *event, int first);

static int
yaml_emitter_emit_flow_mapping_key(yaml_emitter_t *emitter,
        yaml_event_t *event, int first);

static int
yaml_emitter_emit_flow_mapping_value(yaml_emitter_t *emitter,
        yaml_event_t *event, int simple);

static int
yaml_emitter_emit_block_sequence_item(yaml_emitter_t *emitter,
        yaml_event_t *event, int first);

static int
yaml_emitter_emit_block_mapping_key(yaml_emitter_t *emitter,
        yaml_event_t *event, int first);

static int
yaml_emitter_emit_block_mapping_value(yaml_emitter_t *emitter,
        yaml_event_t *event, int simple);

static int
yaml_emitter_emit_node(yaml_emitter_t *emitter, yaml_event_t *event,
        int root, int sequence, int mapping, int simple_key);

static int
yaml_emitter_emit_alias(yaml_emitter_t *emitter, yaml_event_t *event);

static int
yaml_emitter_emit_scalar(yaml_emitter_t *emitter, yaml_event_t *event);

static int
yaml_emitter_emit_sequence_start(yaml_emitter_t *emitter, yaml_event_t *event);

static int
yaml_emitter_emit_mapping_start(yaml_emitter_t *emitter, yaml_event_t *event);

/*
 * Checkers.
 */

static int
yaml_emitter_check_empty_document(yaml_emitter_t *emitter);

static int
yaml_emitter_check_empty_sequence(yaml_emitter_t *emitter);

static int
yaml_emitter_check_empty_mapping(yaml_emitter_t *emitter);

static int
yaml_emitter_check_simple_key(yaml_emitter_t *emitter);

static int
yaml_emitter_select_scalar_style(yaml_emitter_t *emitter, yaml_event_t *event);

/*
 * Processors.
 */

static int
yaml_emitter_process_anchor(yaml_emitter_t *emitter);

static int
yaml_emitter_process_tag(yaml_emitter_t *emitter);

static int
yaml_emitter_process_scalar(yaml_emitter_t *emitter);

/*
 * Analyzers.
 */

static int
yaml_emitter_analyze_version_directive(yaml_emitter_t *emitter,
        yaml_version_directive_t version_directive);

static int
yaml_emitter_analyze_tag_directive(yaml_emitter_t *emitter,
        yaml_tag_directive_t tag_directive);

static int
yaml_emitter_analyze_anchor(yaml_emitter_t *emitter,
        yaml_char_t *anchor, int alias);

static int
yaml_emitter_analyze_tag(yaml_emitter_t *emitter,
        yaml_char_t *tag);

static int
yaml_emitter_analyze_scalar(yaml_emitter_t *emitter,
        yaml_char_t *value, size_t length);

static int
yaml_emitter_analyze_event(yaml_emitter_t *emitter,
        yaml_event_t *event);

/*
 * Writers.
 */

static int
yaml_emitter_write_bom(yaml_emitter_t *emitter);

static int
yaml_emitter_write_indent(yaml_emitter_t *emitter);

static int
yaml_emitter_write_indicator(yaml_emitter_t *emitter,
        const char *indicator, int need_whitespace,
        int is_whitespace, int is_indention);

static int
yaml_emitter_write_anchor(yaml_emitter_t *emitter,
        yaml_char_t *value, size_t length);

static int
yaml_emitter_write_tag_handle(yaml_emitter_t *emitter,
        yaml_char_t *value, size_t length);

static int
yaml_emitter_write_tag_content(yaml_emitter_t *emitter,
        yaml_char_t *value, size_t length, int need_whitespace);

static int
yaml_emitter_write_plain_scalar(yaml_emitter_t *emitter,
        yaml_char_t *value, size_t length, int allow_breaks);

static int
yaml_emitter_write_single_quoted_scalar(yaml_emitter_t *emitter,
        yaml_char_t *value, size_t length, int allow_breaks);

static int
yaml_emitter_write_double_quoted_scalar(yaml_emitter_t *emitter,
        yaml_char_t *value, size_t length, int allow_breaks);

static int
yaml_emitter_write_block_scalar_hints(yaml_emitter_t *emitter,
        yaml_string_t string);

static int
yaml_emitter_write_literal_scalar(yaml_emitter_t *emitter,
        yaml_char_t *value, size_t length);

static int
yaml_emitter_write_folded_scalar(yaml_emitter_t *emitter,
        yaml_char_t *value, size_t length);

/*
 * Set an emitter error and return 0.
 */

static int
yaml_emitter_set_emitter_error(yaml_emitter_t *emitter, const char *problem)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_set_emitter_error 1\n");
    emitter->error = YAML_EMITTER_ERROR;
    emitter->problem = problem;

    return 0;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_set_emitter_error 1\n");
}

/*
 * Emit an event.
 */

YAML_DECLARE(int)
yaml_emitter_emit(yaml_emitter_t *emitter, yaml_event_t *event)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit 1\n");
    if (!ENQUEUE(emitter, emitter->events, *event)) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit 2\n");
        yaml_event_delete(event);
        return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit 2\n");
    }
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit 1\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit 3\n");
    while (!yaml_emitter_need_more_events(emitter)) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit 4\n");
        if (!yaml_emitter_analyze_event(emitter, emitter->events.head))
            return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit 4\n");
        
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit 5\n");
        if (!yaml_emitter_state_machine(emitter, emitter->events.head))
            return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit 5\n");
        
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit 6\n");
        yaml_event_delete(&DEQUEUE(emitter, emitter->events));
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit 6\n");
    }
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit 3\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit 7\n");
    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit 7\n");
}

/*
 * Check if we need to accumulate more events before emitting.
 *
 * We accumulate extra
 *  - 1 event for DOCUMENT-START
 *  - 2 events for SEQUENCE-START
 *  - 3 events for MAPPING-START
 */

static int
yaml_emitter_need_more_events(yaml_emitter_t *emitter)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_need_more_events 1\n");
    int level = 0;
    int accumulate = 0;
    yaml_event_t *event;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_need_more_events 1\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_need_more_events 2\n");
    if (QUEUE_EMPTY(emitter, emitter->events))
        return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_need_more_events 2\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_need_more_events 3\n");
    switch (emitter->events.head->type) {
        case YAML_DOCUMENT_START_EVENT:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_need_more_events 4\n");
            accumulate = 1;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_need_more_events 4\n");
            break;
        case YAML_SEQUENCE_START_EVENT:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_need_more_events 5\n");
            accumulate = 2;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_need_more_events 5\n");
            break;
        case YAML_MAPPING_START_EVENT:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_need_more_events 6\n");
            accumulate = 3;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_need_more_events 6\n");
            break;
        default:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_need_more_events 7\n");
            return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_need_more_events 7\n");
    }
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_need_more_events 3\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_need_more_events 8\n");
    if (emitter->events.tail - emitter->events.head > accumulate)
        return 0;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_need_more_events 8\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_need_more_events 9\n");
    for (event = emitter->events.head; event != emitter->events.tail; event ++) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_need_more_events 10\n");
        switch (event->type) {
            case YAML_STREAM_START_EVENT:
            case YAML_DOCUMENT_START_EVENT:
            case YAML_SEQUENCE_START_EVENT:
            case YAML_MAPPING_START_EVENT:
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_need_more_events 11\n");
                level += 1;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_need_more_events 11\n");
                break;
            case YAML_STREAM_END_EVENT:
            case YAML_DOCUMENT_END_EVENT:
            case YAML_SEQUENCE_END_EVENT:
            case YAML_MAPPING_END_EVENT:
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_need_more_events 12\n");
                level -= 1;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_need_more_events 12\n");
                break;
            default:
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_need_more_events 13\n");
                break;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_need_more_events 13\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_need_more_events 10\n");
        
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_need_more_events 14\n");
        if (!level)
            return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_need_more_events 14\n");
    }
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_need_more_events 9\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_need_more_events 15\n");
    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_need_more_events 15\n");
}

/*
 * Append a directive to the directives stack.
 */

static int
yaml_emitter_append_tag_directive(yaml_emitter_t *emitter,
        yaml_tag_directive_t value, int allow_duplicates)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_append_tag_directive 1\n");
    yaml_tag_directive_t *tag_directive;
    yaml_tag_directive_t copy = { NULL, NULL };
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_append_tag_directive 1\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_append_tag_directive 2\n");
    for (tag_directive = emitter->tag_directives.start;
            tag_directive != emitter->tag_directives.top; tag_directive ++) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_append_tag_directive 3\n");
        if (strcmp((char *)value.handle, (char *)tag_directive->handle) == 0) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_append_tag_directive 4\n");
            if (allow_duplicates)
                return 1;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_append_tag_directive 4\n");
            
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_append_tag_directive 5\n");
            return yaml_emitter_set_emitter_error(emitter,
                    "duplicate %TAG directive");
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_append_tag_directive 5\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_append_tag_directive 3\n");
    }
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_append_tag_directive 2\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_append_tag_directive 6\n");
    copy.handle = yaml_strdup(value.handle);
    copy.prefix = yaml_strdup(value.prefix);
    if (!copy.handle || !copy.prefix) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_append_tag_directive 7\n");
        emitter->error = YAML_MEMORY_ERROR;
        goto error;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_append_tag_directive 7\n");
    }
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_append_tag_directive 6\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_append_tag_directive 8\n");
    if (!PUSH(emitter, emitter->tag_directives, copy))
        goto error;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_append_tag_directive 8\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_append_tag_directive 9\n");
    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_append_tag_directive 9\n");

error:
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_append_tag_directive 10\n");
    yaml_free(copy.handle);
    yaml_free(copy.prefix);
    return 0;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_append_tag_directive 10\n");
}

/*
 * Increase the indentation level.
 */

static int
yaml_emitter_increase_indent(yaml_emitter_t *emitter,
        int flow, int indentless)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_increase_indent 1\n");
    if (!PUSH(emitter, emitter->indents, emitter->indent))
        return 0;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_increase_indent 1\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_increase_indent 2\n");
    if (emitter->indent < 0) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_increase_indent 3\n");
        emitter->indent = flow ? emitter->best_indent : 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_increase_indent 3\n");
    }
    else if (!indentless) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_increase_indent 4\n");
        emitter->indent += emitter->best_indent;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_increase_indent 4\n");
    }
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_increase_indent 2\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_increase_indent 5\n");
    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_increase_indent 5\n");
}

/*
 * State dispatcher.
 */

static int
yaml_emitter_state_machine(yaml_emitter_t *emitter, yaml_event_t *event)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_state_machine 1\n");
    switch (emitter->state)
    {
        case YAML_EMIT_STREAM_START_STATE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_state_machine 2\n");
            return yaml_emitter_emit_stream_start(emitter, event);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_state_machine 2\n");

        case YAML_EMIT_FIRST_DOCUMENT_START_STATE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_state_machine 3\n");
            return yaml_emitter_emit_document_start(emitter, event, 1);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_state_machine 3\n");

        case YAML_EMIT_DOCUMENT_START_STATE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_state_machine 4\n");
            return yaml_emitter_emit_document_start(emitter, event, 0);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_state_machine 4\n");

        case YAML_EMIT_DOCUMENT_CONTENT_STATE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_state_machine 5\n");
            return yaml_emitter_emit_document_content(emitter, event);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_state_machine 5\n");

        case YAML_EMIT_DOCUMENT_END_STATE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_state_machine 6\n");
            return yaml_emitter_emit_document_end(emitter, event);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_state_machine 6\n");

        case YAML_EMIT_FLOW_SEQUENCE_FIRST_ITEM_STATE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_state_machine 7\n");
            return yaml_emitter_emit_flow_sequence_item(emitter, event, 1);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_state_machine 7\n");

        case YAML_EMIT_FLOW_SEQUENCE_ITEM_STATE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_state_machine 8\n");
            return yaml_emitter_emit_flow_sequence_item(emitter, event, 0);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_state_machine 8\n");

        case YAML_EMIT_FLOW_MAPPING_FIRST_KEY_STATE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_state_machine 9\n");
            return yaml_emitter_emit_flow_mapping_key(emitter, event, 1);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_state_machine 9\n");

        case YAML_EMIT_FLOW_MAPPING_KEY_STATE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_state_machine 10\n");
            return yaml_emitter_emit_flow_mapping_key(emitter, event, 0);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_state_machine 10\n");

        case YAML_EMIT_FLOW_MAPPING_SIMPLE_VALUE_STATE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_state_machine 11\n");
            return yaml_emitter_emit_flow_mapping_value(emitter, event, 1);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_state_machine 11\n");

        case YAML_EMIT_FLOW_MAPPING_VALUE_STATE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_state_machine 12\n");
            return yaml_emitter_emit_flow_mapping_value(emitter, event, 0);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_state_machine 12\n");

        case YAML_EMIT_BLOCK_SEQUENCE_FIRST_ITEM_STATE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_state_machine 13\n");
            return yaml_emitter_emit_block_sequence_item(emitter, event, 1);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_state_machine 13\n");

        case YAML_EMIT_BLOCK_SEQUENCE_ITEM_STATE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_state_machine 14\n");
            return yaml_emitter_emit_block_sequence_item(emitter, event, 0);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_state_machine 14\n");

        case YAML_EMIT_BLOCK_MAPPING_FIRST_KEY_STATE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_state_machine 15\n");
            return yaml_emitter_emit_block_mapping_key(emitter, event, 1);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_state_machine 15\n");

        case YAML_EMIT_BLOCK_MAPPING_KEY_STATE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_state_machine 16\n");
            return yaml_emitter_emit_block_mapping_key(emitter, event, 0);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_state_machine 16\n");

        case YAML_EMIT_BLOCK_MAPPING_SIMPLE_VALUE_STATE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_state_machine 17\n");
            return yaml_emitter_emit_block_mapping_value(emitter, event, 1);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_state_machine 17\n");

        case YAML_EMIT_BLOCK_MAPPING_VALUE_STATE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_state_machine 18\n");
            return yaml_emitter_emit_block_mapping_value(emitter, event, 0);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_state_machine 18\n");

        case YAML_EMIT_END_STATE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_state_machine 19\n");
            return yaml_emitter_set_emitter_error(emitter,
                    "expected nothing after STREAM-END");
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_state_machine 19\n");

        default:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_state_machine 20\n");
            assert(1);      /* Invalid state. */
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_state_machine 20\n");
    }
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_state_machine 1\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_state_machine 21\n");
    return 0;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_state_machine 21\n");
}

/*
 * Expect STREAM-START.
 */

static int
yaml_emitter_emit_stream_start(yaml_emitter_t *emitter,
        yaml_event_t *event)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_stream_start 1\n");
    emitter->open_ended = 0;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_stream_start 1\n");
    
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_stream_start 2\n");
    if (event->type == YAML_STREAM_START_EVENT)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_stream_start 3\n");
        if (!emitter->encoding) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_stream_start 4\n");
            emitter->encoding = event->data.stream_start.encoding;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_stream_start 4\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_stream_start 3\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_stream_start 5\n");
        if (!emitter->encoding) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_stream_start 6\n");
            emitter->encoding = YAML_UTF8_ENCODING;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_stream_start 6\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_stream_start 5\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_stream_start 7\n");
        if (emitter->best_indent < 2 || emitter->best_indent > 9) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_stream_start 8\n");
            emitter->best_indent  = 2;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_stream_start 8\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_stream_start 7\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_stream_start 9\n");
        if (emitter->best_width >= 0
                && emitter->best_width <= emitter->best_indent*2) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_stream_start 10\n");
            emitter->best_width = 80;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_stream_start 10\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_stream_start 9\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_stream_start 11\n");
        if (emitter->best_width < 0) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_stream_start 12\n");
            emitter->best_width = INT_MAX;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_stream_start 12\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_stream_start 11\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_stream_start 13\n");
        if (!emitter->line_break) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_stream_start 14\n");
            emitter->line_break = YAML_LN_BREAK;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_stream_start 14\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_stream_start 13\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_stream_start 15\n");
        emitter->indent = -1;

        emitter->line = 0;
        emitter->column = 0;
        emitter->whitespace = 1;
        emitter->indention = 1;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_stream_start 15\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_stream_start 16\n");
        if (emitter->encoding != YAML_UTF8_ENCODING) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_stream_start 17\n");
            if (!yaml_emitter_write_bom(emitter))
                return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_stream_start 17\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_stream_start 16\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_stream_start 18\n");
        emitter->state = YAML_EMIT_FIRST_DOCUMENT_START_STATE;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_stream_start 18\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_stream_start 19\n");
        return 1;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_stream_start 19\n");
    }
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_stream_start 2\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_stream_start 20\n");
    return yaml_emitter_set_emitter_error(emitter,
            "expected STREAM-START");
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_stream_start 20\n");
}

/*
 * Expect DOCUMENT-START or STREAM-END.
 */

static int
yaml_emitter_emit_document_start(yaml_emitter_t *emitter,
        yaml_event_t *event, int first)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 1\n");
    if (event->type == YAML_DOCUMENT_START_EVENT)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 2\n");
        yaml_tag_directive_t default_tag_directives[] = {
            {(yaml_char_t *)"!", (yaml_char_t *)"!"},
            {(yaml_char_t *)"!!", (yaml_char_t *)"tag:yaml.org,2002:"},
            {NULL, NULL}
        };
        yaml_tag_directive_t *tag_directive;
        int implicit;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 2\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 3\n");
        if (event->data.document_start.version_directive) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 4\n");
            if (!yaml_emitter_analyze_version_directive(emitter,
                        *event->data.document_start.version_directive))
                return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 4\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 3\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 5\n");
        for (tag_directive = event->data.document_start.tag_directives.start;
                tag_directive != event->data.document_start.tag_directives.end;
                tag_directive ++) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 6\n");
            if (!yaml_emitter_analyze_tag_directive(emitter, *tag_directive))
                return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 6\n");
            
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 7\n");
            if (!yaml_emitter_append_tag_directive(emitter, *tag_directive, 0))
                return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 7\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 5\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 8\n");
        for (tag_directive = default_tag_directives;
                tag_directive->handle; tag_directive ++) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 9\n");
            if (!yaml_emitter_append_tag_directive(emitter, *tag_directive, 1))
                return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 9\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 8\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 10\n");
        implicit = event->data.document_start.implicit;
        if (!first || emitter->canonical) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 11\n");
            implicit = 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 11\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 10\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 12\n");
        if ((event->data.document_start.version_directive ||
                    (event->data.document_start.tag_directives.start
                     != event->data.document_start.tag_directives.end)) &&
                emitter->open_ended)
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 13\n");
            if (!yaml_emitter_write_indicator(emitter, "...", 1, 0, 0))
                return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 13\n");
            
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 14\n");
            if (!yaml_emitter_write_indent(emitter))
                return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 14\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 12\n");
        
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 15\n");
        emitter->open_ended = 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 15\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 16\n");
        if (event->data.document_start.version_directive) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 17\n");
            implicit = 0;
            if (!yaml_emitter_write_indicator(emitter, "%YAML", 1, 0, 0))
                return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 17\n");
            
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 18\n");
            if (event->data.document_start.version_directive->minor == 1) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 19\n");
                if (!yaml_emitter_write_indicator(emitter, "1.1", 1, 0, 0))
                    return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 19\n");
            }
            else {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 20\n");
                if (!yaml_emitter_write_indicator(emitter, "1.2", 1, 0, 0))
                    return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 20\n");
            }
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 18\n");
            
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 21\n");
            if (!yaml_emitter_write_indent(emitter))
                return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 21\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 16\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 22\n");
        if (event->data.document_start.tag_directives.start
                != event->data.document_start.tag_directives.end) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 23\n");
            implicit = 0;
            for (tag_directive = event->data.document_start.tag_directives.start;
                    tag_directive != event->data.document_start.tag_directives.end;
                    tag_directive ++) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 24\n");
                if (!yaml_emitter_write_indicator(emitter, "%TAG", 1, 0, 0))
                    return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 24\n");
                
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 25\n");
                if (!yaml_emitter_write_tag_handle(emitter, tag_directive->handle,
                            strlen((char *)tag_directive->handle)))
                    return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 25\n");
                
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 26\n");
                if (!yaml_emitter_write_tag_content(emitter, tag_directive->prefix,
                            strlen((char *)tag_directive->prefix), 1))
                    return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 26\n");
                
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 27\n");
                if (!yaml_emitter_write_indent(emitter))
                    return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 27\n");
            }
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 23\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 22\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 28\n");
        if (yaml_emitter_check_empty_document(emitter)) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 29\n");
            implicit = 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 29\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 28\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 30\n");
        if (!implicit) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 31\n");
            if (!yaml_emitter_write_indent(emitter))
                return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 31\n");
            
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 32\n");
            if (!yaml_emitter_write_indicator(emitter, "---", 1, 0, 0))
                return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 32\n");
            
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 33\n");
            if (emitter->canonical) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 34\n");
                if (!yaml_emitter_write_indent(emitter))
                    return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 34\n");
            }
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 33\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 30\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 35\n");
        emitter->state = YAML_EMIT_DOCUMENT_CONTENT_STATE;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 35\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 36\n");
        emitter->open_ended = 0;
        return 1;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 36\n");
    }
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 1\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 37\n");
    if (event->type == YAML_STREAM_END_EVENT)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 38\n");
        /**
         * This can happen if a block scalar with trailing empty lines
         * is at the end of the stream
         */
        if (emitter->open_ended == 2)
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 39\n");
            if (!yaml_emitter_write_indicator(emitter, "...", 1, 0, 0))
                return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 39\n");
            
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 40\n");
            emitter->open_ended = 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 40\n");
            
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 41\n");
            if (!yaml_emitter_write_indent(emitter))
                return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 41\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 38\n");
        
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 42\n");
        if (!yaml_emitter_flush(emitter))
            return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 42\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 43\n");
        emitter->state = YAML_EMIT_END_STATE;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 43\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 44\n");
        return 1;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 44\n");
    }
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 37\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_start 45\n");
    return yaml_emitter_set_emitter_error(emitter,
            "expected DOCUMENT-START or STREAM-END");
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_start 45\n");
}

/*
 * Expect the root node.
 */

static int
yaml_emitter_emit_document_content(yaml_emitter_t *emitter,
        yaml_event_t *event)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_content 1\n");
    if (!PUSH(emitter, emitter->states, YAML_EMIT_DOCUMENT_END_STATE))
        return 0;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_content 1\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_content 2\n");
    return yaml_emitter_emit_node(emitter, event, 1, 0, 0, 0);
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_content 2\n");
}

/*
 * Expect DOCUMENT-END.
 */

static int
yaml_emitter_emit_document_end(yaml_emitter_t *emitter,
        yaml_event_t *event)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_end 1\n");
    if (event->type == YAML_DOCUMENT_END_EVENT)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_end 2\n");
        if (!yaml_emitter_write_indent(emitter))
            return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_end 2\n");
        
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_end 3\n");
        if (!event->data.document_end.implicit) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_end 4\n");
            if (!yaml_emitter_write_indicator(emitter, "...", 1, 0, 0))
                return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_end 4\n");
            
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_end 5\n");
            emitter->open_ended = 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_end 5\n");
            
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_end 6\n");
            if (!yaml_emitter_write_indent(emitter))
                return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_end 6\n");
        }
        else if (!emitter->open_ended) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_end 7\n");
            emitter->open_ended = 1;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_end 7\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_end 3\n");
        
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_end 8\n");
        if (!yaml_emitter_flush(emitter))
            return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_end 8\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_end 9\n");
        emitter->state = YAML_EMIT_DOCUMENT_START_STATE;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_end 9\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_end 10\n");
        while (!STACK_EMPTY(emitter, emitter->tag_directives)) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_end 11\n");
            yaml_tag_directive_t tag_directive = POP(emitter,
                    emitter->tag_directives);
            yaml_free(tag_directive.handle);
            yaml_free(tag_directive.prefix);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_end 11\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_end 10\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_end 12\n");
        return 1;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_end 12\n");
    }
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_end 1\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_document_end 13\n");
    return yaml_emitter_set_emitter_error(emitter,
            "expected DOCUMENT-END");
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_document_end 13\n");
}

/*
 *
 * Expect a flow item node.
 */

static int
yaml_emitter_emit_flow_sequence_item(yaml_emitter_t *emitter,
        yaml_event_t *event, int first)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_sequence_item 1\n");
    if (first)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_sequence_item 2\n");
        if (!yaml_emitter_write_indicator(emitter, "[", 1, 1, 0))
            return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_sequence_item 2\n");
        
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_sequence_item 3\n");
        if (!yaml_emitter_increase_indent(emitter, 1, 0))
            return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_sequence_item 3\n");
        
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_sequence_item 4\n");
        emitter->flow_level ++;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_sequence_item 4\n");
    }
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_sequence_item 1\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_sequence_item 5\n");
    if (event->type == YAML_SEQUENCE_END_EVENT)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_sequence_item 6\n");
        emitter->flow_level --;
        emitter->indent = POP(emitter, emitter->indents);
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_sequence_item 6\n");
        
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_sequence_item 7\n");
        if (emitter->canonical && !first) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_sequence_item 8\n");
            if (!yaml_emitter_write_indicator(emitter, ",", 0, 0, 0))
                return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_sequence_item 8\n");
            
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_sequence_item 9\n");
            if (!yaml_emitter_write_indent(emitter))
                return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_sequence_item 9\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_sequence_item 7\n");
        
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_sequence_item 10\n");
        if (!yaml_emitter_write_indicator(emitter, "]", 0, 0, 0))
            return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_sequence_item 10\n");
        
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_sequence_item 11\n");
        emitter->state = POP(emitter, emitter->states);
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_sequence_item 11\n");

        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_sequence_item 12\n");
        return 1;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_sequence_item 12\n");
    }
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_sequence_item 5\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_sequence_item 13\n");
    if (!first) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_sequence_item 14\n");
        if (!yaml_emitter_write_indicator(emitter, ",", 0, 0, 0))
            return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_sequence_item 14\n");
    }
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_sequence_item 13\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_sequence_item 15\n");
    if (emitter->canonical || emitter->column > emitter->best_width) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_sequence_item 16\n");
        if (!yaml_emitter_write_indent(emitter))
            return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_sequence_item 16\n");
    }
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_sequence_item 15\n");
    
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_sequence_item 17\n");
    if (!PUSH(emitter, emitter->states, YAML_EMIT_FLOW_SEQUENCE_ITEM_STATE))
        return 0;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_sequence_item 17\n");

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_sequence_item 18\n");
    return yaml_emitter_emit_node(emitter, event, 0, 1, 0, 0);
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_sequence_item 18\n");
}

/*
 * Expect a flow key node.
 */
static int
yaml_emitter_emit_flow_mapping_key(yaml_emitter_t *emitter,
        yaml_event_t *event, int first)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_mapping_key 1\n");
    if (first)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_mapping_key 2\n");
        if (!yaml_emitter_write_indicator(emitter, "{", 1, 1, 0))
            return 0;
        if (!yaml_emitter_increase_indent(emitter, 1, 0))
            return 0;
        emitter->flow_level ++;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_mapping_key 2\n");
    }

    if (event->type == YAML_MAPPING_END_EVENT)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_mapping_key 3\n");
        emitter->flow_level --;
        emitter->indent = POP(emitter, emitter->indents);
        if (emitter->canonical && !first) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_mapping_key 4\n");
            if (!yaml_emitter_write_indicator(emitter, ",", 0, 0, 0))
                return 0;
            if (!yaml_emitter_write_indent(emitter))
                return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_mapping_key 4\n");
        }
        if (!yaml_emitter_write_indicator(emitter, "}", 0, 0, 0))
            return 0;
        emitter->state = POP(emitter, emitter->states);

        return 1;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_mapping_key 3\n");
    }

    if (!first) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_mapping_key 5\n");
        if (!yaml_emitter_write_indicator(emitter, ",", 0, 0, 0))
            return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_mapping_key 5\n");
    }
    if (emitter->canonical || emitter->column > emitter->best_width) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_mapping_key 6\n");
        if (!yaml_emitter_write_indent(emitter))
            return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_mapping_key 6\n");
    }

    if (!emitter->canonical && yaml_emitter_check_simple_key(emitter))
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_mapping_key 7\n");
        if (!PUSH(emitter, emitter->states,
                    YAML_EMIT_FLOW_MAPPING_SIMPLE_VALUE_STATE))
            return 0;

        return yaml_emitter_emit_node(emitter, event, 0, 0, 1, 1);
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_mapping_key 7\n");
    }
    else
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_mapping_key 8\n");
        if (!yaml_emitter_write_indicator(emitter, "?", 1, 0, 0))
            return 0;
        if (!PUSH(emitter, emitter->states,
                    YAML_EMIT_FLOW_MAPPING_VALUE_STATE))
            return 0;

        return yaml_emitter_emit_node(emitter, event, 0, 0, 1, 0);
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_mapping_key 8\n");
    }
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_mapping_key 1\n");
}

/*
 * Expect a flow value node.
 */

static int
yaml_emitter_emit_flow_mapping_value(yaml_emitter_t *emitter,
        yaml_event_t *event, int simple)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_mapping_value 1\n");
    if (simple) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_mapping_value 2\n");
        if (!yaml_emitter_write_indicator(emitter, ":", 0, 0, 0))
            return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_mapping_value 2\n");
    }
    else {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_mapping_value 3\n");
        if (emitter->canonical || emitter->column > emitter->best_width) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_flow_mapping_value 4\n");
            if (!yaml_emitter_write_indent(emitter))
                return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_mapping_value 4\n");
        }
        if (!yaml_emitter_write_indicator(emitter, ":", 1, 0, 0))
            return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_mapping_value 3\n");
    }
    if (!PUSH(emitter, emitter->states, YAML_EMIT_FLOW_MAPPING_KEY_STATE))
        return 0;
    return yaml_emitter_emit_node(emitter, event, 0, 0, 1, 0);
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_flow_mapping_value 1\n");
}

/*
 * Expect a block item node.
 */

static int
yaml_emitter_emit_block_sequence_item(yaml_emitter_t *emitter,
        yaml_event_t *event, int first)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_block_sequence_item 1\n");
    if (first)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_block_sequence_item 2\n");
        if (!yaml_emitter_increase_indent(emitter, 0,
                    (emitter->mapping_context && !emitter->indention)))
            return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_block_sequence_item 2\n");
    }

    if (event->type == YAML_SEQUENCE_END_EVENT)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_block_sequence_item 3\n");
        emitter->indent = POP(emitter, emitter->indents);
        emitter->state = POP(emitter, emitter->states);

        return 1;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_block_sequence_item 3\n");
    }

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_block_sequence_item 4\n");
    if (!yaml_emitter_write_indent(emitter))
        return 0;
    if (!yaml_emitter_write_indicator(emitter, "-", 1, 0, 1))
        return 0;
    if (!PUSH(emitter, emitter->states,
                YAML_EMIT_BLOCK_SEQUENCE_ITEM_STATE))
        return 0;

    return yaml_emitter_emit_node(emitter, event, 0, 1, 0, 0);
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_block_sequence_item 4\n");
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_block_sequence_item 1\n");
}

/*
 * Expect a block key node.
 */

static int
yaml_emitter_emit_block_mapping_key(yaml_emitter_t *emitter,
        yaml_event_t *event, int first)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_block_mapping_key 1\n");
    if (first)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_block_mapping_key 2\n");
        if (!yaml_emitter_increase_indent(emitter, 0, 0))
            return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_block_mapping_key 2\n");
    }

    if (event->type == YAML_MAPPING_END_EVENT)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_block_mapping_key 3\n");
        emitter->indent = POP(emitter, emitter->indents);
        emitter->state = POP(emitter, emitter->states);

        return 1;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_block_mapping_key 3\n");
    }

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_block_mapping_key 4\n");
    if (!yaml_emitter_write_indent(emitter))
        return 0;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_block_mapping_key 4\n");

    if (yaml_emitter_check_simple_key(emitter))
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_block_mapping_key 5\n");
        if (!PUSH(emitter, emitter->states,
                    YAML_EMIT_BLOCK_MAPPING_SIMPLE_VALUE_STATE))
            return 0;

        return yaml_emitter_emit_node(emitter, event, 0, 0, 1, 1);
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_block_mapping_key 5\n");
    }
    else
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_block_mapping_key 6\n");
        if (!yaml_emitter_write_indicator(emitter, "?", 1, 0, 1))
            return 0;
        if (!PUSH(emitter, emitter->states,
                    YAML_EMIT_BLOCK_MAPPING_VALUE_STATE))
            return 0;

        return yaml_emitter_emit_node(emitter, event, 0, 0, 1, 0);
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_block_mapping_key 6\n");
    }
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_block_mapping_key 1\n");
}

/*
 * Expect a block value node.
 */

static int
yaml_emitter_emit_block_mapping_value(yaml_emitter_t *emitter,
        yaml_event_t *event, int simple)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_block_mapping_value 1\n");
    if (simple) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_block_mapping_value 2\n");
        if (!yaml_emitter_write_indicator(emitter, ":", 0, 0, 0))
            return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_block_mapping_value 2\n");
    }
    else {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_block_mapping_value 3\n");
        if (!yaml_emitter_write_indent(emitter))
            return 0;
        if (!yaml_emitter_write_indicator(emitter, ":", 1, 0, 1))
            return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_block_mapping_value 3\n");
    }
    if (!PUSH(emitter, emitter->states,
                YAML_EMIT_BLOCK_MAPPING_KEY_STATE))
        return 0;

    return yaml_emitter_emit_node(emitter, event, 0, 0, 1, 0);
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_block_mapping_value 1\n");
}

/*
 * Expect a node.
 */

static int
yaml_emitter_emit_node(yaml_emitter_t *emitter, yaml_event_t *event,
        int root, int sequence, int mapping, int simple_key)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_node 1\n");
    emitter->root_context = root;
    emitter->sequence_context = sequence;
    emitter->mapping_context = mapping;
    emitter->simple_key_context = simple_key;

    switch (event->type)
    {
        case YAML_ALIAS_EVENT:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_node 2\n");
            return yaml_emitter_emit_alias(emitter, event);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_node 2\n");

        case YAML_SCALAR_EVENT:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_node 3\n");
            return yaml_emitter_emit_scalar(emitter, event);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_node 3\n");

        case YAML_SEQUENCE_START_EVENT:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_node 4\n");
            return yaml_emitter_emit_sequence_start(emitter, event);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_node 4\n");

        case YAML_MAPPING_START_EVENT:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_node 5\n");
            return yaml_emitter_emit_mapping_start(emitter, event);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_node 5\n");

        default:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_node 6\n");
            return yaml_emitter_set_emitter_error(emitter,
                    "expected SCALAR, SEQUENCE-START, MAPPING-START, or ALIAS");
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_node 6\n");
    }

    return 0;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_node 1\n");
}

/*
 * Expect ALIAS.
 */

static int
yaml_emitter_emit_alias(yaml_emitter_t *emitter, SHIM(yaml_event_t *event))
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_alias 1\n");
    if (!yaml_emitter_process_anchor(emitter))
        return 0;
    if (emitter->simple_key_context)
        if (!PUT(emitter, ' ')) return 0;
    emitter->state = POP(emitter, emitter->states);

    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_alias 1\n");
}

/*
 * Expect SCALAR.
 */

static int
yaml_emitter_emit_scalar(yaml_emitter_t *emitter, yaml_event_t *event)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_scalar 1\n");
    if (!yaml_emitter_select_scalar_style(emitter, event))
        return 0;
    if (!yaml_emitter_process_anchor(emitter))
        return 0;
    if (!yaml_emitter_process_tag(emitter))
        return 0;
    if (!yaml_emitter_increase_indent(emitter, 1, 0))
        return 0;
    if (!yaml_emitter_process_scalar(emitter))
        return 0;
    emitter->indent = POP(emitter, emitter->indents);
    emitter->state = POP(emitter, emitter->states);

    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_scalar 1\n");
}

/*
 * Expect SEQUENCE-START.
 */

static int
yaml_emitter_emit_sequence_start(yaml_emitter_t *emitter, yaml_event_t *event)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_sequence_start 1\n");
    if (!yaml_emitter_process_anchor(emitter))
        return 0;
    if (!yaml_emitter_process_tag(emitter))
        return 0;

    if (emitter->flow_level || emitter->canonical
            || event->data.sequence_start.style == YAML_FLOW_SEQUENCE_STYLE
            || yaml_emitter_check_empty_sequence(emitter)) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_sequence_start 2\n");
        emitter->state = YAML_EMIT_FLOW_SEQUENCE_FIRST_ITEM_STATE;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_sequence_start 2\n");
    }
    else {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_sequence_start 3\n");
        emitter->state = YAML_EMIT_BLOCK_SEQUENCE_FIRST_ITEM_STATE;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_sequence_start 3\n");
    }

    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_sequence_start 1\n");
}

/*
 * Expect MAPPING-START.
 */

static int
yaml_emitter_emit_mapping_start(yaml_emitter_t *emitter, yaml_event_t *event)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_mapping_start 1\n");
    if (!yaml_emitter_process_anchor(emitter))
        return 0;
    if (!yaml_emitter_process_tag(emitter))
        return 0;

    if (emitter->flow_level || emitter->canonical
            || event->data.mapping_start.style == YAML_FLOW_MAPPING_STYLE
            || yaml_emitter_check_empty_mapping(emitter)) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_mapping_start 2\n");
        emitter->state = YAML_EMIT_FLOW_MAPPING_FIRST_KEY_STATE;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_mapping_start 2\n");
    }
    else {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_emit_mapping_start 3\n");
        emitter->state = YAML_EMIT_BLOCK_MAPPING_FIRST_KEY_STATE;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_mapping_start 3\n");
    }

    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_emit_mapping_start 1\n");
}

/*
 * Check if the document content is an empty scalar.
 */

static int
yaml_emitter_check_empty_document(SHIM(yaml_emitter_t *emitter))
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_check_empty_document 1\n");
    return 0;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_check_empty_document 1\n");
}

/*
 * Check if the next events represent an empty sequence.
 */

static int
yaml_emitter_check_empty_sequence(yaml_emitter_t *emitter)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_check_empty_sequence 1\n");
    if (emitter->events.tail - emitter->events.head < 2)
        return 0;

    return (emitter->events.head[0].type == YAML_SEQUENCE_START_EVENT
            && emitter->events.head[1].type == YAML_SEQUENCE_END_EVENT);
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_check_empty_sequence 1\n");
}

/*
 * Check if the next events represent an empty mapping.
 */

static int
yaml_emitter_check_empty_mapping(yaml_emitter_t *emitter)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_check_empty_mapping 1\n");
    if (emitter->events.tail - emitter->events.head < 2)
        return 0;

    return (emitter->events.head[0].type == YAML_MAPPING_START_EVENT
            && emitter->events.head[1].type == YAML_MAPPING_END_EVENT);
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_check_empty_mapping 1\n");
}

/*
 * Check if the next node can be expressed as a simple key.
 */

static int
yaml_emitter_check_simple_key(yaml_emitter_t *emitter)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_check_simple_key 1\n");
    yaml_event_t *event = emitter->events.head;
    size_t length = 0;

    switch (event->type)
    {
        case YAML_ALIAS_EVENT:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_check_simple_key 2\n");
            length += emitter->anchor_data.anchor_length;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_check_simple_key 2\n");
            break;

        case YAML_SCALAR_EVENT:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_check_simple_key 3\n");
            if (emitter->scalar_data.multiline)
                return 0;
            length += emitter->anchor_data.anchor_length
                + emitter->tag_data.handle_length
                + emitter->tag_data.suffix_length
                + emitter->scalar_data.length;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_check_simple_key 3\n");
            break;

        case YAML_SEQUENCE_START_EVENT:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_check_simple_key 4\n");
            if (!yaml_emitter_check_empty_sequence(emitter))
                return 0;
            length += emitter->anchor_data.anchor_length
                + emitter->tag_data.handle_length
                + emitter->tag_data.suffix_length;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_check_simple_key 4\n");
            break;

        case YAML_MAPPING_START_EVENT:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_check_simple_key 5\n");
            if (!yaml_emitter_check_empty_mapping(emitter))
                return 0;
            length += emitter->anchor_data.anchor_length
                + emitter->tag_data.handle_length
                + emitter->tag_data.suffix_length;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_check_simple_key 5\n");
            break;

        default:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_check_simple_key 6\n");
            return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_check_simple_key 6\n");
    }

    if (length > 128)
        return 0;

    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_check_simple_key 1\n");
}

/*
 * Determine an acceptable scalar style.
 */

static int
yaml_emitter_select_scalar_style(yaml_emitter_t *emitter, yaml_event_t *event)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_select_scalar_style 1\n");
    yaml_scalar_style_t style = event->data.scalar.style;
    int no_tag = (!emitter->tag_data.handle && !emitter->tag_data.suffix);

    if (no_tag && !event->data.scalar.plain_implicit
            && !event->data.scalar.quoted_implicit) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_select_scalar_style 2\n");
        return yaml_emitter_set_emitter_error(emitter,
                "neither tag nor implicit flags are specified");
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_select_scalar_style 2\n");
    }

    if (style == YAML_ANY_SCALAR_STYLE)
        style = YAML_PLAIN_SCALAR_STYLE;

    if (emitter->canonical)
        style = YAML_DOUBLE_QUOTED_SCALAR_STYLE;

    if (emitter->simple_key_context && emitter->scalar_data.multiline)
        style = YAML_DOUBLE_QUOTED_SCALAR_STYLE;

    if (style == YAML_PLAIN_SCALAR_STYLE)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_select_scalar_style 3\n");
        if ((emitter->flow_level && !emitter->scalar_data.flow_plain_allowed)
                || (!emitter->flow_level && !emitter->scalar_data.block_plain_allowed))
            style = YAML_SINGLE_QUOTED_SCALAR_STYLE;
        if (!emitter->scalar_data.length
                && (emitter->flow_level || emitter->simple_key_context))
            style = YAML_SINGLE_QUOTED_SCALAR_STYLE;
        if (no_tag && !event->data.scalar.plain_implicit)
            style = YAML_SINGLE_QUOTED_SCALAR_STYLE;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_select_scalar_style 3\n");
    }

    if (style == YAML_SINGLE_QUOTED_SCALAR_STYLE)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_select_scalar_style 4\n");
        if (!emitter->scalar_data.single_quoted_allowed)
            style = YAML_DOUBLE_QUOTED_SCALAR_STYLE;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_select_scalar_style 4\n");
    }

    if (style == YAML_LITERAL_SCALAR_STYLE || style == YAML_FOLDED_SCALAR_STYLE)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_select_scalar_style 5\n");
        if (!emitter->scalar_data.block_allowed
                || emitter->flow_level || emitter->simple_key_context)
            style = YAML_DOUBLE_QUOTED_SCALAR_STYLE;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_select_scalar_style 5\n");
    }

    if (no_tag && !event->data.scalar.quoted_implicit
            && style != YAML_PLAIN_SCALAR_STYLE)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_select_scalar_style 6\n");
        emitter->tag_data.handle = (yaml_char_t *)"!";
        emitter->tag_data.handle_length = 1;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_select_scalar_style 6\n");
    }

    emitter->scalar_data.style = style;

    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_select_scalar_style 1\n");
}

/*
 * Write an anchor.
 */

static int
yaml_emitter_process_anchor(yaml_emitter_t *emitter)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_process_anchor 1\n");
    if (!emitter->anchor_data.anchor)
        return 1;

    if (!yaml_emitter_write_indicator(emitter,
                (emitter->anchor_data.alias ? "*" : "&"), 1, 0, 0))
        return 0;

    return yaml_emitter_write_anchor(emitter,
            emitter->anchor_data.anchor, emitter->anchor_data.anchor_length);
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_process_anchor 1\n");
}

/*
 * Write a tag.
 */

static int
yaml_emitter_process_tag(yaml_emitter_t *emitter)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_process_tag 1\n");
    if (!emitter->tag_data.handle && !emitter->tag_data.suffix)
        return 1;

    if (emitter->tag_data.handle)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_process_tag 2\n");
        if (!yaml_emitter_write_tag_handle(emitter, emitter->tag_data.handle,
                    emitter->tag_data.handle_length))
            return 0;
        if (emitter->tag_data.suffix) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_process_tag 3\n");
            if (!yaml_emitter_write_tag_content(emitter, emitter->tag_data.suffix,
                        emitter->tag_data.suffix_length, 0))
                return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_process_tag 3\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_process_tag 2\n");
    }
    else
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_process_tag 4\n");
        if (!yaml_emitter_write_indicator(emitter, "!<", 1, 0, 0))
            return 0;
        if (!yaml_emitter_write_tag_content(emitter, emitter->tag_data.suffix,
                    emitter->tag_data.suffix_length, 0))
            return 0;
        if (!yaml_emitter_write_indicator(emitter, ">", 0, 0, 0))
            return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_process_tag 4\n");
    }

    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_process_tag 1\n");
}

/*
 * Write a scalar.
 */

static int
yaml_emitter_process_scalar(yaml_emitter_t *emitter)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_process_scalar 1\n");
    switch (emitter->scalar_data.style)
    {
        case YAML_PLAIN_SCALAR_STYLE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_process_scalar 2\n");
            return yaml_emitter_write_plain_scalar(emitter,
                    emitter->scalar_data.value, emitter->scalar_data.length,
                    !emitter->simple_key_context);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_process_scalar 2\n");

        case YAML_SINGLE_QUOTED_SCALAR_STYLE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_process_scalar 3\n");
            return yaml_emitter_write_single_quoted_scalar(emitter,
                    emitter->scalar_data.value, emitter->scalar_data.length,
                    !emitter->simple_key_context);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_process_scalar 3\n");

        case YAML_DOUBLE_QUOTED_SCALAR_STYLE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_process_scalar 4\n");
            return yaml_emitter_write_double_quoted_scalar(emitter,
                    emitter->scalar_data.value, emitter->scalar_data.length,
                    !emitter->simple_key_context);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_process_scalar 4\n");

        case YAML_LITERAL_SCALAR_STYLE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_process_scalar 5\n");
            return yaml_emitter_write_literal_scalar(emitter,
                    emitter->scalar_data.value, emitter->scalar_data.length);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_process_scalar 5\n");

        case YAML_FOLDED_SCALAR_STYLE:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_process_scalar 6\n");
            return yaml_emitter_write_folded_scalar(emitter,
                    emitter->scalar_data.value, emitter->scalar_data.length);
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_process_scalar 6\n");

        default:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_process_scalar 7\n");
            assert(1);      /* Impossible. */
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_process_scalar 7\n");
    }

    return 0;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_process_scalar 1\n");
}

/*
 * Check if a %YAML directive is valid.
 */

static int
yaml_emitter_analyze_version_directive(yaml_emitter_t *emitter,
        yaml_version_directive_t version_directive)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_version_directive 1\n");
    if (version_directive.major != 1 || (
        version_directive.minor != 1
        && version_directive.minor != 2
        )) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_version_directive 2\n");
        return yaml_emitter_set_emitter_error(emitter,
                "incompatible %YAML directive");
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_version_directive 2\n");
    }

    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_version_directive 1\n");
}

/*
 * Check if a %TAG directive is valid.
 */

static int
yaml_emitter_analyze_tag_directive(yaml_emitter_t *emitter,
        yaml_tag_directive_t tag_directive)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_tag_directive 1\n");
    yaml_string_t handle;
    yaml_string_t prefix;
    size_t handle_length;
    size_t prefix_length;

    handle_length = strlen((char *)tag_directive.handle);
    prefix_length = strlen((char *)tag_directive.prefix);
    STRING_ASSIGN(handle, tag_directive.handle, handle_length);
    STRING_ASSIGN(prefix, tag_directive.prefix, prefix_length);

    if (handle.start == handle.end) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_tag_directive 2\n");
        return yaml_emitter_set_emitter_error(emitter,
                "tag handle must not be empty");
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_tag_directive 2\n");
    }

    if (handle.start[0] != '!') {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_tag_directive 3\n");
        return yaml_emitter_set_emitter_error(emitter,
                "tag handle must start with '!'");
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_tag_directive 3\n");
    }

    if (handle.end[-1] != '!') {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_tag_directive 4\n");
        return yaml_emitter_set_emitter_error(emitter,
                "tag handle must end with '!'");
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_tag_directive 4\n");
    }

    handle.pointer ++;

    while (handle.pointer < handle.end-1) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_tag_directive 5\n");
        if (!IS_ALPHA(handle)) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_tag_directive 6\n");
            return yaml_emitter_set_emitter_error(emitter,
                    "tag handle must contain alphanumerical characters only");
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_tag_directive 6\n");
        }
        MOVE(handle);
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_tag_directive 5\n");
    }

    if (prefix.start == prefix.end) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_tag_directive 7\n");
        return yaml_emitter_set_emitter_error(emitter,
                "tag prefix must not be empty");
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_tag_directive 7\n");
    }

    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_tag_directive 1\n");
}

/*
 * Check if an anchor is valid.
 */

static int
yaml_emitter_analyze_anchor(yaml_emitter_t *emitter,
        yaml_char_t *anchor, int alias)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_anchor 1\n");
    size_t anchor_length;
    yaml_string_t string;

    anchor_length = strlen((char *)anchor);
    STRING_ASSIGN(string, anchor, anchor_length);

    if (string.start == string.end) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_anchor 2\n");
        return yaml_emitter_set_emitter_error(emitter, alias ?
                "alias value must not be empty" :
                "anchor value must not be empty");
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_anchor 2\n");
    }

    while (string.pointer != string.end) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_anchor 3\n");
        if (!IS_ALPHA(string)) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_anchor 4\n");
            return yaml_emitter_set_emitter_error(emitter, alias ?
                    "alias value must contain alphanumerical characters only" :
                    "anchor value must contain alphanumerical characters only");
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_anchor 4\n");
        }
        MOVE(string);
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_anchor 3\n");
    }

    emitter->anchor_data.anchor = string.start;
    emitter->anchor_data.anchor_length = string.end - string.start;
    emitter->anchor_data.alias = alias;

    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_anchor 1\n");
}

/*
 * Check if a tag is valid.
 */

static int
yaml_emitter_analyze_tag(yaml_emitter_t *emitter,
        yaml_char_t *tag)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_tag 1\n");
    size_t tag_length;
    yaml_string_t string;
    yaml_tag_directive_t *tag_directive;

    tag_length = strlen((char *)tag);
    STRING_ASSIGN(string, tag, tag_length);

    if (string.start == string.end) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_tag 2\n");
        return yaml_emitter_set_emitter_error(emitter,
                "tag value must not be empty");
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_tag 2\n");
    }

    for (tag_directive = emitter->tag_directives.start;
            tag_directive != emitter->tag_directives.top; tag_directive ++) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_tag 3\n");
        size_t prefix_length = strlen((char *)tag_directive->prefix);
        if (prefix_length < (size_t)(string.end - string.start)
                && strncmp((char *)tag_directive->prefix, (char *)string.start,
                    prefix_length) == 0)
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_tag 4\n");
            emitter->tag_data.handle = tag_directive->handle;
            emitter->tag_data.handle_length =
                strlen((char *)tag_directive->handle);
            emitter->tag_data.suffix = string.start + prefix_length;
            emitter->tag_data.suffix_length =
                (string.end - string.start) - prefix_length;
            return 1;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_tag 4\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_tag 3\n");
    }

    emitter->tag_data.suffix = string.start;
    emitter->tag_data.suffix_length = string.end - string.start;

    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_tag 1\n");
}

/*
 * Check if a scalar is valid.
 */
static int
yaml_emitter_analyze_scalar(yaml_emitter_t *emitter,
        yaml_char_t *value, size_t length)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 1\n");
    yaml_string_t string;

    int block_indicators = 0;
    int flow_indicators = 0;
    int line_breaks = 0;
    int special_characters = 0;

    int leading_space = 0;
    int leading_break = 0;
    int trailing_space = 0;
    int trailing_break = 0;
    int break_space = 0;
    int space_break = 0;

    int preceded_by_whitespace = 0;
    int followed_by_whitespace = 0;
    int previous_space = 0;
    int previous_break = 0;

    STRING_ASSIGN(string, value, length);

    emitter->scalar_data.value = value;
    emitter->scalar_data.length = length;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 1\n");

    if (string.start == string.end)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 2\n");
        emitter->scalar_data.multiline = 0;
        emitter->scalar_data.flow_plain_allowed = 0;
        emitter->scalar_data.block_plain_allowed = 1;
        emitter->scalar_data.single_quoted_allowed = 1;
        emitter->scalar_data.block_allowed = 0;

        return 1;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 2\n");
    }

    if ((CHECK_AT(string, '-', 0)
                && CHECK_AT(string, '-', 1)
                && CHECK_AT(string, '-', 2))
            || (CHECK_AT(string, '.', 0)
                && CHECK_AT(string, '.', 1)
                && CHECK_AT(string, '.', 2))) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 3\n");
        block_indicators = 1;
        flow_indicators = 1;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 3\n");
    }

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 4\n");
    preceded_by_whitespace = 1;
    followed_by_whitespace = IS_BLANKZ_AT(string, WIDTH(string));
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 4\n");

    while (string.pointer != string.end)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 5\n");
        if (string.start == string.pointer)
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 6\n");
            if (CHECK(string, '#') || CHECK(string, ',')
                    || CHECK(string, '[') || CHECK(string, ']')
                    || CHECK(string, '{') || CHECK(string, '}')
                    || CHECK(string, '&') || CHECK(string, '*')
                    || CHECK(string, '!') || CHECK(string, '|')
                    || CHECK(string, '>') || CHECK(string, '\'')
                    || CHECK(string, '"') || CHECK(string, '%')
                    || CHECK(string, '@') || CHECK(string, '`')) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 7\n");
                flow_indicators = 1;
                block_indicators = 1;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 7\n");
            }

            if (CHECK(string, '?') || CHECK(string, ':')) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 8\n");
                flow_indicators = 1;
                if (followed_by_whitespace) {
                    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 9\n");
                    block_indicators = 1;
                    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 9\n");
                }
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 8\n");
            }

            if (CHECK(string, '-') && followed_by_whitespace) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 10\n");
                flow_indicators = 1;
                block_indicators = 1;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 10\n");
            }
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 6\n");
        }
        else
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 11\n");
            if (CHECK(string, ',') || CHECK(string, '?')
                    || CHECK(string, '[') || CHECK(string, ']')
                    || CHECK(string, '{') || CHECK(string, '}')) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 12\n");
                flow_indicators = 1;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 12\n");
            }

            if (CHECK(string, ':')) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 13\n");
                flow_indicators = 1;
                if (followed_by_whitespace) {
                    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 14\n");
                    block_indicators = 1;
                    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 14\n");
                }
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 13\n");
            }

            if (CHECK(string, '#') && preceded_by_whitespace) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 15\n");
                flow_indicators = 1;
                block_indicators = 1;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 15\n");
            }
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 11\n");
        }

        if (!IS_PRINTABLE(string)
                || (!IS_ASCII(string) && !emitter->unicode)) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 16\n");
            special_characters = 1;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 16\n");
        }

        if (IS_BREAK(string)) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 17\n");
            line_breaks = 1;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 17\n");
        }

        if (IS_SPACE(string))
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 18\n");
            if (string.start == string.pointer) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 19\n");
                leading_space = 1;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 19\n");
            }
            if (string.pointer+WIDTH(string) == string.end) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 20\n");
                trailing_space = 1;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 20\n");
            }
            if (previous_break) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 21\n");
                break_space = 1;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 21\n");
            }
            previous_space = 1;
            previous_break = 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 18\n");
        }
        else if (IS_BREAK(string))
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 22\n");
            if (string.start == string.pointer) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 23\n");
                leading_break = 1;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 23\n");
            }
            if (string.pointer+WIDTH(string) == string.end) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 24\n");
                trailing_break = 1;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 24\n");
            }
            if (previous_space) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 25\n");
                space_break = 1;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 25\n");
            }
            previous_space = 0;
            previous_break = 1;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 22\n");
        }
        else
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 26\n");
            previous_space = 0;
            previous_break = 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 26\n");
        }

        preceded_by_whitespace = IS_BLANKZ(string);
        MOVE(string);
        if (string.pointer != string.end) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 27\n");
            followed_by_whitespace = IS_BLANKZ_AT(string, WIDTH(string));
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 27\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 5\n");
    }

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 28\n");
    emitter->scalar_data.multiline = line_breaks;

    emitter->scalar_data.flow_plain_allowed = 1;
    emitter->scalar_data.block_plain_allowed = 1;
    emitter->scalar_data.single_quoted_allowed = 1;
    emitter->scalar_data.block_allowed = 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 28\n");

    if (leading_space || leading_break || trailing_space || trailing_break) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 29\n");
        emitter->scalar_data.flow_plain_allowed = 0;
        emitter->scalar_data.block_plain_allowed = 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 29\n");
    }

    if (trailing_space) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 30\n");
        emitter->scalar_data.block_allowed = 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 30\n");
    }

    if (break_space) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 31\n");
        emitter->scalar_data.flow_plain_allowed = 0;
        emitter->scalar_data.block_plain_allowed = 0;
        emitter->scalar_data.single_quoted_allowed = 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 31\n");
    }

    if (space_break || special_characters) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 32\n");
        emitter->scalar_data.flow_plain_allowed = 0;
        emitter->scalar_data.block_plain_allowed = 0;
        emitter->scalar_data.single_quoted_allowed = 0;
        emitter->scalar_data.block_allowed = 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 32\n");
    }

    if (line_breaks) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 33\n");
        emitter->scalar_data.flow_plain_allowed = 0;
        emitter->scalar_data.block_plain_allowed = 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 33\n");
    }

    if (flow_indicators) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 34\n");
        emitter->scalar_data.flow_plain_allowed = 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 34\n");
    }

    if (block_indicators) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_scalar 35\n");
        emitter->scalar_data.block_plain_allowed = 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_scalar 35\n");
    }

    return 1;
}

/*
 * Check if the event data is valid.
 */

static int
yaml_emitter_analyze_event(yaml_emitter_t *emitter,
        yaml_event_t *event)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_event 1\n");
    emitter->anchor_data.anchor = NULL;
    emitter->anchor_data.anchor_length = 0;
    emitter->tag_data.handle = NULL;
    emitter->tag_data.handle_length = 0;
    emitter->tag_data.suffix = NULL;
    emitter->tag_data.suffix_length = 0;
    emitter->scalar_data.value = NULL;
    emitter->scalar_data.length = 0;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_event 1\n");

    switch (event->type)
    {
        case YAML_ALIAS_EVENT:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_event 2\n");
            if (!yaml_emitter_analyze_anchor(emitter,
                        event->data.alias.anchor, 1))
                return 0;
            return 1;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_event 2\n");

        case YAML_SCALAR_EVENT:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_event 3\n");
            if (event->data.scalar.anchor) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_event 4\n");
                if (!yaml_emitter_analyze_anchor(emitter,
                            event->data.scalar.anchor, 0))
                    return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_event 4\n");
            }
            if (event->data.scalar.tag && (emitter->canonical ||
                        (!event->data.scalar.plain_implicit
                         && !event->data.scalar.quoted_implicit))) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_event 5\n");
                if (!yaml_emitter_analyze_tag(emitter, event->data.scalar.tag))
                    return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_event 5\n");
            }
            if (!yaml_emitter_analyze_scalar(emitter,
                        event->data.scalar.value, event->data.scalar.length))
                return 0;
            return 1;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_event 3\n");

        case YAML_SEQUENCE_START_EVENT:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_event 6\n");
            if (event->data.sequence_start.anchor) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_event 7\n");
                if (!yaml_emitter_analyze_anchor(emitter,
                            event->data.sequence_start.anchor, 0))
                    return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_event 7\n");
            }
            if (event->data.sequence_start.tag && (emitter->canonical ||
                        !event->data.sequence_start.implicit)) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_event 8\n");
                if (!yaml_emitter_analyze_tag(emitter,
                            event->data.sequence_start.tag))
                    return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_event 8\n");
            }
            return 1;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_event 6\n");

        case YAML_MAPPING_START_EVENT:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_event 9\n");
            if (event->data.mapping_start.anchor) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_event 10\n");
                if (!yaml_emitter_analyze_anchor(emitter,
                            event->data.mapping_start.anchor, 0))
                    return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_event 10\n");
            }
            if (event->data.mapping_start.tag && (emitter->canonical ||
                        !event->data.mapping_start.implicit)) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_event 11\n");
                if (!yaml_emitter_analyze_tag(emitter,
                            event->data.mapping_start.tag))
                    return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_event 11\n");
            }
            return 1;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_event 9\n");

        default:
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_analyze_event 12\n");
            return 1;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_analyze_event 12\n");
    }
}

/*
 * Write the BOM character.
 */

static int
yaml_emitter_write_bom(yaml_emitter_t *emitter)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_bom 1\n");
    if (!FLUSH(emitter)) return 0;

    *(emitter->buffer.pointer++) = (yaml_char_t) '\xEF';
    *(emitter->buffer.pointer++) = (yaml_char_t) '\xBB';
    *(emitter->buffer.pointer++) = (yaml_char_t) '\xBF';

    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_bom 1\n");
}

static int
yaml_emitter_write_indent(yaml_emitter_t *emitter)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_indent 1\n");
    int indent = (emitter->indent >= 0) ? emitter->indent : 0;

    if (!emitter->indention || emitter->column > indent
            || (emitter->column == indent && !emitter->whitespace)) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_indent 2\n");
        if (!PUT_BREAK(emitter)) return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_indent 2\n");
    }

    while (emitter->column < indent) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_indent 3\n");
        if (!PUT(emitter, ' ')) return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_indent 3\n");
    }

    emitter->whitespace = 1;
    emitter->indention = 1;

    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_indent 1\n");
}

static int
yaml_emitter_write_indicator(yaml_emitter_t *emitter,
        const char *indicator, int need_whitespace,
        int is_whitespace, int is_indention)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_indicator 1\n");
    size_t indicator_length;
    yaml_string_t string;

    indicator_length = strlen(indicator);
    STRING_ASSIGN(string, (yaml_char_t *)indicator, indicator_length);

    if (need_whitespace && !emitter->whitespace) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_indicator 2\n");
        if (!PUT(emitter, ' ')) return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_indicator 2\n");
    }

    while (string.pointer != string.end) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_indicator 3\n");
        if (!WRITE(emitter, string)) return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_indicator 3\n");
    }

    emitter->whitespace = is_whitespace;
    emitter->indention = (emitter->indention && is_indention);

    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_indicator 1\n");
}

static int
yaml_emitter_write_anchor(yaml_emitter_t *emitter,
        yaml_char_t *value, size_t length)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_anchor 1\n");
    yaml_string_t string;
    STRING_ASSIGN(string, value, length);

    while (string.pointer != string.end) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_anchor 2\n");
        if (!WRITE(emitter, string)) return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_anchor 2\n");
    }

    emitter->whitespace = 0;
    emitter->indention = 0;

    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_anchor 1\n");
}

static int
yaml_emitter_write_tag_handle(yaml_emitter_t *emitter,
        yaml_char_t *value, size_t length)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_tag_handle 1\n");
    yaml_string_t string;
    STRING_ASSIGN(string, value, length);

    if (!emitter->whitespace) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_tag_handle 2\n");
        if (!PUT(emitter, ' ')) return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_tag_handle 2\n");
    }

    while (string.pointer != string.end) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_tag_handle 3\n");
        if (!WRITE(emitter, string)) return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_tag_handle 3\n");
    }

    emitter->whitespace = 0;
    emitter->indention = 0;

    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_tag_handle 1\n");
}

static int
yaml_emitter_write_tag_content(yaml_emitter_t *emitter,
        yaml_char_t *value, size_t length,
        int need_whitespace)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_tag_content 1\n");
    yaml_string_t string;
    STRING_ASSIGN(string, value, length);

    if (need_whitespace && !emitter->whitespace) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_tag_content 2\n");
        if (!PUT(emitter, ' ')) return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_tag_content 2\n");
    }

    while (string.pointer != string.end) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_tag_content 3\n");
        if (IS_ALPHA(string)
                || CHECK(string, ';') || CHECK(string, '/')
                || CHECK(string, '?') || CHECK(string, ':')
                || CHECK(string, '@') || CHECK(string, '&')
                || CHECK(string, '=') || CHECK(string, '+')
                || CHECK(string, '$') || CHECK(string, ',')
                || CHECK(string, '_') || CHECK(string, '.')
                || CHECK(string, '~') || CHECK(string, '*')
                || CHECK(string, '\'') || CHECK(string, '(')
                || CHECK(string, ')') || CHECK(string, '[')
                || CHECK(string, ']')) {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_tag_content 4\n");
            if (!WRITE(emitter, string)) return 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_tag_content 4\n");
        }
        else {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_tag_content 5\n");
            int width = WIDTH(string);
            unsigned int value;
            while (width --) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_tag_content 6\n");
                value = *(string.pointer++);
                if (!PUT(emitter, '%')) return 0;
                if (!PUT(emitter, (value >> 4)
                            + ((value >> 4) < 10 ? '0' : 'A' - 10)))
                    return 0;
                if (!PUT(emitter, (value & 0x0F)
                            + ((value & 0x0F) < 10 ? '0' : 'A' - 10)))
                    return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_tag_content 6\n");
            }
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_tag_content 5\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_tag_content 3\n");
    }

    emitter->whitespace = 0;
    emitter->indention = 0;

    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_tag_content 1\n");
}

static int
yaml_emitter_write_plain_scalar(yaml_emitter_t *emitter,
        yaml_char_t *value, size_t length, int allow_breaks)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_plain_scalar 1\n");
    yaml_string_t string;
    int spaces = 0;
    int breaks = 0;

    STRING_ASSIGN(string, value, length);

    /**
     * Avoid trailing spaces for empty values in block mode.
     * In flow mode, we still want the space to prevent ambiguous things
     * like {a:}.
     * Currently, the emitter forbids any plain empty scalar in flow mode
     * (e.g. it outputs {a: ''} instead), so emitter->flow_level will
     * never be true here.
     * But if the emitter is ever changed to allow emitting empty values,
     * the check for flow_level is already here.
     */
    if (!emitter->whitespace && (length || emitter->flow_level)) {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_plain_scalar 2\n");
        if (!PUT(emitter, ' ')) return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_plain_scalar 2\n");
    }

    while (string.pointer != string.end)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_plain_scalar 3\n");
        if (IS_SPACE(string))
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_plain_scalar 4\n");
            if (allow_breaks && !spaces
                    && emitter->column > emitter->best_width
                    && !IS_SPACE_AT(string, 1)) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_plain_scalar 5\n");
                if (!yaml_emitter_write_indent(emitter)) return 0;
                MOVE(string);
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_plain_scalar 5\n");
            }
            else {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_plain_scalar 6\n");
                if (!WRITE(emitter, string)) return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_plain_scalar 6\n");
            }
            spaces = 1;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_plain_scalar 4\n");
        }
        else if (IS_BREAK(string))
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_plain_scalar 7\n");
            if (!breaks && CHECK(string, '\n')) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_plain_scalar 8\n");
                if (!PUT_BREAK(emitter)) return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_plain_scalar 8\n");
            }
            if (!WRITE_BREAK(emitter, string)) return 0;
            emitter->indention = 1;
            breaks = 1;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_plain_scalar 7\n");
        }
        else
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_plain_scalar 9\n");
            if (breaks) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_plain_scalar 10\n");
                if (!yaml_emitter_write_indent(emitter)) return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_plain_scalar 10\n");
            }
            if (!WRITE(emitter, string)) return 0;
            emitter->indention = 0;
            spaces = 0;
            breaks = 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_plain_scalar 9\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_plain_scalar 3\n");
    }

    emitter->whitespace = 0;
    emitter->indention = 0;

    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_plain_scalar 1\n");
}

static int
yaml_emitter_write_single_quoted_scalar(yaml_emitter_t *emitter,
        yaml_char_t *value, size_t length, int allow_breaks)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_single_quoted_scalar 1\n");
    yaml_string_t string;
    int spaces = 0;
    int breaks = 0;

    STRING_ASSIGN(string, value, length);

    if (!yaml_emitter_write_indicator(emitter, "'", 1, 0, 0))
        return 0;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_single_quoted_scalar 1\n");

    while (string.pointer != string.end)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_single_quoted_scalar 2\n");
        if (IS_SPACE(string))
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_single_quoted_scalar 3\n");
            if (allow_breaks && !spaces
                    && emitter->column > emitter->best_width
                    && string.pointer != string.start
                    && string.pointer != string.end - 1
                    && !IS_SPACE_AT(string, 1)) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_single_quoted_scalar 4\n");
                if (!yaml_emitter_write_indent(emitter)) return 0;
                MOVE(string);
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_single_quoted_scalar 4\n");
            }
            else {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_single_quoted_scalar 5\n");
                if (!WRITE(emitter, string)) return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_single_quoted_scalar 5\n");
            }
            spaces = 1;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_single_quoted_scalar 3\n");
        }
        else if (IS_BREAK(string))
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_single_quoted_scalar 6\n");
            if (!breaks && CHECK(string, '\n')) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_single_quoted_scalar 7\n");
                if (!PUT_BREAK(emitter)) return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_single_quoted_scalar 7\n");
            }
            if (!WRITE_BREAK(emitter, string)) return 0;
            emitter->indention = 1;
            breaks = 1;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_single_quoted_scalar 6\n");
        }
        else
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_single_quoted_scalar 8\n");
            if (breaks) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_single_quoted_scalar 9\n");
                if (!yaml_emitter_write_indent(emitter)) return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_single_quoted_scalar 9\n");
            }
            if (CHECK(string, '\'')) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_single_quoted_scalar 10\n");
                if (!PUT(emitter, '\'')) return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_single_quoted_scalar 10\n");
            }
            if (!WRITE(emitter, string)) return 0;
            emitter->indention = 0;
            spaces = 0;
            breaks = 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_single_quoted_scalar 8\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_single_quoted_scalar 2\n");
    }

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_single_quoted_scalar 11\n");
    if (breaks)
        if (!yaml_emitter_write_indent(emitter)) return 0;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_single_quoted_scalar 11\n");

    if (!yaml_emitter_write_indicator(emitter, "'", 0, 0, 0))
        return 0;

    emitter->whitespace = 0;
    emitter->indention = 0;

    return 1;
}

static int
yaml_emitter_write_double_quoted_scalar(yaml_emitter_t *emitter,
        yaml_char_t *value, size_t length, int allow_breaks)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 1\n");
    yaml_string_t string;
    int spaces = 0;

    STRING_ASSIGN(string, value, length);

    if (!yaml_emitter_write_indicator(emitter, "\"", 1, 0, 0))
        return 0;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 1\n");

    while (string.pointer != string.end)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 2\n");
        if (!IS_PRINTABLE(string) || (!emitter->unicode && !IS_ASCII(string))
                || IS_BOM(string) || IS_BREAK(string)
                || CHECK(string, '"') || CHECK(string, '\\'))
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 3\n");
            unsigned char octet;
            unsigned int width;
            unsigned int value;
            int k;

            octet = string.pointer[0];
            width = (octet & 0x80) == 0x00 ? 1 :
                    (octet & 0xE0) == 0xC0 ? 2 :
                    (octet & 0xF0) == 0xE0 ? 3 :
                    (octet & 0xF8) == 0xF0 ? 4 : 0;
            value = (octet & 0x80) == 0x00 ? octet & 0x7F :
                    (octet & 0xE0) == 0xC0 ? octet & 0x1F :
                    (octet & 0xF0) == 0xE0 ? octet & 0x0F :
                    (octet & 0xF8) == 0xF0 ? octet & 0x07 : 0;
            for (k = 1; k < (int)width; k ++) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 4\n");
                octet = string.pointer[k];
                value = (value << 6) + (octet & 0x3F);
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 4\n");
            }
            string.pointer += width;

            if (!PUT(emitter, '\\')) return 0;

            switch (value)
            {
                case 0x00:
                    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 5\n");
                    if (!PUT(emitter, '0')) return 0;
                    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 5\n");
                    break;

                case 0x07:
                    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 6\n");
                    if (!PUT(emitter, 'a')) return 0;
                    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 6\n");
                    break;

                case 0x08:
                    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 7\n");
                    if (!PUT(emitter, 'b')) return 0;
                    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 7\n");
                    break;

                case 0x09:
                    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 8\n");
                    if (!PUT(emitter, 't')) return 0;
                    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 8\n");
                    break;

                case 0x0A:
                    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 9\n");
                    if (!PUT(emitter, 'n')) return 0;
                    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 9\n");
                    break;

                case 0x0B:
                    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 10\n");
                    if (!PUT(emitter, 'v')) return 0;
                    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 10\n");
                    break;

                case 0x0C:
                    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 11\n");
                    if (!PUT(emitter, 'f')) return 0;
                    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 11\n");
                    break;

                case 0x0D:
                    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 12\n");
                    if (!PUT(emitter, 'r')) return 0;
                    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 12\n");
                    break;

                case 0x1B:
                    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 13\n");
                    if (!PUT(emitter, 'e')) return 0;
                    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 13\n");
                    break;

                case 0x22:
                    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 14\n");
                    if (!PUT(emitter, '\"')) return 0;
                    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 14\n");
                    break;

                case 0x5C:
                    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 15\n");
                    if (!PUT(emitter, '\\')) return 0;
                    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 15\n");
                    break;

                case 0x85:
                    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 16\n");
                    if (!PUT(emitter, 'N')) return 0;
                    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 16\n");
                    break;

                case 0xA0:
                    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 17\n");
                    if (!PUT(emitter, '_')) return 0;
                    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 17\n");
                    break;

                case 0x2028:
                    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 18\n");
                    if (!PUT(emitter, 'L')) return 0;
                    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 18\n");
                    break;

                case 0x2029:
                    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 19\n");
                    if (!PUT(emitter, 'P')) return 0;
                    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 19\n");
                    break;

                default:
                    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 20\n");
                    if (value <= 0xFF) {
                        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 21\n");
                        if (!PUT(emitter, 'x')) return 0;
                        width = 2;
                        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 21\n");
                    }
                    else if (value <= 0xFFFF) {
                        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 22\n");
                        if (!PUT(emitter, 'u')) return 0;
                        width = 4;
                        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 22\n");
                    }
                    else {
                        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 23\n");
                        if (!PUT(emitter, 'U')) return 0;
                        width = 8;
                        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 23\n");
                    }
                    for (k = (width-1)*4; k >= 0; k -= 4) {
                        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 24\n");
                        int digit = (value >> k) & 0x0F;
                        if (!PUT(emitter, digit + (digit < 10 ? '0' : 'A'-10)))
                            return 0;
                        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 24\n");
                    }
                    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 20\n");
            }
            spaces = 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 3\n");
        }
        else if (IS_SPACE(string))
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 25\n");
            if (allow_breaks && !spaces
                    && emitter->column > emitter->best_width
                    && string.pointer != string.start
                    && string.pointer != string.end - 1) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 26\n");
                if (!yaml_emitter_write_indent(emitter)) return 0;
                if (IS_SPACE_AT(string, 1)) {
                    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 27\n");
                    if (!PUT(emitter, '\\')) return 0;
                    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 27\n");
                }
                MOVE(string);
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 26\n");
            }
            else {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 28\n");
                if (!WRITE(emitter, string)) return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 28\n");
            }
            spaces = 1;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 25\n");
        }
        else
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_double_quoted_scalar 29\n");
            if (!WRITE(emitter, string)) return 0;
            spaces = 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 29\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_double_quoted_scalar 2\n");
    }

    if (!yaml_emitter_write_indicator(emitter, "\"", 0, 0, 0))
        return 0;

    emitter->whitespace = 0;
    emitter->indention = 0;

    return 1;
}

static int
yaml_emitter_write_block_scalar_hints(yaml_emitter_t *emitter,
        yaml_string_t string)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_block_scalar_hints 1\n");
    char indent_hint[2];
    const char *chomp_hint = NULL;

    if (IS_SPACE(string) || IS_BREAK(string))
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_block_scalar_hints 2\n");
        indent_hint[0] = '0' + (char)emitter->best_indent;
        indent_hint[1] = '\0';
        if (!yaml_emitter_write_indicator(emitter, indent_hint, 0, 0, 0))
            return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_block_scalar_hints 2\n");
    }

    emitter->open_ended = 0;

    string.pointer = string.end;
    if (string.start == string.pointer)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_block_scalar_hints 3\n");
        chomp_hint = "-";
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_block_scalar_hints 3\n");
    }
    else
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_block_scalar_hints 4\n");
        do {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_block_scalar_hints 5\n");
            string.pointer --;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_block_scalar_hints 5\n");
        } while ((*string.pointer & 0xC0) == 0x80);
        if (!IS_BREAK(string))
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_block_scalar_hints 6\n");
            chomp_hint = "-";
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_block_scalar_hints 6\n");
        }
        else if (string.start == string.pointer)
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_block_scalar_hints 7\n");
            chomp_hint = "+";
            emitter->open_ended = 2;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_block_scalar_hints 7\n");
        }
        else
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_block_scalar_hints 8\n");
            do {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_block_scalar_hints 9\n");
                string.pointer --;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_block_scalar_hints 9\n");
            } while ((*string.pointer & 0xC0) == 0x80);
            if (IS_BREAK(string))
            {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_block_scalar_hints 10\n");
                chomp_hint = "+";
                emitter->open_ended = 2;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_block_scalar_hints 10\n");
            }
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_block_scalar_hints 8\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_block_scalar_hints 4\n");
    }

    if (chomp_hint)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_block_scalar_hints 11\n");
        if (!yaml_emitter_write_indicator(emitter, chomp_hint, 0, 0, 0))
            return 0;
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_block_scalar_hints 11\n");
    }

    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_block_scalar_hints 1\n");
}
static int
yaml_emitter_write_literal_scalar(yaml_emitter_t *emitter,
        yaml_char_t *value, size_t length)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_literal_scalar 1\n");
    yaml_string_t string;
    int breaks = 1;

    STRING_ASSIGN(string, value, length);

    if (!yaml_emitter_write_indicator(emitter, "|", 1, 0, 0))
        return 0;
    if (!yaml_emitter_write_block_scalar_hints(emitter, string))
        return 0;
    if (!PUT_BREAK(emitter)) return 0;
    emitter->indention = 1;
    emitter->whitespace = 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_literal_scalar 1\n");

    while (string.pointer != string.end)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_literal_scalar 2\n");
        if (IS_BREAK(string))
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_literal_scalar 3\n");
            if (!WRITE_BREAK(emitter, string)) return 0;
            emitter->indention = 1;
            breaks = 1;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_literal_scalar 3\n");
        }
        else
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_literal_scalar 4\n");
            if (breaks) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_literal_scalar 5\n");
                if (!yaml_emitter_write_indent(emitter)) return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_literal_scalar 5\n");
            }
            if (!WRITE(emitter, string)) return 0;
            emitter->indention = 0;
            breaks = 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_literal_scalar 4\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_literal_scalar 2\n");
    }

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_literal_scalar 6\n");
    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_literal_scalar 6\n");
}

static int
yaml_emitter_write_folded_scalar(yaml_emitter_t *emitter,
        yaml_char_t *value, size_t length)
{
    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_folded_scalar 1\n");
    yaml_string_t string;
    int breaks = 1;
    int leading_spaces = 1;

    STRING_ASSIGN(string, value, length);

    if (!yaml_emitter_write_indicator(emitter, ">", 1, 0, 0))
        return 0;
    if (!yaml_emitter_write_block_scalar_hints(emitter, string))
        return 0;
    if (!PUT_BREAK(emitter)) return 0;
    emitter->indention = 1;
    emitter->whitespace = 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_folded_scalar 1\n");

    while (string.pointer != string.end)
    {
        fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_folded_scalar 2\n");
        if (IS_BREAK(string))
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_folded_scalar 3\n");
            if (!breaks && !leading_spaces && CHECK(string, '\n')) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_folded_scalar 4\n");
                int k = 0;
                while (IS_BREAK_AT(string, k)) {
                    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_folded_scalar 5\n");
                    k += WIDTH_AT(string, k);
                    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_folded_scalar 5\n");
                }
                if (!IS_BLANKZ_AT(string, k)) {
                    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_folded_scalar 6\n");
                    if (!PUT_BREAK(emitter)) return 0;
                    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_folded_scalar 6\n");
                }
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_folded_scalar 4\n");
            }
            if (!WRITE_BREAK(emitter, string)) return 0;
            emitter->indention = 1;
            breaks = 1;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_folded_scalar 3\n");
        }
        else
        {
            fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_folded_scalar 7\n");
            if (breaks) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_folded_scalar 8\n");
                if (!yaml_emitter_write_indent(emitter)) return 0;
                leading_spaces = IS_BLANK(string);
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_folded_scalar 8\n");
            }
            if (!breaks && IS_SPACE(string) && !IS_SPACE_AT(string, 1)
                    && emitter->column > emitter->best_width) {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_folded_scalar 9\n");
                if (!yaml_emitter_write_indent(emitter)) return 0;
                MOVE(string);
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_folded_scalar 9\n");
            }
            else {
                fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_folded_scalar 10\n");
                if (!WRITE(emitter, string)) return 0;
                fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_folded_scalar 10\n");
            }
            emitter->indention = 0;
            breaks = 0;
            fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_folded_scalar 7\n");
        }
        fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_folded_scalar 2\n");
    }

    fprintf(stderr, "[src/emitter.c] enter yaml_emitter_write_folded_scalar 11\n");
    return 1;
    fprintf(stderr, "[src/emitter.c] exit yaml_emitter_write_folded_scalar 11\n");
}
// Total cost: 1.260309
// Total split cost: 0.521743, input tokens: 144451, output tokens: 1924, cache read tokens: 8088, cache write tokens: 21698, split chunks: [(0, 793), (793, 1499), (1499, 2263), (2263, 2358)]
// Total instrumented cost: 0.738566, input tokens: 30712, output tokens: 39272, cache read tokens: 8955, cache write tokens: 21741

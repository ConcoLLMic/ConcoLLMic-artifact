
/*
 * The parser implements the following grammar:
 *
 * stream               ::= STREAM-START implicit_document? explicit_document* STREAM-END
 * implicit_document    ::= block_node DOCUMENT-END*
 * explicit_document    ::= DIRECTIVE* DOCUMENT-START block_node? DOCUMENT-END*
 * block_node_or_indentless_sequence    ::=
 *                          ALIAS
 *                          | properties (block_content | indentless_block_sequence)?
 *                          | block_content
 *                          | indentless_block_sequence
 * block_node           ::= ALIAS
 *                          | properties block_content?
 *                          | block_content
 * flow_node            ::= ALIAS
 *                          | properties flow_content?
 *                          | flow_content
 * properties           ::= TAG ANCHOR? | ANCHOR TAG?
 * block_content        ::= block_collection | flow_collection | SCALAR
 * flow_content         ::= flow_collection | SCALAR
 * block_collection     ::= block_sequence | block_mapping
 * flow_collection      ::= flow_sequence | flow_mapping
 * block_sequence       ::= BLOCK-SEQUENCE-START (BLOCK-ENTRY block_node?)* BLOCK-END
 * indentless_sequence  ::= (BLOCK-ENTRY block_node?)+
 * block_mapping        ::= BLOCK-MAPPING_START
 *                          ((KEY block_node_or_indentless_sequence?)?
 *                          (VALUE block_node_or_indentless_sequence?)?)*
 *                          BLOCK-END
 * flow_sequence        ::= FLOW-SEQUENCE-START
 *                          (flow_sequence_entry FLOW-ENTRY)*
 *                          flow_sequence_entry?
 *                          FLOW-SEQUENCE-END
 * flow_sequence_entry  ::= flow_node | KEY flow_node? (VALUE flow_node?)?
 * flow_mapping         ::= FLOW-MAPPING-START
 *                          (flow_mapping_entry FLOW-ENTRY)*
 *                          flow_mapping_entry?
 *                          FLOW-MAPPING-END
 * flow_mapping_entry   ::= flow_node | KEY flow_node? (VALUE flow_node?)?
 */

#include "yaml_private.h"

/*
 * Peek the next token in the token queue.
 */

#define PEEK_TOKEN(parser)                                                      \
    ((parser->token_available || yaml_parser_fetch_more_tokens(parser)) ?       \
        parser->tokens.head : NULL)

/*
 * Remove the next token from the queue (must be called after PEEK_TOKEN).
 */

#define SKIP_TOKEN(parser)                                                      \
    (parser->token_available = 0,                                               \
     parser->tokens_parsed ++,                                                  \
     parser->stream_end_produced =                                              \
        (parser->tokens.head->type == YAML_STREAM_END_TOKEN),                   \
     parser->tokens.head ++)

/*
 * Public API declarations.
 */

int MAX_NESTING_LEVEL = 1000;

YAML_DECLARE(int)
yaml_parser_parse(yaml_parser_t *parser, yaml_event_t *event);

/*
 * Error handling.
 */

static int
yaml_parser_set_parser_error(yaml_parser_t *parser,
        const char *problem, yaml_mark_t problem_mark);

static int
yaml_parser_set_parser_error_context(yaml_parser_t *parser,
        const char *context, yaml_mark_t context_mark,
        const char *problem, yaml_mark_t problem_mark);

static int
yaml_maximum_level_reached(yaml_parser_t *parser,
        yaml_mark_t context_mark, yaml_mark_t problem_mark);

/*
 * State functions.
 */

static int
yaml_parser_state_machine(yaml_parser_t *parser, yaml_event_t *event);

static int
yaml_parser_parse_stream_start(yaml_parser_t *parser, yaml_event_t *event);

static int
yaml_parser_parse_document_start(yaml_parser_t *parser, yaml_event_t *event,
        int implicit);

static int
yaml_parser_parse_document_content(yaml_parser_t *parser, yaml_event_t *event);

static int
yaml_parser_parse_document_end(yaml_parser_t *parser, yaml_event_t *event);

static int
yaml_parser_parse_node(yaml_parser_t *parser, yaml_event_t *event,
        int block, int indentless_sequence);

static int
yaml_parser_parse_block_sequence_entry(yaml_parser_t *parser,
        yaml_event_t *event, int first);

static int
yaml_parser_parse_indentless_sequence_entry(yaml_parser_t *parser,
        yaml_event_t *event);

static int
yaml_parser_parse_block_mapping_key(yaml_parser_t *parser,
        yaml_event_t *event, int first);

static int
yaml_parser_parse_block_mapping_value(yaml_parser_t *parser,
        yaml_event_t *event);

static int
yaml_parser_parse_flow_sequence_entry(yaml_parser_t *parser,
        yaml_event_t *event, int first);

static int
yaml_parser_parse_flow_sequence_entry_mapping_key(yaml_parser_t *parser,
        yaml_event_t *event);

static int
yaml_parser_parse_flow_sequence_entry_mapping_value(yaml_parser_t *parser,
        yaml_event_t *event);

static int
yaml_parser_parse_flow_sequence_entry_mapping_end(yaml_parser_t *parser,
        yaml_event_t *event);

static int
yaml_parser_parse_flow_mapping_key(yaml_parser_t *parser,
        yaml_event_t *event, int first);

static int
yaml_parser_parse_flow_mapping_value(yaml_parser_t *parser,
        yaml_event_t *event, int empty);

/*
 * Utility functions.
 */

static int
yaml_parser_process_empty_scalar(yaml_parser_t *parser,
        yaml_event_t *event, yaml_mark_t mark);

static int
yaml_parser_process_directives(yaml_parser_t *parser,
        yaml_version_directive_t **version_directive_ref,
        yaml_tag_directive_t **tag_directives_start_ref,
        yaml_tag_directive_t **tag_directives_end_ref);

static int
yaml_parser_append_tag_directive(yaml_parser_t *parser,
        yaml_tag_directive_t value, int allow_duplicates, yaml_mark_t mark);

YAML_DECLARE(void)
yaml_set_max_nest_level(int max)
{
    fprintf(stderr, "[src/parser.c] enter yaml_set_max_nest_level 1\n");
    MAX_NESTING_LEVEL = max;
    fprintf(stderr, "[src/parser.c] exit yaml_set_max_nest_level 1\n");
}

/*
 * Get the next event.
 */

YAML_DECLARE(int)
yaml_parser_parse(yaml_parser_t *parser, yaml_event_t *event)
{
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse 1\n");
    assert(parser);     /* Non-NULL parser object is expected. */
    assert(event);      /* Non-NULL event object is expected. */

    /* Erase the event object. */
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse 1\n");

    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse 2\n");
    memset(event, 0, sizeof(yaml_event_t));
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse 2\n");

    /* No events after the end of the stream or error. */

    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse 3\n");
    if (parser->stream_end_produced || parser->error ||
            parser->state == YAML_PARSE_END_STATE) {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse 4\n");
        return 1;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse 4\n");
    }
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse 3\n");

    /* Generate the next event. */
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse 5\n");
    return yaml_parser_state_machine(parser, event);
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse 5\n");
}

/*
 * Set parser error.
 */

static int
yaml_parser_set_parser_error(yaml_parser_t *parser,
        const char *problem, yaml_mark_t problem_mark)
{
    fprintf(stderr, "[src/parser.c] enter yaml_parser_set_parser_error 1\n");
    parser->error = YAML_PARSER_ERROR;
    parser->problem = problem;
    parser->problem_mark = problem_mark;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_set_parser_error 1\n");

    return 0;
}

static int
yaml_parser_set_parser_error_context(yaml_parser_t *parser,
        const char *context, yaml_mark_t context_mark,
        const char *problem, yaml_mark_t problem_mark)
{
    fprintf(stderr, "[src/parser.c] enter yaml_parser_set_parser_error_context 1\n");
    parser->error = YAML_PARSER_ERROR;
    parser->context = context;
    parser->context_mark = context_mark;
    parser->problem = problem;
    parser->problem_mark = problem_mark;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_set_parser_error_context 1\n");

    return 0;
}

static int
yaml_maximum_level_reached(yaml_parser_t *parser,
        yaml_mark_t context_mark, yaml_mark_t problem_mark)
{
    fprintf(stderr, "[src/parser.c] enter yaml_maximum_level_reached 1\n");
    yaml_parser_set_parser_error_context(parser,
            "while parsing", context_mark, "Maximum nesting level reached, set with yaml_set_max_nest_level())", problem_mark);
    fprintf(stderr, "[src/parser.c] exit yaml_maximum_level_reached 1\n");
    return 0;
}

/*
 * State dispatcher.
 */

static int
yaml_parser_state_machine(yaml_parser_t *parser, yaml_event_t *event)
{
    fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 1\n");
    switch (parser->state)
    {
        case YAML_PARSE_STREAM_START_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 2\n");
            return yaml_parser_parse_stream_start(parser, event);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 2\n");

        case YAML_PARSE_IMPLICIT_DOCUMENT_START_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 3\n");
            return yaml_parser_parse_document_start(parser, event, 1);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 3\n");

        case YAML_PARSE_DOCUMENT_START_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 4\n");
            return yaml_parser_parse_document_start(parser, event, 0);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 4\n");

        case YAML_PARSE_DOCUMENT_CONTENT_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 5\n");
            return yaml_parser_parse_document_content(parser, event);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 5\n");

        case YAML_PARSE_DOCUMENT_END_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 6\n");
            return yaml_parser_parse_document_end(parser, event);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 6\n");

        case YAML_PARSE_BLOCK_NODE_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 7\n");
            return yaml_parser_parse_node(parser, event, 1, 0);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 7\n");

        case YAML_PARSE_BLOCK_NODE_OR_INDENTLESS_SEQUENCE_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 8\n");
            return yaml_parser_parse_node(parser, event, 1, 1);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 8\n");

        case YAML_PARSE_FLOW_NODE_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 9\n");
            return yaml_parser_parse_node(parser, event, 0, 0);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 9\n");

        case YAML_PARSE_BLOCK_SEQUENCE_FIRST_ENTRY_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 10\n");
            return yaml_parser_parse_block_sequence_entry(parser, event, 1);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 10\n");

        case YAML_PARSE_BLOCK_SEQUENCE_ENTRY_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 11\n");
            return yaml_parser_parse_block_sequence_entry(parser, event, 0);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 11\n");

        case YAML_PARSE_INDENTLESS_SEQUENCE_ENTRY_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 12\n");
            return yaml_parser_parse_indentless_sequence_entry(parser, event);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 12\n");

        case YAML_PARSE_BLOCK_MAPPING_FIRST_KEY_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 13\n");
            return yaml_parser_parse_block_mapping_key(parser, event, 1);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 13\n");

        case YAML_PARSE_BLOCK_MAPPING_KEY_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 14\n");
            return yaml_parser_parse_block_mapping_key(parser, event, 0);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 14\n");

        case YAML_PARSE_BLOCK_MAPPING_VALUE_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 15\n");
            return yaml_parser_parse_block_mapping_value(parser, event);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 15\n");

        case YAML_PARSE_FLOW_SEQUENCE_FIRST_ENTRY_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 16\n");
            return yaml_parser_parse_flow_sequence_entry(parser, event, 1);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 16\n");

        case YAML_PARSE_FLOW_SEQUENCE_ENTRY_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 17\n");
            return yaml_parser_parse_flow_sequence_entry(parser, event, 0);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 17\n");

        case YAML_PARSE_FLOW_SEQUENCE_ENTRY_MAPPING_KEY_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 18\n");
            return yaml_parser_parse_flow_sequence_entry_mapping_key(parser, event);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 18\n");

        case YAML_PARSE_FLOW_SEQUENCE_ENTRY_MAPPING_VALUE_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 19\n");
            return yaml_parser_parse_flow_sequence_entry_mapping_value(parser, event);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 19\n");

        case YAML_PARSE_FLOW_SEQUENCE_ENTRY_MAPPING_END_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 20\n");
            return yaml_parser_parse_flow_sequence_entry_mapping_end(parser, event);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 20\n");

        case YAML_PARSE_FLOW_MAPPING_FIRST_KEY_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 21\n");
            return yaml_parser_parse_flow_mapping_key(parser, event, 1);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 21\n");

        case YAML_PARSE_FLOW_MAPPING_KEY_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 22\n");
            return yaml_parser_parse_flow_mapping_key(parser, event, 0);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 22\n");

        case YAML_PARSE_FLOW_MAPPING_VALUE_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 23\n");
            return yaml_parser_parse_flow_mapping_value(parser, event, 0);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 23\n");

        case YAML_PARSE_FLOW_MAPPING_EMPTY_VALUE_STATE:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 24\n");
            return yaml_parser_parse_flow_mapping_value(parser, event, 1);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 24\n");

        default:
            fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 25\n");
            assert(1);      /* Invalid state. */
            fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 25\n");
    }
    fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 1\n");

    fprintf(stderr, "[src/parser.c] enter yaml_parser_state_machine 26\n");
    return 0;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_state_machine 26\n");
}

/*
 * Parse the production:
 * stream   ::= STREAM-START implicit_document? explicit_document* STREAM-END
 *              ************
 */

static int
yaml_parser_parse_stream_start(yaml_parser_t *parser, yaml_event_t *event)
{
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_stream_start 1\n");
    yaml_token_t *token;

    token = PEEK_TOKEN(parser);
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_stream_start 1\n");
    
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_stream_start 2\n");
    if (!token) return 0;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_stream_start 2\n");

    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_stream_start 3\n");
    if (token->type != YAML_STREAM_START_TOKEN) {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_stream_start 4\n");
        return yaml_parser_set_parser_error(parser,
                "did not find expected <stream-start>", token->start_mark);
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_stream_start 4\n");
    }
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_stream_start 3\n");

    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_stream_start 5\n");
    parser->state = YAML_PARSE_IMPLICIT_DOCUMENT_START_STATE;
    STREAM_START_EVENT_INIT(*event, token->data.stream_start.encoding,
            token->start_mark, token->start_mark);
    SKIP_TOKEN(parser);
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_stream_start 5\n");

    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_stream_start 6\n");
    return 1;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_stream_start 6\n");
}

/*
 * Parse the productions:
 * implicit_document    ::= block_node DOCUMENT-END*
 *                          *
 * explicit_document    ::= DIRECTIVE* DOCUMENT-START block_node? DOCUMENT-END*
 *                          *************************
 */

static int
yaml_parser_parse_document_start(yaml_parser_t *parser, yaml_event_t *event,
        int implicit)
{
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_start 1\n");
    yaml_token_t *token;
    yaml_version_directive_t *version_directive = NULL;
    struct {
        yaml_tag_directive_t *start;
        yaml_tag_directive_t *end;
    } tag_directives = { NULL, NULL };

    token = PEEK_TOKEN(parser);
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_start 1\n");
    
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_start 2\n");
    if (!token) return 0;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_start 2\n");

    /* Parse extra document end indicators. */
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_start 3\n");
    if (!implicit)
    {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_start 4\n");
        while (token->type == YAML_DOCUMENT_END_TOKEN) {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_start 5\n");
            SKIP_TOKEN(parser);
            token = PEEK_TOKEN(parser);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_start 5\n");
            
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_start 6\n");
            if (!token) return 0;
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_start 6\n");
        }
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_start 4\n");
    }
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_start 3\n");

    /* Parse an implicit document. */
   if (implicit && token->type != YAML_VERSION_DIRECTIVE_TOKEN &&
            token->type != YAML_TAG_DIRECTIVE_TOKEN &&
            token->type != YAML_DOCUMENT_START_TOKEN &&
            token->type != YAML_STREAM_END_TOKEN)
    {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_start 8\n");
        if (!yaml_parser_process_directives(parser, NULL, NULL, NULL))
            return 0;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_start 8\n");
        
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_start 9\n");
        if (!PUSH(parser, parser->states, YAML_PARSE_DOCUMENT_END_STATE))
            return 0;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_start 9\n");
        
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_start 10\n");
        parser->state = YAML_PARSE_BLOCK_NODE_STATE;
        DOCUMENT_START_EVENT_INIT(*event, NULL, NULL, NULL, 1,
                token->start_mark, token->start_mark);
        return 1;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_start 10\n");
    }

    /* Parse an explicit document. */

    else if (token->type != YAML_STREAM_END_TOKEN)
    {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_start 12\n");
        yaml_mark_t start_mark, end_mark;
        start_mark = token->start_mark;
        if (!yaml_parser_process_directives(parser, &version_directive,
                    &tag_directives.start, &tag_directives.end))
            goto error;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_start 12\n");
        
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_start 13\n");
        token = PEEK_TOKEN(parser);
        if (!token) goto error;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_start 13\n");
        
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_start 14\n");
        if (token->type != YAML_DOCUMENT_START_TOKEN) {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_start 15\n");
            yaml_parser_set_parser_error(parser,
                    "did not find expected <document start>", token->start_mark);
            goto error;
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_start 15\n");
        }
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_start 14\n");
        
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_start 16\n");
        if (!PUSH(parser, parser->states, YAML_PARSE_DOCUMENT_END_STATE))
            goto error;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_start 16\n");
        
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_start 17\n");
        parser->state = YAML_PARSE_DOCUMENT_CONTENT_STATE;
        end_mark = token->end_mark;
        DOCUMENT_START_EVENT_INIT(*event, version_directive,
                tag_directives.start, tag_directives.end, 0,
                start_mark, end_mark);
        SKIP_TOKEN(parser);
        version_directive = NULL;
        tag_directives.start = tag_directives.end = NULL;
        return 1;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_start 17\n");
    }

    /* Parse the stream end. */

    else
    {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_start 19\n");
        parser->state = YAML_PARSE_END_STATE;
        STREAM_END_EVENT_INIT(*event, token->start_mark, token->end_mark);
        SKIP_TOKEN(parser);
        return 1;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_start 19\n");
    }

error:
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_start 20\n");
    yaml_free(version_directive);
    while (tag_directives.start != tag_directives.end) {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_start 21\n");
        yaml_free(tag_directives.end[-1].handle);
        yaml_free(tag_directives.end[-1].prefix);
        tag_directives.end --;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_start 21\n");
    }
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_start 20\n");
    
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_start 22\n");
    yaml_free(tag_directives.start);
    return 0;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_start 22\n");
}

/*
 * Parse the productions:
 * explicit_document    ::= DIRECTIVE* DOCUMENT-START block_node? DOCUMENT-END*
 *                                                    ***********
 */

static int
yaml_parser_parse_document_content(yaml_parser_t *parser, yaml_event_t *event)
{
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_content 1\n");
    yaml_token_t *token;

    token = PEEK_TOKEN(parser);
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_content 1\n");
    
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_content 2\n");
    if (!token) return 0;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_content 2\n");

    if (token->type == YAML_VERSION_DIRECTIVE_TOKEN ||
            token->type == YAML_TAG_DIRECTIVE_TOKEN ||
            token->type == YAML_DOCUMENT_START_TOKEN ||
            token->type == YAML_DOCUMENT_END_TOKEN ||
            token->type == YAML_STREAM_END_TOKEN) {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_content 4\n");
        parser->state = POP(parser, parser->states);
        return yaml_parser_process_empty_scalar(parser, event,
                token->start_mark);
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_content 4\n");
    }
    else {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_content 6\n");
        return yaml_parser_parse_node(parser, event, 1, 0);
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_content 6\n");
    }
}

/*
 * Parse the productions:
 * implicit_document    ::= block_node DOCUMENT-END*
 *                                     *************
 * explicit_document    ::= DIRECTIVE* DOCUMENT-START block_node? DOCUMENT-END*
 *                                                                *************
 */

static int
yaml_parser_parse_document_end(yaml_parser_t *parser, yaml_event_t *event)
{
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_end 1\n");
    yaml_token_t *token;
    yaml_mark_t start_mark, end_mark;
    int implicit = 1;

    token = PEEK_TOKEN(parser);
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_end 1\n");
    
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_end 2\n");
    if (!token) return 0;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_end 2\n");

    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_end 3\n");
    start_mark = end_mark = token->start_mark;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_end 3\n");

    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_end 4\n");
    if (token->type == YAML_DOCUMENT_END_TOKEN) {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_end 5\n");
        end_mark = token->end_mark;
        SKIP_TOKEN(parser);
        implicit = 0;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_end 5\n");
    }
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_end 4\n");

    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_end 6\n");
    while (!STACK_EMPTY(parser, parser->tag_directives)) {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_end 7\n");
        yaml_tag_directive_t tag_directive = POP(parser, parser->tag_directives);
        yaml_free(tag_directive.handle);
        yaml_free(tag_directive.prefix);
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_end 7\n");
    }
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_end 6\n");

    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_end 8\n");
    parser->state = YAML_PARSE_DOCUMENT_START_STATE;
    DOCUMENT_END_EVENT_INIT(*event, implicit, start_mark, end_mark);
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_end 8\n");

    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_document_end 9\n");
    return 1;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_document_end 9\n");
}

/*
 * Parse the productions:
 * block_node_or_indentless_sequence    ::=
 *                          ALIAS
 *                          *****
 *                          | properties (block_content | indentless_block_sequence)?
 *                            **********  *
 *                          | block_content | indentless_block_sequence
 *                            *
 * block_node           ::= ALIAS
 *                          *****
 *                          | properties block_content?
 *                            ********** *
 *                          | block_content
 *                            *
 * flow_node            ::= ALIAS
 *                          *****
 *                          | properties flow_content?
 *                            ********** *
 *                          | flow_content
 *                            *
 * properties           ::= TAG ANCHOR? | ANCHOR TAG?
 *                          *************************
 * block_content        ::= block_collection | flow_collection | SCALAR
 *                                                               ******
 * flow_content         ::= flow_collection | SCALAR
 *                                            ******
 */

static int
yaml_parser_parse_node(yaml_parser_t *parser, yaml_event_t *event,
        int block, int indentless_sequence)
{
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 1\n");
    yaml_token_t *token;
    yaml_char_t *anchor = NULL;
    yaml_char_t *tag_handle = NULL;
    yaml_char_t *tag_suffix = NULL;
    yaml_char_t *tag = NULL;
    yaml_mark_t start_mark, end_mark, tag_mark;
    int implicit;

    token = PEEK_TOKEN(parser);
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 1\n");
    
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 2\n");
    if (!token) return 0;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 2\n");

    if (token->type == YAML_ALIAS_TOKEN)
    {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 4\n");
        parser->state = POP(parser, parser->states);
        ALIAS_EVENT_INIT(*event, token->data.alias.value,
                token->start_mark, token->end_mark);
        SKIP_TOKEN(parser);
        return 1;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 4\n");
    }

    else
    {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 6\n");
        start_mark = end_mark = token->start_mark;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 6\n");

        if (token->type == YAML_ANCHOR_TOKEN)
        {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 8\n");
            anchor = token->data.anchor.value;
            start_mark = token->start_mark;
            end_mark = token->end_mark;
            SKIP_TOKEN(parser);
            token = PEEK_TOKEN(parser);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 8\n");
            
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 9\n");
            if (!token) goto error;
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 9\n");
            
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 10\n");
            if (token->type == YAML_TAG_TOKEN)
            {
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 11\n");
                tag_handle = token->data.tag.handle;
                tag_suffix = token->data.tag.suffix;
                tag_mark = token->start_mark;
                end_mark = token->end_mark;
                SKIP_TOKEN(parser);
                token = PEEK_TOKEN(parser);
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 11\n");
                
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 12\n");
                if (!token) goto error;
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 12\n");
            }
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 10\n");
        }
        else if (token->type == YAML_TAG_TOKEN)
        {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 14\n");
            tag_handle = token->data.tag.handle;
            tag_suffix = token->data.tag.suffix;
            start_mark = tag_mark = token->start_mark;
            end_mark = token->end_mark;
            SKIP_TOKEN(parser);
            token = PEEK_TOKEN(parser);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 14\n");
            
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 15\n");
            if (!token) goto error;
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 15\n");
            
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 16\n");
            if (token->type == YAML_ANCHOR_TOKEN)
            {
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 17\n");
                anchor = token->data.anchor.value;
                end_mark = token->end_mark;
                SKIP_TOKEN(parser);
                token = PEEK_TOKEN(parser);
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 17\n");
                
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 18\n");
                if (!token) goto error;
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 18\n");
            }
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 16\n");
        }

        if (tag_handle) {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 20\n");
            if (!*tag_handle) {
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 21\n");
                tag = tag_suffix;
                yaml_free(tag_handle);
                tag_handle = tag_suffix = NULL;
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 21\n");
            }
            else {
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 23\n");
                yaml_tag_directive_t *tag_directive;
                for (tag_directive = parser->tag_directives.start;
                        tag_directive != parser->tag_directives.top;
                        tag_directive ++) {
                    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 24\n");
                    if (strcmp((char *)tag_directive->handle, (char *)tag_handle) == 0) {
                        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 25\n");
                        size_t prefix_len = strlen((char *)tag_directive->prefix);
                        size_t suffix_len = strlen((char *)tag_suffix);
                        tag = YAML_MALLOC(prefix_len+suffix_len+1);
                        if (!tag) {
                            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 26\n");
                            parser->error = YAML_MEMORY_ERROR;
                            goto error;
                            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 26\n");
                        }
                        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 25\n");
                        
                        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 27\n");
                        memcpy(tag, tag_directive->prefix, prefix_len);
                        memcpy(tag+prefix_len, tag_suffix, suffix_len);
                        tag[prefix_len+suffix_len] = '\0';
                        yaml_free(tag_handle);
                        yaml_free(tag_suffix);
                        tag_handle = tag_suffix = NULL;
                        break;
                        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 27\n");
                    }
                    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 24\n");
                }
                
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 28\n");
                if (!tag) {
                    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 29\n");
                    yaml_parser_set_parser_error_context(parser,
                            "while parsing a node", start_mark,
                            "found undefined tag handle", tag_mark);
                    goto error;
                    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 29\n");
                }
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 28\n");
            }
        }

        implicit = (!tag || !*tag);
        if (indentless_sequence && token->type == YAML_BLOCK_ENTRY_TOKEN) {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 31\n");
            end_mark = token->end_mark;
            parser->state = YAML_PARSE_INDENTLESS_SEQUENCE_ENTRY_STATE;
            SEQUENCE_START_EVENT_INIT(*event, anchor, tag, implicit,
                    YAML_BLOCK_SEQUENCE_STYLE, start_mark, end_mark);
            return 1;
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 31\n");
        }
        else {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 33\n");
            if (token->type == YAML_SCALAR_TOKEN) {
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 34\n");
                int plain_implicit = 0;
                int quoted_implicit = 0;
                end_mark = token->end_mark;
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 34\n");
                if ((token->data.scalar.style == YAML_PLAIN_SCALAR_STYLE && !tag)
                        || (tag && strcmp((char *)tag, "!") == 0)) {
                    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 35\n");
                    plain_implicit = 1;
                    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 35\n");
                }
                
                else if (!tag) {
                    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 37\n");
                    quoted_implicit = 1;
                    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 37\n");
                }
               
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 38\n");
                parser->state = POP(parser, parser->states);
                SCALAR_EVENT_INIT(*event, anchor, tag,
                        token->data.scalar.value, token->data.scalar.length,
                        plain_implicit, quoted_implicit,
                        token->data.scalar.style, start_mark, end_mark);
                SKIP_TOKEN(parser);
                return 1;
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 38\n");
            }
            else if (token->type == YAML_FLOW_SEQUENCE_START_TOKEN) {
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 40\n");
                if (!STACK_LIMIT(parser, parser->indents, MAX_NESTING_LEVEL - parser->flow_level)) {
                    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 41\n");
                    yaml_maximum_level_reached(parser, start_mark, token->start_mark);
                    goto error;
                    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 41\n");
                }
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 40\n");
                
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 42\n");
                end_mark = token->end_mark;
                parser->state = YAML_PARSE_FLOW_SEQUENCE_FIRST_ENTRY_STATE;
                SEQUENCE_START_EVENT_INIT(*event, anchor, tag, implicit,
                        YAML_FLOW_SEQUENCE_STYLE, start_mark, end_mark);
                return 1;
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 42\n");
            }
            else if (token->type == YAML_FLOW_MAPPING_START_TOKEN) {
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 44\n");
                if (!STACK_LIMIT(parser, parser->indents, MAX_NESTING_LEVEL - parser->flow_level)) {
                    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 45\n");
                    yaml_maximum_level_reached(parser, start_mark, token->start_mark);
                    goto error;
                    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 45\n");
                }
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 44\n");
                
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 46\n");
                end_mark = token->end_mark;
                parser->state = YAML_PARSE_FLOW_MAPPING_FIRST_KEY_STATE;
                MAPPING_START_EVENT_INIT(*event, anchor, tag, implicit,
                        YAML_FLOW_MAPPING_STYLE, start_mark, end_mark);
                return 1;
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 46\n");
            }
            else if (block && token->type == YAML_BLOCK_SEQUENCE_START_TOKEN) {
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 48\n");
                if (!STACK_LIMIT(parser, parser->indents, MAX_NESTING_LEVEL - parser->flow_level)) {
                    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 49\n");
                    yaml_maximum_level_reached(parser, start_mark, token->start_mark);
                    goto error;
                    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 49\n");
                }
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 48\n");
                
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 50\n");
                end_mark = token->end_mark;
                parser->state = YAML_PARSE_BLOCK_SEQUENCE_FIRST_ENTRY_STATE;
                SEQUENCE_START_EVENT_INIT(*event, anchor, tag, implicit,
                        YAML_BLOCK_SEQUENCE_STYLE, start_mark, end_mark);
                return 1;
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 50\n");
            }
            else if (block && token->type == YAML_BLOCK_MAPPING_START_TOKEN) {
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 52\n");
                if (!STACK_LIMIT(parser, parser->indents, MAX_NESTING_LEVEL - parser->flow_level)) {
                    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 53\n");
                    yaml_maximum_level_reached(parser, start_mark, token->start_mark);
                    goto error;
                    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 53\n");
                }
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 52\n");
                
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 54\n");
                end_mark = token->end_mark;
                parser->state = YAML_PARSE_BLOCK_MAPPING_FIRST_KEY_STATE;
                MAPPING_START_EVENT_INIT(*event, anchor, tag, implicit,
                        YAML_BLOCK_MAPPING_STYLE, start_mark, end_mark);
                return 1;
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 54\n");
            }
            else if (anchor || tag) {
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 56\n");
                yaml_char_t *value = YAML_MALLOC(1);
                if (!value) {
                    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 57\n");
                    parser->error = YAML_MEMORY_ERROR;
                    goto error;
                    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 57\n");
                }
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 56\n");
                
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 58\n");
                value[0] = '\0';
                parser->state = POP(parser, parser->states);
                SCALAR_EVENT_INIT(*event, anchor, tag, value, 0,
                        implicit, 0, YAML_PLAIN_SCALAR_STYLE,
                        start_mark, end_mark);
                return 1;
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 58\n");
            }
            else {
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 60\n");
                yaml_parser_set_parser_error_context(parser,
                        (block ? "while parsing a block node"
                         : "while parsing a flow node"), start_mark,
                        "did not find expected node content", token->start_mark);
                goto error;
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 60\n");
            }
        }
    }

error:
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 61\n");
    yaml_free(anchor);
    yaml_free(tag_handle);
    yaml_free(tag_suffix);
    yaml_free(tag);
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 61\n");

    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_node 62\n");
    return 0;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_node 62\n");
}

/*
 * Parse the productions:
 * block_sequence ::= BLOCK-SEQUENCE-START (BLOCK-ENTRY block_node?)* BLOCK-END
 *                    ********************  *********** *             *********
 */

static int
yaml_parser_parse_block_sequence_entry(yaml_parser_t *parser,
        yaml_event_t *event, int first)
{
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_block_sequence_entry 1\n");
    yaml_token_t *token;

    if (first) {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_block_sequence_entry 2\n");
        token = PEEK_TOKEN(parser);
        if (!PUSH(parser, parser->marks, token->start_mark))
            return 0;
        SKIP_TOKEN(parser);
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_block_sequence_entry 2\n");
    }

    token = PEEK_TOKEN(parser);
    if (!token) return 0;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_block_sequence_entry 1\n");

    if (token->type == YAML_BLOCK_ENTRY_TOKEN)
    {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_block_sequence_entry 3\n");
        yaml_mark_t mark = token->end_mark;
        SKIP_TOKEN(parser);
        token = PEEK_TOKEN(parser);
        if (!token) return 0;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_block_sequence_entry 3\n");
        if (token->type != YAML_BLOCK_ENTRY_TOKEN &&
                token->type != YAML_BLOCK_END_TOKEN) {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_block_sequence_entry 4\n");
            if (!PUSH(parser, parser->states,
                        YAML_PARSE_BLOCK_SEQUENCE_ENTRY_STATE))
                return 0;
            return yaml_parser_parse_node(parser, event, 1, 0);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_block_sequence_entry 4\n");
        }
        else {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_block_sequence_entry 5\n");
            parser->state = YAML_PARSE_BLOCK_SEQUENCE_ENTRY_STATE;
            return yaml_parser_process_empty_scalar(parser, event, mark);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_block_sequence_entry 5\n");
        }
    }

    else if (token->type == YAML_BLOCK_END_TOKEN)
    {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_block_sequence_entry 6\n");
        parser->state = POP(parser, parser->states);
        (void)POP(parser, parser->marks);
        SEQUENCE_END_EVENT_INIT(*event, token->start_mark, token->end_mark);
        SKIP_TOKEN(parser);
        return 1;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_block_sequence_entry 6\n");
    }

    else
    {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_block_sequence_entry 7\n");
        return yaml_parser_set_parser_error_context(parser,
                "while parsing a block collection", POP(parser, parser->marks),
                "did not find expected '-' indicator", token->start_mark);
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_block_sequence_entry 7\n");
    }
}

/*
 * Parse the productions:
 * indentless_sequence  ::= (BLOCK-ENTRY block_node?)+
 *                           *********** *
 */

static int
yaml_parser_parse_indentless_sequence_entry(yaml_parser_t *parser,
        yaml_event_t *event)
{
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_indentless_sequence_entry 1\n");
    yaml_token_t *token;

    token = PEEK_TOKEN(parser);
    if (!token) return 0;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_indentless_sequence_entry 1\n");

    if (token->type == YAML_BLOCK_ENTRY_TOKEN)
    {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_indentless_sequence_entry 2\n");
        yaml_mark_t mark = token->end_mark;
        SKIP_TOKEN(parser);
        token = PEEK_TOKEN(parser);
        if (!token) return 0;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_indentless_sequence_entry 2\n");
        if (token->type != YAML_BLOCK_ENTRY_TOKEN &&
                token->type != YAML_KEY_TOKEN &&
                token->type != YAML_VALUE_TOKEN &&
                token->type != YAML_BLOCK_END_TOKEN) {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_indentless_sequence_entry 3\n");
            if (!PUSH(parser, parser->states,
                        YAML_PARSE_INDENTLESS_SEQUENCE_ENTRY_STATE))
                return 0;
            return yaml_parser_parse_node(parser, event, 1, 0);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_indentless_sequence_entry 3\n");
        }
        else {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_indentless_sequence_entry 4\n");
            parser->state = YAML_PARSE_INDENTLESS_SEQUENCE_ENTRY_STATE;
            return yaml_parser_process_empty_scalar(parser, event, mark);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_indentless_sequence_entry 4\n");
        }
    }

    else
    {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_indentless_sequence_entry 5\n");
        parser->state = POP(parser, parser->states);
        SEQUENCE_END_EVENT_INIT(*event, token->start_mark, token->start_mark);
        return 1;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_indentless_sequence_entry 5\n");
    }
}

/*
 * Parse the productions:
 * block_mapping        ::= BLOCK-MAPPING_START
 *                          *******************
 *                          ((KEY block_node_or_indentless_sequence?)?
 *                            *** *
 *                          (VALUE block_node_or_indentless_sequence?)?)*
 *
 *                          BLOCK-END
 *                          *********
 */

static int
yaml_parser_parse_block_mapping_key(yaml_parser_t *parser,
        yaml_event_t *event, int first)
{
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_block_mapping_key 1\n");
    yaml_token_t *token;

    if (first) {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_block_mapping_key 2\n");
        token = PEEK_TOKEN(parser);
        if (!PUSH(parser, parser->marks, token->start_mark))
            return 0;
        SKIP_TOKEN(parser);
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_block_mapping_key 2\n");
    }

    token = PEEK_TOKEN(parser);
    if (!token) return 0;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_block_mapping_key 1\n");

    if (token->type == YAML_KEY_TOKEN)
    {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_block_mapping_key 3\n");
        yaml_mark_t mark = token->end_mark;
        SKIP_TOKEN(parser);
        token = PEEK_TOKEN(parser);
        if (!token) return 0;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_block_mapping_key 3\n");
        if (token->type != YAML_KEY_TOKEN &&
                token->type != YAML_VALUE_TOKEN &&
                token->type != YAML_BLOCK_END_TOKEN) {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_block_mapping_key 4\n");
            if (!PUSH(parser, parser->states,
                        YAML_PARSE_BLOCK_MAPPING_VALUE_STATE))
                return 0;
            return yaml_parser_parse_node(parser, event, 1, 1);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_block_mapping_key 4\n");
        }
        else {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_block_mapping_key 5\n");
            parser->state = YAML_PARSE_BLOCK_MAPPING_VALUE_STATE;
            return yaml_parser_process_empty_scalar(parser, event, mark);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_block_mapping_key 5\n");
        }
    }

    else if (token->type == YAML_BLOCK_END_TOKEN)
    {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_block_mapping_key 6\n");
        parser->state = POP(parser, parser->states);
        (void)POP(parser, parser->marks);
        MAPPING_END_EVENT_INIT(*event, token->start_mark, token->end_mark);
        SKIP_TOKEN(parser);
        return 1;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_block_mapping_key 6\n");
    }

    else
    {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_block_mapping_key 7\n");
        return yaml_parser_set_parser_error_context(parser,
                "while parsing a block mapping", POP(parser, parser->marks),
                "did not find expected key", token->start_mark);
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_block_mapping_key 7\n");
    }
}

/*
 * Parse the productions:
 * block_mapping        ::= BLOCK-MAPPING_START
 *
 *                          ((KEY block_node_or_indentless_sequence?)?
 *
 *                          (VALUE block_node_or_indentless_sequence?)?)*
 *                           ***** *
 *                          BLOCK-END
 *
 */

static int
yaml_parser_parse_block_mapping_value(yaml_parser_t *parser,
        yaml_event_t *event)
{
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_block_mapping_value 1\n");
    yaml_token_t *token;

    token = PEEK_TOKEN(parser);
    if (!token) return 0;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_block_mapping_value 1\n");

    if (token->type == YAML_VALUE_TOKEN)
    {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_block_mapping_value 2\n");
        yaml_mark_t mark = token->end_mark;
        SKIP_TOKEN(parser);
        token = PEEK_TOKEN(parser);
        if (!token) return 0;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_block_mapping_value 2\n");
        if (token->type != YAML_KEY_TOKEN &&
                token->type != YAML_VALUE_TOKEN &&
                token->type != YAML_BLOCK_END_TOKEN) {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_block_mapping_value 3\n");
            if (!PUSH(parser, parser->states,
                        YAML_PARSE_BLOCK_MAPPING_KEY_STATE))
                return 0;
            return yaml_parser_parse_node(parser, event, 1, 1);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_block_mapping_value 3\n");
        }
        else {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_block_mapping_value 4\n");
            parser->state = YAML_PARSE_BLOCK_MAPPING_KEY_STATE;
            return yaml_parser_process_empty_scalar(parser, event, mark);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_block_mapping_value 4\n");
        }
    }

    else
    {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_block_mapping_value 5\n");
        parser->state = YAML_PARSE_BLOCK_MAPPING_KEY_STATE;
        return yaml_parser_process_empty_scalar(parser, event, token->start_mark);
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_block_mapping_value 5\n");
    }
}

/*
 * Parse the productions:
 * flow_sequence        ::= FLOW-SEQUENCE-START
 *                          *******************
 *                          (flow_sequence_entry FLOW-ENTRY)*
 *                           *                   **********
 *                          flow_sequence_entry?
 *                          *
 *                          FLOW-SEQUENCE-END
 *                          *****************
 * flow_sequence_entry  ::= flow_node | KEY flow_node? (VALUE flow_node?)?
 *                          *
 */

static int
yaml_parser_parse_flow_sequence_entry(yaml_parser_t *parser,
        yaml_event_t *event, int first)
{
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_sequence_entry 1\n");
    yaml_token_t *token;

    if (first) {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_sequence_entry 2\n");
        token = PEEK_TOKEN(parser);
        if (!PUSH(parser, parser->marks, token->start_mark))
            return 0;
        SKIP_TOKEN(parser);
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_sequence_entry 2\n");
    }

    token = PEEK_TOKEN(parser);
    if (!token) return 0;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_sequence_entry 1\n");

    if (token->type != YAML_FLOW_SEQUENCE_END_TOKEN)
    {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_sequence_entry 3\n");
        if (!first) {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_sequence_entry 4\n");
            if (token->type == YAML_FLOW_ENTRY_TOKEN) {
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_sequence_entry 5\n");
                SKIP_TOKEN(parser);
                token = PEEK_TOKEN(parser);
                if (!token) return 0;
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_sequence_entry 5\n");
            }
            else {
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_sequence_entry 6\n");
                return yaml_parser_set_parser_error_context(parser,
                        "while parsing a flow sequence", POP(parser, parser->marks),
                        "did not find expected ',' or ']'", token->start_mark);
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_sequence_entry 6\n");
            }
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_sequence_entry 4\n");
        }

        if (token->type == YAML_KEY_TOKEN) {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_sequence_entry 7\n");
            parser->state = YAML_PARSE_FLOW_SEQUENCE_ENTRY_MAPPING_KEY_STATE;
            MAPPING_START_EVENT_INIT(*event, NULL, NULL,
                    1, YAML_FLOW_MAPPING_STYLE,
                    token->start_mark, token->end_mark);
            SKIP_TOKEN(parser);
            return 1;
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_sequence_entry 7\n");
        }

        else if (token->type != YAML_FLOW_SEQUENCE_END_TOKEN) {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_sequence_entry 8\n");
            if (!PUSH(parser, parser->states,
                        YAML_PARSE_FLOW_SEQUENCE_ENTRY_STATE))
                return 0;
            return yaml_parser_parse_node(parser, event, 0, 0);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_sequence_entry 8\n");
        }
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_sequence_entry 3\n");
    }

    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_sequence_entry 9\n");
    parser->state = POP(parser, parser->states);
    (void)POP(parser, parser->marks);
    SEQUENCE_END_EVENT_INIT(*event, token->start_mark, token->end_mark);
    SKIP_TOKEN(parser);
    return 1;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_sequence_entry 9\n");
}

/*
 * Parse the productions:
 * flow_sequence_entry  ::= flow_node | KEY flow_node? (VALUE flow_node?)?
 *                                      *** *
 */

static int
yaml_parser_parse_flow_sequence_entry_mapping_key(yaml_parser_t *parser,
        yaml_event_t *event)
{
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_sequence_entry_mapping_key 1\n");
    yaml_token_t *token;

    token = PEEK_TOKEN(parser);
    if (!token) return 0;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_sequence_entry_mapping_key 1\n");

    if (token->type != YAML_VALUE_TOKEN && token->type != YAML_FLOW_ENTRY_TOKEN
            && token->type != YAML_FLOW_SEQUENCE_END_TOKEN) {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_sequence_entry_mapping_key 2\n");
        if (!PUSH(parser, parser->states,
                    YAML_PARSE_FLOW_SEQUENCE_ENTRY_MAPPING_VALUE_STATE))
            return 0;
        return yaml_parser_parse_node(parser, event, 0, 0);
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_sequence_entry_mapping_key 2\n");
    }
    else if (token->type == YAML_FLOW_SEQUENCE_END_TOKEN) {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_sequence_entry_mapping_key 3\n");
        yaml_mark_t mark = token->start_mark;
        parser->state = YAML_PARSE_FLOW_SEQUENCE_ENTRY_MAPPING_VALUE_STATE;
        return yaml_parser_process_empty_scalar(parser, event, mark);
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_sequence_entry_mapping_key 3\n");
    }
    else {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_sequence_entry_mapping_key 4\n");
        yaml_mark_t mark = token->end_mark;
        SKIP_TOKEN(parser);
        parser->state = YAML_PARSE_FLOW_SEQUENCE_ENTRY_MAPPING_VALUE_STATE;
        return yaml_parser_process_empty_scalar(parser, event, mark);
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_sequence_entry_mapping_key 4\n");
    }
}

/*
 * Parse the productions:
 * flow_sequence_entry  ::= flow_node | KEY flow_node? (VALUE flow_node?)?
 *                                                      ***** *
 */

static int
yaml_parser_parse_flow_sequence_entry_mapping_value(yaml_parser_t *parser,
        yaml_event_t *event)
{
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_sequence_entry_mapping_value 1\n");
    yaml_token_t *token;

    token = PEEK_TOKEN(parser);
    if (!token) return 0;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_sequence_entry_mapping_value 1\n");

    if (token->type == YAML_VALUE_TOKEN) {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_sequence_entry_mapping_value 2\n");
        SKIP_TOKEN(parser);
        token = PEEK_TOKEN(parser);
        if (!token) return 0;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_sequence_entry_mapping_value 2\n");
        if (token->type != YAML_FLOW_ENTRY_TOKEN
                && token->type != YAML_FLOW_SEQUENCE_END_TOKEN) {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_sequence_entry_mapping_value 3\n");
            if (!PUSH(parser, parser->states,
                        YAML_PARSE_FLOW_SEQUENCE_ENTRY_MAPPING_END_STATE))
                return 0;
            return yaml_parser_parse_node(parser, event, 0, 0);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_sequence_entry_mapping_value 3\n");
        }
    }
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_sequence_entry_mapping_value 4\n");
    parser->state = YAML_PARSE_FLOW_SEQUENCE_ENTRY_MAPPING_END_STATE;
    return yaml_parser_process_empty_scalar(parser, event, token->start_mark);
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_sequence_entry_mapping_value 4\n");
}

/*
 * Parse the productions:
 * flow_sequence_entry  ::= flow_node | KEY flow_node? (VALUE flow_node?)?
 *                                                                      *
 */

static int
yaml_parser_parse_flow_sequence_entry_mapping_end(yaml_parser_t *parser,
        yaml_event_t *event)
{
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_sequence_entry_mapping_end 1\n");
    yaml_token_t *token;

    token = PEEK_TOKEN(parser);
    if (!token) return 0;

    parser->state = YAML_PARSE_FLOW_SEQUENCE_ENTRY_STATE;

    MAPPING_END_EVENT_INIT(*event, token->start_mark, token->start_mark);
    return 1;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_sequence_entry_mapping_end 1\n");
}

/*
 * Parse the productions:
 * flow_mapping         ::= FLOW-MAPPING-START
 *                          ******************
 *                          (flow_mapping_entry FLOW-ENTRY)*
 *                           *                  **********
 *                          flow_mapping_entry?
 *                          ******************
 *                          FLOW-MAPPING-END
 *                          ****************
 * flow_mapping_entry   ::= flow_node | KEY flow_node? (VALUE flow_node?)?
 *                          *           *** *
 */

static int
yaml_parser_parse_flow_mapping_key(yaml_parser_t *parser,
        yaml_event_t *event, int first)
{
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_mapping_key 1\n");
    yaml_token_t *token;

    if (first) {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_mapping_key 2\n");
        token = PEEK_TOKEN(parser);
        if (!PUSH(parser, parser->marks, token->start_mark))
            return 0;
        SKIP_TOKEN(parser);
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_mapping_key 2\n");
    }

    token = PEEK_TOKEN(parser);
    if (!token) return 0;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_mapping_key 1\n");

    if (token->type != YAML_FLOW_MAPPING_END_TOKEN)
    {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_mapping_key 3\n");
        if (!first) {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_mapping_key 4\n");
            if (token->type == YAML_FLOW_ENTRY_TOKEN) {
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_mapping_key 5\n");
                SKIP_TOKEN(parser);
                token = PEEK_TOKEN(parser);
                if (!token) return 0;
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_mapping_key 5\n");
            }
            else {
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_mapping_key 6\n");
                return yaml_parser_set_parser_error_context(parser,
                        "while parsing a flow mapping", POP(parser, parser->marks),
                        "did not find expected ',' or '}'", token->start_mark);
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_mapping_key 6\n");
            }
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_mapping_key 4\n");
        }

        if (token->type == YAML_KEY_TOKEN) {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_mapping_key 7\n");
            SKIP_TOKEN(parser);
            token = PEEK_TOKEN(parser);
            if (!token) return 0;
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_mapping_key 7\n");
            if (token->type != YAML_VALUE_TOKEN
                    && token->type != YAML_FLOW_ENTRY_TOKEN
                    && token->type != YAML_FLOW_MAPPING_END_TOKEN) {
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_mapping_key 8\n");
                if (!PUSH(parser, parser->states,
                            YAML_PARSE_FLOW_MAPPING_VALUE_STATE))
                    return 0;
                return yaml_parser_parse_node(parser, event, 0, 0);
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_mapping_key 8\n");
            }
            else {
                fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_mapping_key 9\n");
                parser->state = YAML_PARSE_FLOW_MAPPING_VALUE_STATE;
                return yaml_parser_process_empty_scalar(parser, event,
                        token->start_mark);
                fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_mapping_key 9\n");
            }
        }
        else if (token->type != YAML_FLOW_MAPPING_END_TOKEN) {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_mapping_key 10\n");
            if (!PUSH(parser, parser->states,
                        YAML_PARSE_FLOW_MAPPING_EMPTY_VALUE_STATE))
                return 0;
            return yaml_parser_parse_node(parser, event, 0, 0);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_mapping_key 10\n");
        }
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_mapping_key 3\n");
    }

    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_mapping_key 11\n");
    parser->state = POP(parser, parser->states);
    (void)POP(parser, parser->marks);
    MAPPING_END_EVENT_INIT(*event, token->start_mark, token->end_mark);
    SKIP_TOKEN(parser);
    return 1;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_mapping_key 11\n");
}

/*
 * Parse the productions:
 * flow_mapping_entry   ::= flow_node | KEY flow_node? (VALUE flow_node?)?
 *                                   *                  ***** *
 */

static int
yaml_parser_parse_flow_mapping_value(yaml_parser_t *parser,
        yaml_event_t *event, int empty)
{
    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_mapping_value 1\n");
    yaml_token_t *token;

    token = PEEK_TOKEN(parser);
    if (!token) return 0;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_mapping_value 1\n");

    if (empty) {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_mapping_value 2\n");
        parser->state = YAML_PARSE_FLOW_MAPPING_KEY_STATE;
        return yaml_parser_process_empty_scalar(parser, event,
                token->start_mark);
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_mapping_value 2\n");
    }

    if (token->type == YAML_VALUE_TOKEN) {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_mapping_value 3\n");
        SKIP_TOKEN(parser);
        token = PEEK_TOKEN(parser);
        if (!token) return 0;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_mapping_value 3\n");
        if (token->type != YAML_FLOW_ENTRY_TOKEN
                && token->type != YAML_FLOW_MAPPING_END_TOKEN) {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_mapping_value 4\n");
            if (!PUSH(parser, parser->states,
                        YAML_PARSE_FLOW_MAPPING_KEY_STATE))
                return 0;
            return yaml_parser_parse_node(parser, event, 0, 0);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_mapping_value 4\n");
        }
    }

    fprintf(stderr, "[src/parser.c] enter yaml_parser_parse_flow_mapping_value 5\n");
    parser->state = YAML_PARSE_FLOW_MAPPING_KEY_STATE;
    return yaml_parser_process_empty_scalar(parser, event, token->start_mark);
    fprintf(stderr, "[src/parser.c] exit yaml_parser_parse_flow_mapping_value 5\n");
}

/*
 * Generate an empty scalar event.
 */

static int
yaml_parser_process_empty_scalar(yaml_parser_t *parser, yaml_event_t *event,
        yaml_mark_t mark)
{
    fprintf(stderr, "[src/parser.c] enter yaml_parser_process_empty_scalar 1\n");
    yaml_char_t *value;

    value = YAML_MALLOC(1);
    if (!value) {
        parser->error = YAML_MEMORY_ERROR;
        return 0;
    }
    value[0] = '\0';

    SCALAR_EVENT_INIT(*event, NULL, NULL, value, 0,
            1, 0, YAML_PLAIN_SCALAR_STYLE, mark, mark);

    return 1;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_process_empty_scalar 1\n");
}

/*
 * Parse directives.
 */

static int
yaml_parser_process_directives(yaml_parser_t *parser,
        yaml_version_directive_t **version_directive_ref,
        yaml_tag_directive_t **tag_directives_start_ref,
        yaml_tag_directive_t **tag_directives_end_ref)
{
    fprintf(stderr, "[src/parser.c] enter yaml_parser_process_directives 1\n");
    yaml_tag_directive_t default_tag_directives[] = {
        {(yaml_char_t *)"!", (yaml_char_t *)"!"},
        {(yaml_char_t *)"!!", (yaml_char_t *)"tag:yaml.org,2002:"},
        {NULL, NULL}
    };
    yaml_tag_directive_t *default_tag_directive;
    yaml_version_directive_t *version_directive = NULL;
    struct {
        yaml_tag_directive_t *start;
        yaml_tag_directive_t *end;
        yaml_tag_directive_t *top;
    } tag_directives = { NULL, NULL, NULL };
    yaml_token_t *token;

    if (!STACK_INIT(parser, tag_directives, yaml_tag_directive_t*))
        goto error;

    token = PEEK_TOKEN(parser);
    if (!token) goto error;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_process_directives 1\n");

    while (token->type == YAML_VERSION_DIRECTIVE_TOKEN ||
            token->type == YAML_TAG_DIRECTIVE_TOKEN)
    {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_process_directives 2\n");
        if (token->type == YAML_VERSION_DIRECTIVE_TOKEN) {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_process_directives 3\n");
            if (version_directive) {
                fprintf(stderr, "[src/parser.c] enter yaml_parser_process_directives 4\n");
                yaml_parser_set_parser_error(parser,
                        "found duplicate %YAML directive", token->start_mark);
                goto error;
                fprintf(stderr, "[src/parser.c] exit yaml_parser_process_directives 4\n");
            }
            if (token->data.version_directive.major != 1
                    || (
                        token->data.version_directive.minor != 1
                        && token->data.version_directive.minor != 2
                    )) {
                fprintf(stderr, "[src/parser.c] enter yaml_parser_process_directives 5\n");
                yaml_parser_set_parser_error(parser,
                        "found incompatible YAML document", token->start_mark);
                goto error;
                fprintf(stderr, "[src/parser.c] exit yaml_parser_process_directives 5\n");
            }
            version_directive = YAML_MALLOC_STATIC(yaml_version_directive_t);
            if (!version_directive) {
                parser->error = YAML_MEMORY_ERROR;
                goto error;
            }
            version_directive->major = token->data.version_directive.major;
            version_directive->minor = token->data.version_directive.minor;
            fprintf(stderr, "[src/parser.c] exit yaml_parser_process_directives 3\n");
        }

        else if (token->type == YAML_TAG_DIRECTIVE_TOKEN) {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_process_directives 6\n");
            yaml_tag_directive_t value;
            value.handle = token->data.tag_directive.handle;
            value.prefix = token->data.tag_directive.prefix;

            if (!yaml_parser_append_tag_directive(parser, value, 0,
                        token->start_mark))
                goto error;
            if (!PUSH(parser, tag_directives, value))
                goto error;
            fprintf(stderr, "[src/parser.c] exit yaml_parser_process_directives 6\n");
        }

        SKIP_TOKEN(parser);
        token = PEEK_TOKEN(parser);
        if (!token) goto error;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_process_directives 2\n");
    }

    fprintf(stderr, "[src/parser.c] enter yaml_parser_process_directives 7\n");
    for (default_tag_directive = default_tag_directives;
            default_tag_directive->handle; default_tag_directive++) {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_process_directives 8\n");
        if (!yaml_parser_append_tag_directive(parser, *default_tag_directive, 1,
                    token->start_mark))
            goto error;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_process_directives 8\n");
    }

    if (version_directive_ref) {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_process_directives 9\n");
        *version_directive_ref = version_directive;
        fprintf(stderr, "[src/parser.c] exit yaml_parser_process_directives 9\n");
    }
    if (tag_directives_start_ref) {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_process_directives 10\n");
        if (STACK_EMPTY(parser, tag_directives)) {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_process_directives 11\n");
            *tag_directives_start_ref = *tag_directives_end_ref = NULL;
            STACK_DEL(parser, tag_directives);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_process_directives 11\n");
        }
        else {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_process_directives 12\n");
            *tag_directives_start_ref = tag_directives.start;
            *tag_directives_end_ref = tag_directives.top;
            fprintf(stderr, "[src/parser.c] exit yaml_parser_process_directives 12\n");
        }
        fprintf(stderr, "[src/parser.c] exit yaml_parser_process_directives 10\n");
    }
    else {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_process_directives 13\n");
        STACK_DEL(parser, tag_directives);
        fprintf(stderr, "[src/parser.c] exit yaml_parser_process_directives 13\n");
    }

    if (!version_directive_ref)
        yaml_free(version_directive);
    return 1;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_process_directives 7\n");

error:
    fprintf(stderr, "[src/parser.c] enter yaml_parser_process_directives 14\n");
    yaml_free(version_directive);
    while (!STACK_EMPTY(parser, tag_directives)) {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_process_directives 15\n");
        yaml_tag_directive_t tag_directive = POP(parser, tag_directives);
        yaml_free(tag_directive.handle);
        yaml_free(tag_directive.prefix);
        fprintf(stderr, "[src/parser.c] exit yaml_parser_process_directives 15\n");
    }
    STACK_DEL(parser, tag_directives);
    return 0;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_process_directives 14\n");
}

/*
 * Append a tag directive to the directives stack.
 */

static int
yaml_parser_append_tag_directive(yaml_parser_t *parser,
        yaml_tag_directive_t value, int allow_duplicates, yaml_mark_t mark)
{
    fprintf(stderr, "[src/parser.c] enter yaml_parser_append_tag_directive 1\n");
    yaml_tag_directive_t *tag_directive;
    yaml_tag_directive_t copy = { NULL, NULL };

    for (tag_directive = parser->tag_directives.start;
            tag_directive != parser->tag_directives.top; tag_directive ++) {
        fprintf(stderr, "[src/parser.c] enter yaml_parser_append_tag_directive 2\n");
        if (strcmp((char *)value.handle, (char *)tag_directive->handle) == 0) {
            fprintf(stderr, "[src/parser.c] enter yaml_parser_append_tag_directive 3\n");
            if (allow_duplicates)
                return 1;
            return yaml_parser_set_parser_error(parser,
                    "found duplicate %TAG directive", mark);
            fprintf(stderr, "[src/parser.c] exit yaml_parser_append_tag_directive 3\n");
        }
        fprintf(stderr, "[src/parser.c] exit yaml_parser_append_tag_directive 2\n");
    }

    copy.handle = yaml_strdup(value.handle);
    copy.prefix = yaml_strdup(value.prefix);
    if (!copy.handle || !copy.prefix) {
        parser->error = YAML_MEMORY_ERROR;
        goto error;
    }

    if (!PUSH(parser, parser->tag_directives, copy))
        goto error;

    return 1;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_append_tag_directive 1\n");

error:
    fprintf(stderr, "[src/parser.c] enter yaml_parser_append_tag_directive 4\n");
    yaml_free(copy.handle);
    yaml_free(copy.prefix);
    return 0;
    fprintf(stderr, "[src/parser.c] exit yaml_parser_append_tag_directive 4\n");
}
// Total cost: 2.805862
// Total split cost: 0.260593, input tokens: 65259, output tokens: 1123, cache read tokens: 4044, cache write tokens: 15704, split chunks: [(0, 760), (760, 1416)]
// Total instrumented cost: 2.545269, input tokens: 250563, output tokens: 123986, cache read tokens: 155918, cache write tokens: 94605

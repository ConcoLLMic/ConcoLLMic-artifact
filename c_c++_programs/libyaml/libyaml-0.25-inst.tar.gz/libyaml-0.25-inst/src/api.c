
#include "yaml_private.h"

/*
 * Get the library version.
 */

YAML_DECLARE(const char *)
yaml_get_version_string(void)
{
    fprintf(stderr, "[src/api.c] enter yaml_get_version_string 1\n");
    return YAML_VERSION_STRING;
    fprintf(stderr, "[src/api.c] exit yaml_get_version_string 1\n");
}

/*
 * Get the library version numbers.
 */

YAML_DECLARE(void)
yaml_get_version(int *major, int *minor, int *patch)
{
    fprintf(stderr, "[src/api.c] enter yaml_get_version 1\n");
    *major = YAML_VERSION_MAJOR;
    *minor = YAML_VERSION_MINOR;
    *patch = YAML_VERSION_PATCH;
    fprintf(stderr, "[src/api.c] exit yaml_get_version 1\n");
}

/*
 * Allocate a dynamic memory block.
 */

YAML_DECLARE(void *)
yaml_malloc(size_t size)
{
    fprintf(stderr, "[src/api.c] enter yaml_malloc 1\n");
    return malloc(size ? size : 1);
    fprintf(stderr, "[src/api.c] exit yaml_malloc 1\n");
}

/*
 * Reallocate a dynamic memory block.
 */

YAML_DECLARE(void *)
yaml_realloc(void *ptr, size_t size)
{
    fprintf(stderr, "[src/api.c] enter yaml_realloc 1\n");
    return ptr ? realloc(ptr, size ? size : 1) : malloc(size ? size : 1);
    fprintf(stderr, "[src/api.c] exit yaml_realloc 1\n");
}

/*
 * Free a dynamic memory block.
 */

YAML_DECLARE(void)
yaml_free(void *ptr)
{
    fprintf(stderr, "[src/api.c] enter yaml_free 1\n");
    if (ptr) free(ptr);
    fprintf(stderr, "[src/api.c] exit yaml_free 1\n");
}

/*
 * Duplicate a string.
 */

YAML_DECLARE(yaml_char_t *)
yaml_strdup(const yaml_char_t *str)
{
    fprintf(stderr, "[src/api.c] enter yaml_strdup 1\n");
    if (!str)
        return NULL;
    fprintf(stderr, "[src/api.c] exit yaml_strdup 1\n");

    fprintf(stderr, "[src/api.c] enter yaml_strdup 2\n");
    return (yaml_char_t *)strdup((char *)str);
    fprintf(stderr, "[src/api.c] exit yaml_strdup 2\n");
}

/*
 * Extend a string.
 */

YAML_DECLARE(int)
yaml_string_extend(yaml_char_t **start,
        yaml_char_t **pointer, yaml_char_t **end)
{
    fprintf(stderr, "[src/api.c] enter yaml_string_extend 1\n");
    yaml_char_t *new_start = (yaml_char_t *)yaml_realloc((void*)*start, (*end - *start)*2);

    if (!new_start) return 0;
    fprintf(stderr, "[src/api.c] exit yaml_string_extend 1\n");

    fprintf(stderr, "[src/api.c] enter yaml_string_extend 2\n");
    memset(new_start + (*end - *start), 0, *end - *start);

    *pointer = new_start + (*pointer - *start);
    *end = new_start + (*end - *start)*2;
    *start = new_start;

    return 1;
    fprintf(stderr, "[src/api.c] exit yaml_string_extend 2\n");
}

/*
 * Append a string B to a string A.
 */

YAML_DECLARE(int)
yaml_string_join(
        yaml_char_t **a_start, yaml_char_t **a_pointer, yaml_char_t **a_end,
        yaml_char_t **b_start, yaml_char_t **b_pointer, SHIM(yaml_char_t **b_end))
{
    fprintf(stderr, "[src/api.c] enter yaml_string_join 1\n");
    UNUSED_PARAM(b_end)
    if (*b_start == *b_pointer)
        return 1;
    fprintf(stderr, "[src/api.c] exit yaml_string_join 1\n");

    fprintf(stderr, "[src/api.c] enter yaml_string_join 2\n");
    while (*a_end - *a_pointer <= *b_pointer - *b_start) {
        fprintf(stderr, "[src/api.c] enter yaml_string_join 3\n");
        if (!yaml_string_extend(a_start, a_pointer, a_end))
            return 0;
        fprintf(stderr, "[src/api.c] exit yaml_string_join 3\n");
    }

    memcpy(*a_pointer, *b_start, *b_pointer - *b_start);
    *a_pointer += *b_pointer - *b_start;

    return 1;
    fprintf(stderr, "[src/api.c] exit yaml_string_join 2\n");
}

/*
 * Extend a stack.
 */

YAML_DECLARE(int)
yaml_stack_extend(void **start, void **top, void **end)
{
    fprintf(stderr, "[src/api.c] enter yaml_stack_extend 1\n");
    void *new_start;

    if ((char *)*end - (char *)*start >= INT_MAX / 2)
	return 0;
    fprintf(stderr, "[src/api.c] exit yaml_stack_extend 1\n");

    fprintf(stderr, "[src/api.c] enter yaml_stack_extend 2\n");
    new_start = yaml_realloc(*start, ((char *)*end - (char *)*start)*2);

    if (!new_start) return 0;
    fprintf(stderr, "[src/api.c] exit yaml_stack_extend 2\n");

    fprintf(stderr, "[src/api.c] enter yaml_stack_extend 3\n");
    *top = (char *)new_start + ((char *)*top - (char *)*start);
    *end = (char *)new_start + ((char *)*end - (char *)*start)*2;
    *start = new_start;

    return 1;
    fprintf(stderr, "[src/api.c] exit yaml_stack_extend 3\n");
}

/*
 * Extend or move a queue.
 */

YAML_DECLARE(int)
yaml_queue_extend(void **start, void **head, void **tail, void **end)
{
    fprintf(stderr, "[src/api.c] enter yaml_queue_extend 1\n");
    /* Check if we need to resize the queue. */

    if (*start == *head && *tail == *end) {
        fprintf(stderr, "[src/api.c] enter yaml_queue_extend 2\n");
        void *new_start = yaml_realloc(*start,
                ((char *)*end - (char *)*start)*2);

        if (!new_start) return 0;
        fprintf(stderr, "[src/api.c] exit yaml_queue_extend 2\n");

        fprintf(stderr, "[src/api.c] enter yaml_queue_extend 3\n");
        *head = (char *)new_start + ((char *)*head - (char *)*start);
        *tail = (char *)new_start + ((char *)*tail - (char *)*start);
        *end = (char *)new_start + ((char *)*end - (char *)*start)*2;
        *start = new_start;
        fprintf(stderr, "[src/api.c] exit yaml_queue_extend 3\n");
    }

    /* Check if we need to move the queue at the beginning of the buffer. */

    if (*tail == *end) {
        fprintf(stderr, "[src/api.c] enter yaml_queue_extend 4\n");
        if (*head != *tail) {
            fprintf(stderr, "[src/api.c] enter yaml_queue_extend 5\n");
            memmove(*start, *head, (char *)*tail - (char *)*head);
            fprintf(stderr, "[src/api.c] exit yaml_queue_extend 5\n");
        }
        *tail = (char *)*tail - (char *)*head + (char *)*start;
        *head = *start;
        fprintf(stderr, "[src/api.c] exit yaml_queue_extend 4\n");
    }

    return 1;
    fprintf(stderr, "[src/api.c] exit yaml_queue_extend 1\n");
}


/*
 * Create a new parser object.
 */

YAML_DECLARE(int)
yaml_parser_initialize(yaml_parser_t *parser)
{
    fprintf(stderr, "[src/api.c] enter yaml_parser_initialize 1\n");
    assert(parser);     /* Non-NULL parser object expected. */

    memset(parser, 0, sizeof(yaml_parser_t));
    if (!BUFFER_INIT(parser, parser->raw_buffer, INPUT_RAW_BUFFER_SIZE))
        goto error;
    if (!BUFFER_INIT(parser, parser->buffer, INPUT_BUFFER_SIZE))
        goto error;
    if (!QUEUE_INIT(parser, parser->tokens, INITIAL_QUEUE_SIZE, yaml_token_t*))
        goto error;
    if (!STACK_INIT(parser, parser->indents, int*))
        goto error;
    if (!STACK_INIT(parser, parser->simple_keys, yaml_simple_key_t*))
        goto error;
    if (!STACK_INIT(parser, parser->states, yaml_parser_state_t*))
        goto error;
    if (!STACK_INIT(parser, parser->marks, yaml_mark_t*))
        goto error;
    if (!STACK_INIT(parser, parser->tag_directives, yaml_tag_directive_t*))
        goto error;

    return 1;
    fprintf(stderr, "[src/api.c] exit yaml_parser_initialize 1\n");

error:
    fprintf(stderr, "[src/api.c] enter yaml_parser_initialize 2\n");
    BUFFER_DEL(parser, parser->raw_buffer);
    BUFFER_DEL(parser, parser->buffer);
    QUEUE_DEL(parser, parser->tokens);
    STACK_DEL(parser, parser->indents);
    STACK_DEL(parser, parser->simple_keys);
    STACK_DEL(parser, parser->states);
    STACK_DEL(parser, parser->marks);
    STACK_DEL(parser, parser->tag_directives);

    return 0;
    fprintf(stderr, "[src/api.c] exit yaml_parser_initialize 2\n");
}

/*
 * Destroy a parser object.
 */

YAML_DECLARE(void)
yaml_parser_delete(yaml_parser_t *parser)
{
    fprintf(stderr, "[src/api.c] enter yaml_parser_delete 1\n");
    assert(parser); /* Non-NULL parser object expected. */

    BUFFER_DEL(parser, parser->raw_buffer);
    BUFFER_DEL(parser, parser->buffer);
    while (!QUEUE_EMPTY(parser, parser->tokens)) {
        fprintf(stderr, "[src/api.c] enter yaml_parser_delete 2\n");
        yaml_token_delete(&DEQUEUE(parser, parser->tokens));
        fprintf(stderr, "[src/api.c] exit yaml_parser_delete 2\n");
    }
    QUEUE_DEL(parser, parser->tokens);
    STACK_DEL(parser, parser->indents);
    STACK_DEL(parser, parser->simple_keys);
    STACK_DEL(parser, parser->states);
    STACK_DEL(parser, parser->marks);
    while (!STACK_EMPTY(parser, parser->tag_directives)) {
        fprintf(stderr, "[src/api.c] enter yaml_parser_delete 3\n");
        yaml_tag_directive_t tag_directive = POP(parser, parser->tag_directives);
        yaml_free(tag_directive.handle);
        yaml_free(tag_directive.prefix);
        fprintf(stderr, "[src/api.c] exit yaml_parser_delete 3\n");
    }
    STACK_DEL(parser, parser->tag_directives);

    memset(parser, 0, sizeof(yaml_parser_t));
    fprintf(stderr, "[src/api.c] exit yaml_parser_delete 1\n");
}

/*
 * String read handler.
 */

static int
yaml_string_read_handler(void *data, unsigned char *buffer, size_t size,
        size_t *size_read)
{
    fprintf(stderr, "[src/api.c] enter yaml_string_read_handler 1\n");
    yaml_parser_t *parser = (yaml_parser_t *)data;

    if (parser->input.string.current == parser->input.string.end) {
        fprintf(stderr, "[src/api.c] enter yaml_string_read_handler 2\n");
        *size_read = 0;
        return 1;
        fprintf(stderr, "[src/api.c] exit yaml_string_read_handler 2\n");
    }

    if (size > (size_t)(parser->input.string.end
                - parser->input.string.current)) {
        fprintf(stderr, "[src/api.c] enter yaml_string_read_handler 3\n");
        size = parser->input.string.end - parser->input.string.current;
        fprintf(stderr, "[src/api.c] exit yaml_string_read_handler 3\n");
    }

    fprintf(stderr, "[src/api.c] enter yaml_string_read_handler 4\n");
    memcpy(buffer, parser->input.string.current, size);
    parser->input.string.current += size;
    *size_read = size;
    return 1;
    fprintf(stderr, "[src/api.c] exit yaml_string_read_handler 4\n");
    fprintf(stderr, "[src/api.c] exit yaml_string_read_handler 1\n");
}

/*
 * File read handler.
 */

static int
yaml_file_read_handler(void *data, unsigned char *buffer, size_t size,
        size_t *size_read)
{
    fprintf(stderr, "[src/api.c] enter yaml_file_read_handler 1\n");
    yaml_parser_t *parser = (yaml_parser_t *)data;

    *size_read = fread(buffer, 1, size, parser->input.file);
    return !ferror(parser->input.file);
    fprintf(stderr, "[src/api.c] exit yaml_file_read_handler 1\n");
}

/*
 * Set a string input.
 */

YAML_DECLARE(void)
yaml_parser_set_input_string(yaml_parser_t *parser,
        const unsigned char *input, size_t size)
{
    fprintf(stderr, "[src/api.c] enter yaml_parser_set_input_string 1\n");
    assert(parser); /* Non-NULL parser object expected. */
    assert(!parser->read_handler);  /* You can set the source only once. */
    assert(input);  /* Non-NULL input string expected. */

    parser->read_handler = yaml_string_read_handler;
    parser->read_handler_data = parser;

    parser->input.string.start = input;
    parser->input.string.current = input;
    parser->input.string.end = input+size;
    fprintf(stderr, "[src/api.c] exit yaml_parser_set_input_string 1\n");
}

/*
 * Set a file input.
 */

YAML_DECLARE(void)
yaml_parser_set_input_file(yaml_parser_t *parser, FILE *file)
{
    fprintf(stderr, "[src/api.c] enter yaml_parser_set_input_file 1\n");
    assert(parser); /* Non-NULL parser object expected. */
    assert(!parser->read_handler);  /* You can set the source only once. */
    assert(file);   /* Non-NULL file object expected. */

    parser->read_handler = yaml_file_read_handler;
    parser->read_handler_data = parser;

    parser->input.file = file;
    fprintf(stderr, "[src/api.c] exit yaml_parser_set_input_file 1\n");
}

/*
 * Set a generic input.
 */

YAML_DECLARE(void)
yaml_parser_set_input(yaml_parser_t *parser,
        yaml_read_handler_t *handler, void *data)
{
    fprintf(stderr, "[src/api.c] enter yaml_parser_set_input 1\n");
    assert(parser); /* Non-NULL parser object expected. */
    assert(!parser->read_handler);  /* You can set the source only once. */
    assert(handler);    /* Non-NULL read handler expected. */

    parser->read_handler = handler;
    parser->read_handler_data = data;
    fprintf(stderr, "[src/api.c] exit yaml_parser_set_input 1\n");
}

/*
 * Set the source encoding.
 */

YAML_DECLARE(void)
yaml_parser_set_encoding(yaml_parser_t *parser, yaml_encoding_t encoding)
{
    fprintf(stderr, "[src/api.c] enter yaml_parser_set_encoding 1\n");
    assert(parser); /* Non-NULL parser object expected. */
    assert(!parser->encoding); /* Encoding is already set or detected. */

    parser->encoding = encoding;
    fprintf(stderr, "[src/api.c] exit yaml_parser_set_encoding 1\n");
}

/*
 * Create a new emitter object.
 */

YAML_DECLARE(int)
yaml_emitter_initialize(yaml_emitter_t *emitter)
{
    fprintf(stderr, "[src/api.c] enter yaml_emitter_initialize 1\n");
    assert(emitter);    /* Non-NULL emitter object expected. */

    memset(emitter, 0, sizeof(yaml_emitter_t));
    if (!BUFFER_INIT(emitter, emitter->buffer, OUTPUT_BUFFER_SIZE))
        goto error;
    if (!BUFFER_INIT(emitter, emitter->raw_buffer, OUTPUT_RAW_BUFFER_SIZE))
        goto error;
    if (!STACK_INIT(emitter, emitter->states, yaml_emitter_state_t*))
        goto error;
    if (!QUEUE_INIT(emitter, emitter->events, INITIAL_QUEUE_SIZE, yaml_event_t*))
        goto error;
    if (!STACK_INIT(emitter, emitter->indents, int*))
        goto error;
    if (!STACK_INIT(emitter, emitter->tag_directives, yaml_tag_directive_t*))
        goto error;

    return 1;
    fprintf(stderr, "[src/api.c] exit yaml_emitter_initialize 1\n");

error:
    fprintf(stderr, "[src/api.c] enter yaml_emitter_initialize 2\n");
    BUFFER_DEL(emitter, emitter->buffer);
    BUFFER_DEL(emitter, emitter->raw_buffer);
    STACK_DEL(emitter, emitter->states);
    QUEUE_DEL(emitter, emitter->events);
    STACK_DEL(emitter, emitter->indents);
    STACK_DEL(emitter, emitter->tag_directives);

    return 0;
    fprintf(stderr, "[src/api.c] exit yaml_emitter_initialize 2\n");
}

/*
 * Destroy an emitter object.
 */

YAML_DECLARE(void)
yaml_emitter_delete(yaml_emitter_t *emitter)
{
    fprintf(stderr, "[src/api.c] enter yaml_emitter_delete 1\n");
    assert(emitter);    /* Non-NULL emitter object expected. */

    BUFFER_DEL(emitter, emitter->buffer);
    BUFFER_DEL(emitter, emitter->raw_buffer);
    STACK_DEL(emitter, emitter->states);
    while (!QUEUE_EMPTY(emitter, emitter->events)) {
        fprintf(stderr, "[src/api.c] enter yaml_emitter_delete 2\n");
        yaml_event_delete(&DEQUEUE(emitter, emitter->events));
        fprintf(stderr, "[src/api.c] exit yaml_emitter_delete 2\n");
    }
    QUEUE_DEL(emitter, emitter->events);
    STACK_DEL(emitter, emitter->indents);
    while (!STACK_EMPTY(empty, emitter->tag_directives)) {
        fprintf(stderr, "[src/api.c] enter yaml_emitter_delete 3\n");
        yaml_tag_directive_t tag_directive = POP(emitter, emitter->tag_directives);
        yaml_free(tag_directive.handle);
        yaml_free(tag_directive.prefix);
        fprintf(stderr, "[src/api.c] exit yaml_emitter_delete 3\n");
    }
    STACK_DEL(emitter, emitter->tag_directives);
    yaml_free(emitter->anchors);

    memset(emitter, 0, sizeof(yaml_emitter_t));
    fprintf(stderr, "[src/api.c] exit yaml_emitter_delete 1\n");
}

/*
 * String write handler.
 */

static int
yaml_string_write_handler(void *data, unsigned char *buffer, size_t size)
{
    fprintf(stderr, "[src/api.c] enter yaml_string_write_handler 1\n");
    yaml_emitter_t *emitter = (yaml_emitter_t *)data;

    if (emitter->output.string.size - *emitter->output.string.size_written
            < size) {
        fprintf(stderr, "[src/api.c] enter yaml_string_write_handler 2\n");
        memcpy(emitter->output.string.buffer
                + *emitter->output.string.size_written,
                buffer,
                emitter->output.string.size
                - *emitter->output.string.size_written);
        *emitter->output.string.size_written = emitter->output.string.size;
        return 0;
        fprintf(stderr, "[src/api.c] exit yaml_string_write_handler 2\n");
    }

    fprintf(stderr, "[src/api.c] enter yaml_string_write_handler 3\n");
    memcpy(emitter->output.string.buffer
            + *emitter->output.string.size_written, buffer, size);
    *emitter->output.string.size_written += size;
    return 1;
    fprintf(stderr, "[src/api.c] exit yaml_string_write_handler 3\n");
    fprintf(stderr, "[src/api.c] exit yaml_string_write_handler 1\n");
}

/*
 * File write handler.
 */

static int
yaml_file_write_handler(void *data, unsigned char *buffer, size_t size)
{
    fprintf(stderr, "[src/api.c] enter yaml_file_write_handler 1\n");
    yaml_emitter_t *emitter = (yaml_emitter_t *)data;

    return (fwrite(buffer, 1, size, emitter->output.file) == size);
    fprintf(stderr, "[src/api.c] exit yaml_file_write_handler 1\n");
}
/*
 * Set a string output.
 */

YAML_DECLARE(void)
yaml_emitter_set_output_string(yaml_emitter_t *emitter,
        unsigned char *output, size_t size, size_t *size_written)
{
    fprintf(stderr, "[src/api.c] enter yaml_emitter_set_output_string 1\n");
    assert(emitter);    /* Non-NULL emitter object expected. */
    assert(!emitter->write_handler);    /* You can set the output only once. */
    assert(output);     /* Non-NULL output string expected. */

    emitter->write_handler = yaml_string_write_handler;
    emitter->write_handler_data = emitter;

    emitter->output.string.buffer = output;
    emitter->output.string.size = size;
    emitter->output.string.size_written = size_written;
    *size_written = 0;
    fprintf(stderr, "[src/api.c] exit yaml_emitter_set_output_string 1\n");
}

/*
 * Set a file output.
 */

YAML_DECLARE(void)
yaml_emitter_set_output_file(yaml_emitter_t *emitter, FILE *file)
{
    fprintf(stderr, "[src/api.c] enter yaml_emitter_set_output_file 1\n");
    assert(emitter);    /* Non-NULL emitter object expected. */
    assert(!emitter->write_handler);    /* You can set the output only once. */
    assert(file);       /* Non-NULL file object expected. */

    emitter->write_handler = yaml_file_write_handler;
    emitter->write_handler_data = emitter;

    emitter->output.file = file;
    fprintf(stderr, "[src/api.c] exit yaml_emitter_set_output_file 1\n");
}

/*
 * Set a generic output handler.
 */

YAML_DECLARE(void)
yaml_emitter_set_output(yaml_emitter_t *emitter,
        yaml_write_handler_t *handler, void *data)
{
    fprintf(stderr, "[src/api.c] enter yaml_emitter_set_output 1\n");
    assert(emitter);    /* Non-NULL emitter object expected. */
    assert(!emitter->write_handler);    /* You can set the output only once. */
    assert(handler);    /* Non-NULL handler object expected. */

    emitter->write_handler = handler;
    emitter->write_handler_data = data;
    fprintf(stderr, "[src/api.c] exit yaml_emitter_set_output 1\n");
}

/*
 * Set the output encoding.
 */

YAML_DECLARE(void)
yaml_emitter_set_encoding(yaml_emitter_t *emitter, yaml_encoding_t encoding)
{
    fprintf(stderr, "[src/api.c] enter yaml_emitter_set_encoding 1\n");
    assert(emitter);    /* Non-NULL emitter object expected. */
    assert(!emitter->encoding);     /* You can set encoding only once. */

    emitter->encoding = encoding;
    fprintf(stderr, "[src/api.c] exit yaml_emitter_set_encoding 1\n");
}

/*
 * Set the canonical output style.
 */

YAML_DECLARE(void)
yaml_emitter_set_canonical(yaml_emitter_t *emitter, int canonical)
{
    fprintf(stderr, "[src/api.c] enter yaml_emitter_set_canonical 1\n");
    assert(emitter);    /* Non-NULL emitter object expected. */

    emitter->canonical = (canonical != 0);
    fprintf(stderr, "[src/api.c] exit yaml_emitter_set_canonical 1\n");
}

/*
 * Set the indentation increment.
 */

YAML_DECLARE(void)
yaml_emitter_set_indent(yaml_emitter_t *emitter, int indent)
{
    fprintf(stderr, "[src/api.c] enter yaml_emitter_set_indent 1\n");
    assert(emitter);    /* Non-NULL emitter object expected. */

    emitter->best_indent = (1 < indent && indent < 10) ? indent : 2;
    fprintf(stderr, "[src/api.c] exit yaml_emitter_set_indent 1\n");
}

/*
 * Set the preferred line width.
 */

YAML_DECLARE(void)
yaml_emitter_set_width(yaml_emitter_t *emitter, int width)
{
    fprintf(stderr, "[src/api.c] enter yaml_emitter_set_width 1\n");
    assert(emitter);    /* Non-NULL emitter object expected. */

    emitter->best_width = (width >= 0) ? width : -1;
    fprintf(stderr, "[src/api.c] exit yaml_emitter_set_width 1\n");
}

/*
 * Set if unescaped non-ASCII characters are allowed.
 */

YAML_DECLARE(void)
yaml_emitter_set_unicode(yaml_emitter_t *emitter, int unicode)
{
    fprintf(stderr, "[src/api.c] enter yaml_emitter_set_unicode 1\n");
    assert(emitter);    /* Non-NULL emitter object expected. */

    emitter->unicode = (unicode != 0);
    fprintf(stderr, "[src/api.c] exit yaml_emitter_set_unicode 1\n");
}

/*
 * Set the preferred line break character.
 */

YAML_DECLARE(void)
yaml_emitter_set_break(yaml_emitter_t *emitter, yaml_break_t line_break)
{
    fprintf(stderr, "[src/api.c] enter yaml_emitter_set_break 1\n");
    assert(emitter);    /* Non-NULL emitter object expected. */

    emitter->line_break = line_break;
    fprintf(stderr, "[src/api.c] exit yaml_emitter_set_break 1\n");
}

/*
 * Destroy a token object.
 */

YAML_DECLARE(void)
yaml_token_delete(yaml_token_t *token)
{
    fprintf(stderr, "[src/api.c] enter yaml_token_delete 1\n");
    assert(token);  /* Non-NULL token object expected. */

    switch (token->type)
    {
        case YAML_TAG_DIRECTIVE_TOKEN:
            fprintf(stderr, "[src/api.c] enter yaml_token_delete 2\n");
            yaml_free(token->data.tag_directive.handle);
            yaml_free(token->data.tag_directive.prefix);
            fprintf(stderr, "[src/api.c] exit yaml_token_delete 2\n");
            break;

        case YAML_ALIAS_TOKEN:
            fprintf(stderr, "[src/api.c] enter yaml_token_delete 3\n");
            yaml_free(token->data.alias.value);
            fprintf(stderr, "[src/api.c] exit yaml_token_delete 3\n");
            break;

        case YAML_ANCHOR_TOKEN:
            fprintf(stderr, "[src/api.c] enter yaml_token_delete 4\n");
            yaml_free(token->data.anchor.value);
            fprintf(stderr, "[src/api.c] exit yaml_token_delete 4\n");
            break;

        case YAML_TAG_TOKEN:
            fprintf(stderr, "[src/api.c] enter yaml_token_delete 5\n");
            yaml_free(token->data.tag.handle);
            yaml_free(token->data.tag.suffix);
            fprintf(stderr, "[src/api.c] exit yaml_token_delete 5\n");
            break;

        case YAML_SCALAR_TOKEN:
            fprintf(stderr, "[src/api.c] enter yaml_token_delete 6\n");
            yaml_free(token->data.scalar.value);
            fprintf(stderr, "[src/api.c] exit yaml_token_delete 6\n");
            break;

        default:
            break;
    }

    memset(token, 0, sizeof(yaml_token_t));
    fprintf(stderr, "[src/api.c] exit yaml_token_delete 1\n");
}

/*
 * Check if a string is a valid UTF-8 sequence.
 *
 * Check 'reader.c' for more details on UTF-8 encoding.
 */

static int
yaml_check_utf8(const yaml_char_t *start, size_t length)
{
    fprintf(stderr, "[src/api.c] enter yaml_check_utf8 1\n");
    const yaml_char_t *end = start+length;
    const yaml_char_t *pointer = start;

    while (pointer < end) {
        fprintf(stderr, "[src/api.c] enter yaml_check_utf8 2\n");
        unsigned char octet;
        unsigned int width;
        unsigned int value;
        size_t k;

        octet = pointer[0];
        width = (octet & 0x80) == 0x00 ? 1 :
                (octet & 0xE0) == 0xC0 ? 2 :
                (octet & 0xF0) == 0xE0 ? 3 :
                (octet & 0xF8) == 0xF0 ? 4 : 0;
        value = (octet & 0x80) == 0x00 ? octet & 0x7F :
                (octet & 0xE0) == 0xC0 ? octet & 0x1F :
                (octet & 0xF0) == 0xE0 ? octet & 0x0F :
                (octet & 0xF8) == 0xF0 ? octet & 0x07 : 0;
        if (!width) return 0;
        if (pointer+width > end) return 0;
        for (k = 1; k < width; k ++) {
            fprintf(stderr, "[src/api.c] enter yaml_check_utf8 3\n");
            octet = pointer[k];
            if ((octet & 0xC0) != 0x80) return 0;
            value = (value << 6) + (octet & 0x3F);
            fprintf(stderr, "[src/api.c] exit yaml_check_utf8 3\n");
        }
        if (!((width == 1) ||
            (width == 2 && value >= 0x80) ||
            (width == 3 && value >= 0x800) ||
            (width == 4 && value >= 0x10000))) return 0;

        pointer += width;
        fprintf(stderr, "[src/api.c] exit yaml_check_utf8 2\n");
    }

    return 1;
    fprintf(stderr, "[src/api.c] exit yaml_check_utf8 1\n");
}

/*
 * Create STREAM-START.
 */

YAML_DECLARE(int)
yaml_stream_start_event_initialize(yaml_event_t *event,
        yaml_encoding_t encoding)
{
    fprintf(stderr, "[src/api.c] enter yaml_stream_start_event_initialize 1\n");
    yaml_mark_t mark = { 0, 0, 0 };

    assert(event);  /* Non-NULL event object is expected. */

    STREAM_START_EVENT_INIT(*event, encoding, mark, mark);

    return 1;
    fprintf(stderr, "[src/api.c] exit yaml_stream_start_event_initialize 1\n");
}

/*
 * Create STREAM-END.
 */

YAML_DECLARE(int)
yaml_stream_end_event_initialize(yaml_event_t *event)
{
    fprintf(stderr, "[src/api.c] enter yaml_stream_end_event_initialize 1\n");
    yaml_mark_t mark = { 0, 0, 0 };

    assert(event);  /* Non-NULL event object is expected. */

    STREAM_END_EVENT_INIT(*event, mark, mark);

    return 1;
    fprintf(stderr, "[src/api.c] exit yaml_stream_end_event_initialize 1\n");
}

/*
 * Create DOCUMENT-START.
 */

YAML_DECLARE(int)
yaml_document_start_event_initialize(yaml_event_t *event,
        yaml_version_directive_t *version_directive,
        yaml_tag_directive_t *tag_directives_start,
        yaml_tag_directive_t *tag_directives_end,
        int implicit)
{
    fprintf(stderr, "\n");
    struct {
        yaml_error_type_t error;
    } context;
    yaml_mark_t mark = { 0, 0, 0 };
    yaml_version_directive_t *version_directive_copy = NULL;
    struct {
        yaml_tag_directive_t *start;
        yaml_tag_directive_t *end;
        yaml_tag_directive_t *top;
    } tag_directives_copy = { NULL, NULL, NULL };
    yaml_tag_directive_t value = { NULL, NULL };

    assert(event);          /* Non-NULL event object is expected. */
    assert((tag_directives_start && tag_directives_end) ||
            (tag_directives_start == tag_directives_end));
                            /* Valid tag directives are expected. */

    if (version_directive) {
        fprintf(stderr, "[src/api.c] enter yaml_document_start_event_initialize 2\n");
        version_directive_copy = YAML_MALLOC_STATIC(yaml_version_directive_t);
        if (!version_directive_copy) goto error;
        version_directive_copy->major = version_directive->major;
        version_directive_copy->minor = version_directive->minor;
        fprintf(stderr, "[src/api.c] exit yaml_document_start_event_initialize 2\n");
    }

    if (tag_directives_start != tag_directives_end) {
        fprintf(stderr, "[src/api.c] enter yaml_document_start_event_initialize 3\n");
        yaml_tag_directive_t *tag_directive;
        if (!STACK_INIT(&context, tag_directives_copy, yaml_tag_directive_t*))
            goto error;
        for (tag_directive = tag_directives_start;
                tag_directive != tag_directives_end; tag_directive ++) {
            fprintf(stderr, "[src/api.c] enter yaml_document_start_event_initialize 4\n");
            assert(tag_directive->handle);
            assert(tag_directive->prefix);
            if (!yaml_check_utf8(tag_directive->handle,
                        strlen((char *)tag_directive->handle)))
                goto error;
            if (!yaml_check_utf8(tag_directive->prefix,
                        strlen((char *)tag_directive->prefix)))
                goto error;
            value.handle = yaml_strdup(tag_directive->handle);
            value.prefix = yaml_strdup(tag_directive->prefix);
            if (!value.handle || !value.prefix) goto error;
            if (!PUSH(&context, tag_directives_copy, value))
                goto error;
            value.handle = NULL;
            value.prefix = NULL;
            fprintf(stderr, "[src/api.c] exit yaml_document_start_event_initialize 4\n");
        }
        fprintf(stderr, "[src/api.c] exit yaml_document_start_event_initialize 3\n");
    }

    fprintf(stderr, "[src/api.c] enter yaml_document_start_event_initialize 5\n");
    DOCUMENT_START_EVENT_INIT(*event, version_directive_copy,
            tag_directives_copy.start, tag_directives_copy.top,
            implicit, mark, mark);

    return 1;
    fprintf(stderr, "[src/api.c] exit yaml_document_start_event_initialize 5\n");

error:
    fprintf(stderr, "[src/api.c] enter yaml_document_start_event_initialize 6\n");
    yaml_free(version_directive_copy);
    while (!STACK_EMPTY(context, tag_directives_copy)) {
        fprintf(stderr, "[src/api.c] enter yaml_document_start_event_initialize 7\n");
        yaml_tag_directive_t value = POP(context, tag_directives_copy);
        yaml_free(value.handle);
        yaml_free(value.prefix);
        fprintf(stderr, "[src/api.c] exit yaml_document_start_event_initialize 7\n");
    }
    STACK_DEL(context, tag_directives_copy);
    yaml_free(value.handle);
    yaml_free(value.prefix);

    return 0;
    fprintf(stderr, "[src/api.c] exit yaml_document_start_event_initialize 6\n");
}

/*
 * Create DOCUMENT-END.
 */

YAML_DECLARE(int)
yaml_document_end_event_initialize(yaml_event_t *event, int implicit)
{
    fprintf(stderr, "[src/api.c] enter yaml_document_end_event_initialize 1\n");
    yaml_mark_t mark = { 0, 0, 0 };

    assert(event);      /* Non-NULL emitter object is expected. */

    DOCUMENT_END_EVENT_INIT(*event, implicit, mark, mark);

    return 1;
    fprintf(stderr, "[src/api.c] exit yaml_document_end_event_initialize 1\n");
}

/*
 * Create ALIAS.
 */
YAML_DECLARE(int)
yaml_alias_event_initialize(yaml_event_t *event, const yaml_char_t *anchor)
{
    fprintf(stderr, "[src/api.c] enter yaml_alias_event_initialize 1\n");
    yaml_mark_t mark = { 0, 0, 0 };
    yaml_char_t *anchor_copy = NULL;

    assert(event);      /* Non-NULL event object is expected. */
    assert(anchor);     /* Non-NULL anchor is expected. */

    if (!yaml_check_utf8(anchor, strlen((char *)anchor))) return 0;
    fprintf(stderr, "[src/api.c] exit yaml_alias_event_initialize 1\n");

    fprintf(stderr, "[src/api.c] enter yaml_alias_event_initialize 2\n");
    anchor_copy = yaml_strdup(anchor);
    if (!anchor_copy)
        return 0;
    fprintf(stderr, "[src/api.c] exit yaml_alias_event_initialize 2\n");

    fprintf(stderr, "[src/api.c] enter yaml_alias_event_initialize 3\n");
    ALIAS_EVENT_INIT(*event, anchor_copy, mark, mark);

    return 1;
    fprintf(stderr, "[src/api.c] exit yaml_alias_event_initialize 3\n");
}

/*
 * Create SCALAR.
 */

YAML_DECLARE(int)
yaml_scalar_event_initialize(yaml_event_t *event,
        const yaml_char_t *anchor, const yaml_char_t *tag,
        const yaml_char_t *value, int length,
        int plain_implicit, int quoted_implicit,
        yaml_scalar_style_t style)
{
    fprintf(stderr, "[src/api.c] enter yaml_scalar_event_initialize 1\n");
    yaml_mark_t mark = { 0, 0, 0 };
    yaml_char_t *anchor_copy = NULL;
    yaml_char_t *tag_copy = NULL;
    yaml_char_t *value_copy = NULL;

    assert(event);      /* Non-NULL event object is expected. */
    assert(value);      /* Non-NULL anchor is expected. */
    fprintf(stderr, "[src/api.c] exit yaml_scalar_event_initialize 1\n");

    if (anchor) {
        fprintf(stderr, "[src/api.c] enter yaml_scalar_event_initialize 2\n");
        if (!yaml_check_utf8(anchor, strlen((char *)anchor))) goto error;
        anchor_copy = yaml_strdup(anchor);
        if (!anchor_copy) goto error;
        fprintf(stderr, "[src/api.c] exit yaml_scalar_event_initialize 2\n");
    }

    if (tag) {
        fprintf(stderr, "[src/api.c] enter yaml_scalar_event_initialize 3\n");
        if (!yaml_check_utf8(tag, strlen((char *)tag))) goto error;
        tag_copy = yaml_strdup(tag);
        if (!tag_copy) goto error;
        fprintf(stderr, "[src/api.c] exit yaml_scalar_event_initialize 3\n");
    }

    if (length < 0) {
        fprintf(stderr, "[src/api.c] enter yaml_scalar_event_initialize 4\n");
        length = strlen((char *)value);
        fprintf(stderr, "[src/api.c] exit yaml_scalar_event_initialize 4\n");
    }

    fprintf(stderr, "[src/api.c] enter yaml_scalar_event_initialize 5\n");
    if (!yaml_check_utf8(value, length)) goto error;
    value_copy = YAML_MALLOC(length+1);
    if (!value_copy) goto error;
    memcpy(value_copy, value, length);
    value_copy[length] = '\0';
    fprintf(stderr, "[src/api.c] exit yaml_scalar_event_initialize 5\n");

    fprintf(stderr, "[src/api.c] enter yaml_scalar_event_initialize 6\n");
    SCALAR_EVENT_INIT(*event, anchor_copy, tag_copy, value_copy, length,
            plain_implicit, quoted_implicit, style, mark, mark);

    return 1;
    fprintf(stderr, "[src/api.c] exit yaml_scalar_event_initialize 6\n");

error:
    fprintf(stderr, "[src/api.c] enter yaml_scalar_event_initialize 7\n");
    yaml_free(anchor_copy);
    yaml_free(tag_copy);
    yaml_free(value_copy);

    return 0;
    fprintf(stderr, "[src/api.c] exit yaml_scalar_event_initialize 7\n");
}

/*
 * Create SEQUENCE-START.
 */

YAML_DECLARE(int)
yaml_sequence_start_event_initialize(yaml_event_t *event,
        const yaml_char_t *anchor, const yaml_char_t *tag, int implicit,
        yaml_sequence_style_t style)
{
    fprintf(stderr, "[src/api.c] enter yaml_sequence_start_event_initialize 1\n");
    yaml_mark_t mark = { 0, 0, 0 };
    yaml_char_t *anchor_copy = NULL;
    yaml_char_t *tag_copy = NULL;

    assert(event);      /* Non-NULL event object is expected. */
    fprintf(stderr, "[src/api.c] exit yaml_sequence_start_event_initialize 1\n");

    if (anchor) {
        fprintf(stderr, "[src/api.c] enter yaml_sequence_start_event_initialize 2\n");
        if (!yaml_check_utf8(anchor, strlen((char *)anchor))) goto error;
        anchor_copy = yaml_strdup(anchor);
        if (!anchor_copy) goto error;
        fprintf(stderr, "[src/api.c] exit yaml_sequence_start_event_initialize 2\n");
    }

    if (tag) {
        fprintf(stderr, "[src/api.c] enter yaml_sequence_start_event_initialize 3\n");
        if (!yaml_check_utf8(tag, strlen((char *)tag))) goto error;
        tag_copy = yaml_strdup(tag);
        if (!tag_copy) goto error;
        fprintf(stderr, "[src/api.c] exit yaml_sequence_start_event_initialize 3\n");
    }

    fprintf(stderr, "[src/api.c] enter yaml_sequence_start_event_initialize 4\n");
    SEQUENCE_START_EVENT_INIT(*event, anchor_copy, tag_copy,
            implicit, style, mark, mark);

    return 1;
    fprintf(stderr, "[src/api.c] exit yaml_sequence_start_event_initialize 4\n");

error:
    fprintf(stderr, "[src/api.c] enter yaml_sequence_start_event_initialize 5\n");
    yaml_free(anchor_copy);
    yaml_free(tag_copy);

    return 0;
    fprintf(stderr, "[src/api.c] exit yaml_sequence_start_event_initialize 5\n");
}

/*
 * Create SEQUENCE-END.
 */

YAML_DECLARE(int)
yaml_sequence_end_event_initialize(yaml_event_t *event)
{
    fprintf(stderr, "[src/api.c] enter yaml_sequence_end_event_initialize 1\n");
    yaml_mark_t mark = { 0, 0, 0 };

    assert(event);      /* Non-NULL event object is expected. */

    SEQUENCE_END_EVENT_INIT(*event, mark, mark);

    return 1;
    fprintf(stderr, "[src/api.c] exit yaml_sequence_end_event_initialize 1\n");
}

/*
 * Create MAPPING-START.
 */

YAML_DECLARE(int)
yaml_mapping_start_event_initialize(yaml_event_t *event,
        const yaml_char_t *anchor, const yaml_char_t *tag, int implicit,
        yaml_mapping_style_t style)
{
    fprintf(stderr, "[src/api.c] enter yaml_mapping_start_event_initialize 1\n");
    yaml_mark_t mark = { 0, 0, 0 };
    yaml_char_t *anchor_copy = NULL;
    yaml_char_t *tag_copy = NULL;

    assert(event);      /* Non-NULL event object is expected. */
    fprintf(stderr, "[src/api.c] exit yaml_mapping_start_event_initialize 1\n");

    if (anchor) {
        fprintf(stderr, "[src/api.c] enter yaml_mapping_start_event_initialize 2\n");
        if (!yaml_check_utf8(anchor, strlen((char *)anchor))) goto error;
        anchor_copy = yaml_strdup(anchor);
        if (!anchor_copy) goto error;
        fprintf(stderr, "[src/api.c] exit yaml_mapping_start_event_initialize 2\n");
    }

    if (tag) {
        fprintf(stderr, "[src/api.c] enter yaml_mapping_start_event_initialize 3\n");
        if (!yaml_check_utf8(tag, strlen((char *)tag))) goto error;
        tag_copy = yaml_strdup(tag);
        if (!tag_copy) goto error;
        fprintf(stderr, "[src/api.c] exit yaml_mapping_start_event_initialize 3\n");
    }

    fprintf(stderr, "[src/api.c] enter yaml_mapping_start_event_initialize 4\n");
    MAPPING_START_EVENT_INIT(*event, anchor_copy, tag_copy,
            implicit, style, mark, mark);

    return 1;
    fprintf(stderr, "[src/api.c] exit yaml_mapping_start_event_initialize 4\n");

error:
    fprintf(stderr, "[src/api.c] enter yaml_mapping_start_event_initialize 5\n");
    yaml_free(anchor_copy);
    yaml_free(tag_copy);

    return 0;
    fprintf(stderr, "[src/api.c] exit yaml_mapping_start_event_initialize 5\n");
}

/*
 * Create MAPPING-END.
 */

YAML_DECLARE(int)
yaml_mapping_end_event_initialize(yaml_event_t *event)
{
    fprintf(stderr, "[src/api.c] enter yaml_mapping_end_event_initialize 1\n");
    yaml_mark_t mark = { 0, 0, 0 };

    assert(event);      /* Non-NULL event object is expected. */

    MAPPING_END_EVENT_INIT(*event, mark, mark);

    return 1;
    fprintf(stderr, "[src/api.c] exit yaml_mapping_end_event_initialize 1\n");
}

/*
 * Destroy an event object.
 */

YAML_DECLARE(void)
yaml_event_delete(yaml_event_t *event)
{
    fprintf(stderr, "[src/api.c] enter yaml_event_delete 1\n");
    yaml_tag_directive_t *tag_directive;

    assert(event);  /* Non-NULL event object expected. */
    fprintf(stderr, "[src/api.c] exit yaml_event_delete 1\n");

    switch (event->type)
    {
        case YAML_DOCUMENT_START_EVENT:
            fprintf(stderr, "[src/api.c] enter yaml_event_delete 2\n");
            yaml_free(event->data.document_start.version_directive);
            for (tag_directive = event->data.document_start.tag_directives.start;
                    tag_directive != event->data.document_start.tag_directives.end;
                    tag_directive++) {
                yaml_free(tag_directive->handle);
                yaml_free(tag_directive->prefix);
            }
            yaml_free(event->data.document_start.tag_directives.start);
            fprintf(stderr, "[src/api.c] exit yaml_event_delete 2\n");
            break;

        case YAML_ALIAS_EVENT:
            fprintf(stderr, "[src/api.c] enter yaml_event_delete 3\n");
            yaml_free(event->data.alias.anchor);
            fprintf(stderr, "[src/api.c] exit yaml_event_delete 3\n");
            break;

        case YAML_SCALAR_EVENT:
            fprintf(stderr, "[src/api.c] enter yaml_event_delete 4\n");
            yaml_free(event->data.scalar.anchor);
            yaml_free(event->data.scalar.tag);
            yaml_free(event->data.scalar.value);
            fprintf(stderr, "[src/api.c] exit yaml_event_delete 4\n");
            break;

        case YAML_SEQUENCE_START_EVENT:
            fprintf(stderr, "[src/api.c] enter yaml_event_delete 5\n");
            yaml_free(event->data.sequence_start.anchor);
            yaml_free(event->data.sequence_start.tag);
            fprintf(stderr, "[src/api.c] exit yaml_event_delete 5\n");
            break;

        case YAML_MAPPING_START_EVENT:
            fprintf(stderr, "[src/api.c] enter yaml_event_delete 6\n");
            yaml_free(event->data.mapping_start.anchor);
            yaml_free(event->data.mapping_start.tag);
            fprintf(stderr, "[src/api.c] exit yaml_event_delete 6\n");
            break;

        default:
            fprintf(stderr, "\n");
            fprintf(stderr, "\n");
            break;
    }

    fprintf(stderr, "[src/api.c] enter yaml_event_delete 8\n");
    memset(event, 0, sizeof(yaml_event_t));
    fprintf(stderr, "[src/api.c] exit yaml_event_delete 8\n");
}

/*
 * Create a document object.
 */

YAML_DECLARE(int)
yaml_document_initialize(yaml_document_t *document,
        yaml_version_directive_t *version_directive,
        yaml_tag_directive_t *tag_directives_start,
        yaml_tag_directive_t *tag_directives_end,
        int start_implicit, int end_implicit)
{
    fprintf(stderr, "[src/api.c] enter yaml_document_initialize 1\n");
    struct {
        yaml_error_type_t error;
    } context;
    struct {
        yaml_node_t *start;
        yaml_node_t *end;
        yaml_node_t *top;
    } nodes = { NULL, NULL, NULL };
    yaml_version_directive_t *version_directive_copy = NULL;
    struct {
        yaml_tag_directive_t *start;
        yaml_tag_directive_t *end;
        yaml_tag_directive_t *top;
    } tag_directives_copy = { NULL, NULL, NULL };
    yaml_tag_directive_t value = { NULL, NULL };
    yaml_mark_t mark = { 0, 0, 0 };

    assert(document);       /* Non-NULL document object is expected. */
    assert((tag_directives_start && tag_directives_end) ||
            (tag_directives_start == tag_directives_end));
                            /* Valid tag directives are expected. */
    fprintf(stderr, "[src/api.c] exit yaml_document_initialize 1\n");

    fprintf(stderr, "[src/api.c] enter yaml_document_initialize 2\n");
    if (!STACK_INIT(&context, nodes, yaml_node_t*)) goto error;
    fprintf(stderr, "[src/api.c] exit yaml_document_initialize 2\n");

    if (version_directive) {
        fprintf(stderr, "[src/api.c] enter yaml_document_initialize 3\n");
        version_directive_copy = YAML_MALLOC_STATIC(yaml_version_directive_t);
        if (!version_directive_copy) goto error;
        version_directive_copy->major = version_directive->major;
        version_directive_copy->minor = version_directive->minor;
        fprintf(stderr, "[src/api.c] exit yaml_document_initialize 3\n");
    }

    if (tag_directives_start != tag_directives_end) {
        fprintf(stderr, "[src/api.c] enter yaml_document_initialize 4\n");
        yaml_tag_directive_t *tag_directive;
        if (!STACK_INIT(&context, tag_directives_copy, yaml_tag_directive_t*))
            goto error;
        fprintf(stderr, "[src/api.c] exit yaml_document_initialize 4\n");
        
        for (tag_directive = tag_directives_start;
                tag_directive != tag_directives_end; tag_directive ++) {
            fprintf(stderr, "[src/api.c] enter yaml_document_initialize 5\n");
            assert(tag_directive->handle);
            assert(tag_directive->prefix);
            if (!yaml_check_utf8(tag_directive->handle,
                        strlen((char *)tag_directive->handle)))
                goto error;
            if (!yaml_check_utf8(tag_directive->prefix,
                        strlen((char *)tag_directive->prefix)))
                goto error;
            value.handle = yaml_strdup(tag_directive->handle);
            value.prefix = yaml_strdup(tag_directive->prefix);
            if (!value.handle || !value.prefix) goto error;
            if (!PUSH(&context, tag_directives_copy, value))
                goto error;
            value.handle = NULL;
            value.prefix = NULL;
            fprintf(stderr, "[src/api.c] exit yaml_document_initialize 5\n");
        }
    }

    fprintf(stderr, "[src/api.c] enter yaml_document_initialize 6\n");
    DOCUMENT_INIT(*document, nodes.start, nodes.end, version_directive_copy,
            tag_directives_copy.start, tag_directives_copy.top,
            start_implicit, end_implicit, mark, mark);

    return 1;
    fprintf(stderr, "[src/api.c] exit yaml_document_initialize 6\n");

error:
    fprintf(stderr, "[src/api.c] enter yaml_document_initialize 7\n");
    STACK_DEL(&context, nodes);
    yaml_free(version_directive_copy);
    while (!STACK_EMPTY(&context, tag_directives_copy)) {
        yaml_tag_directive_t value = POP(&context, tag_directives_copy);
        yaml_free(value.handle);
        yaml_free(value.prefix);
    }
    STACK_DEL(&context, tag_directives_copy);
    yaml_free(value.handle);
    yaml_free(value.prefix);

    return 0;
    fprintf(stderr, "[src/api.c] exit yaml_document_initialize 7\n");
}

/*
 * Destroy a document object.
 */

YAML_DECLARE(void)
yaml_document_delete(yaml_document_t *document)
{
    fprintf(stderr, "[src/api.c] enter yaml_document_delete 1\n");
    yaml_tag_directive_t *tag_directive;

    assert(document);   /* Non-NULL document object is expected. */
    fprintf(stderr, "[src/api.c] exit yaml_document_delete 1\n");

    fprintf(stderr, "[src/api.c] enter yaml_document_delete 2\n");
    while (!STACK_EMPTY(&context, document->nodes)) {
        yaml_node_t node = POP(&context, document->nodes);
        yaml_free(node.tag);
        switch (node.type) {
            case YAML_SCALAR_NODE:
                fprintf(stderr, "[src/api.c] enter yaml_document_delete 3\n");
                yaml_free(node.data.scalar.value);
                fprintf(stderr, "[src/api.c] exit yaml_document_delete 3\n");
                break;
            case YAML_SEQUENCE_NODE:
                fprintf(stderr, "[src/api.c] enter yaml_document_delete 4\n");
                STACK_DEL(&context, node.data.sequence.items);
                fprintf(stderr, "[src/api.c] exit yaml_document_delete 4\n");
                break;
            case YAML_MAPPING_NODE:
                fprintf(stderr, "[src/api.c] enter yaml_document_delete 5\n");
                STACK_DEL(&context, node.data.mapping.pairs);
                fprintf(stderr, "[src/api.c] exit yaml_document_delete 5\n");
                break;
            default:
                fprintf(stderr, "[src/api.c] enter yaml_document_delete 6\n");
                assert(0);  /* Should not happen. */
                fprintf(stderr, "[src/api.c] exit yaml_document_delete 6\n");
        }
    }
    STACK_DEL(&context, document->nodes);
    fprintf(stderr, "[src/api.c] exit yaml_document_delete 2\n");

    fprintf(stderr, "[src/api.c] enter yaml_document_delete 7\n");
    yaml_free(document->version_directive);
    for (tag_directive = document->tag_directives.start;
            tag_directive != document->tag_directives.end;
            tag_directive++) {
        yaml_free(tag_directive->handle);
        yaml_free(tag_directive->prefix);
    }
    yaml_free(document->tag_directives.start);
    fprintf(stderr, "[src/api.c] exit yaml_document_delete 7\n");

    fprintf(stderr, "[src/api.c] enter yaml_document_delete 8\n");
    memset(document, 0, sizeof(yaml_document_t));
    fprintf(stderr, "[src/api.c] exit yaml_document_delete 8\n");
}

/**
 * Get a document node.
 */

YAML_DECLARE(yaml_node_t *)
yaml_document_get_node(yaml_document_t *document, int index)
{
    fprintf(stderr, "[src/api.c] enter yaml_document_get_node 1\n");
    assert(document);   /* Non-NULL document object is expected. */
    fprintf(stderr, "[src/api.c] exit yaml_document_get_node 1\n");

    if (index > 0 && document->nodes.start + index <= document->nodes.top) {
        fprintf(stderr, "[src/api.c] enter yaml_document_get_node 2\n");
        return document->nodes.start + index - 1;
        fprintf(stderr, "[src/api.c] exit yaml_document_get_node 2\n");
    }
    fprintf(stderr, "[src/api.c] enter yaml_document_get_node 3\n");
    return NULL;
    fprintf(stderr, "[src/api.c] exit yaml_document_get_node 3\n");
}

/**
 * Get the root object.
 */

YAML_DECLARE(yaml_node_t *)
yaml_document_get_root_node(yaml_document_t *document)
{
    fprintf(stderr, "[src/api.c] enter yaml_document_get_root_node 1\n");
    assert(document);   /* Non-NULL document object is expected. */
    fprintf(stderr, "[src/api.c] exit yaml_document_get_root_node 1\n");

    if (document->nodes.top != document->nodes.start) {
        fprintf(stderr, "[src/api.c] enter yaml_document_get_root_node 2\n");
        return document->nodes.start;
        fprintf(stderr, "[src/api.c] exit yaml_document_get_root_node 2\n");
    }
    fprintf(stderr, "[src/api.c] enter yaml_document_get_root_node 3\n");
    return NULL;
    fprintf(stderr, "[src/api.c] exit yaml_document_get_root_node 3\n");
}

/*
 * Add a scalar node to a document.
 */

YAML_DECLARE(int)
yaml_document_add_scalar(yaml_document_t *document,
        const yaml_char_t *tag, const yaml_char_t *value, int length,
        yaml_scalar_style_t style)
{
    fprintf(stderr, "[src/api.c] enter yaml_document_add_scalar 1\n");
    struct {
        yaml_error_type_t error;
    } context;
    yaml_mark_t mark = { 0, 0, 0 };
    yaml_char_t *tag_copy = NULL;
    yaml_char_t *value_copy = NULL;
    yaml_node_t node;

    assert(document);   /* Non-NULL document object is expected. */
    assert(value);      /* Non-NULL value is expected. */
    fprintf(stderr, "[src/api.c] exit yaml_document_add_scalar 1\n");

    if (!tag) {
        fprintf(stderr, "[src/api.c] enter yaml_document_add_scalar 2\n");
        tag = (yaml_char_t *)YAML_DEFAULT_SCALAR_TAG;
        fprintf(stderr, "[src/api.c] exit yaml_document_add_scalar 2\n");
    }

    fprintf(stderr, "[src/api.c] enter yaml_document_add_scalar 3\n");
    if (!yaml_check_utf8(tag, strlen((char *)tag))) goto error;
    tag_copy = yaml_strdup(tag);
    if (!tag_copy) goto error;
    fprintf(stderr, "[src/api.c] exit yaml_document_add_scalar 3\n");

    if (length < 0) {
        fprintf(stderr, "[src/api.c] enter yaml_document_add_scalar 4\n");
        length = strlen((char *)value);
        fprintf(stderr, "[src/api.c] exit yaml_document_add_scalar 4\n");
    }

    fprintf(stderr, "[src/api.c] enter yaml_document_add_scalar 5\n");
    if (!yaml_check_utf8(value, length)) goto error;
    value_copy = YAML_MALLOC(length+1);
    if (!value_copy) goto error;
    memcpy(value_copy, value, length);
    value_copy[length] = '\0';
    fprintf(stderr, "[src/api.c] exit yaml_document_add_scalar 5\n");

    fprintf(stderr, "[src/api.c] enter yaml_document_add_scalar 6\n");
    SCALAR_NODE_INIT(node, tag_copy, value_copy, length, style, mark, mark);
    if (!PUSH(&context, document->nodes, node)) goto error;
    fprintf(stderr, "[src/api.c] exit yaml_document_add_scalar 6\n");

    fprintf(stderr, "[src/api.c] enter yaml_document_add_scalar 7\n");
    return document->nodes.top - document->nodes.start;
    fprintf(stderr, "[src/api.c] exit yaml_document_add_scalar 7\n");

error:
    fprintf(stderr, "[src/api.c] enter yaml_document_add_scalar 8\n");
    yaml_free(tag_copy);
    yaml_free(value_copy);

    return 0;
    fprintf(stderr, "[src/api.c] exit yaml_document_add_scalar 8\n");
}

/*
 * Add a sequence node to a document.
 */

YAML_DECLARE(int)
yaml_document_add_sequence(yaml_document_t *document,
        const yaml_char_t *tag, yaml_sequence_style_t style)
{
    fprintf(stderr, "[src/api.c] enter yaml_document_add_sequence 1\n");
    struct {
        yaml_error_type_t error;
    } context;
    yaml_mark_t mark = { 0, 0, 0 };
    yaml_char_t *tag_copy = NULL;
    struct {
        yaml_node_item_t *start;
        yaml_node_item_t *end;
        yaml_node_item_t *top;
    } items = { NULL, NULL, NULL };
    yaml_node_t node;

    assert(document);   /* Non-NULL document object is expected. */
    fprintf(stderr, "[src/api.c] exit yaml_document_add_sequence 1\n");

    if (!tag) {
        fprintf(stderr, "[src/api.c] enter yaml_document_add_sequence 2\n");
        tag = (yaml_char_t *)YAML_DEFAULT_SEQUENCE_TAG;
        fprintf(stderr, "[src/api.c] exit yaml_document_add_sequence 2\n");
    }

    fprintf(stderr, "[src/api.c] enter yaml_document_add_sequence 3\n");
    if (!yaml_check_utf8(tag, strlen((char *)tag))) goto error;
    tag_copy = yaml_strdup(tag);
    if (!tag_copy) goto error;
    fprintf(stderr, "[src/api.c] exit yaml_document_add_sequence 3\n");

    fprintf(stderr, "[src/api.c] enter yaml_document_add_sequence 4\n");
    if (!STACK_INIT(&context, items, yaml_node_item_t*)) goto error;
    fprintf(stderr, "[src/api.c] exit yaml_document_add_sequence 4\n");

    fprintf(stderr, "[src/api.c] enter yaml_document_add_sequence 5\n");
    SEQUENCE_NODE_INIT(node, tag_copy, items.start, items.end,
            style, mark, mark);
    if (!PUSH(&context, document->nodes, node)) goto error;
    fprintf(stderr, "[src/api.c] exit yaml_document_add_sequence 5\n");

    fprintf(stderr, "[src/api.c] enter yaml_document_add_sequence 6\n");
    return document->nodes.top - document->nodes.start;
    fprintf(stderr, "[src/api.c] exit yaml_document_add_sequence 6\n");

error:
    fprintf(stderr, "[src/api.c] enter yaml_document_add_sequence 7\n");
    STACK_DEL(&context, items);
    yaml_free(tag_copy);

    return 0;
    fprintf(stderr, "[src/api.c] exit yaml_document_add_sequence 7\n");
}

/*
 * Add a mapping node to a document.
 */

YAML_DECLARE(int)
yaml_document_add_mapping(yaml_document_t *document,
        const yaml_char_t *tag, yaml_mapping_style_t style)
{
    fprintf(stderr, "[src/api.c] enter yaml_document_add_mapping 1\n");
    struct {
        yaml_error_type_t error;
    } context;
    yaml_mark_t mark = { 0, 0, 0 };
    yaml_char_t *tag_copy = NULL;
    struct {
        yaml_node_pair_t *start;
        yaml_node_pair_t *end;
        yaml_node_pair_t *top;
    } pairs = { NULL, NULL, NULL };
    yaml_node_t node;

    assert(document);   /* Non-NULL document object is expected. */
    fprintf(stderr, "[src/api.c] exit yaml_document_add_mapping 1\n");

    if (!tag) {
        fprintf(stderr, "[src/api.c] enter yaml_document_add_mapping 2\n");
        tag = (yaml_char_t *)YAML_DEFAULT_MAPPING_TAG;
        fprintf(stderr, "[src/api.c] exit yaml_document_add_mapping 2\n");
    }

    fprintf(stderr, "[src/api.c] enter yaml_document_add_mapping 3\n");
    if (!yaml_check_utf8(tag, strlen((char *)tag))) goto error;
    tag_copy = yaml_strdup(tag);
    if (!tag_copy) goto error;
    fprintf(stderr, "[src/api.c] exit yaml_document_add_mapping 3\n");

    fprintf(stderr, "[src/api.c] enter yaml_document_add_mapping 4\n");
    if (!STACK_INIT(&context, pairs, yaml_node_pair_t*)) goto error;
    fprintf(stderr, "[src/api.c] exit yaml_document_add_mapping 4\n");

    fprintf(stderr, "[src/api.c] enter yaml_document_add_mapping 5\n");
    MAPPING_NODE_INIT(node, tag_copy, pairs.start, pairs.end,
            style, mark, mark);
    if (!PUSH(&context, document->nodes, node)) goto error;
    fprintf(stderr, "[src/api.c] exit yaml_document_add_mapping 5\n");

    fprintf(stderr, "[src/api.c] enter yaml_document_add_mapping 6\n");
    return document->nodes.top - document->nodes.start;
    fprintf(stderr, "[src/api.c] exit yaml_document_add_mapping 6\n");

error:
    fprintf(stderr, "[src/api.c] enter yaml_document_add_mapping 7\n");
    STACK_DEL(&context, pairs);
    yaml_free(tag_copy);

    return 0;
    fprintf(stderr, "[src/api.c] exit yaml_document_add_mapping 7\n");
}

/*
 * Append an item to a sequence node.
 */

YAML_DECLARE(int)
yaml_document_append_sequence_item(yaml_document_t *document,
        int sequence, int item)
{
    fprintf(stderr, "[src/api.c] enter yaml_document_append_sequence_item 1\n");
    struct {
        yaml_error_type_t error;
    } context;

    assert(document);       /* Non-NULL document is required. */
    assert(sequence > 0
            && document->nodes.start + sequence <= document->nodes.top);
                            /* Valid sequence id is required. */
    assert(document->nodes.start[sequence-1].type == YAML_SEQUENCE_NODE);
                            /* A sequence node is required. */
    assert(item > 0 && document->nodes.start + item <= document->nodes.top);
                            /* Valid item id is required. */
    fprintf(stderr, "[src/api.c] exit yaml_document_append_sequence_item 1\n");

    fprintf(stderr, "[src/api.c] enter yaml_document_append_sequence_item 2\n");
    if (!PUSH(&context,
                document->nodes.start[sequence-1].data.sequence.items, item))
        return 0;
    fprintf(stderr, "[src/api.c] exit yaml_document_append_sequence_item 2\n");

    fprintf(stderr, "[src/api.c] enter yaml_document_append_sequence_item 3\n");
    return 1;
    fprintf(stderr, "[src/api.c] exit yaml_document_append_sequence_item 3\n");
}

/*
 * Append a pair of a key and a value to a mapping node.
 */

YAML_DECLARE(int)
yaml_document_append_mapping_pair(yaml_document_t *document,
        int mapping, int key, int value)
{
    fprintf(stderr, "[src/api.c] enter yaml_document_append_mapping_pair 1\n");
    struct {
        yaml_error_type_t error;
    } context;

    yaml_node_pair_t pair;

    assert(document);       /* Non-NULL document is required. */
    assert(mapping > 0
            && document->nodes.start + mapping <= document->nodes.top);
                            /* Valid mapping id is required. */
    assert(document->nodes.start[mapping-1].type == YAML_MAPPING_NODE);
                            /* A mapping node is required. */
    assert(key > 0 && document->nodes.start + key <= document->nodes.top);
                            /* Valid key id is required. */
    assert(value > 0 && document->nodes.start + value <= document->nodes.top);
                            /* Valid value id is required. */
    fprintf(stderr, "[src/api.c] exit yaml_document_append_mapping_pair 1\n");

    fprintf(stderr, "[src/api.c] enter yaml_document_append_mapping_pair 2\n");
    pair.key = key;
    pair.value = value;
    fprintf(stderr, "[src/api.c] exit yaml_document_append_mapping_pair 2\n");

    fprintf(stderr, "[src/api.c] enter yaml_document_append_mapping_pair 3\n");
    if (!PUSH(&context,
                document->nodes.start[mapping-1].data.mapping.pairs, pair))
        return 0;
    fprintf(stderr, "[src/api.c] exit yaml_document_append_mapping_pair 3\n");

    fprintf(stderr, "[src/api.c] enter yaml_document_append_mapping_pair 4\n");
    return 1;
    fprintf(stderr, "[src/api.c] exit yaml_document_append_mapping_pair 4\n");
}
// Total cost: 0.510207
// Total split cost: 0.151017, input tokens: 29153, output tokens: 1612, cache read tokens: 2696, cache write tokens: 12442, split chunks: [(0, 795), (795, 1393)]
// Total instrumented cost: 0.359189, input tokens: 16898, output tokens: 18281, cache read tokens: 4505, cache write tokens: 12385


#include "yaml_private.h"

/*
 * API functions.
 */

YAML_DECLARE(int)
yaml_emitter_open(yaml_emitter_t *emitter);

YAML_DECLARE(int)
yaml_emitter_close(yaml_emitter_t *emitter);

YAML_DECLARE(int)
yaml_emitter_dump(yaml_emitter_t *emitter, yaml_document_t *document);

/*
 * Clean up functions.
 */

static void
yaml_emitter_delete_document_and_anchors(yaml_emitter_t *emitter);

/*
 * Anchor functions.
 */

static void
yaml_emitter_anchor_node(yaml_emitter_t *emitter, int index);

static yaml_char_t *
yaml_emitter_generate_anchor(yaml_emitter_t *emitter, int anchor_id);


/*
 * Serialize functions.
 */

static int
yaml_emitter_dump_node(yaml_emitter_t *emitter, int index);

static int
yaml_emitter_dump_alias(yaml_emitter_t *emitter, yaml_char_t *anchor);

static int
yaml_emitter_dump_scalar(yaml_emitter_t *emitter, yaml_node_t *node,
        yaml_char_t *anchor);

static int
yaml_emitter_dump_sequence(yaml_emitter_t *emitter, yaml_node_t *node,
        yaml_char_t *anchor);

static int
yaml_emitter_dump_mapping(yaml_emitter_t *emitter, yaml_node_t *node,
        yaml_char_t *anchor);

/*
 * Issue a STREAM-START event.
 */

YAML_DECLARE(int)
yaml_emitter_open(yaml_emitter_t *emitter)
{
    fprintf(stderr, "[src/dumper.c] enter yaml_emitter_open 1\n");
    yaml_event_t event;
    yaml_mark_t mark = { 0, 0, 0 };

    assert(emitter);            /* Non-NULL emitter object is required. */
    assert(!emitter->opened);   /* Emitter should not be opened yet. */

    STREAM_START_EVENT_INIT(event, YAML_ANY_ENCODING, mark, mark);

    if (!yaml_emitter_emit(emitter, &event)) {
        fprintf(stderr, "[src/dumper.c] enter yaml_emitter_open 2\n");
        return 0;
        fprintf(stderr, "[src/dumper.c] exit yaml_emitter_open 2\n");
    }

    emitter->opened = 1;

    return 1;
    fprintf(stderr, "[src/dumper.c] exit yaml_emitter_open 1\n");
}

/*
 * Issue a STREAM-END event.
 */

YAML_DECLARE(int)
yaml_emitter_close(yaml_emitter_t *emitter)
{
    fprintf(stderr, "[src/dumper.c] enter yaml_emitter_close 1\n");
    yaml_event_t event;
    yaml_mark_t mark = { 0, 0, 0 };

    assert(emitter);            /* Non-NULL emitter object is required. */
    assert(emitter->opened);    /* Emitter should be opened. */

    if (emitter->closed) {
        fprintf(stderr, "[src/dumper.c] enter yaml_emitter_close 2\n");
        return 1;
        fprintf(stderr, "[src/dumper.c] exit yaml_emitter_close 2\n");
    }

    STREAM_END_EVENT_INIT(event, mark, mark);

    if (!yaml_emitter_emit(emitter, &event)) {
        fprintf(stderr, "[src/dumper.c] enter yaml_emitter_close 3\n");
        return 0;
        fprintf(stderr, "[src/dumper.c] exit yaml_emitter_close 3\n");
    }

    emitter->closed = 1;

    return 1;
    fprintf(stderr, "[src/dumper.c] exit yaml_emitter_close 1\n");
}

/*
 * Dump a YAML document.
 */

YAML_DECLARE(int)
yaml_emitter_dump(yaml_emitter_t *emitter, yaml_document_t *document)
{
    fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump 1\n");
    yaml_event_t event;
    yaml_mark_t mark = { 0, 0, 0 };

    assert(emitter);            /* Non-NULL emitter object is required. */
    assert(document);           /* Non-NULL emitter object is expected. */

    emitter->document = document;

    if (!emitter->opened) {
        fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump 2\n");
        if (!yaml_emitter_open(emitter)) goto error;
        fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump 2\n");
    }

    if (STACK_EMPTY(emitter, document->nodes)) {
        fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump 3\n");
        if (!yaml_emitter_close(emitter)) goto error;
        yaml_emitter_delete_document_and_anchors(emitter);
        return 1;
        fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump 3\n");
    }

    assert(emitter->opened);    /* Emitter should be opened. */

    emitter->anchors = (yaml_anchors_t*)yaml_malloc(sizeof(*(emitter->anchors))
            * (document->nodes.top - document->nodes.start));
    if (!emitter->anchors) {
        fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump 4\n");
        goto error;
        fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump 4\n");
    }
    memset(emitter->anchors, 0, sizeof(*(emitter->anchors))
            * (document->nodes.top - document->nodes.start));

    DOCUMENT_START_EVENT_INIT(event, document->version_directive,
            document->tag_directives.start, document->tag_directives.end,
            document->start_implicit, mark, mark);
    if (!yaml_emitter_emit(emitter, &event)) {
        fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump 5\n");
        goto error;
        fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump 5\n");
    }

    yaml_emitter_anchor_node(emitter, 1);
    if (!yaml_emitter_dump_node(emitter, 1)) {
        fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump 6\n");
        goto error;
        fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump 6\n");
    }

    DOCUMENT_END_EVENT_INIT(event, document->end_implicit, mark, mark);
    if (!yaml_emitter_emit(emitter, &event)) {
        fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump 7\n");
        goto error;
        fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump 7\n");
    }

    yaml_emitter_delete_document_and_anchors(emitter);

    return 1;
    fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump 1\n");

error:
    fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump 8\n");
    yaml_emitter_delete_document_and_anchors(emitter);

    return 0;
    fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump 8\n");
}

/*
 * Clean up the emitter object after a document is dumped.
 */

static void
yaml_emitter_delete_document_and_anchors(yaml_emitter_t *emitter)
{
    fprintf(stderr, "[src/dumper.c] enter yaml_emitter_delete_document_and_anchors 1\n");
    int index;

    if (!emitter->anchors) {
        fprintf(stderr, "[src/dumper.c] enter yaml_emitter_delete_document_and_anchors 2\n");
        yaml_document_delete(emitter->document);
        emitter->document = NULL;
        return;
        fprintf(stderr, "[src/dumper.c] exit yaml_emitter_delete_document_and_anchors 2\n");
    }

    for (index = 0; emitter->document->nodes.start + index
            < emitter->document->nodes.top; index ++) {
        fprintf(stderr, "[src/dumper.c] enter yaml_emitter_delete_document_and_anchors 3\n");
        yaml_node_t node = emitter->document->nodes.start[index];
        if (!emitter->anchors[index].serialized) {
            fprintf(stderr, "[src/dumper.c] enter yaml_emitter_delete_document_and_anchors 4\n");
            yaml_free(node.tag);
            if (node.type == YAML_SCALAR_NODE) {
                fprintf(stderr, "[src/dumper.c] enter yaml_emitter_delete_document_and_anchors 5\n");
                yaml_free(node.data.scalar.value);
                fprintf(stderr, "[src/dumper.c] exit yaml_emitter_delete_document_and_anchors 5\n");
            }
            fprintf(stderr, "[src/dumper.c] exit yaml_emitter_delete_document_and_anchors 4\n");
        }
        if (node.type == YAML_SEQUENCE_NODE) {
            fprintf(stderr, "[src/dumper.c] enter yaml_emitter_delete_document_and_anchors 6\n");
            STACK_DEL(emitter, node.data.sequence.items);
            fprintf(stderr, "[src/dumper.c] exit yaml_emitter_delete_document_and_anchors 6\n");
        }
        if (node.type == YAML_MAPPING_NODE) {
            fprintf(stderr, "[src/dumper.c] enter yaml_emitter_delete_document_and_anchors 7\n");
            STACK_DEL(emitter, node.data.mapping.pairs);
            fprintf(stderr, "[src/dumper.c] exit yaml_emitter_delete_document_and_anchors 7\n");
        }
        fprintf(stderr, "[src/dumper.c] exit yaml_emitter_delete_document_and_anchors 3\n");
    }

    STACK_DEL(emitter, emitter->document->nodes);
    yaml_free(emitter->anchors);

    emitter->anchors = NULL;
    emitter->last_anchor_id = 0;
    emitter->document = NULL;
    fprintf(stderr, "[src/dumper.c] exit yaml_emitter_delete_document_and_anchors 1\n");
}

/*
 * Check the references of a node and assign the anchor id if needed.
 */

static void
yaml_emitter_anchor_node(yaml_emitter_t *emitter, int index)
{
    fprintf(stderr, "[src/dumper.c] enter yaml_emitter_anchor_node 1\n");
    yaml_node_t *node = emitter->document->nodes.start + index - 1;
    yaml_node_item_t *item;
    yaml_node_pair_t *pair;

    emitter->anchors[index-1].references ++;

    if (emitter->anchors[index-1].references == 1) {
        fprintf(stderr, "[src/dumper.c] enter yaml_emitter_anchor_node 2\n");
        switch (node->type) {
            case YAML_SEQUENCE_NODE:
                fprintf(stderr, "[src/dumper.c] enter yaml_emitter_anchor_node 3\n");
                for (item = node->data.sequence.items.start;
                        item < node->data.sequence.items.top; item ++) {
                    fprintf(stderr, "[src/dumper.c] enter yaml_emitter_anchor_node 4\n");
                    yaml_emitter_anchor_node(emitter, *item);
                    fprintf(stderr, "[src/dumper.c] exit yaml_emitter_anchor_node 4\n");
                }
                fprintf(stderr, "[src/dumper.c] exit yaml_emitter_anchor_node 3\n");
                break;
            case YAML_MAPPING_NODE:
                fprintf(stderr, "[src/dumper.c] enter yaml_emitter_anchor_node 5\n");
                for (pair = node->data.mapping.pairs.start;
                        pair < node->data.mapping.pairs.top; pair ++) {
                    fprintf(stderr, "[src/dumper.c] enter yaml_emitter_anchor_node 6\n");
                    yaml_emitter_anchor_node(emitter, pair->key);
                    yaml_emitter_anchor_node(emitter, pair->value);
                    fprintf(stderr, "[src/dumper.c] exit yaml_emitter_anchor_node 6\n");
                }
                fprintf(stderr, "[src/dumper.c] exit yaml_emitter_anchor_node 5\n");
                break;
            default:
                fprintf(stderr, "\n");
                fprintf(stderr, "\n");
                break;
        }
        fprintf(stderr, "[src/dumper.c] exit yaml_emitter_anchor_node 2\n");
    }

    else if (emitter->anchors[index-1].references == 2) {
        fprintf(stderr, "[src/dumper.c] enter yaml_emitter_anchor_node 8\n");
        emitter->anchors[index-1].anchor = (++ emitter->last_anchor_id);
        fprintf(stderr, "[src/dumper.c] exit yaml_emitter_anchor_node 8\n");
    }
    fprintf(stderr, "[src/dumper.c] exit yaml_emitter_anchor_node 1\n");
}

/*
 * Generate a textual representation for an anchor.
 */

#define ANCHOR_TEMPLATE         "id%03d"
#define ANCHOR_TEMPLATE_LENGTH  16

static yaml_char_t *
yaml_emitter_generate_anchor(SHIM(yaml_emitter_t *emitter), int anchor_id)
{
    fprintf(stderr, "[src/dumper.c] enter yaml_emitter_generate_anchor 1\n");
    yaml_char_t *anchor = YAML_MALLOC(ANCHOR_TEMPLATE_LENGTH);

    if (!anchor) {
        fprintf(stderr, "[src/dumper.c] enter yaml_emitter_generate_anchor 2\n");
        return NULL;
        fprintf(stderr, "[src/dumper.c] exit yaml_emitter_generate_anchor 2\n");
    }

    sprintf((char *)anchor, ANCHOR_TEMPLATE, anchor_id);

    return anchor;
    fprintf(stderr, "[src/dumper.c] exit yaml_emitter_generate_anchor 1\n");
}

/*
 * Serialize a node.
 */

static int
yaml_emitter_dump_node(yaml_emitter_t *emitter, int index)
{
    fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump_node 1\n");
    yaml_node_t *node = emitter->document->nodes.start + index - 1;
    int anchor_id = emitter->anchors[index-1].anchor;
    yaml_char_t *anchor = NULL;

    if (anchor_id) {
        fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump_node 2\n");
        anchor = yaml_emitter_generate_anchor(emitter, anchor_id);
        if (!anchor) {
            fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump_node 3\n");
            return 0;
            fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump_node 3\n");
        }
        fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump_node 2\n");
    }

    if (emitter->anchors[index-1].serialized) {
        fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump_node 4\n");
        return yaml_emitter_dump_alias(emitter, anchor);
        fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump_node 4\n");
    }

    emitter->anchors[index-1].serialized = 1;

    switch (node->type) {
        case YAML_SCALAR_NODE:
            fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump_node 5\n");
            return yaml_emitter_dump_scalar(emitter, node, anchor);
            fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump_node 5\n");
        case YAML_SEQUENCE_NODE:
            fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump_node 6\n");
            return yaml_emitter_dump_sequence(emitter, node, anchor);
            fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump_node 6\n");
        case YAML_MAPPING_NODE:
            fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump_node 7\n");
            return yaml_emitter_dump_mapping(emitter, node, anchor);
            fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump_node 7\n");
        default:
            fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump_node 8\n");
            assert(0);      /* Could not happen. */
            fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump_node 8\n");
            break;
    }

    return 0;       /* Could not happen. */
    fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump_node 1\n");
}

/*
 * Serialize an alias.
 */

static int
yaml_emitter_dump_alias(yaml_emitter_t *emitter, yaml_char_t *anchor)
{
    fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump_alias 1\n");
    yaml_event_t event;
    yaml_mark_t mark  = { 0, 0, 0 };

    ALIAS_EVENT_INIT(event, anchor, mark, mark);

    return yaml_emitter_emit(emitter, &event);
    fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump_alias 1\n");
}

/*
 * Serialize a scalar.
 */

static int
yaml_emitter_dump_scalar(yaml_emitter_t *emitter, yaml_node_t *node,
        yaml_char_t *anchor)
{
    fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump_scalar 1\n");
    yaml_event_t event;
    yaml_mark_t mark  = { 0, 0, 0 };

    int plain_implicit = (strcmp((char *)node->tag,
                YAML_DEFAULT_SCALAR_TAG) == 0);
    int quoted_implicit = (strcmp((char *)node->tag,
                YAML_DEFAULT_SCALAR_TAG) == 0);

    SCALAR_EVENT_INIT(event, anchor, node->tag, node->data.scalar.value,
            node->data.scalar.length, plain_implicit, quoted_implicit,
            node->data.scalar.style, mark, mark);

    return yaml_emitter_emit(emitter, &event);
    fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump_scalar 1\n");
}

/*
 * Serialize a sequence.
 */

static int
yaml_emitter_dump_sequence(yaml_emitter_t *emitter, yaml_node_t *node,
        yaml_char_t *anchor)
{
    fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump_sequence 1\n");
    yaml_event_t event;
    yaml_mark_t mark  = { 0, 0, 0 };

    int implicit = (strcmp((char *)node->tag, YAML_DEFAULT_SEQUENCE_TAG) == 0);

    yaml_node_item_t *item;

    SEQUENCE_START_EVENT_INIT(event, anchor, node->tag, implicit,
            node->data.sequence.style, mark, mark);
    if (!yaml_emitter_emit(emitter, &event)) {
        fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump_sequence 2\n");
        return 0;
        fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump_sequence 2\n");
    }

    for (item = node->data.sequence.items.start;
            item < node->data.sequence.items.top; item ++) {
        fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump_sequence 3\n");
        if (!yaml_emitter_dump_node(emitter, *item)) {
            fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump_sequence 4\n");
            return 0;
            fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump_sequence 4\n");
        }
        fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump_sequence 3\n");
    }

    SEQUENCE_END_EVENT_INIT(event, mark, mark);
    if (!yaml_emitter_emit(emitter, &event)) {
        fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump_sequence 5\n");
        return 0;
        fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump_sequence 5\n");
    }

    return 1;
    fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump_sequence 1\n");
}

/*
 * Serialize a mapping.
 */

static int
yaml_emitter_dump_mapping(yaml_emitter_t *emitter, yaml_node_t *node,
        yaml_char_t *anchor)
{
    fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump_mapping 1\n");
    yaml_event_t event;
    yaml_mark_t mark  = { 0, 0, 0 };

    int implicit = (strcmp((char *)node->tag, YAML_DEFAULT_MAPPING_TAG) == 0);

    yaml_node_pair_t *pair;

    MAPPING_START_EVENT_INIT(event, anchor, node->tag, implicit,
            node->data.mapping.style, mark, mark);
    if (!yaml_emitter_emit(emitter, &event)) {
        fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump_mapping 2\n");
        return 0;
        fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump_mapping 2\n");
    }

    for (pair = node->data.mapping.pairs.start;
            pair < node->data.mapping.pairs.top; pair ++) {
        fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump_mapping 3\n");
        if (!yaml_emitter_dump_node(emitter, pair->key)) {
            fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump_mapping 4\n");
            return 0;
            fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump_mapping 4\n");
        }
        if (!yaml_emitter_dump_node(emitter, pair->value)) {
            fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump_mapping 5\n");
            return 0;
            fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump_mapping 5\n");
        }
        fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump_mapping 3\n");
    }

    MAPPING_END_EVENT_INIT(event, mark, mark);
    if (!yaml_emitter_emit(emitter, &event)) {
        fprintf(stderr, "[src/dumper.c] enter yaml_emitter_dump_mapping 6\n");
        return 0;
        fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump_mapping 6\n");
    }

    return 1;
    fprintf(stderr, "[src/dumper.c] exit yaml_emitter_dump_mapping 1\n");
}
// Total cost: 0.110807
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 394)]
// Total instrumented cost: 0.110807, input tokens: 5810, output tokens: 5754, cache read tokens: 2280, cache write tokens: 3526

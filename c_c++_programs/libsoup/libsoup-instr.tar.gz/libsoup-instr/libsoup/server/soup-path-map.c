/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * soup-path-map.c: URI path prefix-matcher
 *
 * Copyright (C) 2007 Novell, Inc.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <string.h>

#include "soup-path-map.h"

/* This could be replaced with something more clever, like a Patricia
 * trie, but it's probably not worth it since the total number of
 * mappings is likely to always be small. So we keep an array of
 * paths, sorted by decreasing length. (The first prefix match will
 * therefore be the longest.)
 */

typedef struct {
	char     *path;
	int       len;
	gpointer  data;
} SoupPathMapping;

struct SoupPathMap {
	GArray *mappings;
	GDestroyNotify free_func;
};

/**
 * soup_path_map_new:
 * @data_free_func: function to use to free data added with
 *   soup_path_map_add().
 *
 * Creates a new %SoupPathMap.
 *
 * Returns: the new %SoupPathMap
 **/
SoupPathMap *
soup_path_map_new (GDestroyNotify data_free_func)
{
	fprintf(stderr, "[libsoup/server/soup-path-map.c] enter soup_path_map_new 1\n");
	SoupPathMap *map;

	map = g_slice_new0 (SoupPathMap);
	map->mappings = g_array_new (FALSE, FALSE, sizeof (SoupPathMapping));
	map->free_func = data_free_func;

	return map;
	// fprintf(stderr, "[libsoup/server/soup-path-map.c] exit soup_path_map_new 1\n");
}

/**
 * soup_path_map_free:
 * @map: a %SoupPathMap
 *
 * Frees @map and all data stored in it.
 **/
void
soup_path_map_free (SoupPathMap *map)
{
	fprintf(stderr, "[libsoup/server/soup-path-map.c] enter soup_path_map_free 1\n");
	SoupPathMapping *mappings = (SoupPathMapping *)map->mappings->data;
	guint i;

	for (i = 0; i < map->mappings->len; i++) {
		fprintf(stderr, "[libsoup/server/soup-path-map.c] enter soup_path_map_free 2\n");
		g_free (mappings[i].path);
		if (map->free_func)
			map->free_func (mappings[i].data);
		// fprintf(stderr, "[libsoup/server/soup-path-map.c] exit soup_path_map_free 2\n");
	}
	g_array_free (map->mappings, TRUE);
	
	g_slice_free (SoupPathMap, map);
	// fprintf(stderr, "[libsoup/server/soup-path-map.c] exit soup_path_map_free 1\n");
}

/* Scan @map looking for @path or one of its ancestors.
 * Sets *@match to the index of a match, or -1 if no match is found.
 * Sets *@insert to the index to insert @path at if a new mapping is
 * desired. Returns %TRUE if *@match is an exact match.
 */
static gboolean
mapping_lookup (SoupPathMap *map, const char *path, int *match, int *insert)
{
	fprintf(stderr, "[libsoup/server/soup-path-map.c] enter mapping_lookup 1\n");
	SoupPathMapping *mappings = (SoupPathMapping *)map->mappings->data;
	guint i;
	int path_len;
	gboolean exact = FALSE;

	*match = -1;

	path_len = strcspn (path, "?");
	for (i = 0; i < map->mappings->len; i++) {
		fprintf(stderr, "[libsoup/server/soup-path-map.c] enter mapping_lookup 2\n");
		if (mappings[i].len > path_len)
			continue;

		if (insert && mappings[i].len < path_len) {
			fprintf(stderr, "[libsoup/server/soup-path-map.c] enter mapping_lookup 3\n");
			*insert = i;
			/* Clear insert so we don't try to set it again */
			insert = NULL;
			// fprintf(stderr, "[libsoup/server/soup-path-map.c] exit mapping_lookup 3\n");
		}

		if (!strncmp (mappings[i].path, path, mappings[i].len)) {
			fprintf(stderr, "[libsoup/server/soup-path-map.c] enter mapping_lookup 4\n");
			*match = i;
			if (path_len == mappings[i].len)
				exact = TRUE;
			if (!insert)
				return exact;
			// fprintf(stderr, "[libsoup/server/soup-path-map.c] exit mapping_lookup 4\n");
		}
		// fprintf(stderr, "[libsoup/server/soup-path-map.c] exit mapping_lookup 2\n");
	}

	if (insert) {
		fprintf(stderr, "[libsoup/server/soup-path-map.c] enter mapping_lookup 5\n");
		*insert = i;
		// fprintf(stderr, "[libsoup/server/soup-path-map.c] exit mapping_lookup 5\n");
	}
	return exact;
	// fprintf(stderr, "[libsoup/server/soup-path-map.c] exit mapping_lookup 1\n");
}	

/**
 * soup_path_map_add:
 * @map: a %SoupPathMap
 * @path: the path
 * @data: the data
 *
 * Adds @data to @map at @path. If there was already data at @path it
 * will be freed.
 **/
void
soup_path_map_add (SoupPathMap *map, const char *path, gpointer data)
{
	fprintf(stderr, "[libsoup/server/soup-path-map.c] enter soup_path_map_add 1\n");
	SoupPathMapping *mappings = (SoupPathMapping *)map->mappings->data;
	int match, insert;

	if (mapping_lookup (map, path, &match, &insert)) {
		fprintf(stderr, "[libsoup/server/soup-path-map.c] enter soup_path_map_add 2\n");
		if (map->free_func)
			map->free_func (mappings[match].data);
		mappings[match].data = data;
		// fprintf(stderr, "[libsoup/server/soup-path-map.c] exit soup_path_map_add 2\n");
	} else {
		fprintf(stderr, "[libsoup/server/soup-path-map.c] enter soup_path_map_add 3\n");
		SoupPathMapping mapping;

		mapping.path = g_strdup (path);
		mapping.len = strlen (path);
		mapping.data = data;
		g_array_insert_val (map->mappings, insert, mapping);
		// fprintf(stderr, "[libsoup/server/soup-path-map.c] exit soup_path_map_add 3\n");
	}
	// fprintf(stderr, "[libsoup/server/soup-path-map.c] exit soup_path_map_add 1\n");
}

/**
 * soup_path_map_remove:
 * @map: a %SoupPathMap
 * @path: the path
 *
 * Removes @data from @map at @path. (This must be called with the same
 * path the data was originally added with, not a subdirectory.)
 **/
void
soup_path_map_remove (SoupPathMap *map, const char *path)
{
	fprintf(stderr, "[libsoup/server/soup-path-map.c] enter soup_path_map_remove 1\n");
	SoupPathMapping *mappings = (SoupPathMapping *)map->mappings->data;
	int match;

	if (!mapping_lookup (map, path, &match, NULL))
		return;

	if (map->free_func)
		map->free_func (mappings[match].data);
	g_free (mappings[match].path);
	g_array_remove_index (map->mappings, match);
	// fprintf(stderr, "[libsoup/server/soup-path-map.c] exit soup_path_map_remove 1\n");
}

/**
 * soup_path_map_lookup:
 * @map: a %SoupPathMap
 * @path: the path
 *
 * Finds the data associated with @path in @map. If there is no data
 * specifically associated with @path, it will return the data for the
 * closest parent directory of @path that has data associated with it.
 *
 * Returns: (nullable): the data set with soup_path_map_add(), or
 *   %NULL if no data could be found for @path or any of its ancestors.
 **/
gpointer
soup_path_map_lookup (SoupPathMap *map, const char *path)
{
	fprintf(stderr, "[libsoup/server/soup-path-map.c] enter soup_path_map_lookup 1\n");
	SoupPathMapping *mappings = (SoupPathMapping *)map->mappings->data;
	int match;

	mapping_lookup (map, path, &match, NULL);
	if (match == -1) {
		fprintf(stderr, "[libsoup/server/soup-path-map.c] enter soup_path_map_lookup 2\n");
		return NULL;
		// fprintf(stderr, "[libsoup/server/soup-path-map.c] exit soup_path_map_lookup 2\n");
	}
	else {
		fprintf(stderr, "[libsoup/server/soup-path-map.c] enter soup_path_map_lookup 3\n");
		return mappings[match].data;
		// fprintf(stderr, "[libsoup/server/soup-path-map.c] exit soup_path_map_lookup 3\n");
	}
	// fprintf(stderr, "[libsoup/server/soup-path-map.c] exit soup_path_map_lookup 1\n");
}
// Total cost: 0.041958
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 192)]
// Total instrumented cost: 0.041958, input tokens: 2398, output tokens: 2305, cache read tokens: 2394, cache write tokens: 1774

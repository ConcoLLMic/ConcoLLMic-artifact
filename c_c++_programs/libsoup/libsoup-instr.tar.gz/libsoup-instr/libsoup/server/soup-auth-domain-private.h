/*
 * Copyright (C) 2007 Novell, Inc.
 * Copyright (C) 2022 Igalia S.L.
 */

#pragma once

#include "soup-auth-domain.h"

gboolean    soup_auth_domain_try_generic_auth_callback (SoupAuthDomain    *domain,
							SoupServerMessage *msg,
							const char        *username);
// Total cost: 0.001780
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 12)]
// Total instrumented cost: 0.001780, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 188

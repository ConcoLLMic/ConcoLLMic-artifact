/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright (C) 2022 Igalia S.L.
 */

#pragma once

#include "soup-server-connection.h"
#include "soup-server-message-io.h"

SoupServerMessageIO *soup_server_message_io_http1_new (SoupServerConnection  *conn,
                                                       SoupServerMessage     *msg,
                                                       SoupMessageIOStartedFn started_cb,
                                                       gpointer               user_data);
// Total cost: 0.002013
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 14)]
// Total instrumented cost: 0.002013, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 250

/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * soup-server-message-io-http1.c: HTTP message I/O
 *
 * Copyright (C) 2000-2003, Ximian, Inc.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <glib/gi18n-lib.h>
#include <stdio.h>

#include "soup-server-message-io-http1.h"
#include "soup.h"
#include "soup-body-input-stream.h"
#include "soup-body-output-stream.h"
#include "soup-filter-input-stream.h"
#include "soup-message-io-data.h"
#include "soup-message-headers-private.h"
#include "soup-server-message-private.h"
#include "soup-misc.h"

typedef struct {
        SoupMessageIOData base;

        SoupServerMessage *msg;

        GBytes  *write_chunk;
	goffset  write_body_offset;

        GSource *unpause_source;

	GMainContext *async_context;
} SoupMessageIOHTTP1;

typedef struct {
        SoupServerMessageIO iface;

        GIOStream *iostream;
        GInputStream *istream;
        GOutputStream *ostream;

        SoupMessageIOStartedFn started_cb;
        gpointer started_user_data;

        gboolean in_io_run;

        SoupMessageIOHTTP1 *msg_io;
} SoupServerMessageIOHTTP1;

#define RESPONSE_BLOCK_SIZE 8192
#define HEADER_SIZE_LIMIT (100 * 1024)

static gboolean io_run_ready (SoupServerMessage *msg,
                              gpointer           user_data);
static void io_run (SoupServerMessageIOHTTP1 *server_io);

static SoupMessageIOHTTP1 *
soup_message_io_http1_new (SoupServerMessage *msg)
{
    fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter soup_message_io_http1_new 1\n");
    SoupMessageIOHTTP1 *msg_io;

    msg_io = g_new0 (SoupMessageIOHTTP1, 1);
    msg_io->msg = msg;
    msg_io->base.read_header_buf = g_byte_array_new ();
    msg_io->base.write_buf = g_string_new (NULL);
    msg_io->base.read_state = SOUP_MESSAGE_IO_STATE_HEADERS;
    msg_io->base.write_state = SOUP_MESSAGE_IO_STATE_NOT_STARTED;
    msg_io->async_context = g_main_context_ref_thread_default ();

    return msg_io;
    // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit soup_message_io_http1_new 1\n");
}

static void
soup_message_io_http1_free (SoupMessageIOHTTP1 *msg_io)
{
    fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter soup_message_io_http1_free 1\n");
    soup_message_io_data_cleanup (&msg_io->base);

    if (msg_io->unpause_source) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter soup_message_io_http1_free 2\n");
        g_source_destroy (msg_io->unpause_source);
        g_source_unref (msg_io->unpause_source);
        msg_io->unpause_source = NULL;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit soup_message_io_http1_free 2\n");
    }

    g_clear_object (&msg_io->msg);
    g_clear_pointer (&msg_io->async_context, g_main_context_unref);
    g_clear_pointer (&msg_io->write_chunk, g_bytes_unref);

    g_free (msg_io);
    // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit soup_message_io_http1_free 1\n");
}

static void
soup_server_message_io_http1_destroy (SoupServerMessageIO *iface)
{
    fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter soup_server_message_io_http1_destroy 1\n");
    SoupServerMessageIOHTTP1 *io = (SoupServerMessageIOHTTP1 *)iface;

    g_clear_object (&io->iostream);
    g_clear_pointer (&io->msg_io, soup_message_io_http1_free);

    g_slice_free (SoupServerMessageIOHTTP1, io);
    // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit soup_server_message_io_http1_destroy 1\n");
}

static void
soup_server_message_io_http1_finished (SoupServerMessageIO *iface,
                                       SoupServerMessage   *msg)
{
    fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter soup_server_message_io_http1_finished 1\n");
    SoupServerMessageIOHTTP1 *io = (SoupServerMessageIOHTTP1 *)iface;
    SoupMessageIOCompletionFn completion_cb;
    gpointer completion_data;
    SoupMessageIOCompletion completion;
    SoupServerConnection *conn;

    completion_cb = io->msg_io->base.completion_cb;
    completion_data = io->msg_io->base.completion_data;

    if ((io->msg_io->base.read_state >= SOUP_MESSAGE_IO_STATE_FINISHING &&
         io->msg_io->base.write_state >= SOUP_MESSAGE_IO_STATE_FINISHING))
        completion = SOUP_MESSAGE_IO_COMPLETE;
    else
        completion = SOUP_MESSAGE_IO_INTERRUPTED;

    g_object_ref (msg);
    g_clear_pointer (&io->msg_io, soup_message_io_http1_free);
    conn = soup_server_message_get_connection (msg);
    if (completion_cb) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter soup_server_message_io_http1_finished 2\n");
        completion_cb (G_OBJECT (msg), completion, completion_data);
        if (soup_server_connection_is_connected (conn)) {
            fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter soup_server_message_io_http1_finished 3\n");
            io->msg_io = soup_message_io_http1_new (soup_server_message_new (conn));
            io->msg_io->base.io_source = soup_message_io_data_get_source (&io->msg_io->base,
                                                                          G_OBJECT (io->msg_io->msg),
                                                                          io->istream,
                                                                          io->ostream,
                                                                          NULL,
                                                                          (SoupMessageIOSourceFunc)io_run_ready,
                                                                          NULL);
            g_source_attach (io->msg_io->base.io_source, io->msg_io->async_context);
            // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit soup_server_message_io_http1_finished 3\n");
        }
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit soup_server_message_io_http1_finished 2\n");
    } else {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter soup_server_message_io_http1_finished 4\n");
        soup_server_connection_disconnect (conn);
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit soup_server_message_io_http1_finished 4\n");
    }
    g_object_unref (msg);
    // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit soup_server_message_io_http1_finished 1\n");
}

static GIOStream *
soup_server_message_io_http1_steal (SoupServerMessageIO *iface)
{
    fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter soup_server_message_io_http1_steal 1\n");
    SoupServerMessageIOHTTP1 *io = (SoupServerMessageIOHTTP1 *)iface;
    SoupServerMessage *msg;
    SoupMessageIOCompletionFn completion_cb;
    gpointer completion_data;
    GIOStream *iostream;

    if (!io->iostream) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter soup_server_message_io_http1_steal 2\n");
        return NULL;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit soup_server_message_io_http1_steal 2\n");
    }

    iostream = g_object_ref (io->iostream);
    completion_cb = io->msg_io->base.completion_cb;
    completion_data = io->msg_io->base.completion_data;

    msg = io->msg_io->msg;
    g_object_ref (msg);
    g_clear_pointer (&io->msg_io, soup_message_io_http1_free);
    if (completion_cb) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter soup_server_message_io_http1_steal 3\n");
        completion_cb (G_OBJECT (msg), SOUP_MESSAGE_IO_STOLEN, completion_data);
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit soup_server_message_io_http1_steal 3\n");
    }
    g_object_unref (msg);

    return iostream;
    // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit soup_server_message_io_http1_steal 1\n");
}

static void
closed_async (GObject      *source,
              GAsyncResult *result,
              gpointer      user_data)
{
    fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter closed_async 1\n");
    GOutputStream *body_ostream = G_OUTPUT_STREAM (source);
    SoupServerMessage *msg = user_data;
    SoupServerMessageIOHTTP1 *io;
    GCancellable *async_wait;

    io = (SoupServerMessageIOHTTP1 *)soup_server_message_get_io_data (msg);
    if (!io || !io->msg_io || !io->msg_io->base.async_wait || io->msg_io->base.body_ostream != body_ostream) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter closed_async 2\n");
        g_object_unref (msg);
        return;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit closed_async 2\n");
    }

    g_output_stream_close_finish (body_ostream, result, &io->msg_io->base.async_error);
    g_clear_object (&io->msg_io->base.body_ostream);

    async_wait = g_steal_pointer (&io->msg_io->base.async_wait);
    g_cancellable_cancel (async_wait);
    g_object_unref (async_wait);

    g_object_unref (msg);
    // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit closed_async 1\n");
}

/*
 * There are two request/response formats: the basic request/response,
 * possibly with one or more unsolicited informational responses (such
 * as the WebDAV "102 Processing" response):
 *
 *     Client                            Server
 *      W:HEADERS  / R:NOT_STARTED    ->  R:HEADERS  / W:NOT_STARTED
 *      W:BODY     / R:NOT_STARTED    ->  R:BODY     / W:NOT_STARTED
 *     [W:DONE     / R:HEADERS (1xx)  <-  R:DONE     / W:HEADERS (1xx) ...]
 *      W:DONE     / R:HEADERS        <-  R:DONE     / W:HEADERS
 *      W:DONE     / R:BODY           <-  R:DONE     / W:BODY
 *      W:DONE     / R:DONE               R:DONE     / W:DONE
 *     
 * and the "Expect: 100-continue" request/response, with the client
 * blocking halfway through its request, and then either continuing or
 * aborting, depending on the server response:
 *
 *     Client                            Server
 *      W:HEADERS  / R:NOT_STARTED    ->  R:HEADERS  / W:NOT_STARTED
 *      W:BLOCKING / R:HEADERS        <-  R:BLOCKING / W:HEADERS
 *     [W:BODY     / R:BLOCKING       ->  R:BODY     / W:BLOCKING]
 *     [W:DONE     / R:HEADERS        <-  R:DONE     / W:HEADERS]
 *      W:DONE     / R:BODY           <-  R:DONE     / W:BODY
 *      W:DONE     / R:DONE               R:DONE     / W:DONE
 */

static void
handle_partial_get (SoupServerMessage *msg)
{
    fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter handle_partial_get 1\n");
    SoupRange *ranges;
    int nranges;
    GBytes *full_response;
    guint status;
    SoupMessageHeaders *request_headers;
    SoupMessageHeaders *response_headers;
    SoupMessageBody *response_body;

    request_headers = soup_server_message_get_request_headers (msg);
    response_headers = soup_server_message_get_response_headers (msg);
    response_body = soup_server_message_get_response_body (msg);

    /* Make sure the message is set up right for us to return a
     * partial response; it has to be a GET, the status must be
     * 200 OK (and in particular, NOT already 206 Partial
     * Content), and the SoupServer must have already filled in
     * the response body
     */
    if (soup_server_message_get_method (msg) != SOUP_METHOD_GET ||
        soup_server_message_get_status (msg) != SOUP_STATUS_OK ||
        soup_message_headers_get_encoding (response_headers) !=
        SOUP_ENCODING_CONTENT_LENGTH ||
        response_body->length == 0 ||
        !soup_message_body_get_accumulate (response_body)) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter handle_partial_get 2\n");
        return;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit handle_partial_get 2\n");
    }

    /* Oh, and there has to have been a valid Range header on the
     * request, of course.
     */
    status = soup_message_headers_get_ranges_internal (request_headers,
                                                       response_body->length,
                                                       TRUE,
                                                       &ranges, &nranges);
    if (status == SOUP_STATUS_REQUESTED_RANGE_NOT_SATISFIABLE) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter handle_partial_get 3\n");
        soup_server_message_set_status (msg, status, NULL);
        soup_message_body_truncate (response_body);
        return;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit handle_partial_get 3\n");
    } else if (status != SOUP_STATUS_PARTIAL_CONTENT) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter handle_partial_get 4\n");
        return;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit handle_partial_get 4\n");
    }

    full_response = soup_message_body_flatten (response_body);
    if (!full_response) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter handle_partial_get 5\n");
        soup_message_headers_free_ranges (request_headers, ranges);
        return;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit handle_partial_get 5\n");
    }

    soup_server_message_set_status (msg, SOUP_STATUS_PARTIAL_CONTENT, NULL);
    soup_message_body_truncate (response_body);

    if (nranges == 1) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter handle_partial_get 6\n");
        GBytes *range_buf;

        /* Single range, so just set Content-Range and fix the body. */

        soup_message_headers_set_content_range (response_headers,
                                                ranges[0].start,
                                                ranges[0].end,
                                                g_bytes_get_size (full_response));
        range_buf = g_bytes_new_from_bytes (full_response,
                                            ranges[0].start,
                                            ranges[0].end - ranges[0].start + 1);
        soup_message_body_append_bytes (response_body, range_buf);
        g_bytes_unref (range_buf);
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit handle_partial_get 6\n");
    } else {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter handle_partial_get 7\n");
        SoupMultipart *multipart;
        SoupMessageHeaders *part_headers;
        GBytes *part_body;
        GBytes *body = NULL;
        const char *content_type;
        int i;

        /* Multiple ranges, so build a multipart/byteranges response
         * to replace msg->response_body with.
         */
        if (soup_server_message_get_method (msg) != SOUP_METHOD_GET ||
            soup_server_message_get_status (msg) != SOUP_STATUS_OK ||
            soup_message_headers_get_encoding (response_headers) !=
            SOUP_ENCODING_CONTENT_LENGTH ||
            response_body->length == 0 ||
            !soup_message_body_get_accumulate (response_body))
                return;

        multipart = soup_multipart_new ("multipart/byteranges");
        content_type = soup_message_headers_get_one_common (response_headers, SOUP_HEADER_CONTENT_TYPE);
        for (i = 0; i < nranges; i++) {
            fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter handle_partial_get 8\n");
            part_headers = soup_message_headers_new (SOUP_MESSAGE_HEADERS_MULTIPART);
            if (content_type) {
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter handle_partial_get 9\n");
                soup_message_headers_append_common (part_headers,
                                                    SOUP_HEADER_CONTENT_TYPE,
                                                    content_type);
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit handle_partial_get 9\n");
            }
            soup_message_headers_set_content_range (part_headers,
                                                    ranges[i].start,
                                                    ranges[i].end,
                                                    g_bytes_get_size (full_response));
            part_body = g_bytes_new_from_bytes (full_response,
                                                ranges[i].start,
                                                ranges[i].end - ranges[i].start + 1);
            soup_multipart_append_part (multipart, part_headers,
                                        part_body);
            soup_message_headers_unref (part_headers);
            g_bytes_unref (part_body);
            // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit handle_partial_get 8\n");
        }

        soup_multipart_to_message (multipart, response_headers, &body);
        soup_message_body_append_bytes (response_body, body);
        g_bytes_unref (body);
        soup_multipart_free (multipart);
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit handle_partial_get 7\n");
    }

    g_bytes_unref (full_response);
    soup_message_headers_free_ranges (request_headers, ranges);
    // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit handle_partial_get 1\n");
}

static void
write_headers (SoupServerMessage  *msg,
               GString            *headers,
               SoupEncoding       *encoding)
{
    fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter write_headers 1\n");
    SoupEncoding claimed_encoding;
    SoupMessageHeadersIter iter;
    const char *name, *value;
    guint status_code;
    const char *reason_phrase;
    const char *method;
    SoupMessageHeaders *response_headers;

    if (soup_server_message_get_status (msg) == 0) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter write_headers 2\n");
        soup_server_message_set_status (msg, SOUP_STATUS_INTERNAL_SERVER_ERROR, NULL);
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit write_headers 2\n");
    }

    handle_partial_get (msg);

    status_code = soup_server_message_get_status (msg);
    reason_phrase = soup_server_message_get_reason_phrase (msg);

    g_string_append_printf (headers, "HTTP/1.%c %d %s\r\n",
                            soup_server_message_get_http_version (msg) == SOUP_HTTP_1_0 ? '0' : '1',
                            status_code, reason_phrase);

    method = soup_server_message_get_method (msg);
    response_headers = soup_server_message_get_response_headers (msg);
    claimed_encoding = soup_message_headers_get_encoding (response_headers);
    if ((method == SOUP_METHOD_HEAD ||
         status_code  == SOUP_STATUS_NO_CONTENT ||
         status_code  == SOUP_STATUS_NOT_MODIFIED ||
         SOUP_STATUS_IS_INFORMATIONAL (status_code)) ||
        (method == SOUP_METHOD_CONNECT &&
         SOUP_STATUS_IS_SUCCESSFUL (status_code))) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter write_headers 3\n");
        *encoding = SOUP_ENCODING_NONE;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit write_headers 3\n");
    } else {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter write_headers 4\n");
        *encoding = claimed_encoding;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit write_headers 4\n");
    }

    /* Per rfc 7230:
     * A server MUST NOT send a Content-Length header field in any response
     * with a status code of 1xx (Informational) or 204 (No Content).
     */

    if (status_code  == SOUP_STATUS_NO_CONTENT ||
        SOUP_STATUS_IS_INFORMATIONAL (status_code)) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter write_headers 5\n");
        soup_message_headers_remove (response_headers, "Content-Length");
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit write_headers 5\n");
    } else if (claimed_encoding == SOUP_ENCODING_CONTENT_LENGTH &&
               !soup_message_headers_get_content_length (response_headers)) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter write_headers 6\n");
        SoupMessageBody *response_body;

        response_body = soup_server_message_get_response_body (msg);
        soup_message_headers_set_content_length (response_headers,
                                                 response_body->length);
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit write_headers 6\n");
    }

    soup_message_headers_iter_init (&iter, response_headers);
    while (soup_message_headers_iter_next (&iter, &name, &value)) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter write_headers 7\n");
        g_string_append_printf (headers, "%s: %s\r\n", name, value);
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit write_headers 7\n");
    }
    g_string_append (headers, "\r\n");
    // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit write_headers 1\n");
}

/* Attempts to push forward the writing side of @msg's I/O. Returns
 * %TRUE if it manages to make some progress, and it is likely that
 * further progress can be made. Returns %FALSE if it has reached a
 * stopping point of some sort (need input from the application,
 * socket not writable, write is complete, etc).
 */
static gboolean
io_write (SoupServerMessageIOHTTP1 *server_io,
          GError                  **error)
{
    fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 1\n");
    SoupServerMessage *msg = server_io->msg_io->msg;
    SoupMessageIOData *io = &server_io->msg_io->base;
    GBytes *chunk;
    gssize nwrote;
    guint status_code;

    if (io->async_error) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 2\n");
        g_propagate_error (error, io->async_error);
        io->async_error = NULL;
        return FALSE;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 2\n");
    } else if (io->async_wait) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 3\n");
        g_set_error_literal (error, G_IO_ERROR,
                             G_IO_ERROR_WOULD_BLOCK,
                             _("Operation would block"));
        return FALSE;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 3\n");
    }

    switch (io->write_state) {
    case SOUP_MESSAGE_IO_STATE_HEADERS:
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 4\n");
        status_code = soup_server_message_get_status (msg);
        if (io->read_state == SOUP_MESSAGE_IO_STATE_BLOCKING && status_code == 0) {
            fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 5\n");
            /* Client requested "Expect: 100-continue", and
             * server did not set an error.
             */
            soup_server_message_set_status (msg, SOUP_STATUS_CONTINUE, NULL);
            // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 5\n");
        }

        if (!io->write_buf->len) {
            fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 6\n");
            write_headers (msg, io->write_buf, &io->write_encoding);
            // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 6\n");
        }

        while (io->written < io->write_buf->len) {
            fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 7\n");
            nwrote = g_pollable_stream_write (server_io->ostream,
                                              io->write_buf->str + io->written,
                                              io->write_buf->len - io->written,
                                              FALSE,
                                              NULL, error);
            if (nwrote == -1)
                return FALSE;
            io->written += nwrote;
            // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 7\n");
        }

        io->written = 0;
        g_string_truncate (io->write_buf, 0);

        status_code = soup_server_message_get_status (msg);
        if (SOUP_STATUS_IS_INFORMATIONAL (status_code)) {
            fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 8\n");
            if (status_code == SOUP_STATUS_CONTINUE) {
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 9\n");
                /* Stop and wait for the body now */
                io->write_state =
                    SOUP_MESSAGE_IO_STATE_BLOCKING;
                io->read_state = SOUP_MESSAGE_IO_STATE_BODY_START;
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 9\n");
            } else {
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 10\n");
                /* We just wrote a 1xx response
                 * header, so stay in STATE_HEADERS.
                 * (The caller will pause us from the
                 * wrote_informational callback if he
                 * is not ready to send the final
                 * response.)
                 */
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 10\n");
            }

            soup_server_message_wrote_informational (msg);

            /* If this was "101 Switching Protocols", then
             * the server probably stole the connection...
             */
            if ((SoupServerMessageIO *)server_io != soup_server_message_get_io_data (msg))
                return FALSE;

            soup_server_message_cleanup_response (msg);
            break;
            // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 8\n");
        }

        if (io->write_encoding == SOUP_ENCODING_CONTENT_LENGTH) {
            fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 11\n");
            io->write_length = soup_message_headers_get_content_length (soup_server_message_get_response_headers (msg));
            // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 11\n");
        }

        io->write_state = SOUP_MESSAGE_IO_STATE_BODY_START;
        /* If the client was waiting for a Continue
         * but we sent something else, then they're
         * now done writing.
         */
        if (io->read_state == SOUP_MESSAGE_IO_STATE_BLOCKING) {
            fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 12\n");
            io->read_state = SOUP_MESSAGE_IO_STATE_DONE;
            // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 12\n");
        }

        soup_server_message_wrote_headers (msg);
        break;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 4\n");

    case SOUP_MESSAGE_IO_STATE_BODY_START:
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 13\n");
        io->body_ostream = soup_body_output_stream_new (server_io->ostream,
                                                        io->write_encoding,
                                                        io->write_length);
        io->write_state = SOUP_MESSAGE_IO_STATE_BODY;
        break;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 13\n");

    case SOUP_MESSAGE_IO_STATE_BODY:
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 14\n");
        if (!io->write_length &&
            io->write_encoding != SOUP_ENCODING_EOF &&
            io->write_encoding != SOUP_ENCODING_CHUNKED) {
            fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 15\n");
            io->write_state = SOUP_MESSAGE_IO_STATE_BODY_FLUSH;
            break;
            // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 15\n");
        }

        if (!server_io->msg_io->write_chunk) {
            fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 16\n");
            server_io->msg_io->write_chunk = soup_message_body_get_chunk (soup_server_message_get_response_body (msg),
                                                                          server_io->msg_io->write_body_offset);
            if (!server_io->msg_io->write_chunk) {
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 17\n");
                soup_server_message_pause (msg);
                return FALSE;
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 17\n");
            }
            if (!g_bytes_get_size (server_io->msg_io->write_chunk)) {
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 18\n");
                io->write_state = SOUP_MESSAGE_IO_STATE_BODY_FLUSH;
                break;
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 18\n");
            }
            // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 16\n");
        }

        nwrote = g_pollable_stream_write (io->body_ostream,
                                          (guchar*)g_bytes_get_data (server_io->msg_io->write_chunk, NULL) + io->written,
                                          g_bytes_get_size (server_io->msg_io->write_chunk) - io->written,
                                          FALSE,
                                          NULL, error);
        if (nwrote == -1)
            return FALSE;

        chunk = g_bytes_new_from_bytes (server_io->msg_io->write_chunk, io->written, nwrote);
        io->written += nwrote;
        if (io->write_length)
            io->write_length -= nwrote;

        if (io->written == g_bytes_get_size (server_io->msg_io->write_chunk)) {
            fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 19\n");
            io->write_state = SOUP_MESSAGE_IO_STATE_BODY_DATA;
            // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 19\n");
        }

        soup_server_message_wrote_body_data (msg, g_bytes_get_size (chunk));
        g_bytes_unref (chunk);
        break;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 14\n");

    case SOUP_MESSAGE_IO_STATE_BODY_DATA:
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 20\n");
        io->written = 0;
        if (g_bytes_get_size (server_io->msg_io->write_chunk) == 0) {
            fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 21\n");
            io->write_state = SOUP_MESSAGE_IO_STATE_BODY_FLUSH;
            break;
            // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 21\n");
        }

        soup_message_body_wrote_chunk (soup_server_message_get_response_body (msg),
                                       server_io->msg_io->write_chunk);
        server_io->msg_io->write_body_offset += g_bytes_get_size (server_io->msg_io->write_chunk);
        g_clear_pointer (&server_io->msg_io->write_chunk, g_bytes_unref);

        io->write_state = SOUP_MESSAGE_IO_STATE_BODY;
        soup_server_message_wrote_chunk (msg);
        break;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 20\n");

    case SOUP_MESSAGE_IO_STATE_BODY_FLUSH:
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 22\n");
        if (io->body_ostream) {
            fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 23\n");
            if (io->write_encoding != SOUP_ENCODING_CHUNKED) {
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 24\n");
                if (!g_output_stream_close (io->body_ostream, NULL, error))
                    return FALSE;
                g_clear_object (&io->body_ostream);
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 24\n");
            } else {
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 25\n");
                io->async_wait = g_cancellable_new ();
                g_main_context_push_thread_default (server_io->msg_io->async_context);
                g_output_stream_close_async (io->body_ostream,
                                             G_PRIORITY_DEFAULT, NULL,
                                             closed_async, g_object_ref (msg));
                g_main_context_pop_thread_default (server_io->msg_io->async_context);
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 25\n");
            }
            // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 23\n");
        }

        io->write_state = SOUP_MESSAGE_IO_STATE_BODY_DONE;
        break;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 22\n");

    case SOUP_MESSAGE_IO_STATE_BODY_DONE:
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 26\n");
        io->write_state = SOUP_MESSAGE_IO_STATE_FINISHING;
        soup_server_message_wrote_body (msg);
        break;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 26\n");

    case SOUP_MESSAGE_IO_STATE_FINISHING:
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 27\n");
        io->write_state = SOUP_MESSAGE_IO_STATE_DONE;
        break;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 27\n");

    default:
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_write 28\n");
        g_return_val_if_reached (FALSE);
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 28\n");
    }

    return TRUE;
    // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_write 1\n");
}

static GUri *
parse_connect_authority (const char *req_path)
{
    fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter parse_connect_authority 1\n");
    GUri *uri;
    char *fake_uri;

    fake_uri = g_strdup_printf ("http://%s", req_path);
    uri = g_uri_parse (fake_uri, SOUP_HTTP_URI_FLAGS, NULL);
    g_free (fake_uri);

    if (!uri) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter parse_connect_authority 2\n");
        return NULL;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit parse_connect_authority 2\n");
    }

    if (g_uri_get_user (uri) ||
        g_uri_get_password (uri) ||
        g_uri_get_query (uri) ||
        g_uri_get_fragment (uri) ||
        !g_uri_get_host (uri) ||
        g_uri_get_port (uri) <= 0 ||
        strcmp (g_uri_get_path (uri), "/") != 0) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter parse_connect_authority 3\n");
        g_uri_unref (uri);
        return NULL;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit parse_connect_authority 3\n");
    }

    return uri;
    // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit parse_connect_authority 1\n");
}

static guint
parse_headers (SoupServerMessage *msg,
               char              *headers,
               guint              headers_len,
               SoupEncoding      *encoding,
               GError           **error)
{
    fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter parse_headers 1\n");
    char *req_method, *req_path, *url;
    SoupHTTPVersion version;
    SoupServerConnection *conn;
    const char *req_host;
    guint status;
    GUri *uri;
    SoupMessageHeaders *request_headers;

    request_headers = soup_server_message_get_request_headers (msg);

    status = soup_headers_parse_request (headers, headers_len,
                                         request_headers,
                                         &req_method,
                                         &req_path,
                                         &version);
    if (!SOUP_STATUS_IS_SUCCESSFUL (status)) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter parse_headers 2\n");
        return status;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit parse_headers 2\n");
    }

    soup_server_message_set_method (msg, req_method);
    soup_server_message_set_http_version (msg, version);
    g_free (req_method);

    /* Handle request body encoding */
    *encoding = soup_message_headers_get_encoding (request_headers);
    if (*encoding == SOUP_ENCODING_UNRECOGNIZED) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter parse_headers 3\n");
        g_free (req_path);
        if (soup_message_headers_get_list_common (request_headers, SOUP_HEADER_TRANSFER_ENCODING)) {
            fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter parse_headers 4\n");
            return SOUP_STATUS_NOT_IMPLEMENTED;
            // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit parse_headers 4\n");
        } else {
            fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter parse_headers 5\n");
            return SOUP_STATUS_BAD_REQUEST;
            // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit parse_headers 5\n");
        }
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit parse_headers 3\n");
    }

    /* Generate correct context for request */
    req_host = soup_message_headers_get_one_common (request_headers, SOUP_HEADER_HOST);
    if (req_host && strchr (req_host, '/')) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter parse_headers 6\n");
        g_free (req_path);
        return SOUP_STATUS_BAD_REQUEST;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit parse_headers 6\n");
    }

    conn = soup_server_message_get_connection (msg);

    if (!strcmp (req_path, "*") && req_host) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter parse_headers 7\n");
        /* Eg, "OPTIONS * HTTP/1.1" */
        url = g_strdup_printf ("%s://%s/",
                               soup_server_connection_is_ssl (conn) ? "https" : "http",
                               req_host);
        uri = g_uri_parse (url, SOUP_HTTP_URI_FLAGS, NULL);
        soup_server_message_set_options_ping (msg, TRUE);
        g_free (url);
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit parse_headers 7\n");
    } else if (soup_server_message_get_method (msg) == SOUP_METHOD_CONNECT) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter parse_headers 8\n");
        /* Authority */
        uri = parse_connect_authority (req_path);
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit parse_headers 8\n");
    } else if (*req_path != '/') {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter parse_headers 9\n");
        /* Absolute URI */
        uri = g_uri_parse (req_path, SOUP_HTTP_URI_FLAGS, NULL);
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit parse_headers 9\n");
    } else if (req_host) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter parse_headers 10\n");
        url = g_strdup_printf ("%s://%s%s",
                               soup_server_connection_is_ssl (conn) ? "https" : "http",
                               req_host, req_path);
        uri = g_uri_parse (url, SOUP_HTTP_URI_FLAGS, NULL);
        g_free (url);
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit parse_headers 10\n");
    } else if (soup_server_message_get_http_version (msg) == SOUP_HTTP_1_0) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter parse_headers 11\n");
        /* No Host header, no AbsoluteUri */
        GInetSocketAddress *addr = G_INET_SOCKET_ADDRESS (soup_server_connection_get_local_address (conn));
        GInetAddress *inet_addr = g_inet_socket_address_get_address (addr);
        char *local_ip = g_inet_address_to_string (inet_addr);
        int port = g_inet_socket_address_get_port (addr);
        if (port == 0)
            port = -1;

        uri = g_uri_build (SOUP_HTTP_URI_FLAGS,
                           soup_server_connection_is_ssl (conn) ? "https" : "http",
                           NULL, local_ip, port, req_path, NULL, NULL);
        g_free (local_ip);
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit parse_headers 11\n");
    } else {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter parse_headers 12\n");
        uri = NULL;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit parse_headers 12\n");
    }

    g_free (req_path);

    if (!uri || !g_uri_get_host (uri)) {
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter parse_headers 13\n");
        if (uri)
            g_uri_unref (uri);
        return SOUP_STATUS_BAD_REQUEST;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit parse_headers 13\n");
    }

    soup_server_message_set_uri (msg, uri);
    g_uri_unref (uri);

    return SOUP_STATUS_OK;
    // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit parse_headers 1\n");
}
/* Attempts to push forward the reading side of @msg's I/O. Returns
 * %TRUE if it manages to make some progress, and it is likely that
 * further progress can be made. Returns %FALSE if it has reached a
 * stopping point of some sort (need input from the application,
 * socket not readable, read is complete, etc).
 */
static gboolean
io_read (SoupServerMessageIOHTTP1 *server_io,
         GError                  **error)
{
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_read 1\n");
        SoupServerMessage *msg = server_io->msg_io->msg;
	SoupMessageIOData *io = &server_io->msg_io->base;
        gssize nread;
        guint status;
	SoupMessageHeaders *request_headers;
        gboolean succeeded;
        gboolean is_first_read;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_read 1\n");

        switch (io->read_state) {
        case SOUP_MESSAGE_IO_STATE_HEADERS:
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_read 2\n");
                is_first_read = io->read_header_buf->len == 0 && !soup_server_message_get_method (msg);

                succeeded = soup_message_io_data_read_headers (io, SOUP_FILTER_INPUT_STREAM (server_io->istream), FALSE, NULL, NULL, error);
                if (is_first_read && io->read_header_buf->len > 0 && !io->completion_cb)
                        server_io->started_cb (msg, server_io->started_user_data);

                if (!succeeded) {
                        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_read 3\n");
                        if (g_error_matches (*error, G_IO_ERROR, G_IO_ERROR_PARTIAL_INPUT))
                                soup_server_message_set_status (msg, SOUP_STATUS_BAD_REQUEST, NULL);
                        return FALSE;
                        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_read 3\n");
		}

                status = parse_headers (msg,
                                        (char *)io->read_header_buf->data,
                                        io->read_header_buf->len,
                                        &io->read_encoding,
                                        error);
                g_byte_array_set_size (io->read_header_buf, 0);

		request_headers = soup_server_message_get_request_headers (msg);

                if (status != SOUP_STATUS_OK) {
                        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_read 4\n");
                        /* Either we couldn't parse the headers, or they
                         * indicated something that would mean we wouldn't
                         * be able to parse the body. (Eg, unknown
                         * Transfer-Encoding.). Skip the rest of the
                         * reading, and make sure the connection gets
                         * closed when we're done.
                         */
                        soup_server_message_set_status (msg, status, NULL);
                        soup_message_headers_append_common (request_headers, SOUP_HEADER_CONNECTION, "close");
                        io->read_state = SOUP_MESSAGE_IO_STATE_FINISHING;
                        break;
                        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_read 4\n");
                }

                if (soup_message_headers_get_expectations (request_headers) & SOUP_EXPECTATION_CONTINUE) {
                        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_read 5\n");
                        /* We must return a status code and response
                         * headers to the client; either an error to
                         * be set by a got-headers handler below, or
                         * else %SOUP_STATUS_CONTINUE otherwise.
                         */
                        io->write_state = SOUP_MESSAGE_IO_STATE_HEADERS;
                        io->read_state = SOUP_MESSAGE_IO_STATE_BLOCKING;
                        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_read 5\n");
                } else {
                        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_read 6\n");
                        io->read_state = SOUP_MESSAGE_IO_STATE_BODY_START;
                        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_read 6\n");
                }

                if (io->read_encoding == SOUP_ENCODING_CONTENT_LENGTH) {
                        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_read 7\n");
                        io->read_length = soup_message_headers_get_content_length (request_headers);
                        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_read 7\n");
                }
                else {
                        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_read 8\n");
                        io->read_length = -1;
                        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_read 8\n");
                }

                soup_server_message_got_headers (msg);
                break;
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_read 2\n");

        case SOUP_MESSAGE_IO_STATE_BODY_START:
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_read 9\n");
                if (!io->body_istream) {
                        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_read 10\n");
                        io->body_istream = soup_body_input_stream_new (server_io->istream,
                                                                       io->read_encoding,
                                                                       io->read_length);
                        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_read 10\n");
                }

                io->read_state = SOUP_MESSAGE_IO_STATE_BODY;
                break;
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_read 9\n");

        case SOUP_MESSAGE_IO_STATE_BODY: {
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_read 11\n");
                guchar buf[RESPONSE_BLOCK_SIZE];

                nread = g_pollable_stream_read (io->body_istream,
                                                buf,
                                                RESPONSE_BLOCK_SIZE,
                                                FALSE,
                                                NULL, error);
                if (nread > 0) {
                        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_read 12\n");
			SoupMessageBody *request_body;

			request_body = soup_server_message_get_request_body (msg);
                        if (request_body) {
                                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_read 13\n");
                                GBytes *bytes = g_bytes_new (buf, nread);
                                soup_message_body_got_chunk (request_body, bytes);
                                soup_server_message_got_chunk (msg, bytes);
                                g_bytes_unref (bytes);
                                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_read 13\n");
                        }
                        break;
                        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_read 12\n");
                }

                if (nread == -1) {
                        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_read 14\n");
                        return FALSE;
                        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_read 14\n");
                }

                /* else nread == 0 */
                io->read_state = SOUP_MESSAGE_IO_STATE_BODY_DONE;
                break;
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_read 11\n");
        }

        case SOUP_MESSAGE_IO_STATE_BODY_DONE:
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_read 15\n");
                io->read_state = SOUP_MESSAGE_IO_STATE_FINISHING;
                soup_server_message_got_body (msg);
                break;
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_read 15\n");

        case SOUP_MESSAGE_IO_STATE_FINISHING:
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_read 16\n");
                io->read_state = SOUP_MESSAGE_IO_STATE_DONE;
                io->write_state = SOUP_MESSAGE_IO_STATE_HEADERS;
                break;
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_read 16\n");

        default:
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_read 17\n");
                g_return_val_if_reached (FALSE);
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_read 17\n");
        }

        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_read 18\n");
        return TRUE;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_read 18\n");
}

static gboolean
io_run_until (SoupServerMessageIOHTTP1 *server_io,
              SoupMessageIOState        read_state,
              SoupMessageIOState        write_state,
              GError                  **error)
{
        fprintf(stderr, "\n");
        SoupServerMessage *msg = server_io->msg_io->msg;
	SoupMessageIOData *io = &server_io->msg_io->base;
        gboolean progress = TRUE, done;
        GError *my_error = NULL;

        if (!io) {
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_run_until 2\n");
                return FALSE;
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_run_until 2\n");
        }

        g_object_ref (msg);

        while (progress && soup_server_message_get_io_data (msg) == (SoupServerMessageIO *)server_io && !io->paused && !io->async_wait &&
               (io->read_state < read_state || io->write_state < write_state)) {
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_run_until 3\n");
                if (SOUP_MESSAGE_IO_STATE_ACTIVE (io->read_state)) {
                        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_run_until 4\n");
                        progress = io_read (server_io, &my_error);
                        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_run_until 4\n");
                }
                else if (SOUP_MESSAGE_IO_STATE_ACTIVE (io->write_state)) {
                        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_run_until 5\n");
                        progress = io_write (server_io, &my_error);
                        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_run_until 5\n");
                }
                else {
                        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_run_until 6\n");
                        progress = FALSE;
                        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_run_until 6\n");
                }
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_run_until 3\n");
        }

        if (my_error) {
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_run_until 7\n");
                g_propagate_error (error, my_error);
                g_object_unref (msg);
                return FALSE;
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_run_until 7\n");
        }

	if (soup_server_message_get_io_data (msg) != (SoupServerMessageIO *)server_io) {
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_run_until 8\n");
                g_object_unref (msg);
                return FALSE;
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_run_until 8\n");
        }

        done = (io->read_state >= read_state &&
                io->write_state >= write_state);

        if (!done) {
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_run_until 9\n");
                g_set_error_literal (error, G_IO_ERROR,
                                     G_IO_ERROR_WOULD_BLOCK,
                                     _("Operation would block"));
                g_object_unref (msg);
                return FALSE;
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_run_until 9\n");
        }

        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_run_until 10\n");
        g_object_unref (msg);
        return done;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_run_until 10\n");
}

static gboolean
io_run_ready (SoupServerMessage *msg,
              gpointer           user_data)
{
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_run_ready 1\n");
        io_run ((SoupServerMessageIOHTTP1 *)soup_server_message_get_io_data (msg));
        return FALSE;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_run_ready 1\n");
}

static void
io_run (SoupServerMessageIOHTTP1 *server_io)
{
        fprintf(stderr, "\n");
        SoupServerMessage *msg = server_io->msg_io->msg;
	SoupMessageIOData *io = &server_io->msg_io->base;
        gboolean success;
        GError *error = NULL;

        g_assert (!server_io->in_io_run);
        server_io->in_io_run = TRUE;

        if (io->io_source) {
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_run 2\n");
                g_source_destroy (io->io_source);
                g_source_unref (io->io_source);
                io->io_source = NULL;
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_run 2\n");
        }

        g_object_ref (msg);
        success = io_run_until (server_io,
                                SOUP_MESSAGE_IO_STATE_DONE,
                                SOUP_MESSAGE_IO_STATE_DONE,
                                &error);

        if (soup_server_message_get_io_data (msg) != (SoupServerMessageIO *)server_io) {
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_run 3\n");
                g_object_unref (msg);
                g_clear_error (&error);

                return;
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_run 3\n");
        }

        server_io->in_io_run = FALSE;

        if (success) {
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_run 4\n");
                soup_server_message_finish (msg);
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_run 4\n");
        } else if (g_error_matches (error, G_IO_ERROR, G_IO_ERROR_WOULD_BLOCK)) {
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_run 5\n");
                g_clear_error (&error);
                io->io_source = soup_message_io_data_get_source (io, G_OBJECT (msg),
                                                                 server_io->istream,
                                                                 server_io->ostream,
                                                                 NULL,
								 (SoupMessageIOSourceFunc)io_run_ready,
								 NULL);
                g_source_attach (io->io_source, server_io->msg_io->async_context);
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_run 5\n");
        } else if (soup_server_message_get_io_data (msg) == (SoupServerMessageIO *)server_io) {
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_run 6\n");
		soup_server_message_set_status (msg, SOUP_STATUS_INTERNAL_SERVER_ERROR, error ? error->message : NULL);
		soup_server_message_finish (msg);
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_run 6\n");
	}
	
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_run 7\n");
	g_object_unref (msg);
	g_clear_error (&error);
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_run 7\n");
}

static void
soup_server_message_io_http1_read_request (SoupServerMessageIO      *iface,
                                           SoupServerMessage        *msg,
                                           SoupMessageIOCompletionFn completion_cb,
                                           gpointer                  user_data)
{
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter soup_server_message_io_http1_read_request 1\n");
        SoupServerMessageIOHTTP1 *io = (SoupServerMessageIOHTTP1 *)iface;
        SoupMessageIOHTTP1 *msg_io = io->msg_io;

        g_assert (msg_io->msg == msg);

        msg_io->base.completion_cb = completion_cb;
        msg_io->base.completion_data = user_data;

        if (!io->in_io_run)
                io_run (io);
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit soup_server_message_io_http1_read_request 1\n");
}

static void
soup_server_message_io_http1_pause (SoupServerMessageIO *iface,
                                    SoupServerMessage   *msg)
{
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter soup_server_message_io_http1_pause 1\n");
        SoupServerMessageIOHTTP1 *io = (SoupServerMessageIOHTTP1 *)iface;

        g_assert (io->msg_io && io->msg_io->msg == msg);

	if (io->msg_io->unpause_source) {
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter soup_server_message_io_http1_pause 2\n");
                g_source_destroy (io->msg_io->unpause_source);
                g_clear_pointer (&io->msg_io->unpause_source, g_source_unref);
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit soup_server_message_io_http1_pause 2\n");
	}

	soup_message_io_data_pause (&io->msg_io->base);
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit soup_server_message_io_http1_pause 1\n");
}

static gboolean
io_unpause_internal (SoupServerMessageIOHTTP1 *io)
{
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_unpause_internal 1\n");
	g_assert (io != NULL && io->msg_io != NULL);

	g_clear_pointer (&io->msg_io->unpause_source, g_source_unref);
	soup_message_io_data_unpause (&io->msg_io->base);
        if (io->msg_io->base.io_source) {
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter io_unpause_internal 2\n");
		return FALSE;
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_unpause_internal 2\n");
        }

        io_run (io);
	return FALSE;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit io_unpause_internal 1\n");
}

static void
soup_server_message_io_http1_unpause (SoupServerMessageIO *iface,
                                      SoupServerMessage   *msg)
{
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter soup_server_message_io_http1_unpause 1\n");
        SoupServerMessageIOHTTP1 *io = (SoupServerMessageIOHTTP1 *)iface;

        g_assert (io->msg_io && io->msg_io->msg == msg);

        if (!io->msg_io->unpause_source) {
                fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter soup_server_message_io_http1_unpause 2\n");
	        io->msg_io->unpause_source = soup_add_completion_reffed (io->msg_io->async_context,
                                                                         (GSourceFunc)io_unpause_internal,
                                                                         io, NULL);
                // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit soup_server_message_io_http1_unpause 2\n");
        }
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit soup_server_message_io_http1_unpause 1\n");
}

static gboolean
soup_server_message_io_http1_is_paused (SoupServerMessageIO *iface,
                                        SoupServerMessage   *msg)
{
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter soup_server_message_io_http1_is_paused 1\n");
        SoupServerMessageIOHTTP1 *io = (SoupServerMessageIOHTTP1 *)iface;

        g_assert (io->msg_io && io->msg_io->msg == msg);

	return io->msg_io->base.paused;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit soup_server_message_io_http1_is_paused 1\n");
}

static const SoupServerMessageIOFuncs io_funcs = {
        soup_server_message_io_http1_destroy,
        soup_server_message_io_http1_finished,
        soup_server_message_io_http1_steal,
        soup_server_message_io_http1_read_request,
        soup_server_message_io_http1_pause,
        soup_server_message_io_http1_unpause,
        soup_server_message_io_http1_is_paused
};

SoupServerMessageIO *
soup_server_message_io_http1_new (SoupServerConnection  *conn,
                                  SoupServerMessage     *msg,
                                  SoupMessageIOStartedFn started_cb,
                                  gpointer               user_data)
{
        fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] enter soup_server_message_io_http1_new 1\n");
        SoupServerMessageIOHTTP1 *io;

        io = g_slice_new0 (SoupServerMessageIOHTTP1);
        io->iostream = g_object_ref (soup_server_connection_get_iostream (conn));
        io->istream = g_io_stream_get_input_stream (io->iostream);
        io->ostream = g_io_stream_get_output_stream (io->iostream);

        io->started_cb = started_cb;
        io->started_user_data = user_data;

        io->iface.funcs = &io_funcs;

        io->msg_io = soup_message_io_http1_new (msg);

        return (SoupServerMessageIO *)io;
        // fprintf(stderr, "[libsoup/server/http1/soup-server-message-io-http1.c] exit soup_server_message_io_http1_new 1\n");
}
// Total cost: 0.469921
// Total split cost: 0.066058, input tokens: 15011, output tokens: 830, cache read tokens: 15002, cache write tokens: 13088, split chunks: [(0, 715), (715, 1064)]
// Total instrumented cost: 0.403864, input tokens: 10967, output tokens: 22216, cache read tokens: 10955, cache write tokens: 17947

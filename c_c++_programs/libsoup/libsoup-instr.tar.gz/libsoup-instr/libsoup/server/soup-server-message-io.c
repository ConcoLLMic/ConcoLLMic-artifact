/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright (C) 2022 Igalia S.L.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include "soup-server-message-io.h"

void
soup_server_message_io_destroy (SoupServerMessageIO *io)
{
        fprintf(stderr, "[libsoup/server/soup-server-message-io.c] enter soup_server_message_io_destroy 1\n");
        if (!io)
                return;
        // fprintf(stderr, "[libsoup/server/soup-server-message-io.c] exit soup_server_message_io_destroy 1\n");

        fprintf(stderr, "[libsoup/server/soup-server-message-io.c] enter soup_server_message_io_destroy 2\n");
        io->funcs->destroy (io);
        // fprintf(stderr, "[libsoup/server/soup-server-message-io.c] exit soup_server_message_io_destroy 2\n");
}

void
soup_server_message_io_finished (SoupServerMessageIO *io,
                                 SoupServerMessage   *msg)
{
        fprintf(stderr, "[libsoup/server/soup-server-message-io.c] enter soup_server_message_io_finished 1\n");
        io->funcs->finished (io, msg);
        // fprintf(stderr, "[libsoup/server/soup-server-message-io.c] exit soup_server_message_io_finished 1\n");
}

GIOStream *
soup_server_message_io_steal (SoupServerMessageIO *io)
{
        fprintf(stderr, "[libsoup/server/soup-server-message-io.c] enter soup_server_message_io_steal 1\n");
        return io->funcs->steal (io);
        // fprintf(stderr, "[libsoup/server/soup-server-message-io.c] exit soup_server_message_io_steal 1\n");
}

void
soup_server_message_io_read_request (SoupServerMessageIO       *io,
                                     SoupServerMessage         *msg,
                                     SoupMessageIOCompletionFn  completion_cb,
                                     gpointer                   user_data)
{
        fprintf(stderr, "[libsoup/server/soup-server-message-io.c] enter soup_server_message_io_read_request 1\n");
        io->funcs->read_request (io, msg, completion_cb, user_data);
        // fprintf(stderr, "[libsoup/server/soup-server-message-io.c] exit soup_server_message_io_read_request 1\n");
}

void
soup_server_message_io_pause (SoupServerMessageIO *io,
                              SoupServerMessage   *msg)
{
        fprintf(stderr, "[libsoup/server/soup-server-message-io.c] enter soup_server_message_io_pause 1\n");
        io->funcs->pause (io, msg);
        // fprintf(stderr, "[libsoup/server/soup-server-message-io.c] exit soup_server_message_io_pause 1\n");
}

void
soup_server_message_io_unpause (SoupServerMessageIO *io,
                                SoupServerMessage   *msg)
{
        fprintf(stderr, "[libsoup/server/soup-server-message-io.c] enter soup_server_message_io_unpause 1\n");
        io->funcs->unpause (io, msg);
        // fprintf(stderr, "[libsoup/server/soup-server-message-io.c] exit soup_server_message_io_unpause 1\n");
}

gboolean
soup_server_message_io_is_paused (SoupServerMessageIO *io,
                                  SoupServerMessage   *msg)
{
        fprintf(stderr, "[libsoup/server/soup-server-message-io.c] enter soup_server_message_io_is_paused 1\n");
        return io->funcs->is_paused (io, msg);
        // fprintf(stderr, "[libsoup/server/soup-server-message-io.c] exit soup_server_message_io_is_paused 1\n");
}
// Total cost: 0.016053
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 62)]
// Total instrumented cost: 0.016053, input tokens: 2398, output tokens: 880, cache read tokens: 2394, cache write tokens: 566

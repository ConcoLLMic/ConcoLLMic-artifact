/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright (C) 2008 Red Hat, Inc.
 */

#pragma once

#include "soup-types.h"

G_BEGIN_DECLS

#define SOUP_TYPE_SESSION_FEATURE (soup_session_feature_get_type ())
SOUP_AVAILABLE_IN_ALL
G_DECLARE_INTERFACE (SoupSessionFeature, soup_session_feature, SOUP, SESSION_FEATURE, GObject)

G_END_DECLS
// Total cost: 0.001949
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 16)]
// Total instrumented cost: 0.001949, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 233

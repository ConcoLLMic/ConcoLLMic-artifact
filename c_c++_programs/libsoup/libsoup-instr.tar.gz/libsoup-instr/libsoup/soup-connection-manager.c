/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright 2022 Igalia S.L.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include "soup-connection-manager.h"
#include "soup-message-private.h"
#include "soup-misc.h"
#include "soup-session-private.h"
#include "soup-uri-utils-private.h"
#include "soup.h"

struct _SoupConnectionManager {
        SoupSession *session;

        GMutex mutex;
        GCond cond;
        GSocketConnectable *remote_connectable;
        guint max_conns;
        guint max_conns_per_host;
        guint num_conns;

        GHashTable *http_hosts;
        GHashTable *https_hosts;
        GHashTable *conns;

        guint64 last_connection_id;
};

typedef struct {
        GUri *uri;
        GMutex *mutex;
        GHashTable *owner_map;
        GNetworkAddress *addr;

        GList *conns;
        guint  num_conns;

        GMainContext *context;
        GSource *keep_alive_src;
} SoupHost;

#define HOST_KEEP_ALIVE (5 * 60 * 1000) /* 5 min in msecs */

static SoupHost *
soup_host_new (GUri         *uri,
               GHashTable   *owner_map,
               GMutex       *mutex,
               GMainContext *context)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_host_new 1\n");
        SoupHost *host;
        const char *scheme = g_uri_get_scheme (uri);

        host = g_new0 (SoupHost, 1);
        host->owner_map = owner_map;
        host->mutex = mutex;
        if (g_strcmp0 (scheme, "http") != 0 && g_strcmp0 (scheme, "https") != 0) {
                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_host_new 2\n");
                host->uri = soup_uri_copy (uri,
                                           SOUP_URI_SCHEME, soup_uri_is_https (uri) ? "https" : "http",
                                           SOUP_URI_NONE);
                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_host_new 2\n");
        } else {
                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_host_new 3\n");
                host->uri = g_uri_ref (uri);
                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_host_new 3\n");
        }

        host->addr = g_object_new (G_TYPE_NETWORK_ADDRESS,
                                   "hostname", g_uri_get_host (host->uri),
                                   "port", g_uri_get_port (host->uri),
                                   "scheme", g_uri_get_scheme (host->uri),
                                   NULL);

        host->context = context;

        g_hash_table_insert (host->owner_map, host->uri, host);

        return host;
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_host_new 1\n");
}

static void
soup_host_free (SoupHost *host)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_host_free 1\n");
        g_warn_if_fail (host->conns == NULL);

        if (host->keep_alive_src) {
                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_host_free 2\n");
                g_source_destroy (host->keep_alive_src);
                g_source_unref (host->keep_alive_src);
                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_host_free 2\n");
        }

        g_uri_unref (host->uri);
        g_object_unref (host->addr);
        g_free (host);
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_host_free 1\n");
}

/* Note that we can't use soup_uri_host_hash() and soup_uri_host_equal()
 * because we want to ignore the protocol; http://example.com and
 * webcal://example.com are the same host.
 */
static guint
soup_host_uri_hash (gconstpointer key)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_host_uri_hash 1\n");
        GUri *uri = (GUri*)key;

        g_warn_if_fail (uri != NULL && g_uri_get_host (uri) != NULL);

        return g_uri_get_port (uri) + soup_str_case_hash (g_uri_get_host (uri));
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_host_uri_hash 1\n");
}

static gboolean
soup_host_uri_equal (gconstpointer v1, gconstpointer v2)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_host_uri_equal 1\n");
        GUri *one = (GUri*)v1;
        GUri *two = (GUri*)v2;

        g_warn_if_fail (one != NULL && two != NULL);

        const char *one_host = g_uri_get_host (one);
        const char *two_host = g_uri_get_host (two);
        g_warn_if_fail (one_host != NULL && two_host != NULL);

        if (g_uri_get_port (one) != g_uri_get_port (two)) {
                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_host_uri_equal 2\n");
                return FALSE;
                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_host_uri_equal 2\n");
        }

        return g_ascii_strcasecmp (one_host, two_host) == 0;
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_host_uri_equal 1\n");
}

static gboolean
free_unused_host (gpointer user_data)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter free_unused_host 1\n");
        SoupHost *host = (SoupHost *)user_data;
        GMutex *mutex = host->mutex;

        g_mutex_lock (mutex);

        g_clear_pointer (&host->keep_alive_src, g_source_unref);

        if (!host->conns) {
                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter free_unused_host 2\n");
                /* This will free the host in addition to removing it from the hash table */
                g_hash_table_remove (host->owner_map, host->uri);
                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit free_unused_host 2\n");
        }

        g_mutex_unlock (mutex);

        return G_SOURCE_REMOVE;
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit free_unused_host 1\n");
}

static void
soup_host_add_connection (SoupHost       *host,
                          SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_host_add_connection 1\n");
        host->conns = g_list_prepend (host->conns, conn);
        host->num_conns++;

        if (host->keep_alive_src) {
                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_host_add_connection 2\n");
                g_source_destroy (host->keep_alive_src);
                g_source_unref (host->keep_alive_src);
                host->keep_alive_src = NULL;
                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_host_add_connection 2\n");
        }
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_host_add_connection 1\n");
}

static void
soup_host_remove_connection (SoupHost       *host,
                             SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_host_remove_connection 1\n");
        host->conns = g_list_remove (host->conns, conn);
        host->num_conns--;

        /* Free the SoupHost (and its GNetworkAddress) if there
         * has not been any new connection to the host during
         * the last HOST_KEEP_ALIVE msecs.
         */
        if (host->num_conns == 0) {
                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_host_remove_connection 2\n");
                g_assert (host->keep_alive_src == NULL);
                host->keep_alive_src = soup_add_timeout (host->context,
                                                         HOST_KEEP_ALIVE,
                                                         free_unused_host,
                                                         host);
                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_host_remove_connection 2\n");
        }
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_host_remove_connection 1\n");
}

static SoupHost *
soup_connection_manager_get_host_for_message (SoupConnectionManager *manager,
                                              SoupMessage           *msg)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_host_for_message 1\n");
        GUri *uri = soup_message_get_uri (msg);
        GHashTable *map;

        map = soup_uri_is_https (uri) ?  manager->https_hosts : manager->http_hosts;
        return g_hash_table_lookup (map, uri);
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_host_for_message 1\n");
}

static SoupHost *
soup_connection_manager_get_or_create_host_for_item (SoupConnectionManager *manager,
                                                     SoupMessageQueueItem  *item)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_or_create_host_for_item 1\n");
        GUri *uri = soup_message_get_uri (item->msg);
        GHashTable *map;
        SoupHost *host;

        map = soup_uri_is_https (uri) ?  manager->https_hosts : manager->http_hosts;
        host = g_hash_table_lookup (map, uri);
        if (!host) {
                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_or_create_host_for_item 2\n");
                host = soup_host_new (uri, map, &manager->mutex, soup_session_get_context (item->session));
                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_or_create_host_for_item 2\n");
        }

        return host;
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_or_create_host_for_item 1\n");
}

static void
soup_connection_manager_drop_connection (SoupConnectionManager *manager,
                                         SoupConnection        *conn)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_drop_connection 1\n");
        g_signal_handlers_disconnect_by_data (conn, manager);
        manager->num_conns--;
        g_object_unref (conn);

        g_cond_broadcast (&manager->cond);
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_drop_connection 1\n");
}

static void
remove_connection (gpointer key,
                   gpointer value,
                   gpointer user_data)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter remove_connection 1\n");
        SoupConnectionManager *manager = user_data;
        soup_connection_manager_drop_connection (manager, key);
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit remove_connection 1\n");
}

SoupConnectionManager *
soup_connection_manager_new (SoupSession *session,
                             guint        max_conns,
                             guint        max_conns_per_host)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_new 1\n");
        SoupConnectionManager *manager;

        manager = g_new0 (SoupConnectionManager, 1);
        manager->session = session;
        manager->max_conns = max_conns;
        manager->max_conns_per_host = max_conns_per_host;
        manager->http_hosts = g_hash_table_new_full (soup_host_uri_hash,
                                                     soup_host_uri_equal,
                                                     NULL,
                                                     (GDestroyNotify)soup_host_free);
        manager->https_hosts = g_hash_table_new_full (soup_host_uri_hash,
                                                      soup_host_uri_equal,
                                                      NULL,
                                                      (GDestroyNotify)soup_host_free);
        manager->conns = g_hash_table_new (NULL, NULL);
        g_mutex_init (&manager->mutex);
        g_cond_init (&manager->cond);

        return manager;
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_new 1\n");
}

void
soup_connection_manager_free (SoupConnectionManager *manager)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_free 1\n");
        g_hash_table_foreach (manager->conns, remove_connection, manager);
        g_assert (manager->num_conns == 0);

        g_clear_object (&manager->remote_connectable);
        g_hash_table_destroy (manager->http_hosts);
        g_hash_table_destroy (manager->https_hosts);
        g_hash_table_destroy (manager->conns);
        g_mutex_clear (&manager->mutex);
        g_cond_clear (&manager->cond);

        g_free (manager);
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_free 1\n");
}

void
soup_connection_manager_set_max_conns (SoupConnectionManager *manager,
                                       guint                  max_conns)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_set_max_conns 1\n");
        g_assert (manager->num_conns == 0);
        manager->max_conns = max_conns;
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_set_max_conns 1\n");
}

guint
soup_connection_manager_get_max_conns (SoupConnectionManager *manager)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_max_conns 1\n");
        return manager->max_conns;
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_max_conns 1\n");
}

void
soup_connection_manager_set_max_conns_per_host (SoupConnectionManager *manager,
                                                guint                  max_conns_per_host)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_set_max_conns_per_host 1\n");
        g_assert (manager->num_conns == 0);
        manager->max_conns_per_host = max_conns_per_host;
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_set_max_conns_per_host 1\n");
}

guint
soup_connection_manager_get_max_conns_per_host (SoupConnectionManager *manager)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_max_conns_per_host 1\n");
        return manager->max_conns_per_host;
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_max_conns_per_host 1\n");
}

void
soup_connection_manager_set_remote_connectable (SoupConnectionManager *manager,
                                                GSocketConnectable    *connectable)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_set_remote_connectable 1\n");
        g_assert (manager->num_conns == 0);
        manager->remote_connectable = connectable ? g_object_ref (connectable) : NULL;
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_set_remote_connectable 1\n");
}

GSocketConnectable *
soup_connection_manager_get_remote_connectable (SoupConnectionManager *manager)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_remote_connectable 1\n");
        return manager->remote_connectable;
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_remote_connectable 1\n");
}

guint
soup_connection_manager_get_num_conns (SoupConnectionManager *manager)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_num_conns 1\n");
        return manager->num_conns;
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_num_conns 1\n");
}

static void
soup_connection_list_disconnect_all (GList *conns)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_list_disconnect_all 1\n");
        GList *c;

        for (c = conns; c; c = g_list_next (c)) {
                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_list_disconnect_all 2\n");
                SoupConnection *conn = (SoupConnection *)c->data;

                soup_connection_disconnect (conn);
                g_object_unref (conn);
                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_list_disconnect_all 2\n");
	}
        g_list_free (conns);
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_list_disconnect_all 1\n");
}

static GList *
soup_connection_manager_cleanup_locked (SoupConnectionManager *manager,
                                        gboolean               cleanup_idle)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_cleanup_locked 1\n");
        GList *conns = NULL;
        GHashTableIter iter;
        SoupConnection *conn;
        SoupHost *host;

        g_hash_table_iter_init (&iter, manager->conns);
        while (g_hash_table_iter_next (&iter, (gpointer *)&conn, (gpointer *)&host)) {
                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_cleanup_locked 2\n");
                SoupConnectionState state;

                state = soup_connection_get_state (conn);
                if (state == SOUP_CONNECTION_IDLE && (cleanup_idle || !soup_connection_is_idle_open (conn))) {
                        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_cleanup_locked 3\n");
                        conns = g_list_prepend (conns, g_object_ref (conn));
                        g_hash_table_iter_remove (&iter);
                        soup_host_remove_connection (host, conn);
                        soup_connection_manager_drop_connection (manager, conn);
                        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_cleanup_locked 3\n");
                }
                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_cleanup_locked 2\n");
        }

        return conns;
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_cleanup_locked 1\n");
}

static void
connection_disconnected (SoupConnection        *conn,
                         SoupConnectionManager *manager)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter connection_disconnected 1\n");
        SoupHost *host = NULL;

        g_mutex_lock (&manager->mutex);
        g_hash_table_steal_extended (manager->conns, conn, NULL, (gpointer *)&host);
        if (host) {
                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter connection_disconnected 2\n");
                soup_host_remove_connection (host, conn);
                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit connection_disconnected 2\n");
        }
        soup_connection_manager_drop_connection (manager, conn);
        g_mutex_unlock (&manager->mutex);

        soup_session_kick_queue (manager->session);
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit connection_disconnected 1\n");
}

static void
connection_state_changed (SoupConnection        *conn,
                          GParamSpec            *param,
                          SoupConnectionManager *manager)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter connection_state_changed 1\n");
        if (soup_connection_get_state (conn) != SOUP_CONNECTION_IDLE) {
                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter connection_state_changed 2\n");
                return;
                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit connection_state_changed 2\n");
        }

        g_mutex_lock (&manager->mutex);
        g_cond_broadcast (&manager->cond);
        g_mutex_unlock (&manager->mutex);

        soup_session_kick_queue (manager->session);
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit connection_state_changed 1\n");
}
static SoupConnection *
soup_connection_manager_get_connection_locked (SoupConnectionManager *manager,
                                               SoupMessageQueueItem  *item)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_connection_locked 1\n");
        static int env_force_http1 = -1;
        SoupMessage *msg = item->msg;
        gboolean need_new_connection;
        SoupConnection *conn;
        SoupSocketProperties *socket_props;
        SoupHost *host;
        guint8 force_http_version;
        GList *l;
        GSocketConnectable *remote_connectable;
        gboolean try_cleanup = TRUE;

        if (env_force_http1 == -1)
                env_force_http1 = g_getenv ("SOUP_FORCE_HTTP1") != NULL ? 1 : 0;

        need_new_connection =
                (soup_message_query_flags (msg, SOUP_MESSAGE_NEW_CONNECTION)) ||
                (soup_message_is_misdirected_retry (msg)) ||
                (!soup_message_query_flags (msg, SOUP_MESSAGE_IDEMPOTENT) &&
                 !SOUP_METHOD_IS_IDEMPOTENT (soup_message_get_method (msg)));

        host = soup_connection_manager_get_or_create_host_for_item (manager, item);

        force_http_version = env_force_http1 ? SOUP_HTTP_1_1 : soup_message_get_force_http_version (msg);
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_connection_locked 1\n");
        
        while (TRUE) {
                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_connection_locked 2\n");
                for (l = host->conns; l && l->data; l = g_list_next (l)) {
                        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_connection_locked 3\n");
                        SoupHTTPVersion http_version;

                        conn = (SoupConnection *)l->data;

                        http_version = soup_connection_get_negotiated_protocol (conn);
                        if (force_http_version <= SOUP_HTTP_2_0 && http_version != force_http_version)
                                continue;

                        switch (soup_connection_get_state (conn)) {
                        case SOUP_CONNECTION_IN_USE:
                                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_connection_locked 4\n");
                                if (!need_new_connection && http_version == SOUP_HTTP_2_0 && soup_connection_get_owner (conn) == g_thread_self () && soup_connection_is_reusable (conn))
                                        return conn;
                                break;
                                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_connection_locked 4\n");
                        case SOUP_CONNECTION_IDLE:
                                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_connection_locked 5\n");
                                if (!need_new_connection && soup_connection_is_idle_open (conn))
                                        return conn;
                                break;
                                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_connection_locked 5\n");
                        case SOUP_CONNECTION_CONNECTING:
                                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_connection_locked 6\n");
                                if (soup_session_steal_preconnection (item->session, item, conn))
                                        return conn;

                                /* Always wait if we have a pending connection as it may be
                                 * an h2 connection which will be shared. http/1.x connections
                                 * will only be slightly delayed. */
                                if (force_http_version > SOUP_HTTP_1_1 && !need_new_connection && !item->connect_only && item->async && soup_connection_get_owner (conn) == g_thread_self ())
                                        return NULL;
                                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_connection_locked 6\n");
                        default:
                                break;
                        }
                        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_connection_locked 3\n");
                }

                if (host->num_conns >= manager->max_conns_per_host) {
                        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_connection_locked 7\n");
                        if (need_new_connection && try_cleanup) {
                                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_connection_locked 8\n");
                                GList *conns;

                                try_cleanup = FALSE;
                                conns = soup_connection_manager_cleanup_locked (manager, TRUE);
                                if (conns) {
                                        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_connection_locked 9\n");
                                        /* The connection has already been removed and the signals disconnected so,
                                         * it's ok to disconnect with the mutex locked.
                                         */
                                        soup_connection_list_disconnect_all (conns);
                                        continue;
                                        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_connection_locked 9\n");
                                }
                                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_connection_locked 8\n");
                        }

                        if (item->async) {
                                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_connection_locked 10\n");
                                return NULL;
                                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_connection_locked 10\n");
                        }

                        g_cond_wait (&manager->cond, &manager->mutex);
                        try_cleanup = TRUE;
                        continue;
                        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_connection_locked 7\n");
                }

                if (manager->num_conns >= manager->max_conns) {
                        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_connection_locked 11\n");
                        if (try_cleanup) {
                                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_connection_locked 12\n");
                                GList *conns;

                                try_cleanup = FALSE;
                                conns = soup_connection_manager_cleanup_locked (manager, TRUE);
                                if (conns) {
                                        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_connection_locked 13\n");
                                        /* The connection has already been removed and the signals disconnected so,
                                         * it's ok to disconnect with the mutex locked.
                                         */
                                        soup_connection_list_disconnect_all (conns);
                                        continue;
                                        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_connection_locked 13\n");
                                }
                                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_connection_locked 12\n");
                        }

                        if (item->async) {
                                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_connection_locked 14\n");
                                return NULL;
                                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_connection_locked 14\n");
                        }

                        g_cond_wait (&manager->cond, &manager->mutex);
                        try_cleanup = TRUE;
                        continue;
                        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_connection_locked 11\n");
                }

                break;
                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_connection_locked 2\n");
        }

        /* Create a new connection */
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_connection_locked 15\n");
        remote_connectable = manager->remote_connectable ? manager->remote_connectable : G_SOCKET_CONNECTABLE (host->addr);
        socket_props = soup_session_ensure_socket_props (item->session);
        conn = g_object_new (SOUP_TYPE_CONNECTION,
                             "id", ++manager->last_connection_id,
                             "context", soup_session_get_context (item->session),
                             "remote-connectable", remote_connectable,
                             "ssl", soup_uri_is_https (host->uri),
                             "socket-properties", socket_props,
                             "force-http-version", force_http_version,
                             NULL);

        g_signal_connect (conn, "disconnected",
                          G_CALLBACK (connection_disconnected),
                          manager);
        g_signal_connect (conn, "notify::state",
                          G_CALLBACK (connection_state_changed),
                          manager);

        g_hash_table_insert (manager->conns, conn, host);

        manager->num_conns++;
        soup_host_add_connection (host, conn);

        return conn;
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_connection_locked 15\n");
}

SoupConnection *
soup_connection_manager_get_connection (SoupConnectionManager *manager,
                                        SoupMessageQueueItem  *item)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_connection 1\n");
        SoupConnection *conn;

        soup_connection_manager_cleanup (manager, FALSE);

        conn = soup_message_get_connection (item->msg);
        if (conn) {
                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_get_connection 2\n");
                g_warn_if_fail (soup_connection_get_state (conn) != SOUP_CONNECTION_DISCONNECTED);
                g_object_unref (conn);
                return conn;
                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_connection 2\n");
        }

        g_mutex_lock (&manager->mutex);
        conn = soup_connection_manager_get_connection_locked (manager, item);
        if (conn)
                soup_message_set_connection (item->msg, conn);
        g_mutex_unlock (&manager->mutex);

        return conn;
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_get_connection 1\n");
}

gboolean
soup_connection_manager_cleanup (SoupConnectionManager *manager,
                                 gboolean               cleanup_idle)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_cleanup 1\n");
        GList *conns;

        g_mutex_lock (&manager->mutex);
        conns = soup_connection_manager_cleanup_locked (manager, cleanup_idle);
        g_mutex_unlock (&manager->mutex);

        if (conns) {
                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_cleanup 2\n");
                soup_connection_list_disconnect_all (conns);

                return TRUE;
                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_cleanup 2\n");
        }

        return FALSE;
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_cleanup 1\n");
}

GIOStream *
soup_connection_manager_steal_connection (SoupConnectionManager *manager,
                                          SoupMessage           *msg)
{
        fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_steal_connection 1\n");
        SoupConnection *conn;
        SoupHost *host;
        GIOStream *stream;

        conn = soup_message_get_connection (msg);
        if (!conn) {
                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_steal_connection 2\n");
                return NULL;
                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_steal_connection 2\n");
        }

        if (soup_connection_get_state (conn) != SOUP_CONNECTION_IN_USE) {
                fprintf(stderr, "[libsoup/soup-connection-manager.c] enter soup_connection_manager_steal_connection 3\n");
                g_object_unref (conn);
                return NULL;
                // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_steal_connection 3\n");
        }

        g_mutex_lock (&manager->mutex);
        host = soup_connection_manager_get_host_for_message (manager, msg);
        g_hash_table_remove (manager->conns, conn);
        soup_host_remove_connection (host, conn);
        soup_connection_manager_drop_connection (manager, conn);
        g_mutex_unlock (&manager->mutex);

        stream = soup_connection_steal_iostream (conn);
        soup_message_set_connection (msg, NULL);
        g_object_unref (conn);

        return stream;
        // fprintf(stderr, "[libsoup/soup-connection-manager.c] exit soup_connection_manager_steal_connection 1\n");
}
// Total cost: 0.209141
// Total split cost: 0.050433, input tokens: 22605, output tokens: 883, cache read tokens: 22589, cache write tokens: 8097, split chunks: [(0, 388), (388, 597)]
// Total instrumented cost: 0.158707, input tokens: 2402, output tokens: 8480, cache read tokens: 2394, cache write tokens: 8204

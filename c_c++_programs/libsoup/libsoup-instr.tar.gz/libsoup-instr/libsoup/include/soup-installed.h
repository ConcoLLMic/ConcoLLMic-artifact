/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright (C) 2000-2003, Ximian, Inc.
 */

#ifndef __SOUP_H__
#define __SOUP_H__ 1

#define __SOUP_H_INSIDE__

#include <libsoup/soup-auth.h>
#include <libsoup/soup-auth-manager.h>
#include <libsoup/soup-cache.h>
#include <libsoup/soup-content-decoder.h>
#include <libsoup/soup-content-sniffer.h>
#include <libsoup/soup-cookie.h>
#include <libsoup/soup-cookie-jar.h>
#include <libsoup/soup-cookie-jar-db.h>
#include <libsoup/soup-cookie-jar-text.h>
#include <libsoup/soup-date-utils.h>
#include <libsoup/soup-enum-types.h>
#include <libsoup/soup-form.h>
#include <libsoup/soup-headers.h>
#include <libsoup/soup-hsts-enforcer.h>
#include <libsoup/soup-hsts-enforcer-db.h>
#include <libsoup/soup-hsts-policy.h>
#include <libsoup/soup-logger.h>
#include <libsoup/soup-message.h>
#include <libsoup/soup-message-metrics.h>
#include <libsoup/soup-method.h>
#include <libsoup/soup-multipart.h>
#include <libsoup/soup-multipart-input-stream.h>
#include <libsoup/soup-auth-domain.h>
#include <libsoup/soup-auth-domain-basic.h>
#include <libsoup/soup-auth-domain-digest.h>
#include <libsoup/soup-server.h>
#include <libsoup/soup-server-message.h>
#include <libsoup/soup-session.h>
#include <libsoup/soup-session-feature.h>
#include <libsoup/soup-status.h>
#include <libsoup/soup-tld.h>
#include <libsoup/soup-uri-utils.h>
#include <libsoup/soup-version.h>
#include <libsoup/soup-websocket.h>
#include <libsoup/soup-websocket-connection.h>
#include <libsoup/soup-websocket-extension.h>
#include <libsoup/soup-websocket-extension-deflate.h>
#include <libsoup/soup-websocket-extension-manager.h>

#undef __SOUP_H_INSIDE__

#endif /* __SOUP_H__ */
// Total cost: 0.004105
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 52)]
// Total instrumented cost: 0.004105, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 808

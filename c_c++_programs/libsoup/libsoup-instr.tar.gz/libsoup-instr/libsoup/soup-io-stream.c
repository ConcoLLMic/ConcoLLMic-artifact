/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * soup-io-stream.c
 *
 * Copyright 2012 Red Hat, Inc.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include "soup-io-stream.h"
#include "soup.h"
#include "soup-filter-input-stream.h"

struct _SoupIOStream {
	GIOStream parent_instance;
};

typedef struct {
	GIOStream *base_iostream;
	gboolean close_on_dispose;

	GInputStream *istream;
	GOutputStream *ostream;
	gboolean disposing;
} SoupIOStreamPrivate;

enum {
	PROP_0,

	PROP_BASE_IOSTREAM,
	PROP_CLOSE_ON_DISPOSE,

        LAST_PROPERTY
};

static GParamSpec *properties[LAST_PROPERTY] = { NULL, };

G_DEFINE_FINAL_TYPE_WITH_PRIVATE (SoupIOStream, soup_io_stream, G_TYPE_IO_STREAM)

static void
soup_io_stream_init (SoupIOStream *stream)
{
	fprintf(stderr, "\n");
	// fprintf(stderr, "\n");
}

static void
soup_io_stream_set_property (GObject *object, guint prop_id,
			     const GValue *value, GParamSpec *pspec)
{
	fprintf(stderr, "[libsoup/soup-io-stream.c] enter soup_io_stream_set_property 1\n");
	SoupIOStream *siostream = SOUP_IO_STREAM (object);
        SoupIOStreamPrivate *priv = soup_io_stream_get_instance_private (siostream);
	GIOStream *io;
	// fprintf(stderr, "[libsoup/soup-io-stream.c] exit soup_io_stream_set_property 1\n");

	switch (prop_id) {
	case PROP_BASE_IOSTREAM:
		fprintf(stderr, "[libsoup/soup-io-stream.c] enter soup_io_stream_set_property 2\n");
		io = priv->base_iostream = g_value_dup_object (value);
		if (io) {
			fprintf(stderr, "[libsoup/soup-io-stream.c] enter soup_io_stream_set_property 3\n");
			priv->istream =
				soup_filter_input_stream_new (g_io_stream_get_input_stream (io));
			priv->ostream =
				g_object_ref (g_io_stream_get_output_stream (io));
			// fprintf(stderr, "[libsoup/soup-io-stream.c] exit soup_io_stream_set_property 3\n");
		} else {
			fprintf(stderr, "[libsoup/soup-io-stream.c] enter soup_io_stream_set_property 4\n");
			g_clear_object (&priv->istream);
			g_clear_object (&priv->ostream);
			// fprintf(stderr, "[libsoup/soup-io-stream.c] exit soup_io_stream_set_property 4\n");
		}
		break;
		// fprintf(stderr, "[libsoup/soup-io-stream.c] exit soup_io_stream_set_property 2\n");
	case PROP_CLOSE_ON_DISPOSE:
		fprintf(stderr, "[libsoup/soup-io-stream.c] enter soup_io_stream_set_property 5\n");
		priv->close_on_dispose = g_value_get_boolean (value);
		break;
		// fprintf(stderr, "[libsoup/soup-io-stream.c] exit soup_io_stream_set_property 5\n");
	default:
		fprintf(stderr, "[libsoup/soup-io-stream.c] enter soup_io_stream_set_property 6\n");
		G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
		break;
		// fprintf(stderr, "[libsoup/soup-io-stream.c] exit soup_io_stream_set_property 6\n");
	}
}

static void
soup_io_stream_get_property (GObject *object, guint prop_id,
			     GValue *value, GParamSpec *pspec)
{
	fprintf(stderr, "[libsoup/soup-io-stream.c] enter soup_io_stream_get_property 1\n");
	SoupIOStream *siostream = SOUP_IO_STREAM (object);
        SoupIOStreamPrivate *priv = soup_io_stream_get_instance_private (siostream);
	// fprintf(stderr, "[libsoup/soup-io-stream.c] exit soup_io_stream_get_property 1\n");

	switch (prop_id) {
	case PROP_BASE_IOSTREAM:
		fprintf(stderr, "[libsoup/soup-io-stream.c] enter soup_io_stream_get_property 2\n");
		g_value_set_object (value, priv->base_iostream);
		break;
		// fprintf(stderr, "[libsoup/soup-io-stream.c] exit soup_io_stream_get_property 2\n");
	case PROP_CLOSE_ON_DISPOSE:
		fprintf(stderr, "[libsoup/soup-io-stream.c] enter soup_io_stream_get_property 3\n");
		g_value_set_boolean (value, priv->close_on_dispose);
		break;
		// fprintf(stderr, "[libsoup/soup-io-stream.c] exit soup_io_stream_get_property 3\n");
	default:
		fprintf(stderr, "[libsoup/soup-io-stream.c] enter soup_io_stream_get_property 4\n");
		G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
		break;
		// fprintf(stderr, "[libsoup/soup-io-stream.c] exit soup_io_stream_get_property 4\n");
	}
}

static void
soup_io_stream_dispose (GObject *object)
{
	fprintf(stderr, "[libsoup/soup-io-stream.c] enter soup_io_stream_dispose 1\n");
	SoupIOStream *siostream = SOUP_IO_STREAM (object);
        SoupIOStreamPrivate *priv = soup_io_stream_get_instance_private (siostream);

	priv->disposing = TRUE;

	G_OBJECT_CLASS (soup_io_stream_parent_class)->dispose (object);
	// fprintf(stderr, "[libsoup/soup-io-stream.c] exit soup_io_stream_dispose 1\n");
}

static void
soup_io_stream_finalize (GObject *object)
{
	fprintf(stderr, "[libsoup/soup-io-stream.c] enter soup_io_stream_finalize 1\n");
	SoupIOStream *siostream = SOUP_IO_STREAM (object);
        SoupIOStreamPrivate *priv = soup_io_stream_get_instance_private (siostream);

	g_clear_object (&priv->base_iostream);
	g_clear_object (&priv->istream);
	g_clear_object (&priv->ostream);

	G_OBJECT_CLASS (soup_io_stream_parent_class)->finalize (object);
	// fprintf(stderr, "[libsoup/soup-io-stream.c] exit soup_io_stream_finalize 1\n");
}

static GInputStream *
soup_io_stream_get_input_stream (GIOStream *stream)
{
	fprintf(stderr, "[libsoup/soup-io-stream.c] enter soup_io_stream_get_input_stream 1\n");
        SoupIOStream *siostream = SOUP_IO_STREAM (stream);
        SoupIOStreamPrivate *priv = soup_io_stream_get_instance_private (siostream);
	return priv->istream;
	// fprintf(stderr, "[libsoup/soup-io-stream.c] exit soup_io_stream_get_input_stream 1\n");
}

static GOutputStream *
soup_io_stream_get_output_stream (GIOStream *stream)
{
	fprintf(stderr, "[libsoup/soup-io-stream.c] enter soup_io_stream_get_output_stream 1\n");
        SoupIOStream *siostream = SOUP_IO_STREAM (stream);
        SoupIOStreamPrivate *priv = soup_io_stream_get_instance_private (siostream);
	return priv->ostream;
	// fprintf(stderr, "[libsoup/soup-io-stream.c] exit soup_io_stream_get_output_stream 1\n");
}


static gboolean
soup_io_stream_close (GIOStream     *stream,
		      GCancellable  *cancellable,
		      GError       **error)
{
	fprintf(stderr, "[libsoup/soup-io-stream.c] enter soup_io_stream_close 1\n");
	SoupIOStream *siostream = SOUP_IO_STREAM (stream);
        SoupIOStreamPrivate *priv = soup_io_stream_get_instance_private (siostream);
	// fprintf(stderr, "[libsoup/soup-io-stream.c] exit soup_io_stream_close 1\n");

	if (priv->disposing &&
	    !priv->close_on_dispose) {
		fprintf(stderr, "[libsoup/soup-io-stream.c] enter soup_io_stream_close 2\n");
		return TRUE;
		// fprintf(stderr, "[libsoup/soup-io-stream.c] exit soup_io_stream_close 2\n");
	}

	fprintf(stderr, "[libsoup/soup-io-stream.c] enter soup_io_stream_close 3\n");
	return g_io_stream_close (priv->base_iostream,
				  cancellable, error);
	// fprintf(stderr, "[libsoup/soup-io-stream.c] exit soup_io_stream_close 3\n");
}

static void
close_async_complete (GObject      *object,
		      GAsyncResult *result,
		      gpointer      user_data)
{
	fprintf(stderr, "[libsoup/soup-io-stream.c] enter close_async_complete 1\n");
	GTask *task = user_data;
	GError *error = NULL;

	if (g_io_stream_close_finish (G_IO_STREAM (object), result, &error)) {
		fprintf(stderr, "[libsoup/soup-io-stream.c] enter close_async_complete 2\n");
		g_task_return_boolean (task, TRUE);
		// fprintf(stderr, "[libsoup/soup-io-stream.c] exit close_async_complete 2\n");
	}
	else {
		fprintf(stderr, "[libsoup/soup-io-stream.c] enter close_async_complete 3\n");
		g_task_return_error (task, error);
		// fprintf(stderr, "[libsoup/soup-io-stream.c] exit close_async_complete 3\n");
	}
	g_object_unref (task);
	// fprintf(stderr, "[libsoup/soup-io-stream.c] exit close_async_complete 1\n");
}

static void    
soup_io_stream_close_async (GIOStream           *stream,
			    int                  io_priority,
			    GCancellable        *cancellable,
			    GAsyncReadyCallback  callback,
			    gpointer             user_data)
{
	fprintf(stderr, "[libsoup/soup-io-stream.c] enter soup_io_stream_close_async 1\n");
	GTask *task;
        SoupIOStream *siostream = SOUP_IO_STREAM (stream);
        SoupIOStreamPrivate *priv = soup_io_stream_get_instance_private (siostream);

	task = g_task_new (stream, cancellable, callback, user_data);
	g_task_set_source_tag (task, soup_io_stream_close_async);
	g_io_stream_close_async (priv->base_iostream,
				 io_priority, cancellable,
				 close_async_complete, task);
	// fprintf(stderr, "[libsoup/soup-io-stream.c] exit soup_io_stream_close_async 1\n");
}

static gboolean
soup_io_stream_close_finish (GIOStream     *stream,
                             GAsyncResult  *result,
			     GError       **error)
{
	fprintf(stderr, "[libsoup/soup-io-stream.c] enter soup_io_stream_close_finish 1\n");
	return g_task_propagate_boolean (G_TASK (result), error);
	// fprintf(stderr, "[libsoup/soup-io-stream.c] exit soup_io_stream_close_finish 1\n");
}

static void
soup_io_stream_class_init (SoupIOStreamClass *stream_class)
{
	fprintf(stderr, "[libsoup/soup-io-stream.c] enter soup_io_stream_class_init 1\n");
	GObjectClass *object_class = G_OBJECT_CLASS (stream_class);
	GIOStreamClass *io_stream_class = G_IO_STREAM_CLASS (stream_class);

	object_class->set_property = soup_io_stream_set_property;
	object_class->get_property = soup_io_stream_get_property;
	object_class->dispose = soup_io_stream_dispose;
	object_class->finalize = soup_io_stream_finalize;

	io_stream_class->get_input_stream = soup_io_stream_get_input_stream;
	io_stream_class->get_output_stream = soup_io_stream_get_output_stream;
	io_stream_class->close_fn = soup_io_stream_close;
	io_stream_class->close_async = soup_io_stream_close_async;
	io_stream_class->close_finish = soup_io_stream_close_finish;

        properties[PROP_BASE_IOSTREAM] =
		g_param_spec_object ("base-iostream",
				     "Base IOStream",
				     "Base GIOStream",
				     G_TYPE_IO_STREAM,
				     G_PARAM_READWRITE |
				     G_PARAM_CONSTRUCT_ONLY |
				     G_PARAM_STATIC_STRINGS);

        properties[PROP_CLOSE_ON_DISPOSE] =
		g_param_spec_boolean ("close-on-dispose",
				      "Close base stream",
				      "Close base GIOStream when closing",
				      TRUE,
				      G_PARAM_READWRITE |
				      G_PARAM_CONSTRUCT_ONLY |
				      G_PARAM_STATIC_STRINGS);

        g_object_class_install_properties (object_class, LAST_PROPERTY, properties);
	// fprintf(stderr, "[libsoup/soup-io-stream.c] exit soup_io_stream_class_init 1\n");
}

GIOStream *
soup_io_stream_new (GIOStream *base_iostream,
		    gboolean   close_on_dispose)
{
	fprintf(stderr, "[libsoup/soup-io-stream.c] enter soup_io_stream_new 1\n");
	return g_object_new (SOUP_TYPE_IO_STREAM,
			     "base-iostream", base_iostream,
			     "close-on-dispose", close_on_dispose,
			     NULL);
	// fprintf(stderr, "[libsoup/soup-io-stream.c] exit soup_io_stream_new 1\n");
}

GIOStream *
soup_io_stream_get_base_iostream (SoupIOStream *stream)
{
	fprintf(stderr, "[libsoup/soup-io-stream.c] enter soup_io_stream_get_base_iostream 1\n");
        SoupIOStreamPrivate *priv = soup_io_stream_get_instance_private (stream);

	g_return_val_if_fail (SOUP_IS_IO_STREAM (stream), NULL);

	return priv->base_iostream;
	// fprintf(stderr, "[libsoup/soup-io-stream.c] exit soup_io_stream_get_base_iostream 1\n");
}
// Total cost: 0.065680
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 251)]
// Total instrumented cost: 0.065680, input tokens: 2398, output tokens: 3682, cache read tokens: 2394, cache write tokens: 2592

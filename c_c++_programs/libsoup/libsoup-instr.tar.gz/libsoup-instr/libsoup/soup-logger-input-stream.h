/*
 * Copyright (C) 2021 Igalia S.L.
 */

#pragma once

#include "soup-types.h"
#include "soup-logger.h"

G_BEGIN_DECLS

#define SOUP_TYPE_LOGGER_INPUT_STREAM (soup_logger_input_stream_get_type ())
G_DECLARE_FINAL_TYPE (SoupLoggerInputStream,
                      soup_logger_input_stream,
                      SOUP,
                      LOGGER_INPUT_STREAM,
                      GFilterInputStream)

SoupLogger *soup_logger_input_stream_get_logger (SoupLoggerInputStream *stream);

G_END_DECLS
// Total cost: 0.002028
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 21)]
// Total instrumented cost: 0.002028, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 254

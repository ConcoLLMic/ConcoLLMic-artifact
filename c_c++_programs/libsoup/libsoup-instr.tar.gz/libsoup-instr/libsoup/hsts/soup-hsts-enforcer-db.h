/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright (C) 2016, 2017, 2018 Igalia S.L.
 * Copyright (C) 2017, 2018 Metrological Group B.V.
 */

#pragma once

#include "soup-hsts-enforcer.h"

G_BEGIN_DECLS

#define SOUP_TYPE_HSTS_ENFORCER_DB (soup_hsts_enforcer_db_get_type ())
SOUP_AVAILABLE_IN_ALL
G_DECLARE_FINAL_TYPE (SoupHSTSEnforcerDB, soup_hsts_enforcer_db, SOUP, HSTS_ENFORCER_DB, SoupHSTSEnforcer)

SOUP_AVAILABLE_IN_ALL
SoupHSTSEnforcer *soup_hsts_enforcer_db_new (const char *filename);

G_END_DECLS
// Total cost: 0.002373
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 20)]
// Total instrumented cost: 0.002373, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 346

/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright (C) 2003, Ximian, Inc.
 */

#pragma once

#include "soup-types.h"

G_BEGIN_DECLS

typedef struct _SoupConnection        SoupConnection;
typedef struct _SoupMessageQueue      SoupMessageQueue;
typedef struct _SoupMessageQueueItem  SoupMessageQueueItem;
typedef struct _SoupClientMessageIO   SoupClientMessageIO;
typedef struct _SoupSocket            SoupSocket;

G_END_DECLS
// Total cost: 0.001979
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 18)]
// Total instrumented cost: 0.001979, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 241

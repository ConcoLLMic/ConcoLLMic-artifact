/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * soup-tls-interaction.c: TLS interaction implementation
 *
 * Copyright (C) 2021 Igalia S.L.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include "soup-tls-interaction.h"

struct _SoupTlsInteraction {
        GTlsInteraction parent;
};

typedef struct {
        GWeakRef conn;
} SoupTlsInteractionPrivate;

G_DEFINE_FINAL_TYPE_WITH_PRIVATE (SoupTlsInteraction, soup_tls_interaction, G_TYPE_TLS_INTERACTION)

static void
soup_tls_interaction_request_certificate_async (GTlsInteraction             *tls_interaction,
                                                GTlsConnection              *connection,
                                                GTlsCertificateRequestFlags  flags,
                                                GCancellable                *cancellable,
                                                GAsyncReadyCallback          callback,
                                                gpointer                     user_data)
{
        fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] enter soup_tls_interaction_request_certificate_async 1\n");
        SoupTlsInteractionPrivate *priv = soup_tls_interaction_get_instance_private (SOUP_TLS_INTERACTION (tls_interaction));
        GTask *task;
        SoupConnection *conn = g_weak_ref_get (&priv->conn);

        task = g_task_new (tls_interaction, cancellable, callback, user_data);
        g_task_set_source_tag (task, soup_tls_interaction_request_certificate_async);
        // fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] exit soup_tls_interaction_request_certificate_async 1\n");
        if (conn) {
                fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] enter soup_tls_interaction_request_certificate_async 2\n");
                soup_connection_request_tls_certificate (conn, connection, task);
                g_object_unref (conn);
                // fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] exit soup_tls_interaction_request_certificate_async 2\n");
        } else {
                fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] enter soup_tls_interaction_request_certificate_async 3\n");
                g_task_return_int (task, G_TLS_INTERACTION_FAILED);
                // fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] exit soup_tls_interaction_request_certificate_async 3\n");
        }
        fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] enter soup_tls_interaction_request_certificate_async 4\n");
        g_object_unref (task);
        // fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] exit soup_tls_interaction_request_certificate_async 4\n");
}

static GTlsInteractionResult
soup_tls_interaction_request_certificate_finish (GTlsInteraction *tls_interaction,
                                                 GAsyncResult    *result,
                                                 GError         **error)
{
        fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] enter soup_tls_interaction_request_certificate_finish 1\n");
        int task_result;

        task_result = g_task_propagate_int (G_TASK (result), error);
        return task_result != -1 ? task_result : G_TLS_INTERACTION_FAILED;
        // fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] exit soup_tls_interaction_request_certificate_finish 1\n");
}

static void
soup_tls_interaction_ask_password_async (GTlsInteraction    *tls_interaction,
                                         GTlsPassword       *password,
                                         GCancellable       *cancellable,
                                         GAsyncReadyCallback callback,
                                         gpointer            user_data)
{
        fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] enter soup_tls_interaction_ask_password_async 1\n");
        SoupTlsInteractionPrivate *priv = soup_tls_interaction_get_instance_private (SOUP_TLS_INTERACTION (tls_interaction));
        GTask *task;
        SoupConnection *conn = g_weak_ref_get (&priv->conn);

        task = g_task_new (tls_interaction, cancellable, callback, user_data);
        g_task_set_source_tag (task, soup_tls_interaction_ask_password_async);
        // fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] exit soup_tls_interaction_ask_password_async 1\n");
        if (conn) {
                fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] enter soup_tls_interaction_ask_password_async 2\n");
                soup_connection_request_tls_certificate_password (conn, password, task);
                g_object_unref (conn);
                // fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] exit soup_tls_interaction_ask_password_async 2\n");
        } else {
                fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] enter soup_tls_interaction_ask_password_async 3\n");
                g_task_return_int (task, G_TLS_INTERACTION_FAILED);
                // fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] exit soup_tls_interaction_ask_password_async 3\n");
        }
        fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] enter soup_tls_interaction_ask_password_async 4\n");
        g_object_unref (task);
        // fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] exit soup_tls_interaction_ask_password_async 4\n");
}

static GTlsInteractionResult
soup_tls_interaction_ask_password_finish (GTlsInteraction *tls_interaction,
                                          GAsyncResult    *result,
                                          GError         **error)
{
        fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] enter soup_tls_interaction_ask_password_finish 1\n");
        int task_result;

        task_result = g_task_propagate_int (G_TASK (result), error);
        return task_result != -1 ? task_result : G_TLS_INTERACTION_FAILED;
        // fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] exit soup_tls_interaction_ask_password_finish 1\n");
}

static void
soup_tls_interaction_finalize (GObject *object)
{
        fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] enter soup_tls_interaction_finalize 1\n");
        SoupTlsInteractionPrivate *priv = soup_tls_interaction_get_instance_private (SOUP_TLS_INTERACTION (object));

        g_weak_ref_clear (&priv->conn);

        G_OBJECT_CLASS (soup_tls_interaction_parent_class)->finalize (object);
        // fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] exit soup_tls_interaction_finalize 1\n");
}

static void
soup_tls_interaction_init (SoupTlsInteraction *interaction)
{
        fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] enter soup_tls_interaction_init 1\n");
        SoupTlsInteractionPrivate *priv = soup_tls_interaction_get_instance_private (interaction);

        g_weak_ref_init (&priv->conn, NULL);
        // fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] exit soup_tls_interaction_init 1\n");
}

static void
soup_tls_interaction_class_init (SoupTlsInteractionClass *klass)
{
        fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] enter soup_tls_interaction_class_init 1\n");
        GObjectClass *object_class = G_OBJECT_CLASS (klass);
        GTlsInteractionClass *interaction_class = G_TLS_INTERACTION_CLASS (klass);

        object_class->finalize = soup_tls_interaction_finalize;

        interaction_class->request_certificate_async = soup_tls_interaction_request_certificate_async;
        interaction_class->request_certificate_finish = soup_tls_interaction_request_certificate_finish;
        interaction_class->ask_password_async = soup_tls_interaction_ask_password_async;
        interaction_class->ask_password_finish = soup_tls_interaction_ask_password_finish;
        // fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] exit soup_tls_interaction_class_init 1\n");
}

GTlsInteraction *
soup_tls_interaction_new (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] enter soup_tls_interaction_new 1\n");
        GTlsInteraction *interaction;
        SoupTlsInteractionPrivate *priv;

        interaction = g_object_new (SOUP_TYPE_TLS_INTERACTION, NULL);
        priv = soup_tls_interaction_get_instance_private (SOUP_TLS_INTERACTION (interaction));
        g_weak_ref_set (&priv->conn, conn);

        return interaction;
        // fprintf(stderr, "[libsoup/auth/soup-tls-interaction.c] exit soup_tls_interaction_new 1\n");
}
// Total cost: 0.040326
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 134)]
// Total instrumented cost: 0.040326, input tokens: 2398, output tokens: 2238, cache read tokens: 2394, cache write tokens: 1607

/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright (C) 2000-2003, Ximian, Inc.
 */

#pragma once

#include "soup-auth.h"

G_BEGIN_DECLS

SOUP_AVAILABLE_IN_ALL
G_DECLARE_FINAL_TYPE (SoupAuthBasic, soup_auth_basic, SOUP, AUTH_BASIC, SoupAuth)

G_END_DECLS
// Total cost: 0.001896
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 15)]
// Total instrumented cost: 0.001896, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 219

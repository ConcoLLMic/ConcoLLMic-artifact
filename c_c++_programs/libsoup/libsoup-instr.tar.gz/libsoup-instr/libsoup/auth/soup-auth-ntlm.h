/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-ntlm-offset: 8 -*- */
/*
 * Copyright (C) 2007 Red Hat, Inc.
 */

#pragma once

#include "soup-connection-auth.h"

G_BEGIN_DECLS

SOUP_AVAILABLE_IN_ALL
G_DECLARE_FINAL_TYPE (SoupAuthNTLM, soup_auth_ntlm, SOUP, AUTH_NTLM, SoupConnectionAuth)

G_END_DECLS
// Total cost: 0.001926
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 15)]
// Total instrumented cost: 0.001926, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 227

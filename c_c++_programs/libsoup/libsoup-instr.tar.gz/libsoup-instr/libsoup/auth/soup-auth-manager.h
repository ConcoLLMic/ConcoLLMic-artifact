/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright (C) 2007 Red Hat, Inc.
 */

#pragma once

#include "soup-types.h"
#include "soup-auth.h"

G_BEGIN_DECLS

#define SOUP_TYPE_AUTH_MANAGER (soup_auth_manager_get_type ())
SOUP_AVAILABLE_IN_ALL
G_DECLARE_FINAL_TYPE (SoupAuthManager, soup_auth_manager, SOUP, AUTH_MANAGER, GObject)

SOUP_AVAILABLE_IN_ALL
void  soup_auth_manager_use_auth (SoupAuthManager *manager,
				  GUri            *uri,
				  SoupAuth        *auth);

SOUP_AVAILABLE_IN_ALL
void soup_auth_manager_clear_cached_credentials (SoupAuthManager *manager);

G_END_DECLS
// Total cost: 0.002298
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 25)]
// Total instrumented cost: 0.002298, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 326

/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright (C) 2021 Igalia S.L.
 */

#pragma once

#include "soup-connection.h"
#include <gio/gio.h>

G_BEGIN_DECLS

#define SOUP_TYPE_TLS_INTERACTION (soup_tls_interaction_get_type ())
G_DECLARE_FINAL_TYPE (SoupTlsInteraction, soup_tls_interaction, SOUP, TLS_INTERACTION, GTlsInteraction)

GType            soup_tls_interaction_get_type (void);
GTlsInteraction *soup_tls_interaction_new      (SoupConnection *conn);

G_END_DECLS
// Total cost: 0.002166
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 19)]
// Total instrumented cost: 0.002166, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 291

/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * soup-auth-basic.c: HTTP Basic Authentication
 *
 * Copyright (C) 2001-2003, Ximian, Inc.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <string.h>
#include <stdio.h>

#include "soup-auth-basic.h"
#include "soup.h"

struct _SoupAuthBasic {
	SoupAuth parent;
};

typedef struct {
	char *token;
} SoupAuthBasicPrivate;

/**
 * SoupAuthBasic:
 *
 * HTTP "Basic" authentication.
 *
 * [class@Session]s support this by default; if you want to disable
 * support for it, call [method@Session.remove_feature_by_type],
 * passing %SOUP_TYPE_AUTH_BASIC.
 *
 */

G_DEFINE_FINAL_TYPE_WITH_PRIVATE (SoupAuthBasic, soup_auth_basic, SOUP_TYPE_AUTH)

static void
soup_auth_basic_init (SoupAuthBasic *basic)
{
	fprintf(stderr, "\n");
	// fprintf(stderr, "\n");
}

static void
soup_auth_basic_finalize (GObject *object)
{
	fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] enter soup_auth_basic_finalize 1\n");
	SoupAuthBasicPrivate *priv = soup_auth_basic_get_instance_private (SOUP_AUTH_BASIC (object));

	g_free (priv->token);

	G_OBJECT_CLASS (soup_auth_basic_parent_class)->finalize (object);
	// fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] exit soup_auth_basic_finalize 1\n");
}

static gboolean
soup_auth_basic_update (SoupAuth *auth, SoupMessage *msg,
			GHashTable *auth_params)
{
	fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] enter soup_auth_basic_update 1\n");
	SoupAuthBasicPrivate *priv = soup_auth_basic_get_instance_private (SOUP_AUTH_BASIC (auth));

	/* If we're updating a pre-existing auth, the
	 * username/password must be bad now, so forget it.
	 * Other than that, there's nothing to do here.
	 */
	if (priv->token) {
		fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] enter soup_auth_basic_update 2\n");
		memset (priv->token, 0, strlen (priv->token));
		g_free (priv->token);
		priv->token = NULL;
		// fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] exit soup_auth_basic_update 2\n");
	}

	return TRUE;
	// fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] exit soup_auth_basic_update 1\n");
}

static GSList *
soup_auth_basic_get_protection_space (SoupAuth *auth, GUri *source_uri)
{
	fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] enter soup_auth_basic_get_protection_space 1\n");
	char *space, *p;

	space = g_strdup (g_uri_get_path (source_uri));

	/* Strip filename component */
	p = strrchr (space, '/');
	if (p == space && p[1]) {
		fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] enter soup_auth_basic_get_protection_space 2\n");
		p[1] = '\0';
		// fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] exit soup_auth_basic_get_protection_space 2\n");
	}
	else if (p && p[1]) {
		fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] enter soup_auth_basic_get_protection_space 3\n");
		*p = '\0';
		// fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] exit soup_auth_basic_get_protection_space 3\n");
	}

	return g_slist_prepend (NULL, space);
	// fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] exit soup_auth_basic_get_protection_space 1\n");
}

static void
soup_auth_basic_authenticate (SoupAuth *auth, const char *username,
			      const char *password)
{
	fprintf(stderr, "\n");
	SoupAuthBasicPrivate *priv = soup_auth_basic_get_instance_private (SOUP_AUTH_BASIC (auth));
	char *user_pass, *user_pass_latin1;
	int len;

	user_pass = g_strdup_printf ("%s:%s", username, password);
	user_pass_latin1 = g_convert (user_pass, -1, "ISO-8859-1", "UTF-8",
				      NULL, NULL, NULL);
	if (user_pass_latin1) {
		fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] enter soup_auth_basic_authenticate 2\n");
		memset (user_pass, 0, strlen (user_pass));
		g_free (user_pass);
		user_pass = user_pass_latin1;
		// fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] exit soup_auth_basic_authenticate 2\n");
	}
	len = strlen (user_pass);

	if (priv->token) {
		fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] enter soup_auth_basic_authenticate 3\n");
		memset (priv->token, 0, strlen (priv->token));
		g_free (priv->token);
		// fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] exit soup_auth_basic_authenticate 3\n");
	}
	fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] enter soup_auth_basic_authenticate 4\n");
	priv->token = g_base64_encode ((guchar *)user_pass, len);

	memset (user_pass, 0, len);
	g_free (user_pass);
	// fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] exit soup_auth_basic_authenticate 4\n");
}

static gboolean
soup_auth_basic_is_authenticated (SoupAuth *auth)
{
	fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] enter soup_auth_basic_is_authenticated 1\n");
	SoupAuthBasicPrivate *priv = soup_auth_basic_get_instance_private (SOUP_AUTH_BASIC (auth));

	return priv->token != NULL;
	// fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] exit soup_auth_basic_is_authenticated 1\n");
}

static char *
soup_auth_basic_get_authorization (SoupAuth *auth, SoupMessage *msg)
{
	fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] enter soup_auth_basic_get_authorization 1\n");
	SoupAuthBasicPrivate *priv = soup_auth_basic_get_instance_private (SOUP_AUTH_BASIC (auth));

	return g_strdup_printf ("Basic %s", priv->token);
	// fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] exit soup_auth_basic_get_authorization 1\n");
}

static void
soup_auth_basic_class_init (SoupAuthBasicClass *auth_basic_class)
{
	fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] enter soup_auth_basic_class_init 1\n");
	SoupAuthClass *auth_class = SOUP_AUTH_CLASS (auth_basic_class);
	GObjectClass *object_class = G_OBJECT_CLASS (auth_basic_class);

	auth_class->scheme_name = "Basic";
	auth_class->strength = 1;

	auth_class->update = soup_auth_basic_update;
	auth_class->get_protection_space = soup_auth_basic_get_protection_space;
	auth_class->authenticate = soup_auth_basic_authenticate;
	auth_class->is_authenticated = soup_auth_basic_is_authenticated;
	auth_class->get_authorization = soup_auth_basic_get_authorization;

	object_class->finalize = soup_auth_basic_finalize;
	// fprintf(stderr, "[libsoup/auth/soup-auth-basic.c] exit soup_auth_basic_class_init 1\n");
}
// Total cost: 0.036850
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 149)]
// Total instrumented cost: 0.036850, input tokens: 2398, output tokens: 2035, cache read tokens: 2394, cache write tokens: 1492

/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright (C) 2000-2003, Ximian, Inc.
 */

#pragma once

#include "soup-auth.h"

SOUP_AVAILABLE_IN_ALL
G_DECLARE_FINAL_TYPE (SoupAuthDigest, soup_auth_digest, SOUP, AUTH_DIGEST, SoupAuth)
// Total cost: 0.001836
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 11)]
// Total instrumented cost: 0.001836, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 203

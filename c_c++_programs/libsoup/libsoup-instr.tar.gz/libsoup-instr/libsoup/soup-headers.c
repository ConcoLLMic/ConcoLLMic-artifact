/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * soup-headers.c: HTTP message header parsing
 *
 * Copyright (C) 2001-2003, Ximian, Inc.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "soup-misc.h"
#include "soup-headers.h"
#include "soup-message-headers-private.h"
#include "soup.h"

/**
 * soup_headers_parse:
 * @str: the header string (including the Request-Line or Status-Line,
 *   but not the trailing blank line)
 * @len: length of @str
 * @dest: #SoupMessageHeaders to store the header values in
 *
 * Parses the headers of an HTTP request or response in @str and
 * stores the results in @dest.
 *
 * Beware that @dest may be modified even on failure.
 *
 * This is a low-level method; normally you would use
 * [func@headers_parse_request] or [func@headers_parse_response].
 *
 * Returns: success or failure
 **/
gboolean
soup_headers_parse (const char *str, int len, SoupMessageHeaders *dest)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse 1\n");
	const char *headers_start;
	char *headers_copy, *name, *name_end, *value, *value_end;
	char *eol, *sol, *p;
	gsize copy_len;
	gboolean success = FALSE;

	g_return_val_if_fail (str != NULL, FALSE);
	g_return_val_if_fail (dest != NULL, FALSE);
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse 1\n");

	/* As per RFC 2616 section 19.3, we treat '\n' as the
	 * line terminator, and '\r', if it appears, merely as
	 * ignorable trailing whitespace.
	 */

	/* No '\0's are allowed */
	if (memchr (str, '\0', len)) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse 2\n");
		return FALSE;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse 2\n");
	}

	/* Skip over the Request-Line / Status-Line */
	headers_start = memchr (str, '\n', len);
	if (!headers_start) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse 3\n");
		return FALSE;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse 3\n");
	}

	/* We work on a copy of the headers, which we can write '\0's
	 * into, so that we don't have to individually g_strndup and
	 * then g_free each header name and value.
	 */
	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse 4\n");
	copy_len = len - (headers_start - str);
	headers_copy = g_malloc (copy_len + 1);
	memcpy (headers_copy, headers_start, copy_len);
	headers_copy[copy_len] = '\0';
	value_end = headers_copy;
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse 4\n");

	while (*(value_end + 1)) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse 5\n");
		name = value_end + 1;
		name_end = strchr (name, ':');

		/* Reject if there is no ':', or the header name is
		 * empty, or it contains whitespace.
		 */
		if (!name_end ||
		    name_end == name ||
		    name + strcspn (name, " \t\r\n") < name_end) {
			fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse 6\n");
			/* Ignore this line. Note that if it has
			 * continuation lines, we'll end up ignoring
			 * them too since they'll start with spaces.
			 */
			value_end = strchr (name, '\n');
			if (!value_end) {
				fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse 7\n");
				goto done;
				// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse 7\n");
			}
			// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse 6\n");
			continue;
		}

		/* Find the end of the value; ie, an end-of-line that
		 * isn't followed by a continuation line.
		 */
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse 8\n");
		value = name_end + 1;
		value_end = strchr (name, '\n');
		if (!value_end) {
			fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse 9\n");
			goto done;
			// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse 9\n");
		}
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse 8\n");
		
		while (*(value_end + 1) == ' ' || *(value_end + 1) == '\t') {
			fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse 10\n");
			value_end = strchr (value_end + 1, '\n');
			if (!value_end) {
				fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse 11\n");
				goto done;
				// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse 11\n");
			}
			// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse 10\n");
		}

		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse 12\n");
		*name_end = '\0';
		*value_end = '\0';

		/* Skip leading whitespace */
		while (value < value_end &&
		       (*value == ' ' || *value == '\t' ||
			*value == '\r' || *value == '\n'))
			value++;

		/* Collapse continuation lines */
		while ((eol = strchr (value, '\n'))) {
			fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse 13\n");
			/* find start of next line */
			sol = eol + 1;
			while (*sol == ' ' || *sol == '\t')
				sol++;

			/* back up over trailing whitespace on current line */
			while (eol[-1] == ' ' || eol[-1] == '\t' || eol[-1] == '\r')
				eol--;

			/* Delete all but one SP */
			*eol = ' ';
			memmove (eol + 1, sol, strlen (sol) + 1);
			// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse 13\n");
		}

		/* clip trailing whitespace */
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse 14\n");
		eol = strchr (value, '\0');
		while (eol > value &&
		       (eol[-1] == ' ' || eol[-1] == '\t' || eol[-1] == '\r'))
			eol--;
		*eol = '\0';

		/* convert (illegal) '\r's to spaces */
		for (p = strchr (value, '\r'); p; p = strchr (p, '\r'))
			*p = ' ';

		soup_message_headers_append_untrusted_data (dest, name, value);
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse 14\n");
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse 12\n");
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse 5\n");
        }
	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse 15\n");
	success = TRUE;
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse 15\n");

done:
	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse 16\n");
	g_free (headers_copy);
	return success;
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse 16\n");
}

/**
 * soup_headers_parse_request:
 * @str: the headers (up to, but not including, the trailing blank line)
 * @len: length of @str
 * @req_headers: #SoupMessageHeaders to store the header values in
 * @req_method: (out) (optional): if non-%NULL, will be filled in with the
 *   request method
 * @req_path: (out) (optional): if non-%NULL, will be filled in with the
 *   request path
 * @ver: (out) (optional): if non-%NULL, will be filled in with the HTTP
 *   version
 *
 * Parses the headers of an HTTP request in @str and stores the
 * results in @req_method, @req_path, @ver, and @req_headers.
 *
 * Beware that @req_headers may be modified even on failure.
 *
 * Returns: %SOUP_STATUS_OK if the headers could be parsed, or an
 *   HTTP error to be returned to the client if they could not be.
 **/
guint
soup_headers_parse_request (const char          *str, 
			    int                  len, 
			    SoupMessageHeaders  *req_headers,
			    char               **req_method,
			    char               **req_path,
			    SoupHTTPVersion     *ver) 
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_request 1\n");
	const char *method, *method_end, *path, *path_end;
	const char *version, *version_end, *headers;
	unsigned long major_version, minor_version;
	char *p;

	g_return_val_if_fail (str != NULL, SOUP_STATUS_BAD_REQUEST);

	/* RFC 2616 4.1 "servers SHOULD ignore any empty line(s)
	 * received where a Request-Line is expected."
	 */
	while (len > 0 && (*str == '\r' || *str == '\n')) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_request 2\n");
		str++;
		len--;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_request 2\n");
	}
	if (!len) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_request 3\n");
		return SOUP_STATUS_BAD_REQUEST;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_request 3\n");
	}

	/* RFC 2616 19.3 "[servers] SHOULD accept any amount of SP or
	 * HT characters between [Request-Line] fields"
	 */

	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_request 4\n");
	method = method_end = str;
	while (method_end < str + len && *method_end != ' ' && *method_end != '\t')
		method_end++;
	if (method_end >= str + len) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_request 5\n");
		return SOUP_STATUS_BAD_REQUEST;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_request 5\n");
	}

	path = method_end;
	while (path < str + len && (*path == ' ' || *path == '\t'))
		path++;
	if (path >= str + len) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_request 6\n");
		return SOUP_STATUS_BAD_REQUEST;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_request 6\n");
	}

	path_end = path;
	while (path_end < str + len && *path_end != ' ' && *path_end != '\t')
		path_end++;
	if (path_end >= str + len) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_request 7\n");
		return SOUP_STATUS_BAD_REQUEST;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_request 7\n");
	}

	version = path_end;
	while (version < str + len && (*version == ' ' || *version == '\t'))
		version++;
	if (version + 8 >= str + len) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_request 8\n");
		return SOUP_STATUS_BAD_REQUEST;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_request 8\n");
	}

	if (strncmp (version, "HTTP/", 5) != 0 ||
	    !g_ascii_isdigit (version[5])) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_request 9\n");
		return SOUP_STATUS_BAD_REQUEST;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_request 9\n");
	}
	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_request 10\n");
	major_version = strtoul (version + 5, &p, 10);
	if (p + 1 >= str + len || *p != '.' || !g_ascii_isdigit (p[1])) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_request 11\n");
		return SOUP_STATUS_BAD_REQUEST;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_request 11\n");
	}
	minor_version = strtoul (p + 1, &p, 10);
	version_end = p;
	if (major_version != 1) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_request 12\n");
		return SOUP_STATUS_HTTP_VERSION_NOT_SUPPORTED;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_request 12\n");
	}
	if (minor_version > 1) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_request 13\n");
		return SOUP_STATUS_HTTP_VERSION_NOT_SUPPORTED;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_request 13\n");
	}
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_request 10\n");

	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_request 14\n");
	headers = version_end;
	while (headers < str + len && (*headers == '\r' || *headers == ' '))
		headers++;
	if (headers >= str + len || *headers != '\n') {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_request 15\n");
		return SOUP_STATUS_BAD_REQUEST;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_request 15\n");
	}

	if (!soup_headers_parse (str, len, req_headers)) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_request 16\n");
		return SOUP_STATUS_BAD_REQUEST;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_request 16\n");
	}

	if (soup_message_headers_get_expectations (req_headers) &
	    SOUP_EXPECTATION_UNRECOGNIZED) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_request 17\n");
		return SOUP_STATUS_EXPECTATION_FAILED;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_request 17\n");
	}
	/* RFC 2616 14.10 */
	if (minor_version == 0) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_request 18\n");
		soup_message_headers_clean_connection_headers (req_headers);
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_request 18\n");
	}

	if (req_method) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_request 19\n");
		*req_method = g_strndup (method, method_end - method);
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_request 19\n");
	}
	if (req_path) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_request 20\n");
		*req_path = g_strndup (path, path_end - path);
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_request 20\n");
	}
	if (ver) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_request 21\n");
		*ver = (minor_version == 0) ? SOUP_HTTP_1_0 : SOUP_HTTP_1_1;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_request 21\n");
	}
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_request 14\n");

	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_request 22\n");
	return SOUP_STATUS_OK;
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_request 22\n");
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_request 4\n");
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_request 1\n");
}

/**
 * soup_headers_parse_status_line:
 * @status_line: an HTTP Status-Line
 * @ver: (out) (optional): if non-%NULL, will be filled in with the HTTP
 *   version
 * @status_code: (out) (optional): if non-%NULL, will be filled in with
 *   the status code
 * @reason_phrase: (out) (optional): if non-%NULL, will be filled in with
 *   the reason phrase
 *
 * Parses the HTTP Status-Line string in @status_line into @ver,
 * @status_code, and @reason_phrase.
 *
 * @status_line must be terminated by either "\0" or "\r\n".
 *
 * Returns: %TRUE if @status_line was parsed successfully.
 **/
gboolean
soup_headers_parse_status_line (const char       *status_line,
				SoupHTTPVersion  *ver,
				guint            *status_code,
				char            **reason_phrase)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_status_line 1\n");
	unsigned long major_version, minor_version, code;
	const char *code_start, *code_end, *phrase_start, *phrase_end;
	char *p;

	g_return_val_if_fail (status_line != NULL, FALSE);

	if (strncmp (status_line, "HTTP/", 5) == 0 &&
	    g_ascii_isdigit (status_line[5])) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_status_line 2\n");
		major_version = strtoul (status_line + 5, &p, 10);
		if (*p != '.' || !g_ascii_isdigit (p[1])) {
			fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_status_line 3\n");
			return FALSE;
			// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_status_line 3\n");
		}
		minor_version = strtoul (p + 1, &p, 10);
		if (major_version != 1) {
			fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_status_line 4\n");
			return FALSE;
			// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_status_line 4\n");
		}
		if (minor_version > 1) {
			fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_status_line 5\n");
			return FALSE;
			// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_status_line 5\n");
		}
		if (ver) {
			fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_status_line 6\n");
			*ver = (minor_version == 0) ? SOUP_HTTP_1_0 : SOUP_HTTP_1_1;
			// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_status_line 6\n");
		}
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_status_line 2\n");
	} else if (!strncmp (status_line, "ICY", 3)) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_status_line 7\n");
		/* Shoutcast not-quite-HTTP format */
		if (ver) {
			fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_status_line 8\n");
			*ver = SOUP_HTTP_1_0;
			// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_status_line 8\n");
		}
		p = (char *)status_line + 3;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_status_line 7\n");
	} else {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_status_line 9\n");
		return FALSE;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_status_line 9\n");
	}

	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_status_line 10\n");
	code_start = p;
	while (*code_start == ' ' || *code_start == '\t')
		code_start++;
	code_end = code_start;
	while (*code_end >= '0' && *code_end <= '9')
		code_end++;
	if (code_end != code_start + 3) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_status_line 11\n");
		return FALSE;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_status_line 11\n");
	}
	code = atoi (code_start);
	if (code < 100 || code > 999) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_status_line 12\n");
		return FALSE;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_status_line 12\n");
	}
	if (status_code) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_status_line 13\n");
		*status_code = code;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_status_line 13\n");
	}

	phrase_start = code_end;
	while (*phrase_start == ' ' || *phrase_start == '\t')
		phrase_start++;
	phrase_end = phrase_start + strcspn (phrase_start, "\n");
	while (phrase_end > phrase_start &&
	       (phrase_end[-1] == '\r' || phrase_end[-1] == ' ' || phrase_end[-1] == '\t'))
		phrase_end--;
	if (reason_phrase) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_status_line 14\n");
		*reason_phrase = g_strndup (phrase_start, phrase_end - phrase_start);
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_status_line 14\n");
	}
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_status_line 10\n");

	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_status_line 15\n");
	return TRUE;
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_status_line 15\n");
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_status_line 1\n");
}

/**
 * soup_headers_parse_response:
 * @str: the headers (up to, but not including, the trailing blank line)
 * @len: length of @str
 * @headers: #SoupMessageHeaders to store the header values in
 * @ver: (out) (optional): if non-%NULL, will be filled in with the HTTP
 *   version
 * @status_code: (out) (optional): if non-%NULL, will be filled in with
 *   the status code
 * @reason_phrase: (out) (optional): if non-%NULL, will be filled in with
 *   the reason phrase
 *
 * Parses the headers of an HTTP response in @str and stores the
 * results in @ver, @status_code, @reason_phrase, and @headers.
 *
 * Beware that @headers may be modified even on failure.
 *
 * Returns: success or failure.
 **/
gboolean
soup_headers_parse_response (const char          *str, 
			     int                  len, 
			     SoupMessageHeaders  *headers,
			     SoupHTTPVersion     *ver,
			     guint               *status_code,
			     char               **reason_phrase)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_response 1\n");
	SoupHTTPVersion version;

	g_return_val_if_fail (str != NULL, FALSE);

	/* Workaround for broken servers that send extra line breaks
	 * after a response, which we then see prepended to the next
	 * response on that connection.
	 */
	while (len > 0 && (*str == '\r' || *str == '\n')) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_response 2\n");
		str++;
		len--;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_response 2\n");
	}
	if (!len) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_response 3\n");
		return FALSE;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_response 3\n");
	}

	if (!soup_headers_parse (str, len, headers)) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_response 4\n");
		return FALSE;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_response 4\n");
	}

	if (!soup_headers_parse_status_line (str, 
					     &version, 
					     status_code, 
					     reason_phrase)) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_response 5\n");
		return FALSE;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_response 5\n");
	}
	if (ver) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_response 6\n");
		*ver = version;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_response 6\n");
	}

	/* RFC 2616 14.10 */
	if (version == SOUP_HTTP_1_0) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_response 7\n");
		soup_message_headers_clean_connection_headers (headers);
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_response 7\n");
	}

	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_headers_parse_response 8\n");
	return TRUE;
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_response 8\n");
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_headers_parse_response 1\n");
}


/*
 * Parsing of specific HTTP header types
 */

static const char *
skip_lws (const char *s)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter skip_lws 1\n");
	while (g_ascii_isspace (*s))
		s++;
	return s;
	// fprintf(stderr, "[libsoup/soup-headers.c] exit skip_lws 1\n");
}

static const char *
unskip_lws (const char *s, const char *start)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter unskip_lws 1\n");
	while (s > start && g_ascii_isspace (*(s - 1)))
		s--;
	return s;
	// fprintf(stderr, "[libsoup/soup-headers.c] exit unskip_lws 1\n");
}

static const char *
skip_delims (const char *s, char delim)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter skip_delims 1\n");
	/* The grammar allows for multiple delimiters */
	while (g_ascii_isspace (*s) || *s == delim)
		s++;
	return s;
	// fprintf(stderr, "[libsoup/soup-headers.c] exit skip_delims 1\n");
}

static const char *
skip_item (const char *s, char delim)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter skip_item 1\n");
	gboolean quoted = FALSE;
	const char *start = s;

	/* A list item ends at the last non-whitespace character
	 * before a delimiter which is not inside a quoted-string. Or
	 * at the end of the string.
	 */

	while (*s) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter skip_item 2\n");
		if (*s == '"') {
			fprintf(stderr, "[libsoup/soup-headers.c] enter skip_item 3\n");
			quoted = !quoted;
			// fprintf(stderr, "[libsoup/soup-headers.c] exit skip_item 3\n");
		} else if (quoted) {
			fprintf(stderr, "[libsoup/soup-headers.c] enter skip_item 4\n");
			if (*s == '\\' && *(s + 1)) {
				fprintf(stderr, "[libsoup/soup-headers.c] enter skip_item 5\n");
				s++;
				// fprintf(stderr, "[libsoup/soup-headers.c] exit skip_item 5\n");
			}
			// fprintf(stderr, "[libsoup/soup-headers.c] exit skip_item 4\n");
		} else {
			fprintf(stderr, "[libsoup/soup-headers.c] enter skip_item 6\n");
			if (*s == delim) {
				fprintf(stderr, "[libsoup/soup-headers.c] enter skip_item 7\n");
				break;
				// fprintf(stderr, "[libsoup/soup-headers.c] exit skip_item 7\n");
			}
			// fprintf(stderr, "[libsoup/soup-headers.c] exit skip_item 6\n");
		}
		s++;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit skip_item 2\n");
	}

	fprintf(stderr, "[libsoup/soup-headers.c] enter skip_item 8\n");
	return unskip_lws (s, start);
	// fprintf(stderr, "[libsoup/soup-headers.c] exit skip_item 8\n");
	// fprintf(stderr, "[libsoup/soup-headers.c] exit skip_item 1\n");
}

static GSList *
parse_list (const char *header, char delim)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter parse_list 1\n");
	GSList *list = NULL;
	const char *end;

	header = skip_delims (header, delim);
	while (*header) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter parse_list 2\n");
		end = skip_item (header, delim);
		list = g_slist_prepend (list, g_strndup (header, end - header));
		header = skip_delims (end, delim);
		// fprintf(stderr, "[libsoup/soup-headers.c] exit parse_list 2\n");
	}

	fprintf(stderr, "[libsoup/soup-headers.c] enter parse_list 3\n");
	return g_slist_reverse (list);
	// fprintf(stderr, "[libsoup/soup-headers.c] exit parse_list 3\n");
	// fprintf(stderr, "[libsoup/soup-headers.c] exit parse_list 1\n");
}

/**
 * soup_header_parse_list:
 * @header: a header value
 *
 * Parses a header whose content is described by RFC2616 as `#something`.
 *
 * "something" does not itself contain commas, except as part of quoted-strings.
 *
 * Returns: (transfer full) (element-type utf8): a #GSList of
 *   list elements, as allocated strings
 **/
GSList *
soup_header_parse_list (const char *header)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_list 1\n");
	g_return_val_if_fail (header != NULL, NULL);

	return parse_list (header, ',');
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_list 1\n");
}

typedef struct {
	char *item;
	double qval;
} QualityItem;

static int
sort_by_qval (const void *a, const void *b)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter sort_by_qval 1\n");
	QualityItem *qia = (QualityItem *)a;
	QualityItem *qib = (QualityItem *)b;

	if (qia->qval == qib->qval) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter sort_by_qval 2\n");
		return 0;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit sort_by_qval 2\n");
	} else if (qia->qval < qib->qval) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter sort_by_qval 3\n");
		return 1;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit sort_by_qval 3\n");
	} else {
		fprintf(stderr, "[libsoup/soup-headers.c] enter sort_by_qval 4\n");
		return -1;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit sort_by_qval 4\n");
	}
	// fprintf(stderr, "[libsoup/soup-headers.c] exit sort_by_qval 1\n");
}

/**
 * soup_header_parse_quality_list:
 * @header: a header value
 * @unacceptable: (out) (optional) (transfer full) (element-type utf8): on
 *   return, will contain a list of unacceptable values
 *
 * Parses a header whose content is a list of items with optional
 * "qvalue"s (eg, Accept, Accept-Charset, Accept-Encoding,
 * Accept-Language, TE).
 *
 * If @unacceptable is not %NULL, then on return, it will contain the
 * items with qvalue 0. Either way, those items will be removed from
 * the main list.
 *
 * Returns: (transfer full) (element-type utf8): a #GSList of
 *   acceptable values (as allocated strings), highest-qvalue first.
 **/
GSList *
soup_header_parse_quality_list (const char *header, GSList **unacceptable)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_quality_list 1\n");
	GSList *unsorted;
	QualityItem *array;
	GSList *sorted, *iter;
	char *semi;
	const char *param, *equal, *value;
	double qval;
	int n;

	g_return_val_if_fail (header != NULL, NULL);

	if (unacceptable) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_quality_list 2\n");
		*unacceptable = NULL;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_quality_list 2\n");
	}

	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_quality_list 3\n");
	unsorted = soup_header_parse_list (header);
	array = g_new0 (QualityItem, g_slist_length (unsorted));
	for (iter = unsorted, n = 0; iter; iter = iter->next) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_quality_list 4\n");
		qval = 1.0;
		for (semi = strchr (iter->data, ';'); semi; semi = strchr (semi + 1, ';')) {
			fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_quality_list 5\n");
			param = skip_lws (semi + 1);
			if (*param != 'q') {
				fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_quality_list 6\n");
				continue;
				// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_quality_list 6\n");
			}
			equal = skip_lws (param + 1);
			if (!equal || *equal != '=') {
				fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_quality_list 7\n");
				continue;
				// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_quality_list 7\n");
			}
			value = skip_lws (equal + 1);
			if (!value) {
				fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_quality_list 8\n");
				continue;
				// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_quality_list 8\n");
			}

			if (value[0] != '0' && value[0] != '1') {
				fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_quality_list 9\n");
				continue;
				// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_quality_list 9\n");
			}
			fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_quality_list 10\n");
			qval = (double)(value[0] - '0');
			if (value[0] == '0' && value[1] == '.') {
				fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_quality_list 11\n");
				if (g_ascii_isdigit (value[2])) {
					fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_quality_list 12\n");
					qval += (double)(value[2] - '0') / 10;
					if (g_ascii_isdigit (value[3])) {
						fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_quality_list 13\n");
						qval += (double)(value[3] - '0') / 100;
						if (g_ascii_isdigit (value[4])) {
							fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_quality_list 14\n");
							qval += (double)(value[4] - '0') / 1000;
							// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_quality_list 14\n");
						}
						// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_quality_list 13\n");
					}
					// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_quality_list 12\n");
				}
				// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_quality_list 11\n");
			}
			// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_quality_list 10\n");

			fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_quality_list 15\n");
			*semi = '\0';
			break;
			// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_quality_list 15\n");
			// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_quality_list 5\n");
		}

		if (qval == 0.0) {
			fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_quality_list 16\n");
			if (unacceptable) {
				fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_quality_list 17\n");
				*unacceptable = g_slist_prepend (*unacceptable,
								 g_steal_pointer (&iter->data));
				// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_quality_list 17\n");
			}
			// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_quality_list 16\n");
		} else {
			fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_quality_list 18\n");
			array[n].item = g_steal_pointer (&iter->data);
			array[n].qval = qval;
			n++;
			// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_quality_list 18\n");
		}
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_quality_list 4\n");
	}
	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_quality_list 19\n");
	g_slist_free_full (unsorted, g_free);

	qsort (array, n, sizeof (QualityItem), sort_by_qval);
	sorted = NULL;
	while (n--) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_quality_list 20\n");
		sorted = g_slist_prepend (sorted, array[n].item);
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_quality_list 20\n");
	}
	g_free (array);
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_quality_list 19\n");

	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_quality_list 21\n");
	return sorted;
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_quality_list 21\n");
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_quality_list 3\n");
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_quality_list 1\n");
}

/**
 * soup_header_free_list: (skip)
 * @list: a #GSList returned from [func@header_parse_list] or
 * [func@header_parse_quality_list]
 *
 * Frees @list.
 **/
void
soup_header_free_list (GSList *list)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_free_list 1\n");
	g_slist_free_full (list, g_free);
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_free_list 1\n");
}

/**
 * soup_header_contains:
 * @header: An HTTP header suitable for parsing with
 *   [func@header_parse_list]
 * @token: a token
 *
 * Parses @header to see if it contains the token @token (matched
 * case-insensitively).
 *
 * Note that this can't be used with lists that have qvalues.
 *
 * Returns: whether or not @header contains @token
 **/
gboolean
soup_header_contains (const char *header, const char *token)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_contains 1\n");
	const char *end;
	guint len;

	g_return_val_if_fail (header != NULL, FALSE);
	g_return_val_if_fail (token != NULL, FALSE);

	len = strlen (token);

	header = skip_delims (header, ',');
	while (*header) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_contains 2\n");
		end = skip_item (header, ',');
		if (end - header == len &&
		    !g_ascii_strncasecmp (header, token, len)) {
			fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_contains 3\n");
			return TRUE;
			// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_contains 3\n");
		}
		header = skip_delims (end, ',');
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_contains 2\n");
	}

	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_contains 4\n");
	return FALSE;
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_contains 4\n");
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_contains 1\n");
}

static void
decode_quoted_string_inplace (GString *quoted_gstring)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter decode_quoted_string_inplace 1\n");
	char *quoted_string = quoted_gstring->str;
	char *src, *dst;

	src = quoted_string + 1;
	dst = quoted_string;
	while (*src && *src != '"') {
		fprintf(stderr, "[libsoup/soup-headers.c] enter decode_quoted_string_inplace 2\n");
		if (*src == '\\' && *(src + 1)) {
			fprintf(stderr, "[libsoup/soup-headers.c] enter decode_quoted_string_inplace 3\n");
			src++;
			// fprintf(stderr, "[libsoup/soup-headers.c] exit decode_quoted_string_inplace 3\n");
		}
		*dst++ = *src++;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit decode_quoted_string_inplace 2\n");
	}
	fprintf(stderr, "[libsoup/soup-headers.c] enter decode_quoted_string_inplace 4\n");
	*dst = '\0';
	// fprintf(stderr, "[libsoup/soup-headers.c] exit decode_quoted_string_inplace 4\n");
	// fprintf(stderr, "[libsoup/soup-headers.c] exit decode_quoted_string_inplace 1\n");
}

static gboolean
decode_rfc5987_inplace (GString *encoded_gstring)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter decode_rfc5987_inplace 1\n");
	char *q, *decoded;
	gboolean iso_8859_1 = FALSE;
	const char *encoded_string = encoded_gstring->str;

	q = strchr (encoded_string, '\'');
	if (!q) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter decode_rfc5987_inplace 2\n");
		return FALSE;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit decode_rfc5987_inplace 2\n");
	}
	if (g_ascii_strncasecmp (encoded_string, "UTF-8",
				 q - encoded_string) == 0) {
		fprintf(stderr, "\n");
		// fprintf(stderr, "\n");
	} else if (g_ascii_strncasecmp (encoded_string, "iso-8859-1",
				      q - encoded_string) == 0) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter decode_rfc5987_inplace 4\n");
		iso_8859_1 = TRUE;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit decode_rfc5987_inplace 4\n");
	} else {
		fprintf(stderr, "[libsoup/soup-headers.c] enter decode_rfc5987_inplace 5\n");
		return FALSE;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit decode_rfc5987_inplace 5\n");
	}

	fprintf(stderr, "[libsoup/soup-headers.c] enter decode_rfc5987_inplace 6\n");
	q = strchr (q + 1, '\'');
	if (!q) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter decode_rfc5987_inplace 7\n");
		return FALSE;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit decode_rfc5987_inplace 7\n");
	}

	decoded = g_uri_unescape_string (q + 1, NULL);
	if (decoded == NULL) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter decode_rfc5987_inplace 8\n");
		return FALSE;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit decode_rfc5987_inplace 8\n");
	}

	if (iso_8859_1) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter decode_rfc5987_inplace 9\n");
		char *utf8 =  g_convert_with_fallback (decoded, -1, "UTF-8",
						       "iso-8859-1", "_",
						       NULL, NULL, NULL);
		g_free (decoded);
		if (!utf8) {
			fprintf(stderr, "[libsoup/soup-headers.c] enter decode_rfc5987_inplace 10\n");
			return FALSE;
			// fprintf(stderr, "[libsoup/soup-headers.c] exit decode_rfc5987_inplace 10\n");
		}
		decoded = utf8;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit decode_rfc5987_inplace 9\n");
	}

	fprintf(stderr, "[libsoup/soup-headers.c] enter decode_rfc5987_inplace 11\n");
	g_string_assign (encoded_gstring, decoded);
	g_free (decoded);
	return TRUE;
	// fprintf(stderr, "[libsoup/soup-headers.c] exit decode_rfc5987_inplace 11\n");
	// fprintf(stderr, "[libsoup/soup-headers.c] exit decode_rfc5987_inplace 6\n");
	// fprintf(stderr, "[libsoup/soup-headers.c] exit decode_rfc5987_inplace 1\n");
}

static GHashTable *
parse_param_list (const char *header, char delim, gboolean strict)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter parse_param_list 1\n");
	GHashTable *params;
	GSList *list, *iter;

	params = g_hash_table_new_full (soup_str_case_hash, 
					soup_str_case_equal,
					g_free, g_free);

	list = parse_list (header, delim);
	for (iter = list; iter; iter = iter->next) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter parse_param_list 2\n");
		char *item, *eq, *name_end;
		gboolean override, duplicated;
		GString *parsed_value = NULL;

		item = iter->data;
		override = FALSE;

		eq = strchr (item, '=');
		if (eq) {
			fprintf(stderr, "[libsoup/soup-headers.c] enter parse_param_list 3\n");
			name_end = (char *)unskip_lws (eq, item);
			if (name_end == item) {
				fprintf(stderr, "[libsoup/soup-headers.c] enter parse_param_list 4\n");
				/* That's no good... */
				g_free (item);
				continue;
				// fprintf(stderr, "[libsoup/soup-headers.c] exit parse_param_list 4\n");
			}

			*name_end = '\0';

			parsed_value = g_string_new ((char *)skip_lws (eq + 1));

			if (name_end[-1] == '*' && name_end > item + 1) {
				fprintf(stderr, "[libsoup/soup-headers.c] enter parse_param_list 5\n");
				name_end[-1] = '\0';
				if (!decode_rfc5987_inplace (parsed_value)) {
					fprintf(stderr, "[libsoup/soup-headers.c] enter parse_param_list 6\n");
					g_string_free (parsed_value, TRUE);
					g_free (item);
					continue;
					// fprintf(stderr, "[libsoup/soup-headers.c] exit parse_param_list 6\n");
				}
				override = TRUE;
				// fprintf(stderr, "[libsoup/soup-headers.c] exit parse_param_list 5\n");
			} else if (parsed_value->str[0] == '"') {
				fprintf(stderr, "[libsoup/soup-headers.c] enter parse_param_list 7\n");
				decode_quoted_string_inplace (parsed_value);
				// fprintf(stderr, "[libsoup/soup-headers.c] exit parse_param_list 7\n");
			}
			// fprintf(stderr, "[libsoup/soup-headers.c] exit parse_param_list 3\n");
		}

		fprintf(stderr, "[libsoup/soup-headers.c] enter parse_param_list 8\n");
		duplicated = g_hash_table_lookup_extended (params, item, NULL, NULL);

		if (strict && duplicated) {
			fprintf(stderr, "[libsoup/soup-headers.c] enter parse_param_list 9\n");
			soup_header_free_param_list (params);
			params = NULL;
			g_slist_foreach (iter, (GFunc)g_free, NULL);
			if (parsed_value)
				g_string_free (parsed_value, TRUE);
			break;
			// fprintf(stderr, "[libsoup/soup-headers.c] exit parse_param_list 9\n");
		} else if (override || !duplicated) {
			fprintf(stderr, "[libsoup/soup-headers.c] enter parse_param_list 10\n");
			g_hash_table_replace (params, item, parsed_value ? g_string_free (parsed_value, FALSE) : NULL);
			// fprintf(stderr, "[libsoup/soup-headers.c] exit parse_param_list 10\n");
		} else {
			fprintf(stderr, "[libsoup/soup-headers.c] enter parse_param_list 11\n");
			if (parsed_value)
				g_string_free (parsed_value, TRUE);
			g_free (item);
			// fprintf(stderr, "[libsoup/soup-headers.c] exit parse_param_list 11\n");
		}
		// fprintf(stderr, "[libsoup/soup-headers.c] exit parse_param_list 8\n");
		// fprintf(stderr, "[libsoup/soup-headers.c] exit parse_param_list 2\n");
	}

	fprintf(stderr, "[libsoup/soup-headers.c] enter parse_param_list 12\n");
	g_slist_free (list);
	return params;
	// fprintf(stderr, "[libsoup/soup-headers.c] exit parse_param_list 12\n");
	// fprintf(stderr, "[libsoup/soup-headers.c] exit parse_param_list 1\n");
}

/**
 * soup_header_parse_param_list:
 * @header: a header value
 *
 * Parses a header which is a comma-delimited list of something like:
 * `token [ "=" ( token | quoted-string ) ]`.
 *
 * Tokens that don't have an associated value will still be added to
 * the resulting hash table, but with a %NULL value.
 * 
 * This also handles RFC5987 encoding (which in HTTP is mostly used
 * for giving UTF8-encoded filenames in the Content-Disposition
 * header).
 *
 * Returns: (element-type utf8 utf8) (transfer full): a
 *   #GHashTable of list elements, which can be freed with
 *   [func@header_free_param_list].
 **/
GHashTable *
soup_header_parse_param_list (const char *header)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_param_list 1\n");
	g_return_val_if_fail (header != NULL, NULL);

	return parse_param_list (header, ',', FALSE);
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_param_list 1\n");
}

/**
 * soup_header_parse_semi_param_list:
 * @header: a header value
 *
 * Parses a header which is a semicolon-delimited list of something
 * like: `token [ "=" ( token | quoted-string ) ]`.
 *
 * Tokens that don't have an associated value will still be added to
 * the resulting hash table, but with a %NULL value.
 * 
 * This also handles RFC5987 encoding (which in HTTP is mostly used
 * for giving UTF8-encoded filenames in the Content-Disposition
 * header).
 *
 * Returns: (element-type utf8 utf8) (transfer full): a
 *   #GHashTable of list elements, which can be freed with
 *   [func@header_free_param_list].
 **/
GHashTable *
soup_header_parse_semi_param_list (const char *header)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_semi_param_list 1\n");
	g_return_val_if_fail (header != NULL, NULL);

	return parse_param_list (header, ';', FALSE);
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_semi_param_list 1\n");
}

/**
 * soup_header_parse_param_list_strict:
 * @header: a header value
 *
 * A strict version of [func@header_parse_param_list]
 * that bails out if there are duplicate parameters.
 *
 * Note that this function will treat RFC5987-encoded
 * parameters as duplicated if an ASCII version is also
 * present. For header fields that might contain
 * RFC5987-encoded parameters, use
 * [func@header_parse_param_list] instead.
 *
 * Returns: (element-type utf8 utf8) (transfer full) (nullable):
 *   a #GHashTable of list elements, which can be freed with
 *   [func@header_free_param_list] or %NULL if there are duplicate
 *   elements.
 **/
GHashTable *
soup_header_parse_param_list_strict (const char *header)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_param_list_strict 1\n");
	g_return_val_if_fail (header != NULL, NULL);

	return parse_param_list (header, ',', TRUE);
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_param_list_strict 1\n");
}

/**
 * soup_header_parse_semi_param_list_strict:
 * @header: a header value
 *
 * A strict version of [func@header_parse_semi_param_list]
 * that bails out if there are duplicate parameters.
 *
 * Note that this function will treat RFC5987-encoded
 * parameters as duplicated if an ASCII version is also
 * present. For header fields that might contain
 * RFC5987-encoded parameters, use
 * [func@header_parse_semi_param_list] instead.
 *
 * Returns: (element-type utf8 utf8) (transfer full) (nullable):
 *   a #GHashTable of list elements, which can be freed with
 *   [func@header_free_param_list] or %NULL if there are duplicate
 *   elements.
 **/
GHashTable *
soup_header_parse_semi_param_list_strict (const char *header)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_parse_semi_param_list_strict 1\n");
	g_return_val_if_fail (header != NULL, NULL);

	return parse_param_list (header, ';', TRUE);
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_parse_semi_param_list_strict 1\n");
}

/**
 * soup_header_free_param_list:
 * @param_list: (element-type utf8 utf8): a #GHashTable returned from
 *   [func@header_parse_param_list] or [func@header_parse_semi_param_list]
 *
 * Frees @param_list.
 **/
void
soup_header_free_param_list (GHashTable *param_list)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_free_param_list 1\n");
	g_return_if_fail (param_list != NULL);

	g_hash_table_destroy (param_list);
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_free_param_list 1\n");
}

static void
append_param_rfc5987 (GString    *string,
		      const char *name,
		      const char *value)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter append_param_rfc5987 1\n");
	char *encoded;

	g_string_append (string, name);
	g_string_append (string, "*=UTF-8''");
	encoded = g_uri_escape_string (value, "!#$&+-.^_`|~", FALSE);
	g_string_append (string, encoded);
	g_free (encoded);
	// fprintf(stderr, "[libsoup/soup-headers.c] exit append_param_rfc5987 1\n");
}

static void
append_param_quoted (GString    *string,
		     const char *name,
		     const char *value)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter append_param_quoted 1\n");
	gsize len;

	g_string_append (string, name);
	g_string_append (string, "=\"");
	while (*value) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter append_param_quoted 2\n");
		while (*value == '\\' || *value == '"') {
			fprintf(stderr, "[libsoup/soup-headers.c] enter append_param_quoted 3\n");
			g_string_append_c (string, '\\');
			g_string_append_c (string, *value++);
			// fprintf(stderr, "[libsoup/soup-headers.c] exit append_param_quoted 3\n");
		}
		len = strcspn (value, "\\\"");
		g_string_append_len (string, value, len);
		value += len;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit append_param_quoted 2\n");
	}
	g_string_append_c (string, '"');
	// fprintf(stderr, "[libsoup/soup-headers.c] exit append_param_quoted 1\n");
}

static void
append_param_internal (GString    *string,
		       const char *name,
		       const char *value,
		       gboolean    allow_token)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter append_param_internal 1\n");
	const char *v;
	gboolean use_token = allow_token;

	for (v = value; *v; v++) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter append_param_internal 2\n");
		if (*v & 0x80) {
			fprintf(stderr, "[libsoup/soup-headers.c] enter append_param_internal 3\n");
			if (g_utf8_validate (value, -1, NULL)) {
				fprintf(stderr, "[libsoup/soup-headers.c] enter append_param_internal 4\n");
				append_param_rfc5987 (string, name, value);
				return;
				// fprintf(stderr, "[libsoup/soup-headers.c] exit append_param_internal 4\n");
			} else {
				fprintf(stderr, "[libsoup/soup-headers.c] enter append_param_internal 5\n");
				use_token = FALSE;
				// fprintf(stderr, "[libsoup/soup-headers.c] exit append_param_internal 5\n");
			}
			// fprintf(stderr, "[libsoup/soup-headers.c] exit append_param_internal 3\n");
		} else if (!soup_char_is_token (*v)) {
			fprintf(stderr, "[libsoup/soup-headers.c] enter append_param_internal 6\n");
			use_token = FALSE;
			// fprintf(stderr, "[libsoup/soup-headers.c] exit append_param_internal 6\n");
		}
		// fprintf(stderr, "[libsoup/soup-headers.c] exit append_param_internal 2\n");
	}

	if (use_token) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter append_param_internal 7\n");
		g_string_append (string, name);
		g_string_append_c (string, '=');
		g_string_append (string, value);
		// fprintf(stderr, "[libsoup/soup-headers.c] exit append_param_internal 7\n");
	} else {
		fprintf(stderr, "[libsoup/soup-headers.c] enter append_param_internal 8\n");
		append_param_quoted (string, name, value);
		// fprintf(stderr, "[libsoup/soup-headers.c] exit append_param_internal 8\n");
	}
	// fprintf(stderr, "[libsoup/soup-headers.c] exit append_param_internal 1\n");
}

/**
 * soup_header_g_string_append_param_quoted:
 * @string: a #GString being used to construct an HTTP header value
 * @name: a parameter name
 * @value: a parameter value
 *
 * Appends something like `name="value"` to
 * @string, taking care to escape any quotes or backslashes in @value.
 *
 * If @value is (non-ASCII) UTF-8, this will instead use RFC 5987
 * encoding, just like [func@header_g_string_append_param].
 **/
void
soup_header_g_string_append_param_quoted (GString    *string,
					  const char *name,
					  const char *value)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_g_string_append_param_quoted 1\n");
	g_return_if_fail (string != NULL);
	g_return_if_fail (name != NULL);
	g_return_if_fail (value != NULL);

	append_param_internal (string, name, value, FALSE);
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_g_string_append_param_quoted 1\n");
}

/**
 * soup_header_g_string_append_param:
 * @string: a #GString being used to construct an HTTP header value
 * @name: a parameter name
 * @value: (nullable): a parameter value, or %NULL
 *
 * Appends something like `name=value` to @string, taking care to quote @value
 * if needed, and if so, to escape any quotes or backslashes in @value.
 *
 * Alternatively, if @value is a non-ASCII UTF-8 string, it will be
 * appended using RFC5987 syntax. Although in theory this is supposed
 * to work anywhere in HTTP that uses this style of parameter, in
 * reality, it can only be used portably with the Content-Disposition
 * "filename" parameter.
 *
 * If @value is %NULL, this will just append @name to @string.
 **/
void
soup_header_g_string_append_param (GString    *string,
				   const char *name,
				   const char *value)
{
	fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_g_string_append_param 1\n");
	g_return_if_fail (string != NULL);
	g_return_if_fail (name != NULL);

	if (!value) {
		fprintf(stderr, "[libsoup/soup-headers.c] enter soup_header_g_string_append_param 2\n");
		g_string_append (string, name);
		return;
		// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_g_string_append_param 2\n");
	}

	append_param_internal (string, name, value, TRUE);
	// fprintf(stderr, "[libsoup/soup-headers.c] exit soup_header_g_string_append_param 1\n");
}
// Total cost: 0.361877
// Total split cost: 0.079735, input tokens: 71936, output tokens: 1100, cache read tokens: 71917, cache write tokens: 11094, split chunks: [(0, 788), (788, 1010)]
// Total instrumented cost: 0.282143, input tokens: 4741, output tokens: 16245, cache read tokens: 4733, cache write tokens: 9873

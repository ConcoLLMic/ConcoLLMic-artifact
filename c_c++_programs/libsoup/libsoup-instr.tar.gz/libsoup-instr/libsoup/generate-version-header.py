#!/usr/bin/env python3

import sys

sys.stderr.write("[libsoup/generate-version-header.py] enter module 1\n")
input_file = sys.argv[1]
output_file = sys.argv[2]
current_version = sys.argv[3]
major, minor, micro = (int(v) for v in current_version.split('.'))
# sys.stderr.write("[libsoup/generate-version-header.py] exit module 1\n")

def is_stable(version):
    sys.stderr.write("[libsoup/generate-version-header.py] enter is_stable 1\n")
    return not version % 2
    # sys.stderr.write("[libsoup/generate-version-header.py] exit is_stable 1\n")

with open(input_file) as i:
    sys.stderr.write("[libsoup/generate-version-header.py] enter module 2\n")
    template = i.read()
    # sys.stderr.write("[libsoup/generate-version-header.py] exit module 2\n")

sys.stderr.write("[libsoup/generate-version-header.py] enter module 3\n")
versions = []
# sys.stderr.write("[libsoup/generate-version-header.py] exit module 3\n")

if major == 2:
    sys.stderr.write("[libsoup/generate-version-header.py] enter module 4\n")
    # Specific to 3.x dev releases
    versions.append((3, 0))
    # sys.stderr.write("[libsoup/generate-version-header.py] exit module 4\n")
else:
    sys.stderr.write("[libsoup/generate-version-header.py] enter module 5\n")
    minor_max = minor if is_stable(minor) else minor + 1
    for i in range(0, minor_max + 1):
        sys.stderr.write("[libsoup/generate-version-header.py] enter module 6\n")
        if is_stable(i):
            sys.stderr.write("[libsoup/generate-version-header.py] enter module 7\n")
            versions.append((3, i))
            # sys.stderr.write("[libsoup/generate-version-header.py] exit module 7\n")
        # sys.stderr.write("[libsoup/generate-version-header.py] exit module 6\n")
    # sys.stderr.write("[libsoup/generate-version-header.py] exit module 5\n")

sys.stderr.write("[libsoup/generate-version-header.py] enter module 8\n")
version_macros = ''
version_attributes = ''
# sys.stderr.write("[libsoup/generate-version-header.py] exit module 8\n")

for version in versions:
    sys.stderr.write("[libsoup/generate-version-header.py] enter module 9\n")
    version_macros += '''/**
 * SOUP_VERSION_{major_version}_{minor_version}:
 *
 * A macro that evaluates to the {major_version}.{minor_version} version of libsoup, in a format
 * that can be used by the C pre-processor.
 *
 * Since: {major_version}.{minor_version}
 */
#define SOUP_VERSION_{major_version}_{minor_version} (G_ENCODE_VERSION ({major_version}, {minor_version}))
'''.format(major_version=version[0], minor_version=version[1])

    version_attributes += '''/**
 * SOUP_DEPRECATED_IN_{major_version}_{minor_version}:
 * A macro used to indicate a symbol was deprecated in this version.
 */
/**
 * SOUP_DEPRECATED_IN_{major_version}_{minor_version}_FOR:
 * @f: The recommended replacement function.
 *
 * A macro used to indicate a symbol was deprecated in this version with a replacement.
 */
#if SOUP_VERSION_MIN_REQUIRED >= SOUP_VERSION_{major_version}_{minor_version}
# define SOUP_DEPRECATED_IN_{major_version}_{minor_version}                SOUP_DEPRECATED
# define SOUP_DEPRECATED_IN_{major_version}_{minor_version}_FOR(f)         SOUP_DEPRECATED_FOR(f)
#else
# define SOUP_DEPRECATED_IN_{major_version}_{minor_version}                _SOUP_EXTERN
# define SOUP_DEPRECATED_IN_{major_version}_{minor_version}_FOR(f)         _SOUP_EXTERN
#endif

/**
 * SOUP_AVAILABLE_IN_{major_version}_{minor_version}:
 * A macro used to indicate a symbol is available in this version or later.
 */
#if SOUP_VERSION_MAX_ALLOWED < SOUP_VERSION_{major_version}_{minor_version}
# define SOUP_AVAILABLE_IN_{major_version}_{minor_version}                 SOUP_UNAVAILABLE({major_version}, {minor_version})
#else
# define SOUP_AVAILABLE_IN_{major_version}_{minor_version}                 _SOUP_EXTERN
#endif
'''.format(major_version=version[0], minor_version=version[1])
    # sys.stderr.write("[libsoup/generate-version-header.py] exit module 9\n")

sys.stderr.write("[libsoup/generate-version-header.py] enter module 10\n")
header = template.format(version_macros=version_macros,
                         version_attributes=version_attributes,
                         major_version=major,
                         minor_version=minor,
                         micro_version=micro)
# sys.stderr.write("[libsoup/generate-version-header.py] exit module 10\n")

with open(output_file, 'w+') as o:
    sys.stderr.write("[libsoup/generate-version-header.py] enter module 11\n")
    o.write(header)
    # sys.stderr.write("[libsoup/generate-version-header.py] exit module 11\n")
# Total cost: 0.023095
# Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 78)]
# Total instrumented cost: 0.023095, input tokens: 2398, output tokens: 1254, cache read tokens: 2394, cache write tokens: 948

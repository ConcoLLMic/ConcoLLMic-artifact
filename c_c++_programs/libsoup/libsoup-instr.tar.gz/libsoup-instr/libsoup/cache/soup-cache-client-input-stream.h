/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright 2015 Igalia S.L.
 */

#pragma once

#include "soup-types.h"

G_BEGIN_DECLS

#define SOUP_TYPE_CACHE_CLIENT_INPUT_STREAM            (soup_cache_client_input_stream_get_type ())
G_DECLARE_FINAL_TYPE (SoupCacheClientInputStream, soup_cache_client_input_stream, SOUP, CACHE_CLIENT_INPUT_STREAM, GFilterInputStream)

GInputStream *soup_cache_client_input_stream_new (GInputStream *base_stream);

G_END_DECLS
// Total cost: 0.002103
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 17)]
// Total instrumented cost: 0.002103, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 274

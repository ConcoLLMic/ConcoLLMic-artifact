/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright (C) 2012 Igalia, S.L.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <glib/gi18n-lib.h>
#include "soup-cache-input-stream.h"
#include "soup-message-body.h"
#include <stdio.h>

enum {
	CACHING_FINISHED,

	LAST_SIGNAL
};

static guint signals[LAST_SIGNAL] = { 0 };

struct _SoupCacheInputStream {
	SoupFilterInputStream parent_instance;
};

typedef struct {
	GOutputStream *output_stream;
	GCancellable *cancellable;
	gsize bytes_written;

	gboolean read_finished;
	GBytes *current_writing_buffer;
	GQueue *buffer_queue;
} SoupCacheInputStreamPrivate;

static void soup_cache_input_stream_pollable_init (GPollableInputStreamInterface *pollable_interface, gpointer interface_data);

G_DEFINE_FINAL_TYPE_WITH_CODE (SoupCacheInputStream, soup_cache_input_stream, SOUP_TYPE_FILTER_INPUT_STREAM,
                               G_ADD_PRIVATE (SoupCacheInputStream)
                               G_IMPLEMENT_INTERFACE (G_TYPE_POLLABLE_INPUT_STREAM,
                                                      soup_cache_input_stream_pollable_init))


static void soup_cache_input_stream_write_next_buffer (SoupCacheInputStream *istream);

static inline void
notify_and_clear (SoupCacheInputStream *istream, GError *error)
{
	fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter notify_and_clear 1\n");
	SoupCacheInputStreamPrivate *priv = soup_cache_input_stream_get_instance_private (istream);

	g_signal_emit (istream, signals[CACHING_FINISHED], 0, priv->bytes_written, error);

	g_clear_object (&priv->cancellable);
	g_clear_object (&priv->output_stream);
	g_clear_error (&error);
	// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit notify_and_clear 1\n");
}

static inline void
try_write_next_buffer (SoupCacheInputStream *istream)
{
	fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter try_write_next_buffer 1\n");
	SoupCacheInputStreamPrivate *priv = soup_cache_input_stream_get_instance_private (istream);

	if (priv->current_writing_buffer == NULL && priv->buffer_queue->length)
	{
		fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter try_write_next_buffer 2\n");
		soup_cache_input_stream_write_next_buffer (istream);
		// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit try_write_next_buffer 2\n");
	}
	else if (priv->read_finished)
	{
		fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter try_write_next_buffer 3\n");
		notify_and_clear (istream, NULL);
		// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit try_write_next_buffer 3\n");
	}
	else if (g_input_stream_is_closed (G_INPUT_STREAM (istream))) 
	{
		fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter try_write_next_buffer 4\n");
		GError *error = NULL;
		g_set_error_literal (&error, G_IO_ERROR, G_IO_ERROR_CLOSED,
				     _("Network stream unexpectedly closed"));
		notify_and_clear (istream, error);
		// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit try_write_next_buffer 4\n");
	}
	// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit try_write_next_buffer 1\n");
}

static void
file_replaced_cb (GObject      *source,
		  GAsyncResult *res,
		  gpointer      user_data)
{
	fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter file_replaced_cb 1\n");
	SoupCacheInputStream *istream = SOUP_CACHE_INPUT_STREAM (user_data);
	SoupCacheInputStreamPrivate *priv = soup_cache_input_stream_get_instance_private (istream);
	GError *error = NULL;

	priv->output_stream = (GOutputStream *) g_file_replace_finish (G_FILE (source), res, &error);

	if (error)
	{
		fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter file_replaced_cb 2\n");
		notify_and_clear (istream, error);
		// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit file_replaced_cb 2\n");
	}
	else
	{
		fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter file_replaced_cb 3\n");
		try_write_next_buffer (istream);
		// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit file_replaced_cb 3\n");
	}

	g_object_unref (istream);
	// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit file_replaced_cb 1\n");
}

static void
soup_cache_input_stream_init (SoupCacheInputStream *self)
{
	fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter soup_cache_input_stream_init 1\n");
	SoupCacheInputStreamPrivate *priv = soup_cache_input_stream_get_instance_private (self);

	priv->buffer_queue = g_queue_new ();
	// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit soup_cache_input_stream_init 1\n");
}

static void
soup_cache_input_stream_finalize (GObject *object)
{
	fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter soup_cache_input_stream_finalize 1\n");
	SoupCacheInputStream *self = (SoupCacheInputStream *)object;
	SoupCacheInputStreamPrivate *priv = soup_cache_input_stream_get_instance_private (self);

	g_clear_object (&priv->cancellable);
	g_clear_object (&priv->output_stream);
	g_clear_pointer (&priv->current_writing_buffer, g_bytes_unref);
	g_queue_free_full (priv->buffer_queue, (GDestroyNotify) g_bytes_unref);

	G_OBJECT_CLASS (soup_cache_input_stream_parent_class)->finalize (object);
	// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit soup_cache_input_stream_finalize 1\n");
}

static void
write_ready_cb (GObject *source, GAsyncResult *result, SoupCacheInputStream *istream)
{
	fprintf(stderr, "\n");
	GOutputStream *ostream = G_OUTPUT_STREAM (source);
	SoupCacheInputStreamPrivate *priv = soup_cache_input_stream_get_instance_private (istream);
	gssize write_size;
	gsize pending;
	GError *error = NULL;

	write_size = g_output_stream_write_finish (ostream, result, &error);
	if (error) 
	{
		fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter write_ready_cb 2\n");
		notify_and_clear (istream, error);
		g_object_unref (istream);
		return;
		// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit write_ready_cb 2\n");
	}

	/* Check that we have written everything */
	pending = g_bytes_get_size (priv->current_writing_buffer) - write_size;
	if (pending) 
	{
		fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter write_ready_cb 3\n");
		GBytes *subbuffer = g_bytes_new_from_bytes (priv->current_writing_buffer,
							    write_size, pending);
		g_queue_push_head (priv->buffer_queue, g_steal_pointer (&subbuffer));
		// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit write_ready_cb 3\n");
	}

	fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter write_ready_cb 4\n");
	priv->bytes_written += write_size;
	g_clear_pointer (&priv->current_writing_buffer, g_bytes_unref);

	try_write_next_buffer (istream);
	g_object_unref (istream);
	// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit write_ready_cb 4\n");
}

static void
soup_cache_input_stream_write_next_buffer (SoupCacheInputStream *istream)
{
	fprintf(stderr, "\n");
	SoupCacheInputStreamPrivate *priv = soup_cache_input_stream_get_instance_private (istream);
	GBytes *buffer = g_queue_pop_head (priv->buffer_queue);
	int priority;

	g_assert (priv->output_stream && !g_output_stream_is_closed (priv->output_stream));

	g_clear_pointer (&priv->current_writing_buffer, g_bytes_unref);
	priv->current_writing_buffer = buffer;

	if (priv->buffer_queue->length > 10)
	{
		fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter soup_cache_input_stream_write_next_buffer 2\n");
		priority = G_PRIORITY_DEFAULT;
		// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit soup_cache_input_stream_write_next_buffer 2\n");
	}
	else
	{
		fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter soup_cache_input_stream_write_next_buffer 3\n");
		priority = G_PRIORITY_LOW;
		// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit soup_cache_input_stream_write_next_buffer 3\n");
	}

	fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter soup_cache_input_stream_write_next_buffer 4\n");
	g_output_stream_write_async (priv->output_stream,
                                     g_bytes_get_data (buffer, NULL),
                                     g_bytes_get_size (buffer),
				     priority, priv->cancellable,
				     (GAsyncReadyCallback) write_ready_cb,
				     g_object_ref (istream));
	// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit soup_cache_input_stream_write_next_buffer 4\n");
}

static gssize
read_internal (GInputStream  *stream,
	       void          *buffer,
	       gsize          count,
	       gboolean       blocking,
	       GCancellable  *cancellable,
	       GError       **error)
{
	fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter read_internal 1\n");
	SoupCacheInputStream *istream = SOUP_CACHE_INPUT_STREAM (stream);
	SoupCacheInputStreamPrivate *priv = soup_cache_input_stream_get_instance_private (istream);
	GInputStream *base_stream;
	gssize nread;

	base_stream = g_filter_input_stream_get_base_stream (G_FILTER_INPUT_STREAM (stream));
	nread = g_pollable_stream_read (base_stream, buffer, count, blocking,
					cancellable, error);

	if (G_UNLIKELY (nread == -1 || priv->read_finished))
	{
		fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter read_internal 2\n");
		return nread;
		// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit read_internal 2\n");
	}

	if (nread == 0) 
	{
		fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter read_internal 3\n");
		priv->read_finished = TRUE;

		if (priv->current_writing_buffer == NULL && priv->output_stream)
		{
			fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter read_internal 4\n");
			notify_and_clear (istream, NULL);
			// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit read_internal 4\n");
		}
		// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit read_internal 3\n");
	} 
	else 
	{
		fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter read_internal 5\n");
		GBytes *local_buffer = g_bytes_new (buffer, nread);
		g_queue_push_tail (priv->buffer_queue, g_steal_pointer (&local_buffer));

		if (priv->current_writing_buffer == NULL && priv->output_stream)
		{
			fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter read_internal 6\n");
			soup_cache_input_stream_write_next_buffer (istream);
			// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit read_internal 6\n");
		}
		// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit read_internal 5\n");
	}

	return nread;
	// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit read_internal 1\n");
}

static gssize
soup_cache_input_stream_read_fn (GInputStream  *stream,
				 void          *buffer,
				 gsize          count,
				 GCancellable  *cancellable,
				 GError       **error)
{
	fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter soup_cache_input_stream_read_fn 1\n");
	return read_internal (stream, buffer, count, TRUE,
			      cancellable, error);
	// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit soup_cache_input_stream_read_fn 1\n");
}

static gssize
soup_cache_input_stream_read_nonblocking (GPollableInputStream  *stream,
					  void                  *buffer,
					  gsize                  count,
					  GError               **error)
{
	fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter soup_cache_input_stream_read_nonblocking 1\n");
	return read_internal (G_INPUT_STREAM (stream), buffer, count, FALSE,
			      NULL, error);
	// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit soup_cache_input_stream_read_nonblocking 1\n");
}

static void
soup_cache_input_stream_pollable_init (GPollableInputStreamInterface *pollable_interface,
				       gpointer interface_data)
{
	fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter soup_cache_input_stream_pollable_init 1\n");
	pollable_interface->read_nonblocking = soup_cache_input_stream_read_nonblocking;
	// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit soup_cache_input_stream_pollable_init 1\n");
}

static gboolean
soup_cache_input_stream_close_fn (GInputStream  *stream,
				  GCancellable  *cancellable,
				  GError       **error)
{
	fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter soup_cache_input_stream_close_fn 1\n");
	SoupCacheInputStream *istream = SOUP_CACHE_INPUT_STREAM (stream);
	SoupCacheInputStreamPrivate *priv = soup_cache_input_stream_get_instance_private (istream);

	if (!priv->read_finished) 
	{
		fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter soup_cache_input_stream_close_fn 2\n");
		if (priv->output_stream) 
		{
			fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter soup_cache_input_stream_close_fn 3\n");
			/* Cancel any pending write operation or return an error if none. */
			if (g_output_stream_has_pending (priv->output_stream))
			{
				fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter soup_cache_input_stream_close_fn 4\n");
				g_cancellable_cancel (priv->cancellable);
				// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit soup_cache_input_stream_close_fn 4\n");
			}
			else 
			{
				fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter soup_cache_input_stream_close_fn 5\n");
				GError *notify_error = NULL;
				g_set_error_literal (&notify_error, G_IO_ERROR, G_IO_ERROR_PARTIAL_INPUT,
						     _("Failed to completely cache the resource"));
				notify_and_clear (istream, notify_error);
				// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit soup_cache_input_stream_close_fn 5\n");
			}
			// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit soup_cache_input_stream_close_fn 3\n");
		} 
		else if (priv->cancellable)
		{
			fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter soup_cache_input_stream_close_fn 6\n");
			/* The file_replace_async() hasn't finished yet */
			g_cancellable_cancel (priv->cancellable);
			// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit soup_cache_input_stream_close_fn 6\n");
		}
		// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit soup_cache_input_stream_close_fn 2\n");
	}

	return G_INPUT_STREAM_CLASS (soup_cache_input_stream_parent_class)->close_fn (stream, cancellable, error);
	// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit soup_cache_input_stream_close_fn 1\n");
}

static void
soup_cache_input_stream_class_init (SoupCacheInputStreamClass *klass)
{
	fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter soup_cache_input_stream_class_init 1\n");
	GObjectClass *gobject_class = G_OBJECT_CLASS (klass);
	GInputStreamClass *istream_class = G_INPUT_STREAM_CLASS (klass);

	gobject_class->finalize = soup_cache_input_stream_finalize;

	istream_class->read_fn = soup_cache_input_stream_read_fn;
	istream_class->close_fn = soup_cache_input_stream_close_fn;

	signals[CACHING_FINISHED] =
		g_signal_new ("caching-finished",
			      G_OBJECT_CLASS_TYPE (gobject_class),
			      G_SIGNAL_RUN_FIRST,
			      0,
			      NULL, NULL,
			      NULL,
			      G_TYPE_NONE, 2,
			      G_TYPE_INT, G_TYPE_ERROR);
	// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit soup_cache_input_stream_class_init 1\n");
}

GInputStream *
soup_cache_input_stream_new (GInputStream *base_stream,
			     GFile        *file)
{
	fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] enter soup_cache_input_stream_new 1\n");
	SoupCacheInputStream *istream = g_object_new (SOUP_TYPE_CACHE_INPUT_STREAM,
					      "base-stream", base_stream,
					      "close-base-stream", FALSE,
					      NULL);
	SoupCacheInputStreamPrivate *priv = soup_cache_input_stream_get_instance_private (istream);

	priv->cancellable = g_cancellable_new ();
	g_file_replace_async (file, NULL, FALSE,
			      G_FILE_CREATE_PRIVATE | G_FILE_CREATE_REPLACE_DESTINATION,
			      G_PRIORITY_DEFAULT, priv->cancellable,
			      file_replaced_cb, g_object_ref (istream));

	return (GInputStream *) istream;
	// fprintf(stderr, "[libsoup/cache/soup-cache-input-stream.c] exit soup_cache_input_stream_new 1\n");
}
// Total cost: 0.086624
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 302)]
// Total instrumented cost: 0.086624, input tokens: 2398, output tokens: 4880, cache read tokens: 2394, cache write tokens: 3385

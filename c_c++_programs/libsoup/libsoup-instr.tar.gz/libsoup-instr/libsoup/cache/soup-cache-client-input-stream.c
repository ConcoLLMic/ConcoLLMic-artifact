/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * soup-cache-client-input-stream.c
 *
 * Copyright 2015 Igalia S.L.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include "soup-cache-client-input-stream.h"
#include "soup.h"
#include "soup-message-private.h"

enum {
	SIGNAL_EOF,
	SIGNAL_CLOSED,
	LAST_SIGNAL
};

static guint signals[LAST_SIGNAL] = { 0 };

struct _SoupCacheClientInputStream {
	GFilterInputStream parent_instance;
};

G_DEFINE_FINAL_TYPE (SoupCacheClientInputStream, soup_cache_client_input_stream, G_TYPE_FILTER_INPUT_STREAM)

static void
soup_cache_client_input_stream_init (SoupCacheClientInputStream *stream)
{
	fprintf(stderr, "\n");
	// fprintf(stderr, "\n");
}

static gssize
soup_cache_client_input_stream_read_fn (GInputStream  *stream,
					void          *buffer,
					gsize          count,
					GCancellable  *cancellable,
					GError       **error)
{
	fprintf(stderr, "[libsoup/cache/soup-cache-client-input-stream.c] enter soup_cache_client_input_stream_read_fn 1\n");
	gssize nread;

	nread = G_INPUT_STREAM_CLASS (soup_cache_client_input_stream_parent_class)->
		read_fn (stream, buffer, count, cancellable, error);
	// fprintf(stderr, "[libsoup/cache/soup-cache-client-input-stream.c] exit soup_cache_client_input_stream_read_fn 1\n");

	if (nread == 0) {
		fprintf(stderr, "[libsoup/cache/soup-cache-client-input-stream.c] enter soup_cache_client_input_stream_read_fn 2\n");
		g_signal_emit (stream, signals[SIGNAL_EOF], 0);
		// fprintf(stderr, "[libsoup/cache/soup-cache-client-input-stream.c] exit soup_cache_client_input_stream_read_fn 2\n");
	}

	fprintf(stderr, "[libsoup/cache/soup-cache-client-input-stream.c] enter soup_cache_client_input_stream_read_fn 3\n");
	return nread;
	// fprintf(stderr, "[libsoup/cache/soup-cache-client-input-stream.c] exit soup_cache_client_input_stream_read_fn 3\n");
}


static gboolean
soup_cache_client_input_stream_close_fn (GInputStream  *stream,
					 GCancellable  *cancellable,
					 GError       **error)
{
	fprintf(stderr, "[libsoup/cache/soup-cache-client-input-stream.c] enter soup_cache_client_input_stream_close_fn 1\n");
	gboolean success;

	success = G_INPUT_STREAM_CLASS (soup_cache_client_input_stream_parent_class)->
		close_fn (stream, cancellable, error);

	g_signal_emit (stream, signals[SIGNAL_CLOSED], 0);

	return success;
	// fprintf(stderr, "[libsoup/cache/soup-cache-client-input-stream.c] exit soup_cache_client_input_stream_close_fn 1\n");
}

static void
soup_cache_client_input_stream_class_init (SoupCacheClientInputStreamClass *stream_class)
{
	fprintf(stderr, "[libsoup/cache/soup-cache-client-input-stream.c] enter soup_cache_client_input_stream_class_init 1\n");
	GObjectClass *object_class = G_OBJECT_CLASS (stream_class);
	GInputStreamClass *input_stream_class = G_INPUT_STREAM_CLASS (stream_class);

	input_stream_class->read_fn = soup_cache_client_input_stream_read_fn;
	input_stream_class->close_fn = soup_cache_client_input_stream_close_fn;

	signals[SIGNAL_EOF] =
		g_signal_new ("eof",
			      G_OBJECT_CLASS_TYPE (object_class),
			      G_SIGNAL_RUN_LAST,
			      0,
			      NULL, NULL,
			      NULL,
			      G_TYPE_NONE, 0);
	signals[SIGNAL_CLOSED] =
		g_signal_new ("closed",
			      G_OBJECT_CLASS_TYPE (object_class),
			      G_SIGNAL_RUN_LAST,
			      0,
			      NULL, NULL,
			      NULL,
			      G_TYPE_NONE, 0);
	// fprintf(stderr, "[libsoup/cache/soup-cache-client-input-stream.c] exit soup_cache_client_input_stream_class_init 1\n");
}

GInputStream *
soup_cache_client_input_stream_new (GInputStream *base_stream)
{
	fprintf(stderr, "[libsoup/cache/soup-cache-client-input-stream.c] enter soup_cache_client_input_stream_new 1\n");
	return g_object_new (SOUP_TYPE_CACHE_CLIENT_INPUT_STREAM,
			     "base-stream", base_stream,
			     NULL);
	// fprintf(stderr, "[libsoup/cache/soup-cache-client-input-stream.c] exit soup_cache_client_input_stream_new 1\n");
}
// Total cost: 0.023991
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 102)]
// Total instrumented cost: 0.023991, input tokens: 2398, output tokens: 1302, cache read tokens: 2394, cache write tokens: 995

/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright (C) 2021 Igalia S.L.
 */

#pragma once

#include "soup-message-headers.h"
#include "soup-header-names.h"

G_BEGIN_DECLS

void        soup_message_headers_append_untrusted_data  (SoupMessageHeaders *hdrs,
                                                         const char         *name,
                                                         const char         *value);
void        soup_message_headers_append_common          (SoupMessageHeaders *hdrs,
                                                         SoupHeaderName      name,
                                                         const char         *value);
const char *soup_message_headers_get_one_common         (SoupMessageHeaders *hdrs,
                                                         SoupHeaderName      name);
const char *soup_message_headers_get_list_common        (SoupMessageHeaders *hdrs,
                                                         SoupHeaderName      name);
void        soup_message_headers_remove_common          (SoupMessageHeaders *hdrs,
                                                         SoupHeaderName      name);
void        soup_message_headers_replace_common         (SoupMessageHeaders *hdrs,
                                                         SoupHeaderName      name,
                                                         const char         *value);
gboolean    soup_message_headers_header_contains_common (SoupMessageHeaders *hdrs,
                                                         SoupHeaderName      name,
                                                         const char         *token);
gboolean    soup_message_headers_header_equals_common   (SoupMessageHeaders *hdrs,
                                                         SoupHeaderName      name,
                                                         const char         *value);

G_END_DECLS
// Total cost: 0.003055
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 35)]
// Total instrumented cost: 0.003055, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 528

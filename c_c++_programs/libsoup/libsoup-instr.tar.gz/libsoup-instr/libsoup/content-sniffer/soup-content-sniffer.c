/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * soup-content-sniffer.c
 *
 * Copyright (C) 2009, 2013 Gustavo Noronha Silva.
 *
 * This code implements the following specification:
 *
 *  http://mimesniff.spec.whatwg.org/ as of 11 June 2013
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <string.h>
#include <stdio.h>

#include "soup-content-sniffer.h"
#include "soup-session-feature-private.h"
#include "soup-content-processor.h"
#include "soup-content-sniffer-stream.h"
#include "soup-message-private.h"
#include "soup-message-headers-private.h"
#include "soup-session-feature-private.h"

/**
 * SoupContentSniffer:
 *
 * Sniffs the mime type of messages.
 *
 * A #SoupContentSniffer tries to detect the actual content type of
 * the files that are being downloaded by looking at some of the data
 * before the [class@Message] emits its [signal@Message::got-headers] signal.
 * #SoupContentSniffer implements [iface@SessionFeature], so you can add
 * content sniffing to a session with [method@Session.add_feature] or
 * [method@Session.add_feature_by_type].
 **/

static void soup_content_sniffer_session_feature_init (SoupSessionFeatureInterface *feature_interface, gpointer interface_data);

static SoupContentProcessorInterface *soup_content_sniffer_default_content_processor_interface;
static void soup_content_sniffer_content_processor_init (SoupContentProcessorInterface *interface, gpointer interface_data);

struct _SoupContentSniffer {
        GObject parent_instance;
};

G_DEFINE_FINAL_TYPE_WITH_CODE (SoupContentSniffer, soup_content_sniffer, G_TYPE_OBJECT,
			       G_IMPLEMENT_INTERFACE (SOUP_TYPE_SESSION_FEATURE,
						      soup_content_sniffer_session_feature_init)
			       G_IMPLEMENT_INTERFACE (SOUP_TYPE_CONTENT_PROCESSOR,
						      soup_content_sniffer_content_processor_init))


static GInputStream *
soup_content_sniffer_content_processor_wrap_input (SoupContentProcessor *processor,
						   GInputStream *base_stream,
						   SoupMessage *msg,
						   GError **error)
{
	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter soup_content_sniffer_content_processor_wrap_input 1\n");
	return g_object_new (SOUP_TYPE_CONTENT_SNIFFER_STREAM,
			     "base-stream", base_stream,
			     "message", msg,
			     "sniffer", SOUP_CONTENT_SNIFFER (processor),
			     NULL);
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit soup_content_sniffer_content_processor_wrap_input 1\n");
}

static void
soup_content_sniffer_content_processor_init (SoupContentProcessorInterface *processor_interface,
                                            gpointer interface_data)
{
	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter soup_content_sniffer_content_processor_init 1\n");
	soup_content_sniffer_default_content_processor_interface =
		g_type_default_interface_peek (SOUP_TYPE_CONTENT_PROCESSOR);

	processor_interface->processing_stage = SOUP_STAGE_BODY_DATA;
	processor_interface->wrap_input = soup_content_sniffer_content_processor_wrap_input;
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit soup_content_sniffer_content_processor_init 1\n");
}

static void
soup_content_sniffer_init (SoupContentSniffer *content_sniffer)
{
	fprintf(stderr, "\n");
	// fprintf(stderr, "\n");
}

typedef struct {
	const guchar *mask;
	const guchar *pattern;
	guint         pattern_length;
	const char   *sniffed_type;
} SoupContentSnifferMediaPattern;

static char*
sniff_media (SoupContentSniffer *sniffer,
	     GBytes *buffer,
	     SoupContentSnifferMediaPattern table[],
	     int table_length)
{
	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_media 1\n");
        gsize resource_length;
        const guchar *resource = g_bytes_get_data (buffer, &resource_length);
        resource_length = MIN (512, resource_length);
	int i;
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_media 1\n");

	for (i = 0; i < table_length; i++) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_media 2\n");
		SoupContentSnifferMediaPattern *type_row = &(table[i]);
		guint j;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_media 2\n");

		if (resource_length < type_row->pattern_length) {
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_media 3\n");
			continue;
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_media 3\n");
		}

		for (j = 0; j < type_row->pattern_length; j++) {
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_media 4\n");
			if ((type_row->mask[j] & resource[j]) != type_row->pattern[j])
				break;
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_media 4\n");
		}

		/* This means our comparison above matched completely */
		if (j == type_row->pattern_length) {
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_media 5\n");
			return g_strdup (type_row->sniffed_type);
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_media 5\n");
		}
	}

	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_media 6\n");
	return NULL;
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_media 6\n");
}

/* This table is based on the MIMESNIFF spec;
 * See 6.1 Matching an image type pattern
 */
static SoupContentSnifferMediaPattern image_types_table[] = {

	/* Windows icon signature. */
	{ (const guchar *)"\xFF\xFF\xFF\xFF",
	  (const guchar *)"\x00\x00\x01\x00",
	  4,
	  "image/x-icon" },

	/* Windows cursor signature. */
	{ (const guchar *)"\xFF\xFF\xFF\xFF",
	  (const guchar *)"\x00\x00\x02\x00",
	  4,
	  "image/x-icon" },

	/* BMP. */
	{ (const guchar *)"\xFF\xFF",
	  (const guchar *)"BM",
	  2,
	  "image/bmp" },

	/* GIFs. */
	{ (const guchar *)"\xFF\xFF\xFF\xFF\xFF\xFF",
	  (const guchar *)"GIF87a",
	  6,
	  "image/gif" },

	{ (const guchar *)"\xFF\xFF\xFF\xFF\xFF\xFF",
	  (const guchar *)"GIF89a",
	  6,
	  "image/gif" },

	/* WEBP. */
	{ (const guchar *)"\xFF\xFF\xFF\xFF\x00\x00\x00\x00\xFF\xFF\xFF\xFF\xFF\xFF",
	  (const guchar *)"RIFF\x00\x00\x00\x00WEBPVP",
	  14,
	  "image/webp" },

	/* PNG. */
	{ (const guchar *)"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF",
	  (const guchar *)"\x89PNG\x0D\x0A\x1A\x0A",
	  8,
	  "image/png" },

	/* JPEG. */
	{ (const guchar *)"\xFF\xFF\xFF",
	  (const guchar *)"\xFF\xD8\xFF",
	  3,
	  "image/jpeg" },
};

static char*
sniff_images (SoupContentSniffer *sniffer, GBytes *buffer)
{
	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_images 1\n");
	return sniff_media (sniffer,
			    buffer,
			    image_types_table,
			    G_N_ELEMENTS (image_types_table));
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_images 1\n");
}

/* This table is based on the MIMESNIFF spec;
 * See 6.2 Matching an audio or video type pattern
 */
static SoupContentSnifferMediaPattern audio_video_types_table[] = {
	{ (const guchar *)"\xFF\xFF\xFF\xFF",
	  (const guchar *)"\x1A\x45\xDF\xA3",
	  4,
	  "video/webm" },

	{ (const guchar *)"\xFF\xFF\xFF\xFF",
	  (const guchar *)".snd",
	  4,
	  "audio/basic" },


	{ (const guchar *)"\xFF\xFF\xFF\xFF\x00\x00\x00\x00\xFF\xFF\xFF\xFF",
	  (const guchar *)"FORM\0\0\0\0AIFF",
	  12,
	  "audio/aiff" },

	{ (const guchar *)"\xFF\xFF\xFF",
	  (const guchar *)"ID3",
	  3,
	  "audio/mpeg" },

	{ (const guchar *)"\xFF\xFF\xFF\xFF\xFF",
	  (const guchar *)"OggS\0",
	  5,
	  "application/ogg" },

	{ (const guchar *)"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF",
	  (const guchar *)"MThd\x00\x00\x00\x06",
	  8,
	  "audio/midi" },

	{ (const guchar *)"\xFF\xFF\xFF\xFF\x00\x00\x00\x00\xFF\xFF\xFF\xFF",
	  (const guchar *)"RIFF\x00\x00\x00\x00AVI ",
	  12,
	  "video/avi" },

	{ (const guchar *)"\xFF\xFF\xFF\xFF\x00\x00\x00\x00\xFF\xFF\xFF\xFF",
	  (const guchar *)"RIFF\x00\x00\x00\x00WAVE",
	  12,
	  "audio/wave" },
};

static gboolean
data_has_prefix (const char *data, const char *prefix, gsize max_length)
{
	fprintf(stderr, "\n");
        if (strlen (prefix) > max_length) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter data_has_prefix 2\n");
                return FALSE;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit data_has_prefix 2\n");
	}

	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter data_has_prefix 3\n");
        return memcmp (data, prefix, strlen (prefix)) == 0;
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit data_has_prefix 3\n");
}

static gboolean
sniff_mp4 (SoupContentSniffer *sniffer, GBytes *buffer)
{
	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_mp4 1\n");
	gsize resource_length;
	const char *resource = g_bytes_get_data (buffer, &resource_length);
	resource_length = MIN (512, resource_length);
	guint32 box_size;
	guint i;
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_mp4 1\n");

        if (resource_length < sizeof (guint32)) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_mp4 2\n");
                return FALSE;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_mp4 2\n");
	}

	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_mp4 3\n");
	box_size = *((guint32*)resource);
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_mp4 3\n");

#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_mp4 4\n");
	box_size = ((box_size >> 24) |
		    ((box_size << 8) & 0x00FF0000) |
		    ((box_size >> 8) & 0x0000FF00) |
		    (box_size << 24));
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_mp4 4\n");
#endif

	if (resource_length < 12 || resource_length < box_size || box_size % 4 != 0) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_mp4 5\n");
		return FALSE;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_mp4 5\n");
	}

	if (!data_has_prefix (resource + 4, "ftyp", resource_length - 4)) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_mp4 6\n");
		return FALSE;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_mp4 6\n");
	}

	if (!data_has_prefix (resource + 8, "mp4", resource_length - 8)) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_mp4 7\n");
		return FALSE;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_mp4 7\n");
	}

	for (i = 16; i < box_size && i < resource_length; i = i + 4) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_mp4 8\n");
		if (data_has_prefix (resource + i, "mp4", resource_length - i)) {
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_mp4 9\n");
			return TRUE;
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_mp4 9\n");
		}
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_mp4 8\n");
	}

	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_mp4 10\n");
	return FALSE;
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_mp4 10\n");
}

static char*
sniff_audio_video (SoupContentSniffer *sniffer, GBytes *buffer)
{
	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_audio_video 1\n");
	char *sniffed_type;
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_audio_video 1\n");

	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_audio_video 2\n");
	sniffed_type = sniff_media (sniffer,
				    buffer,
				    audio_video_types_table,
				    G_N_ELEMENTS (audio_video_types_table));
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_audio_video 2\n");

	if (sniffed_type != NULL) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_audio_video 3\n");
		return sniffed_type;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_audio_video 3\n");
	}

	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_audio_video 4\n");
	if (sniff_mp4 (sniffer, buffer)) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_audio_video 5\n");
		return g_strdup ("video/mp4");
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_audio_video 5\n");
	}
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_audio_video 4\n");

	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_audio_video 6\n");
	return NULL;
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_audio_video 6\n");
}

/* This table is based on the MIMESNIFF spec;
 * See 7.1 Identifying a resource with an unknown MIME type
 */
typedef struct {
	/* @has_ws is TRUE if @pattern contains "generic" whitespace */
	gboolean      has_ws;
	/* @has_tag_termination is TRUE if we should check for a tag-terminating
	 * byte (0x20 " " or 0x3E ">") after the pattern match.
	 */
	gboolean      has_tag_termination;
	const guchar *mask;
	const guchar *pattern;
	guint         pattern_length;
	const char   *sniffed_type;
	gboolean      scriptable;
} SoupContentSnifferPattern;


/* When has_ws is TRUE, spaces in the pattern will indicate where insignificant space
 * is allowed. Those spaces are marked with \x00 on the mask.
 */
static SoupContentSnifferPattern types_table[] = {
	/* Scriptable types. */

	{ TRUE, TRUE,
	  (const guchar *)"\x00\xFF\xFF\xDF\xDF\xDF\xDF\xDF\xDF\xDF\xFF\xDF\xDF\xDF\xDF",
	  (const guchar *)" <!DOCTYPE HTML",
	  14,
	  "text/html",
	  TRUE },

	{ TRUE, TRUE,
	  (const guchar *)"\x00\xFF\xDF\xDF\xDF\xDF",
	  (const guchar *)" <HTML",
	  5,
	  "text/html",
	  TRUE },

	{ TRUE, TRUE,
	  (const guchar *)"\x00\xFF\xDF\xDF\xDF\xDF",
	  (const guchar *)" <HEAD",
	  5,
	  "text/html",
	  TRUE },

	{ TRUE, TRUE,
	  (const guchar *)"\x00\xFF\xDF\xDF\xDF\xDF\xDF\xDF",
	  (const guchar *)" <SCRIPT",
	  7,
	  "text/html",
	  TRUE },

	{ TRUE, TRUE,
	  (const guchar *)"\x00\xFF\xDF\xDF\xDF\xDF\xDF\xDF",
	  (const guchar *)" <IFRAME",
	  7,
	  "text/html",
	  TRUE },

	{ TRUE, TRUE,
	  (const guchar *)"\x00\xFF\xDF\xFF",
	  (const guchar *)" <H1",
	  3,
	  "text/html",
	  TRUE },

	{ TRUE, TRUE,
	  (const guchar *)"\x00\xFF\xDF\xDF\xDF",
	  (const guchar *)" <DIV",
	  4,
	  "text/html",
	  TRUE },

	{ TRUE, TRUE,
	  (const guchar *)"\x00\xFF\xDF\xDF\xDF\xDF",
	  (const guchar *)" <FONT",
	  5,
	  "text/html",
	  TRUE },

	{ TRUE, TRUE,
	  (const guchar *)"\x00\xFF\xDF\xDF\xDF\xDF\xDF",
	  (const guchar *)" <TABLE",
	  6,
	  "text/html",
	  TRUE },

	{ TRUE, TRUE,
	  (const guchar *)"\x00\xFF\xDF",
	  (const guchar *)" <A",
	  2,
	  "text/html",
	  TRUE },

	{ TRUE, TRUE,
	  (const guchar *)"\x00\xFF\xDF\xDF\xDF\xDF\xDF",
	  (const guchar *)" <STYLE",
	  6,
	  "text/html",
	  TRUE },

	{ TRUE, TRUE,
	  (const guchar *)"\x00\xFF\xDF\xDF\xDF\xDF\xDF",
	  (const guchar *)" <TITLE",
	  6,
	  "text/html",
	  TRUE },

	{ TRUE, TRUE,
	  (const guchar *)"\x00\xFF\xDF",
	  (const guchar *)" <B",
	  2,
	  "text/html",
	  TRUE },

	{ TRUE, TRUE,
	  (const guchar *)"\x00\xFF\xDF\xDF\xDF\xDF",
	  (const guchar *)" <BODY",
	  5,
	  "text/html",
	  TRUE },

	{ TRUE, TRUE,
	  (const guchar *)"\x00\xFF\xDF\xDF",
	  (const guchar *)" <BR",
	  3,
	  "text/html",
	  TRUE },

	{ TRUE, TRUE,
	  (const guchar *)"\x00\xFF\xDF",
	  (const guchar *)" <P",
	  2,
	  "text/html",
	  TRUE },

	{ TRUE, TRUE,
	  (const guchar *)"\x00\xFF\xFF\xFF\xFF",
	  (const guchar *)" <!--",
	  4,
	  "text/html",
	  TRUE },

	{ TRUE, FALSE,
	  (const guchar *)"\x00\xFF\xFF\xFF\xFF\xFF",
	  (const guchar *)" <?xml",
	  5,
	  "text/xml",
	  TRUE },

	{ FALSE, FALSE,
	  (const guchar *)"\xFF\xFF\xFF\xFF\xFF",
	  (const guchar *)"%PDF-",
	  5,
	  "application/pdf",
	  TRUE },

	/* Non-scriptable types. */
	{ FALSE, FALSE,
	  (const guchar *)"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF",
	  (const guchar *)"%!PS-Adobe-",
	  11,
	  "application/postscript",
	  FALSE },

	{ FALSE, FALSE, /* UTF-16BE BOM */
	  (const guchar *)"\xFF\xFF\x00\x00",
	  (const guchar *)"\xFE\xFF\x00\x00",
	  4,
	  "text/plain",
	  FALSE },

	{ FALSE, FALSE, /* UTF-16LE BOM */
	  (const guchar *)"\xFF\xFF\x00\x00",
	  (const guchar *)"\xFF\xFE\x00\x00",
	  4,
	  "text/plain",
	  FALSE },

	{ FALSE, FALSE, /* UTF-8 BOM */
	  (const guchar *)"\xFF\xFF\xFF\x00",
	  (const guchar *)"\xEF\xBB\xBF\x00",
	  4,
	  "text/plain",
	  FALSE },
};

/* Whether a given byte looks like it might be part of binary content.
 * Source: HTML5 spec; borrowed from the Chromium mime sniffer code,
 * which is BSD-licensed
 */
static char byte_looks_binary[] = {
	1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1,  /* 0x00 - 0x0F */
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1,  /* 0x10 - 0x1F */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  /* 0x20 - 0x2F */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  /* 0x30 - 0x3F */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  /* 0x40 - 0x4F */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  /* 0x50 - 0x5F */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  /* 0x60 - 0x6F */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  /* 0x70 - 0x7F */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  /* 0x80 - 0x8F */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  /* 0x90 - 0x9F */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  /* 0xA0 - 0xAF */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  /* 0xB0 - 0xBF */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  /* 0xC0 - 0xCF */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  /* 0xD0 - 0xDF */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  /* 0xE0 - 0xEF */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  /* 0xF0 - 0xFF */
};

/* HTML5: 2.7.4 Content-Type sniffing: unknown type */
static char*
sniff_unknown (SoupContentSniffer *sniffer, GBytes *buffer,
	       gboolean sniff_scriptable)
{
	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 1\n");
	char *sniffed_type = NULL;
	gsize resource_length;
	const guchar *resource = g_bytes_get_data (buffer, &resource_length);
	resource_length = MIN (512, resource_length);
	guint i;
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 1\n");

        if (resource_length == 0) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 2\n");
                return g_strdup ("text/plain");
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 2\n");
	}

	for (i = 0; i < G_N_ELEMENTS (types_table); i++) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 3\n");
		SoupContentSnifferPattern *type_row = &(types_table[i]);
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 3\n");

		if (!sniff_scriptable && type_row->scriptable) {
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 4\n");
			continue;
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 4\n");
		}

		if (type_row->has_ws) {
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 5\n");
			guint index_stream = 0;
			guint index_pattern = 0;
			gboolean skip_row = FALSE;
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 5\n");

			while ((index_stream < resource_length - 1) &&
			       (index_pattern <= type_row->pattern_length)) {
				fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 6\n");
				/* Skip insignificant white space ("WS" in the spec) */
				if (type_row->pattern[index_pattern] == ' ') {
					fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 7\n");
					if (resource[index_stream] == '\x09' ||
					    resource[index_stream] == '\x0a' ||
					    resource[index_stream] == '\x0c' ||
					    resource[index_stream] == '\x0d' ||
					    resource[index_stream] == '\x20')
						index_stream++;
					else
						index_pattern++;
					// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 7\n");
				} else {
					fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 8\n");
					if ((type_row->mask[index_pattern] & resource[index_stream]) != type_row->pattern[index_pattern]) {
						fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 9\n");
						skip_row = TRUE;
						break;
						// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 9\n");
					}
					index_pattern++;
					index_stream++;
					// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 8\n");
				}
				// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 6\n");
			}

			if (skip_row) {
				fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 11\n");
				continue;
				// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 11\n");
			}

			if (index_pattern > type_row->pattern_length) {
				fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 12\n");
				if (type_row->has_tag_termination &&
				    resource[index_stream] != '\x20' &&
				    resource[index_stream] != '\x3E') {
					fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 13\n");
					continue;
					// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 13\n");
				}

				fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 14\n");
				return g_strdup (type_row->sniffed_type);
				// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 14\n");
				// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 12\n");
			}
		} else {
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 15\n");
			guint j;
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 15\n");

			if (resource_length < type_row->pattern_length) {
				fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 16\n");
				continue;
				// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 16\n");
			}

			for (j = 0; j < type_row->pattern_length; j++) {
				fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 17\n");
				if ((type_row->mask[j] & resource[j]) != type_row->pattern[j])
					break;
				// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 17\n");
			}

			/* This means our comparison above matched completely */
			if (j == type_row->pattern_length) {
				fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 18\n");
				return g_strdup (type_row->sniffed_type);
				// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 18\n");
			}
		}
	}

	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 19\n");
	sniffed_type = sniff_images (sniffer, buffer);
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 19\n");

	if (sniffed_type != NULL) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 20\n");
		return sniffed_type;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 20\n");
	}

	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 21\n");
	sniffed_type = sniff_audio_video (sniffer, buffer);
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 21\n");

	if (sniffed_type != NULL) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 22\n");
		return sniffed_type;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 22\n");
	}

	for (i = 0; i < resource_length; i++) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 23\n");
		if (byte_looks_binary[resource[i]]) {
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 24\n");
			return g_strdup ("application/octet-stream");
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 24\n");
		}
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 23\n");
	}

	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_unknown 25\n");
	return g_strdup ("text/plain");
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_unknown 25\n");
}

/* MIMESNIFF: 7.2 Sniffing a mislabeled binary resource */
static char*
sniff_text_or_binary (SoupContentSniffer *sniffer, GBytes *buffer)
{
	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_text_or_binary 1\n");
	gsize resource_length;
	const guchar *resource = g_bytes_get_data (buffer, &resource_length);
	resource_length = MIN (512, resource_length);
	gboolean looks_binary = FALSE;
	int i;
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_text_or_binary 1\n");

	/* 2. Detecting UTF-16BE, UTF-16LE BOMs means it's text/plain */
	if (resource_length >= 2) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_text_or_binary 2\n");
		if ((resource[0] == 0xFE && resource[1] == 0xFF) ||
		    (resource[0] == 0xFF && resource[1] == 0xFE)) {
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_text_or_binary 3\n");
			return g_strdup ("text/plain");
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_text_or_binary 3\n");
		}
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_text_or_binary 2\n");
	}

	/* 3. UTF-8 BOM. */
	if (resource_length >= 3) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_text_or_binary 4\n");
		if (resource[0] == 0xEF && resource[1] == 0xBB && resource[2] == 0xBF) {
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_text_or_binary 5\n");
			return g_strdup ("text/plain");
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_text_or_binary 5\n");
		}
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_text_or_binary 4\n");
	}

	/* 4. Look to see if any of the first n bytes looks binary */
	for (i = 0; i < resource_length; i++) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_text_or_binary 6\n");
		if (byte_looks_binary[resource[i]]) {
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_text_or_binary 7\n");
			looks_binary = TRUE;
			break;
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_text_or_binary 7\n");
		}
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_text_or_binary 6\n");
	}

	if (!looks_binary) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_text_or_binary 8\n");
		return g_strdup ("text/plain");
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_text_or_binary 8\n");
	}

	/* 5. Execute 7.1 Identifying a resource with an unknown MIME type.
	 * TODO: sniff-scriptable needs to be unset.
	 */
	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_text_or_binary 9\n");
	return sniff_unknown (sniffer, buffer, TRUE);
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_text_or_binary 9\n");
}

static gboolean
skip_insignificant_space (const char *resource, gsize *pos, gsize resource_length)
{
	fprintf(stderr, "\n");
        if (*pos >= resource_length) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter skip_insignificant_space 2\n");
	        return TRUE;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit skip_insignificant_space 2\n");
	}

	while ((resource[*pos] == '\x09') ||
	       (resource[*pos] == '\x20') ||
	       (resource[*pos] == '\x0A') ||
	       (resource[*pos] == '\x0D')) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter skip_insignificant_space 3\n");
		*pos = *pos + 1;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit skip_insignificant_space 3\n");

		if (*pos >= resource_length) {
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter skip_insignificant_space 4\n");
			return TRUE;
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit skip_insignificant_space 4\n");
		}
	}

	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter skip_insignificant_space 5\n");
	return FALSE;
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit skip_insignificant_space 5\n");
}
static char*
sniff_feed_or_html (SoupContentSniffer *sniffer, GBytes *buffer)
{
	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 1\n");
	gsize resource_length;
	const char *resource = g_bytes_get_data (buffer, &resource_length);
	resource_length = MIN (512, resource_length);
	gsize pos = 0;
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 1\n");

	if (resource_length < 3)
	{
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 2\n");
		goto text_html;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 2\n");
	}

	/* Skip a leading UTF-8 BOM */
	if ((guchar)resource[0] == 0xEF && (guchar)resource[1] == 0xBB && (guchar)resource[2] == 0xBF)
	{
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 3\n");
		pos = 3;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 3\n");
	}

 look_for_tag:
	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 4\n");
	if (skip_insignificant_space (resource, &pos, resource_length))
	{
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 5\n");
		goto text_html;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 5\n");
	}
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 4\n");

	if (resource[pos] != '<')
	{
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 6\n");
		return g_strdup ("text/html");
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 6\n");
	}

	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 7\n");
	pos++;
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 7\n");

	if ((pos + 2) > resource_length)
	{
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 8\n");
		goto text_html;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 8\n");
	}

	/* Skip comments. */
	if (data_has_prefix (resource + pos, "!--", resource_length - pos)) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 9\n");
		pos = pos + 3;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 9\n");

		if ((pos + 2) > resource_length)
		{
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 10\n");
			goto text_html;
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 10\n");
		}

		while (!data_has_prefix (resource + pos, "-->", resource_length - pos)) {
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 11\n");
			pos++;
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 11\n");

			if ((pos + 2) > resource_length)
			{
				fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 12\n");
				goto text_html;
				// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 12\n");
			}
		}

		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 13\n");
		pos = pos + 3;

		goto look_for_tag;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 13\n");
	}

	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 14\n");
	if (pos > resource_length)
	{
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 15\n");
		goto text_html;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 15\n");
	}
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 14\n");

	if (resource[pos] == '!') {
		fprintf(stderr, "\n");
		do {
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 17\n");
			pos++;
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 17\n");

			if ((pos + 1) > resource_length)
			{
				fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 18\n");
				goto text_html;
				// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 18\n");
			}
		} while (resource[pos] != '>');

		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 19\n");
		pos++;

		goto look_for_tag;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 19\n");
	} else if (resource[pos] == '?') {
		fprintf(stderr, "\n");
		do {
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 21\n");
			pos++;
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 21\n");

			if ((pos + 1) > resource_length)
			{
				fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 22\n");
				goto text_html;
				// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 22\n");
			}
		} while (!data_has_prefix (resource + pos, "?>", resource_length - pos));

		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 23\n");
		pos = pos + 2;

		goto look_for_tag;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 23\n");
	}

	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 24\n");
	if ((pos + 3) > resource_length)
	{
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 25\n");
		goto text_html;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 25\n");
	}
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 24\n");

	if (data_has_prefix (resource + pos, "rss", resource_length - pos))
	{
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 26\n");
		return g_strdup ("application/rss+xml");
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 26\n");
	}

	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 27\n");
	if ((pos + 4) > resource_length)
	{
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 28\n");
		goto text_html;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 28\n");
	}
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 27\n");

	if (data_has_prefix (resource + pos, "feed", resource_length - pos))
	{
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 29\n");
		return g_strdup ("application/atom+xml");
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 29\n");
	}

	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 30\n");
	if ((pos + 7) > resource_length)
	{
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 31\n");
		goto text_html;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 31\n");
	}
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 30\n");

	if (data_has_prefix (resource + pos, "rdf:RDF", resource_length - pos)) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 32\n");
		pos = pos + 7;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 32\n");

		if (skip_insignificant_space (resource, &pos, resource_length))
		{
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 33\n");
			goto text_html;
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 33\n");
		}

		if ((pos + 32) > resource_length)
		{
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 34\n");
			goto text_html;
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 34\n");
		}

		if (data_has_prefix (resource + pos, "xmlns=\"http://purl.org/rss/1.0/\"", resource_length - pos)) {
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 35\n");
			pos = pos + 32;
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 35\n");

			if (skip_insignificant_space (resource, &pos, resource_length))
			{
				fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 36\n");
				goto text_html;
				// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 36\n");
			}

			if ((pos + 55) > resource_length)
			{
				fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 37\n");
				goto text_html;
				// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 37\n");
			}

			if (data_has_prefix (resource + pos, "xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"", resource_length - pos))
			{
				fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 38\n");
				return g_strdup ("application/rss+xml");
				// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 38\n");
			}
		}

		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 39\n");
		if ((pos + 55) > resource_length)
		{
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 40\n");
			goto text_html;
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 40\n");
		}
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 39\n");

		if (data_has_prefix (resource + pos, "xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"", resource_length - pos)) {
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 41\n");
			pos = pos + 55;
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 41\n");

			if (skip_insignificant_space (resource, &pos, resource_length))
			{
				fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 42\n");
				goto text_html;
				// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 42\n");
			}

			if ((pos + 32) > resource_length)
			{
				fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 43\n");
				goto text_html;
				// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 43\n");
			}

			if (data_has_prefix (resource + pos, "xmlns=\"http://purl.org/rss/1.0/\"", resource_length - pos))
			{
				fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 44\n");
				return g_strdup ("application/rss+xml");
				// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 44\n");
			}
		}
	}

 text_html:
	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter sniff_feed_or_html 45\n");
	return g_strdup ("text/html");
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit sniff_feed_or_html 45\n");
}

/**
 * soup_content_sniffer_sniff:
 * @sniffer: a #SoupContentSniffer
 * @msg: the message to sniff
 * @buffer: a buffer containing the start of @msg's response body
 * @params: (element-type utf8 utf8) (out) (transfer full) (nullable): return
 *   location for Content-Type parameters (eg, "charset"), or %NULL
 *
 * Sniffs @buffer to determine its Content-Type.
 *
 * The result may also be influenced by the Content-Type declared in @msg's
 * response headers.
 *
 * Returns: the sniffed Content-Type of @buffer; this will never be %NULL,
 *   but may be `application/octet-stream`.
 */
char *
soup_content_sniffer_sniff (SoupContentSniffer *sniffer, SoupMessage *msg,
			    GBytes *buffer, GHashTable **params)
{
	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter soup_content_sniffer_sniff 1\n");
	const char *content_type;
	const char *x_content_type_options;
	char *sniffed_type = NULL;
	gboolean no_sniff = FALSE;

	content_type = soup_message_headers_get_content_type (soup_message_get_response_headers (msg), params);
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit soup_content_sniffer_sniff 1\n");

	/* MIMESNIFF: 7 Determining the sniffed MIME type of a resource. */

	x_content_type_options = soup_message_headers_get_one_common (soup_message_get_response_headers (msg), SOUP_HEADER_X_CONTENT_TYPE_OPTIONS);
	if (!g_strcmp0 (x_content_type_options, "nosniff"))
	{
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter soup_content_sniffer_sniff 2\n");
		no_sniff = TRUE;
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit soup_content_sniffer_sniff 2\n");
	}

	/* 1. Unknown/undefined supplied type with sniff-scritable = !nosniff. */
	if ((content_type == NULL) ||
	    !g_ascii_strcasecmp (content_type, "unknown/unknown") ||
	    !g_ascii_strcasecmp (content_type, "application/unknown") ||
	    !g_ascii_strcasecmp (content_type, "*/*"))
	{
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter soup_content_sniffer_sniff 3\n");
		return sniff_unknown (sniffer, buffer, !no_sniff);
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit soup_content_sniffer_sniff 3\n");
	}

	/* 2. If nosniff is specified in X-Content-Type-Options use the supplied MIME type. */
	if (no_sniff)
	{
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter soup_content_sniffer_sniff 4\n");
		return g_strdup (content_type);
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit soup_content_sniffer_sniff 4\n");
	}

	/* 3. check-for-apache-bug */
	if ((content_type != NULL) &&
	    (g_str_equal (content_type, "text/plain") ||
	     g_str_equal (content_type, "text/plain; charset=ISO-8859-1") ||
	     g_str_equal (content_type, "text/plain; charset=iso-8859-1") ||
	     g_str_equal (content_type, "text/plain; charset=UTF-8")))
	{
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter soup_content_sniffer_sniff 5\n");
		return sniff_text_or_binary (sniffer, buffer);
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit soup_content_sniffer_sniff 5\n");
	}

	/* 4. XML types sent by the server are always used. */
	if (g_str_has_suffix (content_type, "+xml") ||
	    !g_ascii_strcasecmp (content_type, "text/xml") ||
	    !g_ascii_strcasecmp (content_type, "application/xml"))
	{
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter soup_content_sniffer_sniff 6\n");
		return g_strdup (content_type);
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit soup_content_sniffer_sniff 6\n");
	}

	/* 5. Distinguish feed from HTML. */
	if (!g_ascii_strcasecmp (content_type, "text/html"))
	{
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter soup_content_sniffer_sniff 7\n");
		return sniff_feed_or_html (sniffer, buffer);
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit soup_content_sniffer_sniff 7\n");
	}

	/* 6. Image types.
	 */
	if (!g_ascii_strncasecmp (content_type, "image/", 6)) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter soup_content_sniffer_sniff 8\n");
		sniffed_type = sniff_images (sniffer, buffer);
		if (sniffed_type != NULL)
		{
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter soup_content_sniffer_sniff 9\n");
			return sniffed_type;
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit soup_content_sniffer_sniff 9\n");
		}
		return g_strdup (content_type);
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit soup_content_sniffer_sniff 8\n");
	}

	/* 7. Audio and video types. */
	if (!g_ascii_strncasecmp (content_type, "audio/", 6) ||
	    !g_ascii_strncasecmp (content_type, "video/", 6) ||
	    !g_ascii_strcasecmp (content_type, "application/ogg")) {
	        fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter soup_content_sniffer_sniff 10\n");
	        sniffed_type = sniff_audio_video (sniffer, buffer);
	        if (sniffed_type != NULL)
	        {
			fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter soup_content_sniffer_sniff 11\n");
		        return sniffed_type;
			// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit soup_content_sniffer_sniff 11\n");
		}
		return g_strdup (content_type);
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit soup_content_sniffer_sniff 10\n");
        }

	/* If we got text/plain, use text_or_binary */
	if (g_str_equal (content_type, "text/plain")) {
		fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter soup_content_sniffer_sniff 12\n");
		return sniff_text_or_binary (sniffer, buffer);
		// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit soup_content_sniffer_sniff 12\n");
	}

	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter soup_content_sniffer_sniff 13\n");
	return g_strdup (content_type);
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit soup_content_sniffer_sniff 13\n");
}

static void
soup_content_sniffer_request_queued (SoupSessionFeature *feature,
				     SoupMessage        *msg)
{
	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter soup_content_sniffer_request_queued 1\n");
	soup_message_set_content_sniffer (msg, SOUP_CONTENT_SNIFFER (feature));
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit soup_content_sniffer_request_queued 1\n");
}

static void
soup_content_sniffer_request_unqueued (SoupSessionFeature *feature,
				       SoupMessage        *msg)
{
	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter soup_content_sniffer_request_unqueued 1\n");
	soup_message_set_content_sniffer (msg, NULL);
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit soup_content_sniffer_request_unqueued 1\n");
}

static void
soup_content_sniffer_class_init (SoupContentSnifferClass *content_sniffer_class)
{
	fprintf(stderr, "\n");
	// fprintf(stderr, "\n");
}

static void
soup_content_sniffer_session_feature_init (SoupSessionFeatureInterface *feature_interface,
					   gpointer interface_data)
{
	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter soup_content_sniffer_session_feature_init 1\n");
	feature_interface->request_queued = soup_content_sniffer_request_queued;
	feature_interface->request_unqueued = soup_content_sniffer_request_unqueued;
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit soup_content_sniffer_session_feature_init 1\n");
}

/**
 * soup_content_sniffer_new:
 *
 * Creates a new #SoupContentSniffer.
 *
 * Returns: a new #SoupContentSniffer
 **/
SoupContentSniffer *
soup_content_sniffer_new (void)
{
	fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] enter soup_content_sniffer_new 1\n");
	return g_object_new (SOUP_TYPE_CONTENT_SNIFFER, NULL);
	// fprintf(stderr, "[libsoup/content-sniffer/soup-content-sniffer.c] exit soup_content_sniffer_new 1\n");
}
// Total cost: 0.925338
// Total split cost: 0.059746, input tokens: 24900, output tokens: 749, cache read tokens: 24887, cache write tokens: 10935, split chunks: [(0, 658), (658, 917)]
// Total instrumented cost: 0.865592, input tokens: 64451, output tokens: 46174, cache read tokens: 64431, cache write tokens: 40958

/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright (C) 2008 Red Hat, Inc.
 */

#pragma once

#include "soup-cookie-jar.h"

G_BEGIN_DECLS

#define SOUP_TYPE_COOKIE_JAR_TEXT (soup_cookie_jar_text_get_type ())
SOUP_AVAILABLE_IN_ALL
G_DECLARE_FINAL_TYPE (SoupCookieJarText, soup_cookie_jar_text, SOUP, COOKIE_JAR_TEXT, SoupCookieJar)

SOUP_AVAILABLE_IN_ALL
SoupCookieJar *soup_cookie_jar_text_new (const char *filename,
					 gboolean    read_only);

G_END_DECLS

// Total cost: 0.002215
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 21)]
// Total instrumented cost: 0.002215, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 304

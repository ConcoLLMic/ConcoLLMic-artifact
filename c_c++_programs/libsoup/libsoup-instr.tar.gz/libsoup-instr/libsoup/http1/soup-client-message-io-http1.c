/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * soup-message-io.c: HTTP message I/O
 *
 * Copyright (C) 2000-2003, Ximian, Inc.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <glib/gi18n-lib.h>

#ifdef HAVE_SYSPROF
#include <sysprof-capture.h>
#endif
#include <stdio.h>

#include "soup-client-message-io-http1.h"
#include "soup.h"
#include "soup-body-input-stream.h"
#include "soup-body-output-stream.h"
#include "soup-client-input-stream.h"
#include "soup-connection.h"
#include "soup-session-private.h"
#include "soup-filter-input-stream.h"
#include "soup-logger-private.h"
#include "soup-message-private.h"
#include "soup-message-headers-private.h"
#include "soup-message-metrics-private.h"
#include "soup-message-queue-item.h"
#include "soup-misc.h"
#include "soup-uri-utils-private.h"

typedef struct {
        SoupMessageIOData base;

        SoupMessageQueueItem *item;

        gint64 response_header_bytes_received;
        SoupMessageMetrics *metrics;

        /* Request body logger */
        SoupLogger *logger;

#ifdef HAVE_SYSPROF
        gint64 begin_time_nsec;
#endif
} SoupMessageIOHTTP1;

typedef struct {
        SoupClientMessageIO iface;

        GIOStream *iostream;
        GInputStream *istream;
        GOutputStream *ostream;

        SoupMessageIOHTTP1 *msg_io;
        gboolean is_reusable;
        gboolean ever_used;
} SoupClientMessageIOHTTP1;

#define RESPONSE_BLOCK_SIZE 8192
#define HEADER_SIZE_LIMIT (100 * 1024)

static void
soup_message_io_http1_free (SoupMessageIOHTTP1 *msg_io)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_message_io_http1_free 1\n");
        soup_message_io_data_cleanup (&msg_io->base);
        soup_message_queue_item_unref (msg_io->item);
        g_free (msg_io);
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_message_io_http1_free 1\n");
}

static void
soup_client_message_io_http1_destroy (SoupClientMessageIO *iface)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_destroy 1\n");
        SoupClientMessageIOHTTP1 *io = (SoupClientMessageIOHTTP1 *)iface;

        g_clear_object (&io->iostream);
        g_clear_pointer (&io->msg_io, soup_message_io_http1_free);

        g_slice_free (SoupClientMessageIOHTTP1, io);
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_destroy 1\n");
}

static int
soup_client_message_io_http1_get_priority (SoupClientMessageIOHTTP1 *io)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_get_priority 1\n");
        if (!io->msg_io->item->task) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_get_priority 2\n");
                return G_PRIORITY_DEFAULT;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_get_priority 2\n");
        }

        return g_task_get_priority (io->msg_io->item->task);
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_get_priority 1\n");
}

static void
soup_client_message_io_complete (SoupClientMessageIOHTTP1 *io,
                                 SoupMessage *msg,
                                 SoupMessageIOCompletion completion)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_complete 1\n");
        SoupMessageIOCompletionFn completion_cb;
        gpointer completion_data;

        completion_cb = io->msg_io->base.completion_cb;
        completion_data = io->msg_io->base.completion_data;

        g_object_ref (msg);
        if (io->istream) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_complete 2\n");
                g_signal_handlers_disconnect_by_data (io->istream, msg);
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_complete 2\n");
        }
        if (io->msg_io->base.body_ostream) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_complete 3\n");
                g_signal_handlers_disconnect_by_data (io->msg_io->base.body_ostream, msg);
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_complete 3\n");
        }
        g_clear_pointer (&io->msg_io, soup_message_io_http1_free);
        if (completion_cb) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_complete 4\n");
                completion_cb (G_OBJECT (msg), completion, completion_data);
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_complete 4\n");
        }
        g_object_unref (msg);
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_complete 1\n");
}

static void
soup_client_message_io_http1_finished (SoupClientMessageIO *iface,
                                       SoupMessage         *msg)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_finished 1\n");
        SoupClientMessageIOHTTP1 *io = (SoupClientMessageIOHTTP1 *)iface;
        SoupMessageIOCompletion completion;

        if ((io->msg_io->base.read_state >= SOUP_MESSAGE_IO_STATE_FINISHING &&
             io->msg_io->base.write_state >= SOUP_MESSAGE_IO_STATE_FINISHING)) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_finished 2\n");
                completion = SOUP_MESSAGE_IO_COMPLETE;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_finished 2\n");
        } else {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_finished 3\n");
                completion = SOUP_MESSAGE_IO_INTERRUPTED;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_finished 3\n");
        }

        soup_client_message_io_complete (io, msg, completion);
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_finished 1\n");
}

static void
soup_client_message_io_http1_stolen (SoupClientMessageIO *iface)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_stolen 1\n");
        SoupClientMessageIOHTTP1 *io = (SoupClientMessageIOHTTP1 *)iface;

        soup_client_message_io_complete (io, io->msg_io->item->msg, SOUP_MESSAGE_IO_STOLEN);
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_stolen 1\n");
}

static void
request_body_stream_wrote_data_cb (SoupMessage *msg,
                                   const void  *buffer,
                                   guint        count,
                                   gboolean     is_metadata)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter request_body_stream_wrote_data_cb 1\n");
        SoupClientMessageIOHTTP1 *client_io = (SoupClientMessageIOHTTP1 *)soup_message_get_io_data (msg);

        if (client_io->msg_io->metrics) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter request_body_stream_wrote_data_cb 2\n");
                client_io->msg_io->metrics->request_body_bytes_sent += count;
                if (!is_metadata)
                        client_io->msg_io->metrics->request_body_size += count;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit request_body_stream_wrote_data_cb 2\n");
        }

        if (!is_metadata) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter request_body_stream_wrote_data_cb 3\n");
                if (client_io->msg_io->logger)
                        soup_logger_log_request_data (client_io->msg_io->logger, msg, (const char *)buffer, count);
                soup_message_wrote_body_data (msg, count);
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit request_body_stream_wrote_data_cb 3\n");
        }
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit request_body_stream_wrote_data_cb 1\n");
}

static void
request_body_stream_wrote_cb (GOutputStream *ostream,
                              GAsyncResult  *result,
                              SoupMessage   *msg)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter request_body_stream_wrote_cb 1\n");
        SoupClientMessageIOHTTP1 *io;
        gssize nwrote;
        GCancellable *async_wait;
        GError *error = NULL;

        nwrote = g_output_stream_splice_finish (ostream, result, &error);

        io = (SoupClientMessageIOHTTP1 *)soup_message_get_io_data (msg);
        if (!io || !io->msg_io || !io->msg_io->base.async_wait || io->msg_io->base.body_ostream != ostream) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter request_body_stream_wrote_cb 2\n");
                g_clear_error (&error);
                g_object_unref (msg);
                return;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit request_body_stream_wrote_cb 2\n");
        }

        if (nwrote != -1) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter request_body_stream_wrote_cb 3\n");
                io->msg_io->base.write_state = SOUP_MESSAGE_IO_STATE_BODY_FLUSH;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit request_body_stream_wrote_cb 3\n");
        }

        if (error) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter request_body_stream_wrote_cb 4\n");
                g_propagate_error (&io->msg_io->base.async_error, error);
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit request_body_stream_wrote_cb 4\n");
        }
        async_wait = io->msg_io->base.async_wait;
        io->msg_io->base.async_wait = NULL;
        g_cancellable_cancel (async_wait);
        g_object_unref (async_wait);

        g_object_unref (msg);
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit request_body_stream_wrote_cb 1\n");
}

static void
closed_async (GObject      *source,
              GAsyncResult *result,
              gpointer      user_data)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter closed_async 1\n");
        GOutputStream *body_ostream = G_OUTPUT_STREAM (source);
        SoupMessage *msg = user_data;
        SoupClientMessageIOHTTP1 *io;
        GCancellable *async_wait;

        io = (SoupClientMessageIOHTTP1 *)soup_message_get_io_data (msg);
        if (!io || !io->msg_io || !io->msg_io->base.async_wait || io->msg_io->base.body_ostream != body_ostream) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter closed_async 2\n");
                g_object_unref (msg);
                return;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit closed_async 2\n");
        }

        g_output_stream_close_finish (body_ostream, result, &io->msg_io->base.async_error);
        g_clear_object (&io->msg_io->base.body_ostream);

        async_wait = io->msg_io->base.async_wait;
        io->msg_io->base.async_wait = NULL;
        g_cancellable_cancel (async_wait);
        g_object_unref (async_wait);

        g_object_unref (msg);
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit closed_async 1\n");
}

/*
 * There are two request/response formats: the basic request/response,
 * possibly with one or more unsolicited informational responses (such
 * as the WebDAV "102 Processing" response):
 *
 *     Client                            Server
 *      W:HEADERS  / R:NOT_STARTED    ->  R:HEADERS  / W:NOT_STARTED
 *      W:BODY     / R:NOT_STARTED    ->  R:BODY     / W:NOT_STARTED
 *     [W:DONE     / R:HEADERS (1xx)  <-  R:DONE     / W:HEADERS (1xx) ...]
 *      W:DONE     / R:HEADERS        <-  R:DONE     / W:HEADERS
 *      W:DONE     / R:BODY           <-  R:DONE     / W:BODY
 *      W:DONE     / R:DONE               R:DONE     / W:DONE
 *     
 * and the "Expect: 100-continue" request/response, with the client
 * blocking halfway through its request, and then either continuing or
 * aborting, depending on the server response:
 *
 *     Client                            Server
 *      W:HEADERS  / R:NOT_STARTED    ->  R:HEADERS  / W:NOT_STARTED
 *      W:BLOCKING / R:HEADERS        <-  R:BLOCKING / W:HEADERS
 *     [W:BODY     / R:BLOCKING       ->  R:BODY     / W:BLOCKING]
 *     [W:DONE     / R:HEADERS        <-  R:DONE     / W:HEADERS]
 *      W:DONE     / R:BODY           <-  R:DONE     / W:BODY
 *      W:DONE     / R:DONE               R:DONE     / W:DONE
 */

static void
write_headers (SoupMessage  *msg,
               GString      *header,
               SoupEncoding *encoding)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter write_headers 1\n");
        GUri *uri = soup_message_get_uri (msg);
        char *uri_string;
        SoupMessageHeadersIter iter;
        const char *name, *value;

        if (soup_message_get_method (msg) == SOUP_METHOD_CONNECT) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter write_headers 2\n");
                char *uri_host = soup_uri_get_host_for_headers (uri);

                /* CONNECT URI is hostname:port for tunnel destination */
                uri_string = g_strdup_printf ("%s:%d", uri_host, g_uri_get_port (uri));
                g_free (uri_host);
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit write_headers 2\n");
        } else {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter write_headers 3\n");
                SoupConnection *conn = soup_message_get_connection (msg);
                gboolean proxy = soup_connection_is_via_proxy (conn);

                g_object_unref (conn);

                /* Proxy expects full URI to destination. Otherwise
                 * just the path.
                 */
                if (proxy) {
                        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter write_headers 4\n");
                        uri_string = g_uri_to_string (uri);
                        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit write_headers 4\n");
                } else if (soup_message_get_is_options_ping (msg)) {
                        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter write_headers 5\n");
                        uri_string = g_strdup ("*");
                        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit write_headers 5\n");
                } else {
                        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter write_headers 6\n");
                        uri_string = soup_uri_get_path_and_query (uri);
                        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit write_headers 6\n");
                }

                if (proxy && g_uri_get_fragment (uri)) {
                        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter write_headers 7\n");
                        /* Strip fragment */
                        char *fragment = strchr (uri_string, '#');
                        if (fragment)
                                *fragment = '\0';
                        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit write_headers 7\n");
                }
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit write_headers 3\n");
        }

        g_string_append_printf (header, "%s %s HTTP/1.%d\r\n",
                                soup_message_get_method (msg), uri_string,
                                (soup_message_get_http_version (msg) == SOUP_HTTP_1_0) ? 0 : 1);
        g_free (uri_string);

        *encoding = soup_message_headers_get_encoding (soup_message_get_request_headers (msg));

        soup_message_headers_iter_init (&iter, soup_message_get_request_headers (msg));
        while (soup_message_headers_iter_next (&iter, &name, &value))
                g_string_append_printf (header, "%s: %s\r\n", name, value);
        g_string_append (header, "\r\n");
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit write_headers 1\n");
}

/* Attempts to push forward the writing side of @msg's I/O. Returns
 * %TRUE if it manages to make some progress, and it is likely that
 * further progress can be made. Returns %FALSE if it has reached a
 * stopping point of some sort (need input from the application,
 * socket not writable, write is complete, etc).
 */
static gboolean
io_write (SoupClientMessageIOHTTP1 *client_io,
          gboolean                  blocking,
          GCancellable             *cancellable,
          GError                  **error)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_write 1\n");
        SoupMessageIOData *io = &client_io->msg_io->base;
        SoupMessage *msg = client_io->msg_io->item->msg;
        SoupSessionFeature *logger;
        gssize nwrote;

        if (io->async_error) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_write 2\n");
                g_propagate_error (error, io->async_error);
                io->async_error = NULL;
                return FALSE;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_write 2\n");
        } else if (io->async_wait) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_write 3\n");
                g_set_error_literal (error, G_IO_ERROR,
                                     G_IO_ERROR_WOULD_BLOCK,
                                     _("Operation would block"));
                return FALSE;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_write 3\n");
        }

        switch (io->write_state) {
        case SOUP_MESSAGE_IO_STATE_HEADERS:
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_write 4\n");
                if (!io->write_buf->len)
                        write_headers (msg, io->write_buf, &io->write_encoding);

                while (io->written < io->write_buf->len) {
                        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_write 5\n");
                        nwrote = g_pollable_stream_write (client_io->ostream,
                                                          io->write_buf->str + io->written,
                                                          io->write_buf->len - io->written,
                                                          blocking,
                                                          cancellable, error);
                        if (nwrote == -1)
                                return FALSE;
                        io->written += nwrote;
                        if (client_io->msg_io->metrics)
                                client_io->msg_io->metrics->request_header_bytes_sent += nwrote;
                        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_write 5\n");
                }

                io->written = 0;
                g_string_truncate (io->write_buf, 0);

                if (io->write_encoding == SOUP_ENCODING_CONTENT_LENGTH)
                        io->write_length = soup_message_headers_get_content_length (soup_message_get_request_headers (msg));

                if (soup_message_headers_get_expectations (soup_message_get_request_headers (msg)) & SOUP_EXPECTATION_CONTINUE) {
                        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_write 6\n");
                        /* Need to wait for the Continue response */
                        io->write_state = SOUP_MESSAGE_IO_STATE_BLOCKING;
                        io->read_state = SOUP_MESSAGE_IO_STATE_HEADERS;
                        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_write 6\n");
                } else {
                        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_write 7\n");
                        io->write_state = SOUP_MESSAGE_IO_STATE_BODY_START;
                        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_write 7\n");
                }

                soup_message_wrote_headers (msg);
                break;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_write 4\n");

        case SOUP_MESSAGE_IO_STATE_BODY_START:
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_write 8\n");
                io->body_ostream = soup_body_output_stream_new (client_io->ostream,
                                                                io->write_encoding,
                                                                io->write_length);
                io->write_state = SOUP_MESSAGE_IO_STATE_BODY;
                logger = soup_session_get_feature_for_message (client_io->msg_io->item->session,
                                                               SOUP_TYPE_LOGGER, msg);
                client_io->msg_io->logger = logger ? SOUP_LOGGER (logger) : NULL;
                break;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_write 8\n");

        case SOUP_MESSAGE_IO_STATE_BODY:
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_write 9\n");
                if (!io->write_length &&
                    io->write_encoding != SOUP_ENCODING_EOF &&
                    io->write_encoding != SOUP_ENCODING_CHUNKED) {
                        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_write 10\n");
                        io->write_state = SOUP_MESSAGE_IO_STATE_BODY_FLUSH;
                        break;
                        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_write 10\n");
                }

                if (soup_message_get_request_body_stream (msg)) {
                        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_write 11\n");
                        g_signal_connect_object (io->body_ostream,
                                                 "wrote-data",
                                                 G_CALLBACK (request_body_stream_wrote_data_cb),
                                                 msg, G_CONNECT_SWAPPED);
                        if (blocking) {
                                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_write 12\n");
                                nwrote = g_output_stream_splice (io->body_ostream,
                                                                 soup_message_get_request_body_stream (msg),
                                                                 G_OUTPUT_STREAM_SPLICE_CLOSE_SOURCE,
                                                                 cancellable,
                                                                 error);
                                if (nwrote == -1)
                                        return FALSE;
                                io->write_state = SOUP_MESSAGE_IO_STATE_BODY_FLUSH;
                                break;
                                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_write 12\n");
                        } else {
                                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_write 13\n");
                                io->async_wait = g_cancellable_new ();
                                g_output_stream_splice_async (io->body_ostream,
                                                              soup_message_get_request_body_stream (msg),
                                                              G_OUTPUT_STREAM_SPLICE_CLOSE_SOURCE,
                                                              soup_client_message_io_http1_get_priority (client_io),
                                                              cancellable,
                                                              (GAsyncReadyCallback)request_body_stream_wrote_cb,
                                                              g_object_ref (msg));
                                return FALSE;
                                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_write 13\n");
                        }
                        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_write 11\n");
                } else {
                        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_write 14\n");
                        io->write_state = SOUP_MESSAGE_IO_STATE_BODY_FLUSH;
                        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_write 14\n");
                }
                break;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_write 9\n");

        case SOUP_MESSAGE_IO_STATE_BODY_FLUSH:
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_write 15\n");
                if (io->body_ostream) {
                        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_write 16\n");
                        if (blocking || io->write_encoding != SOUP_ENCODING_CHUNKED) {
                                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_write 17\n");
                                if (!g_output_stream_close (io->body_ostream, cancellable, error))
                                        return FALSE;
                                g_clear_object (&io->body_ostream);
                                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_write 17\n");
                        } else {
                                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_write 18\n");
                                io->async_wait = g_cancellable_new ();
                                g_output_stream_close_async (io->body_ostream,
                                                             soup_client_message_io_http1_get_priority (client_io),
                                                             cancellable,
                                                             closed_async, g_object_ref (msg));
                                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_write 18\n");
                        }
                        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_write 16\n");
                }

                io->write_state = SOUP_MESSAGE_IO_STATE_BODY_DONE;
                break;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_write 15\n");

        case SOUP_MESSAGE_IO_STATE_BODY_DONE:
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_write 19\n");
                io->write_state = SOUP_MESSAGE_IO_STATE_FINISHING;
                soup_message_wrote_body (msg);
                break;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_write 19\n");

        case SOUP_MESSAGE_IO_STATE_FINISHING:
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_write 20\n");
                io->write_state = SOUP_MESSAGE_IO_STATE_DONE;
                io->read_state = SOUP_MESSAGE_IO_STATE_HEADERS;
                break;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_write 20\n");

        default:
                g_return_val_if_reached (FALSE);
        }

        return TRUE;
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_write 1\n");
}

static gboolean
parse_headers (SoupMessage  *msg,
               char         *headers,
               guint         headers_len,
               SoupEncoding *encoding,
               GError      **error)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter parse_headers 1\n");
        SoupHTTPVersion version;
        char *reason_phrase;
        SoupStatus status;

        soup_message_set_reason_phrase (msg, NULL);

        if (!soup_headers_parse_response (headers, headers_len,
                                          soup_message_get_response_headers (msg),
                                          &version,
                                          &status,
                                          &reason_phrase)) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter parse_headers 2\n");
                g_set_error_literal (error, SOUP_SESSION_ERROR,
                                     SOUP_SESSION_ERROR_PARSING,
                                     _("Could not parse HTTP response"));
                return FALSE;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit parse_headers 2\n");
        }

        soup_message_set_status (msg, status, reason_phrase);
        g_free (reason_phrase);

        if (version < soup_message_get_http_version (msg)) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter parse_headers 3\n");
                soup_message_set_http_version (msg, version);
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit parse_headers 3\n");
        }

        if ((soup_message_get_method (msg) == SOUP_METHOD_HEAD ||
             soup_message_get_status (msg)  == SOUP_STATUS_NO_CONTENT ||
             soup_message_get_status (msg)  == SOUP_STATUS_NOT_MODIFIED ||
             SOUP_STATUS_IS_INFORMATIONAL (soup_message_get_status (msg))) ||
            (soup_message_get_method (msg) == SOUP_METHOD_CONNECT &&
             SOUP_STATUS_IS_SUCCESSFUL (soup_message_get_status (msg)))) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter parse_headers 4\n");
                *encoding = SOUP_ENCODING_NONE;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit parse_headers 4\n");
        } else {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter parse_headers 5\n");
                *encoding = soup_message_headers_get_encoding (soup_message_get_response_headers (msg));
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit parse_headers 5\n");
        }

        if (*encoding == SOUP_ENCODING_UNRECOGNIZED) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter parse_headers 6\n");
                g_set_error_literal (error, SOUP_SESSION_ERROR,
                                     SOUP_SESSION_ERROR_ENCODING,
                                     _("Unrecognized HTTP response encoding"));
                return FALSE;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit parse_headers 6\n");
        }

        return TRUE;
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit parse_headers 1\n");
}

static void
response_network_stream_read_data_cb (SoupMessage *msg,
                                      guint        count)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter response_network_stream_read_data_cb 1\n");
        SoupClientMessageIOHTTP1 *client_io = (SoupClientMessageIOHTTP1 *)soup_message_get_io_data (msg);

        if (client_io->msg_io->base.read_state < SOUP_MESSAGE_IO_STATE_BODY_START) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter response_network_stream_read_data_cb 2\n");
                client_io->msg_io->response_header_bytes_received += count;
                if (client_io->msg_io->metrics)
                        client_io->msg_io->metrics->response_header_bytes_received += count;
                return;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit response_network_stream_read_data_cb 2\n");
        }

        if (client_io->msg_io->metrics) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter response_network_stream_read_data_cb 3\n");
                client_io->msg_io->metrics->response_body_bytes_received += count;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit response_network_stream_read_data_cb 3\n");
        }

        soup_message_got_body_data (msg, count);
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit response_network_stream_read_data_cb 1\n");
}
/* Attempts to push forward the reading side of @msg's I/O. Returns
 * %TRUE if it manages to make some progress, and it is likely that
 * further progress can be made. Returns %FALSE if it has reached a
 * stopping point of some sort (need input from the application,
 * socket not readable, read is complete, etc).
 */
static gboolean
io_read (SoupClientMessageIOHTTP1 *client_io,
         gboolean                  blocking,
         GCancellable             *cancellable,
         GError                  **error)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_read 1\n");
        SoupMessageIOData *io = &client_io->msg_io->base;
        SoupMessage *msg = client_io->msg_io->item->msg;
        gboolean succeeded;
        gboolean is_first_read;
        gushort extra_bytes;
        gsize response_body_bytes_received = 0;
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_read 1\n");

        switch (io->read_state) {
        case SOUP_MESSAGE_IO_STATE_HEADERS:
                fprintf(stderr, "\n");
                is_first_read = io->read_header_buf->len == 0 &&
                        soup_message_get_status (msg) == SOUP_STATUS_NONE;

                succeeded = soup_message_io_data_read_headers (io, SOUP_FILTER_INPUT_STREAM (client_io->istream),
                                                               blocking, cancellable, &extra_bytes, error);
                if (is_first_read && io->read_header_buf->len > 0)
                        soup_message_set_metrics_timestamp (msg, SOUP_MESSAGE_METRICS_RESPONSE_START);
                if (!succeeded)
                        return FALSE;

                /* Adjust the header and body bytes received, since we might
                 * have read part of the body already that is queued by the stream.
                 */
                if (client_io->msg_io->response_header_bytes_received > io->read_header_buf->len + extra_bytes) {
                        response_body_bytes_received = client_io->msg_io->response_header_bytes_received - io->read_header_buf->len - extra_bytes;
                        if (client_io->msg_io->metrics) {
                                client_io->msg_io->metrics->response_body_bytes_received = response_body_bytes_received;
                                client_io->msg_io->metrics->response_header_bytes_received -= response_body_bytes_received;
                        }
                }
                client_io->msg_io->response_header_bytes_received = 0;

                succeeded = parse_headers (msg,
                                           (char *)io->read_header_buf->data,
                                           io->read_header_buf->len,
                                           &io->read_encoding,
                                           error);
                g_byte_array_set_size (io->read_header_buf, 0);

                if (!succeeded) {
                        /* Either we couldn't parse the headers, or they
                         * indicated something that would mean we wouldn't
                         * be able to parse the body. (Eg, unknown
                         * Transfer-Encoding.). Skip the rest of the
                         * reading, and make sure the connection gets
                         * closed when we're done.
                         */
                        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_read 3\n");
                        soup_message_headers_append_common (soup_message_get_request_headers (msg),
                                                            SOUP_HEADER_CONNECTION, "close");
                        soup_message_set_metrics_timestamp (msg, SOUP_MESSAGE_METRICS_RESPONSE_END);
                        io->read_state = SOUP_MESSAGE_IO_STATE_FINISHING;
                        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_read 3\n");
                        break;
                }

                if (SOUP_STATUS_IS_INFORMATIONAL (soup_message_get_status (msg))) {
                        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_read 4\n");
                        if (soup_message_get_status (msg) == SOUP_STATUS_CONTINUE &&
                            io->write_state == SOUP_MESSAGE_IO_STATE_BLOCKING) {
                                /* Pause the reader, unpause the writer */
                                io->read_state =
                                        SOUP_MESSAGE_IO_STATE_BLOCKING;
                                io->write_state =
                                        SOUP_MESSAGE_IO_STATE_BODY_START;
                        } else {
                                /* Just stay in HEADERS */
                                io->read_state = SOUP_MESSAGE_IO_STATE_HEADERS;
                        }

                        /* Informational responses have no bodies, so
                         * bail out here rather than parsing encoding, etc
                         */
                        soup_message_got_informational (msg);

                        /* If this was "101 Switching Protocols", then
                         * the session may have stolen the connection...
                         */
                        if (client_io != (SoupClientMessageIOHTTP1 *)soup_message_get_io_data (msg))
                                return FALSE;

                        soup_message_cleanup_response (msg);
                        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_read 4\n");
                        break;
                } else {
                        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_read 5\n");
                        io->read_state = SOUP_MESSAGE_IO_STATE_BODY_START;

                        /* If the client was waiting for a Continue
                         * but got something else, then it's done
                         * writing.
                         */
                        if (io->write_state == SOUP_MESSAGE_IO_STATE_BLOCKING)
                                io->write_state = SOUP_MESSAGE_IO_STATE_FINISHING;
                        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_read 5\n");
                }

                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_read 6\n");
                if (io->read_encoding == SOUP_ENCODING_CONTENT_LENGTH) {
                        io->read_length = soup_message_headers_get_content_length (soup_message_get_response_headers (msg));

                        if (!soup_message_is_keepalive (msg)) {
                                /* Some servers suck and send
                                 * incorrect Content-Length values, so
                                 * allow EOF termination in this case
                                 * (iff the message is too short) too.
                                 */
                                io->read_encoding = SOUP_ENCODING_EOF;
                        }
                } else
                        io->read_length = -1;

                soup_message_got_headers (msg);

                if (response_body_bytes_received > 0)
                        soup_message_got_body_data (msg, response_body_bytes_received);
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_read 6\n");
                break;

        case SOUP_MESSAGE_IO_STATE_BODY_START:
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_read 7\n");
                if (!io->body_istream) {
                        GInputStream *body_istream = soup_body_input_stream_new (client_io->istream,
                                                                                 io->read_encoding,
                                                                                 io->read_length);

                        io->body_istream = soup_session_setup_message_body_input_stream (client_io->msg_io->item->session,
                                                                                         msg, body_istream,
                                                                                         SOUP_STAGE_MESSAGE_BODY);
                        g_object_unref (body_istream);
                }

                if (!soup_message_try_sniff_content (msg, io->body_istream, blocking, cancellable, error))
                        return FALSE;

                io->read_state = SOUP_MESSAGE_IO_STATE_BODY;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_read 7\n");
                break;

        case SOUP_MESSAGE_IO_STATE_BODY: {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_read 8\n");
                guchar buf[RESPONSE_BLOCK_SIZE];
                gssize nread;

                nread = g_pollable_stream_read (io->body_istream,
                                                buf,
                                                RESPONSE_BLOCK_SIZE,
                                                blocking,
                                                cancellable, error);
                if (nread == -1)
                        return FALSE;

                if (nread == 0)
                        io->read_state = SOUP_MESSAGE_IO_STATE_BODY_DONE;

                if (client_io->msg_io->metrics)
                        client_io->msg_io->metrics->response_body_size += nread;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_read 8\n");
                break;
        }

        case SOUP_MESSAGE_IO_STATE_BODY_DONE:
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_read 9\n");
                io->read_state = SOUP_MESSAGE_IO_STATE_FINISHING;
                soup_message_set_metrics_timestamp (msg, SOUP_MESSAGE_METRICS_RESPONSE_END);
                client_io->is_reusable = soup_message_is_keepalive (msg);
                client_io->ever_used = TRUE;
                soup_message_got_body (msg);
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_read 9\n");
                break;

        case SOUP_MESSAGE_IO_STATE_FINISHING:
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_read 10\n");
                io->read_state = SOUP_MESSAGE_IO_STATE_DONE;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_read 10\n");
                break;

        default:
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_read 11\n");
                g_return_val_if_reached (FALSE);
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_read 11\n");
        }

        return TRUE;
}

static gboolean
request_is_restartable (SoupMessage *msg, GError *error)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter request_is_restartable 1\n");
        SoupClientMessageIOHTTP1 *client_io = (SoupClientMessageIOHTTP1 *)soup_message_get_io_data (msg);
        SoupMessageIOData *io;

        if (!client_io || !client_io->msg_io)
                return FALSE;

        io = &client_io->msg_io->base;

        return (io->read_state <= SOUP_MESSAGE_IO_STATE_HEADERS &&
                io->read_header_buf->len == 0 &&
                client_io->ever_used &&
                !g_error_matches (error, G_IO_ERROR, G_IO_ERROR_TIMED_OUT) &&
                !g_error_matches (error, G_IO_ERROR, G_IO_ERROR_WOULD_BLOCK) &&
                !g_error_matches (error, G_IO_ERROR, G_IO_ERROR_CANCELLED) &&
                error->domain != G_TLS_ERROR &&
                SOUP_METHOD_IS_IDEMPOTENT (soup_message_get_method (msg)));
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit request_is_restartable 1\n");
}

static gboolean
io_run_until (SoupClientMessageIOHTTP1 *client_io,
              gboolean                  blocking,
              SoupMessageIOState        read_state,
              SoupMessageIOState        write_state,
              GCancellable             *cancellable,
              GError                  **error)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_run_until 1\n");
        SoupMessageIOData *io;
        SoupMessage *msg;
        gboolean progress = TRUE, done;
        GError *my_error = NULL;

        g_assert (client_io); // Silence clang static analysis
        io = &client_io->msg_io->base;

        if (g_cancellable_set_error_if_cancelled (cancellable, error))
                return FALSE;
        else if (!io) {
                g_set_error_literal (error, G_IO_ERROR,
                                     G_IO_ERROR_CANCELLED,
                                     _("Operation was cancelled"));
                return FALSE;
        }

        msg = client_io->msg_io->item->msg;
        g_object_ref (msg);

        while (progress && (SoupClientMessageIOHTTP1 *)soup_message_get_io_data (msg) == client_io &&
               !io->paused && !io->async_wait &&
               (io->read_state < read_state || io->write_state < write_state)) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_run_until 2\n");
                if (SOUP_MESSAGE_IO_STATE_ACTIVE (io->read_state))
                        progress = io_read (client_io, blocking, cancellable, &my_error);
                else if (SOUP_MESSAGE_IO_STATE_ACTIVE (io->write_state))
                        progress = io_write (client_io, blocking, cancellable, &my_error);
                else
                        progress = FALSE;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_run_until 2\n");
        }

        if (my_error) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_run_until 3\n");
                g_propagate_error (error, my_error);
                g_object_unref (msg);
                return FALSE;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_run_until 3\n");
        } else if ((SoupClientMessageIOHTTP1 *)soup_message_get_io_data (msg) != client_io) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_run_until 4\n");
                g_set_error_literal (error, G_IO_ERROR,
                                     G_IO_ERROR_CANCELLED,
                                     _("Operation was cancelled"));
                g_object_unref (msg);
                return FALSE;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_run_until 4\n");
        } else if (!io->async_wait &&
                   g_cancellable_set_error_if_cancelled (cancellable, error)) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_run_until 5\n");
                g_object_unref (msg);
                return FALSE;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_run_until 5\n");
        }

        done = (io->read_state >= read_state &&
                io->write_state >= write_state);

        if (!blocking && !done) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_run_until 6\n");
                g_set_error_literal (error, G_IO_ERROR,
                                     G_IO_ERROR_WOULD_BLOCK,
                                     _("Operation would block"));
                g_object_unref (msg);
                return FALSE;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_run_until 6\n");
        }

#ifdef HAVE_SYSPROF
        /* Allow profiling of network requests. */
        if (io->read_state == SOUP_MESSAGE_IO_STATE_DONE &&
            io->write_state == SOUP_MESSAGE_IO_STATE_DONE) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_run_until 7\n");
                GUri *uri = soup_message_get_uri (msg);
                char *uri_str = g_uri_to_string_partial (uri, G_URI_HIDE_PASSWORD);
                const gchar *last_modified = soup_message_headers_get_one_common (soup_message_get_response_headers (msg), SOUP_HEADER_LAST_MODIFIED);
                const gchar *etag = soup_message_headers_get_one_common (soup_message_get_response_headers (msg), SOUP_HEADER_ETAG);
                const gchar *if_modified_since = soup_message_headers_get_one_common (soup_message_get_request_headers (msg), SOUP_HEADER_IF_MODIFIED_SINCE);
                const gchar *if_none_match = soup_message_headers_get_one_common (soup_message_get_request_headers (msg), SOUP_HEADER_IF_NONE_MATCH);

                /* FIXME: Expand and generalise sysprof support:
                 * https://gitlab.gnome.org/GNOME/sysprof/-/issues/43 */
                sysprof_collector_mark_printf (client_io->msg_io->begin_time_nsec,
                                               SYSPROF_CAPTURE_CURRENT_TIME - client_io->msg_io->begin_time_nsec,
                                               "libsoup", "message",
                                               "%s request/response to %s: "
                                               "read %" G_GOFFSET_FORMAT "B, "
                                               "wrote %" G_GOFFSET_FORMAT "B, "
                                               "If-Modified-Since: %s, "
                                               "If-None-Match: %s, "
                                               "Last-Modified: %s, "
                                               "ETag: %s",
                                               soup_message_get_tls_peer_certificate (msg) ? "HTTPS" : "HTTP",
                                               uri_str, io->read_length, io->write_length,
                                               (if_modified_since != NULL) ? if_modified_since : "(unset)",
                                               (if_none_match != NULL) ? if_none_match : "(unset)",
                                               (last_modified != NULL) ? last_modified : "(unset)",
                                               (etag != NULL) ? etag : "(unset)");
                g_free (uri_str);
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_run_until 7\n");
        }
#endif  /* HAVE_SYSPROF */

        g_object_unref (msg);
        return done;
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_run_until 1\n");
}

static void
soup_message_io_finish (SoupMessage  *msg,
                        GError       *error)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_message_io_finish 1\n");
        if (request_is_restartable (msg, error)) {
                SoupClientMessageIOHTTP1 *io = (SoupClientMessageIOHTTP1 *)soup_message_get_io_data (msg);

                /* Connection got closed, but we can safely try again. */
                io->msg_io->item->state = SOUP_MESSAGE_RESTARTING;
        } else if (error) {
                soup_message_set_metrics_timestamp (msg, SOUP_MESSAGE_METRICS_RESPONSE_END);
        }

        soup_message_io_finished (msg);
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_message_io_finish 1\n");
}

static void soup_client_message_io_http1_run (SoupClientMessageIO *iface, SoupMessage *msg, gboolean blocking);

static gboolean
io_run_ready (SoupMessage *msg, gpointer user_data)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_run_ready 1\n");
        soup_client_message_io_http1_run (soup_message_get_io_data (msg), msg, FALSE);
        return FALSE;
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_run_ready 1\n");
}

static void
soup_client_message_io_http1_run (SoupClientMessageIO *iface,
                                  SoupMessage         *msg,
                                  gboolean             blocking)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_run 1\n");
        SoupClientMessageIOHTTP1 *client_io = (SoupClientMessageIOHTTP1 *)iface;
        SoupMessageIOData *io = &client_io->msg_io->base;
        GError *error = NULL;

        if (io->io_source) {
                g_source_destroy (io->io_source);
                g_source_unref (io->io_source);
                io->io_source = NULL;
        }

        g_object_ref (msg);

        if (io_run_until (client_io, blocking,
                          SOUP_MESSAGE_IO_STATE_DONE,
                          SOUP_MESSAGE_IO_STATE_DONE,
                          client_io->msg_io->item->cancellable, &error)) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_run 2\n");
                soup_message_io_finished (msg);
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_run 2\n");
        } else if (g_error_matches (error, G_IO_ERROR, G_IO_ERROR_WOULD_BLOCK)) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_run 3\n");
                g_clear_error (&error);
                io->io_source = soup_message_io_data_get_source (io, G_OBJECT (msg),
                                                                 client_io->istream,
                                                                 client_io->ostream,
                                                                 client_io->msg_io->item->cancellable,
                                                                 (SoupMessageIOSourceFunc)io_run_ready,
                                                                 NULL);
                g_source_set_priority (io->io_source,
                                       soup_client_message_io_http1_get_priority (client_io));
                g_source_attach (io->io_source, g_main_context_get_thread_default ());
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_run 3\n");
        } else {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_run 4\n");
                if ((SoupClientMessageIOHTTP1 *)soup_message_get_io_data (msg) == client_io) {
                        g_assert (!client_io->msg_io->item->error);
                        client_io->msg_io->item->error = g_steal_pointer (&error);
                        soup_message_io_finish (msg, client_io->msg_io->item->error);
                }
                g_clear_error (&error);
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_run 4\n");
        }

        g_object_unref (msg);
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_run 1\n");
}

static gboolean
soup_client_message_io_http1_run_until_read (SoupClientMessageIO *iface,
                                             SoupMessage         *msg,
                                             GCancellable        *cancellable,
                                             GError             **error)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_run_until_read 1\n");
        SoupClientMessageIOHTTP1 *io = (SoupClientMessageIOHTTP1 *)iface;

        if (io_run_until (io, TRUE,
                          SOUP_MESSAGE_IO_STATE_BODY,
                          SOUP_MESSAGE_IO_STATE_ANY,
                          cancellable, error))
                return TRUE;

        if ((SoupClientMessageIOHTTP1 *)soup_message_get_io_data (msg) == io)
                soup_message_io_finish (msg, *error);

        return FALSE;
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_run_until_read 1\n");
}

static void io_run_until_read_async (SoupClientMessageIOHTTP1 *io, GTask *task);

static gboolean
io_run_until_read_ready (SoupMessage *msg,
                         gpointer     user_data)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_run_until_read_ready 1\n");
        GTask *task = user_data;

        io_run_until_read_async ((SoupClientMessageIOHTTP1 *)soup_message_get_io_data (msg), task);
        return FALSE;
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_run_until_read_ready 1\n");
}

static void
io_run_until_read_async (SoupClientMessageIOHTTP1 *client_io,
                         GTask                    *task)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_run_until_read_async 1\n");
        SoupMessageIOData *io = &client_io->msg_io->base;
        SoupMessage *msg = client_io->msg_io->item->msg;
        GError *error = NULL;

        if (io->io_source) {
                g_source_destroy (io->io_source);
                g_source_unref (io->io_source);
                io->io_source = NULL;
        }

        if (io_run_until (client_io, FALSE,
                          SOUP_MESSAGE_IO_STATE_BODY,
                          SOUP_MESSAGE_IO_STATE_ANY,
                          g_task_get_cancellable (task),
                          &error)) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_run_until_read_async 2\n");
                g_task_return_boolean (task, TRUE);
                g_object_unref (task);
                return;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_run_until_read_async 2\n");
        }

        if (g_error_matches (error, G_IO_ERROR, G_IO_ERROR_WOULD_BLOCK)) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_run_until_read_async 3\n");
                g_error_free (error);
                io->io_source = soup_message_io_data_get_source (io, G_OBJECT (msg),
                                                                 client_io->istream,
                                                                 client_io->ostream,
                                                                 g_task_get_cancellable (task),
                                                                 (SoupMessageIOSourceFunc)io_run_until_read_ready,
                                                                 task);
                g_source_set_priority (io->io_source, g_task_get_priority (task));
                g_source_attach (io->io_source, g_main_context_get_thread_default ());
                return;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_run_until_read_async 3\n");
        }

        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter io_run_until_read_async 4\n");
        if ((SoupClientMessageIOHTTP1 *)soup_message_get_io_data (msg) == client_io)
                soup_message_io_finish (msg, error);

        g_task_return_error (task, error);
        g_object_unref (task);
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_run_until_read_async 4\n");
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit io_run_until_read_async 1\n");
}

static void
soup_client_message_io_http1_run_until_read_async (SoupClientMessageIO *iface,
                                                   SoupMessage         *msg,
                                                   int                  io_priority,
                                                   GCancellable        *cancellable,
                                                   GAsyncReadyCallback  callback,
                                                   gpointer             user_data)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_run_until_read_async 1\n");
        SoupClientMessageIOHTTP1 *io = (SoupClientMessageIOHTTP1 *)iface;
        GTask *task;

        task = g_task_new (msg, cancellable, callback, user_data);
        g_task_set_source_tag (task, soup_client_message_io_http1_run_until_read_async);
        g_task_set_priority (task, io_priority);
        io_run_until_read_async (io, task);
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_run_until_read_async 1\n");
}

static gboolean
soup_client_message_io_http1_close_async (SoupClientMessageIO *io,
                                          SoupConnection      *conn,
                                          GAsyncReadyCallback  callback)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_close_async 1\n");
        return FALSE;
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_close_async 1\n");
}

static gboolean
soup_client_message_io_http1_skip (SoupClientMessageIO *iface,
                                   SoupMessage         *msg,
                                   gboolean             blocking,
                                   GCancellable        *cancellable,
                                   GError             **error)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_skip 1\n");
        SoupClientMessageIOHTTP1 *io = (SoupClientMessageIOHTTP1 *)iface;
        gboolean success;

        g_object_ref (msg);

        if (io && io->msg_io) {
                if (io->msg_io->base.read_state < SOUP_MESSAGE_IO_STATE_BODY_DONE)
                        io->msg_io->base.read_state = SOUP_MESSAGE_IO_STATE_FINISHING;
        }

        success = io_run_until (io, blocking,
                                SOUP_MESSAGE_IO_STATE_DONE,
                                SOUP_MESSAGE_IO_STATE_DONE,
                                cancellable, error);

        g_object_unref (msg);
        return success;
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_skip 1\n");
}

static void
client_stream_eof (SoupClientInputStream    *stream,
                   SoupClientMessageIOHTTP1 *io)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter client_stream_eof 1\n");
        if (io && io->msg_io && io->msg_io->base.read_state == SOUP_MESSAGE_IO_STATE_BODY)
                io->msg_io->base.read_state = SOUP_MESSAGE_IO_STATE_BODY_DONE;
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit client_stream_eof 1\n");
}

static GInputStream *
soup_client_message_io_http1_get_response_stream (SoupClientMessageIO *iface,
                                                  SoupMessage         *msg,
                                                  GError             **error)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_get_response_stream 1\n");
        SoupClientMessageIOHTTP1 *io = (SoupClientMessageIOHTTP1 *)iface;
        GInputStream *client_stream;

        g_assert (io->msg_io && io->msg_io->item->msg == msg);

        client_stream = soup_client_input_stream_new (io->msg_io->base.body_istream, msg);
        g_signal_connect (client_stream, "eof",
                          G_CALLBACK (client_stream_eof), io);

        return client_stream;
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_get_response_stream 1\n");
}

static void
soup_client_message_io_http1_send_item (SoupClientMessageIO       *iface,
                                        SoupMessageQueueItem      *item,
                                        SoupMessageIOCompletionFn  completion_cb,
                                        gpointer                   user_data)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_send_item 1\n");
        SoupClientMessageIOHTTP1 *io = (SoupClientMessageIOHTTP1 *)iface;
        SoupMessageIOHTTP1 *msg_io;

        msg_io = g_new0 (SoupMessageIOHTTP1, 1);
        msg_io->item = soup_message_queue_item_ref (item);
        msg_io->base.completion_cb = completion_cb;
        msg_io->base.completion_data = user_data;

        msg_io->base.read_header_buf = g_byte_array_new ();
        msg_io->base.write_buf = g_string_new (NULL);

        msg_io->base.read_state = SOUP_MESSAGE_IO_STATE_NOT_STARTED;
        msg_io->base.write_state = SOUP_MESSAGE_IO_STATE_HEADERS;
        msg_io->metrics = soup_message_get_metrics (msg_io->item->msg);
        g_signal_connect_object (io->istream, "read-data",
                                 G_CALLBACK (response_network_stream_read_data_cb),
                                 msg_io->item->msg, G_CONNECT_SWAPPED);

#ifdef HAVE_SYSPROF
        msg_io->begin_time_nsec = SYSPROF_CAPTURE_CURRENT_TIME;
#endif
        if (io->msg_io)
                g_warn_if_reached ();

        io->msg_io = msg_io;
        io->is_reusable = FALSE;
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_send_item 1\n");
}

static void
soup_client_message_io_http1_pause (SoupClientMessageIO *iface,
                                    SoupMessage         *msg)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_pause 1\n");
        SoupClientMessageIOHTTP1 *io = (SoupClientMessageIOHTTP1 *)iface;

        g_assert (io->msg_io && io->msg_io->item->msg == msg);
        g_assert (io->msg_io->base.read_state < SOUP_MESSAGE_IO_STATE_BODY);

        soup_message_io_data_pause (&io->msg_io->base);
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_pause 1\n");
}

static void
soup_client_message_io_http1_unpause (SoupClientMessageIO *iface,
                                      SoupMessage         *msg)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_unpause 1\n");
        SoupClientMessageIOHTTP1 *io = (SoupClientMessageIOHTTP1 *)iface;

        g_assert (io->msg_io && io->msg_io->item->msg == msg);
        g_assert (io->msg_io->base.read_state < SOUP_MESSAGE_IO_STATE_BODY);

        io->msg_io->base.paused = FALSE;
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_unpause 1\n");
}

static gboolean
soup_client_message_io_http1_is_paused (SoupClientMessageIO *iface,
                                        SoupMessage         *msg)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_is_paused 1\n");
        SoupClientMessageIOHTTP1 *io = (SoupClientMessageIOHTTP1 *)iface;

        g_assert (io->msg_io && io->msg_io->item->msg == msg);

        return io->msg_io->base.paused;
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_is_paused 1\n");
}
static gboolean
soup_client_message_io_http1_is_open (SoupClientMessageIO *iface)
{
        fprintf(stderr, "\n");
        SoupClientMessageIOHTTP1 *io = (SoupClientMessageIOHTTP1 *)iface;
        char buffer[1];
        GError *error = NULL;

        /* This is tricky. The goal is to check if the socket is readable. If
         * so, that means either the server has disconnected or it's broken (it
         * should not send any data while the connection is in idle state). But
         * we can't just check the readability of the SoupSocket because there
         * could be non-application layer TLS data that is readable, but which
         * we don't want to consider. So instead, just read and see if the read
         * succeeds. This is OK to do here because if the read does succeed, we
         * just disconnect and ignore the data anyway.
         */
        g_pollable_input_stream_read_nonblocking (G_POLLABLE_INPUT_STREAM (io->istream),
                                                  &buffer, sizeof (buffer),
	                                          NULL, &error);
        if (!g_error_matches (error, G_IO_ERROR, G_IO_ERROR_WOULD_BLOCK)) {
                fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_is_open 2\n");
                g_clear_error (&error);
		return FALSE;
                // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_is_open 2\n");
        }

        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_is_open 3\n");
        g_error_free (error);

        return TRUE;
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_is_open 3\n");
}

static gboolean
soup_client_message_io_http1_in_progress (SoupClientMessageIO *iface,
                                          SoupMessage         *msg)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_in_progress 1\n");
        SoupClientMessageIOHTTP1 *io = (SoupClientMessageIOHTTP1 *)iface;

        return io->msg_io != NULL;
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_in_progress 1\n");
}

static gboolean
soup_client_message_io_http1_is_reusable (SoupClientMessageIO *iface)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_is_reusable 1\n");
        SoupClientMessageIOHTTP1 *io = (SoupClientMessageIOHTTP1 *)iface;

        return io->is_reusable;
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_is_reusable 1\n");
}

static GCancellable *
soup_client_message_io_http1_get_cancellable (SoupClientMessageIO *iface,
                                          SoupMessage         *msg)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_get_cancellable 1\n");
	SoupClientMessageIOHTTP1 *io = (SoupClientMessageIOHTTP1 *)iface;

        return io->msg_io ? io->msg_io->item->cancellable : NULL;
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_get_cancellable 1\n");
}

static const SoupClientMessageIOFuncs io_funcs = {
        soup_client_message_io_http1_destroy,
        soup_client_message_io_http1_finished,
        soup_client_message_io_http1_stolen,
        soup_client_message_io_http1_send_item,
        soup_client_message_io_http1_get_response_stream,
        soup_client_message_io_http1_pause,
        soup_client_message_io_http1_unpause,
        soup_client_message_io_http1_is_paused,
        soup_client_message_io_http1_run,
        soup_client_message_io_http1_run_until_read,
        soup_client_message_io_http1_run_until_read_async,
        soup_client_message_io_http1_close_async,
        soup_client_message_io_http1_skip,
        soup_client_message_io_http1_is_open,
        soup_client_message_io_http1_in_progress,
        soup_client_message_io_http1_is_reusable,
        soup_client_message_io_http1_get_cancellable
};

SoupClientMessageIO *
soup_client_message_io_http1_new (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] enter soup_client_message_io_http1_new 1\n");
        SoupClientMessageIOHTTP1 *io;

        io = g_slice_new0 (SoupClientMessageIOHTTP1);
        io->iostream = g_object_ref (soup_connection_get_iostream (conn));
        io->istream = g_io_stream_get_input_stream (io->iostream);
        io->ostream = g_io_stream_get_output_stream (io->iostream);
        io->is_reusable = TRUE;

        io->iface.funcs = &io_funcs;

        return (SoupClientMessageIO *)io;
        // fprintf(stderr, "[libsoup/http1/soup-client-message-io-http1.c] exit soup_client_message_io_http1_new 1\n");
}
// Total cost: 0.456008
// Total split cost: 0.110771, input tokens: 65837, output tokens: 1690, cache read tokens: 65819, cache write tokens: 17499, split chunks: [(0, 511), (511, 1108), (1108, 1198)]
// Total instrumented cost: 0.345237, input tokens: 4745, output tokens: 18700, cache read tokens: 4733, cache write tokens: 16875

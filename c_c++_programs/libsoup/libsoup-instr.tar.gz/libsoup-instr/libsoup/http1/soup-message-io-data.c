/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * soup-message-io-data.c: HTTP message I/O data
 *
 * Copyright (C) 2000-2003, Ximian, Inc.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <glib/gi18n-lib.h>
#include <stdio.h>

#include "soup-message-io-data.h"
#include "soup-message-private.h"
#include "soup-server-message-private.h"
#include "soup.h"

#define RESPONSE_BLOCK_SIZE 8192
#define HEADER_SIZE_LIMIT (100 * 1024)

void
soup_message_io_data_cleanup (SoupMessageIOData *io)
{
	fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_cleanup 1\n");
	if (io->io_source) {
		fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_cleanup 2\n");
		g_source_destroy (io->io_source);
		g_source_unref (io->io_source);
		io->io_source = NULL;
		// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_cleanup 2\n");
	}

	fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_cleanup 3\n");
	if (io->body_istream)
		g_object_unref (io->body_istream);
	if (io->body_ostream)
		g_object_unref (io->body_ostream);

	g_byte_array_free (io->read_header_buf, TRUE);

	g_string_free (io->write_buf, TRUE);

	if (io->async_wait) {
		fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_cleanup 4\n");
		g_cancellable_cancel (io->async_wait);
		g_clear_object (&io->async_wait);
		// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_cleanup 4\n");
	}
	g_clear_error (&io->async_error);
	// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_cleanup 3\n");
	// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_cleanup 1\n");
}

gboolean
soup_message_io_data_read_headers (SoupMessageIOData     *io,
                                   SoupFilterInputStream *istream,
                                   gboolean               blocking,
                                   GCancellable          *cancellable,
                                   gushort               *extra_bytes,
                                   GError               **error)
{
	fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_read_headers 1\n");
	gssize nread, old_len;
	gboolean got_lf;
	// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_read_headers 1\n");

	while (1) {
		fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_read_headers 2\n");
		old_len = io->read_header_buf->len;
		g_byte_array_set_size (io->read_header_buf, old_len + RESPONSE_BLOCK_SIZE);
		nread = soup_filter_input_stream_read_line (istream,
							    io->read_header_buf->data + old_len,
							    RESPONSE_BLOCK_SIZE,
							    blocking,
							    &got_lf,
							    cancellable, error);
		io->read_header_buf->len = old_len + MAX (nread, 0);
		// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_read_headers 2\n");
		if (nread == 0) {
			fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_read_headers 3\n");
			if (io->read_header_buf->len > 0) {
				fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_read_headers 4\n");
                                if (extra_bytes)
					*extra_bytes = 0;
				break;
				// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_read_headers 4\n");
                        }

			g_set_error_literal (error, G_IO_ERROR,
					     G_IO_ERROR_PARTIAL_INPUT,
					     _("Connection terminated unexpectedly"));
			// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_read_headers 3\n");
		}
		if (nread <= 0) {
			fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_read_headers 5\n");
			return FALSE;
			// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_read_headers 5\n");
		}

		if (got_lf) {
			fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_read_headers 6\n");
			if (nread == 1 && old_len >= 2 &&
			    !strncmp ((char *)io->read_header_buf->data +
				      io->read_header_buf->len - 2,
				      "\n\n", 2)) {
				fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_read_headers 7\n");
				io->read_header_buf->len--;
                                if (extra_bytes)
                                        *extra_bytes = 1;
				break;
				// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_read_headers 7\n");
			} else if (nread == 2 && old_len >= 3 &&
				 !strncmp ((char *)io->read_header_buf->data +
					   io->read_header_buf->len - 3,
					   "\n\r\n", 3)) {
				fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_read_headers 8\n");
				io->read_header_buf->len -= 2;
                                if (extra_bytes)
                                        *extra_bytes = 2;
				break;
				// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_read_headers 8\n");
			}
			// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_read_headers 6\n");
		}

		if (io->read_header_buf->len > HEADER_SIZE_LIMIT) {
			fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_read_headers 9\n");
			g_set_error_literal (error, G_IO_ERROR,
					     G_IO_ERROR_PARTIAL_INPUT,
					     _("Header too big"));
			return FALSE;
			// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_read_headers 9\n");
		}
	}

	fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_read_headers 10\n");
	io->read_header_buf->data[io->read_header_buf->len] = '\0';
	return TRUE;
	// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_read_headers 10\n");
}

static gboolean
message_io_is_paused (GObject *msg)
{
	fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter message_io_is_paused 1\n");
	if (SOUP_IS_MESSAGE (msg)) {
		fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter message_io_is_paused 2\n");
		return soup_message_is_io_paused (SOUP_MESSAGE (msg));
		// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit message_io_is_paused 2\n");
	}

	if (SOUP_IS_SERVER_MESSAGE (msg)) {
		fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter message_io_is_paused 3\n");
		return soup_server_message_is_io_paused (SOUP_SERVER_MESSAGE (msg));
		// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit message_io_is_paused 3\n");
	}

	return FALSE;
	// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit message_io_is_paused 1\n");
}

static gboolean
message_io_source_check (GSource *source)
{
	fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter message_io_source_check 1\n");
	SoupMessageIOSource *message_source = (SoupMessageIOSource *)source;

	if (message_source->paused) {
		fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter message_io_source_check 2\n");
		if (message_io_is_paused (message_source->msg)) {
			fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter message_io_source_check 3\n");
			return FALSE;
			// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit message_io_source_check 3\n");
		}
		return TRUE;
		// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit message_io_source_check 2\n");
	} else {
		fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter message_io_source_check 4\n");
		return FALSE;
		// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit message_io_source_check 4\n");
	}
	// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit message_io_source_check 1\n");
}

GSource *
soup_message_io_data_get_source (SoupMessageIOData      *io,
				 GObject                *msg,
                                 GInputStream           *istream,
                                 GOutputStream          *ostream,
				 GCancellable           *cancellable,
				 SoupMessageIOSourceFunc callback,
				 gpointer                user_data)
{
	fprintf(stderr, "\n");
	GSource *base_source, *source;

	if (!io) {
		fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_get_source 2\n");
		base_source = g_timeout_source_new (0);
		// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_get_source 2\n");
	} else if (io->paused) {
		fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_get_source 3\n");
		base_source = cancellable ? g_cancellable_source_new (cancellable) : NULL;
		// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_get_source 3\n");
	} else if (io->async_wait) {
		fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_get_source 4\n");
		base_source = g_cancellable_source_new (io->async_wait);
		// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_get_source 4\n");
	} else if (SOUP_MESSAGE_IO_STATE_POLLABLE (io->read_state)) {
		fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_get_source 5\n");
		GPollableInputStream *stream;

		if (io->body_istream) {
			fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_get_source 6\n");
			stream = G_POLLABLE_INPUT_STREAM (io->body_istream);
			// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_get_source 6\n");
		} else if (istream) {
			fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_get_source 7\n");
                        stream = G_POLLABLE_INPUT_STREAM (istream);
			// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_get_source 7\n");
		} else {
			fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_get_source 8\n");
                        g_assert_not_reached ();
			// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_get_source 8\n");
		}
		base_source = g_pollable_input_stream_create_source (stream, cancellable);
		// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_get_source 5\n");
	} else if (SOUP_MESSAGE_IO_STATE_POLLABLE (io->write_state)) {
		fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_get_source 9\n");
		GPollableOutputStream *stream;

		if (io->body_ostream) {
			fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_get_source 10\n");
			stream = G_POLLABLE_OUTPUT_STREAM (io->body_ostream);
			// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_get_source 10\n");
		} else if (ostream) {
			fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_get_source 11\n");
                        stream = G_POLLABLE_OUTPUT_STREAM (ostream);
			// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_get_source 11\n");
		} else {
			fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_get_source 12\n");
                        g_assert_not_reached ();
			// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_get_source 12\n");
		}
		base_source = g_pollable_output_stream_create_source (stream, cancellable);
		// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_get_source 9\n");
	} else {
		fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_get_source 13\n");
		base_source = g_timeout_source_new (0);
		// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_get_source 13\n");
	}

	fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_get_source 14\n");
        source = soup_message_io_source_new (base_source, msg, io && io->paused, message_io_source_check);
	g_source_set_static_name (source, "SoupMessageIOData");
	g_source_set_callback (source, (GSourceFunc) callback, user_data, NULL);
	return source;
	// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_get_source 14\n");
}

void
soup_message_io_data_pause (SoupMessageIOData *io)
{
	fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_pause 1\n");
	if (io->io_source) {
		fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_pause 2\n");
		g_source_destroy (io->io_source);
		g_source_unref (io->io_source);
		io->io_source = NULL;
		// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_pause 2\n");
	}

	io->paused = TRUE;
	// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_pause 1\n");
}

void
soup_message_io_data_unpause (SoupMessageIOData *io)
{
	fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] enter soup_message_io_data_unpause 1\n");
        io->paused = FALSE;
	// fprintf(stderr, "[libsoup/http1/soup-message-io-data.c] exit soup_message_io_data_unpause 1\n");
}
// Total cost: 0.066741
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 201)]
// Total instrumented cost: 0.066741, input tokens: 2398, output tokens: 3869, cache read tokens: 2394, cache write tokens: 2127

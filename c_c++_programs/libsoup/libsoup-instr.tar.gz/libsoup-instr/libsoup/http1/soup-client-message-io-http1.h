/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright (C) 2021 Igalia S.L.
 */

#pragma once

#include "soup-client-message-io.h"

SoupClientMessageIO *soup_client_message_io_http1_new (SoupConnection *conn);
// Total cost: 0.001791
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 10)]
// Total instrumented cost: 0.001791, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 191

/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright 2012 Red Hat, Inc.
 */

#pragma once

#include "soup-types.h"
#include "soup-filter-input-stream.h"
#include "soup-message-headers.h"

G_BEGIN_DECLS

#define SOUP_TYPE_BODY_INPUT_STREAM            (soup_body_input_stream_get_type ())
G_DECLARE_FINAL_TYPE (SoupBodyInputStream, soup_body_input_stream, SOUP, BODY_INPUT_STREAM, GFilterInputStream)


GInputStream *soup_body_input_stream_new (GInputStream *base_stream,
					  SoupEncoding  encoding,
					  goffset       content_length);

G_END_DECLS
// Total cost: 0.002223
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 22)]
// Total instrumented cost: 0.002223, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 306

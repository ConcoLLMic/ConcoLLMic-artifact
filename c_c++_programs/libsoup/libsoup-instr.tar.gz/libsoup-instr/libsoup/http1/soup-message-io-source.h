/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * soup-message-io-source.c
 *
 * Copyright (C) 2000-2003, Ximian, Inc.
 * Copyright (C) 2021 Igalia S.L.
 */

#pragma once

#include "soup.h"

typedef struct {
        GSource source;
        GObject *msg;
        gboolean (*check_func) (GSource*);
        gboolean paused;
} SoupMessageIOSource;

typedef gboolean (*SoupMessageIOSourceFunc) (GObject     *msg,
                                             gpointer     user_data);

GSource *soup_message_io_source_new (GSource     *base_source,
                                     GObject     *msg,
                                     gboolean     paused,
                                     gboolean   (*check_func) (GSource*));
// Total cost: 0.002324
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 26)]
// Total instrumented cost: 0.002324, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 333

/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright 2010-2012 Red Hat, Inc.
 */

#pragma once

#include "soup-types.h"
#include "soup-filter-input-stream.h"

G_BEGIN_DECLS

#define SOUP_TYPE_CLIENT_INPUT_STREAM            (soup_client_input_stream_get_type ())
G_DECLARE_FINAL_TYPE (SoupClientInputStream, soup_client_input_stream, SOUP, CLIENT_INPUT_STREAM, SoupFilterInputStream)

GInputStream *soup_client_input_stream_new (GInputStream *base_stream,
					    SoupMessage  *msg);

G_END_DECLS

// Total cost: 0.002133
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 20)]
// Total instrumented cost: 0.002133, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 282

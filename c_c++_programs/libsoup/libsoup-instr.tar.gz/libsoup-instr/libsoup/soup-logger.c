/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * soup-logger.c
 *
 * Copyright (C) 2001-2004 Novell, Inc.
 * Copyright (C) 2008 Red Hat, Inc.
 * Copyright (C) 2013 Igalia, S.L.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <string.h>

#include "soup-logger-private.h"
#include "soup-logger-input-stream.h"
#include "soup-connection.h"
#include "soup-message-private.h"
#include "soup-misc.h"
#include "soup.h"
#include "soup-session-feature-private.h"

/**
 * SoupLogger:
 *
 * Debug logging support
 *
 * #SoupLogger watches a [class@Session] and logs the HTTP traffic that
 * it generates, for debugging purposes. Many applications use an
 * environment variable to determine whether or not to use
 * #SoupLogger, and to determine the amount of debugging output.
 *
 * To use #SoupLogger, first create a logger with [ctor@Logger.new], optionally
 * configure it with [method@Logger.set_request_filter],
 * [method@Logger.set_response_filter], and [method@Logger.set_printer], and
 * then attach it to a session (or multiple sessions) with
 * [method@Session.add_feature].
 *
 * By default, the debugging output is sent to `stdout`, and looks something
 * like:
 *
 * ```
 * > POST /unauth HTTP/1.1
 * > Soup-Debug-Timestamp: 1200171744
 * > Soup-Debug: SoupSession 1 (0x612190), SoupMessage 1 (0x617000), GSocket 1 (0x612220)
 * > Host: localhost
 * > Content-Type: text/plain
 * > Connection: close
 *
 * < HTTP/1.1 201 Created
 * < Soup-Debug-Timestamp: 1200171744
 * < Soup-Debug: SoupMessage 1 (0x617000)
 * < Date: Sun, 12 Jan 2008 21:02:24 GMT
 * < Content-Length: 0
 * ```
 *
 * The `Soup-Debug-Timestamp` line gives the time (as a `time_t`) when the
 * request was sent, or the response fully received.
 *
 * The `Soup-Debug` line gives further debugging information about the
 * [class@Session], [class@Message], and [class@Gio.Socket] involved; the hex
 * numbers are the addresses of the objects in question (which may be useful if
 * you are running in a debugger). The decimal IDs are simply counters that
 * uniquely identify objects across the lifetime of the #SoupLogger. In
 * particular, this can be used to identify when multiple messages are sent
 * across the same connection.
 *
 * Currently, the request half of the message is logged just before
 * the first byte of the request gets written to the network (from the
 * [signal@Message::starting] signal).
 *
 * The response is logged just after the last byte of the response body is read
 * from the network (from the [signal@Message::got-body] or
 * [signal@Message::got-informational] signal), which means that the
 * [signal@Message::got-headers] signal, and anything triggered off it (such as
 * #SoupMessage::authenticate) will be emitted *before* the response headers are
 * actually logged.
 *
 * If the response doesn't happen to trigger the [signal@Message::got-body] nor
 * [signal@Message::got-informational] signals due to, for example, a
 * cancellation before receiving the last byte of the response body, the
 * response will still be logged on the event of the [signal@Message::finished]
 * signal.
 **/

struct _SoupLogger {
	GObject parent;
};

typedef struct {
	GQuark              tag;
        GMutex              mutex;
	GHashTable         *ids;
	GHashTable         *request_bodies;
	GHashTable         *response_bodies;

	SoupSession        *session;
	SoupLoggerLogLevel  level;
	int                 max_body_size;

	SoupLoggerFilter    request_filter;
	gpointer            request_filter_data;
	GDestroyNotify      request_filter_dnotify;

	SoupLoggerFilter    response_filter;
	gpointer            response_filter_data;
	GDestroyNotify      response_filter_dnotify;

	SoupLoggerPrinter   printer;
	gpointer            printer_data;
	GDestroyNotify      printer_dnotify;
} SoupLoggerPrivate;

enum {
	PROP_0,

	PROP_LEVEL,
	PROP_MAX_BODY_SIZE,

	LAST_PROPERTY
};

static GParamSpec *properties[LAST_PROPERTY] = { NULL, };

static void soup_logger_session_feature_init (SoupSessionFeatureInterface *feature_interface, gpointer interface_data);

static SoupContentProcessorInterface *soup_logger_default_content_processor_interface;
static void soup_logger_content_processor_init (SoupContentProcessorInterface *interface, gpointer interface_data);

G_DEFINE_FINAL_TYPE_WITH_CODE (SoupLogger, soup_logger, G_TYPE_OBJECT,
                               G_ADD_PRIVATE (SoupLogger)
                               G_IMPLEMENT_INTERFACE (SOUP_TYPE_SESSION_FEATURE,
                                                      soup_logger_session_feature_init)
                               G_IMPLEMENT_INTERFACE (SOUP_TYPE_CONTENT_PROCESSOR,
                                                      soup_logger_content_processor_init))

static void
write_body (SoupLogger *logger, const char *buffer, gsize nread,
            gpointer key, GHashTable *bodies)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter write_body 1\n");
        SoupLoggerPrivate *priv = soup_logger_get_instance_private (logger);
        GString *body;

        if (!nread) {
                return;
        }
        // fprintf(stderr, "[libsoup/soup-logger.c] exit write_body 1\n");

        fprintf(stderr, "[libsoup/soup-logger.c] enter write_body 2\n");
        g_mutex_lock (&priv->mutex);
        body = g_hash_table_lookup (bodies, key);

        if (!body) {
            fprintf(stderr, "[libsoup/soup-logger.c] enter write_body 3\n");
            body = g_string_new (NULL);
            g_hash_table_insert (bodies, key, body);
            // fprintf(stderr, "[libsoup/soup-logger.c] exit write_body 3\n");
        }
        g_mutex_unlock (&priv->mutex);
        // fprintf(stderr, "[libsoup/soup-logger.c] exit write_body 2\n");

        if (priv->max_body_size >= 0) {
                fprintf(stderr, "[libsoup/soup-logger.c] enter write_body 4\n");
                /* longer than max => we've written the extra [...] */
                if (body->len > priv->max_body_size) {
                        return;
                }
                // fprintf(stderr, "[libsoup/soup-logger.c] exit write_body 4\n");
                
                fprintf(stderr, "[libsoup/soup-logger.c] enter write_body 5\n");
                int cap = priv->max_body_size - body->len;
                if (cap > 0)
                        g_string_append_len (body, buffer, MIN (nread, cap));
                if (nread > cap)
                        g_string_append (body, "\n[...]");
                // fprintf(stderr, "[libsoup/soup-logger.c] exit write_body 5\n");
        } else {
                fprintf(stderr, "[libsoup/soup-logger.c] enter write_body 6\n");
                g_string_append_len (body, buffer, nread);
                // fprintf(stderr, "[libsoup/soup-logger.c] exit write_body 6\n");
        }
        fprintf(stderr, "\n");
        // fprintf(stderr, "\n");
}

void
soup_logger_log_request_data (SoupLogger *logger, SoupMessage *msg, const char *buffer, gsize len)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_log_request_data 1\n");
        SoupLoggerPrivate *priv = soup_logger_get_instance_private (logger);

        write_body (logger, buffer, len, msg, priv->request_bodies);
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_log_request_data 1\n");
}

static void
write_response_body (SoupLoggerInputStream *stream, char *buffer, gsize nread,
                     gpointer user_data)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter write_response_body 1\n");
        SoupLogger *logger = soup_logger_input_stream_get_logger (stream);
        SoupLoggerPrivate *priv = soup_logger_get_instance_private (logger);

        write_body (logger, buffer, nread, user_data, priv->response_bodies);
        // fprintf(stderr, "[libsoup/soup-logger.c] exit write_response_body 1\n");
}

static GInputStream *
soup_logger_content_processor_wrap_input (SoupContentProcessor *processor,
                            GInputStream *base_stream,
                            SoupMessage *msg,
                            GError **error)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_content_processor_wrap_input 1\n");
        SoupLogger *logger = SOUP_LOGGER (processor);
        SoupLoggerPrivate *priv = soup_logger_get_instance_private (logger);
        SoupLoggerInputStream *stream;
        SoupLoggerLogLevel log_level = SOUP_LOGGER_LOG_NONE;

        if (priv->request_filter || priv->response_filter) {
                fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_content_processor_wrap_input 2\n");
                if (priv->request_filter)
                        log_level = priv->request_filter (logger, msg, priv->request_filter_data);
                if (priv->response_filter)
                        log_level = MAX(log_level, priv->response_filter (logger, msg, priv->response_filter_data));
                // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_content_processor_wrap_input 2\n");
        }
        else {
                fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_content_processor_wrap_input 3\n");
                log_level = priv->level;
                // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_content_processor_wrap_input 3\n");
        }

        if (log_level < SOUP_LOGGER_LOG_BODY) {
                return NULL;
        }
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_content_processor_wrap_input 1\n");

        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_content_processor_wrap_input 4\n");
        stream = g_object_new (SOUP_TYPE_LOGGER_INPUT_STREAM,
                               "base-stream", base_stream,
                               "logger", logger,
                               NULL);

        g_signal_connect_object (stream, "read-data",
                                 G_CALLBACK (write_response_body), msg, 0);

        return G_INPUT_STREAM (stream);
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_content_processor_wrap_input 4\n");
}

static void
soup_logger_content_processor_init (SoupContentProcessorInterface *interface,
                                    gpointer interface_data)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_content_processor_init 1\n");
        soup_logger_default_content_processor_interface =
                g_type_default_interface_peek (SOUP_TYPE_CONTENT_PROCESSOR);

        interface->processing_stage = SOUP_STAGE_BODY_DATA;
        interface->wrap_input = soup_logger_content_processor_wrap_input;
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_content_processor_init 1\n");
}

static void
body_free (gpointer str)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter body_free 1\n");
        g_string_free (str, TRUE);
        // fprintf(stderr, "[libsoup/soup-logger.c] exit body_free 1\n");
}

static void
soup_logger_init (SoupLogger *logger)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_init 1\n");
	SoupLoggerPrivate *priv = soup_logger_get_instance_private (logger);
	char *id;

	id = g_strdup_printf ("SoupLogger-%p", logger);
	priv->tag = g_quark_from_string (id);
	g_free (id);
	priv->ids = g_hash_table_new (NULL, NULL);
	priv->request_bodies = g_hash_table_new_full (NULL, NULL, NULL, body_free);
	priv->response_bodies = g_hash_table_new_full (NULL, NULL, NULL, body_free);
        g_mutex_init (&priv->mutex);
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_init 1\n");
}

static void
soup_logger_finalize (GObject *object)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_finalize 1\n");
	SoupLogger *logger = SOUP_LOGGER (object);
	SoupLoggerPrivate *priv = soup_logger_get_instance_private (logger);

	g_hash_table_destroy (priv->ids);
	g_hash_table_destroy (priv->request_bodies);
	g_hash_table_destroy (priv->response_bodies);

	if (priv->request_filter_dnotify)
		priv->request_filter_dnotify (priv->request_filter_data);
	if (priv->response_filter_dnotify)
		priv->response_filter_dnotify (priv->response_filter_data);
	if (priv->printer_dnotify)
		priv->printer_dnotify (priv->printer_data);

        g_mutex_clear (&priv->mutex);

	G_OBJECT_CLASS (soup_logger_parent_class)->finalize (object);
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_finalize 1\n");
}

static void
soup_logger_set_property (GObject *object, guint prop_id,
			  const GValue *value, GParamSpec *pspec)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_set_property 1\n");
	SoupLogger *logger = SOUP_LOGGER (object);
	SoupLoggerPrivate *priv = soup_logger_get_instance_private (logger);

	switch (prop_id) {
	case PROP_LEVEL:
		priv->level = g_value_get_enum (value);
		break;
	case PROP_MAX_BODY_SIZE:
		priv->max_body_size = g_value_get_int (value);
		break;
	default:
		G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
		break;
	}
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_set_property 1\n");
}

static void
soup_logger_get_property (GObject *object, guint prop_id,
			   GValue *value, GParamSpec *pspec)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_get_property 1\n");
	SoupLogger *logger = SOUP_LOGGER (object);
	SoupLoggerPrivate *priv = soup_logger_get_instance_private (logger);

	switch (prop_id) {
	case PROP_LEVEL:
		g_value_set_enum (value, priv->level);
		break;
	case PROP_MAX_BODY_SIZE:
		g_value_set_int (value, priv->max_body_size);
		break;
	default:
		G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
		break;
	}
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_get_property 1\n");
}

static void
soup_logger_class_init (SoupLoggerClass *logger_class)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_class_init 1\n");
	GObjectClass *object_class = G_OBJECT_CLASS (logger_class);

	object_class->finalize = soup_logger_finalize;
	object_class->set_property = soup_logger_set_property;
	object_class->get_property = soup_logger_get_property;

	/* properties */
	/**
	 * SoupLogger:level:
	 *
	 * The level of logging output.
	 */
        properties[PROP_LEVEL] =
		g_param_spec_enum ("level",
				    "Level",
				    "The level of logging output",
				    SOUP_TYPE_LOGGER_LOG_LEVEL,
				    SOUP_LOGGER_LOG_MINIMAL,
				    G_PARAM_READWRITE |
				    G_PARAM_STATIC_STRINGS);
	/**
	 * SoupLogger:max-body-size: (attributes org.gtk.Property.get=soup_logger_get_max_body_size org.gtk.Property.set=soup_logger_set_max_body_size)
	 *
	 * If [property@Logger:level] is %SOUP_LOGGER_LOG_BODY, this gives
	 * the maximum number of bytes of the body that will be logged.
	 * (-1 means "no limit".)
	 **/
        properties[PROP_MAX_BODY_SIZE] =
		g_param_spec_int ("max-body-size",
				    "Max Body Size",
				    "The maximum body size to output",
				    -1,
				    G_MAXINT,
				    -1,
				    G_PARAM_CONSTRUCT |
				    G_PARAM_READWRITE |
				    G_PARAM_STATIC_STRINGS);

        g_object_class_install_properties (object_class, LAST_PROPERTY, properties);
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_class_init 1\n");
}

/**
 * SoupLoggerLogLevel:
 * @SOUP_LOGGER_LOG_NONE: No logging
 * @SOUP_LOGGER_LOG_MINIMAL: Log the Request-Line or Status-Line and
 *   the Soup-Debug pseudo-headers
 * @SOUP_LOGGER_LOG_HEADERS: Log the full request/response headers
 * @SOUP_LOGGER_LOG_BODY: Log the full headers and request/response bodies
 *
 * Describes the level of logging output to provide.
 **/

/**
 * soup_logger_new:
 * @level: the debug level
 *
 * Creates a new #SoupLogger with the given debug level.
 *
 * If you need finer control over what message parts are and aren't
 * logged, use [method@Logger.set_request_filter] and
 * [method@Logger.set_response_filter].
 *
 * Returns: a new #SoupLogger
 **/
SoupLogger *
soup_logger_new (SoupLoggerLogLevel level)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_new 1\n");
	return g_object_new (SOUP_TYPE_LOGGER, "level", level, NULL);
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_new 1\n");
}

/**
 * SoupLoggerFilter:
 * @logger: the #SoupLogger
 * @msg: the message being logged
 * @user_data: the data passed to [method@Logger.set_request_filter]
 *   or [method@Logger.set_response_filter]
 *
 * The prototype for a logging filter.
 *
 * The filter callback will be invoked for each request or response, and should
 * analyze it and return a [enum@LoggerLogLevel] value indicating how much of
 * the message to log.
 *
 * Returns: a [enum@LoggerLogLevel] value indicating how much of the message to
 *   log
 **/

/**
 * soup_logger_set_request_filter:
 * @logger: a #SoupLogger
 * @request_filter: the callback for request debugging
 * @filter_data: data to pass to the callback
 * @destroy: a #GDestroyNotify to free @filter_data
 *
 * Sets up a filter to determine the log level for a given request.
 *
 * For each HTTP request @logger will invoke @request_filter to
 * determine how much (if any) of that request to log. (If you do not
 * set a request filter, @logger will just always log requests at the
 * level passed to [ctor@Logger.new].)
 **/
void
soup_logger_set_request_filter (SoupLogger       *logger,
				SoupLoggerFilter  request_filter,
				gpointer          filter_data,
				GDestroyNotify    destroy)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_set_request_filter 1\n");
	SoupLoggerPrivate *priv = soup_logger_get_instance_private (logger);

	priv->request_filter         = request_filter;
	priv->request_filter_data    = filter_data;
	priv->request_filter_dnotify = destroy;
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_set_request_filter 1\n");
}

/**
 * soup_logger_set_response_filter:
 * @logger: a #SoupLogger
 * @response_filter: the callback for response debugging
 * @filter_data: data to pass to the callback
 * @destroy: a #GDestroyNotify to free @filter_data
 *
 * Sets up a filter to determine the log level for a given response.
 *
 * For each HTTP response @logger will invoke @response_filter to
 * determine how much (if any) of that response to log. (If you do not
 * set a response filter, @logger will just always log responses at
 * the level passed to [ctor@Logger.new].)
 **/
void
soup_logger_set_response_filter (SoupLogger       *logger,
				 SoupLoggerFilter  response_filter,
				 gpointer          filter_data,
				 GDestroyNotify    destroy)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_set_response_filter 1\n");
	SoupLoggerPrivate *priv = soup_logger_get_instance_private (logger);

	priv->response_filter         = response_filter;
	priv->response_filter_data    = filter_data;
	priv->response_filter_dnotify = destroy;
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_set_response_filter 1\n");
}

/**
 * SoupLoggerPrinter:
 * @logger: the #SoupLogger
 * @level: the level of the information being printed.
 * @direction: a single-character prefix to @data
 * @data: data to print
 * @user_data: the data passed to [method@Logger.set_printer]
 *
 * The prototype for a custom printing callback.
 *
 * @level indicates what kind of information is being printed. Eg, it
 * will be %SOUP_LOGGER_LOG_HEADERS if @data is header data.
 *
 * @direction is either '<', '>', or ' ', and @data is the single line
 * to print; the printer is expected to add a terminating newline.
 *
 * To get the effect of the default printer, you would do:
 *
 * ```c
 * printf ("%c %s\n", direction, data);
 * ```
 **/

/**
 * soup_logger_set_printer:
 * @logger: a #SoupLogger
 * @printer: the callback for printing logging output
 * @printer_data: data to pass to the callback
 * @destroy: a #GDestroyNotify to free @printer_data
 *
 * Sets up an alternate log printing routine, if you don't want
 * the log to go to `stdout`.
 **/
void
soup_logger_set_printer (SoupLogger        *logger,
			 SoupLoggerPrinter  printer,
			 gpointer           printer_data,
			 GDestroyNotify     destroy)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_set_printer 1\n");
	SoupLoggerPrivate *priv = soup_logger_get_instance_private (logger);

	priv->printer         = printer;
	priv->printer_data    = printer_data;
	priv->printer_dnotify = destroy;
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_set_printer 1\n");
}

/**
 * soup_logger_set_max_body_size: (attributes org.gtk.Method.set_property=max-body-size)
 * @logger: a #SoupLogger
 * @max_body_size: the maximum body size to log
 *
 * Sets the maximum body size for @logger (-1 means no limit).
 **/
void
soup_logger_set_max_body_size (SoupLogger *logger, int max_body_size)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_set_max_body_size 1\n");
        SoupLoggerPrivate *priv = soup_logger_get_instance_private (logger);

        priv->max_body_size = max_body_size;
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_set_max_body_size 1\n");
}

/**
 * soup_logger_get_max_body_size: (attributes org.gtk.Method.get_property=max-body-size)
 * @logger: a #SoupLogger
 *
 * Get the maximum body size for @logger.
 *
 * Returns: the maximum body size, or -1 if unlimited
 **/
int
soup_logger_get_max_body_size (SoupLogger *logger)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_get_max_body_size 1\n");
        SoupLoggerPrivate *priv = soup_logger_get_instance_private (logger);

        return priv->max_body_size;
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_get_max_body_size 1\n");
}

static guint
soup_logger_get_id (SoupLogger *logger, gpointer object)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_get_id 1\n");
	SoupLoggerPrivate *priv = soup_logger_get_instance_private (logger);

	return GPOINTER_TO_UINT (g_object_get_qdata (object, priv->tag));
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_get_id 1\n");
}

static guint
soup_logger_set_id (SoupLogger *logger, gpointer object)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_set_id 1\n");
	SoupLoggerPrivate *priv = soup_logger_get_instance_private (logger);
	gpointer klass = G_OBJECT_GET_CLASS (object);
	gpointer id;

        g_mutex_lock (&priv->mutex);
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_set_id 2\n");
	id = g_hash_table_lookup (priv->ids, klass);
	id = (char *)id + 1;
	g_hash_table_insert (priv->ids, klass, id);
        g_mutex_unlock (&priv->mutex);
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_set_id 2\n");

	g_object_set_qdata (object, priv->tag, id);
	return GPOINTER_TO_UINT (id);
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_set_id 1\n");
}

static void soup_logger_print (SoupLogger *logger, SoupLoggerLogLevel level,
			       char direction, const char *format, ...) G_GNUC_PRINTF (4, 5);

static void
soup_logger_print (SoupLogger *logger, SoupLoggerLogLevel level,
		   char direction, const char *format, ...)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_print 1\n");
	SoupLoggerPrivate *priv = soup_logger_get_instance_private (logger);
	va_list args;
	char *data, *line, *end;

	va_start (args, format);
	data = g_strdup_vprintf (format, args);
	va_end (args);

	line = data;
	do {
                fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_print 2\n");
		end = strchr (line, '\n');
		if (end)
			*end = '\0';
		if (priv->printer) {
                        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_print 3\n");
			priv->printer (logger, level, direction,
				       line, priv->printer_data);
                        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_print 3\n");
		} else {
                        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_print 4\n");
			printf ("%c %s\n", direction, line);
                        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_print 4\n");
                }

		line = end + 1;
                // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_print 2\n");
	} while (end && *line);

	g_free (data);
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_print 1\n");
}

static void
soup_logger_print_basic_auth (SoupLogger *logger, const char *value)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_print_basic_auth 1\n");
	char *decoded, *decoded_utf8, *p;
	gsize len;

	decoded = (char *)g_base64_decode (value + 6, &len);
	if (decoded && !g_utf8_validate (decoded, -1, NULL)) {
                fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_print_basic_auth 2\n");
		decoded_utf8 = g_convert_with_fallback (decoded, -1,
							"UTF-8", "ISO-8859-1",
							NULL, NULL, &len,
							NULL);
		if (decoded_utf8) {
                        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_print_basic_auth 3\n");
			g_free (decoded);
			decoded = decoded_utf8;
                        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_print_basic_auth 3\n");
		}
                // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_print_basic_auth 2\n");
	}

	if (!decoded) {
                fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_print_basic_auth 4\n");
		decoded = g_strdup (value);
                // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_print_basic_auth 4\n");
        }
	p = strchr (decoded, ':');
	if (p) {
                fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_print_basic_auth 5\n");
		while (++p < decoded + len)
			*p = '*';
                // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_print_basic_auth 5\n");
	}
	soup_logger_print (logger, SOUP_LOGGER_LOG_HEADERS, '>',
			   "Authorization: Basic [%.*s]", (int)len, decoded);
	g_free (decoded);
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_print_basic_auth 1\n");
}

static void
print_request (SoupLogger *logger, SoupMessage *msg,
	       GSocket *socket, gboolean restarted)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter print_request 1\n");
	SoupLoggerPrivate *priv = soup_logger_get_instance_private (logger);
	SoupLoggerLogLevel log_level;
	SoupMessageHeadersIter iter;
	const char *name, *value;
	char *socket_dbg;
	GString *body;
	GUri *uri;

	if (priv->request_filter) {
                fprintf(stderr, "[libsoup/soup-logger.c] enter print_request 2\n");
		log_level = priv->request_filter (logger, msg,
						  priv->request_filter_data);
                // fprintf(stderr, "[libsoup/soup-logger.c] exit print_request 2\n");
	} else {
                fprintf(stderr, "[libsoup/soup-logger.c] enter print_request 3\n");
		log_level = priv->level;
                // fprintf(stderr, "[libsoup/soup-logger.c] exit print_request 3\n");
        }

	if (log_level == SOUP_LOGGER_LOG_NONE) {
		return;
        }
        // fprintf(stderr, "[libsoup/soup-logger.c] exit print_request 1\n");

        fprintf(stderr, "[libsoup/soup-logger.c] enter print_request 4\n");
	uri = soup_message_get_uri (msg);
	if (soup_message_get_method (msg) == SOUP_METHOD_CONNECT) {
                fprintf(stderr, "[libsoup/soup-logger.c] enter print_request 5\n");
		soup_logger_print (logger, SOUP_LOGGER_LOG_MINIMAL, '>',
				   "CONNECT %s:%u HTTP/%s",
				   g_uri_get_host (uri), g_uri_get_port (uri),
				   soup_http_version_to_string (soup_message_get_http_version (msg)));
                // fprintf(stderr, "[libsoup/soup-logger.c] exit print_request 5\n");
	} else {
                fprintf(stderr, "[libsoup/soup-logger.c] enter print_request 6\n");
		soup_logger_print (logger, SOUP_LOGGER_LOG_MINIMAL, '>',
				   "%s %s%s%s HTTP/%s",
				   soup_message_get_method (msg),
                                   g_uri_get_path (uri),
				   g_uri_get_query (uri) ? "?" : "",
				   g_uri_get_query (uri) ? g_uri_get_query (uri) : "",
				   soup_http_version_to_string (soup_message_get_http_version (msg)));
                // fprintf(stderr, "[libsoup/soup-logger.c] exit print_request 6\n");
	}

	soup_logger_print (logger, SOUP_LOGGER_LOG_MINIMAL, '>',
			   "Soup-Debug-Timestamp: %lu",
			   (unsigned long)time (0));

	socket_dbg = socket ?
		g_strdup_printf ("%s %u (%p)",
				 g_type_name_from_instance ((GTypeInstance *)socket),
				 soup_logger_get_id (logger, socket), socket)
		: NULL;

	soup_logger_print (logger, SOUP_LOGGER_LOG_MINIMAL, '>',
			   "Soup-Debug: %s %u (%p), %s %u (%p), %s%s",
			   g_type_name_from_instance ((GTypeInstance *)priv->session),
			   soup_logger_get_id (logger, priv->session), priv->session,
			   g_type_name_from_instance ((GTypeInstance *)msg),
			   soup_logger_get_id (logger, msg), msg,
			   socket_dbg ? socket_dbg : "cached",
			   restarted ? ", restarted" : "");
	g_free (socket_dbg);

	if (log_level == SOUP_LOGGER_LOG_MINIMAL) {
		return;
        }
        // fprintf(stderr, "[libsoup/soup-logger.c] exit print_request 4\n");

        fprintf(stderr, "[libsoup/soup-logger.c] enter print_request 7\n");
	soup_logger_print (logger, SOUP_LOGGER_LOG_HEADERS, '>', "Soup-Host: %s", g_uri_get_host (uri));

	soup_message_headers_iter_init (&iter, soup_message_get_request_headers (msg));
	while (soup_message_headers_iter_next (&iter, &name, &value)) {
                fprintf(stderr, "[libsoup/soup-logger.c] enter print_request 8\n");
		if (!g_ascii_strcasecmp (name, "Authorization") &&
		    !g_ascii_strncasecmp (value, "Basic ", 6)) {
                        fprintf(stderr, "[libsoup/soup-logger.c] enter print_request 9\n");
			soup_logger_print_basic_auth (logger, value);
                        // fprintf(stderr, "[libsoup/soup-logger.c] exit print_request 9\n");
                } else {
                        fprintf(stderr, "[libsoup/soup-logger.c] enter print_request 10\n");
			soup_logger_print (logger, SOUP_LOGGER_LOG_HEADERS, '>',
					   "%s: %s", name, value);
                        // fprintf(stderr, "[libsoup/soup-logger.c] exit print_request 10\n");
		}
                // fprintf(stderr, "[libsoup/soup-logger.c] exit print_request 8\n");
	}

	if (log_level == SOUP_LOGGER_LOG_HEADERS) {
		return;
        }
        // fprintf(stderr, "[libsoup/soup-logger.c] exit print_request 7\n");

        fprintf(stderr, "[libsoup/soup-logger.c] enter print_request 11\n");
	/* will be logged in get_informational */
	if (soup_message_headers_get_expectations (soup_message_get_request_headers (msg)) == SOUP_EXPECTATION_CONTINUE) {
		return;
        }
        // fprintf(stderr, "[libsoup/soup-logger.c] exit print_request 11\n");

        fprintf(stderr, "[libsoup/soup-logger.c] enter print_request 12\n");
	if (!g_hash_table_steal_extended (priv->request_bodies, msg, NULL, (gpointer *)&body)) {
		return;
        }
        // fprintf(stderr, "[libsoup/soup-logger.c] exit print_request 12\n");

        fprintf(stderr, "[libsoup/soup-logger.c] enter print_request 13\n");
	soup_logger_print (logger, SOUP_LOGGER_LOG_BODY, '>', "\n%s", body->str);
	g_string_free (body, TRUE);
        // fprintf(stderr, "[libsoup/soup-logger.c] exit print_request 13\n");
}

static void
print_response (SoupLogger *logger, SoupMessage *msg)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter print_response 1\n");
	SoupLoggerPrivate *priv = soup_logger_get_instance_private (logger);
	SoupLoggerLogLevel log_level;
	SoupMessageHeadersIter iter;
	const char *name, *value;
	GString *body;

	if (priv->response_filter) {
                fprintf(stderr, "[libsoup/soup-logger.c] enter print_response 2\n");
		log_level = priv->response_filter (logger, msg,
						   priv->response_filter_data);
                // fprintf(stderr, "[libsoup/soup-logger.c] exit print_response 2\n");
	} else {
                fprintf(stderr, "[libsoup/soup-logger.c] enter print_response 3\n");
		log_level = priv->level;
                // fprintf(stderr, "[libsoup/soup-logger.c] exit print_response 3\n");
        }

	if (log_level == SOUP_LOGGER_LOG_NONE) {
		return;
        }
        // fprintf(stderr, "[libsoup/soup-logger.c] exit print_response 1\n");

        fprintf(stderr, "[libsoup/soup-logger.c] enter print_response 4\n");
	soup_logger_print (logger, SOUP_LOGGER_LOG_MINIMAL, '<',
			   "HTTP/%s %u %s\n",
			   soup_http_version_to_string (soup_message_get_http_version (msg)),
			   soup_message_get_status (msg), soup_message_get_reason_phrase (msg));

	soup_logger_print (logger, SOUP_LOGGER_LOG_MINIMAL, '<',
			   "Soup-Debug-Timestamp: %lu",
			   (unsigned long)time (0));
	soup_logger_print (logger, SOUP_LOGGER_LOG_MINIMAL, '<',
			   "Soup-Debug: %s %u (%p)",
			   g_type_name_from_instance ((GTypeInstance *)msg),
			   soup_logger_get_id (logger, msg), msg);

	if (log_level == SOUP_LOGGER_LOG_MINIMAL) {
		return;
        }
        // fprintf(stderr, "[libsoup/soup-logger.c] exit print_response 4\n");

        fprintf(stderr, "[libsoup/soup-logger.c] enter print_response 5\n");
	soup_message_headers_iter_init (&iter, soup_message_get_response_headers (msg));
	while (soup_message_headers_iter_next (&iter, &name, &value)) {
                fprintf(stderr, "[libsoup/soup-logger.c] enter print_response 6\n");
		soup_logger_print (logger, SOUP_LOGGER_LOG_HEADERS, '<',
				   "%s: %s", name, value);
                // fprintf(stderr, "[libsoup/soup-logger.c] exit print_response 6\n");
	}

	if (log_level == SOUP_LOGGER_LOG_HEADERS) {
		return;
        }
        // fprintf(stderr, "[libsoup/soup-logger.c] exit print_response 5\n");

        fprintf(stderr, "[libsoup/soup-logger.c] enter print_response 7\n");
	if (!g_hash_table_steal_extended (priv->response_bodies, msg, NULL, (gpointer *)&body)) {
		return;
        }
        // fprintf(stderr, "[libsoup/soup-logger.c] exit print_response 7\n");

        fprintf(stderr, "[libsoup/soup-logger.c] enter print_response 8\n");
	soup_logger_print (logger, SOUP_LOGGER_LOG_BODY, '<', "\n%s", body->str);
	g_string_free (body, TRUE);
        // fprintf(stderr, "[libsoup/soup-logger.c] exit print_response 8\n");
}

static void
finished (SoupMessage *msg, gpointer user_data)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter finished 1\n");
	SoupLogger *logger = user_data;
        SoupLoggerPrivate *priv = soup_logger_get_instance_private (logger);

        /* Do not print the response if we didn't print a request. This can happen if
         * msg is a preconnect request, for example.
         */
        if (!soup_logger_get_id (logger, msg)) {
                return;
        }
        // fprintf(stderr, "[libsoup/soup-logger.c] exit finished 1\n");

        fprintf(stderr, "[libsoup/soup-logger.c] enter finished 2\n");
        g_mutex_lock (&priv->mutex);
	print_response (logger, msg);
	soup_logger_print (logger, SOUP_LOGGER_LOG_MINIMAL, ' ', "\n");
        g_mutex_unlock (&priv->mutex);
        // fprintf(stderr, "[libsoup/soup-logger.c] exit finished 2\n");
}
static void
got_informational (SoupMessage *msg, gpointer user_data)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter got_informational 1\n");
        SoupLogger *logger = user_data;
        SoupLoggerPrivate *priv = soup_logger_get_instance_private (logger);
        SoupLoggerLogLevel log_level;
        GString *body = NULL;
        // fprintf(stderr, "[libsoup/soup-logger.c] exit got_informational 1\n");

        g_mutex_lock (&priv->mutex);

        if (priv->response_filter) {
                fprintf(stderr, "[libsoup/soup-logger.c] enter got_informational 2\n");
                log_level = priv->response_filter (logger, msg,
                                                   priv->response_filter_data);
                // fprintf(stderr, "[libsoup/soup-logger.c] exit got_informational 2\n");
        }
        else {
                fprintf(stderr, "[libsoup/soup-logger.c] enter got_informational 3\n");
                log_level = priv->level;
                // fprintf(stderr, "[libsoup/soup-logger.c] exit got_informational 3\n");
        }

        fprintf(stderr, "[libsoup/soup-logger.c] enter got_informational 4\n");
        g_signal_handlers_disconnect_by_func (msg, finished, logger);
        print_response (logger, msg);
        soup_logger_print (logger, SOUP_LOGGER_LOG_MINIMAL, ' ', "\n");
        // fprintf(stderr, "[libsoup/soup-logger.c] exit got_informational 4\n");

        if (!g_hash_table_steal_extended (priv->response_bodies, msg, NULL, (gpointer *)&body)) {
                fprintf(stderr, "[libsoup/soup-logger.c] enter got_informational 5\n");
                g_mutex_unlock (&priv->mutex);
                return;
                // fprintf(stderr, "[libsoup/soup-logger.c] exit got_informational 5\n");
        }

        fprintf(stderr, "[libsoup/soup-logger.c] enter got_informational 6\n");
        if (soup_message_get_status (msg) == SOUP_STATUS_CONTINUE) {
                fprintf(stderr, "[libsoup/soup-logger.c] enter got_informational 7\n");
                soup_logger_print (logger, SOUP_LOGGER_LOG_MINIMAL, '>',
                                   "[Now sending request body...]");

                if (log_level == SOUP_LOGGER_LOG_BODY) {
                        fprintf(stderr, "[libsoup/soup-logger.c] enter got_informational 8\n");
                        soup_logger_print (logger, SOUP_LOGGER_LOG_BODY,
                                           '>', "%s", body->str);
                        // fprintf(stderr, "[libsoup/soup-logger.c] exit got_informational 8\n");
                }

                soup_logger_print (logger, SOUP_LOGGER_LOG_MINIMAL, ' ', "\n");
                // fprintf(stderr, "[libsoup/soup-logger.c] exit got_informational 7\n");
        }

        g_string_free (body, TRUE);

        g_mutex_unlock (&priv->mutex);
        // fprintf(stderr, "[libsoup/soup-logger.c] exit got_informational 6\n");
}

static void
got_body (SoupMessage *msg, gpointer user_data)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter got_body 1\n");
	SoupLogger *logger = user_data;
        SoupLoggerPrivate *priv = soup_logger_get_instance_private (logger);
        // fprintf(stderr, "[libsoup/soup-logger.c] exit got_body 1\n");

        g_mutex_lock (&priv->mutex);

        fprintf(stderr, "[libsoup/soup-logger.c] enter got_body 2\n");
	g_signal_handlers_disconnect_by_func (msg, finished, logger);

	print_response (logger, msg);
	soup_logger_print (logger, SOUP_LOGGER_LOG_MINIMAL, ' ', "\n");

        g_mutex_unlock (&priv->mutex);
        // fprintf(stderr, "[libsoup/soup-logger.c] exit got_body 2\n");
}

static void
wrote_body (SoupMessage *msg, gpointer user_data)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter wrote_body 1\n");
	SoupLogger *logger = SOUP_LOGGER (user_data);
	SoupLoggerPrivate *priv = soup_logger_get_instance_private (logger);
	gboolean restarted;
	guint msg_id;
	SoupConnection *conn;
	GSocket *socket = NULL;
        // fprintf(stderr, "[libsoup/soup-logger.c] exit wrote_body 1\n");

        fprintf(stderr, "[libsoup/soup-logger.c] enter wrote_body 2\n");
	msg_id = soup_logger_get_id (logger, msg);
	if (msg_id) {
                fprintf(stderr, "[libsoup/soup-logger.c] enter wrote_body 3\n");
		restarted = TRUE;
                // fprintf(stderr, "[libsoup/soup-logger.c] exit wrote_body 3\n");
        }
	else {
                fprintf(stderr, "[libsoup/soup-logger.c] enter wrote_body 4\n");
		soup_logger_set_id (logger, msg);
		restarted = FALSE;
                // fprintf(stderr, "[libsoup/soup-logger.c] exit wrote_body 4\n");
        }

        fprintf(stderr, "[libsoup/soup-logger.c] enter wrote_body 5\n");
	if (!soup_logger_get_id (logger, priv->session)) {
                fprintf(stderr, "[libsoup/soup-logger.c] enter wrote_body 6\n");
		soup_logger_set_id (logger, priv->session);
                // fprintf(stderr, "[libsoup/soup-logger.c] exit wrote_body 6\n");
        }

        fprintf(stderr, "[libsoup/soup-logger.c] enter wrote_body 7\n");
	conn = soup_message_get_connection (msg);
        if (conn) {
                fprintf(stderr, "[libsoup/soup-logger.c] enter wrote_body 8\n");
                socket = soup_connection_get_socket (conn);
                g_object_unref (conn);
                // fprintf(stderr, "[libsoup/soup-logger.c] exit wrote_body 8\n");
        }
        
        fprintf(stderr, "[libsoup/soup-logger.c] enter wrote_body 9\n");
	if (socket && !soup_logger_get_id (logger, socket)) {
                fprintf(stderr, "[libsoup/soup-logger.c] enter wrote_body 10\n");
		soup_logger_set_id (logger, socket);
                // fprintf(stderr, "[libsoup/soup-logger.c] exit wrote_body 10\n");
        }

        fprintf(stderr, "[libsoup/soup-logger.c] enter wrote_body 11\n");
        g_mutex_lock (&priv->mutex);
	print_request (logger, msg, socket, restarted);
	soup_logger_print (logger, SOUP_LOGGER_LOG_MINIMAL, ' ', "\n");
        g_mutex_unlock (&priv->mutex);
        // fprintf(stderr, "[libsoup/soup-logger.c] exit wrote_body 11\n");
        // fprintf(stderr, "[libsoup/soup-logger.c] exit wrote_body 9\n");
        // fprintf(stderr, "[libsoup/soup-logger.c] exit wrote_body 7\n");
        // fprintf(stderr, "[libsoup/soup-logger.c] exit wrote_body 5\n");
        // fprintf(stderr, "[libsoup/soup-logger.c] exit wrote_body 2\n");
}

static void
soup_logger_request_queued (SoupSessionFeature *logger,
			    SoupMessage        *msg)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_request_queued 1\n");
	g_return_if_fail (SOUP_IS_MESSAGE (msg));

	g_signal_connect (msg, "wrote-body",
				G_CALLBACK (wrote_body),
				logger);
	g_signal_connect (msg, "got-informational",
			  G_CALLBACK (got_informational),
			  logger);
	g_signal_connect (msg, "got-body",
			  G_CALLBACK (got_body),
			  logger);
	g_signal_connect (msg, "finished",
			  G_CALLBACK (finished),
			  logger);
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_request_queued 1\n");
}

static void
soup_logger_request_unqueued (SoupSessionFeature *logger,
			      SoupMessage        *msg)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_request_unqueued 1\n");
	g_return_if_fail (SOUP_IS_MESSAGE (msg));

	g_signal_handlers_disconnect_by_data (msg, logger);
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_request_unqueued 1\n");
}

static void
soup_logger_feature_attach (SoupSessionFeature *feature,
			    SoupSession *session)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_feature_attach 1\n");
	SoupLoggerPrivate *priv = soup_logger_get_instance_private (SOUP_LOGGER (feature));

	priv->session = session;
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_feature_attach 1\n");
}

static void
soup_logger_session_feature_init (SoupSessionFeatureInterface *feature_interface,
				  gpointer interface_data)
{
        fprintf(stderr, "[libsoup/soup-logger.c] enter soup_logger_session_feature_init 1\n");
	feature_interface->attach = soup_logger_feature_attach;
	feature_interface->request_queued = soup_logger_request_queued;
	feature_interface->request_unqueued = soup_logger_request_unqueued;
        // fprintf(stderr, "[libsoup/soup-logger.c] exit soup_logger_session_feature_init 1\n");
}
// Total cost: 0.732611
// Total split cost: 0.073870, input tokens: 35115, output tokens: 1114, cache read tokens: 35099, cache write tokens: 12422, split chunks: [(0, 780), (780, 919)]
// Total instrumented cost: 0.658740, input tokens: 37470, output tokens: 35167, cache read tokens: 37454, cache write tokens: 31987

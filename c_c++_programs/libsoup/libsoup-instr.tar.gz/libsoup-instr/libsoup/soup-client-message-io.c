/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright (C) 2021 Igalia S.L.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include "soup-client-message-io.h"

void
soup_client_message_io_destroy (SoupClientMessageIO *io)
{
        fprintf(stderr, "[libsoup/soup-client-message-io.c] enter soup_client_message_io_destroy 1\n");
        if (!io)
                return;
        // fprintf(stderr, "[libsoup/soup-client-message-io.c] exit soup_client_message_io_destroy 1\n");

        fprintf(stderr, "[libsoup/soup-client-message-io.c] enter soup_client_message_io_destroy 2\n");
        io->funcs->destroy (io);
        // fprintf(stderr, "[libsoup/soup-client-message-io.c] exit soup_client_message_io_destroy 2\n");
}

void
soup_client_message_io_finished (SoupClientMessageIO *io,
                                 SoupMessage         *msg)
{
        fprintf(stderr, "[libsoup/soup-client-message-io.c] enter soup_client_message_io_finished 1\n");
        io->funcs->finished (io, msg);
        // fprintf(stderr, "[libsoup/soup-client-message-io.c] exit soup_client_message_io_finished 1\n");
}

void
soup_client_message_io_stolen (SoupClientMessageIO *io)
{
        fprintf(stderr, "[libsoup/soup-client-message-io.c] enter soup_client_message_io_stolen 1\n");
        io->funcs->stolen (io);
        // fprintf(stderr, "[libsoup/soup-client-message-io.c] exit soup_client_message_io_stolen 1\n");
}

void
soup_client_message_io_send_item (SoupClientMessageIO       *io,
                                  SoupMessageQueueItem      *item,
                                  SoupMessageIOCompletionFn  completion_cb,
                                  gpointer                   user_data)
{
        fprintf(stderr, "[libsoup/soup-client-message-io.c] enter soup_client_message_io_send_item 1\n");
        io->funcs->send_item (io, item, completion_cb, user_data);
        // fprintf(stderr, "[libsoup/soup-client-message-io.c] exit soup_client_message_io_send_item 1\n");
}

void
soup_client_message_io_pause (SoupClientMessageIO *io,
                              SoupMessage         *msg)
{
        fprintf(stderr, "[libsoup/soup-client-message-io.c] enter soup_client_message_io_pause 1\n");
        io->funcs->pause (io, msg);
        // fprintf(stderr, "[libsoup/soup-client-message-io.c] exit soup_client_message_io_pause 1\n");
}

void
soup_client_message_io_unpause (SoupClientMessageIO *io,
                                SoupMessage         *msg)
{
        fprintf(stderr, "[libsoup/soup-client-message-io.c] enter soup_client_message_io_unpause 1\n");
        io->funcs->unpause (io, msg);
        // fprintf(stderr, "[libsoup/soup-client-message-io.c] exit soup_client_message_io_unpause 1\n");
}

gboolean
soup_client_message_io_is_paused (SoupClientMessageIO *io,
                                  SoupMessage         *msg)
{
        fprintf(stderr, "[libsoup/soup-client-message-io.c] enter soup_client_message_io_is_paused 1\n");
        return io->funcs->is_paused (io, msg);
        // fprintf(stderr, "[libsoup/soup-client-message-io.c] exit soup_client_message_io_is_paused 1\n");
}

void
soup_client_message_io_run (SoupClientMessageIO *io,
                            SoupMessage         *msg,
                            gboolean             blocking)
{
        fprintf(stderr, "[libsoup/soup-client-message-io.c] enter soup_client_message_io_run 1\n");
        io->funcs->run (io, msg, blocking);
        // fprintf(stderr, "[libsoup/soup-client-message-io.c] exit soup_client_message_io_run 1\n");
}

gboolean
soup_client_message_io_run_until_read (SoupClientMessageIO *io,
                                       SoupMessage         *msg,
                                       GCancellable        *cancellable,
                                       GError             **error)
{
        fprintf(stderr, "[libsoup/soup-client-message-io.c] enter soup_client_message_io_run_until_read 1\n");
        return io->funcs->run_until_read (io, msg, cancellable, error);
        // fprintf(stderr, "[libsoup/soup-client-message-io.c] exit soup_client_message_io_run_until_read 1\n");
}

void
soup_client_message_io_run_until_read_async (SoupClientMessageIO *io,
                                             SoupMessage         *msg,
                                             int                  io_priority,
                                             GCancellable        *cancellable,
                                             GAsyncReadyCallback  callback,
                                             gpointer             user_data)
{
        fprintf(stderr, "[libsoup/soup-client-message-io.c] enter soup_client_message_io_run_until_read_async 1\n");
        io->funcs->run_until_read_async (io, msg, io_priority, cancellable, callback, user_data);
        // fprintf(stderr, "[libsoup/soup-client-message-io.c] exit soup_client_message_io_run_until_read_async 1\n");
}

gboolean
soup_client_message_io_close_async (SoupClientMessageIO *io,
                                    SoupConnection      *conn,
                                    GAsyncReadyCallback  callback)
{
        fprintf(stderr, "[libsoup/soup-client-message-io.c] enter soup_client_message_io_close_async 1\n");
        return io->funcs->close_async (io, conn, callback);
        // fprintf(stderr, "[libsoup/soup-client-message-io.c] exit soup_client_message_io_close_async 1\n");
}

gboolean
soup_client_message_io_skip (SoupClientMessageIO *io,
                             SoupMessage         *msg,
                             gboolean             blocking,
                             GCancellable        *cancellable,
                             GError             **error)
{
        fprintf(stderr, "[libsoup/soup-client-message-io.c] enter soup_client_message_io_skip 1\n");
        return io->funcs->skip (io, msg, blocking, cancellable, error);
        // fprintf(stderr, "[libsoup/soup-client-message-io.c] exit soup_client_message_io_skip 1\n");
}

GInputStream *
soup_client_message_io_get_response_stream (SoupClientMessageIO *io,
                                            SoupMessage         *msg,
                                            GError             **error)
{
        fprintf(stderr, "[libsoup/soup-client-message-io.c] enter soup_client_message_io_get_response_stream 1\n");
        return io->funcs->get_response_stream (io, msg, error);
        // fprintf(stderr, "[libsoup/soup-client-message-io.c] exit soup_client_message_io_get_response_stream 1\n");
}

gboolean
soup_client_message_io_is_open (SoupClientMessageIO *io)
{
        fprintf(stderr, "[libsoup/soup-client-message-io.c] enter soup_client_message_io_is_open 1\n");
        return io->funcs->is_open (io);
        // fprintf(stderr, "[libsoup/soup-client-message-io.c] exit soup_client_message_io_is_open 1\n");
}

gboolean
soup_client_message_io_in_progress (SoupClientMessageIO *io,
                                    SoupMessage         *msg)
{
        fprintf(stderr, "[libsoup/soup-client-message-io.c] enter soup_client_message_io_in_progress 1\n");
        return io->funcs->in_progress (io, msg);
        // fprintf(stderr, "[libsoup/soup-client-message-io.c] exit soup_client_message_io_in_progress 1\n");
}

gboolean
soup_client_message_io_is_reusable (SoupClientMessageIO *io)
{
        fprintf(stderr, "[libsoup/soup-client-message-io.c] enter soup_client_message_io_is_reusable 1\n");
        return io->funcs->is_reusable (io);
        // fprintf(stderr, "[libsoup/soup-client-message-io.c] exit soup_client_message_io_is_reusable 1\n");
}

GCancellable *
soup_client_message_io_get_cancellable (SoupClientMessageIO *io,
                                        SoupMessage         *msg)
{
        fprintf(stderr, "[libsoup/soup-client-message-io.c] enter soup_client_message_io_get_cancellable 1\n");
        return io->funcs->get_cancellable (io, msg);
        // fprintf(stderr, "[libsoup/soup-client-message-io.c] exit soup_client_message_io_get_cancellable 1\n");
}

void
soup_client_message_io_owner_changed (SoupClientMessageIO *io)
{
        fprintf(stderr, "[libsoup/soup-client-message-io.c] enter soup_client_message_io_owner_changed 1\n");
        if (io->funcs->owner_changed)
                io->funcs->owner_changed (io);
        // fprintf(stderr, "[libsoup/soup-client-message-io.c] exit soup_client_message_io_owner_changed 1\n");
}
// Total cost: 0.038733
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 149)]
// Total instrumented cost: 0.038733, input tokens: 2398, output tokens: 2201, cache read tokens: 2394, cache write tokens: 1330

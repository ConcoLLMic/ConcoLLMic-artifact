/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright (C) 2021 Igalia S.L.
 */

#pragma once

#include "soup-client-message-io.h"

G_BEGIN_DECLS

SoupClientMessageIO *soup_client_message_io_http2_new (SoupConnection *conn);

G_END_DECLS
// Total cost: 0.001851
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 14)]
// Total instrumented cost: 0.001851, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 207

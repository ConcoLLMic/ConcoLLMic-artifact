/*
 * Copyright (C) 2020 Igalia, S.L.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public License
 * along with this library; see the file COPYING.LIB.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA 02110-1301, USA.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdlib.h>
#include <stdio.h>

#include "soup-date-utils.h"
#include "soup-date-utils-private.h"

/**
 * soup_date_time_is_past:
 * @date: a #GDateTime
 *
 * Determines if @date is in the past.
 *
 * Returns: %TRUE if @date is in the past
 */
gboolean
soup_date_time_is_past (GDateTime *date)
{
        fprintf(stderr, "[libsoup/soup-date-utils.c] enter soup_date_time_is_past 1\n");
        g_return_val_if_fail (date != NULL, TRUE);
        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit soup_date_time_is_past 1\n");

	/* optimization */
	if (g_date_time_get_year (date) < 2020) {
                fprintf(stderr, "[libsoup/soup-date-utils.c] enter soup_date_time_is_past 2\n");
		return TRUE;
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit soup_date_time_is_past 2\n");
        }

        fprintf(stderr, "[libsoup/soup-date-utils.c] enter soup_date_time_is_past 3\n");
	return g_date_time_to_unix (date) < time (NULL);
        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit soup_date_time_is_past 3\n");
}

/**
 * SoupDateFormat:
 * @SOUP_DATE_HTTP: RFC 1123 format, used by the HTTP "Date" header. Eg
 *   "Sun, 06 Nov 1994 08:49:37 GMT".
 * @SOUP_DATE_COOKIE: The format for the "Expires" timestamp in the
 *   Netscape cookie specification. Eg, "Sun, 06-Nov-1994 08:49:37 GMT".
 *
 * Date formats that [func@date_time_to_string] can use.
 *
 * @SOUP_DATE_HTTP and @SOUP_DATE_COOKIE always coerce the time to
 * UTC.
 *
 * This enum may be extended with more values in future releases.
 **/

/* Do not internationalize */
static const char *const months[] = {
	"Jan", "Feb", "Mar", "Apr", "May", "Jun",
	"Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
};

/* Do not internationalize */
static const char *const days[] = {
	"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"
};

/**
 * soup_date_time_to_string:
 * @date: a #GDateTime
 * @format: the format to generate the date in
 *
 * Converts @date to a string in the format described by @format.
 *
 * Returns: (transfer full): @date as a string or %NULL
 **/
char *
soup_date_time_to_string (GDateTime      *date,
                          SoupDateFormat  format)
{
        fprintf(stderr, "[libsoup/soup-date-utils.c] enter soup_date_time_to_string 1\n");
	g_return_val_if_fail (date != NULL, NULL);
        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit soup_date_time_to_string 1\n");

	if (format == SOUP_DATE_HTTP || format == SOUP_DATE_COOKIE) {
                fprintf(stderr, "[libsoup/soup-date-utils.c] enter soup_date_time_to_string 2\n");
		/* HTTP and COOKIE formats require UTC timestamp, so coerce
		 * @date if it's non-UTC.
		 */
		GDateTime *utcdate = g_date_time_to_utc (date);
                char *date_format;
                char *formatted_date;
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit soup_date_time_to_string 2\n");

                // We insert days/months ourselves to avoid locale specific formatting
                if (format == SOUP_DATE_HTTP) {
                        fprintf(stderr, "[libsoup/soup-date-utils.c] enter soup_date_time_to_string 3\n");
			/* "Sun, 06 Nov 1994 08:49:37 GMT" */
                        date_format = g_strdup_printf ("%s, %%d %s %%Y %%T GMT",
                                                       days[g_date_time_get_day_of_week (utcdate) - 1],
                                                       months[g_date_time_get_month (utcdate) - 1]);
                        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit soup_date_time_to_string 3\n");
                } else {
                        fprintf(stderr, "[libsoup/soup-date-utils.c] enter soup_date_time_to_string 4\n");
			/* "Sun, 06-Nov-1994 08:49:37 GMT" */
                        date_format = g_strdup_printf ("%s, %%d-%s-%%Y %%T GMT",
                                                       days[g_date_time_get_day_of_week (utcdate) - 1],
                                                       months[g_date_time_get_month (utcdate) - 1]);
                        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit soup_date_time_to_string 4\n");
		}

                fprintf(stderr, "[libsoup/soup-date-utils.c] enter soup_date_time_to_string 5\n");
                formatted_date = g_date_time_format (utcdate, (const char*)date_format);
                g_date_time_unref (utcdate);
                g_free (date_format);
                return formatted_date;
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit soup_date_time_to_string 5\n");
	}

        fprintf(stderr, "[libsoup/soup-date-utils.c] enter soup_date_time_to_string 6\n");
        g_return_val_if_reached (NULL);
        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit soup_date_time_to_string 6\n");
}

static inline gboolean
parse_day (int *day, const char **date_string)
{
        fprintf(stderr, "\n");
	char *end;

	*day = strtoul (*date_string, &end, 10);
	if (end == (char *)*date_string) {
                fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_day 2\n");
		return FALSE;
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_day 2\n");
        }

        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_day 3\n");
	while (*end == ' ' || *end == '-')
		end++;
	*date_string = end;
	return *day >= 1 && *day <= 31;
        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_day 3\n");
}

static inline gboolean
parse_month (int *month, const char **date_string)
{
        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_month 1\n");
	int i;
        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_month 1\n");

	for (i = 0; i < G_N_ELEMENTS (months); i++) {
                fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_month 2\n");
		if (!g_ascii_strncasecmp (*date_string, months[i], 3)) {
                        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_month 3\n");
			*month = i + 1;
			*date_string += 3;
			while (**date_string == ' ' || **date_string == '-')
				(*date_string)++;
			return TRUE;
                        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_month 3\n");
		}
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_month 2\n");
	}
        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_month 4\n");
	return FALSE;
        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_month 4\n");
}

static inline gboolean
parse_year (int *year, const char **date_string)
{
        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_year 1\n");
	char *end;

	*year = strtoul (*date_string, &end, 10);
	if (end == (char *)*date_string) {
                fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_year 2\n");
		return FALSE;
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_year 2\n");
        }
        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_year 1\n");

        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_year 3\n");
	if (end == (char *)*date_string + 2) {
                fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_year 4\n");
		if (*year < 70) {
                        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_year 5\n");
			*year += 2000;
                        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_year 5\n");
                } else {
                        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_year 6\n");
			*year += 1900;
                        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_year 6\n");
                }
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_year 4\n");
	} else if (end == (char *)*date_string + 3) {
                fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_year 7\n");
		*year += 1900;
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_year 7\n");
        }
        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_year 3\n");

        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_year 8\n");
	while (*end == ' ' || *end == '-')
		end++;
	*date_string = end;
	return *year > 0 && *year < 9999;
        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_year 8\n");
}

static inline gboolean
parse_time (int *hour, int *minute, int *second, const char **date_string)
{
        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_time 1\n");
	char *p, *end;

	*hour = strtoul (*date_string, &end, 10);
	if (end == (char *)*date_string || *end++ != ':') {
                fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_time 2\n");
		return FALSE;
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_time 2\n");
        }
        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_time 1\n");

        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_time 3\n");
	p = end;
	*minute = strtoul (p, &end, 10);
	if (end == p || *end++ != ':') {
                fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_time 4\n");
		return FALSE;
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_time 4\n");
        }
        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_time 3\n");

        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_time 5\n");
	p = end;
	*second = strtoul (p, &end, 10);
	if (end == p) {
                fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_time 6\n");
		return FALSE;
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_time 6\n");
        }
        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_time 5\n");

        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_time 7\n");
	p = end;

	while (*p == ' ')
		p++;
	*date_string = p;
	return *hour >= 0 && *hour < 24 && *minute >= 0 && *minute < 60 && *second >= 0 && *second < 60;
        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_time 7\n");
}

static inline gboolean
parse_timezone (GTimeZone **timezone, const char **date_string)
{
        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_timezone 1\n");
        gint32 offset_minutes;
        gboolean utc;
        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_timezone 1\n");

	if (!**date_string) {
                fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_timezone 2\n");
                utc = FALSE;
		offset_minutes = 0;
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_timezone 2\n");
	} else if (**date_string == '+' || **date_string == '-') {
                fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_timezone 3\n");
		gulong val;
		int sign = (**date_string == '+') ? 1 : -1;
		val = strtoul (*date_string + 1, (char **)date_string, 10);
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_timezone 3\n");
		if (val > 9999) {
                        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_timezone 4\n");
			return FALSE;
                        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_timezone 4\n");
                }
                fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_timezone 5\n");
		if (**date_string == ':') {
                        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_timezone 6\n");
			gulong val2 = strtoul (*date_string + 1, (char **)date_string, 10);
                        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_timezone 6\n");
			if (val > 99 || val2 > 99) {
                                fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_timezone 7\n");
				return FALSE;
                                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_timezone 7\n");
                        }
                        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_timezone 8\n");
			val = 60 * val + val2;
                        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_timezone 8\n");
		} else {
                        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_timezone 9\n");
			val =  60 * (val / 100) + (val % 100);
                        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_timezone 9\n");
                }
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_timezone 5\n");
                fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_timezone 10\n");
		offset_minutes = sign * val;
                utc = (sign == -1) && !val;
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_timezone 10\n");
	} else if (**date_string == 'Z') {
                fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_timezone 11\n");
		offset_minutes = 0;
                utc = TRUE;
		(*date_string)++;
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_timezone 11\n");
	} else if (!strcmp (*date_string, "GMT") ||
		   !strcmp (*date_string, "UTC")) {
                fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_timezone 12\n");
		offset_minutes = 0;
                utc = TRUE;
		(*date_string) += 3;
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_timezone 12\n");
	} else if (strchr ("ECMP", **date_string) &&
		   ((*date_string)[1] == 'D' || (*date_string)[1] == 'S') &&
		   (*date_string)[2] == 'T') {
                fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_timezone 13\n");
		offset_minutes = -60 * (5 * strcspn ("ECMP", *date_string));
		if ((*date_string)[1] == 'D') {
                        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_timezone 14\n");
			offset_minutes += 60;
                        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_timezone 14\n");
                }
                utc = FALSE;
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_timezone 13\n");
	} else {
                fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_timezone 15\n");
		return FALSE;
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_timezone 15\n");
        }

        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_timezone 16\n");
        if (utc)
                *timezone = g_time_zone_new_utc ();
        else
                *timezone = g_time_zone_new_offset (offset_minutes * 60);
	return TRUE;
        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_timezone 16\n");
}

static GDateTime *
parse_textual_date (const char *date_string)
{
        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_textual_date 1\n");
        int month, day, year, hour, minute, second;
        GTimeZone *tz = NULL;
        GDateTime *date;
        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_textual_date 1\n");

	/* If it starts with a word, it must be a weekday, which we skip */
	if (g_ascii_isalpha (*date_string)) {
                fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_textual_date 2\n");
		while (g_ascii_isalpha (*date_string))
			date_string++;
		if (*date_string == ',')
			date_string++;
		while (g_ascii_isspace (*date_string))
			date_string++;
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_textual_date 2\n");
	}

	/* If there's now another word, this must be an asctime-date */
	if (g_ascii_isalpha (*date_string)) {
                fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_textual_date 3\n");
		/* (Sun) Nov  6 08:49:37 1994 */
		if (!parse_month (&month, &date_string) ||
		    !parse_day (&day, &date_string) ||
		    !parse_time (&hour, &minute, &second, &date_string) ||
		    !parse_year (&year, &date_string) ||
		    !g_date_valid_dmy (day, month, year)) {
                        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_textual_date 4\n");
			return NULL;
                        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_textual_date 4\n");
                }
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_textual_date 3\n");

                fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_textual_date 5\n");
		/* There shouldn't be a timezone, but check anyway */
		parse_timezone (&tz, &date_string);
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_textual_date 5\n");
	} else {
                fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_textual_date 6\n");
		/* Non-asctime date, so some variation of
		 * (Sun,) 06 Nov 1994 08:49:37 GMT
		 */
		if (!parse_day (&day, &date_string) ||
		    !parse_month (&month, &date_string) ||
		    !parse_year (&year, &date_string) ||
		    !parse_time (&hour, &minute, &second, &date_string) ||
		    !g_date_valid_dmy (day, month, year)) {
                        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_textual_date 7\n");
			return NULL;
                        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_textual_date 7\n");
                }
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_textual_date 6\n");

                fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_textual_date 8\n");
		/* This time there *should* be a timezone, but we
		 * survive if there isn't.
		 */
		parse_timezone (&tz, &date_string);
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_textual_date 8\n");
	}

        fprintf(stderr, "[libsoup/soup-date-utils.c] enter parse_textual_date 9\n");
        if (!tz)
                tz = g_time_zone_new_utc ();

        date = g_date_time_new (tz, year, month, day, hour, minute, second);
        g_time_zone_unref (tz);

        return date;
        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit parse_textual_date 9\n");
}

/**
 * soup_date_time_new_from_http_string:
 * @date_string: The date as a string
 *
 * Parses @date_string and tries to extract a date from it.
 *
 * This recognizes all of the "HTTP-date" formats from RFC 2616, RFC 2822 dates,
 * and reasonable approximations thereof. (Eg, it is lenient about whitespace,
 * leading "0"s, etc.)
 *
 * Returns: (nullable): a new #GDateTime, or %NULL if @date_string
 *   could not be parsed.
 **/
GDateTime *
soup_date_time_new_from_http_string (const char *date_string)
{
        fprintf(stderr, "[libsoup/soup-date-utils.c] enter soup_date_time_new_from_http_string 1\n");
        g_return_val_if_fail (date_string != NULL, NULL);
        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit soup_date_time_new_from_http_string 1\n");

        fprintf(stderr, "[libsoup/soup-date-utils.c] enter soup_date_time_new_from_http_string 2\n");
	while (g_ascii_isspace (*date_string))
		date_string++;
        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit soup_date_time_new_from_http_string 2\n");

        /* If it starts with a digit, it's either an ISO 8601 date, or
         * an RFC2822 date without the optional weekday; in the later
         * case, there will be a month name later on, so look for one
         * of the month-start letters.
         * Previous versions of this library supported parsing iso8601 strings
         * however g_date_time_new_from_iso8601() should be used now. Just
         * catch those in case for testing.
         */
	if (G_UNLIKELY (g_ascii_isdigit (*date_string) && !strpbrk (date_string, "JFMASOND"))) {
                fprintf(stderr, "[libsoup/soup-date-utils.c] enter soup_date_time_new_from_http_string 3\n");
                g_debug ("Unsupported format passed to soup_date_time_new_from_http_string(): %s", date_string);
                return NULL;
                // fprintf(stderr, "[libsoup/soup-date-utils.c] exit soup_date_time_new_from_http_string 3\n");
        }

        fprintf(stderr, "[libsoup/soup-date-utils.c] enter soup_date_time_new_from_http_string 4\n");
	return parse_textual_date (date_string);
        // fprintf(stderr, "[libsoup/soup-date-utils.c] exit soup_date_time_new_from_http_string 4\n");
}
// Total cost: 0.333111
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 339)]
// Total instrumented cost: 0.333111, input tokens: 20424, output tokens: 17877, cache read tokens: 20412, cache write tokens: 15679

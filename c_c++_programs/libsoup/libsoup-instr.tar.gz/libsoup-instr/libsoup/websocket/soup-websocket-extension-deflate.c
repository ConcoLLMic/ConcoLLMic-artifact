/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * soup-websocket-extension-deflate.c
 *
 * Copyright (C) 2019 Igalia S.L.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public License
 * along with this library; see the file COPYING.LIB.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA 02110-1301, USA.
 */


#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "soup-websocket-extension-deflate.h"
#include <zlib.h>
#include <stdio.h>

typedef struct {
        z_stream zstream;
        gboolean no_context_takeover;
} Deflater;

typedef struct {
        z_stream zstream;
        gboolean uncompress_ongoing;
} Inflater;

#define BUFFER_SIZE 4096

typedef enum {
        PARAM_SERVER_NO_CONTEXT_TAKEOVER   = 1 << 0,
        PARAM_CLIENT_NO_CONTEXT_TAKEOVER   = 1 << 1,
        PARAM_SERVER_MAX_WINDOW_BITS       = 1 << 2,
        PARAM_CLIENT_MAX_WINDOW_BITS       = 1 << 3
} ParamFlags;

typedef struct {
        ParamFlags flags;
        gushort server_max_window_bits;
        gushort client_max_window_bits;
} Params;

struct _SoupWebsocketExtensionDeflate {
	SoupWebsocketExtension parent;
};

typedef struct {
        Params params;

        gboolean enabled;

        Deflater deflater;
        Inflater inflater;
} SoupWebsocketExtensionDeflatePrivate;

/**
 * SoupWebsocketExtensionDeflate:
 *
 * A SoupWebsocketExtensionDeflate is a [class@WebsocketExtension]
 * implementing permessage-deflate (RFC 7692).
 *
 * This extension is used by default in a [class@Session] when [class@WebsocketExtensionManager]
 * feature is present, and always used by [class@Server].
 */

G_DEFINE_FINAL_TYPE_WITH_PRIVATE (SoupWebsocketExtensionDeflate, soup_websocket_extension_deflate, SOUP_TYPE_WEBSOCKET_EXTENSION)

static void
soup_websocket_extension_deflate_init (SoupWebsocketExtensionDeflate *basic)
{
    fprintf(stderr, "\n");
    // fprintf(stderr, "\n");
}

static void
soup_websocket_extension_deflate_finalize (GObject *object)
{
    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_finalize 1\n");
    SoupWebsocketExtensionDeflatePrivate *priv = soup_websocket_extension_deflate_get_instance_private (SOUP_WEBSOCKET_EXTENSION_DEFLATE (object));
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_finalize 1\n");

    if (priv->enabled) {
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_finalize 2\n");
        deflateEnd (&priv->deflater.zstream);
        inflateEnd (&priv->inflater.zstream);
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_finalize 2\n");
    }

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_finalize 3\n");
    G_OBJECT_CLASS (soup_websocket_extension_deflate_parent_class)->finalize (object);
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_finalize 3\n");
}

static gboolean
parse_window_bits (const char *value,
                   gushort    *out)
{
    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter parse_window_bits 1\n");
    guint64 int_value;
    char *end = NULL;
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit parse_window_bits 1\n");

    if (!value || !*value) {
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter parse_window_bits 2\n");
        return FALSE;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit parse_window_bits 2\n");
    }

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter parse_window_bits 3\n");
    int_value = g_ascii_strtoull (value, &end, 10);
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit parse_window_bits 3\n");
    
    if (*end != '\0') {
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter parse_window_bits 4\n");
        return FALSE;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit parse_window_bits 4\n");
    }

    fprintf(stderr, "\n");
    if (int_value < 8 || int_value > 15) {
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter parse_window_bits 6\n");
        return FALSE;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit parse_window_bits 6\n");
    }

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter parse_window_bits 7\n");
    *out = (gushort)int_value;
    return TRUE;
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit parse_window_bits 7\n");
}

static gboolean
return_invalid_param_error (GError    **error,
                            const char *param)
{
    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter return_invalid_param_error 1\n");
    g_set_error (error,
                 SOUP_WEBSOCKET_ERROR,
                 SOUP_WEBSOCKET_ERROR_BAD_HANDSHAKE,
                 "Invalid parameter '%s' in permessage-deflate extension header",
                 param);
    return FALSE;
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit return_invalid_param_error 1\n");
}

static gboolean
return_invalid_param_value_error (GError    **error,
                                  const char *param)
{
    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter return_invalid_param_value_error 1\n");
    g_set_error (error,
                 SOUP_WEBSOCKET_ERROR,
                 SOUP_WEBSOCKET_ERROR_BAD_HANDSHAKE,
                 "Invalid value of parameter '%s' in permessage-deflate extension header",
                 param);
    return FALSE;
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit return_invalid_param_value_error 1\n");
}

static gboolean
parse_params (GHashTable *params,
              Params     *out,
              GError    **error)
{
    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter parse_params 1\n");
    GHashTableIter iter;
    gpointer key, value;
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit parse_params 1\n");

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter parse_params 2\n");
    g_hash_table_iter_init (&iter, params);
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit parse_params 2\n");
    
    while (g_hash_table_iter_next (&iter, &key, &value)) {
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter parse_params 3\n");
        if (g_str_equal ((char *)key, "server_no_context_takeover")) {
            fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter parse_params 4\n");
            if (value)
                return return_invalid_param_value_error(error, "server_no_context_takeover");

            out->flags |= PARAM_SERVER_NO_CONTEXT_TAKEOVER;
            // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit parse_params 4\n");
        } else if (g_str_equal ((char *)key, "client_no_context_takeover")) {
            fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter parse_params 5\n");
            if (value)
                return return_invalid_param_value_error(error, "client_no_context_takeover");

            out->flags |= PARAM_CLIENT_NO_CONTEXT_TAKEOVER;
            // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit parse_params 5\n");
        } else if (g_str_equal ((char *)key, "server_max_window_bits")) {
            fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter parse_params 6\n");
            if (!parse_window_bits ((char *)value, &out->server_max_window_bits))
                return return_invalid_param_value_error(error, "server_max_window_bits");

            out->flags |= PARAM_SERVER_MAX_WINDOW_BITS;
            // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit parse_params 6\n");
        } else if (g_str_equal ((char *)key, "client_max_window_bits")) {
            fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter parse_params 7\n");
            if (value) {
                fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter parse_params 8\n");
                if (!parse_window_bits ((char *)value, &out->client_max_window_bits))
                    return return_invalid_param_value_error(error, "client_max_window_bits");
                // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit parse_params 8\n");
            } else {
                fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter parse_params 9\n");
                out->client_max_window_bits = 15;
                // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit parse_params 9\n");
            }
            out->flags |= PARAM_CLIENT_MAX_WINDOW_BITS;
            // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit parse_params 7\n");
        } else {
            fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter parse_params 10\n");
            return return_invalid_param_error (error, (char *)key);
            // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit parse_params 10\n");
        }
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit parse_params 3\n");
    }

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter parse_params 11\n");
    return TRUE;
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit parse_params 11\n");
}

static gboolean
soup_websocket_extension_deflate_configure (SoupWebsocketExtension     *extension,
                                            SoupWebsocketConnectionType connection_type,
                                            GHashTable                 *params,
                                            GError                    **error)
{
    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_configure 1\n");
    gushort deflater_max_window_bits;
    gushort inflater_max_window_bits;
    SoupWebsocketExtensionDeflatePrivate *priv;
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_configure 1\n");

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_configure 2\n");
    priv = soup_websocket_extension_deflate_get_instance_private (SOUP_WEBSOCKET_EXTENSION_DEFLATE (extension));
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_configure 2\n");

    if (params && !parse_params (params, &priv->params, error)) {
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_configure 3\n");
        return FALSE;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_configure 3\n");
    }

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_configure 4\n");
    switch (connection_type) {
    case SOUP_WEBSOCKET_CONNECTION_CLIENT:
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_configure 5\n");
        priv->deflater.no_context_takeover = priv->params.flags & PARAM_CLIENT_NO_CONTEXT_TAKEOVER;
        deflater_max_window_bits = priv->params.flags & PARAM_CLIENT_MAX_WINDOW_BITS ? priv->params.client_max_window_bits : 15;
        inflater_max_window_bits = priv->params.flags & PARAM_SERVER_MAX_WINDOW_BITS ? priv->params.server_max_window_bits : 15;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_configure 5\n");
        break;
    case SOUP_WEBSOCKET_CONNECTION_SERVER:
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_configure 6\n");
        priv->deflater.no_context_takeover = priv->params.flags & PARAM_SERVER_NO_CONTEXT_TAKEOVER;
        deflater_max_window_bits = priv->params.flags & PARAM_SERVER_MAX_WINDOW_BITS ? priv->params.server_max_window_bits : 15;
        inflater_max_window_bits = priv->params.flags & PARAM_CLIENT_MAX_WINDOW_BITS ? priv->params.client_max_window_bits : 15;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_configure 6\n");
        break;
    default:
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_configure 7\n");
        g_assert_not_reached ();
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_configure 7\n");
    }
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_configure 4\n");

    /* zlib is unable to compress with window_bits=8, so use 9
     * instead. This is compatible with decompressing using
     * window_bits=8.
     */
    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_configure 8\n");
    deflater_max_window_bits = MAX (deflater_max_window_bits, 9);
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_configure 8\n");

    /* In case of failing to initialize zlib deflater/inflater,
     * we return TRUE without setting enabled = TRUE, so that the
     * hanshake doesn't fail.
     */
    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_configure 9\n");
    if (deflateInit2 (&priv->deflater.zstream, Z_DEFAULT_COMPRESSION, Z_DEFLATED, -deflater_max_window_bits, 8, Z_DEFAULT_STRATEGY) != Z_OK)
        return TRUE;
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_configure 9\n");

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_configure 10\n");
    if (inflateInit2 (&priv->inflater.zstream, -inflater_max_window_bits) != Z_OK) {
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_configure 11\n");
        deflateEnd (&priv->deflater.zstream);
        return TRUE;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_configure 11\n");
    }
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_configure 10\n");

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_configure 12\n");
    priv->enabled = TRUE;

    return TRUE;
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_configure 12\n");
}

static char *
soup_websocket_extension_deflate_get_request_params (SoupWebsocketExtension *extension)
{
    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_get_request_params 1\n");
    return g_strdup ("; client_max_window_bits");
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_get_request_params 1\n");
}

static char *
soup_websocket_extension_deflate_get_response_params (SoupWebsocketExtension *extension)
{
    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_get_response_params 1\n");
    GString *params;
    SoupWebsocketExtensionDeflatePrivate *priv;
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_get_response_params 1\n");

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_get_response_params 2\n");
    priv = soup_websocket_extension_deflate_get_instance_private (SOUP_WEBSOCKET_EXTENSION_DEFLATE (extension));
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_get_response_params 2\n");
    
    if (!priv->enabled) {
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_get_response_params 3\n");
        return NULL;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_get_response_params 3\n");
    }

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_get_response_params 4\n");
    if (priv->params.flags == 0) {
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_get_response_params 5\n");
        return NULL;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_get_response_params 5\n");
    }
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_get_response_params 4\n");

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_get_response_params 6\n");
    params = g_string_new (NULL);
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_get_response_params 6\n");

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_get_response_params 7\n");
    if (priv->params.flags & PARAM_SERVER_NO_CONTEXT_TAKEOVER)
        params = g_string_append (params, "; server_no_context_takeover");
    if (priv->params.flags & PARAM_CLIENT_NO_CONTEXT_TAKEOVER)
        params = g_string_append (params, "; client_no_context_takeover");
    if (priv->params.flags & PARAM_SERVER_MAX_WINDOW_BITS)
        g_string_append_printf (params, "; server_max_window_bits=%u", priv->params.server_max_window_bits);
    if (priv->params.flags & PARAM_CLIENT_MAX_WINDOW_BITS)
        g_string_append_printf (params, "; client_max_window_bits=%u", priv->params.client_max_window_bits);
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_get_response_params 7\n");

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_get_response_params 8\n");
    return g_string_free (params, FALSE);
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_get_response_params 8\n");
}

static void
deflater_reset (Deflater *deflater)
{
    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter deflater_reset 1\n");
    if (deflater->no_context_takeover)
        deflateReset (&deflater->zstream);
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit deflater_reset 1\n");
}

static GBytes *
soup_websocket_extension_deflate_process_outgoing_message (SoupWebsocketExtension *extension,
                                                           guint8                 *header,
                                                           GBytes                 *payload,
                                                           GError                **error)
{
    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_outgoing_message 1\n");
    const guint8 *payload_data;
    gsize payload_length;
    guint max_length;
    gboolean control;
    GByteArray *buffer;
    gsize bytes_written;
    int result;
    gboolean in_sync_flush;
    SoupWebsocketExtensionDeflatePrivate *priv;
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_outgoing_message 1\n");

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_outgoing_message 2\n");
    priv = soup_websocket_extension_deflate_get_instance_private (SOUP_WEBSOCKET_EXTENSION_DEFLATE (extension));
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_outgoing_message 2\n");

    if (!priv->enabled) {
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_outgoing_message 3\n");
        return payload;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_outgoing_message 3\n");
    }

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_outgoing_message 4\n");
    control = header[0] & 0x08;
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_outgoing_message 4\n");

    /* Do not compress control frames */
    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_outgoing_message 5\n");
    if (control) {
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_outgoing_message 6\n");
        return payload;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_outgoing_message 6\n");
    }
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_outgoing_message 5\n");

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_outgoing_message 7\n");
    payload_data = g_bytes_get_data (payload, &payload_length);
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_outgoing_message 7\n");
    
    if (payload_length == 0) {
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_outgoing_message 8\n");
        return payload;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_outgoing_message 8\n");
    }

    /* Mark the frame as compressed using reserved bit 1 (0x40) */
    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_outgoing_message 9\n");
    header[0] |= 0x40;
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_outgoing_message 9\n");

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_outgoing_message 10\n");
    buffer = g_byte_array_new ();
    max_length = deflateBound(&priv->deflater.zstream, payload_length);

    priv->deflater.zstream.next_in = (void *)payload_data;
    priv->deflater.zstream.avail_in = payload_length;

    bytes_written = 0;
    priv->deflater.zstream.avail_out = 0;
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_outgoing_message 10\n");

    do {
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_outgoing_message 11\n");
        gsize write_remaining;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_outgoing_message 11\n");

        if (priv->deflater.zstream.avail_out == 0) {
            fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_outgoing_message 12\n");
            guint write_position;

            priv->deflater.zstream.avail_out = max_length;
            write_position = buffer->len;
            g_byte_array_set_size (buffer, buffer->len + max_length);
            priv->deflater.zstream.next_out = buffer->data + write_position;

            /* Use a fixed value for buffer increments */
            max_length = BUFFER_SIZE;
            // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_outgoing_message 12\n");
        }

        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_outgoing_message 13\n");
        write_remaining = buffer->len - bytes_written;
        in_sync_flush = priv->deflater.zstream.avail_in == 0;
        result = deflate (&priv->deflater.zstream, in_sync_flush ? Z_SYNC_FLUSH : Z_NO_FLUSH);
        bytes_written += write_remaining - priv->deflater.zstream.avail_out;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_outgoing_message 13\n");
    } while (result == Z_OK);

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_outgoing_message 14\n");
    g_bytes_unref (payload);
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_outgoing_message 14\n");

    if (result != Z_BUF_ERROR || bytes_written < 4) {
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_outgoing_message 15\n");
        g_set_error_literal (error,
                             SOUP_WEBSOCKET_ERROR,
                             SOUP_WEBSOCKET_CLOSE_PROTOCOL_ERROR,
                             "Failed to compress outgoing frame");
        g_byte_array_unref (buffer);
        deflater_reset (&priv->deflater);
        return NULL;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_outgoing_message 15\n");
    }

    /* Remove 4 octets (that are 0x00 0x00 0xff 0xff) from the tail end. */
    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_outgoing_message 16\n");
    g_byte_array_set_size (buffer, bytes_written - 4);
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_outgoing_message 16\n");

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_outgoing_message 17\n");
    deflater_reset (&priv->deflater);
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_outgoing_message 17\n");

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_outgoing_message 18\n");
    return g_byte_array_free_to_bytes (buffer);
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_outgoing_message 18\n");
}

static GBytes *
soup_websocket_extension_deflate_process_incoming_message (SoupWebsocketExtension *extension,
                                                           guint8                 *header,
                                                           GBytes                 *payload,
                                                           GError                **error)
{
    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 1\n");
    const guint8 *payload_data;
    gsize payload_length;
    gboolean fin, control, compressed;
    GByteArray *buffer;
    gsize bytes_read, bytes_written;
    int result;
    gboolean tail_added = FALSE;
    SoupWebsocketExtensionDeflatePrivate *priv;
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 1\n");

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 2\n");
    priv = soup_websocket_extension_deflate_get_instance_private (SOUP_WEBSOCKET_EXTENSION_DEFLATE (extension));
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 2\n");

    if (!priv->enabled) {
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 3\n");
        return payload;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 3\n");
    }

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 4\n");
    control = header[0] & 0x08;
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 4\n");

    /* Do not uncompress control frames */
    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 5\n");
    if (control) {
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 6\n");
        return payload;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 6\n");
    }
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 5\n");

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 7\n");
    compressed = header[0] & 0x40;
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 7\n");
    
    if (!priv->inflater.uncompress_ongoing && !compressed) {
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 8\n");
        return payload;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 8\n");
    }

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 9\n");
    if (priv->inflater.uncompress_ongoing && compressed) {
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 10\n");
        g_set_error_literal (error,
                             SOUP_WEBSOCKET_ERROR,
                             SOUP_WEBSOCKET_CLOSE_PROTOCOL_ERROR,
                             "Received a non-first frame with RSV1 flag set");
        g_bytes_unref (payload);
        return NULL;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 10\n");
    }
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 9\n");

    /* Remove the compressed flag */
    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 11\n");
    header[0] &= ~0x40;
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 11\n");

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 12\n");
    fin = header[0] & 0x80;
    payload_data = g_bytes_get_data (payload, &payload_length);
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 12\n");
    
    if (payload_length == 0 && ((!priv->inflater.uncompress_ongoing && fin) || (priv->inflater.uncompress_ongoing && !fin))) {
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 13\n");
        return payload;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 13\n");
    }

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 14\n");
    priv->inflater.uncompress_ongoing = !fin;
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 14\n");

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 15\n");
    buffer = g_byte_array_new ();

    bytes_read = 0;
    priv->inflater.zstream.next_in = (void *)payload_data;
    priv->inflater.zstream.avail_in = payload_length;

    bytes_written = 0;
    priv->inflater.zstream.avail_out = 0;
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 15\n");

    do {
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 16\n");
        gsize read_remaining;
        gsize write_remaining;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 16\n");

        if (priv->inflater.zstream.avail_out == 0) {
            fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 17\n");
            guint current_position;

            priv->inflater.zstream.avail_out = BUFFER_SIZE;
            current_position = buffer->len;
            g_byte_array_set_size (buffer, buffer->len + BUFFER_SIZE);
            priv->inflater.zstream.next_out = buffer->data + current_position;
            // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 17\n");
        }

        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 18\n");
        if (priv->inflater.zstream.avail_in == 0 && !tail_added && fin) {
            fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 19\n");
            /* Append 4 octets of 0x00 0x00 0xff 0xff to the tail end */
            priv->inflater.zstream.next_in = (void *)"\x00\x00\xff\xff";
            priv->inflater.zstream.avail_in = 4;
            bytes_read = 0;
            tail_added = TRUE;
            // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 19\n");
        }
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 18\n");

        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 20\n");
        read_remaining = tail_added ? 4 : payload_length - bytes_read;
        write_remaining = buffer->len - bytes_written;
        result = inflate (&priv->inflater.zstream, tail_added ? Z_FINISH : Z_NO_FLUSH);
        bytes_read += read_remaining - priv->inflater.zstream.avail_in;
        bytes_written += write_remaining - priv->inflater.zstream.avail_out;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 20\n");
        
        if (!tail_added && result == Z_STREAM_END) {
            fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 21\n");
            /* Received a block with BFINAL set to 1. Reset decompression state. */
            result = inflateReset (&priv->inflater.zstream);
            // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 21\n");
        }

        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 22\n");
        if ((!fin && bytes_read == payload_length) || (fin && tail_added && bytes_read == 4))
            break;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 22\n");
    } while (result == Z_OK || result == Z_BUF_ERROR);

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 23\n");
    g_bytes_unref (payload);
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 23\n");

    if (result != Z_OK && result != Z_BUF_ERROR) {
        fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 24\n");
        priv->inflater.uncompress_ongoing = FALSE;
        g_set_error_literal (error,
                             SOUP_WEBSOCKET_ERROR,
                             SOUP_WEBSOCKET_CLOSE_PROTOCOL_ERROR,
                             "Failed to uncompress incoming frame");
        g_byte_array_unref (buffer);

        return NULL;
        // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 24\n");
    }

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 25\n");
    g_byte_array_set_size (buffer, bytes_written);
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 25\n");

    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_process_incoming_message 26\n");
    return g_byte_array_free_to_bytes (buffer);
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_process_incoming_message 26\n");
}

static void
soup_websocket_extension_deflate_class_init (SoupWebsocketExtensionDeflateClass *klass)
{
    fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] enter soup_websocket_extension_deflate_class_init 1\n");
    SoupWebsocketExtensionClass *extension_class = SOUP_WEBSOCKET_EXTENSION_CLASS (klass);
    GObjectClass *object_class = G_OBJECT_CLASS (klass);

    extension_class->name = "permessage-deflate";

    extension_class->configure = soup_websocket_extension_deflate_configure;
    extension_class->get_request_params = soup_websocket_extension_deflate_get_request_params;
    extension_class->get_response_params = soup_websocket_extension_deflate_get_response_params;
    extension_class->process_outgoing_message = soup_websocket_extension_deflate_process_outgoing_message;
    extension_class->process_incoming_message = soup_websocket_extension_deflate_process_incoming_message;

    object_class->finalize = soup_websocket_extension_deflate_finalize;
    // fprintf(stderr, "[libsoup/websocket/soup-websocket-extension-deflate.c] exit soup_websocket_extension_deflate_class_init 1\n");
}
// Total cost: 0.173875
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 488)]
// Total instrumented cost: 0.173875, input tokens: 2398, output tokens: 10151, cache read tokens: 2394, cache write tokens: 5568

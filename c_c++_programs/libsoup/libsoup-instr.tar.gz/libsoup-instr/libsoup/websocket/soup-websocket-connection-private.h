/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright (C) 2024 Axis Communications AB, SWEDEN.
 */

#ifndef __SOUP_WEBSOCKET_CONNECTION_PRIVATE_H__
#define __SOUP_WEBSOCKET_CONNECTION_PRIVATE_H__ 1

#include "soup-websocket-connection.h"

void soup_websocket_connection_set_suppress_pongs_for_tests (SoupWebsocketConnection *self,
                                                             gboolean suppress);

#endif /* __SOUP_WEBSOCKET_CONNECTION_PRIVATE_H__ */
// Total cost: 0.002035
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 14)]
// Total instrumented cost: 0.002035, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 256

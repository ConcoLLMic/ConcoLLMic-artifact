/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * soup-session.c
 *
 * Copyright (C) 2000-2003, Ximian, Inc.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <glib/gi18n-lib.h>
#include <gmodule.h>
#include "gconstructor.h"
#include <stdio.h>

#ifdef G_OS_WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

HMODULE soup_dll;
#endif

static gboolean
soup2_is_loaded (void)
{
    fprintf(stderr, "[libsoup/soup-init.c] enter soup2_is_loaded 1\n");
    GModule *module = g_module_open (NULL, 0);
    gpointer func;
    gboolean result = FALSE;
    // fprintf(stderr, "[libsoup/soup-init.c] exit soup2_is_loaded 1\n");

    if (g_module_symbol (module, "soup_uri_new", &func)) {
        fprintf(stderr, "[libsoup/soup-init.c] enter soup2_is_loaded 2\n");
        result = TRUE;
        // fprintf(stderr, "[libsoup/soup-init.c] exit soup2_is_loaded 2\n");
    }

    fprintf(stderr, "[libsoup/soup-init.c] enter soup2_is_loaded 3\n");
    g_module_close (module);

    return result;
    // fprintf(stderr, "[libsoup/soup-init.c] exit soup2_is_loaded 3\n");
}

static void
soup_init (void)
{
    fprintf(stderr, "[libsoup/soup-init.c] enter soup_init 1\n");
#ifdef G_OS_WIN32
	char *basedir = g_win32_get_package_installation_directory_of_module (soup_dll);
	char *localedir = g_build_filename (basedir, "share", "locale", NULL);
	bindtextdomain (GETTEXT_PACKAGE, localedir);
	g_free (localedir);
	g_free (basedir);
#else
	bindtextdomain (GETTEXT_PACKAGE, LOCALEDIR);
#endif
#ifdef HAVE_BIND_TEXTDOMAIN_CODESET
	bind_textdomain_codeset (GETTEXT_PACKAGE, "UTF-8");
#endif

    if (soup2_is_loaded ()) {
        fprintf(stderr, "[libsoup/soup-init.c] enter soup_init 2\n");
        g_error ("libsoup2 symbols detected. Using libsoup2 and libsoup3 in the same process is not supported.");
        // fprintf(stderr, "[libsoup/soup-init.c] exit soup_init 2\n");
    }
    // fprintf(stderr, "[libsoup/soup-init.c] exit soup_init 1\n");
}

#if defined (G_OS_WIN32)

BOOL WINAPI DllMain (HINSTANCE hinstDLL,
                     DWORD     fdwReason,
                     LPVOID    lpvReserved);

BOOL WINAPI
DllMain (HINSTANCE hinstDLL,
         DWORD     fdwReason,
         LPVOID    lpvReserved)
{
    fprintf(stderr, "[libsoup/soup-init.c] enter DllMain 1\n");
	switch (fdwReason) {
	case DLL_PROCESS_ATTACH:
        fprintf(stderr, "[libsoup/soup-init.c] enter DllMain 2\n");
		soup_dll = hinstDLL;

		soup_init ();
		break;
        // fprintf(stderr, "[libsoup/soup-init.c] exit DllMain 2\n");

	case DLL_THREAD_DETACH:
        fprintf(stderr, "\n");
        // fprintf(stderr, "\n");
        break;

	default:
        fprintf(stderr, "[libsoup/soup-init.c] enter DllMain 4\n");
		/* do nothing */
		;
        // fprintf(stderr, "[libsoup/soup-init.c] exit DllMain 4\n");
	}

	return TRUE;
    // fprintf(stderr, "[libsoup/soup-init.c] exit DllMain 1\n");
}

#elif defined (G_HAS_CONSTRUCTORS)

#ifdef G_DEFINE_CONSTRUCTOR_NEEDS_PRAGMA
#pragma G_DEFINE_CONSTRUCTOR_PRAGMA_ARGS(soup_init_ctor)
#endif
G_DEFINE_CONSTRUCTOR(soup_init_ctor)

static void
soup_init_ctor (void)
{
    fprintf(stderr, "[libsoup/soup-init.c] enter soup_init_ctor 1\n");
	soup_init ();
    // fprintf(stderr, "[libsoup/soup-init.c] exit soup_init_ctor 1\n");
}

#else
# error Your platform/compiler is missing constructor support
#endif
// Total cost: 0.021640
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 101)]
// Total instrumented cost: 0.021640, input tokens: 2398, output tokens: 1178, cache read tokens: 2394, cache write tokens: 864

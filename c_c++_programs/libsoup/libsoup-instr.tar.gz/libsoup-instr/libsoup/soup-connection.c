/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * soup-connection.c: A single HTTP/HTTPS connection
 *
 * Copyright (C) 2000-2003, Ximian, Inc.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include "soup-connection.h"
#include "soup.h"
#include "soup-io-stream.h"
#include "soup-message-queue-item.h"
#include "soup-client-message-io-http1.h"
#include "soup-client-message-io-http2.h"
#include "soup-socket-properties.h"
#include "soup-private-enum-types.h"
#include "soup-tls-interaction.h"
#include <gio/gnetworking.h>

struct _SoupConnection {
        GObject parent_instance;
};

typedef struct {
	GIOStream *connection;
	GSocketConnectable *remote_connectable;
	GIOStream *iostream;
	SoupSocketProperties *socket_props;
        guint64 id;
        GSocketAddress *remote_address;
        guint8 force_http_version;

	GUri *proxy_uri;
	gboolean ssl;

	SoupMessage *proxy_msg;
        SoupClientMessageIO *io_data;
	SoupConnectionState state;
	time_t       unused_timeout;
	GSource     *idle_timeout_src;
        guint        in_use;
        SoupHTTPVersion http_version;

        GTlsCertificate *tls_client_cert;

	GCancellable *cancellable;
        GThread *owner;

        int window_size;
        int stream_window_size;
} SoupConnectionPrivate;

G_DEFINE_FINAL_TYPE_WITH_PRIVATE (SoupConnection, soup_connection, G_TYPE_OBJECT)

enum {
	EVENT,
	ACCEPT_CERTIFICATE,
        REQUEST_CERTIFICATE,
        REQUEST_CERTIFICATE_PASSWORD,
	DISCONNECTED,
	LAST_SIGNAL
};

static guint signals[LAST_SIGNAL] = { 0 };

enum {
	PROP_0,

        PROP_ID,
	PROP_REMOTE_CONNECTABLE,
        PROP_REMOTE_ADDRESS,
	PROP_SOCKET_PROPERTIES,
	PROP_STATE,
	PROP_SSL,
	PROP_TLS_CERTIFICATE,
	PROP_TLS_CERTIFICATE_ERRORS,
        PROP_TLS_PROTOCOL_VERSION,
        PROP_TLS_CIPHERSUITE_NAME,
        PROP_FORCE_HTTP_VERSION,
        PROP_CONTEXT,

	LAST_PROPERTY
};

static GParamSpec *properties[LAST_PROPERTY] = { NULL, };

static gboolean idle_timeout (gpointer conn);

/* Number of seconds after which we close a connection that hasn't yet
 * been used.
 */
#define SOUP_CONNECTION_UNUSED_TIMEOUT 3

#define HTTP2_INITIAL_WINDOW_SIZE (15 * 1024 * 1024) /* 15MB */
#define HTTP2_INITIAL_STREAM_WINDOW_SIZE (6 * 1024 * 1024) /* 6MB */

static void
soup_connection_init (SoupConnection *conn)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_init 1\n");
    SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

    priv->http_version = SOUP_HTTP_1_1;
    priv->force_http_version = G_MAXUINT8;
    priv->owner = g_thread_self ();
    priv->window_size = HTTP2_INITIAL_WINDOW_SIZE;
    priv->stream_window_size = HTTP2_INITIAL_STREAM_WINDOW_SIZE;
    // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_init 1\n");
}

static void
soup_connection_finalize (GObject *object)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_finalize 1\n");
    SoupConnectionPrivate *priv = soup_connection_get_instance_private (SOUP_CONNECTION (object));

    g_clear_pointer (&priv->proxy_uri, g_uri_unref);
    g_clear_pointer (&priv->socket_props, soup_socket_properties_unref);
    g_clear_pointer (&priv->io_data, soup_client_message_io_destroy);
    g_clear_object (&priv->remote_connectable);
    g_clear_object (&priv->remote_address);
    g_clear_object (&priv->proxy_msg);

    if (priv->cancellable) {
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_finalize 2\n");
        g_warning ("Disposing connection %p during connect", object);
        g_object_unref (priv->cancellable);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_finalize 2\n");
    }

    if (priv->connection) {
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_finalize 3\n");
        g_warning ("Disposing connection %p while still connected", object);
        g_io_stream_close (priv->connection, NULL, NULL);
        g_object_unref (priv->connection);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_finalize 3\n");
    }

    g_clear_object (&priv->iostream);
    g_clear_object (&priv->tls_client_cert);

    G_OBJECT_CLASS (soup_connection_parent_class)->finalize (object);
    // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_finalize 1\n");
}

static void
soup_connection_dispose (GObject *object)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_dispose 1\n");
    SoupConnection *conn = SOUP_CONNECTION (object);
    SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

    if (priv->idle_timeout_src) {
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_dispose 2\n");
        g_source_destroy (priv->idle_timeout_src);
        g_source_unref (priv->idle_timeout_src);
        priv->idle_timeout_src = NULL;
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_dispose 2\n");
    }

    G_OBJECT_CLASS (soup_connection_parent_class)->dispose (object);
    // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_dispose 1\n");
}

static void
soup_connection_set_property (GObject *object, guint prop_id,
			      const GValue *value, GParamSpec *pspec)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_property 1\n");
    SoupConnectionPrivate *priv = soup_connection_get_instance_private (SOUP_CONNECTION (object));

    switch (prop_id) {
    case PROP_REMOTE_CONNECTABLE:
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_property 2\n");
        priv->remote_connectable = g_value_dup_object (value);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_property 2\n");
        break;
    case PROP_SOCKET_PROPERTIES:
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_property 3\n");
        priv->socket_props = g_value_dup_boxed (value);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_property 3\n");
        break;
    case PROP_SSL:
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_property 4\n");
        priv->ssl = g_value_get_boolean (value);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_property 4\n");
        break;
    case PROP_ID:
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_property 5\n");
        priv->id = g_value_get_uint64 (value);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_property 5\n");
        break;
    case PROP_FORCE_HTTP_VERSION:
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_property 6\n");
        priv->force_http_version = g_value_get_uchar (value);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_property 6\n");
        break;
    case PROP_CONTEXT:
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_property 7\n");
        priv->idle_timeout_src = g_timeout_source_new (0);
        g_source_set_ready_time (priv->idle_timeout_src, -1);
        g_source_set_static_name (priv->idle_timeout_src, "Soup connection idle timeout");
        g_source_set_callback (priv->idle_timeout_src, idle_timeout, object, NULL);
        g_source_attach (priv->idle_timeout_src, g_value_get_pointer (value));
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_property 7\n");
        break;
    default:
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_property 8\n");
        G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_property 8\n");
        break;
    }
    // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_property 1\n");
}

static void
soup_connection_get_property (GObject *object, guint prop_id,
			      GValue *value, GParamSpec *pspec)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_property 1\n");
    SoupConnectionPrivate *priv = soup_connection_get_instance_private (SOUP_CONNECTION (object));

    switch (prop_id) {
    case PROP_REMOTE_CONNECTABLE:
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_property 2\n");
        g_value_set_object (value, priv->remote_connectable);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_property 2\n");
        break;
    case PROP_REMOTE_ADDRESS:
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_property 3\n");
        g_value_set_object (value, priv->remote_address);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_property 3\n");
        break;
    case PROP_SOCKET_PROPERTIES:
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_property 4\n");
        g_value_set_boxed (value, priv->socket_props);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_property 4\n");
        break;
    case PROP_STATE:
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_property 5\n");
        g_value_set_enum (value, g_atomic_int_get (&priv->state));
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_property 5\n");
        break;
    case PROP_SSL:
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_property 6\n");
        g_value_set_boolean (value, priv->ssl);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_property 6\n");
        break;
    case PROP_ID:
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_property 7\n");
        g_value_set_uint64 (value, priv->id);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_property 7\n");
        break;
    case PROP_TLS_CERTIFICATE:
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_property 8\n");
        g_value_set_object (value, soup_connection_get_tls_certificate (SOUP_CONNECTION (object)));
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_property 8\n");
        break;
    case PROP_TLS_CERTIFICATE_ERRORS:
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_property 9\n");
        g_value_set_flags (value, soup_connection_get_tls_certificate_errors (SOUP_CONNECTION (object)));
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_property 9\n");
        break;
    case PROP_TLS_PROTOCOL_VERSION:
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_property 10\n");
        g_value_set_enum (value, soup_connection_get_tls_protocol_version (SOUP_CONNECTION (object)));
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_property 10\n");
        break;
    case PROP_TLS_CIPHERSUITE_NAME:
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_property 11\n");
        g_value_set_string (value, soup_connection_get_tls_ciphersuite_name (SOUP_CONNECTION (object)));
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_property 11\n");
        break;
    case PROP_FORCE_HTTP_VERSION:
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_property 12\n");
        g_value_set_uchar (value, priv->force_http_version);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_property 12\n");
        break;
    default:
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_property 13\n");
        G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_property 13\n");
        break;
    }
    // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_property 1\n");
}

static void
soup_connection_class_init (SoupConnectionClass *connection_class)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_class_init 1\n");
    GObjectClass *object_class = G_OBJECT_CLASS (connection_class);

    /* virtual method override */
    object_class->dispose = soup_connection_dispose;
    object_class->finalize = soup_connection_finalize;
    object_class->set_property = soup_connection_set_property;
    object_class->get_property = soup_connection_get_property;

    /* signals */
    signals[EVENT] =
        g_signal_new ("event",
                      G_OBJECT_CLASS_TYPE (object_class),
                      G_SIGNAL_RUN_FIRST,
                      0,
                      NULL, NULL,
                      NULL,
                      G_TYPE_NONE, 2,
                      G_TYPE_SOCKET_CLIENT_EVENT,
                      G_TYPE_IO_STREAM);
    signals[ACCEPT_CERTIFICATE] =
        g_signal_new ("accept-certificate",
                      G_OBJECT_CLASS_TYPE (object_class),
                      G_SIGNAL_RUN_LAST,
                      0,
                      g_signal_accumulator_true_handled, NULL,
                      NULL,
                      G_TYPE_BOOLEAN, 2,
                      G_TYPE_TLS_CERTIFICATE,
                      G_TYPE_TLS_CERTIFICATE_FLAGS);
    signals[REQUEST_CERTIFICATE] =
            g_signal_new ("request-certificate",
                          G_OBJECT_CLASS_TYPE (object_class),
                          G_SIGNAL_RUN_LAST,
                          0,
                          g_signal_accumulator_true_handled, NULL,
                          NULL,
                          G_TYPE_BOOLEAN, 2,
                          G_TYPE_TLS_CLIENT_CONNECTION,
                          G_TYPE_TASK);
    signals[REQUEST_CERTIFICATE_PASSWORD] =
            g_signal_new ("request-certificate-password",
                          G_OBJECT_CLASS_TYPE (object_class),
                          G_SIGNAL_RUN_LAST,
                          0,
                          g_signal_accumulator_true_handled, NULL,
                          NULL,
                          G_TYPE_BOOLEAN, 2,
                          G_TYPE_TLS_PASSWORD,
                          G_TYPE_TASK);
    signals[DISCONNECTED] =
        g_signal_new ("disconnected",
                      G_OBJECT_CLASS_TYPE (object_class),
                      G_SIGNAL_RUN_FIRST,
                      0,
                      NULL, NULL,
                      NULL,
                      G_TYPE_NONE, 0);

    /* properties */
    properties[PROP_REMOTE_CONNECTABLE] =
            g_param_spec_object ("remote-connectable",
                                 "Remote Connectable",
                                 "Socket to connect to make outgoing connections on",
                                 G_TYPE_SOCKET_CONNECTABLE,
                                 G_PARAM_READWRITE | G_PARAM_CONSTRUCT_ONLY |
                                 G_PARAM_STATIC_STRINGS);
    properties[PROP_REMOTE_ADDRESS] =
            g_param_spec_object ("remote-address",
                                 "Remote Address",
                                 "Remote address of connection",
                                 G_TYPE_SOCKET_ADDRESS,
                                 G_PARAM_READABLE |
                                 G_PARAM_STATIC_STRINGS);
    properties[PROP_SOCKET_PROPERTIES] =
        g_param_spec_boxed ("socket-properties",
                            "Socket properties",
                            "Socket properties",
                            SOUP_TYPE_SOCKET_PROPERTIES,
                            G_PARAM_READWRITE | G_PARAM_CONSTRUCT_ONLY |
                            G_PARAM_STATIC_STRINGS);
    properties[PROP_STATE] =
        g_param_spec_enum ("state",
                           "Connection state",
                           "Current state of connection",
                           SOUP_TYPE_CONNECTION_STATE,
                           SOUP_CONNECTION_NEW,
                           G_PARAM_READABLE |
                           G_PARAM_STATIC_STRINGS);
    properties[PROP_SSL] =
        g_param_spec_boolean ("ssl",
                              "Connection uses TLS",
                              "Whether the connection should use TLS",
                              FALSE,G_PARAM_READWRITE |
                              G_PARAM_STATIC_STRINGS);
    properties[PROP_ID] =
        g_param_spec_uint64 ("id",
                             "Connection Identifier",
                             "Unique identifier for the connection",
                             0, G_MAXUINT64,
                             0, G_PARAM_READWRITE | G_PARAM_CONSTRUCT_ONLY |
                             G_PARAM_STATIC_STRINGS);
    properties[PROP_TLS_CERTIFICATE] =
        g_param_spec_object ("tls-certificate",
                             "TLS Certificate",
                             "The TLS certificate associated with the connection",
                             G_TYPE_TLS_CERTIFICATE,
                             G_PARAM_READABLE |
                             G_PARAM_STATIC_STRINGS);
    properties[PROP_TLS_CERTIFICATE_ERRORS] =
            g_param_spec_flags ("tls-certificate-errors",
                                "TLS Certificate Errors",
                                "The verification errors on the connections's TLS certificate",
                                G_TYPE_TLS_CERTIFICATE_FLAGS, 0,
                                G_PARAM_READABLE |
                                G_PARAM_STATIC_STRINGS);
    properties[PROP_TLS_PROTOCOL_VERSION] =
            g_param_spec_enum ("tls-protocol-version",
                               "TLS Protocol Version",
                               "TLS protocol version negotiated for this connection",
                               G_TYPE_TLS_PROTOCOL_VERSION,
                               G_TLS_PROTOCOL_VERSION_UNKNOWN,
                               G_PARAM_READABLE |
                               G_PARAM_STATIC_STRINGS);
    properties[PROP_TLS_CIPHERSUITE_NAME] =
            g_param_spec_string ("tls-ciphersuite-name",
                                 "TLS Ciphersuite Name",
                                 "Name of TLS ciphersuite negotiated for this connection",
                                 NULL,
                                 G_PARAM_READABLE |
                                 G_PARAM_STATIC_STRINGS);
    properties[PROP_FORCE_HTTP_VERSION] =
            g_param_spec_uchar ("force-http-version",
                                "Force HTTP version",
                                "Force connection to use a specific HTTP version",
                                0, G_MAXUINT8, G_MAXUINT8,
                                G_PARAM_READWRITE | G_PARAM_CONSTRUCT_ONLY |
                                G_PARAM_STATIC_STRINGS);
    properties[PROP_CONTEXT] =
            g_param_spec_pointer ("context",
                                  "Context",
                                  "The session main context",
                                  G_PARAM_WRITABLE | G_PARAM_CONSTRUCT_ONLY |
                                  G_PARAM_STATIC_STRINGS);

    g_object_class_install_properties (object_class, LAST_PROPERTY, properties);
    // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_class_init 1\n");
}

static void
soup_connection_event (SoupConnection      *conn,
		       GSocketClientEvent   event,
		       GIOStream           *connection)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_event 1\n");
    SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

    g_signal_emit (conn, signals[EVENT], 0,
                   event, connection ? connection : priv->connection);
    // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_event 1\n");
}

static gboolean
idle_timeout (gpointer conn)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter idle_timeout 1\n");
    soup_connection_disconnect (conn);
    return G_SOURCE_REMOVE;
    // fprintf(stderr, "[libsoup/soup-connection.c] exit idle_timeout 1\n");
}

static void
start_idle_timer (SoupConnection *conn)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter start_idle_timer 1\n");
    SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

    if (priv->socket_props->idle_timeout == 0) {
        fprintf(stderr, "\n");
        // fprintf(stderr, "\n");
        return;
    }

    if (g_source_get_ready_time (priv->idle_timeout_src) >= 0) {
        fprintf(stderr, "\n");
        // fprintf(stderr, "\n");
        return;
    }

    fprintf(stderr, "[libsoup/soup-connection.c] enter start_idle_timer 4\n");
    g_source_set_ready_time (priv->idle_timeout_src,
                             g_get_monotonic_time () + (guint64)priv->socket_props->idle_timeout * G_USEC_PER_SEC);
    // fprintf(stderr, "[libsoup/soup-connection.c] exit start_idle_timer 4\n");
    // fprintf(stderr, "[libsoup/soup-connection.c] exit start_idle_timer 1\n");
}

static void
soup_connection_set_state (SoupConnection     *conn,
                           SoupConnectionState state)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_state 1\n");
    SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

    if (g_atomic_int_get (&priv->state) == state) {
        fprintf(stderr, "\n");
        // fprintf(stderr, "\n");
        return;
    }

    fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_state 3\n");
    g_atomic_int_set (&priv->state, state);
    if (state == SOUP_CONNECTION_IDLE)
        start_idle_timer (conn);

    g_object_notify_by_pspec (G_OBJECT (conn), properties[PROP_STATE]);
    // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_state 3\n");
    // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_state 1\n");
}

static void
proxy_msg_got_body (SoupMessage    *msg,
                    SoupConnection *conn)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter proxy_msg_got_body 1\n");
    SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

    if (SOUP_STATUS_IS_SUCCESSFUL (soup_message_get_status (msg))) {
        fprintf(stderr, "[libsoup/soup-connection.c] enter proxy_msg_got_body 2\n");
        soup_connection_event (conn, G_SOCKET_CLIENT_PROXY_NEGOTIATED, NULL);

        /* We're now effectively no longer proxying */
        g_clear_pointer (&priv->proxy_uri, g_uri_unref);
        g_signal_handlers_disconnect_by_func (priv->proxy_msg, proxy_msg_got_body, conn);
        g_clear_object (&priv->proxy_msg);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit proxy_msg_got_body 2\n");
    }
    // fprintf(stderr, "[libsoup/soup-connection.c] exit proxy_msg_got_body 1\n");
}

static void
clear_proxy_msg (SoupConnection *conn)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter clear_proxy_msg 1\n");
    SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

    if (!priv->proxy_msg) {
        fprintf(stderr, "\n");
        // fprintf(stderr, "\n");
        return;
    }

    fprintf(stderr, "[libsoup/soup-connection.c] enter clear_proxy_msg 3\n");
    g_signal_handlers_disconnect_by_func (priv->proxy_msg, proxy_msg_got_body, conn);
    g_clear_object (&priv->proxy_msg);
    // fprintf(stderr, "[libsoup/soup-connection.c] exit clear_proxy_msg 3\n");
    // fprintf(stderr, "[libsoup/soup-connection.c] exit clear_proxy_msg 1\n");
}

static void
set_proxy_msg (SoupConnection *conn,
               SoupMessage    *msg)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter set_proxy_msg 1\n");
    SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

    g_assert (priv->http_version != SOUP_HTTP_2_0);

    clear_proxy_msg (conn);
    priv->proxy_msg = g_object_ref (msg);
    g_signal_connect_object (msg, "got-body",
                             G_CALLBACK (proxy_msg_got_body),
                             conn, 0);

    soup_connection_event (conn, G_SOCKET_CLIENT_PROXY_NEGOTIATING, NULL);
    // fprintf(stderr, "[libsoup/soup-connection.c] exit set_proxy_msg 1\n");
}

static void
soup_connection_set_connection (SoupConnection *conn,
				GIOStream      *connection)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_connection 1\n");
    SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

    g_clear_pointer (&priv->io_data, soup_client_message_io_destroy);

    g_clear_object (&priv->connection);
    priv->connection = connection;
    g_clear_object (&priv->iostream);
    priv->iostream = soup_io_stream_new (G_IO_STREAM (priv->connection), FALSE);
    // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_connection 1\n");
}

static void
soup_connection_create_io_data (SoupConnection *conn)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_create_io_data 1\n");
    SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

    g_assert (!priv->io_data);
    switch (priv->http_version) {
    case SOUP_HTTP_1_0:
    case SOUP_HTTP_1_1:
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_create_io_data 2\n");
        priv->io_data = soup_client_message_io_http1_new (conn);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_create_io_data 2\n");
        break;
    case SOUP_HTTP_2_0:
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_create_io_data 3\n");
        priv->io_data = soup_client_message_io_http2_new (conn);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_create_io_data 3\n");
        break;
    }
    // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_create_io_data 1\n");
}

static void
re_emit_socket_event (GSocketClient       *client,
		      GSocketClientEvent   event,
		      GSocketConnectable  *connectable,
		      GIOStream           *connection,
		      SoupConnection      *conn)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter re_emit_socket_event 1\n");
    /* We handle COMPLETE ourselves */
    if (event == G_SOCKET_CLIENT_COMPLETE) {
        fprintf(stderr, "\n");
        // fprintf(stderr, "\n");
        return;
    }

    fprintf(stderr, "[libsoup/soup-connection.c] enter re_emit_socket_event 3\n");
    soup_connection_event (conn, event, connection);
    // fprintf(stderr, "[libsoup/soup-connection.c] exit re_emit_socket_event 3\n");
    // fprintf(stderr, "[libsoup/soup-connection.c] exit re_emit_socket_event 1\n");
}

static GSocketClient *
new_socket_client (SoupConnection *conn)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter new_socket_client 1\n");
    SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);
    GSocketClient *client;
    SoupSocketProperties *props = priv->socket_props;

    client = g_socket_client_new ();
    g_signal_connect_object (client, "event",
                             G_CALLBACK (re_emit_socket_event),
                             conn, 0);

    if (!props->proxy_use_default && !props->proxy_resolver) {
        fprintf(stderr, "[libsoup/soup-connection.c] enter new_socket_client 2\n");
        g_socket_client_set_enable_proxy (client, FALSE);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit new_socket_client 2\n");
    } else {
        fprintf(stderr, "[libsoup/soup-connection.c] enter new_socket_client 3\n");
        if (props->proxy_resolver)
            g_socket_client_set_proxy_resolver (client, props->proxy_resolver);
        g_socket_client_add_application_proxy (client, "http");
        // fprintf(stderr, "[libsoup/soup-connection.c] exit new_socket_client 3\n");
    }

    if (props->io_timeout) {
        fprintf(stderr, "[libsoup/soup-connection.c] enter new_socket_client 4\n");
        g_socket_client_set_timeout (client, props->io_timeout);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit new_socket_client 4\n");
    }
    if (props->local_addr) {
        fprintf(stderr, "[libsoup/soup-connection.c] enter new_socket_client 5\n");
        g_socket_client_set_local_address (client, G_SOCKET_ADDRESS (props->local_addr));
        // fprintf(stderr, "[libsoup/soup-connection.c] exit new_socket_client 5\n");
    }

    return client;
    // fprintf(stderr, "[libsoup/soup-connection.c] exit new_socket_client 1\n");
}

static gboolean
tls_connection_accept_certificate (SoupConnection      *conn,
                                   GTlsCertificate     *tls_certificate,
                                   GTlsCertificateFlags tls_errors)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter tls_connection_accept_certificate 1\n");
    gboolean accept = FALSE;

    g_signal_emit (conn, signals[ACCEPT_CERTIFICATE], 0,
                   tls_certificate, tls_errors, &accept);
    return accept;
    // fprintf(stderr, "[libsoup/soup-connection.c] exit tls_connection_accept_certificate 1\n");
}

static void
tls_connection_peer_certificate_changed (SoupConnection *conn)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter tls_connection_peer_certificate_changed 1\n");
    g_object_notify_by_pspec (G_OBJECT (conn), properties[PROP_TLS_CERTIFICATE]);
    // fprintf(stderr, "[libsoup/soup-connection.c] exit tls_connection_peer_certificate_changed 1\n");
}

static void
tls_connection_protocol_version_changed (SoupConnection *conn)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter tls_connection_protocol_version_changed 1\n");
    g_object_notify_by_pspec (G_OBJECT (conn), properties[PROP_TLS_PROTOCOL_VERSION]);
    // fprintf(stderr, "[libsoup/soup-connection.c] exit tls_connection_protocol_version_changed 1\n");
}

static void
tls_connection_ciphersuite_name_changed (SoupConnection *conn)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter tls_connection_ciphersuite_name_changed 1\n");
    g_object_notify_by_pspec (G_OBJECT (conn), properties[PROP_TLS_CIPHERSUITE_NAME]);
    // fprintf(stderr, "[libsoup/soup-connection.c] exit tls_connection_ciphersuite_name_changed 1\n");
}

static gboolean
is_not_using_http_proxy (SoupConnection *conn)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter is_not_using_http_proxy 1\n");
    SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

    if (!priv->remote_address || !G_IS_PROXY_ADDRESS (priv->remote_address)) {
        fprintf(stderr, "[libsoup/soup-connection.c] enter is_not_using_http_proxy 2\n");
        return TRUE;
        // fprintf(stderr, "[libsoup/soup-connection.c] exit is_not_using_http_proxy 2\n");
    }

    return g_strcmp0 (g_proxy_address_get_protocol (G_PROXY_ADDRESS (priv->remote_address)), "http") != 0;
    // fprintf(stderr, "[libsoup/soup-connection.c] exit is_not_using_http_proxy 1\n");
}

static GTlsClientConnection *
new_tls_connection (SoupConnection    *conn,
                    GSocketConnection *connection,
                    GError           **error)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter new_tls_connection 1\n");
    SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);
    GTlsClientConnection *tls_connection;
    GTlsInteraction *tls_interaction;
    GPtrArray *advertised_protocols = g_ptr_array_sized_new (4);

    // https://www.iana.org/assignments/tls-extensiontype-values/tls-extensiontype-values.xhtml
    switch (priv->force_http_version) {
    case SOUP_HTTP_1_0:
        fprintf(stderr, "[libsoup/soup-connection.c] enter new_tls_connection 2\n");
        g_ptr_array_add (advertised_protocols, "http/1.0");
        // fprintf(stderr, "[libsoup/soup-connection.c] exit new_tls_connection 2\n");
        break;
    case SOUP_HTTP_1_1:
        fprintf(stderr, "[libsoup/soup-connection.c] enter new_tls_connection 3\n");
        g_ptr_array_add (advertised_protocols, "http/1.1");
        // fprintf(stderr, "[libsoup/soup-connection.c] exit new_tls_connection 3\n");
        break;
    case SOUP_HTTP_2_0:
        fprintf(stderr, "[libsoup/soup-connection.c] enter new_tls_connection 4\n");
        g_ptr_array_add (advertised_protocols, "h2");
        // fprintf(stderr, "[libsoup/soup-connection.c] exit new_tls_connection 4\n");
        break;
    default:
        fprintf(stderr, "[libsoup/soup-connection.c] enter new_tls_connection 5\n");
        if (is_not_using_http_proxy (conn))
            g_ptr_array_add (advertised_protocols, "h2");
        g_ptr_array_add (advertised_protocols, "http/1.1");
        g_ptr_array_add (advertised_protocols, "http/1.0");
        // fprintf(stderr, "[libsoup/soup-connection.c] exit new_tls_connection 5\n");
        break;
    }
    g_ptr_array_add (advertised_protocols, NULL);

    tls_interaction = priv->socket_props->tls_interaction ? g_object_ref (priv->socket_props->tls_interaction) : soup_tls_interaction_new (conn);
    tls_connection = g_initable_new (g_tls_backend_get_client_connection_type (g_tls_backend_get_default ()),
                                     priv->cancellable, error,
                                     "base-io-stream", connection,
                                     "server-identity", priv->remote_connectable,
                                     "require-close-notify", FALSE,
                                     "interaction", tls_interaction,
                                     "advertised-protocols", advertised_protocols->pdata,
                                     NULL);

    g_object_unref (tls_interaction);
    g_ptr_array_unref (advertised_protocols);

    if (!tls_connection) {
        fprintf(stderr, "[libsoup/soup-connection.c] enter new_tls_connection 6\n");
        return NULL;
        // fprintf(stderr, "[libsoup/soup-connection.c] exit new_tls_connection 6\n");
    }

    if (!priv->socket_props->tlsdb_use_default) {
        fprintf(stderr, "[libsoup/soup-connection.c] enter new_tls_connection 7\n");
        g_tls_connection_set_database (G_TLS_CONNECTION (tls_connection), priv->socket_props->tlsdb);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit new_tls_connection 7\n");
    }

    g_signal_connect_object (tls_connection, "accept-certificate",
                             G_CALLBACK (tls_connection_accept_certificate),
                             conn, G_CONNECT_SWAPPED);
    g_signal_connect_object (tls_connection, "notify::peer-certificate",
                             G_CALLBACK (tls_connection_peer_certificate_changed),
                             conn, G_CONNECT_SWAPPED);
    g_signal_connect_object (tls_connection, "notify::protocol-version",
                             G_CALLBACK (tls_connection_protocol_version_changed),
                             conn, G_CONNECT_SWAPPED);
    g_signal_connect_object (tls_connection, "notify::ciphersuite-name",
                             G_CALLBACK (tls_connection_ciphersuite_name_changed),
                             conn, G_CONNECT_SWAPPED);

    return tls_connection;
    // fprintf(stderr, "[libsoup/soup-connection.c] exit new_tls_connection 1\n");
}

static gboolean
soup_connection_connected (SoupConnection    *conn,
                           GSocketConnection *connection,
                           GError           **error)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_connected 1\n");
    SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);
    GSocket *socket;

    socket = g_socket_connection_get_socket (connection);
    g_socket_set_timeout (socket, priv->socket_props->io_timeout);
    g_socket_set_option (socket, IPPROTO_TCP, TCP_NODELAY, TRUE, NULL);

    g_clear_object (&priv->remote_address);
    priv->remote_address = g_socket_get_remote_address (socket, NULL);
    g_object_notify_by_pspec (G_OBJECT (conn), properties[PROP_REMOTE_ADDRESS]);

    if (priv->remote_address && G_IS_PROXY_ADDRESS (priv->remote_address)) {
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_connected 2\n");
        GProxyAddress *paddr = G_PROXY_ADDRESS (priv->remote_address);

        if (strcmp (g_proxy_address_get_protocol (paddr), "http") == 0) {
            fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_connected 3\n");
            GError *error = NULL;
            priv->proxy_uri = g_uri_parse (g_proxy_address_get_uri (paddr), SOUP_HTTP_URI_FLAGS, &error);
            if (error) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_connected 4\n");
                g_warning ("Failed to parse proxy URI %s: %s", g_proxy_address_get_uri (paddr), error->message);
                g_error_free (error);
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_connected 4\n");
            }
            // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_connected 3\n");
        }
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_connected 2\n");
    }

    if (priv->ssl && !priv->proxy_uri) {
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_connected 5\n");
        GTlsClientConnection *tls_connection;

        tls_connection = new_tls_connection (conn, connection, error);
        if (!tls_connection) {
            fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_connected 6\n");
            return FALSE;
            // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_connected 6\n");
        }

        g_object_unref (connection);
        soup_connection_set_connection (conn, G_IO_STREAM (tls_connection));
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_connected 5\n");
    } else {
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_connected 7\n");
        soup_connection_set_connection (conn, G_IO_STREAM (connection));
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_connected 7\n");
    }

    return TRUE;
    // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_connected 1\n");
}

static void
soup_connection_complete (SoupConnection *conn)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_complete 1\n");
    SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

    g_clear_object (&priv->cancellable);

    if (G_IS_TLS_CONNECTION (priv->connection)) {
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_complete 2\n");
        const char *protocol = g_tls_connection_get_negotiated_protocol (G_TLS_CONNECTION (priv->connection));
        if (g_strcmp0 (protocol, "h2") == 0)
            priv->http_version = SOUP_HTTP_2_0;
        else if (g_strcmp0 (protocol, "http/1.0") == 0)
            priv->http_version = SOUP_HTTP_1_0;
        else if (g_strcmp0 (protocol, "http/1.1") == 0)
            priv->http_version = SOUP_HTTP_1_1;
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_complete 2\n");
    }

    if (!priv->ssl || !priv->proxy_uri) {
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_complete 3\n");
        soup_connection_event (conn,
                               G_SOCKET_CLIENT_COMPLETE,
                               NULL);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_complete 3\n");
    }

    fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_complete 4\n");
    soup_connection_create_io_data (conn);

    soup_connection_set_state (conn, SOUP_CONNECTION_IN_USE);
    priv->unused_timeout = time (NULL) + SOUP_CONNECTION_UNUSED_TIMEOUT;
    start_idle_timer (conn);
    // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_complete 4\n");
    // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_complete 1\n");
}

static void
handshake_ready_cb (GTlsConnection *tls_connection,
                    GAsyncResult   *result,
                    GTask          *task)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter handshake_ready_cb 1\n");
    SoupConnection *conn = g_task_get_source_object (task);
    SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);
    GError *error = NULL;

    if (g_tls_connection_handshake_finish (tls_connection, result, &error)) {
        fprintf(stderr, "[libsoup/soup-connection.c] enter handshake_ready_cb 2\n");
        soup_connection_event (conn, G_SOCKET_CLIENT_TLS_HANDSHAKED, NULL);
        soup_connection_complete (conn);
        g_task_return_boolean (task, TRUE);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit handshake_ready_cb 2\n");
    } else {
        fprintf(stderr, "[libsoup/soup-connection.c] enter handshake_ready_cb 3\n");
        g_clear_object (&priv->cancellable);
        g_task_return_error (task, error);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit handshake_ready_cb 3\n");
    }
    g_object_unref (task);
    // fprintf(stderr, "[libsoup/soup-connection.c] exit handshake_ready_cb 1\n");
}

static void
connect_async_ready_cb (GSocketClient *client,
                        GAsyncResult  *result,
                        GTask         *task)
{
    fprintf(stderr, "[libsoup/soup-connection.c] enter connect_async_ready_cb 1\n");
    SoupConnection *conn = g_task_get_source_object (task);
    SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);
    GSocketConnection *connection;
    GError *error = NULL;

    connection = g_socket_client_connect_finish (client, result, &error);
    if (!connection) {
        fprintf(stderr, "[libsoup/soup-connection.c] enter connect_async_ready_cb 2\n");
        g_clear_object (&priv->cancellable);
        g_task_return_error (task, error);
        g_object_unref (task);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit connect_async_ready_cb 2\n");
        return;
    }

    if (!soup_connection_connected (conn, connection, &error)) {
        fprintf(stderr, "[libsoup/soup-connection.c] enter connect_async_ready_cb 3\n");
        g_clear_object (&priv->cancellable);
        g_task_return_error (task, error);
        g_object_unref (task);
        g_object_unref (connection);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit connect_async_ready_cb 3\n");
        return;
    }

    if (G_IS_TLS_CONNECTION (priv->connection)) {
        fprintf(stderr, "[libsoup/soup-connection.c] enter connect_async_ready_cb 4\n");
        soup_connection_event (conn, G_SOCKET_CLIENT_TLS_HANDSHAKING, NULL);

        g_tls_connection_handshake_async (G_TLS_CONNECTION (priv->connection),
                                          g_task_get_priority (task),
                                          priv->cancellable,
                                          (GAsyncReadyCallback)handshake_ready_cb,
                                          task);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit connect_async_ready_cb 4\n");
        return;
    }

    fprintf(stderr, "[libsoup/soup-connection.c] enter connect_async_ready_cb 5\n");
    soup_connection_complete (conn);
    g_task_return_boolean (task, TRUE);
    g_object_unref (task);
    // fprintf(stderr, "[libsoup/soup-connection.c] exit connect_async_ready_cb 5\n");
    // fprintf(stderr, "[libsoup/soup-connection.c] exit connect_async_ready_cb 1\n");
}
void
soup_connection_connect_async (SoupConnection      *conn,
                               int                  io_priority,
                               GCancellable        *cancellable,
                               GAsyncReadyCallback  callback,
                               gpointer             user_data)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_connect_async 1\n");
        SoupConnectionPrivate *priv;
        GTask *task;
        GSocketClient *client;

        g_return_if_fail (SOUP_IS_CONNECTION (conn));

        priv = soup_connection_get_instance_private (conn);

        soup_connection_set_state (conn, SOUP_CONNECTION_CONNECTING);

        priv->cancellable = cancellable ? g_object_ref (cancellable) : g_cancellable_new ();
        task = g_task_new (conn, priv->cancellable, callback, user_data);
        g_task_set_source_tag (task, soup_connection_connect_async);
        g_task_set_priority (task, io_priority);

        client = new_socket_client (conn);
        g_socket_client_connect_async (client,
                                       priv->remote_connectable,
                                       priv->cancellable,
                                       (GAsyncReadyCallback)connect_async_ready_cb,
                                       task);
        g_object_unref (client);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_connect_async 1\n");
}

gboolean
soup_connection_connect_finish (SoupConnection  *conn,
                                GAsyncResult    *result,
                                GError         **error)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_connect_finish 1\n");
        return g_task_propagate_boolean (G_TASK (result), error);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_connect_finish 1\n");
}

gboolean
soup_connection_connect (SoupConnection  *conn,
			 GCancellable    *cancellable,
			 GError         **error)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_connect 1\n");
        SoupConnectionPrivate *priv;
        GSocketClient *client;
        GSocketConnection *connection;

        g_return_val_if_fail (SOUP_IS_CONNECTION (conn), FALSE);

        priv = soup_connection_get_instance_private (conn);

        soup_connection_set_state (conn, SOUP_CONNECTION_CONNECTING);

        priv->cancellable = cancellable ? g_object_ref (cancellable) : g_cancellable_new ();

        client = new_socket_client (conn);
        connection = g_socket_client_connect (client,
                                              priv->remote_connectable,
                                              priv->cancellable,
                                              error);
        g_object_unref (client);

        if (!connection) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_connect 2\n");
                g_clear_object (&priv->cancellable);
                return FALSE;
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_connect 2\n");
        }

        if (!soup_connection_connected (conn, connection, error)) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_connect 3\n");
                g_object_unref (connection);
                g_clear_object (&priv->cancellable);
                return FALSE;
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_connect 3\n");
        }

        if (G_IS_TLS_CONNECTION (priv->connection)) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_connect 4\n");
                soup_connection_event (conn, G_SOCKET_CLIENT_TLS_HANDSHAKING, NULL);
                if (!g_tls_connection_handshake (G_TLS_CONNECTION (priv->connection),
                                                 priv->cancellable, error)) {
                        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_connect 5\n");
                        g_clear_object (&priv->cancellable);
                        return FALSE;
                        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_connect 5\n");
                }
                soup_connection_event (conn, G_SOCKET_CLIENT_TLS_HANDSHAKED, NULL);
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_connect 4\n");
        }

        soup_connection_complete (conn);

        return TRUE;
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_connect 1\n");
}

gboolean
soup_connection_is_tunnelled (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_is_tunnelled 1\n");
	SoupConnectionPrivate *priv;

	g_return_val_if_fail (SOUP_IS_CONNECTION (conn), FALSE);
	priv = soup_connection_get_instance_private (conn);

	return priv->ssl && priv->proxy_uri != NULL;
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_is_tunnelled 1\n");
}

static void
tunnel_handshake_ready_cb (GTlsConnection *tls_connection,
                           GAsyncResult   *result,
                           GTask          *task)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter tunnel_handshake_ready_cb 1\n");
        SoupConnection *conn = g_task_get_source_object (task);
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);
        GError *error = NULL;

        g_clear_object (&priv->cancellable);

        if (g_tls_connection_handshake_finish (tls_connection, result, &error)) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter tunnel_handshake_ready_cb 2\n");
                soup_connection_event (conn, G_SOCKET_CLIENT_TLS_HANDSHAKED, NULL);
                soup_connection_event (conn, G_SOCKET_CLIENT_COMPLETE, NULL);

                g_assert (!priv->io_data);
                priv->io_data = soup_client_message_io_http1_new (conn);

                g_task_return_boolean (task, TRUE);
                // fprintf(stderr, "[libsoup/soup-connection.c] exit tunnel_handshake_ready_cb 2\n");
        } else {
                fprintf(stderr, "[libsoup/soup-connection.c] enter tunnel_handshake_ready_cb 3\n");
                g_task_return_error (task, error);
                // fprintf(stderr, "[libsoup/soup-connection.c] exit tunnel_handshake_ready_cb 3\n");
        }
        g_object_unref (task);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit tunnel_handshake_ready_cb 1\n");
}

void
soup_connection_tunnel_handshake_async (SoupConnection     *conn,
                                        int                 io_priority,
                                        GCancellable       *cancellable,
                                        GAsyncReadyCallback callback,
                                        gpointer            user_data)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_tunnel_handshake_async 1\n");
        SoupConnectionPrivate *priv;
        GTask *task;
        GTlsClientConnection *tls_connection;
        GError *error = NULL;

        g_return_if_fail (SOUP_IS_CONNECTION (conn));

        priv = soup_connection_get_instance_private (conn);
        g_return_if_fail (G_IS_SOCKET_CONNECTION (priv->connection));
        g_return_if_fail (priv->cancellable == NULL);

        priv->cancellable = cancellable ? g_object_ref (cancellable) : g_cancellable_new ();
        task = g_task_new (conn, priv->cancellable, callback, user_data);
        g_task_set_source_tag (task, soup_connection_tunnel_handshake_async);
        g_task_set_priority (task, io_priority);

        tls_connection = new_tls_connection (conn, G_SOCKET_CONNECTION (priv->connection), &error);
        if (!tls_connection) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_tunnel_handshake_async 2\n");
		g_clear_object (&priv->cancellable);
                g_task_return_error (task, error);
                g_object_unref (task);
                return;
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_tunnel_handshake_async 2\n");
        }

        soup_connection_set_connection (conn, G_IO_STREAM (tls_connection));
        soup_connection_event (conn, G_SOCKET_CLIENT_TLS_HANDSHAKING, NULL);
        g_tls_connection_handshake_async (G_TLS_CONNECTION (priv->connection),
                                          g_task_get_priority (task),
                                          priv->cancellable,
                                          (GAsyncReadyCallback)tunnel_handshake_ready_cb,
                                          task);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_tunnel_handshake_async 1\n");
}

gboolean
soup_connection_tunnel_handshake_finish (SoupConnection *conn,
                                         GAsyncResult   *result,
                                         GError        **error)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_tunnel_handshake_finish 1\n");
        g_return_val_if_fail (SOUP_IS_CONNECTION (conn), FALSE);

        return g_task_propagate_boolean (G_TASK (result), error);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_tunnel_handshake_finish 1\n");
}

gboolean
soup_connection_tunnel_handshake (SoupConnection *conn,
                                  GCancellable   *cancellable,
                                  GError        **error)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_tunnel_handshake 1\n");
        SoupConnectionPrivate *priv;
        GTlsClientConnection *tls_connection;

        g_return_val_if_fail (SOUP_IS_CONNECTION (conn), FALSE);

        priv = soup_connection_get_instance_private (conn);
        g_return_val_if_fail (G_IS_SOCKET_CONNECTION (priv->connection), FALSE);
        g_return_val_if_fail (priv->cancellable == NULL, FALSE);

        tls_connection = new_tls_connection (conn, G_SOCKET_CONNECTION (priv->connection), error);
        if (!tls_connection) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_tunnel_handshake 2\n");
                return FALSE;
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_tunnel_handshake 2\n");
        }

        soup_connection_set_connection (conn, G_IO_STREAM (tls_connection));
        soup_connection_event (conn, G_SOCKET_CLIENT_TLS_HANDSHAKING, NULL);

        priv->cancellable = cancellable ? g_object_ref (cancellable) : g_cancellable_new ();
        if (!g_tls_connection_handshake (G_TLS_CONNECTION (priv->connection),
                                         priv->cancellable, error)) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_tunnel_handshake 3\n");
                g_clear_object (&priv->cancellable);
                return FALSE;
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_tunnel_handshake 3\n");
        }
        g_clear_object (&priv->cancellable);

        soup_connection_event (conn, G_SOCKET_CLIENT_TLS_HANDSHAKED, NULL);
        soup_connection_event (conn, G_SOCKET_CLIENT_COMPLETE, NULL);

        g_assert (!priv->io_data);
        priv->io_data = soup_client_message_io_http1_new (conn);

        return TRUE;
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_tunnel_handshake 1\n");
}

static void
soup_connection_disconnected (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_disconnected 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

        if (priv->connection) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_disconnected 2\n");
                GIOStream *connection;

                connection = priv->connection;
                priv->connection = NULL;

                g_io_stream_close (connection, NULL, NULL);
                g_signal_handlers_disconnect_by_data (connection, conn);
                g_object_unref (connection);
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_disconnected 2\n");
        }

        g_signal_emit (conn, signals[DISCONNECTED], 0);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_disconnected 1\n");
}

static void
client_message_io_closed_cb (SoupConnection *conn,
                             GAsyncResult   *result)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter client_message_io_closed_cb 1\n");
        g_task_propagate_boolean (G_TASK (result), NULL);
        soup_connection_disconnected (conn);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit client_message_io_closed_cb 1\n");
}

/**
 * soup_connection_disconnect:
 * @conn: a connection
 *
 * Disconnects @conn's socket and emits a [signal@Socket::disconnected] signal.
 *
 * After calling this, @conn will be essentially useless.
 **/
void
soup_connection_disconnect (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_disconnect 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

        if (g_atomic_int_get (&priv->state) == SOUP_CONNECTION_DISCONNECTED) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_disconnect 2\n");
                return;
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_disconnect 2\n");
        }

        soup_connection_set_state (conn, SOUP_CONNECTION_DISCONNECTED);

        if (priv->cancellable) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_disconnect 3\n");
                g_cancellable_cancel (priv->cancellable);
                priv->cancellable = NULL;
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_disconnect 3\n");
        }

        if (priv->io_data &&
            soup_client_message_io_close_async (priv->io_data, conn, (GAsyncReadyCallback)client_message_io_closed_cb)) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_disconnect 4\n");
                return;
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_disconnect 4\n");
        }

        soup_connection_disconnected (conn);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_disconnect 1\n");
}

GSocket *
soup_connection_get_socket (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_socket 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);
        GSocketConnection *connection = NULL;

        g_return_val_if_fail (SOUP_IS_CONNECTION (conn), NULL);

        if (G_IS_TLS_CONNECTION (priv->connection)) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_socket 2\n");
                g_object_get (priv->connection, "base-io-stream", &connection, NULL);
                g_object_unref (connection);
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_socket 2\n");
        } else if (G_IS_SOCKET_CONNECTION (priv->connection)) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_socket 3\n");
                connection = G_SOCKET_CONNECTION (priv->connection);
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_socket 3\n");
        }

        return connection ? g_socket_connection_get_socket (connection) : NULL;
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_socket 1\n");
}

GIOStream *
soup_connection_get_iostream (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_iostream 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

        g_return_val_if_fail (SOUP_IS_CONNECTION (conn), NULL);

        return priv->iostream;
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_iostream 1\n");
}

GIOStream *
soup_connection_steal_iostream (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_steal_iostream 1\n");
        SoupConnectionPrivate *priv;
        GSocket *socket;
        GIOStream *iostream;

        g_return_val_if_fail (SOUP_IS_CONNECTION (conn), NULL);

        socket = soup_connection_get_socket (conn);
        g_socket_set_timeout (socket, 0);

        priv = soup_connection_get_instance_private (conn);
        iostream = priv->iostream;
        priv->iostream = NULL;

        g_object_set_data_full (G_OBJECT (iostream), "GSocket",
                                g_object_ref (socket), g_object_unref);
        g_clear_object (&priv->connection);

        if (priv->io_data)
                soup_client_message_io_stolen (priv->io_data);

        return iostream;
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_steal_iostream 1\n");
}

GUri *
soup_connection_get_proxy_uri (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_proxy_uri 1\n");
	SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

	g_return_val_if_fail (SOUP_IS_CONNECTION (conn), NULL);

	return priv->proxy_uri;
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_proxy_uri 1\n");
}

gboolean
soup_connection_is_via_proxy (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_is_via_proxy 1\n");
	SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

	g_return_val_if_fail (SOUP_IS_CONNECTION (conn), FALSE);

	return priv->proxy_uri != NULL;
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_is_via_proxy 1\n");
}

gboolean
soup_connection_is_idle_open (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_is_idle_open 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

        if (g_atomic_int_get (&priv->state) != SOUP_CONNECTION_IDLE) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_is_idle_open 2\n");
                return FALSE;
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_is_idle_open 2\n");
        }

	if (!g_socket_is_connected (soup_connection_get_socket (conn))) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_is_idle_open 3\n");
		return FALSE;
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_is_idle_open 3\n");
        }

	if (priv->unused_timeout && priv->unused_timeout < time (NULL)) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_is_idle_open 4\n");
		return FALSE;
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_is_idle_open 4\n");
        }

        return soup_client_message_io_is_open (priv->io_data);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_is_idle_open 1\n");
}

SoupConnectionState
soup_connection_get_state (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_state 1\n");
	SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

	return g_atomic_int_get (&priv->state);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_state 1\n");
}

void
soup_connection_set_in_use (SoupConnection *conn,
                            gboolean        in_use)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_in_use 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

        g_assert (in_use || g_atomic_int_get (&priv->in_use) > 0);

        if (in_use) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_in_use 2\n");
                g_atomic_int_inc (&priv->in_use);
                if (g_atomic_int_compare_and_exchange (&priv->state, SOUP_CONNECTION_IDLE, SOUP_CONNECTION_IN_USE)) {
                        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_in_use 3\n");
                        priv->owner = g_thread_self ();
                        soup_client_message_io_owner_changed (priv->io_data);
                        g_object_notify_by_pspec (G_OBJECT (conn), properties[PROP_STATE]);
                        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_in_use 3\n");
                }

                return;
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_in_use 2\n");
        }

        g_assert (g_atomic_int_get (&priv->state) != SOUP_CONNECTION_IDLE);

        if (g_atomic_int_dec_and_test (&priv->in_use)) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_in_use 4\n");
                clear_proxy_msg (conn);

                if (soup_connection_get_state (conn) == SOUP_CONNECTION_DISCONNECTED) {
                        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_in_use 5\n");
                        return;
                        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_in_use 5\n");
                }

                if (soup_connection_is_reusable (conn)) {
                        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_in_use 6\n");
                        soup_connection_set_state (conn, SOUP_CONNECTION_IDLE);
                        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_in_use 6\n");
                } else {
                        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_in_use 7\n");
                        soup_connection_disconnect (conn);
                        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_in_use 7\n");
                }
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_in_use 4\n");
        }
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_in_use 1\n");
}

SoupClientMessageIO *
soup_connection_setup_message_io (SoupConnection *conn,
                                  SoupMessage    *msg)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_setup_message_io 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

        g_assert (g_atomic_int_get (&priv->state) == SOUP_CONNECTION_IN_USE);

        priv->unused_timeout = 0;
        g_source_set_ready_time (priv->idle_timeout_src, -1);

        if (priv->proxy_uri && soup_message_get_method (msg) == SOUP_METHOD_CONNECT) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_setup_message_io 2\n");
                set_proxy_msg (conn, msg);
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_setup_message_io 2\n");
        }

        if (!soup_client_message_io_is_reusable (priv->io_data))
                g_warn_if_reached ();

        return priv->io_data;
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_setup_message_io 1\n");
}

GTlsCertificate *
soup_connection_get_tls_certificate (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_tls_certificate 1\n");
	SoupConnectionPrivate *priv;

	g_return_val_if_fail (SOUP_IS_CONNECTION (conn), NULL);

	priv = soup_connection_get_instance_private (conn);

	if (!G_IS_TLS_CONNECTION (priv->connection)) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_tls_certificate 2\n");
		return NULL;
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_tls_certificate 2\n");
        }

	return g_tls_connection_get_peer_certificate (G_TLS_CONNECTION (priv->connection));
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_tls_certificate 1\n");
}

GTlsCertificateFlags
soup_connection_get_tls_certificate_errors (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_tls_certificate_errors 1\n");
	SoupConnectionPrivate *priv;

	g_return_val_if_fail (SOUP_IS_CONNECTION (conn), 0);

	priv = soup_connection_get_instance_private (conn);

	if (!G_IS_TLS_CONNECTION (priv->connection)) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_tls_certificate_errors 2\n");
		return 0;
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_tls_certificate_errors 2\n");
        }

	return g_tls_connection_get_peer_certificate_errors (G_TLS_CONNECTION (priv->connection));
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_tls_certificate_errors 1\n");
}

GTlsProtocolVersion
soup_connection_get_tls_protocol_version (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_tls_protocol_version 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

        if (!G_IS_TLS_CONNECTION (priv->connection)) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_tls_protocol_version 2\n");
                return G_TLS_PROTOCOL_VERSION_UNKNOWN;
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_tls_protocol_version 2\n");
        }

        return g_tls_connection_get_protocol_version (G_TLS_CONNECTION (priv->connection));
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_tls_protocol_version 1\n");
}

char *
soup_connection_get_tls_ciphersuite_name (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_tls_ciphersuite_name 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

        if (!G_IS_TLS_CONNECTION (priv->connection)) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_tls_ciphersuite_name 2\n");
                return NULL;
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_tls_ciphersuite_name 2\n");
        }

        return g_tls_connection_get_ciphersuite_name (G_TLS_CONNECTION (priv->connection));
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_tls_ciphersuite_name 1\n");
}

void
soup_connection_set_tls_client_certificate (SoupConnection  *conn,
                                            GTlsCertificate *certificate)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_tls_client_certificate 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

        if (G_IS_TLS_CONNECTION (priv->connection) && certificate) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_tls_client_certificate 2\n");
                g_tls_connection_set_certificate (G_TLS_CONNECTION (priv->connection),
                                                  certificate);
                g_clear_object (&priv->tls_client_cert);
                return;
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_tls_client_certificate 2\n");
        }

        if (priv->tls_client_cert == certificate) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_tls_client_certificate 3\n");
                return;
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_tls_client_certificate 3\n");
        }

        g_clear_object (&priv->tls_client_cert);
        priv->tls_client_cert = certificate ? g_object_ref (certificate) : NULL;
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_tls_client_certificate 1\n");
}

void
soup_connection_request_tls_certificate (SoupConnection *conn,
                                         GTlsConnection *connection,
                                         GTask          *task)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_request_tls_certificate 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);
        gboolean handled = FALSE;

        if (!G_IS_TLS_CONNECTION (priv->connection) || G_TLS_CONNECTION (priv->connection) != connection) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_request_tls_certificate 2\n");
                g_task_return_int (task, G_TLS_INTERACTION_FAILED);
                return;
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_request_tls_certificate 2\n");
        }

        if (priv->tls_client_cert) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_request_tls_certificate 3\n");
                soup_connection_complete_tls_certificate_request (conn,
                                                                  priv->tls_client_cert,
                                                                  g_object_ref (task));
                g_clear_object (&priv->tls_client_cert);
                return;
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_request_tls_certificate 3\n");
        }

        g_signal_emit (conn, signals[REQUEST_CERTIFICATE], 0, connection, task, &handled);
        if (!handled) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_request_tls_certificate 4\n");
                g_task_return_int (task, G_TLS_INTERACTION_FAILED);
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_request_tls_certificate 4\n");
        }
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_request_tls_certificate 1\n");
}

void
soup_connection_complete_tls_certificate_request (SoupConnection  *conn,
                                                  GTlsCertificate *certificate,
                                                  GTask           *task)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_complete_tls_certificate_request 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

        if (G_IS_TLS_CONNECTION (priv->connection) && certificate) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_complete_tls_certificate_request 2\n");
                g_tls_connection_set_certificate (G_TLS_CONNECTION (priv->connection),
                                                  certificate);
                g_task_return_int (task, G_TLS_INTERACTION_HANDLED);
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_complete_tls_certificate_request 2\n");
        } else {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_complete_tls_certificate_request 3\n");
                g_task_return_int (task, G_TLS_INTERACTION_FAILED);
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_complete_tls_certificate_request 3\n");
        }
        g_object_unref (task);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_complete_tls_certificate_request 1\n");
}

void
soup_connection_request_tls_certificate_password (SoupConnection *conn,
                                                  GTlsPassword   *password,
                                                  GTask          *task)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_request_tls_certificate_password 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);
        gboolean handled = FALSE;

        if (!G_IS_TLS_CONNECTION (priv->connection)) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_request_tls_certificate_password 2\n");
                g_task_return_int (task, G_TLS_INTERACTION_FAILED);
                return;
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_request_tls_certificate_password 2\n");
        }

        g_signal_emit (conn, signals[REQUEST_CERTIFICATE_PASSWORD], 0, password, task, &handled);
        if (!handled) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_request_tls_certificate_password 3\n");
                g_task_return_int (task, G_TLS_INTERACTION_FAILED);
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_request_tls_certificate_password 3\n");
        }
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_request_tls_certificate_password 1\n");
}

void
soup_connection_complete_tls_certificate_password_request (SoupConnection *conn,
                                                           GTask          *task)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_complete_tls_certificate_password_request 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

        if (G_IS_TLS_CONNECTION (priv->connection)) {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_complete_tls_certificate_password_request 2\n");
                g_task_return_int (task, G_TLS_INTERACTION_HANDLED);
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_complete_tls_certificate_password_request 2\n");
        } else {
                fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_complete_tls_certificate_password_request 3\n");
                g_task_return_int (task, G_TLS_INTERACTION_FAILED);
                // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_complete_tls_certificate_password_request 3\n");
        }
        g_object_unref (task);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_complete_tls_certificate_password_request 1\n");
}

guint64
soup_connection_get_id (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_id 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

        return priv->id;
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_id 1\n");
}

GSocketAddress *
soup_connection_get_remote_address (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_remote_address 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

        return priv->remote_address;
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_remote_address 1\n");
}

SoupHTTPVersion
soup_connection_get_negotiated_protocol (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_negotiated_protocol 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

        return priv->http_version;
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_negotiated_protocol 1\n");
}

gboolean
soup_connection_is_reusable (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_is_reusable 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

        return priv->io_data && soup_client_message_io_is_reusable (priv->io_data);
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_is_reusable 1\n");
}

GThread *
soup_connection_get_owner (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_owner 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

        return priv->owner;
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_owner 1\n");
}

void
soup_connection_set_http2_initial_window_size (SoupConnection *conn,
                                               int             window_size)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_http2_initial_window_size 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

        priv->window_size = window_size;
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_http2_initial_window_size 1\n");
}

int
soup_connection_get_http2_initial_window_size (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_http2_initial_window_size 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

        return priv->window_size;
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_http2_initial_window_size 1\n");
}

void
soup_connection_set_http2_initial_stream_window_size (SoupConnection *conn,
                                                      int             window_size)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_set_http2_initial_stream_window_size 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

        priv->stream_window_size = window_size;
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_set_http2_initial_stream_window_size 1\n");
}

int
soup_connection_get_http2_initial_stream_window_size (SoupConnection *conn)
{
        fprintf(stderr, "[libsoup/soup-connection.c] enter soup_connection_get_http2_initial_stream_window_size 1\n");
        SoupConnectionPrivate *priv = soup_connection_get_instance_private (conn);

        return priv->stream_window_size;
        // fprintf(stderr, "[libsoup/soup-connection.c] exit soup_connection_get_http2_initial_stream_window_size 1\n");
}
// Total cost: 0.537282
// Total split cost: 0.135106, input tokens: 105634, output tokens: 2160, cache read tokens: 105615, cache write tokens: 18924, split chunks: [(0, 796), (796, 1437)]
// Total instrumented cost: 0.402176, input tokens: 2402, output tokens: 22348, cache read tokens: 2394, cache write tokens: 17657

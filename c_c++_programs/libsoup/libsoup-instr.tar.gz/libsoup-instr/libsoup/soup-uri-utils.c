/* soup-uri-utils.c
 *
 * Copyright 2020 Igalia S.L.
 * Copyright 1999-2003 Ximian, Inc.
 *
 * This file is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This file is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * SPDX-License-Identifier: LGPL-2.0-or-later
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include <glib/gi18n-lib.h>

#include "soup-uri-utils-private.h"
#include "soup.h"
#include "soup-misc.h"

/**
 * SOUP_HTTP_URI_FLAGS:
 *
 * The set of #GUriFlags libsoup expects all #GUri to use.
 */

static inline int
soup_scheme_default_port (const char *scheme)
{
        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_scheme_default_port 1\n");
        if (!g_strcmp0 (scheme, "http") ||
            !g_strcmp0 (scheme, "ws"))
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_scheme_default_port 2\n");
		return 80;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_scheme_default_port 2\n");
        }
	else if (!g_strcmp0 (scheme, "https") ||
                 !g_strcmp0 (scheme, "wss"))
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_scheme_default_port 3\n");
		return 443;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_scheme_default_port 3\n");
        }
	else if (!g_strcmp0 (scheme, "ftp"))
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_scheme_default_port 4\n");
		return 21;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_scheme_default_port 4\n");
        }
	else
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_scheme_default_port 5\n");
		return -1;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_scheme_default_port 5\n");
        }
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_scheme_default_port 1\n");
}

static inline gboolean
parts_equal (const char *one, const char *two, gboolean insensitive)
{
        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter parts_equal 1\n");
	if (!one && !two)
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter parts_equal 2\n");
		return TRUE;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit parts_equal 2\n");
        }
	if (!one || !two)
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter parts_equal 3\n");
		return FALSE;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit parts_equal 3\n");
        }
        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter parts_equal 4\n");
	return insensitive ? !g_ascii_strcasecmp (one, two) : !strcmp (one, two);
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit parts_equal 4\n");
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit parts_equal 1\n");
}

static inline gboolean
path_equal (const char *one, const char *two)
{
        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter path_equal 1\n");
        if (one[0] == '\0')
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter path_equal 2\n");
                one = "/";
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit path_equal 2\n");
        }
        if (two[0] == '\0')
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter path_equal 3\n");
                two = "/";
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit path_equal 3\n");
        }

        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter path_equal 4\n");
	return !strcmp (one, two);
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit path_equal 4\n");
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit path_equal 1\n");
}

static gboolean
flags_equal (GUriFlags flags1, GUriFlags flags2)
{
        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter flags_equal 1\n");
        /* We only care about flags that affect the contents which these do */
        static const GUriFlags normalization_flags = (G_URI_FLAGS_ENCODED | G_URI_FLAGS_ENCODED_FRAGMENT |
                                                      G_URI_FLAGS_ENCODED_PATH | G_URI_FLAGS_ENCODED_QUERY |
                                                      G_URI_FLAGS_SCHEME_NORMALIZE);

        return (flags1 & normalization_flags) == (flags2 & normalization_flags);
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit flags_equal 1\n");
}

/**
 * soup_uri_equal:
 * @uri1: a #GUri
 * @uri2: another #GUri
 *
 * Tests whether or not @uri1 and @uri2 are equal in all parts.
 *
 * Returns: %TRUE if equal otherwise %FALSE
 **/
gboolean
soup_uri_equal (GUri *uri1, GUri *uri2)
{
        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_equal 1\n");
     	g_return_val_if_fail (uri1 != NULL, FALSE);
	g_return_val_if_fail (uri2 != NULL, FALSE);

       	if (!flags_equal (g_uri_get_flags (uri1), g_uri_get_flags (uri2))                  ||
            g_strcmp0 (g_uri_get_scheme (uri1), g_uri_get_scheme (uri2))                   ||
	    g_uri_get_port (uri1) != g_uri_get_port (uri2)                                 ||
	    !parts_equal (g_uri_get_user (uri1), g_uri_get_user (uri2), FALSE)             ||
	    !parts_equal (g_uri_get_password (uri1), g_uri_get_password (uri2), FALSE)     ||
	    !parts_equal (g_uri_get_host (uri1), g_uri_get_host (uri2), TRUE)              ||
	    !path_equal (g_uri_get_path (uri1), g_uri_get_path (uri2))                     ||
	    !parts_equal (g_uri_get_query (uri1), g_uri_get_query (uri2), FALSE)           ||
	    !parts_equal (g_uri_get_fragment (uri1), g_uri_get_fragment (uri2), FALSE)) {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_equal 2\n");
                return FALSE;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_equal 2\n");
            }

        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_equal 3\n");
        return TRUE;
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_equal 3\n");
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_equal 1\n");
}

/**
 * soup_uri_get_path_and_query:
 * @uri: a #GUri
 *
 * Extracts the `path` and `query` parts from @uri.
 *
 * Returns: string of combined path and query
 **/
char *
soup_uri_get_path_and_query (GUri *uri)
{
        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_get_path_and_query 1\n");
        const char *query;

	g_return_val_if_fail (uri != NULL, NULL);

        query = g_uri_get_query (uri);

        return g_strdup_printf ("%s%c%s", g_uri_get_path (uri),
                                query ? '?' : '\0',
                                query ? query : "");
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_get_path_and_query 1\n");
}

/**
 * soup_uri_uses_default_port:
 * @uri: a #GUri
 *
 * Tests if @uri uses the default port for its scheme.
 *
 * (Eg, 80 for http.) (This only works for http, https and ftp; libsoup does not
 * know the default ports of other protocols.)
 *
 * Returns: %TRUE or %FALSE
 **/
gboolean
soup_uri_uses_default_port (GUri *uri)
{
        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_uses_default_port 1\n");
        g_return_val_if_fail (uri != NULL, FALSE);

        if (g_uri_get_port (uri) == -1)
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_uses_default_port 2\n");
                return TRUE;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_uses_default_port 2\n");
        }

        if (g_uri_get_scheme (uri))
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_uses_default_port 3\n");
                return g_uri_get_port (uri) == soup_scheme_default_port (g_uri_get_scheme (uri));
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_uses_default_port 3\n");
        }

        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_uses_default_port 4\n");
        return FALSE;
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_uses_default_port 4\n");
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_uses_default_port 1\n");
}

GUri *
soup_uri_copy_host (GUri *uri)
{
        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_copy_host 1\n");
        g_return_val_if_fail (uri != NULL, NULL);

        return soup_uri_copy (uri,
                              SOUP_URI_USER, NULL,
                              SOUP_URI_PASSWORD, NULL,
                              SOUP_URI_AUTH_PARAMS, NULL,
                              SOUP_URI_PATH, "/",
                              SOUP_URI_QUERY, NULL,
                              SOUP_URI_FRAGMENT, NULL,
                              SOUP_URI_NONE);
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_copy_host 1\n");
}

/**
 * soup_uri_host_hash:
 * @key: (type GUri): a #GUri with a non-%NULL @host member
 *
 * Hashes @key, considering only the scheme, host, and port.
 *
 * Returns: A hash
 */
guint
soup_uri_host_hash (gconstpointer key)
{
        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_host_hash 1\n");
	GUri *uri = (GUri*)key;
        const char *host;

	g_return_val_if_fail (uri != NULL, 0);

        host = g_uri_get_host (uri);

	g_return_val_if_fail (host != NULL, 0);

	return soup_str_case_hash (g_uri_get_scheme (uri)) +
               g_uri_get_port (uri) +
	       soup_str_case_hash (host);
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_host_hash 1\n");
}

/**
 * soup_uri_host_equal:
 * @v1: (type GUri): a #GUri with a non-%NULL @host member
 * @v2: (type GUri): a #GUri with a non-%NULL @host member
 *
 * Compares @v1 and @v2, considering only the scheme, host, and port.
 *
 * Returns: %TRUE if the URIs are equal in scheme, host, and port.
 */
gboolean
soup_uri_host_equal (gconstpointer v1, gconstpointer v2)
{
        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_host_equal 1\n");
	GUri *one = (GUri*)v1;
	GUri *two = (GUri*)v2;
        const char *one_host, *two_host;

	g_return_val_if_fail (one != NULL && two != NULL, one == two);

        one_host = g_uri_get_host (one);
        two_host = g_uri_get_host (two);

	g_return_val_if_fail (one_host != NULL && two_host != NULL, one_host == two_host);

        if (one == two)
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_host_equal 2\n");
                return TRUE;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_host_equal 2\n");
        }
	if (g_strcmp0 (g_uri_get_scheme (one), g_uri_get_scheme (two)) != 0)
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_host_equal 3\n");
		return FALSE;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_host_equal 3\n");
        }

	if (g_uri_get_port (one) != g_uri_get_port (two))
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_host_equal 4\n");
		return FALSE;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_host_equal 4\n");
        }

        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_host_equal 5\n");
	return g_ascii_strcasecmp (one_host, two_host) == 0;
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_host_equal 5\n");
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_host_equal 1\n");
}

gboolean
soup_uri_is_https (GUri *uri)
{
        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_is_https 1\n");
        const char *scheme;

        g_assert (uri != NULL);

        scheme = g_uri_get_scheme (uri);
        if (G_UNLIKELY (scheme == NULL))
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_is_https 2\n");
                return FALSE;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_is_https 2\n");
        }

        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_is_https 3\n");
        return strcmp (scheme, "https") == 0 || strcmp (scheme, "wss") == 0;
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_is_https 3\n");
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_is_https 1\n");
}

gboolean
soup_uri_is_http (GUri *uri)
{
        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_is_http 1\n");
        const char *scheme;

        g_assert (uri != NULL);

        scheme = g_uri_get_scheme (uri);
        if (G_UNLIKELY (scheme == NULL))
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_is_http 2\n");
                return FALSE;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_is_http 2\n");
        }

        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_is_http 3\n");
        return strcmp (scheme, "http") == 0 || strcmp (scheme, "ws") == 0;
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_is_http 3\n");
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_is_http 1\n");
}

#define BASE64_INDICATOR     ";base64"
#define BASE64_INDICATOR_LEN (sizeof (";base64") - 1)

/**
 * soup_uri_decode_data_uri:
 * @uri: a data URI, in string form
 * @content_type: (out) (nullable) (transfer full): location to store content type
 *
 * Decodes the given data URI and returns its contents and @content_type.
 *
 * Returns: (transfer full): a #GBytes with the contents of @uri,
 *    or %NULL if @uri is not a valid data URI
 */
GBytes *
soup_uri_decode_data_uri (const char *uri,
                          char      **content_type)
{
        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_decode_data_uri 1\n");
        GUri *soup_uri;
        const char *comma, *start, *end;
        gboolean base64 = FALSE;
        char *uri_string;
        GBytes *bytes;

        g_return_val_if_fail (uri != NULL, NULL);

        soup_uri = g_uri_parse (uri, SOUP_HTTP_URI_FLAGS, NULL);
        if (!soup_uri)
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_decode_data_uri 2\n");
                return NULL;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_decode_data_uri 2\n");
        }

        if (g_strcmp0 (g_uri_get_scheme (soup_uri), "data") || g_uri_get_host (soup_uri) != NULL) {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_decode_data_uri 3\n");
                g_uri_unref (soup_uri);
                return NULL;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_decode_data_uri 3\n");
        }

        if (content_type)
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_decode_data_uri 4\n");
                *content_type = NULL;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_decode_data_uri 4\n");
        }

#if !GLIB_CHECK_VERSION (2, 83, 1)
        /* g_uri_to_string() is picky about paths that start with `//` and will assert, clean them up.
         * https://gitlab.gnome.org/GNOME/glib/-/merge_requests/4407 */
        const char *path = g_uri_get_path (soup_uri);
        if (path[0] == '/' && path[1] == '/') {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_decode_data_uri 5\n");
                char *new_path = g_strconcat ("/.", path, NULL);
                GUri *new_uri = soup_uri_copy (soup_uri, SOUP_URI_PATH, new_path, SOUP_URI_NONE);

                g_uri_unref (soup_uri);
                g_free (new_path);

                soup_uri = new_uri;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_decode_data_uri 5\n");
        }
#endif

        uri_string = g_uri_to_string (soup_uri);
        g_uri_unref (soup_uri);
        if (!uri_string)
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_decode_data_uri 6\n");
                return NULL;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_decode_data_uri 6\n");
        }

        start = uri_string + 5;
        comma = strchr (start, ',');
        if (comma && comma != start) {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_decode_data_uri 7\n");
                /* Deal with MIME type / params */
                if (comma >= start + BASE64_INDICATOR_LEN && !g_ascii_strncasecmp (comma - BASE64_INDICATOR_LEN, BASE64_INDICATOR, BASE64_INDICATOR_LEN)) {
                        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_decode_data_uri 8\n");
                        end = comma - BASE64_INDICATOR_LEN;
                        base64 = TRUE;
                        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_decode_data_uri 8\n");
                } else
                {
                        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_decode_data_uri 9\n");
                        end = comma;
                        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_decode_data_uri 9\n");
                }

                if (end != start && content_type)
                {
                        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_decode_data_uri 10\n");
                        *content_type = g_uri_unescape_segment (start, end, NULL);
                        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_decode_data_uri 10\n");
                }
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_decode_data_uri 7\n");
        }

        if (content_type && !*content_type)
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_decode_data_uri 11\n");
                *content_type = g_strdup ("text/plain;charset=US-ASCII");
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_decode_data_uri 11\n");
        }

        if (comma)
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_decode_data_uri 12\n");
                start = comma + 1;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_decode_data_uri 12\n");
        }

        if (*start) {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_decode_data_uri 13\n");
                bytes = g_uri_unescape_bytes (start, -1, NULL, NULL);

                if (base64 && bytes) {
                        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_decode_data_uri 14\n");
                        if (g_bytes_get_size (bytes) <= 1)
                        {
                                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_decode_data_uri 15\n");
                                g_clear_pointer (&bytes, g_bytes_unref);
                                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_decode_data_uri 15\n");
                        }
                        else {
                                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_decode_data_uri 16\n");
                                gsize content_length;
                                GByteArray *unescaped_array = g_bytes_unref_to_array (bytes);
                                g_base64_decode_inplace ((gchar*)unescaped_array->data, &content_length);
                                unescaped_array->len = content_length;
                                bytes = g_byte_array_free_to_bytes (unescaped_array);
                                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_decode_data_uri 16\n");
                        }
                        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_decode_data_uri 14\n");
                }
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_decode_data_uri 13\n");
        } else {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_decode_data_uri 17\n");
                bytes = g_bytes_new_static (NULL, 0);
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_decode_data_uri 17\n");
        }
        g_free (uri_string);

        return bytes;
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_decode_data_uri 1\n");
}

/**
 * SoupURIComponent:
 * @SOUP_URI_NONE: no component
 * @SOUP_URI_SCHEME: the URI scheme component
 * @SOUP_URI_USER: the URI user component
 * @SOUP_URI_PASSWORD: the URI password component
 * @SOUP_URI_AUTH_PARAMS: the URI authentication parameters component
 * @SOUP_URI_HOST: the URI host component
 * @SOUP_URI_PORT: the URI port component
 * @SOUP_URI_PATH: the URI path component
 * @SOUP_URI_QUERY: the URI query component
 * @SOUP_URI_FRAGMENT: the URI fragment component
 *
 * Enum values passed to [func@uri_copy] to indicate the components of
 * the URI that should be updated with the given values.
 */

static int
get_maybe_default_port (GUri *uri)
{
        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter get_maybe_default_port 1\n");
        const char *scheme = g_uri_get_scheme (uri);
        int port = g_uri_get_port (uri);

        switch (port) {
        case 80:
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter get_maybe_default_port 2\n");
                if (!strcmp (scheme, "http") || !strcmp (scheme, "ws"))
                {
                        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter get_maybe_default_port 3\n");
                        return -1;
                        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit get_maybe_default_port 3\n");
                }
                break;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit get_maybe_default_port 2\n");
        case 443:
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter get_maybe_default_port 4\n");
                if (!strcmp (scheme, "https") || !strcmp (scheme, "wss"))
                {
                        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter get_maybe_default_port 5\n");
                        return -1;
                        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit get_maybe_default_port 5\n");
                }
                break;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit get_maybe_default_port 4\n");
        default:
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter get_maybe_default_port 6\n");
                break;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit get_maybe_default_port 6\n");
        }

        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter get_maybe_default_port 7\n");
        return port;
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit get_maybe_default_port 7\n");
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit get_maybe_default_port 1\n");
}

/**
 * soup_uri_copy: (skip)
 * @uri: the #GUri to copy
 * @first_component: first #SoupURIComponent to update
 * @...: value of @first_component  followed by additional
 *    components and values, terminated by %SOUP_URI_NONE
 *
 * As of 3.4.0 this will detect the default ports of HTTP(s) and WS(S)
 * URIs when copying and set it to the default port of the new scheme.
 * So for example copying `http://localhost:80` while changing the scheme to https
 * will result in `https://localhost:443`.
 * 
 * Return a copy of @uri with the given components updated.
 *
 * Returns: (transfer full): a new #GUri
 */
GUri *
soup_uri_copy (GUri            *uri,
               SoupURIComponent first_component,
               ...)
{
        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_copy 1\n");
        va_list args;
        SoupURIComponent component = first_component;
        gpointer values[SOUP_URI_FRAGMENT + 1];
        gboolean values_to_set[SOUP_URI_FRAGMENT + 1];
        GUriFlags flags = g_uri_get_flags (uri);

        g_return_val_if_fail (uri != NULL, NULL);

        memset (&values_to_set, 0, sizeof (values_to_set));

        va_start (args, first_component);
        while (component != SOUP_URI_NONE) {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_copy 2\n");
                if (component == SOUP_URI_PORT)
                {
                        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_copy 3\n");
                        values[component] = GINT_TO_POINTER (va_arg (args, gint));
                        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_copy 3\n");
                }
                else
                {
                        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_copy 4\n");
                        values[component] = va_arg (args, gpointer);
                        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_copy 4\n");
                }
                values_to_set[component] = TRUE;
                component = va_arg (args, SoupURIComponent);
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_copy 2\n");
        }
        va_end (args);

        if (values_to_set[SOUP_URI_PASSWORD])
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_copy 5\n");
                flags |= G_URI_FLAGS_HAS_PASSWORD;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_copy 5\n");
        }
        if (values_to_set[SOUP_URI_AUTH_PARAMS])
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_copy 6\n");
                flags |= G_URI_FLAGS_HAS_AUTH_PARAMS;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_copy 6\n");
        }
        if (values_to_set[SOUP_URI_PATH])
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_copy 7\n");
                flags |= G_URI_FLAGS_ENCODED_PATH;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_copy 7\n");
        }
        if (values_to_set[SOUP_URI_QUERY])
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_copy 8\n");
                flags |= G_URI_FLAGS_ENCODED_QUERY;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_copy 8\n");
        }
        if (values_to_set[SOUP_URI_FRAGMENT])
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_copy 9\n");
                flags |= G_URI_FLAGS_ENCODED_FRAGMENT;
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_copy 9\n");
        }
        return g_uri_build_with_user (
                flags,
                values_to_set[SOUP_URI_SCHEME] ? values[SOUP_URI_SCHEME] : g_uri_get_scheme (uri),
                values_to_set[SOUP_URI_USER] ? values[SOUP_URI_USER] : g_uri_get_user (uri),
                values_to_set[SOUP_URI_PASSWORD] ? values[SOUP_URI_PASSWORD] : g_uri_get_password (uri),
                values_to_set[SOUP_URI_AUTH_PARAMS] ? values[SOUP_URI_AUTH_PARAMS] : g_uri_get_auth_params (uri),
                values_to_set[SOUP_URI_HOST] ? values[SOUP_URI_HOST] : g_uri_get_host (uri),
                values_to_set[SOUP_URI_PORT] ? GPOINTER_TO_INT (values[SOUP_URI_PORT]) : get_maybe_default_port (uri),
                values_to_set[SOUP_URI_PATH] ? values[SOUP_URI_PATH] : g_uri_get_path (uri),
                values_to_set[SOUP_URI_QUERY] ? values[SOUP_URI_QUERY] : g_uri_get_query (uri),
                values_to_set[SOUP_URI_FRAGMENT] ? values[SOUP_URI_FRAGMENT] : g_uri_get_fragment (uri)
        );
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_copy 1\n");
}

GUri *
soup_uri_copy_with_normalized_flags (GUri *uri)
{
        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_copy_with_normalized_flags 1\n");
        GUriFlags flags = g_uri_get_flags (uri);

        /* We require its encoded (hostname encoding optional) */
        if (((flags & (G_URI_FLAGS_ENCODED_PATH | G_URI_FLAGS_ENCODED_QUERY | G_URI_FLAGS_ENCODED_FRAGMENT)) ||
             (flags & G_URI_FLAGS_ENCODED)) &&
            /* And has scheme-based normalization */
            (flags & G_URI_FLAGS_SCHEME_NORMALIZE))
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_copy_with_normalized_flags 2\n");
                return g_uri_ref (uri);
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_copy_with_normalized_flags 2\n");
        }

        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_copy_with_normalized_flags 3\n");
        return g_uri_build_with_user (
                g_uri_get_flags (uri) | SOUP_HTTP_URI_FLAGS,
                g_uri_get_scheme (uri),
                g_uri_get_user (uri),
                g_uri_get_password (uri),
                g_uri_get_auth_params (uri),
                g_uri_get_host (uri),
                g_uri_get_port (uri),
                g_uri_get_path (uri),
                g_uri_get_query (uri),
                g_uri_get_fragment (uri)
        );
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_copy_with_normalized_flags 3\n");
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_copy_with_normalized_flags 1\n");
}

char *
soup_uri_get_host_for_headers (GUri *uri)
{
        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_get_host_for_headers 1\n");
        const char *host = g_uri_get_host (uri);

        if (strchr (host, ':'))
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_get_host_for_headers 2\n");
                return g_strdup_printf ("[%.*s]", (int)strcspn (host, "%"), host);
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_get_host_for_headers 2\n");
        }
        if (g_hostname_is_non_ascii (host))
        {
                fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_get_host_for_headers 3\n");
                return g_hostname_to_ascii (host);
                // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_get_host_for_headers 3\n");
        }

        fprintf(stderr, "[libsoup/soup-uri-utils.c] enter soup_uri_get_host_for_headers 4\n");
        return g_strdup (host);
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_get_host_for_headers 4\n");
        // fprintf(stderr, "[libsoup/soup-uri-utils.c] exit soup_uri_get_host_for_headers 1\n");
}
// Total cost: 0.154401
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 508)]
// Total instrumented cost: 0.154401, input tokens: 2398, output tokens: 8852, cache read tokens: 2394, cache write tokens: 5571

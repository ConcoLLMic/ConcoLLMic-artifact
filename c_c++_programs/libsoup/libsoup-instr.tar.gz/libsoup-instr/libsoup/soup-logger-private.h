/*
 * Copyright (C) 2021 Igalia S.L.
 */

#pragma once

#include "soup-logger.h"
#include "soup-body-output-stream.h"

G_BEGIN_DECLS

void soup_logger_log_request_data (SoupLogger *logger, SoupMessage *msg, const char *buffer, gsize len);

G_END_DECLS
// Total cost: 0.001761
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 14)]
// Total instrumented cost: 0.001761, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 183

/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright (C) 2000-2003, Ximian, Inc.
 */

#pragma once

#include <glib-object.h>

typedef enum {
        SOUP_MESSAGE_IO_COMPLETE,
        SOUP_MESSAGE_IO_INTERRUPTED,
        SOUP_MESSAGE_IO_STOLEN
} SoupMessageIOCompletion;

typedef void (*SoupMessageIOCompletionFn) (GObject                *msg,
                                           SoupMessageIOCompletion completion,
                                           gpointer                user_data);
// Total cost: 0.002028
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 18)]
// Total instrumented cost: 0.002028, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 254

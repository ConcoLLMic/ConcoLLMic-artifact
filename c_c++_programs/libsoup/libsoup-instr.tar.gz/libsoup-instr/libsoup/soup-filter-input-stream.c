/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * soup-filter-input-stream.c
 *
 * Copyright 2012 Red Hat, Inc.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <string.h>

#include "soup-filter-input-stream.h"
#include "soup.h"

/* This is essentially a subset of GDataInputStream, except that we
 * can do the equivalent of "fill_nonblocking()" on it. (We could use
 * an actual GDataInputStream, and implement the nonblocking semantics
 * via fill_async(), but that would be more work...)
 */

typedef struct {
	GByteArray *buf;
	gboolean need_more;
	gboolean in_read_until;
} SoupFilterInputStreamPrivate;

enum {
        READ_DATA,

        LAST_SIGNAL
};

static guint signals[LAST_SIGNAL] = { 0 };

static void soup_filter_input_stream_pollable_init (GPollableInputStreamInterface *pollable_interface, gpointer interface_data);

G_DEFINE_TYPE_WITH_CODE (SoupFilterInputStream, soup_filter_input_stream, G_TYPE_FILTER_INPUT_STREAM,
                         G_ADD_PRIVATE (SoupFilterInputStream)
			 G_IMPLEMENT_INTERFACE (G_TYPE_POLLABLE_INPUT_STREAM,
						soup_filter_input_stream_pollable_init))

static void
soup_filter_input_stream_init (SoupFilterInputStream *stream)
{
    fprintf(stderr, "\n");
    // fprintf(stderr, "\n");
}

static void
soup_filter_input_stream_finalize (GObject *object)
{
    fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_finalize 1\n");
	SoupFilterInputStream *fstream = SOUP_FILTER_INPUT_STREAM (object);
    SoupFilterInputStreamPrivate *priv = soup_filter_input_stream_get_instance_private (fstream);

	g_clear_pointer (&priv->buf, g_byte_array_unref);

	G_OBJECT_CLASS (soup_filter_input_stream_parent_class)->finalize (object);
    // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_finalize 1\n");
}

static gssize
read_from_buf (SoupFilterInputStream *fstream, gpointer buffer, gsize count)
{
    fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter read_from_buf 1\n");
    SoupFilterInputStreamPrivate *priv = soup_filter_input_stream_get_instance_private (fstream);
	GByteArray *buf = priv->buf;

	if (buf->len < count)
		count = buf->len;
	if (buffer)
	        memcpy (buffer, buf->data, count);

	if (count == buf->len) {
        fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter read_from_buf 2\n");
		g_byte_array_free (buf, TRUE);
		priv->buf = NULL;
        // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit read_from_buf 2\n");
	} else {
        fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter read_from_buf 3\n");
		memmove (buf->data, buf->data + count,
			 buf->len - count);
		g_byte_array_set_size (buf, buf->len - count);
        // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit read_from_buf 3\n");
	}

	return count;
    // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit read_from_buf 1\n");
}

static gssize
soup_filter_input_stream_read_fn (GInputStream  *stream,
				  void          *buffer,
				  gsize          count,
				  GCancellable  *cancellable,
				  GError       **error)
{
    fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_fn 1\n");
	SoupFilterInputStream *fstream = SOUP_FILTER_INPUT_STREAM (stream);
    SoupFilterInputStreamPrivate *priv = soup_filter_input_stream_get_instance_private (fstream);
    gssize bytes_read;

    if (g_cancellable_set_error_if_cancelled (cancellable, error)) {
        fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_fn 2\n");
        return -1;
        // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_fn 2\n");
    }

	if (!priv->in_read_until)
		priv->need_more = FALSE;

	if (priv->buf && !priv->in_read_until) {
        fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_fn 3\n");
		return read_from_buf (fstream, buffer, count);
        // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_fn 3\n");
    }

    bytes_read = g_pollable_stream_read (G_FILTER_INPUT_STREAM (fstream)->base_stream,
                                         buffer, count,
                                         TRUE, cancellable, error);
    if (bytes_read > 0) {
        fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_fn 4\n");
        g_signal_emit (fstream, signals[READ_DATA], 0, bytes_read);
        // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_fn 4\n");
    }

    return bytes_read;
    // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_fn 1\n");
}

static gssize
soup_filter_input_stream_skip (GInputStream  *stream,
                               gsize          count,
                               GCancellable  *cancellable,
                               GError       **error)
{
    fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_skip 1\n");
    SoupFilterInputStream *fstream = SOUP_FILTER_INPUT_STREAM (stream);
    SoupFilterInputStreamPrivate *priv = soup_filter_input_stream_get_instance_private (fstream);
    gssize bytes_skipped;

    if (g_cancellable_set_error_if_cancelled (cancellable, error)) {
        fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_skip 2\n");
        return -1;
        // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_skip 2\n");
    }

    if (!priv->in_read_until)
        priv->need_more = FALSE;

    if (priv->buf && !priv->in_read_until) {
        fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_skip 3\n");
        return read_from_buf (fstream, NULL, count);
        // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_skip 3\n");
    }

    bytes_skipped = g_input_stream_skip (G_FILTER_INPUT_STREAM (fstream)->base_stream,
                                         count, cancellable, error);
    if (bytes_skipped > 0) {
        fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_skip 4\n");
        g_signal_emit (fstream, signals[READ_DATA], 0, bytes_skipped);
        // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_skip 4\n");
    }

    return bytes_skipped;
    // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_skip 1\n");
}

static gboolean
soup_filter_input_stream_is_readable (GPollableInputStream *stream)
{
    fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_is_readable 1\n");
	SoupFilterInputStream *fstream = SOUP_FILTER_INPUT_STREAM (stream);
    SoupFilterInputStreamPrivate *priv = soup_filter_input_stream_get_instance_private (fstream);

	if (priv->buf && !priv->need_more) {
        fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_is_readable 2\n");
		return TRUE;
        // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_is_readable 2\n");
    } else {
        fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_is_readable 3\n");
		return g_pollable_input_stream_is_readable (G_POLLABLE_INPUT_STREAM (G_FILTER_INPUT_STREAM (fstream)->base_stream));
        // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_is_readable 3\n");
    }
    // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_is_readable 1\n");
}

static gssize
soup_filter_input_stream_read_nonblocking (GPollableInputStream  *stream,
					   void                  *buffer,
					   gsize                  count,
					   GError               **error)
{
    fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_nonblocking 1\n");
	SoupFilterInputStream *fstream = SOUP_FILTER_INPUT_STREAM (stream);
    SoupFilterInputStreamPrivate *priv = soup_filter_input_stream_get_instance_private (fstream);
    gssize bytes_read;

	if (!priv->in_read_until)
		priv->need_more = FALSE;

	if (priv->buf && !priv->in_read_until) {
        fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_nonblocking 2\n");
		return read_from_buf (fstream, buffer, count);
        // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_nonblocking 2\n");
    }

    bytes_read = g_pollable_stream_read (G_FILTER_INPUT_STREAM (fstream)->base_stream,
                                         buffer, count,
                                         FALSE, NULL, error);
    if (bytes_read > 0) {
        fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_nonblocking 3\n");
        g_signal_emit (fstream, signals[READ_DATA], 0, bytes_read);
        // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_nonblocking 3\n");
    }

    return bytes_read;
    // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_nonblocking 1\n");
}

static GSource *
soup_filter_input_stream_create_source (GPollableInputStream *stream,
					GCancellable         *cancellable)
{
    fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_create_source 1\n");
	SoupFilterInputStream *fstream = SOUP_FILTER_INPUT_STREAM (stream);
    SoupFilterInputStreamPrivate *priv = soup_filter_input_stream_get_instance_private (fstream);
	GSource *base_source, *pollable_source;

	if (priv->buf && !priv->need_more) {
        fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_create_source 2\n");
		base_source = g_timeout_source_new (0);
        // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_create_source 2\n");
    } else {
        fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_create_source 3\n");
		base_source = g_pollable_input_stream_create_source (G_POLLABLE_INPUT_STREAM (G_FILTER_INPUT_STREAM (fstream)->base_stream), cancellable);
        // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_create_source 3\n");
    }

	g_source_set_dummy_callback (base_source);
	pollable_source = g_pollable_source_new (G_OBJECT (stream));
	g_source_add_child_source (pollable_source, base_source);
	g_source_unref (base_source);

	return pollable_source;
    // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_create_source 1\n");
}

static void
soup_filter_input_stream_class_init (SoupFilterInputStreamClass *stream_class)
{
    fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_class_init 1\n");
	GObjectClass *object_class = G_OBJECT_CLASS (stream_class);
	GInputStreamClass *input_stream_class = G_INPUT_STREAM_CLASS (stream_class);

	object_class->finalize = soup_filter_input_stream_finalize;

	input_stream_class->read_fn = soup_filter_input_stream_read_fn;
	input_stream_class->skip = soup_filter_input_stream_skip;

    signals[READ_DATA] =
            g_signal_new ("read-data",
                          G_OBJECT_CLASS_TYPE (object_class),
                          G_SIGNAL_RUN_LAST,
                          0,
                          NULL, NULL,
                          NULL,
                          G_TYPE_NONE, 1,
                          G_TYPE_UINT);
    // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_class_init 1\n");
}

static void
soup_filter_input_stream_pollable_init (GPollableInputStreamInterface *pollable_interface,
					gpointer                       interface_data)
{
    fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_pollable_init 1\n");
	pollable_interface->is_readable = soup_filter_input_stream_is_readable;
	pollable_interface->read_nonblocking = soup_filter_input_stream_read_nonblocking;
	pollable_interface->create_source = soup_filter_input_stream_create_source;
    // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_pollable_init 1\n");
}

GInputStream *
soup_filter_input_stream_new (GInputStream *base_stream)
{
    fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_new 1\n");
	return g_object_new (SOUP_TYPE_FILTER_INPUT_STREAM,
			     "base-stream", base_stream,
			     "close-base-stream", FALSE,
			     NULL);
    // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_new 1\n");
}

gssize
soup_filter_input_stream_read_line (SoupFilterInputStream  *fstream,
				    void                   *buffer,
				    gsize                   length,
				    gboolean                blocking,
				    gboolean               *got_line,
				    GCancellable           *cancellable,
				    GError                **error)
{
    fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_line 1\n");
	return soup_filter_input_stream_read_until (fstream, buffer, length,
						    "\n", 1, blocking,
						    TRUE, got_line,
						    cancellable, error);
    // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_line 1\n");
}

gssize
soup_filter_input_stream_read_until (SoupFilterInputStream  *fstream,
				     void                   *buffer,
				     gsize                   length,
				     const void             *boundary,
				     gsize                   boundary_length,
				     gboolean                blocking,
				     gboolean                include_boundary,
				     gboolean               *got_boundary,
				     GCancellable           *cancellable,
				     GError                **error)
{
    fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_until 1\n");
    SoupFilterInputStreamPrivate *priv = soup_filter_input_stream_get_instance_private (fstream);
	gssize nread, read_length;
	guint8 *p, *buf, *end;
	gboolean eof = FALSE;
	GError *my_error = NULL;

	g_return_val_if_fail (SOUP_IS_FILTER_INPUT_STREAM (fstream), -1);
	g_return_val_if_fail (!include_boundary || (boundary_length < length), -1);

	*got_boundary = FALSE;
	priv->need_more = FALSE;

	if (!priv->buf || priv->buf->len < boundary_length) {
        fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_until 2\n");
		guint prev_len;

	fill_buffer:
		if (!priv->buf)
			priv->buf = g_byte_array_new ();
		prev_len = priv->buf->len;
		g_byte_array_set_size (priv->buf, length);
		buf = priv->buf->data;

		priv->in_read_until = TRUE;
		nread = g_pollable_stream_read (G_INPUT_STREAM (fstream),
						buf + prev_len, length - prev_len,
						blocking,
						cancellable, &my_error);
		priv->in_read_until = FALSE;
		if (nread <= 0) {
            fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_until 3\n");
			if (prev_len)
				priv->buf->len = prev_len;
			else {
                fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_until 4\n");
				g_byte_array_free (priv->buf, TRUE);
				priv->buf = NULL;
                // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_until 4\n");
			}

			if (nread == 0 && prev_len) {
                fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_until 5\n");
				eof = TRUE;
                // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_until 5\n");
            } else {
                fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_until 6\n");
				if (g_error_matches (my_error, G_IO_ERROR, G_IO_ERROR_WOULD_BLOCK))
					priv->need_more = TRUE;
				if (my_error)
					g_propagate_error (error, my_error);

				return nread;
                // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_until 6\n");
			}

			if (my_error) {
                fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_until 7\n");
				g_propagate_error (error, my_error);
                // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_until 7\n");
            }
            // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_until 3\n");
		} else {
            fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_until 8\n");
			priv->buf->len = prev_len + nread;
            // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_until 8\n");
        }
        // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_until 2\n");
	} else {
        fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_until 9\n");
		buf = priv->buf->data;
        // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_until 9\n");
    }

	/* Scan for the boundary within the range we can possibly return. */
	if (include_boundary) {
        fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_until 10\n");
		end = buf + MIN (priv->buf->len, length) - boundary_length;
        // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_until 10\n");
    } else {
        fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_until 11\n");
		end = buf + MIN (priv->buf->len - boundary_length, length);
        // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_until 11\n");
    }
	for (p = buf; p <= end; p++) {
        fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_until 12\n");
		if (*p == *(guint8*)boundary &&
		    !memcmp (p, boundary, boundary_length)) {
            fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_until 13\n");
			if (include_boundary)
				p += boundary_length;
			*got_boundary = TRUE;
			break;
            // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_until 13\n");
		}
        // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_until 12\n");
	}

	if (!*got_boundary && priv->buf->len < length && !eof) {
        fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_until 14\n");
		goto fill_buffer;
        // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_until 14\n");
    }

	if (eof && !*got_boundary) {
        fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_until 15\n");
		read_length = MIN (priv->buf->len, length);
        // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_until 15\n");
    } else {
        fprintf(stderr, "[libsoup/soup-filter-input-stream.c] enter soup_filter_input_stream_read_until 16\n");
		read_length = p - buf;
        // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_until 16\n");
    }
	return read_from_buf (fstream, buffer, read_length);
    // fprintf(stderr, "[libsoup/soup-filter-input-stream.c] exit soup_filter_input_stream_read_until 1\n");
}
// Total cost: 0.099306
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 342)]
// Total instrumented cost: 0.099306, input tokens: 2398, output tokens: 5663, cache read tokens: 2394, cache write tokens: 3635

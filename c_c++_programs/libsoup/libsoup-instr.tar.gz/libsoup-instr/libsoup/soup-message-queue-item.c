/*
 * soup-message-queue-item.c: Message queue item
 *
 * Copyright (C) 2003 Novell, Inc.
 * Copyright (C) 2008 Red Hat, Inc.
 * Copyright (C) 2021 Igalia S.L.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include "soup-message-queue-item.h"
#include "soup.h"

SoupMessageQueueItem *
soup_message_queue_item_new (SoupSession  *session,
                             SoupMessage  *msg,
                             gboolean      async,
                             GCancellable *cancellable)
{
        fprintf(stderr, "[libsoup/soup-message-queue-item.c] enter soup_message_queue_item_new 1\n");
        SoupMessageQueueItem *item;

        item = g_atomic_rc_box_new0 (SoupMessageQueueItem);
        item->session = g_object_ref (session);
        item->msg = g_object_ref (msg);
        item->context = g_main_context_ref_thread_default ();
        item->async = async;
        item->cancellable = cancellable ? g_object_ref (cancellable) : g_cancellable_new ();

        return item;
        // fprintf(stderr, "[libsoup/soup-message-queue-item.c] exit soup_message_queue_item_new 1\n");
}

SoupMessageQueueItem *
soup_message_queue_item_ref (SoupMessageQueueItem *item)
{
        fprintf(stderr, "[libsoup/soup-message-queue-item.c] enter soup_message_queue_item_ref 1\n");
        g_atomic_rc_box_acquire (item);

        return item;
        // fprintf(stderr, "[libsoup/soup-message-queue-item.c] exit soup_message_queue_item_ref 1\n");
}

static void
soup_message_queue_item_destroy (SoupMessageQueueItem *item)
{
        fprintf(stderr, "\n");
        if (!g_error_matches (item->error, SOUP_SESSION_ERROR, SOUP_SESSION_ERROR_MESSAGE_ALREADY_IN_QUEUE)) {
                fprintf(stderr, "[libsoup/soup-message-queue-item.c] enter soup_message_queue_item_destroy 2\n");
                g_warn_if_fail (soup_message_get_connection (item->msg) == NULL);
                // fprintf(stderr, "[libsoup/soup-message-queue-item.c] exit soup_message_queue_item_destroy 2\n");
        }

        fprintf(stderr, "[libsoup/soup-message-queue-item.c] enter soup_message_queue_item_destroy 3\n");
        g_object_unref (item->session);
        g_object_unref (item->msg);
        g_main_context_unref (item->context);
        g_object_unref (item->cancellable);
        g_clear_error (&item->error);
        g_clear_object (&item->task);
        // fprintf(stderr, "[libsoup/soup-message-queue-item.c] exit soup_message_queue_item_destroy 3\n");
}

void
soup_message_queue_item_unref (SoupMessageQueueItem *item)
{
        fprintf(stderr, "[libsoup/soup-message-queue-item.c] enter soup_message_queue_item_unref 1\n");
        g_atomic_rc_box_release_full (item, (GDestroyNotify)soup_message_queue_item_destroy);
        // fprintf(stderr, "[libsoup/soup-message-queue-item.c] exit soup_message_queue_item_unref 1\n");
}

void
soup_message_queue_item_cancel (SoupMessageQueueItem *item)
{
        fprintf(stderr, "[libsoup/soup-message-queue-item.c] enter soup_message_queue_item_cancel 1\n");
        g_cancellable_cancel (item->cancellable);
        // fprintf(stderr, "[libsoup/soup-message-queue-item.c] exit soup_message_queue_item_cancel 1\n");
}
// Total cost: 0.017800
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 67)]
// Total instrumented cost: 0.017800, input tokens: 2398, output tokens: 958, cache read tokens: 2394, cache write tokens: 720

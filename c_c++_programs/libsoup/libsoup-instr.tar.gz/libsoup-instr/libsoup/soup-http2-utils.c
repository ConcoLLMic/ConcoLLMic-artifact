/*
 * Copyright 2022 Igalia, S.L.
 */

#include <glib.h>
#include <stdio.h>

#include "soup-http2-utils.h"

const char *
soup_http2_io_state_to_string (SoupHTTP2IOState state)
{
        fprintf(stderr, "\n");
        // fprintf(stderr, "\n");
        
        switch (state) {
        case STATE_NONE:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_io_state_to_string 2\n");
                return "NONE";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_io_state_to_string 2\n");
        case STATE_WRITE_HEADERS:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_io_state_to_string 3\n");
                return "WRITE_HEADERS";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_io_state_to_string 3\n");
        case STATE_WRITE_DATA:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_io_state_to_string 4\n");
                return "WRITE_DATA";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_io_state_to_string 4\n");
        case STATE_WRITE_DONE:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_io_state_to_string 5\n");
                return "WRITE_DONE";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_io_state_to_string 5\n");
        case STATE_READ_HEADERS:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_io_state_to_string 6\n");
                return "READ_HEADERS";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_io_state_to_string 6\n");
        case STATE_READ_DATA_START:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_io_state_to_string 7\n");
                return "READ_DATA_START";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_io_state_to_string 7\n");
        case STATE_READ_DATA:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_io_state_to_string 8\n");
                return "READ_DATA";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_io_state_to_string 8\n");
        case STATE_READ_DONE:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_io_state_to_string 9\n");
                return "READ_DONE";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_io_state_to_string 9\n");
        }
        fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_io_state_to_string 10\n");
        g_assert_not_reached ();
        return "";
        // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_io_state_to_string 10\n");
}

const char *
soup_http2_frame_type_to_string (nghttp2_frame_type type)
{
        fprintf(stderr, "\n");
        // fprintf(stderr, "\n");
        
        switch (type) {
        case NGHTTP2_DATA:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_frame_type_to_string 2\n");
                return "DATA";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_frame_type_to_string 2\n");
        case NGHTTP2_HEADERS:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_frame_type_to_string 3\n");
                return "HEADERS";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_frame_type_to_string 3\n");
        case NGHTTP2_PRIORITY:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_frame_type_to_string 4\n");
                return "PRIORITY";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_frame_type_to_string 4\n");
        case NGHTTP2_RST_STREAM:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_frame_type_to_string 5\n");
                return "RST_STREAM";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_frame_type_to_string 5\n");
        case NGHTTP2_SETTINGS:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_frame_type_to_string 6\n");
                return "SETTINGS";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_frame_type_to_string 6\n");
        case NGHTTP2_PING:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_frame_type_to_string 7\n");
                return "PING";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_frame_type_to_string 7\n");
        case NGHTTP2_GOAWAY:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_frame_type_to_string 8\n");
                return "GOAWAY";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_frame_type_to_string 8\n");
        case NGHTTP2_WINDOW_UPDATE:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_frame_type_to_string 9\n");
                return "WINDOW_UPDATE";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_frame_type_to_string 9\n");
        /* LCOV_EXCL_START */
        case NGHTTP2_PUSH_PROMISE:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_frame_type_to_string 10\n");
                return "PUSH_PROMISE";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_frame_type_to_string 10\n");
        case NGHTTP2_CONTINUATION:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_frame_type_to_string 11\n");
                return "CONTINUATION";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_frame_type_to_string 11\n");
        case NGHTTP2_ALTSVC:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_frame_type_to_string 12\n");
                return "ALTSVC";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_frame_type_to_string 12\n");
        case NGHTTP2_ORIGIN:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_frame_type_to_string 13\n");
                return "ORIGIN";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_frame_type_to_string 13\n");
        default:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_frame_type_to_string 14\n");
                g_warn_if_reached ();
                return "UNKNOWN";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_frame_type_to_string 14\n");
        /* LCOV_EXCL_STOP */
        }
}

const char *
soup_http2_headers_category_to_string (nghttp2_headers_category catergory)
{
        fprintf(stderr, "\n");
        // fprintf(stderr, "\n");
        
        switch (catergory) {
        case NGHTTP2_HCAT_REQUEST:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_headers_category_to_string 2\n");
                return "REQUEST";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_headers_category_to_string 2\n");
        case NGHTTP2_HCAT_RESPONSE:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_headers_category_to_string 3\n");
                return "RESPONSE";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_headers_category_to_string 3\n");
        case NGHTTP2_HCAT_PUSH_RESPONSE:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_headers_category_to_string 4\n");
                return "PUSH_RESPONSE";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_headers_category_to_string 4\n");
        case NGHTTP2_HCAT_HEADERS:
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_headers_category_to_string 5\n");
                return "HEADERS";
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_headers_category_to_string 5\n");
        }
        fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_headers_category_to_string 6\n");
        g_assert_not_reached ();
        return "";
        // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_headers_category_to_string 6\n");
}

G_GNUC_PRINTF(1, 0)
static void
debug_nghttp2 (const char *format,
               va_list     args)
{
        fprintf(stderr, "[libsoup/soup-http2-utils.c] enter debug_nghttp2 1\n");
        char *message;
        gsize len;
        // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit debug_nghttp2 1\n");

        if (g_log_writer_default_would_drop (G_LOG_LEVEL_DEBUG, "nghttp2"))
        {
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter debug_nghttp2 2\n");
                return;
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit debug_nghttp2 2\n");
        }

        fprintf(stderr, "[libsoup/soup-http2-utils.c] enter debug_nghttp2 3\n");
        message = g_strdup_vprintf (format, args);
        len = strlen (message);
        // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit debug_nghttp2 3\n");
        
        if (len >= 1 && message[len - 1] == '\n')
        {
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter debug_nghttp2 4\n");
                message[len - 1] = '\0';
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit debug_nghttp2 4\n");
        }
        
        fprintf(stderr, "[libsoup/soup-http2-utils.c] enter debug_nghttp2 5\n");
        g_log ("nghttp2", G_LOG_LEVEL_DEBUG, "[NGHTTP2] %s", message);
        g_free (message);
        // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit debug_nghttp2 5\n");
}

void
soup_http2_debug_init (void)
{
        fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_debug_init 1\n");
        static gsize nghttp2_debug_init = 0;
        // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_debug_init 1\n");
        
        if (g_once_init_enter (&nghttp2_debug_init)) {
                fprintf(stderr, "[libsoup/soup-http2-utils.c] enter soup_http2_debug_init 2\n");
                nghttp2_set_debug_vprintf_callback(debug_nghttp2);
                g_once_init_leave (&nghttp2_debug_init, 1);
                // fprintf(stderr, "[libsoup/soup-http2-utils.c] exit soup_http2_debug_init 2\n");
        }

}
// Total cost: 0.104739
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 115)]
// Total instrumented cost: 0.104739, input tokens: 5896, output tokens: 5861, cache read tokens: 5888, cache write tokens: 4009

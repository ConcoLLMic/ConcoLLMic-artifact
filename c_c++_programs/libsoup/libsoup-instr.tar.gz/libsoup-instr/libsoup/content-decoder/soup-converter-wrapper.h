/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright 2011 Red Hat, Inc.
 */

#pragma once

#include "soup-types.h"

G_BEGIN_DECLS

#define SOUP_TYPE_CONVERTER_WRAPPER (soup_converter_wrapper_get_type ())
G_DECLARE_FINAL_TYPE (SoupConverterWrapper, soup_converter_wrapper, SOUP, CONVERTER_WRAPPER, GObject)

GConverter *soup_converter_wrapper_new (GConverter  *base_converter,
					SoupMessage *msg);

G_END_DECLS
// Total cost: 0.002035
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 18)]
// Total instrumented cost: 0.002035, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 256

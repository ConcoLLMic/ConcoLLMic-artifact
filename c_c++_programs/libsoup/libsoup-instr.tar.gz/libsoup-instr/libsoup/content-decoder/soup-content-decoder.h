/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright (C) 2009 Red Hat, Inc.
 */

#pragma once

#include "soup-types.h"
#include "soup-message-body.h"

G_BEGIN_DECLS

#define SOUP_TYPE_CONTENT_DECODER            (soup_content_decoder_get_type ())
SOUP_AVAILABLE_IN_ALL
G_DECLARE_FINAL_TYPE (SoupContentDecoder, soup_content_decoder, SOUP, CONTENT_DECODER, GObject)

G_END_DECLS
// Total cost: 0.002028
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 17)]
// Total instrumented cost: 0.002028, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 254

/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright (C) 2012 Igalia, S.L.
 */


#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include "soup-content-processor.h"
#include "soup.h"

G_DEFINE_INTERFACE (SoupContentProcessor, soup_content_processor, G_TYPE_OBJECT)

static GInputStream *
soup_content_processor_real_wrap_input (SoupContentProcessor *processor,
					GInputStream *base_stream,
					SoupMessage *msg,
					GError **error)
{
	fprintf(stderr, "[libsoup/content-decoder/soup-content-processor.c] enter soup_content_processor_real_wrap_input 1\n");
	g_return_val_if_reached (NULL);
	// fprintf(stderr, "[libsoup/content-decoder/soup-content-processor.c] exit soup_content_processor_real_wrap_input 1\n");
}

static void
soup_content_processor_default_init (SoupContentProcessorInterface *interface)
{
	fprintf(stderr, "[libsoup/content-decoder/soup-content-processor.c] enter soup_content_processor_default_init 1\n");
	interface->processing_stage = SOUP_STAGE_INVALID;
	interface->wrap_input = soup_content_processor_real_wrap_input;
	// fprintf(stderr, "[libsoup/content-decoder/soup-content-processor.c] exit soup_content_processor_default_init 1\n");
}

GInputStream *
soup_content_processor_wrap_input (SoupContentProcessor *processor,
				   GInputStream *base_stream,
				   SoupMessage *msg,
				   GError **error)
{
	fprintf(stderr, "[libsoup/content-decoder/soup-content-processor.c] enter soup_content_processor_wrap_input 1\n");
	g_return_val_if_fail (SOUP_IS_CONTENT_PROCESSOR (processor), NULL);

	return SOUP_CONTENT_PROCESSOR_GET_IFACE (processor)->wrap_input (processor, base_stream, msg, error);
	// fprintf(stderr, "[libsoup/content-decoder/soup-content-processor.c] exit soup_content_processor_wrap_input 1\n");
}

SoupProcessingStage
soup_content_processor_get_processing_stage (SoupContentProcessor *processor)
{
	fprintf(stderr, "[libsoup/content-decoder/soup-content-processor.c] enter soup_content_processor_get_processing_stage 1\n");
	g_return_val_if_fail (SOUP_IS_CONTENT_PROCESSOR (processor), SOUP_STAGE_INVALID);

	return SOUP_CONTENT_PROCESSOR_GET_IFACE (processor)->processing_stage;
	// fprintf(stderr, "[libsoup/content-decoder/soup-content-processor.c] exit soup_content_processor_get_processing_stage 1\n");
}
// Total cost: 0.012899
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 49)]
// Total instrumented cost: 0.012899, input tokens: 2398, output tokens: 675, cache read tokens: 2394, cache write tokens: 545

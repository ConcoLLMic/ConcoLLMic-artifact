/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * soup-content-decoder.c
 *
 * Copyright (C) 2009 Red Hat, Inc.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include "soup-content-decoder.h"
#include "soup-converter-wrapper.h"
#include "soup-session-feature-private.h"
#include "soup-message-private.h"
#include "soup-message-headers-private.h"
#include "soup-headers.h"
#include "soup-uri-utils-private.h"
#ifdef WITH_BROTLI
#include "soup-brotli-decompressor.h"
#endif

/**
 * SoupContentDecoder:
 *
 * Handles decoding of HTTP messages.
 *
 * #SoupContentDecoder handles adding the "Accept-Encoding" header on
 * outgoing messages, and processing the "Content-Encoding" header on
 * incoming ones. Currently it supports the "gzip", "deflate", and "br"
 * content codings.
 *
 * A #SoupContentDecoder will automatically be
 * added to the session by default. (You can use
 * [method@Session.remove_feature_by_type] if you don't
 * want this.)
 *
 * If #SoupContentDecoder successfully decodes the Content-Encoding,
 * the message body will contain the decoded data; however, the message headers
 * will be unchanged (and so "Content-Encoding" will still be present,
 * "Content-Length" will describe the original encoded length, etc).
 *
 * If "Content-Encoding" contains any encoding types that
 * #SoupContentDecoder doesn't recognize, then none of the encodings
 * will be decoded.
 *
 * (Note that currently there is no way to (automatically) use
 * Content-Encoding when sending a request body, or to pick specific
 * encoding types to support.)
 **/

struct _SoupContentDecoder {
	GObject parent;
};

typedef struct {
	GHashTable *decoders;
} SoupContentDecoderPrivate;

typedef GConverter * (*SoupContentDecoderCreator) (void);

static void soup_content_decoder_session_feature_init (SoupSessionFeatureInterface *feature_interface, gpointer interface_data);

static SoupContentProcessorInterface *soup_content_decoder_default_content_processor_interface;
static void soup_content_decoder_content_processor_init (SoupContentProcessorInterface *interface, gpointer interface_data);


G_DEFINE_FINAL_TYPE_WITH_CODE (SoupContentDecoder, soup_content_decoder, G_TYPE_OBJECT,
                               G_ADD_PRIVATE (SoupContentDecoder)
			       G_IMPLEMENT_INTERFACE (SOUP_TYPE_SESSION_FEATURE,
						      soup_content_decoder_session_feature_init)
			       G_IMPLEMENT_INTERFACE (SOUP_TYPE_CONTENT_PROCESSOR,
						      soup_content_decoder_content_processor_init))

static GSList *
soup_content_decoder_get_decoders_for_msg (SoupContentDecoder *decoder, SoupMessage *msg)
{
    fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_get_decoders_for_msg 1\n");
    SoupContentDecoderPrivate *priv = soup_content_decoder_get_instance_private (decoder);
	const char *header;
	GSList *encodings, *e, *decoders = NULL;
	SoupContentDecoderCreator converter_creator;
	GConverter *converter;

	header = soup_message_headers_get_list_common (soup_message_get_response_headers (msg),
                                                       SOUP_HEADER_CONTENT_ENCODING);
	if (!header)
    {
        fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_get_decoders_for_msg 2\n");
		return NULL;
        // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_get_decoders_for_msg 2\n");
    }

	/* Workaround for an apache bug (bgo 613361) */
	if (!g_ascii_strcasecmp (header, "gzip") ||
	    !g_ascii_strcasecmp (header, "x-gzip")) {
        fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_get_decoders_for_msg 3\n");
		const char *content_type = soup_message_headers_get_content_type (soup_message_get_response_headers (msg), NULL);

		if (content_type &&
		    (!g_ascii_strcasecmp (content_type, "application/gzip") ||
		     !g_ascii_strcasecmp (content_type, "application/x-gzip")))
        {
            fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_get_decoders_for_msg 4\n");
			return NULL;
            // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_get_decoders_for_msg 4\n");
        }
        // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_get_decoders_for_msg 3\n");
	}

	/* OK, really, no one is ever going to use more than one
	 * encoding, but we'll be robust.
	 */
    fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_get_decoders_for_msg 5\n");
	encodings = soup_header_parse_list (header);
	if (!encodings)
    {
        fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_get_decoders_for_msg 6\n");
		return NULL;
        // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_get_decoders_for_msg 6\n");
    }

	for (e = encodings; e; e = e->next) {
        fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_get_decoders_for_msg 7\n");
		if (!g_hash_table_lookup (priv->decoders, e->data)) {
            fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_get_decoders_for_msg 8\n");
			soup_header_free_list (encodings);
			return NULL;
            // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_get_decoders_for_msg 8\n");
		}
        // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_get_decoders_for_msg 7\n");
	}

	for (e = encodings; e; e = e->next) {
        fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_get_decoders_for_msg 9\n");
		converter_creator = g_hash_table_lookup (priv->decoders, e->data);
		converter = converter_creator ();

		/* Content-Encoding lists the codings in the order
		 * they were applied in, so we put decoders in reverse
		 * order so the last-applied will be the first
		 * decoded.
		 */
		decoders = g_slist_prepend (decoders, converter);
        // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_get_decoders_for_msg 9\n");
	}
    fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_get_decoders_for_msg 10\n");
	soup_header_free_list (encodings);

	return decoders;
    // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_get_decoders_for_msg 10\n");
    // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_get_decoders_for_msg 5\n");
    // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_get_decoders_for_msg 1\n");
}

static GInputStream*
soup_content_decoder_content_processor_wrap_input (SoupContentProcessor *processor,
						   GInputStream *base_stream,
						   SoupMessage *msg,
						   GError **error)
{
    fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_content_processor_wrap_input 1\n");
	GSList *decoders, *d;
	GInputStream *istream;

	decoders = soup_content_decoder_get_decoders_for_msg (SOUP_CONTENT_DECODER (processor), msg);
	if (!decoders)
    {
        fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_content_processor_wrap_input 2\n");
		return NULL;
        // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_content_processor_wrap_input 2\n");
    }

    fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_content_processor_wrap_input 3\n");
	istream = g_object_ref (base_stream);
	for (d = decoders; d; d = d->next) {
        fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_content_processor_wrap_input 4\n");
		GConverter *decoder, *wrapper;
		GInputStream *filter;

		decoder = d->data;
		wrapper = soup_converter_wrapper_new (decoder, msg);
		filter = g_object_new (G_TYPE_CONVERTER_INPUT_STREAM,
				       "base-stream", istream,
				       "converter", wrapper,
				       NULL);
		g_object_unref (istream);
		g_object_unref (wrapper);
		istream = filter;
        // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_content_processor_wrap_input 4\n");
	}

    fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_content_processor_wrap_input 5\n");
	g_slist_free_full (decoders, g_object_unref);

	return istream;
    // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_content_processor_wrap_input 5\n");
    // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_content_processor_wrap_input 3\n");
    // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_content_processor_wrap_input 1\n");
}

static void
soup_content_decoder_content_processor_init (SoupContentProcessorInterface *processor_interface,
					     gpointer interface_data)
{
    fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_content_processor_init 1\n");
	soup_content_decoder_default_content_processor_interface =
		g_type_default_interface_peek (SOUP_TYPE_CONTENT_PROCESSOR);

	processor_interface->processing_stage = SOUP_STAGE_CONTENT_ENCODING;
	processor_interface->wrap_input = soup_content_decoder_content_processor_wrap_input;
    // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_content_processor_init 1\n");
}

static GConverter *
gzip_decoder_creator (void)
{
    fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter gzip_decoder_creator 1\n");
	return (GConverter *)g_zlib_decompressor_new (G_ZLIB_COMPRESSOR_FORMAT_GZIP);
    // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit gzip_decoder_creator 1\n");
}

static GConverter *
zlib_decoder_creator (void)
{
    fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter zlib_decoder_creator 1\n");
	return (GConverter *)g_zlib_decompressor_new (G_ZLIB_COMPRESSOR_FORMAT_ZLIB);
    // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit zlib_decoder_creator 1\n");
}

#ifdef WITH_BROTLI
static GConverter *
brotli_decoder_creator (void)
{
    fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter brotli_decoder_creator 1\n");
	return (GConverter *)soup_brotli_decompressor_new ();
    // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit brotli_decoder_creator 1\n");
}
#endif

static void
soup_content_decoder_init (SoupContentDecoder *decoder)
{
    fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_init 1\n");
    SoupContentDecoderPrivate *priv = soup_content_decoder_get_instance_private (decoder);

	priv->decoders = g_hash_table_new (g_str_hash, g_str_equal);
	/* Hardcoded for now */
	g_hash_table_insert (priv->decoders, "gzip",
			     gzip_decoder_creator);
	g_hash_table_insert (priv->decoders, "x-gzip",
			     gzip_decoder_creator);
	g_hash_table_insert (priv->decoders, "deflate",
			     zlib_decoder_creator);
#ifdef WITH_BROTLI
	g_hash_table_insert (priv->decoders, "br",
			     brotli_decoder_creator);
#endif
    // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_init 1\n");
}

static void
soup_content_decoder_finalize (GObject *object)
{
    fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_finalize 1\n");
	SoupContentDecoder *decoder = SOUP_CONTENT_DECODER (object);
    SoupContentDecoderPrivate *priv = soup_content_decoder_get_instance_private (decoder);

	g_hash_table_destroy (priv->decoders);

	G_OBJECT_CLASS (soup_content_decoder_parent_class)->finalize (object);
    // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_finalize 1\n");
}

static void
soup_content_decoder_class_init (SoupContentDecoderClass *decoder_class)
{
    fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_class_init 1\n");
	GObjectClass *object_class = G_OBJECT_CLASS (decoder_class);

	object_class->finalize = soup_content_decoder_finalize;
    // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_class_init 1\n");
}

static void
soup_content_decoder_request_queued (SoupSessionFeature *feature,
				     SoupMessage        *msg)
{
    fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_request_queued 1\n");
	if (!soup_message_headers_get_one_common (soup_message_get_request_headers (msg),
                                                  SOUP_HEADER_ACCEPT_ENCODING)) {
        fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_request_queued 2\n");
        const char *header = "gzip, deflate";

#ifdef WITH_BROTLI
        /* brotli is only enabled over TLS connections
         * as other browsers have found that some networks have expectations
         * regarding the encoding of HTTP messages and this may break those
         * expectations. Firefox and Chromium behave similarly.
         */
        if (soup_uri_is_https (soup_message_get_uri (msg)))
        {
            fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_request_queued 3\n");
            header = "gzip, deflate, br";
            // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_request_queued 3\n");
        }
#endif

		soup_message_headers_append_common (soup_message_get_request_headers (msg),
                                                    SOUP_HEADER_ACCEPT_ENCODING, header);
        // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_request_queued 2\n");
	}
    // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_request_queued 1\n");
}

static void
soup_content_decoder_session_feature_init (SoupSessionFeatureInterface *feature_interface,
					   gpointer interface_data)
{
    fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] enter soup_content_decoder_session_feature_init 1\n");
	feature_interface->request_queued = soup_content_decoder_request_queued;
    // fprintf(stderr, "[libsoup/content-decoder/soup-content-decoder.c] exit soup_content_decoder_session_feature_init 1\n");
}
// Total cost: 0.072640
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 261)]
// Total instrumented cost: 0.072640, input tokens: 2398, output tokens: 4093, cache read tokens: 2394, cache write tokens: 2804

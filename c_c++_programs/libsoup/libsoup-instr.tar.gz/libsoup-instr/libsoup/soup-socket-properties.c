/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright 2013 Red Hat, Inc.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include "soup-socket-properties.h"
#include "soup.h"

SoupSocketProperties *
soup_socket_properties_new (GInetSocketAddress *local_addr,
			    GTlsInteraction    *tls_interaction,
			    guint               io_timeout,
			    guint               idle_timeout)
{
	fprintf(stderr, "[libsoup/soup-socket-properties.c] enter soup_socket_properties_new 1\n");
	SoupSocketProperties *props;

	props = g_atomic_rc_box_new0 (SoupSocketProperties);

	props->proxy_use_default = TRUE;
	props->tlsdb_use_default = TRUE;

	props->local_addr = local_addr ? g_object_ref (local_addr) : NULL;
	props->tls_interaction = tls_interaction ? g_object_ref (tls_interaction) : NULL;

	props->io_timeout = io_timeout;
	props->idle_timeout = idle_timeout;

	return props;
	// fprintf(stderr, "[libsoup/soup-socket-properties.c] exit soup_socket_properties_new 1\n");
}

SoupSocketProperties *
soup_socket_properties_ref (SoupSocketProperties *props)
{
	fprintf(stderr, "[libsoup/soup-socket-properties.c] enter soup_socket_properties_ref 1\n");
        g_atomic_rc_box_acquire (props);

	return props;
	// fprintf(stderr, "[libsoup/soup-socket-properties.c] exit soup_socket_properties_ref 1\n");
}

static void
soup_socket_properties_destroy (SoupSocketProperties *props)
{
	fprintf(stderr, "[libsoup/soup-socket-properties.c] enter soup_socket_properties_destroy 1\n");
        g_clear_object (&props->proxy_resolver);
        g_clear_object (&props->local_addr);
	g_clear_object (&props->tlsdb);
	g_clear_object (&props->tls_interaction);
	// fprintf(stderr, "[libsoup/soup-socket-properties.c] exit soup_socket_properties_destroy 1\n");
}

void
soup_socket_properties_unref (SoupSocketProperties *props)
{
	fprintf(stderr, "[libsoup/soup-socket-properties.c] enter soup_socket_properties_unref 1\n");
        g_atomic_rc_box_release_full (props, (GDestroyNotify)soup_socket_properties_destroy);
	// fprintf(stderr, "[libsoup/soup-socket-properties.c] exit soup_socket_properties_unref 1\n");
}

void
soup_socket_properties_set_proxy_resolver (SoupSocketProperties *props,
					   GProxyResolver       *proxy_resolver)
{
	fprintf(stderr, "[libsoup/soup-socket-properties.c] enter soup_socket_properties_set_proxy_resolver 1\n");
	props->proxy_use_default = FALSE;
	// fprintf(stderr, "[libsoup/soup-socket-properties.c] exit soup_socket_properties_set_proxy_resolver 1\n");

	if (props->proxy_resolver == proxy_resolver)
	{
		fprintf(stderr, "[libsoup/soup-socket-properties.c] enter soup_socket_properties_set_proxy_resolver 2\n");
		return;
		// fprintf(stderr, "[libsoup/soup-socket-properties.c] exit soup_socket_properties_set_proxy_resolver 2\n");
	}

	fprintf(stderr, "[libsoup/soup-socket-properties.c] enter soup_socket_properties_set_proxy_resolver 3\n");
	g_clear_object (&props->proxy_resolver);
	props->proxy_resolver = proxy_resolver ? g_object_ref (proxy_resolver) : NULL;
	// fprintf(stderr, "[libsoup/soup-socket-properties.c] exit soup_socket_properties_set_proxy_resolver 3\n");
}

void
soup_socket_properties_set_tls_database (SoupSocketProperties *props,
					 GTlsDatabase         *tlsdb)
{
	fprintf(stderr, "[libsoup/soup-socket-properties.c] enter soup_socket_properties_set_tls_database 1\n");
	props->tlsdb_use_default = FALSE;
	// fprintf(stderr, "[libsoup/soup-socket-properties.c] exit soup_socket_properties_set_tls_database 1\n");

	if (props->tlsdb == tlsdb)
	{
		fprintf(stderr, "[libsoup/soup-socket-properties.c] enter soup_socket_properties_set_tls_database 2\n");
		return;
		// fprintf(stderr, "[libsoup/soup-socket-properties.c] exit soup_socket_properties_set_tls_database 2\n");
	}

	fprintf(stderr, "[libsoup/soup-socket-properties.c] enter soup_socket_properties_set_tls_database 3\n");
	g_clear_object (&props->tlsdb);
	props->tlsdb = tlsdb ? g_object_ref (tlsdb) : NULL;
	// fprintf(stderr, "[libsoup/soup-socket-properties.c] exit soup_socket_properties_set_tls_database 3\n");
}

G_DEFINE_BOXED_TYPE (SoupSocketProperties, soup_socket_properties, soup_socket_properties_ref, soup_socket_properties_unref)
// Total cost: 0.022484
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 84)]
// Total instrumented cost: 0.022484, input tokens: 2398, output tokens: 1245, cache read tokens: 2394, cache write tokens: 821

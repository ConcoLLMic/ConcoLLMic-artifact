/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Copyright 2012 Red Hat, Inc.
 */

#pragma once

#include "soup-types.h"

G_BEGIN_DECLS

#define SOUP_TYPE_IO_STREAM            (soup_io_stream_get_type ())
G_DECLARE_FINAL_TYPE (SoupIOStream, soup_io_stream, SOUP, IO_STREAM, GIOStream)

GIOStream *soup_io_stream_new (GIOStream *base_iostream,
			       gboolean   close_on_dispose);

GIOStream *soup_io_stream_get_base_iostream (SoupIOStream *stream);

G_END_DECLS
// Total cost: 0.002129
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 20)]
// Total instrumented cost: 0.002129, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 281

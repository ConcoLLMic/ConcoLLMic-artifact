#!/usr/bin/env python3

import sys
import subprocess

def main():
    sys.stderr.write("[libsoup/generate-header-names.py] enter main 1\n")
    http_header_name_to_id = { }
    http_header_names = []
    with open('soup-header-names.in') as i:
        for line in i.readlines():
            sys.stderr.write("[libsoup/generate-header-names.py] enter main 2\n")
            name = line.strip();
            if not name or name[0] == '#':
                sys.stderr.write("\n")
                # sys.stderr.write("\n")
                continue

            http_header_name_to_id[name] = 'SOUP_HEADER_' + name.upper().replace('-', '_')
            http_header_names.append(name)
            # sys.stderr.write("[libsoup/generate-header-names.py] exit main 2\n")

    http_header_names.sort()

    gperf_file = '''%{
/* This file has been generated with generate-header-names.py script, do not edit */
#include "soup-header-names.h"
#include <string.h>

static const char * const soup_headr_name_strings[] = {
'''

    for name in http_header_names:
        sys.stderr.write("[libsoup/generate-header-names.py] enter main 4\n")
        gperf_file += '  "%s",\n' % name
        # sys.stderr.write("[libsoup/generate-header-names.py] exit main 4\n")

    gperf_file += '''};
%}
%language=ANSI-C
%struct-type
struct SoupHeaderHashEntry {
    int name;
    SoupHeaderName header_name;
};
%define hash-function-name soup_header_name_hash_function
%define lookup-function-name soup_header_name_find
%readonly-tables
%global-table
%compare-strncmp
%ignore-case
%pic
%%
'''

    for name in http_header_names:
        sys.stderr.write("[libsoup/generate-header-names.py] enter main 5\n")
        gperf_file += '%s, %s\n' % (name, http_header_name_to_id[name])
        # sys.stderr.write("[libsoup/generate-header-names.py] exit main 5\n")

    gperf_file += '''%%
SoupHeaderName soup_header_name_from_string (const char *str)
{
        const struct SoupHeaderHashEntry *entry;

        entry = soup_header_name_find (str, strlen (str));
        return entry ? entry->header_name : SOUP_HEADER_UNKNOWN;
}

const char *soup_header_name_to_string (SoupHeaderName name)
{
        if (name == SOUP_HEADER_UNKNOWN)
                return NULL;

        return soup_headr_name_strings[name];
}
'''

    command = ['gperf', '-k', '*', '-D', '-n', '-s', '2']
    p = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    output, error = p.communicate(gperf_file)

    if p.returncode != 0:
        sys.stderr.write("[libsoup/generate-header-names.py] enter main 6\n")
        print(error)
        sys.exit(p.returncode)
        # sys.stderr.write("[libsoup/generate-header-names.py] exit main 6\n")

    with open('soup-header-names.c', 'w+') as o:
        sys.stderr.write("[libsoup/generate-header-names.py] enter main 7\n")
        o.write(output.replace('const struct SoupHeaderHashEntry *', 'static const struct SoupHeaderHashEntry *', 1))
        # sys.stderr.write("[libsoup/generate-header-names.py] exit main 7\n")


    output = '''/* This file has been generated with generate-header-names.py script, do not edit */

#pragma once

typedef enum {
'''

    for name in http_header_names:
        sys.stderr.write("[libsoup/generate-header-names.py] enter main 8\n")
        output += '        %s,\n' % http_header_name_to_id[name]
        # sys.stderr.write("[libsoup/generate-header-names.py] exit main 8\n")

    output +='''
        SOUP_HEADER_UNKNOWN
} SoupHeaderName;

SoupHeaderName soup_header_name_from_string (const char    *str);
const char    *soup_header_name_to_string   (SoupHeaderName name);
'''

    with open('soup-header-names.h', 'w+') as o:
        sys.stderr.write("[libsoup/generate-header-names.py] enter main 9\n")
        o.write(output)
        # sys.stderr.write("[libsoup/generate-header-names.py] exit main 9\n")
    # sys.stderr.write("[libsoup/generate-header-names.py] exit main 1\n")

if __name__ == "__main__":
    main()
# Total cost: 0.022131
# Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 100)]
# Total instrumented cost: 0.022131, input tokens: 2398, output tokens: 1192, cache read tokens: 2394, cache write tokens: 939

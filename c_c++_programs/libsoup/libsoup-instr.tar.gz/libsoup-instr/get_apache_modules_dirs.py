#!/usr/bin/env python3
#
# Copyright 2017, 2018 Tomas Popela <tpopela@redhat.com>
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be included
# in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

import re
import subprocess
import sys
import os
import glob

def check_module(modules_path, module):
     sys.stderr.write("[get_apache_modules_dirs.py] enter check_module 1\n")
     module_path = os.path.join(modules_path, module)
     return os.path.isfile(module_path)
     # sys.stderr.write("[get_apache_modules_dirs.py] exit check_module 1\n")


def check_required_basic_modules(modules_path):
    sys.stderr.write("[get_apache_modules_dirs.py] enter check_required_basic_modules 1\n")
    apache_required_modules = [
        'mod_alias',
        'mod_auth_basic',
        'mod_auth_digest',
        'mod_authn_core',
        'mod_authn_file',
        'mod_authz_core',
        'mod_authz_host',
        'mod_authz_user',
        'mod_dir',
        'mod_mime',
        'mod_mpm_event',
        'mod_proxy',
        'mod_proxy_http',
        'mod_proxy_connect'
    ]

    found = 0
    not_found = []
    # sys.stderr.write("[get_apache_modules_dirs.py] exit check_required_basic_modules 1\n")
    
    for module_name in apache_required_modules:
        sys.stderr.write("[get_apache_modules_dirs.py] enter check_required_basic_modules 2\n")
        if not check_module(modules_path, module_name + '.so'):
            sys.stderr.write("[get_apache_modules_dirs.py] enter check_required_basic_modules 3\n")
            if found == 0:
                sys.stderr.write("[get_apache_modules_dirs.py] enter check_required_basic_modules 4\n")
                return False
                # sys.stderr.write("[get_apache_modules_dirs.py] exit check_required_basic_modules 4\n")
            # If we found at least one module, continue and later report all the
            # modules that we didn't find.
            not_found.append(module_name)
            # sys.stderr.write("[get_apache_modules_dirs.py] exit check_required_basic_modules 3\n")
        else:
            sys.stderr.write("[get_apache_modules_dirs.py] enter check_required_basic_modules 5\n")
            found += 1
            # sys.stderr.write("[get_apache_modules_dirs.py] exit check_required_basic_modules 5\n")
        # sys.stderr.write("[get_apache_modules_dirs.py] exit check_required_basic_modules 2\n")

    sys.stderr.write("[get_apache_modules_dirs.py] enter check_required_basic_modules 6\n")
    if found < len(apache_required_modules):
        sys.stderr.write("[get_apache_modules_dirs.py] enter check_required_basic_modules 7\n")
        print('Failed to find required Apache modules for running tests: ' + ', '.join(not_found), file=sys.stderr)
        return False
        # sys.stderr.write("[get_apache_modules_dirs.py] exit check_required_basic_modules 7\n")

    return True
    # sys.stderr.write("[get_apache_modules_dirs.py] exit check_required_basic_modules 6\n")


def main():
    """Checks whether the required Apache modules are available and prints their
       paths to stdout (values are separated by colons).

       Only one argument is required - path to the Apache's apachectl executable"""
    sys.stderr.write("[get_apache_modules_dirs.py] enter main 1\n")
    if len(sys.argv) != 2:
        sys.stderr.write("[get_apache_modules_dirs.py] enter main 2\n")
        print('Only one argument with path to the Apache apachectl executable expected!', file=sys.stderr)
        sys.exit(1)
        # sys.stderr.write("[get_apache_modules_dirs.py] exit main 2\n")

    apachectl_executable = sys.argv[1]
    # sys.stderr.write("[get_apache_modules_dirs.py] exit main 1\n")

    sys.stderr.write("[get_apache_modules_dirs.py] enter main 3\n")
    if not os.path.isfile(apachectl_executable):
        sys.stderr.write("[get_apache_modules_dirs.py] enter main 4\n")
        print('The passed Apache apachectl executable does not exist!', file=sys.stderr)
        sys.exit(1)
        # sys.stderr.write("[get_apache_modules_dirs.py] exit main 4\n")

    apache_prefix = os.path.dirname(os.path.dirname(apachectl_executable))
    apachectl_output = subprocess.run(
        [apachectl_executable, '-V', '-C', 'ServerName localhost'], stdout=subprocess.PIPE)
    # sys.stderr.write("[get_apache_modules_dirs.py] exit main 3\n")
    
    sys.stderr.write("[get_apache_modules_dirs.py] enter main 5\n")
    if apachectl_output.returncode != 0:
        sys.stderr.write("[get_apache_modules_dirs.py] enter main 6\n")
        print('Something went wrong when calling ' + apachectl_executable + '!', file=sys.stderr)
        sys.exit(1)
        # sys.stderr.write("[get_apache_modules_dirs.py] exit main 6\n")

    mpm_regex = re.compile(r'\nServer MPM:[\s]+([\w]+)\n')
    mpm = mpm_regex.search(apachectl_output.stdout.decode('utf-8')).group(1).lower()

    apache_modules_dir = ''
    apache_ssl_module_dir = ''
    apache_mod_unixd_module_file = ''
    apache_http2_module_dir = ''
    # sys.stderr.write("[get_apache_modules_dirs.py] exit main 5\n")

    for lib_dir in ['lib', 'lib64']:
        sys.stderr.write("[get_apache_modules_dirs.py] enter main 7\n")
        for httpd_dir in ['apache', 'apache2', 'http', 'http2', 'httpd']:
            sys.stderr.write("[get_apache_modules_dirs.py] enter main 8\n")
            for mpm_suffix in ['', '-' + mpm]:
                sys.stderr.write("[get_apache_modules_dirs.py] enter main 9\n")
                for modules_dir in ['', 'modules']:
                    sys.stderr.write("[get_apache_modules_dirs.py] enter main 10\n")
                    modules_path = os.path.join(apache_prefix, lib_dir, httpd_dir + mpm_suffix, modules_dir)
                    # sys.stderr.write("[get_apache_modules_dirs.py] exit main 10\n")
                    
                    sys.stderr.write("[get_apache_modules_dirs.py] enter main 11\n")
                    if check_required_basic_modules(modules_path):
                        sys.stderr.write("[get_apache_modules_dirs.py] enter main 12\n")
                        apache_modules_dir = modules_path
                        # sys.stderr.write("[get_apache_modules_dirs.py] exit main 12\n")
                    # sys.stderr.write("[get_apache_modules_dirs.py] exit main 11\n")
                    
                    sys.stderr.write("[get_apache_modules_dirs.py] enter main 13\n")
                    if check_module(modules_path, 'mod_ssl.so'):
                        sys.stderr.write("[get_apache_modules_dirs.py] enter main 14\n")
                        apache_ssl_module_dir = modules_path
                        # sys.stderr.write("[get_apache_modules_dirs.py] exit main 14\n")
                    # sys.stderr.write("[get_apache_modules_dirs.py] exit main 13\n")
                    
                    sys.stderr.write("[get_apache_modules_dirs.py] enter main 15\n")
                    if check_module(modules_path, 'mod_unixd.so'):
                        sys.stderr.write("[get_apache_modules_dirs.py] enter main 16\n")
                        apache_mod_unixd_module_file = modules_path
                        # sys.stderr.write("[get_apache_modules_dirs.py] exit main 16\n")
                    # sys.stderr.write("[get_apache_modules_dirs.py] exit main 15\n")
                    
                    sys.stderr.write("[get_apache_modules_dirs.py] enter main 17\n")
                    if check_module(modules_path, 'mod_http2.so'):
                        sys.stderr.write("[get_apache_modules_dirs.py] enter main 18\n")
                        apache_http2_module_dir = modules_path
                        # sys.stderr.write("[get_apache_modules_dirs.py] exit main 18\n")
                    # sys.stderr.write("[get_apache_modules_dirs.py] exit main 17\n")
                # sys.stderr.write("[get_apache_modules_dirs.py] exit main 9\n")
            # sys.stderr.write("[get_apache_modules_dirs.py] exit main 8\n")
        # sys.stderr.write("[get_apache_modules_dirs.py] exit main 7\n")

    sys.stderr.write("[get_apache_modules_dirs.py] enter main 19\n")
    # These two are mandatory for having properly configured Apache
    if apache_modules_dir == '' or apache_ssl_module_dir == '':
        sys.stderr.write("[get_apache_modules_dirs.py] enter main 20\n")
        sys.exit(1)
        # sys.stderr.write("[get_apache_modules_dirs.py] exit main 20\n")

    print(apache_modules_dir + ":" +
          apache_ssl_module_dir + ":" +
          apache_mod_unixd_module_file + ":" +
          apache_http2_module_dir, end='')
    # sys.stderr.write("[get_apache_modules_dirs.py] exit main 19\n")

if __name__ == "__main__":
    sys.stderr.write("[get_apache_modules_dirs.py] enter module 1\n")
    main()
    # sys.stderr.write("[get_apache_modules_dirs.py] exit module 1\n")
# Total cost: 0.037483
# Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 128)]
# Total instrumented cost: 0.037483, input tokens: 3858, output tokens: 2421, cache read tokens: 3854, cache write tokens: 0
